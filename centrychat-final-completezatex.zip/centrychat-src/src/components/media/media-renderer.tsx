"use client";

import { useState, useEffect, useRef } from "react";
import { Loader2, AlertCircle, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ResolvedMedia } from "@/lib/media/types";
import { MediaUnavailableFallback } from "./media-unavailable";

// ── Types ─────────────────────────────────────────────────────────────────

type MediaRendererVariant = "full" | "card" | "avatar";

interface MediaRendererProps {
  /** The resolved media object (from useMediaResolver or server-side). */
  media: ResolvedMedia | null;
  /** Loading state — when true, render a skeleton. */
  loading?: boolean;
  /** Error message — when set, render the fallback. */
  error?: string | null;
  /**
   * Display variant:
   *   - "full"   → large media (article reading page cover image + video)
   *   - "card"   → small thumbnail + aspect ratio (article card on home/profile)
   *   - "avatar" → circular small (profile avatar — only renders images)
   */
  variant?: MediaRendererVariant;
  /** Alt text for images. */
  alt?: string;
  /** Optional className for the outer wrapper. */
  className?: string;
  /** Optional title hint for the media (used in fallback card). */
  titleHint?: string;
}

// ── Component ────────────────────────────────────────────────────────────

/**
 * MediaRenderer — the SINGLE component that renders a ResolvedMedia.
 *
 * Behavior by `media.type`:
 *   - "image"   → responsive <img> with onLoad/onError (fallback to MediaUnavailableFallback)
 *   - "video"   → responsive <video controls preload="metadata">
 *   - "embed"   → responsive <iframe allowFullScreen> + sandbox where possible
 *   - "preview" → MediaUnavailableFallback card with title + open original
 *   - "unknown" → MediaUnavailableFallback card
 *
 * The renderer NEVER does URL classification itself — it trusts the
 * `media.type` from the resolver. The resolver is the SINGLE source of
 * truth for "what kind of media is this URL".
 *
 * Fallback chain:
 *   - If `media` is null AND `loading` is true  → skeleton
 *   - If `media` is null AND `error` is non-null → error card
 *   - If `media.type` is "unknown" or "preview"   → MediaUnavailableFallback
 *   - If <img>/<video>/<iframe> onError fires     → MediaUnavailableFallback
 *
 * Performance:
 *   - Images + iframes use `loading="lazy"` (except "full" variant which
 *     uses `loading="eager"` because it's above the fold).
 *   - The fallback is rendered lazily — only when an error fires.
 */
export function MediaRenderer({
  media,
  loading = false,
  error = null,
  variant = "full",
  alt,
  className,
  titleHint,
}: MediaRendererProps) {
  // ── Loading skeleton ─────────────────────────────────────────────────
  if (loading) {
    return (
      <div
        className={cn(
          "flex items-center justify-center overflow-hidden rounded-xl bg-muted/50",
          variant === "avatar" && "rounded-full",
          className
        )}
        style={variant === "avatar" ? { aspectRatio: "1 / 1" } : undefined}
      >
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // ── Error state ──────────────────────────────────────────────────────
  if (error || !media) {
    return (
      <div
        className={cn(
          "flex flex-col items-center justify-center gap-2 overflow-hidden rounded-xl border bg-muted/30 p-4 text-center",
          variant === "avatar" && "rounded-full",
          className
        )}
      >
        <AlertCircle className="h-5 w-5 text-muted-foreground" />
        <p className="text-xs text-muted-foreground">
          {error ?? "No media available"}
        </p>
      </div>
    );
  }

  // ── Avatar variant: only accept images ──────────────────────────────
  // Avatars must be a direct image. If the resolver returned anything
  // else (embed, video, preview, unknown), we render the fallback —
  // the caller (EditProfileScreen) shows an inline message instead.
  if (variant === "avatar") {
    if (media.type === "image" && media.mediaUrl) {
      return (
        <AvatarImage
          src={media.mediaUrl}
          alt={alt ?? media.title ?? "Profile picture"}
          className={cn("rounded-full", className)}
        />
      );
    }
    // Avatar non-image — return a fallback so the parent can decide to
    // show initials / hide entirely.
    return (
      <div
        className={cn(
          "flex items-center justify-center overflow-hidden rounded-full bg-muted/40",
          className
        )}
        style={{ aspectRatio: "1 / 1" }}
      >
        <AlertCircle className="h-5 w-5 text-muted-foreground" />
      </div>
    );
  }

  // ── Render by media type ────────────────────────────────────────────
  switch (media.type) {
    case "image":
      if (!media.mediaUrl) {
        return <Fallback media={media} variant={variant} className={className} titleHint={titleHint} />;
      }
      return (
        <ResponsiveImage
          src={media.mediaUrl}
          alt={alt ?? media.title ?? titleHint ?? "Image"}
          variant={variant}
          className={className}
          fallback={(onError) => (
            <FallbackOnError
              media={media}
              variant={variant}
              className={className}
              titleHint={titleHint}
              onError={onError}
            />
          )}
        />
      );

    case "video":
      if (!media.mediaUrl) {
        return <Fallback media={media} variant={variant} className={className} titleHint={titleHint} />;
      }
      return (
        <ResponsiveVideo
          src={media.mediaUrl}
          poster={media.thumbnailUrl ?? undefined}
          variant={variant}
          className={className}
          fallback={(onError) => (
            <FallbackOnError
              media={media}
              variant={variant}
              className={className}
              titleHint={titleHint}
              onError={onError}
            />
          )}
        />
      );

    case "embed":
      if (!media.embedUrl && !media.mediaUrl) {
        return <Fallback media={media} variant={variant} className={className} titleHint={titleHint} />;
      }
      return (
        <ResponsiveEmbed
          src={media.embedUrl ?? media.mediaUrl}
          variant={variant}
          title={media.title ?? titleHint ?? "Embedded content"}
          className={className}
          fallback={(onError) => (
            <FallbackOnError
              media={media}
              variant={variant}
              className={className}
              titleHint={titleHint}
              onError={onError}
            />
          )}
        />
      );

    case "preview":
    case "unknown":
    default:
      return <Fallback media={media} variant={variant} className={className} titleHint={titleHint} />;
  }
}

// ── Sub-components ───────────────────────────────────────────────────────

/**
 * Responsive <img> with onLoad/onError. Calls `fallback` when the image
 * fails to load (the fallback re-renders as MediaUnavailableFallback).
 */
function ResponsiveImage({
  src,
  alt,
  variant,
  className,
  fallback,
}: {
  src: string;
  alt: string;
  variant: MediaRendererVariant;
  className?: string;
  fallback: (onError: () => void) => React.ReactNode;
}) {
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [naturalZero, setNaturalZero] = useState(false);

  // Reset when src changes.
  useEffect(() => {
    setFailed(false);
    setLoaded(false);
    setNaturalZero(false);
  }, [src]);

  if (failed || naturalZero) {
    // Render the fallback card with the resolver's media info — but pass
    // setFailed as `onError` so the fallback card can be re-tried if the
    // user clicks (we don't currently support retry, but the API is there).
    return <>{fallback(() => setFailed(false))}</>;
  }

  const variantClass = variant === "card"
    ? "h-24 w-32 md:h-28 md:w-40"
    : "w-full max-h-[400px]";

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl bg-muted/30",
        variantClass,
        className
      )}
    >
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center">
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        </div>
      )}
      <img
        src={src}
        alt={alt}
        className={cn(
          "h-full w-full object-cover transition-opacity duration-200",
          loaded ? "opacity-100" : "opacity-0",
          variant === "card" && "object-cover"
        )}
        loading={variant === "full" ? "eager" : "lazy"}
        draggable={false}
        onLoad={(e) => {
          const img = e.currentTarget;
          if (img.naturalWidth > 0 && img.naturalHeight > 0) {
            setLoaded(true);
          } else {
            // 0×0 natural size = response wasn't a real image (HTML page, 1×1 pixel, etc.).
            setNaturalZero(true);
          }
        }}
        onError={() => setFailed(true)}
      />
    </div>
  );
}

/**
 * Responsive <video controls preload="metadata">. The video maintains its
 * native aspect ratio (via aspect-video CSS) — no distortion, no cropping.
 */
function ResponsiveVideo({
  src,
  poster,
  variant,
  className,
  fallback,
}: {
  src: string;
  poster?: string;
  variant: MediaRendererVariant;
  className?: string;
  fallback: (onError: () => void) => React.ReactNode;
}) {
  const [failed, setFailed] = useState(false);

  // Reset when src changes.
  useEffect(() => {
    setFailed(false);
  }, [src]);

  if (failed) {
    return <>{fallback(() => setFailed(false))}</>;
  }

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl bg-black",
        "aspect-video w-full",
        className
      )}
    >
      <video
        src={src}
        poster={poster}
        controls
        playsInline
        preload="metadata"
        className="h-full w-full"
        onError={() => setFailed(true)}
      />
    </div>
  );
}

/**
 * Responsive <iframe> for platform embeds. Uses the smallest viable
 * sandbox without breaking YouTube/Vimeo/TikTok/etc.
 *
 * Sandbox policy:
 *   - allow-scripts          → required for the embed to run
 *   - allow-same-origin       → required for the embed to access its own cookies
 *   - allow-presentation      → required for fullscreen
 *   - allow-popups            → some embeds open new windows (rare)
 *   - allow-forms             → some embeds have forms (rare)
 *   - NOT allow-top-navigation → embed can't redirect the parent page
 */
function ResponsiveEmbed({
  src,
  variant,
  title,
  className,
  fallback,
}: {
  src: string;
  variant: MediaRendererVariant;
  title: string;
  className?: string;
  fallback: (onError: () => void) => React.ReactNode;
}) {
  // iframes don't fire onError reliably across browsers for CSP-blocked
  // embeds (e.g. when a platform returns X-Frame-Options: DENY). We use
  // a load timeout — if the iframe doesn't fire onLoad within 10 seconds,
  // we show the fallback card. This is the safest way to detect blocked
  // embeds without violating the platform's restrictions.
  //
  // FIX: previously 5 seconds — too short for mobile networks (3G, poor
  // signal). YouTube embeds can take 5-10s to load on mobile. The 5s
  // timeout caused the iframe to be marked "blocked" prematurely → the
  // user saw "Open original" instead of the YouTube player. 10s is
  // a safer threshold that still catches genuinely blocked embeds.
  const [status, setStatus] = useState<"loading" | "loaded" | "blocked">("loading");
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setStatus("loading");
    // 10-second timeout — if the iframe doesn't signal it loaded, we
    // assume it's blocked (X-Frame-Options, platform restriction, etc.).
    timeoutRef.current = setTimeout(() => {
      setStatus((prev) => (prev === "loading" ? "blocked" : prev));
    }, 10000);
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [src]);

  if (status === "blocked") {
    return <>{fallback(() => setStatus("loading"))}</>;
  }

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl bg-black",
        "aspect-video w-full",
        className
      )}
    >
      {status === "loading" && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/40">
          <Loader2 className="h-5 w-5 animate-spin text-white/80" />
        </div>
      )}
      <iframe
        src={src}
        title={title}
        className="h-full w-full border-0"
        loading={variant === "full" ? "eager" : "lazy"}
        allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; autoplay; fullscreen"
        allowFullScreen
        sandbox="allow-scripts allow-same-origin allow-presentation allow-popups allow-forms"
        onLoad={() => {
          if (timeoutRef.current) clearTimeout(timeoutRef.current);
          setStatus("loaded");
        }}
      />
    </div>
  );
}

/**
 * Avatar image — circular, lazy-loaded, with onLoad/onError.
 * Used by the avatar variant of MediaRenderer.
 */
function AvatarImage({
  src,
  alt,
  className,
}: {
  src: string;
  alt: string;
  className?: string;
}) {
  const [status, setStatus] = useState<"loading" | "loaded" | "error">("loading");

  useEffect(() => {
    setStatus("loading");
  }, [src]);

  if (status === "error") {
    return (
      <div
        className={cn(
          "flex items-center justify-center overflow-hidden bg-muted/40",
          className
        )}
        style={{ aspectRatio: "1 / 1" }}
      >
        <AlertCircle className="h-5 w-5 text-muted-foreground" />
      </div>
    );
  }

  return (
    <div
      className={cn("relative overflow-hidden", className)}
      style={{ aspectRatio: "1 / 1" }}
    >
      {status === "loading" && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted/40">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}
      <img
        src={src}
        alt={alt}
        className={cn(
          "h-full w-full object-cover transition-opacity duration-200",
          status === "loaded" ? "opacity-100" : "opacity-0"
        )}
        loading="lazy"
        draggable={false}
        onLoad={(e) => {
          const img = e.currentTarget;
          if (img.naturalWidth > 0 && img.naturalHeight > 0) {
            setStatus("loaded");
          } else {
            setStatus("error");
          }
        }}
        onError={() => setStatus("error")}
      />
    </div>
  );
}

// ── Fallback wrappers ───────────────────────────────────────────────────

/**
 * Fallback card shown when the media cannot be rendered. Uses the
 * resolver's metadata (provider, title, thumbnail) to show a useful
 * "Open original" card.
 */
function Fallback({
  media,
  variant,
  className,
  titleHint,
}: {
  media: ResolvedMedia;
  variant: MediaRendererVariant;
  className?: string;
  titleHint?: string;
}) {
  return (
    <MediaUnavailableFallback
      media={{ ...media, title: media.title ?? titleHint ?? null }}
      compact={variant === "card"}
      className={className}
    />
  );
}

/**
 * Fallback card shown when an <img>/<video>/<iframe> fires onError.
 * Reuses the same MediaUnavailableFallback but logs the failure.
 */
function FallbackOnError({
  media,
  variant,
  className,
  titleHint,
  onError,
}: {
  media: ResolvedMedia;
  variant: MediaRendererVariant;
  className?: string;
  titleHint?: string;
  onError?: () => void;
}) {
  // We intentionally don't call onError here — it's only for retry
  // semantics that aren't currently exposed in the UI.
  void onError;
  return (
    <Fallback
      media={media}
      variant={variant}
      className={className}
      titleHint={titleHint}
    />
  );
}
