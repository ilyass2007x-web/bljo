"use client";

import { useState } from "react";
import { ExternalLink, AlertCircle, ImageOff, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ResolvedMedia } from "@/lib/media/types";

interface MediaUnavailableFallbackProps {
  media: ResolvedMedia;
  className?: string;
  /** When true, the card is compact (used inside ArticleCard thumb slot). */
  compact?: boolean;
}

/**
 * MediaUnavailableFallback — the universal "we couldn't render this media"
 * card. Shows:
 *   - The detected provider name (YouTube, Pinterest, etc.)
 *   - A thumbnail if we have one (og:image, YouTube hqdefault)
 *   - A title if we have one
 *   - An "Open original" link
 *
 * This REPLACES the old "Unable to load this image. Try a different direct
 * image URL (.jpg, .png, .webp)." message.
 *
 * The card NEVER breaks the page — it has fixed min-height + max-height,
 * clips overflow, and the "Open original" link opens in a new tab with
 * `rel="noopener noreferrer"` (prevents tab-nabbing).
 */
export function MediaUnavailableFallback({
  media,
  className,
  compact = false,
}: MediaUnavailableFallbackProps) {
  const providerLabel = formatProvider(media.provider);

  if (compact) {
    return (
      <a
        href={media.originalUrl}
        target="_blank"
        rel="noopener noreferrer"
        className={cn(
          "flex h-full w-full flex-col items-center justify-center gap-1 bg-muted/40 p-2 text-center",
          className
        )}
        title={media.title ?? `Open on ${providerLabel}`}
      >
        <ImageOff className="h-5 w-5 text-muted-foreground" />
        <span className="text-[10px] text-muted-foreground line-clamp-1">
          {providerLabel}
        </span>
      </a>
    );
  }

  return (
    <div
      className={cn(
        "overflow-hidden rounded-xl border bg-muted/30",
        className
      )}
    >
      {media.thumbnailUrl && (
        <div className="relative aspect-video w-full overflow-hidden bg-muted">
          <SafeImage
            src={media.thumbnailUrl}
            alt={media.title ?? providerLabel}
            className="h-full w-full object-cover"
          />
        </div>
      )}
      <div className="flex flex-col gap-2 p-3">
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" />
          <span>{providerLabel}</span>
        </div>
        {media.title && (
          <p className="line-clamp-2 text-sm font-medium" dir="auto">
            {media.title}
          </p>
        )}
        {media.description && !media.title && (
          <p className="line-clamp-2 text-xs text-muted-foreground" dir="auto">
            {media.description}
          </p>
        )}
        <a
          href={media.originalUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
        >
          <ExternalLink className="h-3 w-3" />
          Open original
        </a>
      </div>
    </div>
  );
}

/**
 * Image component with safe onError fallback to a placeholder.
 * Used by MediaUnavailableFallback when there's a thumbnail.
 */
function SafeImage({
  src,
  alt,
  className,
}: {
  src: string;
  alt: string;
  className?: string;
}) {
  const [status, setStatus] = useState<"loading" | "loaded" | "error">("loading");
  return (
    <>
      {status === "loading" && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted/50">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      )}
      {status === "error" ? (
        <div className="absolute inset-0 flex items-center justify-center bg-muted">
          <ImageOff className="h-6 w-6 text-muted-foreground" />
        </div>
      ) : (
        <img
          src={src}
          alt={alt}
          className={cn(
            className,
            status === "loaded" ? "opacity-100" : "opacity-0"
          )}
          loading="lazy"
          draggable={false}
          onLoad={(e) => {
            const img = e.currentTarget;
            if (img.naturalWidth > 0 && img.naturalHeight > 0) {
              setStatus("loaded");
            } else {
              setStatus("error");
            }
          }}
          onError={() => setStatus("error")}
        />
      )}
    </>
  );
}

function formatProvider(provider: string): string {
  switch (provider) {
    case "youtube": return "YouTube";
    case "vimeo": return "Vimeo";
    case "tiktok": return "TikTok";
    case "instagram": return "Instagram";
    case "facebook": return "Facebook";
    case "x": return "X (Twitter)";
    case "reddit": return "Reddit";
    case "pinterest": return "Pinterest";
    case "google": return "Google";
    case "webpage": return "Web page";
    case "direct": return "Media";
    case "unknown":
    default:
      return "External content";
  }
}
