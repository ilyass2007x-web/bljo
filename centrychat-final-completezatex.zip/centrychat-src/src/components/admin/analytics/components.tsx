"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowUp, ArrowDown, Minus, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatNumber } from "@/lib/client/format";
import type { TrafficMetric } from "./types";

// ── MetricCard ──────────────────────────────────────────────────────────

interface MetricCardProps {
  label: string;
  value: number;
  metric?: TrafficMetric | null;
  icon?: React.ReactNode;
  format?: "number" | "decimal";
}

/**
 * MetricCard — a single dashboard card showing:
 *   - Label (e.g. "Total Visitors")
 *   - Current value (large)
 *   - Growth % vs previous period (with up/down arrow + color)
 *   - "vs previous period" subtitle
 *
 * When metric is null (no previous data), shows "—" for growth.
 * When growth is 0, shows a neutral dash.
 */
export function MetricCard({ label, value, metric, icon, format = "number" }: MetricCardProps) {
  const growth = metric?.growth ?? null;
  const previous = metric?.previous ?? 0;
  const displayValue = format === "decimal" ? value.toFixed(2) : formatNumber(value);
  const displayPrevious = format === "decimal" ? previous.toFixed(2) : formatNumber(previous);

  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-muted-foreground">{label}</p>
          {icon && <span className="text-muted-foreground">{icon}</span>}
        </div>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="text-2xl font-bold tracking-tight">{displayValue}</span>
          {growth !== null && (
            <span
              className={cn(
                "flex items-center gap-0.5 text-xs font-medium",
                growth > 0 && "text-green-600 dark:text-green-400",
                growth < 0 && "text-red-600 dark:text-red-400",
                growth === 0 && "text-muted-foreground"
              )}
            >
              {growth > 0 && <ArrowUp className="h-3 w-3" />}
              {growth < 0 && <ArrowDown className="h-3 w-3" />}
              {growth === 0 && <Minus className="h-3 w-3" />}
              {Math.abs(growth).toFixed(1)}%
            </span>
          )}
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          vs {displayPrevious} previous period
        </p>
      </CardContent>
    </Card>
  );
}

// ── EmptyState ──────────────────────────────────────────────────────────

interface EmptyStateProps {
  title?: string;
  description?: string;
}

/**
 * EmptyState — shown when there's no analytics data yet (spec §29).
 */
export function EmptyState({
  title = "No traffic data yet",
  description = "Traffic data will appear once visitors interact with the site.",
}: EmptyStateProps) {
  return (
    <Card>
      <CardContent className="flex flex-col items-center justify-center py-16 text-center">
        <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
          <span className="text-2xl">📊</span>
        </div>
        <h3 className="text-lg font-semibold">{title}</h3>
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
}

// ── LoadingState ────────────────────────────────────────────────────────

export function LoadingState({ label = "Loading..." }: { label?: string }) {
  return (
    <div className="flex items-center justify-center py-16 text-muted-foreground">
      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
      {label}
    </div>
  );
}

// ── ErrorState ──────────────────────────────────────────────────────────

export function ErrorState({ message }: { message: string }) {
  return (
    <Card className="border-red-500/30">
      <CardContent className="py-8 text-center">
        <p className="text-sm text-red-600 dark:text-red-400">{message}</p>
      </CardContent>
    </Card>
  );
}
