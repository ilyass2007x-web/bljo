"use client";

import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend,
  LineChart, Line, XAxis, YAxis, CartesianGrid, BarChart, Bar,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig,
} from "@/components/ui/chart";
// IMPORTANT: import pure helpers from `./admin-helpers-shared`, NOT from
// `@/lib/analytics/admin-helpers` (which imports `db` + PrismaClient at the
// top level). Importing from `@/lib/analytics/admin-helpers` here would pull
// PrismaClient into the browser bundle, throwing the
// "PrismaClient is unable to run in this browser environment" error
// and triggering the global-error.tsx boundary.
import { getSourceColor, getSourceLabel } from "@/lib/analytics/classify-source";
import { formatBucketLabel } from "@/lib/analytics/admin-helpers-shared";
import type { SourceEntry, TimeBucket } from "./types";

// ── SourcesDonutChart ───────────────────────────────────────────────────

interface SourcesDonutChartProps {
  sources: SourceEntry[];
}

/**
 * Donut chart showing the traffic sources breakdown.
 * Each slice is colored via getSourceColor(). The legend shows the source
 * label + percentage.
 */
export function SourcesDonutChart({ sources }: SourcesDonutChartProps) {
  if (sources.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Traffic Sources</CardTitle>
          <CardDescription>Where your visitors come from</CardDescription>
        </CardHeader>
        <CardContent className="flex h-[300px] items-center justify-center text-sm text-muted-foreground">
          No source data for this period.
        </CardContent>
      </Card>
    );
  }

  // Build chart data + config (colors).
  const data = sources.slice(0, 10).map((s) => ({
    name: getSourceLabel(s.source),
    value: s.visitors,
    source: s.source,
    medium: s.medium,
    percentage: s.percentage,
    pageViews: s.pageViews,
  }));
  const chartConfig: ChartConfig = {};
  for (const s of sources.slice(0, 10)) {
    chartConfig[s.source] = {
      label: getSourceLabel(s.source),
      color: getSourceColor(s.source, s.medium as never),
    };
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Traffic Sources</CardTitle>
        <CardDescription>Where your visitors come from</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="mx-auto aspect-square max-h-[300px]">
          <PieChart>
            <ChartTooltip
              content={
                <ChartTooltipContent
                  formatter={(value, name, item) => {
                    const entry = item.payload as { source: string; medium: string; percentage: number; pageViews: number };
                    return (
                      <div className="space-y-1">
                        <p className="font-medium">{name}</p>
                        <p className="text-xs text-muted-foreground">
                          {value} visitors ({entry.percentage}%)
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {entry.pageViews} page views
                        </p>
                      </div>
                    );
                  }}
                />
              }
            />
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              innerRadius={60}
              outerRadius={100}
              paddingAngle={2}
            >
              {data.map((entry) => (
                <Cell
                  key={entry.source}
                  fill={getSourceColor(entry.source, entry.medium as never)}
                />
              ))}
            </Pie>
            <Legend
              verticalAlign="bottom"
              height={36}
              formatter={(value) => <span className="text-xs">{value}</span>}
            />
          </PieChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}

// ── TrafficOverTimeChart ────────────────────────────────────────────────

interface TrafficOverTimeChartProps {
  data: TimeBucket[];
  bucket: "hour" | "day" | "month";
}

/**
 * Area/Line chart showing visitors + page views over time.
 * The x-axis labels adapt to the bucket size (hour/day/month).
 */
export function TrafficOverTimeChart({ data, bucket }: TrafficOverTimeChartProps) {
  if (data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Traffic Over Time</CardTitle>
          <CardDescription>Visitors and page views per {bucket}</CardDescription>
        </CardHeader>
        <CardContent className="flex h-[300px] items-center justify-center text-sm text-muted-foreground">
          No time-series data for this period.
        </CardContent>
      </Card>
    );
  }

  const chartData = data.map((d) => ({
    bucket: formatBucketLabel(d.bucket, bucket),
    visitors: d.visitors,
    pageViews: d.pageViews,
    articleViews: d.articleViews,
  }));

  const chartConfig: ChartConfig = {
    visitors: { label: "Visitors", color: "hsl(var(--chart-1))" },
    pageViews: { label: "Page Views", color: "hsl(var(--chart-2))" },
    articleViews: { label: "Article Views", color: "hsl(var(--chart-3))" },
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Traffic Over Time</CardTitle>
        <CardDescription>Visitors and page views per {bucket}</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="aspect-[16/7] max-h-[320px] w-full">
          <LineChart data={chartData} margin={{ left: 4, right: 12, top: 8, bottom: 4 }}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis
              dataKey="bucket"
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 11 }}
              interval="preserveStartEnd"
              minTickGap={20}
            />
            <YAxis
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 11 }}
              width={36}
            />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend />
            <Line
              type="monotone"
              dataKey="visitors"
              stroke="var(--color-visitors)"
              strokeWidth={2}
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="pageViews"
              stroke="var(--color-pageViews)"
              strokeWidth={2}
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="articleViews"
              stroke="var(--color-articleViews)"
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}

// ── SimpleBarChart (for devices/browsers/OS) ────────────────────────────

interface SimpleBarChartProps {
  title: string;
  description?: string;
  data: Array<{ name: string; visitors: number; percentage: number }>;
  color?: string;
}

export function SimpleBarChart({ title, description, data, color = "hsl(var(--chart-1))" }: SimpleBarChartProps) {
  if (data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">{title}</CardTitle>
          {description && <CardDescription>{description}</CardDescription>}
        </CardHeader>
        <CardContent className="flex h-[200px] items-center justify-center text-sm text-muted-foreground">
          No data for this period.
        </CardContent>
      </Card>
    );
  }

  const chartConfig: ChartConfig = {
    visitors: { label: "Visitors", color },
  };

  const chartData = data.map((d) => ({
    name: d.name,
    visitors: d.visitors,
    percentage: d.percentage,
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="aspect-[16/9] max-h-[220px] w-full">
          <BarChart data={chartData} margin={{ left: 4, right: 12, top: 8, bottom: 4 }}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis
              dataKey="name"
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 11 }}
            />
            <YAxis
              tickLine={false}
              axisLine={false}
              tick={{ fontSize: 11 }}
              width={36}
            />
            <ChartTooltip
              content={
                <ChartTooltipContent
                  formatter={(value, _name, item) => {
                    const entry = item.payload as { percentage: number };
                    return (
                      <div>
                        <p className="font-medium">{value} visitors</p>
                        <p className="text-xs text-muted-foreground">{entry.percentage}%</p>
                      </div>
                    );
                  }}
                />
              }
            />
            <Bar dataKey="visitors" fill={color} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
