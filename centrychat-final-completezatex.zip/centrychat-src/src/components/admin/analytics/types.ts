/**
 * Shared types for the Traffic Analytics admin UI.
 *
 * These mirror the API response shapes so the client gets full typing.
 */

export interface TrafficMetric {
  current: number;
  previous: number;
  growth: number | null; // percentage, null when previous = 0
}

export interface TrafficOverview {
  hasData: boolean;
  range: string;
  metrics: {
    totalVisitors: TrafficMetric;
    totalPageViews: TrafficMetric;
    articleViews: TrafficMetric;
    newVisitors: TrafficMetric;
    returningVisitors: TrafficMetric;
    avgEngagement: TrafficMetric;
    trafficGrowth: number | null;
  } | null;
  error?: string;
}

export interface SourceEntry {
  source: string;
  medium: string;
  visitors: number;
  pageViews: number;
  percentage: number;
}

export interface TimeBucket {
  bucket: string;
  visitors: number;
  pageViews: number;
  articleViews: number;
}

export interface SourcesData {
  sources: SourceEntry[];
  overTime: TimeBucket[];
  bucket: "hour" | "day" | "month";
  range: string;
  error?: string;
}

export interface ArticleTrafficRow {
  id: string;
  title: string;
  status: string;
  publishedAt: string | null;
  author: { fullName: string; username: string } | null;
  views: number;
  uniqueVisitors: number;
  topSource: string;
  growth: number | null;
  lastVisit: string | null;
}

export interface ArticlesData {
  articles: ArticleTrafficRow[];
  range: string;
  error?: string;
}

export interface ArticleTrafficDetails {
  overview: {
    views: number;
    uniqueVisitors: number;
    returningVisitors: number;
    avgEngagement: number;
  };
  // Canonical ArticleView totals (PHASE 12). These match the public view
  // count displayed on the article card (one row per unique viewer).
  canonical?: {
    totalViews: number;
    uniqueVisitors: number;
    viewsToday: number;
    viewsThisWeek: number;
    viewsThisMonth: number;
  };
  // Per-source breakdown from the canonical ArticleView table (first-touch
  // attribution). Available when the ArticleView.source column is populated.
  canonicalSources?: SourceEntry[];
  sources: SourceEntry[];
  overTime: Array<{ bucket: string; views: number; visitors: number }>;
  topReferrers: Array<{ domain: string; visits: number; percentage: number }>;
  countries: Array<{ country: string; visitors: number; percentage: number }>;
  devices: Array<{ device: string; visitors: number; percentage: number }>;
  bucket: "hour" | "day" | "month";
  range: string;
  hasCountryData: boolean;
  error?: string;
}

export interface ReferrerEntry {
  domain: string;
  visits: number;
  percentage: number;
}

export interface ReferrersData {
  referrers: ReferrerEntry[];
  range: string;
  error?: string;
}

export interface RealtimeData {
  liveVisitors: number;
  currentlyReading: Array<{ articleId: string; title: string; readers: number }>;
  minutes: number;
  fetchedAt: string;
  error?: string;
}

export interface DevicesData {
  devices: Array<{ device: string; visitors: number; percentage: number }>;
  browsers: Array<{ browser: string; visitors: number; percentage: number }>;
  operatingSystems: Array<{ os: string; visitors: number; percentage: number }>;
  range: string;
  error?: string;
}

// ── Article Overview (PHASE 11 — canonical ArticleView totals) ──────────

export interface ArticleOverviewData {
  totalViews: number;
  uniqueVisitors: number;
  viewsToday: number;
  viewsYesterday: number;
  viewsLast7Days: number;
  viewsLast30Days: number;
  error?: string;
}

// ── Recent Activity (PHASE 13 — recent article-view feed) ───────────────

export interface RecentActivityEntry {
  articleId: string;
  articleTitle: string;
  authorFullName: string | null;
  source: string;
  referralDomain: string | null;
  viewedAt: string; // ISO timestamp
  device: string | null; // "mobile" | "desktop" | "tablet" | null
}

export interface RecentActivityData {
  activity: RecentActivityEntry[];
  fetchedAt: string;
  error?: string;
}

// ── Sort options (PHASE 16) ─────────────────────────────────────────────

export type ArticleSortKey = "views" | "uniqueVisitors" | "growth" | "recent";

export const SORT_OPTIONS: Array<{ value: ArticleSortKey; label: string }> = [
  { value: "views", label: "Views" },
  { value: "uniqueVisitors", label: "Unique Visitors" },
  { value: "growth", label: "Growth" },
  { value: "recent", label: "Recent Traffic" },
];

export type AnalyticsRange =
  | "today"
  | "yesterday"
  | "7d"
  | "30d"
  | "90d"
  | "1y"
  | "custom";

export const RANGE_OPTIONS: Array<{ value: AnalyticsRange; label: string }> = [
  { value: "today", label: "Today" },
  { value: "yesterday", label: "Yesterday" },
  { value: "7d", label: "Last 7 Days" },
  { value: "30d", label: "Last 30 Days" },
  { value: "90d", label: "Last 90 Days" },
  { value: "1y", label: "This Year" },
];
