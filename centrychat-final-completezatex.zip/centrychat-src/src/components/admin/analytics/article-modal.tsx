"use client";

import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import { formatNumber } from "@/lib/client/format";
import { getSourceColor, getSourceLabel } from "@/lib/analytics/classify-source";
import { countryName, countryToFlagEmoji } from "@/lib/analytics/geo";
import { MetricCard, LoadingState, ErrorState } from "./components";
import { SourcesDonutChart, TrafficOverTimeChart, SimpleBarChart } from "./charts";
import type { ArticleTrafficDetails } from "./types";

interface ArticleTrafficModalProps {
  articleId: string | null;
  articleTitle: string;
  range: string;
  onClose: () => void;
}

/**
 * ArticleTrafficModal — opens when the admin clicks "Analytics" on an article.
 *
 * Shows:
 *   - Overview cards (views, unique visitors, returning visitors, avg engagement)
 *   - Traffic sources donut chart
 *   - Traffic over time line chart
 *   - Top referrers list
 *   - Countries list (when Geo data available — otherwise a "not available" message)
 *   - Devices breakdown
 */
export function ArticleTrafficModal({ articleId, articleTitle, range, onClose }: ArticleTrafficModalProps) {
  const [data, setData] = useState<ArticleTrafficDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!articleId) return;
    setLoading(true);
    setError(null);
    setData(null);
    void api
      .get<{ article: unknown; analytics: ArticleTrafficDetails }>(
        `/api/v1/admin/analytics/articles/${articleId}?range=${range}`
      )
      .then((res) => {
        setData(res.analytics);
      })
      .catch((e) => {
        const msg = e instanceof ApiClientError ? e.message : "Failed to load article traffic";
        setError(msg);
        toast.error(msg);
      })
      .finally(() => setLoading(false));
  }, [articleId, range]);

  return (
    <Dialog open={!!articleId} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-h-[90vh] max-w-4xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg">Article Traffic Analytics</DialogTitle>
          <p className="text-sm text-muted-foreground line-clamp-2">{articleTitle}</p>
        </DialogHeader>

        {loading && <LoadingState label="Loading article analytics..." />}
        {error && !loading && <ErrorState message={error} />}
        {data && !loading && !error && (
          <div className="space-y-4">
            {/* Overview cards (existing — AnalyticsEvent-based) */}
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <MetricCard label="Total Views" value={data.overview.views} />
              <MetricCard label="Unique Visitors" value={data.overview.uniqueVisitors} />
              <MetricCard label="Returning Visitors" value={data.overview.returningVisitors} />
              <MetricCard label="Avg Engagement" value={data.overview.avgEngagement} format="decimal" />
            </div>

            {/* PHASE 12 — Canonical ArticleView totals (matches public view
                count on the article card). Distinct from the AnalyticsEvent-
                based overview above. */}
            {data.canonical && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Canonical View Counts (ArticleView — public view count)
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="grid grid-cols-2 gap-2 md:grid-cols-5">
                    <CanonicalTile label="All Time" value={data.canonical.totalViews} />
                    <CanonicalTile label="Unique" value={data.canonical.uniqueVisitors} />
                    <CanonicalTile label="Today" value={data.canonical.viewsToday} />
                    <CanonicalTile label="This Week" value={data.canonical.viewsThisWeek} />
                    <CanonicalTile label="This Month" value={data.canonical.viewsThisMonth} />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Sources + Over time */}
            <div className="grid gap-4 md:grid-cols-2">
              <SourcesDonutChart sources={data.canonicalSources && data.canonicalSources.length > 0 ? data.canonicalSources : data.sources} />
              <TrafficOverTimeChart
                data={data.overTime.map((o) => ({
                  bucket: o.bucket,
                  visitors: o.visitors,
                  pageViews: o.views,
                  articleViews: o.views,
                }))}
                bucket={data.bucket}
              />
            </div>

            {/* Top referrers + countries */}
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Top Referrers</CardTitle>
                  <CardDescription>Domains that sent traffic to this article</CardDescription>
                </CardHeader>
                <CardContent>
                  {data.topReferrers.length === 0 ? (
                    <p className="py-6 text-center text-sm text-muted-foreground">
                      No referrer data for this period.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {data.topReferrers.map((r) => (
                        <div key={r.domain} className="flex items-center justify-between text-sm">
                          <span className="font-mono text-xs">{r.domain}</span>
                          <div className="flex items-center gap-3">
                            <span className="text-muted-foreground">{formatNumber(r.visits)}</span>
                            <Badge variant="secondary" className="w-16 justify-center">
                              {r.percentage}%
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Countries</CardTitle>
                  <CardDescription>
                    {data.hasCountryData ? "Visitors by country" : "Country data not available"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {!data.hasCountryData ? (
                    <p className="py-6 text-center text-sm text-muted-foreground">
                      Country tracking requires a Geo provider (Cloudflare, Netlify Pro, etc.).
                      Configure one to see this data.
                    </p>
                  ) : data.countries.length === 0 ? (
                    <p className="py-6 text-center text-sm text-muted-foreground">
                      No country data for this period.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {data.countries.map((c) => (
                        <div key={c.country} className="flex items-center justify-between text-sm">
                          <span className="flex items-center gap-2">
                            <span>{countryToFlagEmoji(c.country) ?? "🌐"}</span>
                            <span>{countryName(c.country)}</span>
                          </span>
                          <div className="flex items-center gap-3">
                            <span className="text-muted-foreground">{formatNumber(c.visitors)}</span>
                            <Badge variant="secondary" className="w-16 justify-center">
                              {c.percentage}%
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Devices */}
            <SimpleBarChart
              title="Devices"
              description="Visitors by device type"
              data={data.devices.map((d) => ({
                name: d.device.charAt(0).toUpperCase() + d.device.slice(1),
                visitors: d.visitors,
                percentage: d.percentage,
              }))}
            />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ── CanonicalTile — small tile for the canonical ArticleView totals ─────
function CanonicalTile({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-md border bg-muted/30 p-2 text-center">
      <p className="text-[10px] font-medium text-muted-foreground">{label}</p>
      <p className="mt-0.5 text-base font-bold tracking-tight">{formatNumber(value)}</p>
    </div>
  );
}
