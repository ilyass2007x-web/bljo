"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/shared/avatar";
import { formatNumber, formatRelativeTime } from "@/lib/client/format";
import {
  Eye, Users, Calendar, CalendarDays, CalendarRange, Clock,
  Smartphone, Monitor, Tablet, Loader2, Activity as ActivityIcon,
  ChevronDown, ArrowUpDown,
} from "lucide-react";
import { getSourceColor, getSourceLabel } from "@/lib/analytics/classify-source";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import type {
  ArticleOverviewData,
  RecentActivityData,
  ArticleSortKey,
} from "./types";
import { SORT_OPTIONS } from "./types";

// ── ArticleOverviewCard ──────────────────────────────────────────────────
// (PHASE 11 — canonical ArticleView totals, separate from the existing
// /traffic AnalyticsEvent-based MetricCards.)

interface ArticleOverviewCardProps {
  data: ArticleOverviewData | null;
  loading?: boolean;
}

export function ArticleOverviewCard({ data, loading }: ArticleOverviewCardProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Eye className="h-4 w-4" />
          Article Views — Overview
        </CardTitle>
        <CardDescription>Unique article viewers across all content (ArticleView)</CardDescription>
      </CardHeader>
      <CardContent>
        {loading && !data ? (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        ) : !data ? (
          <p className="py-6 text-center text-sm text-muted-foreground">
            Unable to load overview data.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
            <OverviewTile label="Total Views" value={data.totalViews} icon={<Eye className="h-3.5 w-3.5" />} />
            <OverviewTile label="Unique Visitors" value={data.uniqueVisitors} icon={<Users className="h-3.5 w-3.5" />} />
            <OverviewTile label="Views Today" value={data.viewsToday} icon={<Calendar className="h-3.5 w-3.5" />} />
            <OverviewTile label="Yesterday" value={data.viewsYesterday} icon={<Clock className="h-3.5 w-3.5" />} />
            <OverviewTile label="Last 7 Days" value={data.viewsLast7Days} icon={<CalendarDays className="h-3.5 w-3.5" />} />
            <OverviewTile label="Last 30 Days" value={data.viewsLast30Days} icon={<CalendarRange className="h-3.5 w-3.5" />} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function OverviewTile({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="rounded-lg border bg-muted/20 p-3">
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-medium text-muted-foreground">{label}</span>
        <span className="text-muted-foreground">{icon}</span>
      </div>
      <p className="mt-1 text-xl font-bold tracking-tight">{formatNumber(value)}</p>
    </div>
  );
}

// ── RecentActivityCard ──────────────────────────────────────────────────
// (PHASE 13 — recent article-view feed. No visitor IDs / IPs exposed.)

interface RecentActivityCardProps {
  data: RecentActivityData | null;
  loading?: boolean;
  onArticleClick?: (articleId: string, articleTitle: string) => void;
}

export function RecentActivityCard({ data, loading, onArticleClick }: RecentActivityCardProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <ActivityIcon className="h-4 w-4" />
          Recent Traffic
        </CardTitle>
        <CardDescription>Latest article views across the platform</CardDescription>
      </CardHeader>
      <CardContent>
        {loading && !data ? (
          <div className="space-y-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : !data || data.activity.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">
            No recent article views yet.
          </p>
        ) : (
          <div className="space-y-1.5">
            {data.activity.map((entry, idx) => (
              <RecentActivityRow
                key={`${entry.articleId}-${entry.viewedAt}-${idx}`}
                entry={entry}
                onClick={
                  onArticleClick
                    ? () => onArticleClick(entry.articleId, entry.articleTitle)
                    : undefined
                }
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function RecentActivityRow({
  entry,
  onClick,
}: {
  entry: RecentActivityData["activity"][number];
  onClick?: () => void;
}) {
  const deviceIcon = entry.device === "mobile" ? <Smartphone className="h-3 w-3" />
    : entry.device === "tablet" ? <Tablet className="h-3 w-3" />
    : entry.device === "desktop" ? <Monitor className="h-3 w-3" />
    : null;
  const color = getSourceColor(entry.source, "referral");
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick}
      className="flex w-full items-center gap-2 rounded-md border bg-background px-2.5 py-1.5 text-left text-xs transition-colors hover:bg-accent disabled:cursor-default disabled:hover:bg-background"
    >
      <div className="flex w-12 shrink-0 items-center justify-center">
        <span className="text-[11px] text-muted-foreground">
          {formatRelativeTime(entry.viewedAt)}
        </span>
      </div>
      <div className="flex min-w-0 flex-1 items-center gap-2">
        <Avatar
          // Use the source color as a faux avatar background (no real avatar
          // for an article view event — we just want a visual anchor).
          color={color}
          name={entry.articleTitle}
          size="sm"
          className="h-7 w-7 shrink-0"
        />
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-medium">{entry.articleTitle}</p>
          {entry.authorFullName && (
            <p className="truncate text-[10px] text-muted-foreground">
              by {entry.authorFullName}
            </p>
          )}
        </div>
      </div>
      <Badge
        variant="secondary"
        className="shrink-0 gap-1 text-[10px]"
        style={{
          backgroundColor: `${color}1f`,
          color,
        }}
      >
        {getSourceLabel(entry.source)}
      </Badge>
      <span className="flex w-12 shrink-0 items-center justify-end gap-1 text-[10px] text-muted-foreground">
        {deviceIcon}
        {entry.device ?? ""}
      </span>
    </button>
  );
}

// ── SortDropdown ─────────────────────────────────────────────────────────
// (PHASE 16 — sort the article traffic table by Views / Unique Visitors /
// Growth / Recent Traffic.)

interface SortDropdownProps {
  value: ArticleSortKey;
  onChange: (value: ArticleSortKey) => void;
}

export function SortDropdown({ value, onChange }: SortDropdownProps) {
  return (
    <div className="flex items-center gap-1.5">
      <ArrowUpDown className="h-3.5 w-3.5 text-muted-foreground" />
      <Select value={value} onValueChange={(v) => onChange(v as ArticleSortKey)}>
        <SelectTrigger className="h-7 w-[150px] text-xs">
          <SelectValue placeholder="Sort by" />
        </SelectTrigger>
        <SelectContent>
          {SORT_OPTIONS.map((opt) => (
            <SelectItem key={opt.value} value={opt.value} className="text-xs">
              {opt.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
