"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber } from "@/lib/client/format";
import { toast } from "sonner";
import {
  TrendingUp, TrendingDown, ArrowUp, ArrowDown, Minus,
  Heart, MessageCircle, Eye, Share2, Search, Hash, Users, FileText,
} from "lucide-react";
import { cn } from "@/lib/utils";

type Window = "1h" | "6h" | "12h" | "24h" | "3d" | "7d";

interface TrendingItem {
  type: string; position: number; id: string;
  content?: string; title?: string; excerpt?: string | null; coverImage?: string | null;
  author: { id: string; fullName: string; username: string; isVerified: boolean };
  createdAt?: string; publishedAt?: string | null;
  recentViews: number; recentLikes: number; recentComments: number; recentShares: number;
  totalLikes?: number; totalComments?: number; totalViews?: number; totalShares?: number;
  velocity: number; momentum: number | null; trendScore: number;
  why: string[];
}

interface TrendingData {
  window: string;
  trendingPosts: TrendingItem[] | null;
  trendingArticles: TrendingItem[] | null;
  trendingTopics: { tag: string; count: number; trendScore: number }[] | null;
  trendingSearches: { query: string; currentCount: number; previousCount: number; growth: number | null }[] | null;
  trendingCreators: { id: string; fullName: string; username: string; isVerified: boolean; items: number; totalVelocity: number; trendScore: number }[] | null;
}

export function AdminTrending() {
  const [data, setData] = useState<TrendingData | null>(null);
  const [loading, setLoading] = useState(true);
  const [windowVal, setWindowVal] = useState<Window>("24h");

  const fetch = useCallback(async (w: Window) => {
    setLoading(true);
    try {
      const res = await api.get<{ trending: TrendingData }>(`/api/v1/admin/trending?window=${w}`);
      setData(res.trending);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load trending data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void fetch(windowVal); }, [windowVal, fetch]);

  return (
    <div className="space-y-6">
      {/* Header + Window Selector */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Trending Center</h2>
          <p className="text-sm text-muted-foreground">Content gaining unusual attention. Velocity + momentum, not lifetime views.</p>
        </div>
        <div className="flex flex-wrap gap-1 rounded-lg border bg-muted/30 p-1">
          {(["1h", "6h", "12h", "24h", "3d", "7d"] as Window[]).map(w => (
            <button key={w} onClick={() => setWindowVal(w)}
              className={cn("rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                windowVal === w ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>
              {w === "1h" ? "1 Hour" : w === "6h" ? "6 Hours" : w === "12h" ? "12 Hours" : w === "24h" ? "24 Hours" : w === "3d" ? "3 Days" : "7 Days"}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[0,1,2,3,4].map(i => <Skeleton key={i} className="h-32 w-full rounded-lg" />)}
        </div>
      ) : !data ? (
        <Card><CardContent className="py-6 text-center text-sm text-destructive">Unable to load trending data.</CardContent></Card>
      ) : (
        <>
          {/* Trending Posts */}
          <Section title="Trending Posts" icon={FileText}>
            {data.trendingPosts && data.trendingPosts.length > 0 ? (
              <TrendingList items={data.trendingPosts} type="post" />
            ) : <EmptyState text="No trending posts in this window." />}
          </Section>

          {/* Trending Articles */}
          <Section title="Trending Articles" icon={FileText}>
            {data.trendingArticles && data.trendingArticles.length > 0 ? (
              <TrendingList items={data.trendingArticles} type="article" />
            ) : <EmptyState text="No trending articles in this window." />}
          </Section>

          <div className="grid gap-4 lg:grid-cols-3">
            {/* Trending Topics */}
            <Section title="Trending Topics" icon={Hash} small>
              {data.trendingTopics && data.trendingTopics.length > 0 ? (
                <div className="space-y-1">
                  {data.trendingTopics.map((t, i) => (
                    <div key={t.tag} className="flex items-center justify-between rounded border px-2 py-1 text-xs">
                      <span className="flex items-center gap-2 truncate">
                        <span className="flex h-4 w-4 items-center justify-center rounded-full bg-muted text-[8px] font-bold">{i+1}</span>
                        <span className="truncate font-medium">#{t.tag}</span>
                      </span>
                      <Badge variant="secondary" className="text-[10px]">{t.count}</Badge>
                    </div>
                  ))}
                </div>
              ) : <EmptyState text="No trending topics." />}
            </Section>

            {/* Trending Searches */}
            <Section title="Trending Searches" icon={Search} small>
              {data.trendingSearches && data.trendingSearches.length > 0 ? (
                <div className="space-y-1">
                  {data.trendingSearches.map((s, i) => (
                    <div key={s.query} className="flex items-center justify-between rounded border px-2 py-1 text-xs">
                      <span className="flex items-center gap-2 truncate">
                        <span className="flex h-4 w-4 items-center justify-center rounded-full bg-muted text-[8px] font-bold">{i+1}</span>
                        <span className="truncate" dir="auto">{s.query}</span>
                      </span>
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-muted-foreground">{s.currentCount}</span>
                        {s.growth != null && (
                          <span className={cn("text-[10px] font-medium", s.growth > 0 ? "text-green-600 dark:text-green-400" : s.growth < 0 ? "text-destructive" : "text-muted-foreground")}>
                            {s.growth > 0 ? "+" : ""}{s.growth}%
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : <EmptyState text="No trending searches." />}
            </Section>

            {/* Trending Creators */}
            <Section title="Trending Creators" icon={Users} small>
              {data.trendingCreators && data.trendingCreators.length > 0 ? (
                <div className="space-y-1">
                  {data.trendingCreators.map((c, i) => (
                    <div key={c.id} className="flex items-center gap-2 rounded border px-2 py-1 text-xs">
                      <span className="flex h-4 w-4 items-center justify-center rounded-full bg-muted text-[8px] font-bold">{i+1}</span>
                      <Avatar name={c.fullName} size="sm" className="h-5 w-5 text-[9px]" />
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-1 truncate">
                          <span className="truncate">{c.fullName}</span>
                          {c.isVerified && <VerifiedBadge size={8} />}
                        </p>
                        <p className="truncate text-[10px] text-muted-foreground">@{c.username}</p>
                      </div>
                      <Badge variant="secondary" className="text-[10px]">{c.items} items</Badge>
                    </div>
                  ))}
                </div>
              ) : <EmptyState text="No trending creators." />}
            </Section>
          </div>
        </>
      )}
    </div>
  );
}

function Section({ title, icon: Icon, children, small }: { title: string; icon: React.ComponentType<{ className?: string }>; children: React.ReactNode; small?: boolean }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <Icon className="h-4 w-4 text-muted-foreground" /> {title}
        </CardTitle>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

function TrendingList({ items, type }: { items: TrendingItem[]; type: "post" | "article" }) {
  return (
    <div className="space-y-2">
      {items.map(item => (
        <div key={item.id} className="rounded-lg border p-3">
          {/* Top row: position + preview */}
          <div className="flex items-start gap-2">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[10px] font-bold text-primary">{item.position}</span>
            {type === "article" && item.coverImage && (
              <img src={item.coverImage} alt="" className="h-10 w-10 shrink-0 rounded object-cover" loading="lazy" />
            )}
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium" dir="auto">{type === "article" ? item.title : item.content}</p>
              <p className="truncate text-xs text-muted-foreground">by {item.author.fullName} · @{item.author.username}</p>
            </div>
            <div className="flex shrink-0 flex-col items-end gap-0.5">
              <span className="text-sm font-bold text-primary">{item.trendScore}</span>
              <span className="text-[10px] text-muted-foreground">trend score</span>
            </div>
          </div>
          {/* Stats row */}
          <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-0.5"><Eye className="h-3 w-3" />{formatNumber(item.recentViews)}</span>
            <span className="flex items-center gap-0.5"><Heart className="h-3 w-3" />{formatNumber(item.recentLikes)}</span>
            <span className="flex items-center gap-0.5"><MessageCircle className="h-3 w-3" />{formatNumber(item.recentComments)}</span>
            <span className="flex items-center gap-0.5"><Share2 className="h-3 w-3" />{formatNumber(item.recentShares)}</span>
            <span className="flex items-center gap-0.5"><TrendingUp className="h-3 w-3" />{item.velocity}/hr</span>
            {item.momentum != null && (
              <span className={cn("flex items-center gap-0.5 font-medium",
                item.momentum > 0 ? "text-green-600 dark:text-green-400" : item.momentum < 0 ? "text-destructive" : "text-muted-foreground")}>
                {item.momentum > 0 ? <ArrowUp className="h-3 w-3" /> : item.momentum < 0 ? <ArrowDown className="h-3 w-3" /> : <Minus className="h-3 w-3" />}
                {item.momentum > 0 ? "+" : ""}{item.momentum}% momentum
              </span>
            )}
          </div>
          {/* WHY IS THIS TRENDING? (spec §24) */}
          <div className="mt-2 flex flex-wrap gap-1">
            {item.why.map((reason, i) => (
              <Badge key={i} variant="outline" className="text-[9px]">{reason}</Badge>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return <p className="py-6 text-center text-sm text-muted-foreground">{text}</p>;
}
