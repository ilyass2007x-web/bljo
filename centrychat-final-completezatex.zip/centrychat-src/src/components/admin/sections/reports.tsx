"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { api, ApiClientError } from "@/lib/client/api";
import { formatDateTime } from "@/lib/client/format";
import { toast } from "sonner";
import { ChevronLeft, ChevronRight, Flag } from "lucide-react";

interface Report {
  id: string;
  reason: string;
  description: string;
  status: string;
  resolutionNote: string | null;
  createdAt: string;
  resolvedAt: string | null;
  reporter: { id: string; fullName: string; email: string };
  target: { id: string; fullName: string; email: string } | null;
}

export function AdminReports() {
  const [reports, setReports] = useState<Report[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Report | null>(null);
  const [resolution, setResolution] = useState("");

  async function load() {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), pageSize: "20" });
      if (status) params.set("status", status);
      const data = await api.get<{ reports: Report[]; pagination: { total: number } }>(`/api/v1/admin/reports?${params}`);
      setReports(data.reports);
      setTotal(data.pagination.total);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load reports");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load();  }, [page, status]);

  async function update(id: string, newStatus: string) {
    try {
      await api.patch(`/api/v1/admin/reports/${id}`, { status: newStatus, resolutionNote: resolution });
      toast.success("Report updated");
      setSelected(null);
      setResolution("");
      void load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update report");
    }
  }

  const totalPages = Math.ceil(total / 20);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Reports</h2>
        <p className="text-sm text-muted-foreground">{total} total reports</p>
      </div>

      <Card className="p-4">
        <Select value={status || "all"} onValueChange={(v) => { setStatus(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Filter by status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="OPEN">Open</SelectItem>
            <SelectItem value="INVESTIGATING">Investigating</SelectItem>
            <SelectItem value="RESOLVED">Resolved</SelectItem>
            <SelectItem value="DISMISSED">Dismissed</SelectItem>
          </SelectContent>
        </Select>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b bg-muted/50">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Reason</th>
                <th className="px-4 py-3 text-left font-medium">Reporter</th>
                <th className="px-4 py-3 text-left font-medium">Target</th>
                <th className="px-4 py-3 text-left font-medium">Status</th>
                <th className="px-4 py-3 text-left font-medium">Created</th>
                <th className="px-4 py-3 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">Loading…</td></tr>
              ) : reports.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">No reports</td></tr>
              ) : (
                reports.map((r) => (
                  <tr key={r.id} className="border-b hover:bg-muted/30">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Flag className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{r.reason}</p>
                          <p className="truncate max-w-xs text-xs text-muted-foreground">{r.description}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs">{r.reporter.fullName}</td>
                    <td className="px-4 py-3 text-xs">{r.target?.fullName ?? "—"}</td>
                    <td className="px-4 py-3"><Badge variant={r.status === "OPEN" ? "destructive" : "secondary"}>{r.status}</Badge></td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{formatDateTime(r.createdAt)}</td>
                    <td className="px-4 py-3 text-right">
                      <Button size="sm" variant="ghost" onClick={() => { setSelected(r); setResolution(r.resolutionNote ?? ""); }}>Review</Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t p-3">
            <p className="text-xs text-muted-foreground">Page {page} of {totalPages}</p>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft className="h-4 w-4" /></Button>
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight className="h-4 w-4" /></Button>
            </div>
          </div>
        )}
      </Card>

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setSelected(null)}>
          <Card className="max-w-lg w-full p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-2 text-lg font-semibold">Report Review</h3>
            <div className="space-y-3 text-sm">
              <div><p className="text-muted-foreground">Reason</p><p className="font-medium">{selected.reason}</p></div>
              <div><p className="text-muted-foreground">Reporter</p><p>{selected.reporter.fullName} ({selected.reporter.email})</p></div>
              {selected.target && <div><p className="text-muted-foreground">Target</p><p>{selected.target.fullName} ({selected.target.email})</p></div>}
              <div><p className="text-muted-foreground">Description</p><p className="rounded border p-2">{selected.description}</p></div>
              <div><p className="text-muted-foreground">Resolution note</p><Textarea value={resolution} onChange={(e) => setResolution(e.target.value)} rows={3} /></div>
              <div className="flex flex-wrap gap-2 pt-2">
                <Button size="sm" variant="outline" onClick={() => update(selected.id, "INVESTIGATING")}>Mark Investigating</Button>
                <Button size="sm" variant="default" onClick={() => update(selected.id, "RESOLVED")}>Resolve</Button>
                <Button size="sm" variant="secondary" onClick={() => update(selected.id, "DISMISSED")}>Dismiss</Button>
                <Button size="sm" variant="ghost" onClick={() => setSelected(null)}>Close</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
