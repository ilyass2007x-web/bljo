"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { Loader2, Megaphone } from "lucide-react";

export function AdminNotifications() {
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [scope, setScope] = useState<"all" | "active">("all");
  const [sending, setSending] = useState(false);

  async function send() {
    if (!title.trim() || !message.trim()) {
      toast.error("Title and message are required");
      return;
    }
    setSending(true);
    try {
      const data = await api.post<{ recipients: number }>("/api/v1/admin/notifications/broadcast", { title, message, scope });
      toast.success(`Notification sent to ${data.recipients} users`);
      setTitle("");
      setMessage("");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to send notification");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Notifications</h2>
        <p className="text-sm text-muted-foreground">Broadcast system notifications to users.</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Megaphone className="h-4 w-4" /> Broadcast</CardTitle>
          <CardDescription>Send an in-app notification (and best-effort email) to users.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea id="message" value={message} onChange={(e) => setMessage(e.target.value)} maxLength={500} rows={3} />
          </div>
          <div className="space-y-2">
            <Label>Recipients</Label>
            <Select value={scope} onValueChange={(v) => setScope(v as "all" | "active")}>
              <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All users</SelectItem>
                <SelectItem value="active">Active users only</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={send} disabled={sending}>
            {sending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Send broadcast
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
