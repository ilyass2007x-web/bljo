"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Shield,
  ShieldBan,
  ShieldCheck,
  ShieldX,
  ShieldAlert,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Eye,
  CheckCircle,
  XCircle,
  Ban,
  Trash2,
  AlertTriangle,
  TrendingUp,
  Clock,
} from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber, formatRelativeTime, formatDateTime } from "@/lib/client/format";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// ── Types ──────────────────────────────────────────────────────────────────
// Mirrors the API response shape. The category + severity strings are
// defined in src/lib/moderation/types.ts — kept as string here to avoid
// importing server-only modules into the client bundle.

interface ModerationQueueItem {
  id: string;
  contentType: string;
  contentId: string | null;
  userId: string;
  userFullName: string;
  userUsername: string;
  status: string;
  action: string;
  severity: string;
  score: number;
  categories: string[];
  reasons: string[];
  contentPreview: string;
  createdAt: string;
  reviewedAt: string | null;
  reviewedBy: string | null;
  reviewedByName: string | null;
}

interface ModerationStats {
  totalBlocked: number;
  totalFlagged: number;
  totalReviewed: number;
  pendingReview: number;
  approvalRate: number;
  topCategories: { category: string; count: number }[];
  byContentType: { contentType: string; count: number }[];
  bySeverity: { severity: string; count: number }[];
  last7Days: { date: string; count: number }[];
}

// Tailwind badge color classes per severity + status.
const SEVERITY_BADGE: Record<string, string> = {
  LOW: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  MEDIUM: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  HIGH: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300",
  CRITICAL: "bg-red-200 text-red-800 dark:bg-red-900/60 dark:text-red-200",
};

const STATUS_BADGE: Record<string, string> = {
  PENDING: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  APPROVED: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  REJECTED: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  DISMISSED: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
};

const ACTION_LABEL: Record<string, string> = {
  ALLOW: "Allowed",
  WARN: "Warned",
  BLOCK: "Blocked",
  REVIEW: "Flagged",
};

// Human-readable labels for content types.
const CONTENT_TYPE_LABEL: Record<string, string> = {
  post: "Post",
  article: "Article",
  article_title: "Article Title",
  article_excerpt: "Article Excerpt",
  post_comment: "Post Comment",
  article_comment: "Article Comment",
  profile_bio: "Profile Bio",
  profile_full_name: "Profile Name",
};

const CONTENT_TYPE_OPTIONS = Object.entries(CONTENT_TYPE_LABEL);

const STATUS_OPTIONS: { value: string; label: string }[] = [
  { value: "all", label: "All statuses" },
  { value: "PENDING", label: "Pending Review" },
  { value: "APPROVED", label: "Approved" },
  { value: "REJECTED", label: "Rejected" },
  { value: "DISMISSED", label: "Dismissed" },
];

// ── Component ──────────────────────────────────────────────────────────────

export function AdminContentSafety() {
  const [stats, setStats] = useState<ModerationStats | null>(null);
  const [items, setItems] = useState<ModerationQueueItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [status, setStatus] = useState<string>("PENDING");
  const [contentType, setContentType] = useState<string>("all");
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<ModerationQueueItem | null>(null);
  const [acting, setActing] = useState(false);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: String(page),
        pageSize: String(pageSize),
      });
      if (status && status !== "all") params.set("status", status);
      if (contentType && contentType !== "all") params.set("contentType", contentType);
      const data = await api.get<{
        stats: ModerationStats;
        queue: { items: ModerationQueueItem[]; total: number };
      }>(`/api/v1/admin/moderation?${params}`);
      setStats(data.stats);
      setItems(data.queue.items);
      setTotal(data.queue.total);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load moderation data");
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, status, contentType]);

  useEffect(() => {
    void fetch();
  }, [fetch]);

  async function takeAction(
    eventId: string,
    newStatus: "APPROVED" | "REJECTED" | "DISMISSED",
    deleteContent: boolean
  ) {
    setActing(true);
    try {
      await api.patch(`/api/v1/admin/moderation/${eventId}`, {
        status: newStatus,
        deleteContent,
      });
      toast.success(`Event ${newStatus.toLowerCase()}`);
      setSelected(null);
      void fetch();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update moderation event");
    } finally {
      setActing(false);
    }
  }

  const totalPages = Math.ceil(total / pageSize);
  const maxBars = Math.max(1, ...stats?.last7Days.map((d) => d.count) ?? [1]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Content Safety</h2>
        <p className="text-sm text-muted-foreground">
          Centralized moderation engine — every post, article, comment, reply, and profile bio
          is analyzed server-side before being published.
        </p>
      </div>

      {/* ── Overview Cards ────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <OverviewCard
          icon={<ShieldBan className="h-5 w-5 text-red-500" />}
          label="Blocked"
          value={stats?.totalBlocked ?? 0}
          loading={loading}
        />
        <OverviewCard
          icon={<ShieldAlert className="h-5 w-5 text-amber-500" />}
          label="Pending Review"
          value={stats?.pendingReview ?? 0}
          loading={loading}
        />
        <OverviewCard
          icon={<ShieldX className="h-5 w-5 text-orange-500" />}
          label="High Severity"
          value={
            (stats?.bySeverity ?? []).find((s) => s.severity === "HIGH")?.count ??
            (stats?.bySeverity ?? []).find((s) => s.severity === "CRITICAL")?.count ??
            0
          }
          loading={loading}
        />
        <OverviewCard
          icon={<ShieldCheck className="h-5 w-5 text-emerald-500" />}
          label="Approval Rate"
          value={stats ? `${(stats.approvalRate * 100).toFixed(1)}%` : "—"}
          loading={loading}
        />
      </div>

      {/* ── Charts row ─────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {/* Violation trend (last 7 days) */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              Violations — Last 7 Days
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-32 w-full" />
            ) : (
              <div className="flex h-32 items-end justify-between gap-2">
                {stats?.last7Days.map((day) => {
                  const height = maxBars > 0 ? (day.count / maxBars) * 100 : 0;
                  return (
                    <div key={day.date} className="flex flex-1 flex-col items-center gap-1">
                      <div
                        className="w-full rounded-t bg-primary/70 transition-all"
                        style={{ height: `${Math.max(2, height)}%` }}
                        title={`${day.count} events`}
                      />
                      <span className="text-[10px] text-muted-foreground">
                        {day.date.slice(5)}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top categories */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              Top Violation Categories
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-32 w-full" />
            ) : (
              <div className="space-y-2">
                {(stats?.topCategories ?? []).length === 0 ? (
                  <p className="py-6 text-center text-sm text-muted-foreground">
                    No violations recorded yet.
                  </p>
                ) : (
                  (stats?.topCategories ?? []).map((c) => {
                    const max = stats?.topCategories[0]?.count ?? 1;
                    return (
                      <div key={c.category} className="flex items-center gap-2">
                        <span className="w-40 truncate text-xs text-muted-foreground">
                          {c.category.replace(/_/g, " ")}
                        </span>
                        <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                          <div
                            className="h-full rounded-full bg-primary/70"
                            style={{ width: `${(c.count / max) * 100}%` }}
                          />
                        </div>
                        <span className="w-10 text-right text-xs font-medium tabular-nums">
                          {formatNumber(c.count)}
                        </span>
                      </div>
                    );
                  })
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Filters ────────────────────────────────────────────────────── */}
      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <Select value={status} onValueChange={(v) => { setStatus(v); setPage(1); }}>
            <SelectTrigger className="w-44">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              {STATUS_OPTIONS.map((s) => (
                <SelectItem key={s.value} value={s.value}>
                  {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={contentType} onValueChange={(v) => { setContentType(v); setPage(1); }}>
            <SelectTrigger className="w-44">
              <SelectValue placeholder="Filter by content type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All content types</SelectItem>
              {CONTENT_TYPE_OPTIONS.map(([value, label]) => (
                <SelectItem key={value} value={value}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <span className="ml-auto text-xs text-muted-foreground">
            {formatNumber(total)} events
          </span>
        </div>
      </Card>

      {/* ── Moderation Queue ───────────────────────────────────────────── */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b bg-muted/50">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Content</th>
                <th className="px-4 py-3 text-left font-medium">Author</th>
                <th className="px-4 py-3 text-left font-medium">Type</th>
                <th className="px-4 py-3 text-left font-medium">Severity</th>
                <th className="px-4 py-3 text-left font-medium">Score</th>
                <th className="px-4 py-3 text-left font-medium">Status</th>
                <th className="px-4 py-3 text-left font-medium">Created</th>
                <th className="px-4 py-3 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-b">
                    <td colSpan={8} className="px-4 py-3">
                      <Skeleton className="h-6 w-full" />
                    </td>
                  </tr>
                ))
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-muted-foreground">
                    <Shield className="mx-auto mb-3 h-10 w-10 opacity-40" />
                    <p className="text-sm">No moderation events match these filters.</p>
                  </td>
                </tr>
              ) : (
                items.map((item) => (
                  <tr key={item.id} className="border-b hover:bg-muted/30">
                    <td className="max-w-xs px-4 py-3">
                      <p className="truncate text-xs text-muted-foreground">
                        {item.contentPreview || <em className="opacity-60">No preview</em>}
                      </p>
                      <p className="mt-1 truncate text-[10px] text-muted-foreground">
                        {item.categories.slice(0, 2).map((c) => c.replace(/_/g, " ")).join(", ")}
                        {item.categories.length > 2 && ` +${item.categories.length - 2}`}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Avatar
                          name={item.userFullName}
                          size="sm"
                          className="h-6 w-6 shrink-0 text-[10px]"
                        />
                        <div className="min-w-0">
                          <p className="truncate text-xs font-medium">{item.userFullName}</p>
                          <p className="truncate text-[10px] text-muted-foreground">
                            @{item.userUsername}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs">
                      {CONTENT_TYPE_LABEL[item.contentType] ?? item.contentType}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          "rounded px-2 py-0.5 text-[10px] font-medium",
                          SEVERITY_BADGE[item.severity] ?? SEVERITY_BADGE.LOW
                        )}
                      >
                        {item.severity}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs tabular-nums">{item.score}</td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          "rounded px-2 py-0.5 text-[10px] font-medium",
                          STATUS_BADGE[item.status] ?? STATUS_BADGE.PENDING
                        )}
                      >
                        {item.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">
                      {formatRelativeTime(item.createdAt)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setSelected(item)}
                      >
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t p-3">
            <p className="text-xs text-muted-foreground">
              Page {page} of {totalPages}
            </p>
            <div className="flex gap-1">
              <Button
                size="sm"
                variant="outline"
                disabled={page <= 1}
                onClick={() => setPage((p) => p - 1)}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* ── Detail / Action Modal ──────────────────────────────────────── */}
      {selected && (
        <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <ShieldAlert className="h-5 w-5 text-amber-500" />
                Moderation Event Review
              </DialogTitle>
              <DialogDescription>
                {CONTENT_TYPE_LABEL[selected.contentType] ?? selected.contentType} ·{" "}
                {ACTION_LABEL[selected.action] ?? selected.action} ·{" "}
                {formatDateTime(selected.createdAt)}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-3">
              {/* Content preview */}
              <div>
                <p className="mb-1 text-xs font-medium text-muted-foreground">Content Preview</p>
                <div className="max-h-32 overflow-y-auto rounded border bg-muted/30 p-3 text-sm">
                  {selected.contentPreview || (
                    <em className="text-muted-foreground">No preview available</em>
                  )}
                </div>
              </div>

              {/* Categories + severity */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="mb-1 text-xs font-medium text-muted-foreground">Categories</p>
                  <div className="flex flex-wrap gap-1">
                    {selected.categories.length === 0 ? (
                      <span className="text-xs text-muted-foreground">None</span>
                    ) : (
                      selected.categories.map((c) => (
                        <Badge key={c} variant="secondary" className="text-[10px]">
                          {c.replace(/_/g, " ")}
                        </Badge>
                      ))
                    )}
                  </div>
                </div>
                <div>
                  <p className="mb-1 text-xs font-medium text-muted-foreground">Severity</p>
                  <span
                    className={cn(
                      "rounded px-2 py-0.5 text-xs font-medium",
                      SEVERITY_BADGE[selected.severity] ?? SEVERITY_BADGE.LOW
                    )}
                  >
                    {selected.severity} (score: {selected.score})
                  </span>
                </div>
              </div>

              {/* Author */}
              <div className="flex items-center gap-2 rounded border p-2">
                <Avatar name={selected.userFullName} size="sm" className="h-7 w-7 text-[10px]" />
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{selected.userFullName}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    @{selected.userUsername}
                  </p>
                </div>
                {selected.reviewedByName && (
                  <span className="ml-auto text-xs text-muted-foreground">
                    Reviewed by {selected.reviewedByName} ·{" "}
                    {selected.reviewedAt && formatRelativeTime(selected.reviewedAt)}
                  </span>
                )}
              </div>

              {/* Reasons (admin-only — the raw rule IDs that matched) */}
              {selected.reasons.length > 0 && (
                <details className="text-xs">
                  <summary className="cursor-pointer text-muted-foreground">
                    Matched rules ({selected.reasons.length})
                  </summary>
                  <ul className="mt-1 space-y-1 rounded border bg-muted/30 p-2 font-mono text-[10px]">
                    {selected.reasons.map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                </details>
              )}

              {/* Actions */}
              {selected.status === "PENDING" && (
                <div className="flex flex-wrap gap-2 border-t pt-3">
                  <Button
                    size="sm"
                    variant="default"
                    disabled={acting}
                    onClick={() => takeAction(selected.id, "APPROVED", false)}
                  >
                    {acting ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <CheckCircle className="mr-1 h-3.5 w-3.5" />}
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    disabled={acting}
                    onClick={() => takeAction(selected.id, "REJECTED", true)}
                  >
                    {acting ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Trash2 className="mr-1 h-3.5 w-3.5" />}
                    Reject + Delete Content
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={acting}
                    onClick={() => takeAction(selected.id, "REJECTED", false)}
                  >
                    <XCircle className="mr-1 h-3.5 w-3.5" />
                    Reject (keep content)
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    disabled={acting}
                    onClick={() => takeAction(selected.id, "DISMISSED", false)}
                  >
                    <Ban className="mr-1 h-3.5 w-3.5" />
                    Dismiss
                  </Button>
                </div>
              )}
              {selected.status !== "PENDING" && (
                <div className="rounded border bg-muted/30 p-2 text-xs text-muted-foreground">
                  This event was already reviewed (status: {selected.status}). No further
                  actions available.
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// ── Helper: Overview Card ───────────────────────────────────────────────────

function OverviewCard({
  icon,
  label,
  value,
  loading,
}: {
  icon: React.ReactNode;
  label: string;
  value: number | string;
  loading: boolean;
}) {
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-muted-foreground">{label}</p>
          {loading ? (
            <Skeleton className="mt-1 h-7 w-16" />
          ) : (
            <p className="mt-1 text-2xl font-bold tabular-nums">
              {typeof value === "number" ? formatNumber(value) : value}
            </p>
          )}
        </div>
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted/50">
          {icon}
        </div>
      </div>
    </Card>
  );
}
