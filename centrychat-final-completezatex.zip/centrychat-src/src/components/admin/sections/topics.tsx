"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import {
  Hash, Plus, Search, Pencil, Trash2, Loader2, Check, X, Users,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ── Types ───────────────────────────────────────────────────────────────────

interface AdminTopicDTO {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  isActive: boolean;
  followerCount: number;
  articleCount: number;
  postCount: number;
  createdAt: string;
  updatedAt: string;
}

interface TopicListResponse {
  topics: AdminTopicDTO[];
  nextCursor: string | null;
}

// ── Component ───────────────────────────────────────────────────────────────

export function AdminTopics() {
  const [topics, setTopics] = useState<AdminTopicDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [editTopic, setEditTopic] = useState<AdminTopicDTO | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set("search", search.trim());
      params.set("limit", "50");
      const res = await api.get<TopicListResponse>(`/api/v1/admin/topics?${params}`);
      setTopics(res.topics);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load topics");
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    void load();
  }, [load]);

  // ── Handlers ─────────────────────────────────────────────────────────
  async function handleToggleActive(topic: AdminTopicDTO) {
    try {
      await api.patch(`/api/v1/admin/topics/${topic.id}`, {
        isActive: !topic.isActive,
      });
      toast.success(`${topic.name} ${topic.isActive ? "deactivated" : "activated"}`);
      setTopics((prev) =>
        prev.map((t) => t.id === topic.id ? { ...t, isActive: !t.isActive } : t)
      );
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update topic");
    }
  }

  async function handleDelete(topic: AdminTopicDTO) {
    if (!confirm(`Deactivate "${topic.name}"? Existing relationships will be preserved.`)) {
      return;
    }
    try {
      await api.delete(`/api/v1/admin/topics/${topic.id}`);
      toast.success(`${topic.name} deactivated`);
      setTopics((prev) =>
        prev.map((t) => t.id === topic.id ? { ...t, isActive: false } : t)
      );
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to deactivate topic");
    }
  }

  // ── Render ──────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Topics</h2>
          <p className="text-sm text-muted-foreground">
            Manage topics users can follow + assign to content.
          </p>
        </div>
        <Button onClick={() => setCreateOpen(true)}>
          <Plus className="h-4 w-4 mr-1.5" />
          New Topic
        </Button>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search topics..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button variant="secondary" size="sm" onClick={() => void load()}>
          Refresh
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : topics.length === 0 ? (
            <div className="p-12 text-center text-sm text-muted-foreground">
              No topics yet. Click "New Topic" to create one.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Slug</TableHead>
                  <TableHead className="text-center">Followers</TableHead>
                  <TableHead className="text-center">Articles</TableHead>
                  <TableHead className="text-center">Posts</TableHead>
                  <TableHead className="text-center">Active</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topics.map((topic) => (
                  <TableRow key={topic.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Hash className="h-3.5 w-3.5 text-muted-foreground" />
                        {topic.name}
                      </div>
                      {topic.description && (
                        <div className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
                          {topic.description}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <code className="text-xs bg-muted px-1.5 py-0.5 rounded">
                        {topic.slug}
                      </code>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="secondary" className="font-normal">
                        <Users className="h-3 w-3 mr-1" />
                        {topic.followerCount}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">{topic.articleCount}</TableCell>
                    <TableCell className="text-center">{topic.postCount}</TableCell>
                    <TableCell className="text-center">
                      <Switch
                        checked={topic.isActive}
                        onCheckedChange={() => void handleToggleActive(topic)}
                      />
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setEditTopic(topic)}
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => void handleDelete(topic)}
                          title="Deactivate"
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit dialog */}
      {(createOpen || editTopic) && (
        <TopicEditDialog
          topic={editTopic}
          onClose={() => {
            setCreateOpen(false);
            setEditTopic(null);
          }}
          onSaved={() => {
            setCreateOpen(false);
            setEditTopic(null);
            void load();
          }}
        />
      )}
    </div>
  );
}

// ── TopicEditDialog — create or edit a topic ────────────────────────────────

function TopicEditDialog({
  topic,
  onClose,
  onSaved,
}: {
  topic: AdminTopicDTO | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const isEdit = !!topic;
  const [name, setName] = useState(topic?.name ?? "");
  const [slug, setSlug] = useState(topic?.slug ?? "");
  const [description, setDescription] = useState(topic?.description ?? "");
  const [isActive, setIsActive] = useState(topic?.isActive ?? true);
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    if (!name.trim()) {
      toast.error("Name is required");
      return;
    }
    setSaving(true);
    try {
      if (isEdit && topic) {
        await api.patch(`/api/v1/admin/topics/${topic.id}`, {
          name: name.trim(),
          description: description.trim() || null,
          isActive,
          // Don't change slug unless explicitly provided + different.
          ...(slug !== topic.slug ? { slug: slug.trim() } : {}),
        });
        toast.success("Topic updated");
      } else {
        await api.post("/api/v1/admin/topics", {
          name: name.trim(),
          description: description.trim() || null,
          isActive,
          ...(slug.trim() ? { slug: slug.trim() } : {}),
        });
        toast.success("Topic created");
      }
      onSaved();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to save topic");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit Topic" : "Create Topic"}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? "Update the topic name, description, or active status."
              : "Create a new topic users can follow and assign to content."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="topic-name">Name</Label>
            <Input
              id="topic-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Artificial Intelligence"
              autoFocus
            />
            <p className="text-xs text-muted-foreground">
              Display name shown to users.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="topic-slug">Slug (optional)</Label>
            <Input
              id="topic-slug"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
              placeholder="auto-generated from name when empty"
            />
            <p className="text-xs text-muted-foreground">
              URL-safe identifier. Lowercase, hyphens. Cannot be changed
              once the topic has followers.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="topic-description">Description (optional)</Label>
            <Input
              id="topic-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Latest news + discussion about AI"
            />
          </div>

          {isEdit && (
            <div className="flex items-center justify-between">
              <Label htmlFor="topic-active">Active</Label>
              <Switch
                id="topic-active"
                checked={isActive}
                onCheckedChange={setIsActive}
              />
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : isEdit ? "Save" : "Create"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
