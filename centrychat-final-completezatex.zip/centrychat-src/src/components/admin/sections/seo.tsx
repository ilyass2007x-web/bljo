"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber } from "@/lib/client/format";
import { toast } from "sonner";
import {
  Globe, FileText, Map, Search, CheckCircle, XCircle,
  AlertTriangle, ExternalLink, Activity, Save, Loader2, Link2,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SEOData {
  platform: {
    name: string;
    description: string;
    nameSet: boolean;
    descriptionSet: boolean;
    // ── PHASE-7 SEO audit additions ──
    siteUrl: string;
    siteUrlSet: boolean;
    resolvedBaseUrl: string;
    baseUrlSource: "platform.site_url" | "env" | "default";
    envBaseUrl: string;
    baseUrl: string; // backward compat
    baseUrlSet: boolean;
  };
  articles: { totalPublished: number; missingExcerpt: number; missingCoverImage: number; missingTitle: number; draftCount: number; coveragePercent: number } | null;
  posts: { totalPosts: number; indexable: boolean; note: string } | null;
  topics: { estimatedTopics: number; note: string } | null;
  sitemap: {
    configured: boolean;
    url: string;
    urlCount: number;
    isIndex: boolean;
    includesArticles: boolean;
    includesTopics: boolean;
    includesProfiles: boolean;
    note: string;
  };
  robots: {
    configured: boolean;
    url: string;
    allowsRoot: boolean;
    allowsArticles: boolean;
    allowsTopics: boolean;
    disallowsApi: boolean;
    note: string;
  };
  structuredData: { articleSchema: boolean; topicSchema: boolean; websiteSchema: boolean; profileSchema: boolean };
  checks: Record<string, boolean>;
  seoScore: number;
  issues: { type: string; count: number; severity: "high" | "medium" | "low" }[];
  indexingControl: Record<string, string>;
  domainConsistency: {
    productionDomain: string;
    warnings: { surface: string; found: string; severity: "high" | "medium" | "low" }[];
    scannedAt: string;
  };
}

export function AdminSEO() {
  const [data, setData] = useState<SEOData | null>(null);
  const [loading, setLoading] = useState(true);
  // ── PHASE-7 SEO audit: editable Production Domain ──
  const [siteUrlInput, setSiteUrlInput] = useState("");
  const [saving, setSaving] = useState(false);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<{ seo: SEOData }>("/api/v1/admin/seo");
      setData(res.seo);
      // Initialize the input with the current resolved base URL.
      setSiteUrlInput(res.seo.platform.resolvedBaseUrl || res.seo.platform.baseUrl || "");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load SEO data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void fetch(); }, [fetch]);

  async function saveSiteUrl() {
    const trimmed = siteUrlInput.trim();
    if (!trimmed) {
      toast.error("Production Domain is required.");
      return;
    }
    if (!/^https?:\/\/.+/i.test(trimmed)) {
      toast.error("Production Domain must start with http:// or https://");
      return;
    }
    setSaving(true);
    try {
      await api.put("/api/v1/admin/seo", { siteUrl: trimmed });
      toast.success("Production Domain updated. All SEO surfaces will reflect the change within 30 seconds.");
      void fetch(); // refresh the dashboard
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update Production Domain.");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32 w-full rounded-lg" />
        <Skeleton className="h-64 w-full rounded-lg" />
      </div>
    );
  }

  if (!data) {
    return <Card><CardContent className="py-6 text-center text-sm text-destructive">Unable to load SEO data.</CardContent></Card>;
  }

  // ── PHASE-12 fix: normalize the API response so missing nested fields ──
  // don't crash the render. The API response shape may vary depending on
  // which PHASE added which fields. Without this normalization, accessing
  // `domainConsistency.warnings.map(...)` when `domainConsistency`
  // is undefined throws TypeError → triggers the global Error Boundary
  // → "Something went wrong" on the entire admin panel.
  // The normalization is additive — it only fills in defaults for MISSING
  // fields. It never removes or overrides existing data.
  const platform = data.platform ?? { name: "", description: "", nameSet: false, descriptionSet: false, siteUrl: "", siteUrlSet: false, resolvedBaseUrl: "", baseUrlSource: "default" as const, envBaseUrl: "", baseUrl: "", baseUrlSet: false };
  const articles = data.articles ?? null;
  const posts = data.posts ?? null;
  const topics = data.topics ?? null;
  const sitemap = data.sitemap ?? { configured: true, url: "", urlCount: 0, isIndex: false, includesArticles: true, includesTopics: false, includesProfiles: false, note: "" };
  const robots = data.robots ?? { configured: true, url: "", allowsRoot: true, allowsArticles: true, allowsTopics: true, disallowsApi: true, note: "" };
  const structuredData = data.structuredData ?? { articleSchema: true, topicSchema: true, websiteSchema: true, profileSchema: false };
  const checks = data.checks ?? {};
  const issues = data.issues ?? [];
  const indexingControl = data.indexingControl ?? {};
  const domainConsistency = data.domainConsistency ?? { productionDomain: platform.resolvedBaseUrl || platform.baseUrl || "", warnings: [] as { surface: string; found: string; severity: "high" | "medium" | "low" }[], scannedAt: new Date().toISOString() };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">SEO Center</h2>
        <p className="text-sm text-muted-foreground">Monitor and improve search engine discoverability. All checks use real database data.</p>
      </div>

      {/* ── PHASE-7 SEO audit: Production Domain editor ──────────────── */}
      <Card className="border-primary/30">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <Globe className="h-4 w-4 text-primary" /> Production Domain (Single Source of Truth)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2">
            <Label htmlFor="site-url">Canonical Production URL</Label>
            <Input
              id="site-url"
              value={siteUrlInput}
              onChange={(e) => setSiteUrlInput(e.target.value)}
              placeholder="https://centrychat.netlify.app"
              maxLength={200}
              className="font-mono text-sm"
            />
            <p className="text-[10px] text-muted-foreground">
              Used as the single source of truth for sitemap, robots.txt, canonical URLs, OpenGraph, Twitter Card, JSON-LD, and all absolute URLs. Change this when switching to a custom domain.
            </p>
          </div>

          {/* Resolved source info */}
          <div className="grid gap-2 rounded-lg border bg-muted/30 p-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Currently resolved from:</span>
              <Badge variant="secondary" className="font-mono text-[10px]">
                {platform.baseUrlSource === "platform.site_url" && "platform.site_url (DB)"}
                {platform.baseUrlSource === "env" && "NEXT_PUBLIC_APP_BASE_URL (env)"}
                {platform.baseUrlSource === "default" && "default (localhost — dev only)"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Active Production URL:</span>
              <span className="truncate font-mono font-medium" dir="auto">{platform.resolvedBaseUrl}</span>
            </div>
            {platform.envBaseUrl && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Env var fallback:</span>
                <span className={cn(
                  "truncate font-mono",
                  platform.envBaseUrl.includes("localhost") ? "text-amber-600 dark:text-amber-400" : ""
                )} dir="auto">{platform.envBaseUrl}</span>
              </div>
            )}
          </div>

          <Button onClick={saveSiteUrl} disabled={saving || siteUrlInput === platform.resolvedBaseUrl} size="sm">
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Save Production Domain
          </Button>
          <p className="text-[10px] text-muted-foreground">
            After saving, all SEO surfaces (sitemap, robots, canonical, OG, JSON-LD) pick up the new value within 30 seconds. No rebuild or redeploy needed.
          </p>
        </CardContent>
      </Card>

      {/* ── PHASE-7 SEO audit: Domain Consistency Scanner ─────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <Link2 className="h-4 w-4" /> Domain Consistency Scanner
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <Row label="Production Domain" value={domainConsistency.productionDomain} ok />
          <p className="text-[10px] text-muted-foreground">Last scanned: {new Date(domainConsistency.scannedAt).toLocaleString()}</p>
          <div className="space-y-1">
            {domainConsistency.warnings.length === 0 ? (
              <p className="text-xs text-green-600 dark:text-green-400 flex items-center gap-1">
                <CheckCircle className="h-3 w-3" /> No domain consistency warnings.
              </p>
            ) : (
              domainConsistency.warnings.map((w, i) => (
                <div key={i} className={cn(
                  "flex items-center justify-between rounded border px-2 py-1.5 text-xs",
                  w.severity === "high"
                    ? "border-destructive/30 bg-destructive/5"
                    : w.severity === "medium"
                      ? "border-amber-500/20 bg-amber-500/5"
                      : "border-border bg-muted/20"
                )}>
                  <span className="text-muted-foreground">{w.surface}</span>
                  <span className="truncate font-mono text-[10px] max-w-60" dir="auto">{w.found}</span>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* SEO Health Score (spec §24) */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground">SEO Health Score</p>
              <p className={cn("text-4xl font-bold",
                data.seoScore >= 90 ? "text-green-600 dark:text-green-400" :
                data.seoScore >= 70 ? "text-amber-600 dark:text-amber-400" :
                "text-destructive")}>
                {data.seoScore}%
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {Object.entries(checks).map(([key, passed]) => (
                <Badge key={key} variant={passed ? "default" : "destructive"} className="text-[10px]">
                  {passed ? <CheckCircle className="mr-0.5 h-2.5 w-2.5" /> : <XCircle className="mr-0.5 h-2.5 w-2.5" />}
                  {key.replace(/([A-Z])/g, " $1").replace(/^./, c => c.toUpperCase()).trim()}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Platform Settings (spec §3, §4) */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold"><Globe className="h-4 w-4" /> Global Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <Row label="Site Name" value={platform.name} ok={platform.nameSet} />
          <Row label="Site Description" value={platform.description} ok={platform.descriptionSet} />
          <Row label="Canonical Base URL" value={platform.resolvedBaseUrl} ok={platform.baseUrlSet} />
          <p className="mt-2 text-[10px] text-muted-foreground">
            Configure via Admin → Settings → Customization. Changes propagate to browser title, meta description, OpenGraph, and structured data.
          </p>
        </CardContent>
      </Card>

      {/* Content SEO Report (spec §25) */}
      <div className="grid gap-4 lg:grid-cols-2">
        {/* Article SEO */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold"><FileText className="h-4 w-4" /> Article SEO</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {articles ? (
              <>
                <Row label="Published Articles" value={formatNumber(articles.totalPublished)} ok />
                <Row label="SEO Coverage" value={`${articles.coveragePercent}%`} ok={articles.coveragePercent >= 80} />
                {articles.missingTitle > 0 && <IssueRow label="Missing Title" count={articles.missingTitle} severity="high" />}
                {articles.missingExcerpt > 0 && <IssueRow label="Missing Description/Excerpt" count={articles.missingExcerpt} severity="medium" />}
                {articles.missingCoverImage > 0 && <IssueRow label="Missing Cover Image" count={articles.missingCoverImage} severity="medium" />}
                <Row label="Drafts (noindex ✓)" value={formatNumber(articles.draftCount)} ok />
              </>
            ) : <p className="text-destructive">Unable to load article SEO data.</p>}
          </CardContent>
        </Card>

        {/* Post SEO */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold"><FileText className="h-4 w-4" /> Post SEO</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {posts ? (
              <>
                <Row label="Total Posts" value={formatNumber(posts.totalPosts)} ok />
                <Row label="Indexable" value="No (SPA-only)" ok={false} />
                <p className="text-[10px] text-muted-foreground">{posts.note}</p>
              </>
            ) : <p className="text-destructive">Unable to load post SEO data.</p>}
          </CardContent>
        </Card>
      </div>

      {/* Sitemap + Robots (spec §14, §17) */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold"><Map className="h-4 w-4" /> Sitemap</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Row label="Configured" value="Yes (auto-generated)" ok={sitemap.configured} />
            <Row label="URL" value={sitemap.url} ok />
            <Row label="URL Count" value={formatNumber(sitemap.urlCount)} ok />
            <Row label="Sitemap Index" value={sitemap.isIndex ? "Yes (>50k URLs → chunked)" : "No (single file)"} ok={sitemap.urlCount <= 50000} />
            <Row label="Includes Articles" value="Yes" ok={sitemap.includesArticles} />
            <Row label="Includes Topics" value="No (future)" ok={sitemap.includesTopics} />
            <Row label="Includes Profiles" value="No (SPA-only)" ok={sitemap.includesProfiles} />
            <p className="mt-1 text-[10px] text-muted-foreground">{sitemap.note}</p>
            <Button size="sm" variant="outline" className="mt-1" onClick={() => window.open(sitemap.url, "_blank")}>
              <ExternalLink className="mr-1 h-3 w-3" /> View Sitemap
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold"><Search className="h-4 w-4" /> Robots.txt</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Row label="Configured" value="Yes (auto-generated)" ok={robots.configured} />
            <Row label="URL" value={robots.url} ok />
            <Row label="Allow /" value="Yes" ok={robots.allowsRoot} />
            <Row label="Allow /articles/" value="Yes" ok={robots.allowsArticles} />
            <Row label="Allow /topics/" value="Yes" ok={robots.allowsTopics} />
            <Row label="Disallow /api/" value="Yes" ok={robots.disallowsApi} />
            <p className="mt-1 text-[10px] text-muted-foreground">{robots.note}</p>
            <Button size="sm" variant="outline" className="mt-1" onClick={() => window.open(robots.url, "_blank")}>
              <ExternalLink className="mr-1 h-3 w-3" /> View Robots.txt
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Structured Data (spec §10-§13) */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold"><Activity className="h-4 w-4" /> Structured Data (Schema.org JSON-LD)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <SchemaCard label="Article Schema" ok={structuredData.articleSchema} desc="Article JSON-LD on /articles/[id]" />
            <SchemaCard label="Topic Schema" ok={structuredData.topicSchema} desc="CollectionPage JSON-LD on /topics/[tag]" />
            <SchemaCard label="WebSite Schema" ok={structuredData.websiteSchema} desc="WebSite + SearchAction JSON-LD on root layout" />
            <SchemaCard label="Profile Schema" ok={structuredData.profileSchema} desc="Not applicable (profiles are SPA-only)" />
          </div>
        </CardContent>
      </Card>

      {/* Indexing Control (spec §26) */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold"><Globe className="h-4 w-4" /> Indexing Control</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {Object.entries(indexingControl).map(([type, status]) => (
              <div key={type} className="rounded-lg border p-2 text-center">
                <p className="text-xs font-medium capitalize">{type}</p>
                <Badge variant={status === "indexable" ? "default" : "outline"} className="mt-1 text-[10px]">{status}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* SEO Issues (spec §25) */}
      {issues.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold"><AlertTriangle className="h-4 w-4 text-amber-500" /> SEO Issues</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {issues.map((issue, i) => (
                <div key={i} className={cn("flex items-center justify-between rounded border px-3 py-2 text-sm",
                  issue.severity === "high" ? "border-destructive/30 bg-destructive/5" : "border-amber-500/20 bg-amber-500/5")}>
                  <span>{issue.type}</span>
                  <Badge variant={issue.severity === "high" ? "destructive" : "secondary"} className="text-[10px]">{issue.count} affected</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Data accuracy notice */}
      <p className="text-center text-[10px] text-muted-foreground">
        All SEO checks use real database data. SEO improvements make the website easier for search engines to crawl — actual indexing/ranking is controlled by search engines.
      </p>
    </div>
  );
}

function Row({ label, value, ok }: { label: string; value: string; ok?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="flex items-center gap-1.5 font-medium">
        {ok !== undefined && (ok ? <CheckCircle className="h-3 w-3 text-green-500" /> : <XCircle className="h-3 w-3 text-destructive" />)}
        <span className="truncate max-w-48" dir="auto">{value}</span>
      </span>
    </div>
  );
}

function IssueRow({ label, count, severity }: { label: string; count: number; severity: "high" | "medium" | "low" }) {
  return (
    <div className={cn("flex items-center justify-between rounded px-2 py-1 text-xs",
      severity === "high" ? "bg-destructive/5 text-destructive" : "bg-amber-500/5 text-amber-600 dark:text-amber-400")}>
      <span>{label}</span>
      <span className="font-medium">{count}</span>
    </div>
  );
}

function SchemaCard({ label, ok, desc }: { label: string; ok: boolean; desc: string }) {
  return (
    <div className="rounded-lg border p-2 text-center">
      {ok ? <CheckCircle className="mx-auto h-4 w-4 text-green-500" /> : <XCircle className="mx-auto h-4 w-4 text-muted-foreground" />}
      <p className="mt-1 text-xs font-medium">{label}</p>
      <p className="text-[9px] text-muted-foreground">{desc}</p>
    </div>
  );
}
