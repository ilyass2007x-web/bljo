"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber, formatRelativeTime } from "@/lib/client/format";
import {
  Users, FileText, Heart, MessageCircle, Eye, Share2, TrendingUp,
  Activity, AlertTriangle, CheckCircle, XCircle, HelpCircle,
  LayoutDashboard, Shield, Search as SearchIcon, Cpu, ScrollText,
  UserCog, ArrowRight,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ── Types ──────────────────────────────────────────────────────────────────

interface DashboardStats {
  range: string;
  userStats: {
    totalUsers: number; activeUsers: number; suspendedUsers: number;
    bannedUsers: number; pendingVerification: number;
    newToday: number; newThisWeek: number; newThisMonth: number;
    newInRange: number; activeRecently: number;
  } | null;
  contentStats: {
    totalPosts: number; totalPublishedArticles: number; draftArticles: number;
    postsToday: number; articlesToday: number;
    postsInRange: number; articlesInRange: number;
  } | null;
  engagementStats: {
    totalLikes: number; totalComments: number; totalShares: number;
    totalUniqueViews: number; engagementRate: number;
    likesInRange: number; commentsInRange: number;
    sharesInRange: number; viewsInRange: number;
  } | null;
  growth: { date: string; users: number; posts: number; articles: number; engagement: number }[];
  topContent: {
    posts: any[];
    articles: any[];
    all: any[];
  } | null;
  topCreators: any[] | null;
  recentActivity: { type: string; timestamp: number; text: string; meta?: string }[] | null;
  systemStatus: {
    database: "healthy" | "error" | "not_monitored";
    cloudinary: "healthy" | "error" | "not_monitored";
    resend: "healthy" | "error" | "not_monitored";
    realtime: "healthy" | "error" | "not_monitored";
  };
  messagingStats: {
    totalConversations: number; totalMessages: number;
    unreadMessages: number; reports: { open: number; total: number };
  } | null;
}

type Range = "24h" | "7d" | "30d" | "90d" | "1y";
type GrowthMetric = "users" | "posts" | "articles" | "engagement";
type ContentTab = "all" | "posts" | "articles";

// ── Component ──────────────────────────────────────────────────────────────

export function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [range, setRange] = useState<Range>("30d");
  const [growthMetric, setGrowthMetric] = useState<GrowthMetric>("users");
  const [contentTab, setContentTab] = useState<ContentTab>("all");

  const fetchStats = useCallback(async (r: Range) => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.get<{ stats: DashboardStats }>(
        `/api/v1/admin/dashboard?range=${r}`
      );
      setStats(data.stats);
    } catch (e) {
      setError(e instanceof ApiClientError ? e.message : "Failed to load stats");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchStats(range);
  }, [range, fetchStats]);

  function handleRangeChange(r: Range) {
    setRange(r);
  }

  return (
    <div className="space-y-6">
      {/* ── Header + Time Range Selector ─────────────────────────── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-sm text-muted-foreground">
            Real-time platform statistics from the database.
          </p>
        </div>
        {/* Time Range Selector (spec §8) */}
        <div className="flex flex-wrap gap-1 rounded-lg border bg-muted/30 p-1">
          {(["24h", "7d", "30d", "90d", "1y"] as Range[]).map((r) => (
            <button
              key={r}
              onClick={() => handleRangeChange(r)}
              className={cn(
                "rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                range === r
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {r === "24h" ? "24 Hours" : r === "7d" ? "7 Days" : r === "30d" ? "30 Days" : r === "90d" ? "90 Days" : "1 Year"}
            </button>
          ))}
        </div>
      </div>

      {/* ── Main stat cards (spec §4, §5, §6, §7) ─────────────────── */}
      {error ? (
        <Card>
          <CardContent className="py-10 text-center text-destructive">{error}</CardContent>
        </Card>
      ) : (
        <StatCards loading={loading} stats={stats} range={range} />
      )}

      {/* ── Growth Chart (spec §9) ────────────────────────────────── */}
      <GrowthChart
        data={stats?.growth ?? []}
        metric={growthMetric}
        onMetricChange={setGrowthMetric}
        loading={loading}
      />

      {/* ── Two-column layout: Top Content + Top Creators ───────── */}
      <div className="grid gap-4 lg:grid-cols-2">
        <TopContent
          stats={stats?.topContent ?? null}
          tab={contentTab}
          onTabChange={setContentTab}
          loading={loading}
        />
        <TopCreators creators={stats?.topCreators ?? null} loading={loading} />
      </div>

      {/* ── Recent Activity + System Status ─────────────────────── */}
      <div className="grid gap-4 lg:grid-cols-2">
        <RecentActivity activities={stats?.recentActivity ?? null} loading={loading} />
        <SystemStatus status={stats?.systemStatus} loading={loading} />
      </div>

      {/* ── Quick Actions (spec §14) ─────────────────────────────── */}
      <QuickActions router={router} />
    </div>
  );
}

// ── Sub-component: Stat Cards ────────────────────────────────────────────────

function StatCards({ loading, stats, range }: { loading: boolean; stats: DashboardStats | null; range: Range }) {
  const rangeLabel = range === "24h" ? "24h" : range === "7d" ? "7d" : range === "30d" ? "30d" : range === "90d" ? "90d" : "1y";

  const cards = [
    {
      label: "Total Users",
      value: stats?.userStats?.totalUsers,
      rangeValue: stats?.userStats?.newInRange,
      rangeLabel: `New (${rangeLabel})`,
      icon: Users, color: "text-blue-500",
      sub: stats?.userStats ? `${stats.userStats.pendingVerification} pending` : undefined,
    },
    {
      label: "Total Posts",
      value: stats?.contentStats?.totalPosts,
      rangeValue: stats?.contentStats?.postsInRange,
      rangeLabel: `New (${rangeLabel})`,
      icon: FileText, color: "text-emerald-500",
      sub: stats?.contentStats ? `${stats.contentStats.postsToday} today` : undefined,
    },
    {
      label: "Published Articles",
      value: stats?.contentStats?.totalPublishedArticles,
      rangeValue: stats?.contentStats?.articlesInRange,
      rangeLabel: `New (${rangeLabel})`,
      icon: FileText, color: "text-purple-500",
      sub: stats?.contentStats ? `${stats.contentStats.draftArticles} drafts` : undefined,
    },
    {
      label: "Total Likes",
      value: stats?.engagementStats?.totalLikes,
      rangeValue: stats?.engagementStats?.likesInRange,
      rangeLabel: `New (${rangeLabel})`,
      icon: Heart, color: "text-red-500",
    },
    {
      label: "Total Comments",
      value: stats?.engagementStats?.totalComments,
      rangeValue: stats?.engagementStats?.commentsInRange,
      rangeLabel: `New (${rangeLabel})`,
      icon: MessageCircle, color: "text-sky-500",
    },
    {
      label: "Unique Views",
      value: stats?.engagementStats?.totalUniqueViews,
      rangeValue: stats?.engagementStats?.viewsInRange,
      rangeLabel: `New (${rangeLabel})`,
      icon: Eye, color: "text-amber-500",
    },
    {
      label: "Total Shares",
      value: stats?.engagementStats?.totalShares,
      rangeValue: stats?.engagementStats?.sharesInRange,
      rangeLabel: `New (${rangeLabel})`,
      icon: Share2, color: "text-teal-500",
    },
    {
      label: "Engagement Rate",
      value: stats?.engagementStats?.engagementRate,
      rangeValue: undefined,
      rangeLabel: "",
      icon: TrendingUp, color: "text-primary",
      suffix: "%",
      sub: "Likes+Comments+Shares / Unique Views",
    },
  ];

  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((c) => (
        <Card key={c.label}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">{c.label}</CardTitle>
            <c.icon className={cn("h-4 w-4", c.color)} />
          </CardHeader>
          <CardContent>
            {loading || c.value == null ? (
              <Skeleton className="h-7 w-16" />
            ) : (
              <div className="text-2xl font-bold">
                {formatNumber(c.value)}{c.suffix}
              </div>
            )}
            {c.rangeValue != null && !loading && (
              <p className="mt-1 text-xs text-muted-foreground">
                <span className="font-medium text-foreground">+{formatNumber(c.rangeValue)}</span>{" "}
                {c.rangeLabel}
              </p>
            )}
            {c.sub && !loading && (
              <p className="mt-0.5 text-xs text-muted-foreground">{c.sub}</p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ── Sub-component: Growth Chart (lightweight inline SVG) ───────────────────

function GrowthChart({
  data,
  metric,
  onMetricChange,
  loading,
}: {
  data: { date: string; users: number; posts: number; articles: number; engagement: number }[];
  metric: GrowthMetric;
  onMetricChange: (m: GrowthMetric) => void;
  loading: boolean;
}) {
  const metricLabels: Record<GrowthMetric, string> = {
    users: "Users", posts: "Posts", articles: "Articles", engagement: "Engagement",
  };

  // Calculate chart dimensions + points.
  const values = data.map((d) => d[metric]);
  const maxValue = Math.max(1, ...values);
  const width = 600;
  const height = 200;
  const padding = 30;

  const points = data.length > 0
    ? data.map((d, i) => {
        const x = padding + (i / Math.max(1, data.length - 1)) * (width - 2 * padding);
        const y = height - padding - (d[metric] / maxValue) * (height - 2 * padding);
        return { x, y, value: d[metric], date: d.date };
      })
    : [];

  const pathD = points.length > 0
    ? points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ")
    : "";

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <div>
          <CardTitle className="text-sm font-semibold">Growth Chart</CardTitle>
          <p className="text-xs text-muted-foreground">
            Daily {metricLabels[metric].toLowerCase()} over the selected period.
          </p>
        </div>
        <div className="flex gap-1 rounded-lg border bg-muted/30 p-1">
          {(["users", "posts", "articles", "engagement"] as GrowthMetric[]).map((m) => (
            <button
              key={m}
              onClick={() => onMetricChange(m)}
              className={cn(
                "rounded-md px-2.5 py-1 text-xs font-medium transition-colors",
                metric === m
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {metricLabels[m]}
            </button>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <Skeleton className="h-48 w-full rounded-lg" />
        ) : data.length === 0 ? (
          <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">
            No data for this period.
          </div>
        ) : (
          <div className="w-full overflow-x-auto">
            <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ minWidth: 300, height: 200 }}>
              {/* Y-axis grid lines (4 lines) */}
              {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
                const y = height - padding - ratio * (height - 2 * padding);
                const val = Math.round(maxValue * ratio);
                return (
                  <g key={ratio}>
                    <line x1={padding} y1={y} x2={width - padding} y2={y} stroke="currentColor" strokeWidth={0.5} className="text-border" />
                    <text x={padding - 5} y={y + 3} textAnchor="end" fontSize={9} fill="currentColor" className="text-muted-foreground">
                      {val}
                    </text>
                  </g>
                );
              })}
              {/* Area under the line (gradient) */}
              {pathD && (
                <>
                  <path d={`${pathD} L ${(points[points.length - 1]!.x).toFixed(1)} ${height - padding} L ${padding} ${height - padding} Z`} fill="currentColor" className="text-primary/10" />
                  {/* Line */}
                  <path d={pathD} fill="none" stroke="currentColor" strokeWidth={2} className="text-primary" />
                  {/* Points (only show if few enough to avoid clutter) */}
                  {points.length <= 31 && points.map((p, i) => (
                    <circle key={i} cx={p.x} cy={p.y} r={2} fill="currentColor" className="text-primary" />
                  ))}
                </>
              )}
              {/* X-axis labels (first + last date) */}
              {data.length > 0 && (
                <>
                  <text x={padding} y={height - 8} textAnchor="start" fontSize={9} fill="currentColor" className="text-muted-foreground">
                    {data[0]!.date}
                  </text>
                  <text x={width - padding} y={height - 8} textAnchor="end" fontSize={9} fill="currentColor" className="text-muted-foreground">
                    {data[data.length - 1]!.date}
                  </text>
                </>
              )}
            </svg>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ── Sub-component: Top Content ─────────────────────────────────────────────

function TopContent({
  stats,
  tab,
  onTabChange,
  loading,
}: {
  stats: DashboardStats["topContent"];
  tab: ContentTab;
  onTabChange: (t: ContentTab) => void;
  loading: boolean;
}) {
  const items = stats
    ? tab === "posts" ? stats.posts : tab === "articles" ? stats.articles : stats.all
    : [];

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-sm font-semibold">Top Content</CardTitle>
        <div className="flex gap-1 rounded-lg border bg-muted/30 p-1">
          {(["all", "posts", "articles"] as ContentTab[]).map((t) => (
            <button
              key={t}
              onClick={() => onTabChange(t)}
              className={cn(
                "rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors",
                tab === t ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t}
            </button>
          ))}
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {loading ? (
          [0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-12 w-full rounded-lg" />)
        ) : items.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">No content in this period.</p>
        ) : (
          items.map((item, i) => (
            <div key={`${item.type}-${item.id}`} className="flex items-center gap-2 rounded-lg border p-2 hover:bg-accent/30">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-bold">
                {i + 1}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium" dir="auto">{item.title}</p>
                <p className="truncate text-xs text-muted-foreground">
                  by {item.author?.fullName} · {item.type}
                </p>
              </div>
              <div className="flex shrink-0 gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-0.5"><Heart className="h-3 w-3" />{item.counts?.likes ?? 0}</span>
                <span className="flex items-center gap-0.5"><MessageCircle className="h-3 w-3" />{item.counts?.comments ?? 0}</span>
                <span className="flex items-center gap-0.5"><Eye className="h-3 w-3" />{item.counts?.views ?? 0}</span>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}

// ── Sub-component: Top Creators ────────────────────────────────────────────

function TopCreators({ creators, loading }: { creators: any[] | null; loading: boolean }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold">Top Creators</CardTitle>
        <p className="text-xs text-muted-foreground">Most active users in this period.</p>
      </CardHeader>
      <CardContent className="space-y-2">
        {loading ? (
          [0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-12 w-full rounded-lg" />)
        ) : !creators || creators.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">No creator activity in this period.</p>
        ) : (
          creators.map((c, i) => (
            <div key={c.id} className="flex items-center gap-2 rounded-lg border p-2 hover:bg-accent/30">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-bold">
                {i + 1}
              </span>
              <Avatar name={c.fullName} size="sm" className="h-6 w-6 text-[10px]" />
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1 truncate text-sm font-medium" dir="auto">
                  {c.fullName}
                  {c.isVerified && <VerifiedBadge size={10} />}
                </p>
                <p className="truncate text-xs text-muted-foreground">@{c.username}</p>
              </div>
              <div className="flex shrink-0 gap-2 text-xs text-muted-foreground">
                <span title="Posts in period">📝 {c.postsInPeriod}</span>
                <span title="Articles in period">📖 {c.articlesInPeriod}</span>
                <span title="Followers">👥 {c.followers}</span>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}

// ── Sub-component: Recent Activity ─────────────────────────────────────────

function RecentActivity({ activities, loading }: { activities: any[] | null; loading: boolean }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold">Recent Activity</CardTitle>
        <p className="text-xs text-muted-foreground">Safe administrative events only.</p>
      </CardHeader>
      <CardContent className="space-y-1.5">
        {loading ? (
          [0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-8 w-full rounded-lg" />)
        ) : !activities || activities.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">No recent activity.</p>
        ) : (
          activities.map((a, i) => (
            <div key={i} className="flex items-start gap-2 rounded-lg p-2 hover:bg-accent/30">
              <Activity className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm" dir="auto">{a.text}</p>
                {a.meta && <p className="truncate text-xs text-muted-foreground" dir="auto">{a.meta}</p>}
              </div>
              <span className="shrink-0 text-xs text-muted-foreground">
                {formatRelativeTime(new Date(a.timestamp).toISOString())}
              </span>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}

// ── Sub-component: System Status ───────────────────────────────────────────

function SystemStatus({ status, loading }: { status: DashboardStats["systemStatus"] | undefined; loading: boolean }) {
  if (!status && !loading) return null;

  const services = [
    { name: "Database", key: "database" as const },
    { name: "Cloudinary", key: "cloudinary" as const },
    { name: "Resend (Email)", key: "resend" as const },
    { name: "Realtime", key: "realtime" as const },
  ];

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold">System Status</CardTitle>
        <p className="text-xs text-muted-foreground">Only verifiable services are shown.</p>
      </CardHeader>
      <CardContent className="space-y-2">
        {loading ? (
          [0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-8 w-full rounded-lg" />)
        ) : (
          services.map((s) => {
            const value = status?.[s.key] ?? "not_monitored";
            return (
              <div key={s.key} className="flex items-center justify-between rounded-lg border p-2">
                <span className="text-sm font-medium">{s.name}</span>
                <StatusBadge status={value} />
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}

function StatusBadge({ status }: { status: "healthy" | "error" | "not_monitored" }) {
  if (status === "healthy") {
    return (
      <span className="flex items-center gap-1 text-xs font-medium text-green-600 dark:text-green-400">
        <CheckCircle className="h-3.5 w-3.5" /> Healthy
      </span>
    );
  }
  if (status === "error") {
    return (
      <span className="flex items-center gap-1 text-xs font-medium text-destructive">
        <XCircle className="h-3.5 w-3.5" /> Error
      </span>
    );
  }
  return (
    <span className="flex items-center gap-1 text-xs font-medium text-muted-foreground">
      <HelpCircle className="h-3.5 w-3.5" /> Not monitored
    </span>
  );
}

// ── Sub-component: Quick Actions ──────────────────────────────────────────

function QuickActions({ router }: { router: ReturnType<typeof useRouter> }) {
  const actions = [
    { label: "Manage Users", icon: Users, view: "users" },
    { label: "Manage Posts", icon: FileText, view: "homepage" }, // posts moderation → homepage section for now
    { label: "Manage Articles", icon: FileText, view: "homepage" },
    { label: "Moderation", icon: Shield, view: "moderation" },
    { label: "Algorithm", icon: Cpu, view: "recommendation" },
    { label: "Search Analytics", icon: SearchIcon, view: "system" }, // placeholder until dedicated section
    { label: "SEO", icon: LayoutDashboard, view: "homepage" },
    { label: "System Health", icon: Activity, view: "system" },
  ];

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold">Quick Actions</CardTitle>
        <p className="text-xs text-muted-foreground">Jump to admin sections.</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {actions.map((a) => (
            <button
              key={a.label}
              onClick={() => router.push(`/?view=admin&section=${a.view}`)}
              className="flex flex-col items-center gap-1.5 rounded-lg border p-3 text-center transition-colors hover:bg-accent/30"
            >
              <a.icon className="h-5 w-5 text-muted-foreground" />
              <span className="text-xs font-medium">{a.label}</span>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
