"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber, formatRelativeTime } from "@/lib/client/format";
import { toast } from "sonner";
import {
  Users, Eye, FileText, UserPlus, UserCheck, Clock, TrendingUp,
  Download, Loader2, Globe, Smartphone, Monitor, Tablet,
  Search, Share2, Mail, Link2, BarChart3,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  getSourceColor, getSourceLabel,
} from "@/lib/analytics/classify-source";
import {
  MetricCard, EmptyState, LoadingState, ErrorState,
} from "@/components/admin/analytics/components";
import { SourcesDonutChart, TrafficOverTimeChart, SimpleBarChart } from "@/components/admin/analytics/charts";
import { ArticleTrafficModal } from "@/components/admin/analytics/article-modal";
import {
  ArticleOverviewCard,
  RecentActivityCard,
  SortDropdown,
} from "@/components/admin/analytics/article-overview";
import type {
  TrafficOverview, SourcesData, ArticlesData, ReferrersData,
  RealtimeData, DevicesData, AnalyticsRange,
  ArticleOverviewData, RecentActivityData, ArticleSortKey,
} from "@/components/admin/analytics/types";
import { RANGE_OPTIONS } from "@/components/admin/analytics/types";

/**
 * AdminTrafficAnalytics — the main Traffic Analytics dashboard section.
 *
 * Layout:
 *   - Header with title + time range filter + export button
 *   - Overview cards (7 metrics with growth %)
 *   - Sources donut chart + Traffic over time line chart (side by side)
 *   - Article traffic table (clickable rows → open ArticleTrafficModal)
 *   - Top referrers + Realtime visitors (side by side)
 *   - Devices / Browsers / OS bar charts
 *
 * Behavior:
 *   - All data fetched in parallel on mount + when the range changes.
 *   - Realtime data auto-refreshes every 30 seconds (polling, not WebSocket).
 *   - When the AnalyticsEvent table is empty, shows the EmptyState.
 *   - Export button triggers a CSV/JSON download (server-side).
 *
 * Performance:
 *   - Each API endpoint is cached 30s server-side, so refreshing the
 *     dashboard doesn't hammer the DB.
 *   - Realtime polling is a single lightweight query (count + small groupBy).
 */
export function AdminTrafficAnalytics() {
  const [range, setRange] = useState<AnalyticsRange>("30d");
  const [overview, setOverview] = useState<TrafficOverview | null>(null);
  const [sources, setSources] = useState<SourcesData | null>(null);
  const [articles, setArticles] = useState<ArticlesData | null>(null);
  const [referrers, setReferrers] = useState<ReferrersData | null>(null);
  const [devices, setDevices] = useState<DevicesData | null>(null);
  const [realtime, setRealtime] = useState<RealtimeData | null>(null);
  // PHASE 11 — canonical ArticleView overview (total/unique/today/etc.)
  const [articleOverview, setArticleOverview] = useState<ArticleOverviewData | null>(null);
  // PHASE 13 — recent article-view feed.
  const [recentActivity, setRecentActivity] = useState<RecentActivityData | null>(null);
  // PHASE 16 — sort dropdown for the Article Traffic table.
  const [sort, setSort] = useState<ArticleSortKey>("views");
  const [loading, setLoading] = useState(true);
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);
  const [selectedArticleTitle, setSelectedArticleTitle] = useState("");
  const [exporting, setExporting] = useState(false);

  // ── Fetch all data ──
  const fetchAll = useCallback(async (r: AnalyticsRange, s: ArticleSortKey) => {
    setLoading(true);
    const rangeParam = `range=${r}`;
    const sortParam = `&sort=${s}`;
    try {
      const [ov, src, arts, refs, devs, ao] = await Promise.all([
        api.get<{ analytics: TrafficOverview }>(`/api/v1/admin/analytics/traffic?${rangeParam}`),
        api.get<{ analytics: SourcesData }>(`/api/v1/admin/analytics/sources?${rangeParam}`),
        api.get<{ analytics: ArticlesData }>(`/api/v1/admin/analytics/articles?${rangeParam}${sortParam}`),
        api.get<{ analytics: ReferrersData }>(`/api/v1/admin/analytics/referrers?${rangeParam}`),
        api.get<{ analytics: DevicesData }>(`/api/v1/admin/analytics/devices?${rangeParam}`),
        // PHASE 11 — canonical ArticleView overview (range-independent, but
        // fetched in parallel for a single loading state).
        api.get<{ analytics: ArticleOverviewData }>(`/api/v1/admin/analytics/overview`),
      ]);
      setOverview(ov.analytics);
      setSources(src.analytics);
      setArticles(arts.analytics);
      setReferrers(refs.analytics);
      setDevices(devs.analytics);
      setArticleOverview(ao.analytics);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load analytics");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchAll(range, sort);
  }, [range, sort, fetchAll]);

  // ── Realtime polling (every 30s) ──
  // Fetches BOTH the live-visitors count (existing) AND the recent article-view
  // activity feed (PHASE 13). Both are real-time-ish — they poll together to
  // share a single timer.
  const fetchRealtime = useCallback(async () => {
    try {
      const [rt, ra] = await Promise.all([
        api.get<{ analytics: RealtimeData }>(`/api/v1/admin/analytics/realtime?minutes=5`),
        api.get<{ analytics: RecentActivityData }>(`/api/v1/admin/analytics/recent-activity?limit=20`),
      ]);
      setRealtime(rt.analytics);
      setRecentActivity(ra.analytics);
    } catch {
      // Silent — realtime is non-critical.
    }
  }, []);

  useEffect(() => {
    void fetchRealtime();
    const interval = setInterval(fetchRealtime, 30_000);
    return () => clearInterval(interval);
  }, [fetchRealtime]);

  // ── Export ──
  async function handleExport(format: "csv" | "json") {
    setExporting(true);
    try {
      // The export endpoint returns a file download — we trigger it via
      // a hidden anchor so the browser handles the download natively.
      const url = `/api/v1/admin/analytics/export?range=${range}&format=${format}`;
      const a = document.createElement("a");
      a.href = url;
      a.download = `analytics-${range}.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Export failed");
    } finally {
      setExporting(false);
    }
  }

  // ── Article click → open modal ──
  function openArticleAnalytics(articleId: string, title: string) {
    setSelectedArticleId(articleId);
    setSelectedArticleTitle(title);
  }

  // ── Render ──
  if (loading && !overview) {
    return <LoadingState label="Loading traffic analytics..." />;
  }

  // Empty state — no analytics data yet.
  if (overview && !overview.hasData && !overview.metrics) {
    return (
      <div className="space-y-6">
        <Header
          range={range}
          onRangeChange={setRange}
          onExport={handleExport}
          exporting={exporting}
        />
        <EmptyState />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Header
        range={range}
        onRangeChange={setRange}
        onExport={handleExport}
        exporting={exporting}
      />

      {/* Overview cards */}
      {overview?.metrics && (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-7">
          <MetricCard label="Total Visitors" value={overview.metrics.totalVisitors.current} metric={overview.metrics.totalVisitors} icon={<Users className="h-4 w-4" />} />
          <MetricCard label="Page Views" value={overview.metrics.totalPageViews.current} metric={overview.metrics.totalPageViews} icon={<Eye className="h-4 w-4" />} />
          <MetricCard label="Article Views" value={overview.metrics.articleViews.current} metric={overview.metrics.articleViews} icon={<FileText className="h-4 w-4" />} />
          <MetricCard label="New Visitors" value={overview.metrics.newVisitors.current} metric={overview.metrics.newVisitors} icon={<UserPlus className="h-4 w-4" />} />
          <MetricCard label="Returning" value={overview.metrics.returningVisitors.current} metric={overview.metrics.returningVisitors} icon={<UserCheck className="h-4 w-4" />} />
          <MetricCard label="Avg Engagement" value={overview.metrics.avgEngagement.current} metric={overview.metrics.avgEngagement} icon={<Clock className="h-4 w-4" />} format="decimal" />
          <MetricCard label="Traffic Growth" value={overview.metrics.totalVisitors.current} metric={{ current: overview.metrics.totalVisitors.current, previous: overview.metrics.totalVisitors.previous, growth: overview.metrics.trafficGrowth }} icon={<TrendingUp className="h-4 w-4" />} />
        </div>
      )}

      {/* PHASE 11 — Canonical ArticleView overview (separate from the
          AnalyticsEvent-based MetricCards above). Shows total / unique /
          today / yesterday / 7d / 30d from the ArticleView table — the
          same numbers users see on the public article cards. */}
      <ArticleOverviewCard data={articleOverview} loading={loading && !articleOverview} />

      {/* Sources + Over time */}
      <div className="grid gap-4 lg:grid-cols-2">
        {sources && <SourcesDonutChart sources={sources.sources} />}
        {sources && <TrafficOverTimeChart data={sources.overTime} bucket={sources.bucket} />}
      </div>

      {/* Realtime + Top referrers */}
      <div className="grid gap-4 lg:grid-cols-3">
        <RealtimeCard data={realtime} />
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Link2 className="h-4 w-4" />
              Top Referrers
            </CardTitle>
            <CardDescription>External domains that sent traffic</CardDescription>
          </CardHeader>
          <CardContent>
            {!referrers || referrers.referrers.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">
                No referrer data for this period.
              </p>
            ) : (
              <div className="space-y-2">
                {referrers.referrers.slice(0, 10).map((r) => (
                  <div key={r.domain} className="flex items-center justify-between text-sm">
                    <span className="font-mono text-xs">{r.domain}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-muted-foreground">{formatNumber(r.visits)}</span>
                      <Badge variant="secondary" className="w-16 justify-center">{r.percentage}%</Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Article traffic table */}
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Article Traffic
              </CardTitle>
              <CardDescription>Articles ranked by traffic in the selected period</CardDescription>
            </div>
            {/* PHASE 16 — Sort dropdown (Views / Unique Visitors / Growth / Recent). */}
            <SortDropdown value={sort} onChange={setSort} />
          </div>
        </CardHeader>
        <CardContent>
          {!articles || articles.articles.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              No article traffic data for this period.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-xs text-muted-foreground">
                    <th className="pb-2 pr-3 font-medium">Article</th>
                    <th className="pb-2 pr-3 font-medium text-right">Views</th>
                    <th className="pb-2 pr-3 font-medium text-right">Visitors</th>
                    <th className="pb-2 pr-3 font-medium">Top Source</th>
                    <th className="pb-2 pr-3 font-medium text-right">Growth</th>
                    <th className="pb-2 font-medium text-right">Last Visit</th>
                  </tr>
                </thead>
                <tbody>
                  {articles.articles.map((a) => (
                    <tr
                      key={a.id}
                      className="cursor-pointer border-b last:border-0 hover:bg-muted/50"
                      onClick={() => openArticleAnalytics(a.id, a.title)}
                    >
                      <td className="py-2 pr-3">
                        <div className="flex items-center gap-2">
                          <div className="min-w-0 flex-1">
                            <p className="truncate font-medium">{a.title}</p>
                            {a.author && (
                              <p className="truncate text-xs text-muted-foreground">
                                {a.author.fullName}
                              </p>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-2 pr-3 text-right font-medium">{formatNumber(a.views)}</td>
                      <td className="py-2 pr-3 text-right text-muted-foreground">{formatNumber(a.uniqueVisitors)}</td>
                      <td className="py-2 pr-3">
                        <Badge
                          variant="secondary"
                          className="gap-1"
                          style={{ backgroundColor: `${getSourceColor(a.topSource, "referral")}20`, color: getSourceColor(a.topSource, "referral") }}
                        >
                          {getSourceLabel(a.topSource)}
                        </Badge>
                      </td>
                      <td className="py-2 pr-3 text-right">
                        {a.growth === null ? (
                          <span className="text-muted-foreground">—</span>
                        ) : (
                          <span className={cn(
                            "font-medium",
                            a.growth > 0 && "text-green-600 dark:text-green-400",
                            a.growth < 0 && "text-red-600 dark:text-red-400",
                          )}>
                            {a.growth > 0 ? "+" : ""}{a.growth.toFixed(1)}%
                          </span>
                        )}
                      </td>
                      <td className="py-2 text-right text-xs text-muted-foreground">
                        {a.lastVisit ? formatRelativeTime(a.lastVisit) : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* PHASE 13 — Recent activity feed (latest article views). Sits
          between the Article Traffic table and the Devices breakdown so
          admins get a chronological view of incoming traffic. Clickable
          rows open the per-article analytics modal. */}
      <RecentActivityCard
        data={recentActivity}
        loading={false}
        onArticleClick={(id, title) => openArticleAnalytics(id, title)}
      />

      {/* Devices / Browsers / OS */}
      {devices && (
        <div className="grid gap-4 md:grid-cols-3">
          <SimpleBarChart
            title="Devices"
            description="Visitors by device type"
            data={devices.devices.map((d) => ({
              name: d.device.charAt(0).toUpperCase() + d.device.slice(1),
              visitors: d.visitors,
              percentage: d.percentage,
            }))}
            color="hsl(var(--chart-1))"
          />
          <SimpleBarChart
            title="Browsers"
            description="Visitors by browser"
            data={devices.browsers.map((b) => ({
              name: b.browser.charAt(0).toUpperCase() + b.browser.slice(1),
              visitors: b.visitors,
              percentage: b.percentage,
            }))}
            color="hsl(var(--chart-2))"
          />
          <SimpleBarChart
            title="Operating Systems"
            description="Visitors by OS"
            data={devices.operatingSystems.map((o) => ({
              name: o.os.charAt(0).toUpperCase() + o.os.slice(1),
              visitors: o.visitors,
              percentage: o.percentage,
            }))}
            color="hsl(var(--chart-3))"
          />
        </div>
      )}

      {/* Article traffic details modal */}
      <ArticleTrafficModal
        articleId={selectedArticleId}
        articleTitle={selectedArticleTitle}
        range={range}
        onClose={() => setSelectedArticleId(null)}
      />
    </div>
  );
}

// ── Header (title + range filter + export) ──────────────────────────────

function Header({
  range, onRangeChange, onExport, exporting,
}: {
  range: AnalyticsRange;
  onRangeChange: (r: AnalyticsRange) => void;
  onExport: (format: "csv" | "json") => void;
  exporting: boolean;
}) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div>
        <h2 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
          <BarChart3 className="h-6 w-6" />
          Traffic Analytics
        </h2>
        <p className="text-sm text-muted-foreground">
          Where your visitors come from + how they interact with your content.
        </p>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        {/* Range filter */}
        <div className="flex flex-wrap gap-1 rounded-md border bg-muted/40 p-1">
          {RANGE_OPTIONS.map((opt) => (
            <Button
              key={opt.value}
              size="sm"
              variant={range === opt.value ? "default" : "ghost"}
              className="h-7 px-2 text-xs"
              onClick={() => onRangeChange(opt.value)}
            >
              {opt.label}
            </Button>
          ))}
        </div>
        {/* Export */}
        <Button size="sm" variant="outline" onClick={() => onExport("csv")} disabled={exporting}>
          {exporting ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Download className="mr-1 h-4 w-4" />}
          CSV
        </Button>
        <Button size="sm" variant="outline" onClick={() => onExport("json")} disabled={exporting}>
          {exporting ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Download className="mr-1 h-4 w-4" />}
          JSON
        </Button>
      </div>
    </div>
  );
}

// ── Realtime card ───────────────────────────────────────────────────────

function RealtimeCard({ data }: { data: RealtimeData | null }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-red-500" />
          </span>
          Live Visitors
        </CardTitle>
        <CardDescription>Active in the last {data?.minutes ?? 5} minutes</CardDescription>
      </CardHeader>
      <CardContent>
        {!data ? (
          <Skeleton className="h-16 w-full" />
        ) : (
          <>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold">{data.liveVisitors}</span>
              <span className="text-sm text-muted-foreground">visitors online</span>
            </div>
            <div className="mt-4 space-y-2">
              <p className="text-xs font-medium text-muted-foreground">Currently Reading</p>
              {data.currentlyReading.length === 0 ? (
                <p className="text-xs text-muted-foreground">No articles being read right now.</p>
              ) : (
                data.currentlyReading.slice(0, 5).map((c) => (
                  <div key={c.articleId} className="flex items-center justify-between text-xs">
                    <span className="truncate pr-2">{c.title}</span>
                    <Badge variant="secondary">{c.readers}</Badge>
                  </div>
                ))
              )}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
