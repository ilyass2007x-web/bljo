"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import {
  Activity, Server, Database, Lock, Globe, MessageSquare,
  Search, Brain, TrendingUp, FileText, Mail, Cloud, Zap,
  CheckCircle, XCircle, AlertTriangle, HelpCircle, RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface HealthData {
  app: { environment: string; nodeVersion: string; platform: string; uptimeSeconds: number; memoryUsageMb: number; buildId: string; timestamp: string };
  database: { status: string; provider: string; latencyMs: number | null; ok: boolean };
  auth: { status: string; provider: string; note: string };
  api: { status: string; note: string };
  messaging: { status: string; conversations: number | null; messages: number | null; realtime: string };
  search: { status: string; totalSearches: number | null };
  algorithm: { status: string; weightsConfigured: boolean };
  trending: { status: string; note: string };
  seo: { status: string; sitemap: string; robots: string };
  resend: { status: string; provider: string; note: string };
  cloudinary: { status: string; provider: string; note: string };
  cache: { status: string; provider: string; note: string };
  jobs: { status: string; provider: string; note: string };
  responseTime: { dbLatencyMs: number | null; rating: string; apiLatencyMs: number | null; note: string };
  deployment: { platform: string; database: string; note: string };
  services: { name: string; status: string; details: string }[];
  overallHealth: string;
  lastChecked: string;
}

export function AdminSystemHealth() {
  const [data, setData] = useState<HealthData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const refreshTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetch = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true); else setLoading(true);
    try {
      const res = await api.get<{ health: HealthData }>("/api/v1/admin/system-health");
      setData(res.health);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load system health.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void fetch();
    // Auto-refresh every 60 seconds (spec §31: "reasonable interval").
    refreshTimer.current = setInterval(() => void fetch(true), 60000);
    return () => { if (refreshTimer.current) clearInterval(refreshTimer.current); };
  }, [fetch]);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[0,1,2,3].map(i => <Skeleton key={i} className="h-20 rounded-lg" />)}
        </div>
        <Skeleton className="h-64 w-full rounded-lg" />
      </div>
    );
  }

  if (!data) {
    return <Card><CardContent className="py-6 text-center text-sm text-destructive">Unable to load system health data.</CardContent></Card>;
  }

  return (
    <div className="space-y-6">
      {/* Header + Manual Refresh */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
            <Activity className="h-6 w-6" /> System Health
          </h2>
          <p className="text-sm text-muted-foreground">
            Last checked: {new Date(data.lastChecked).toLocaleTimeString()} · Auto-refreshes every 60s
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => void fetch(true)} disabled={refreshing}>
          <RefreshCw className={cn("mr-1.5 h-3.5 w-3.5", refreshing && "animate-spin")} />
          {refreshing ? "Checking…" : "Refresh Now"}
        </Button>
      </div>

      {/* Overall Health */}
      <div className="flex items-center gap-3">
        <StatusBadge status={data.overallHealth} large />
        <span className="text-sm text-muted-foreground">
          Overall platform health · {data.deployment.platform} · {data.deployment.database}
        </span>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6">
        <QuickStat label="Environment" value={data.app.environment} icon={Server} />
        <QuickStat label="Uptime" value={`${Math.floor(data.app.uptimeSeconds / 3600)}h ${Math.floor((data.app.uptimeSeconds % 3600) / 60)}m`} icon={Activity} />
        <QuickStat label="Memory" value={`${data.app.memoryUsageMb} MB`} icon={Server} />
        <QuickStat label="DB Latency" value={data.responseTime.dbLatencyMs != null ? `${data.responseTime.dbLatencyMs}ms` : "?"} icon={Database} rating={data.responseTime.rating} />
        <QuickStat label="Node Version" value={data.app.nodeVersion} icon={Server} />
        <QuickStat label="Build" value={data.app.buildId} icon={Server} />
      </div>

      {/* Service Status Grid (spec §1, §2) */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold">Service Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1.5">
            {data.services.map(svc => (
              <div key={svc.name} className="flex items-center justify-between rounded-lg border px-3 py-2">
                <div className="flex items-center gap-2">
                  <ServiceIcon name={svc.name} />
                  <div>
                    <p className="text-sm font-medium">{svc.name}</p>
                    <p className="text-[10px] text-muted-foreground">{svc.details}</p>
                  </div>
                </div>
                <StatusBadge status={svc.status} />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Response Time (spec §7) */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold"><Zap className="h-4 w-4" /> Response Time</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <MetricBox label="DB Latency" value={data.responseTime.dbLatencyMs != null ? `${data.responseTime.dbLatencyMs}ms` : "Not measured"} />
            <MetricBox label="DB Rating" value={data.responseTime.rating} rating={data.responseTime.rating} />
            <MetricBox label="API Latency" value="Not tracked" />
            <MetricBox label="Search Latency" value="Not tracked" />
          </div>
          <p className="mt-2 text-[10px] text-muted-foreground">{data.responseTime.note}</p>
        </CardContent>
      </Card>

      {/* Deployment Info (spec §34, §35) */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold"><Cloud className="h-4 w-4" /> Deployment</CardTitle>
        </CardHeader>
        <CardContent className="space-y-1 text-sm">
          <div className="flex justify-between"><span className="text-muted-foreground">Platform</span><span className="font-medium">{data.deployment.platform}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Database</span><span className="font-medium">{data.deployment.database}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Serverless Compatible</span><CheckCircle className="h-4 w-4 text-green-500" /></div>
          <p className="mt-1 text-[10px] text-muted-foreground">{data.deployment.note}</p>
        </CardContent>
      </Card>

      {/* Performance Architecture Summary (spec §37) */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold"><Activity className="h-4 w-4" /> Performance Architecture</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-xs text-muted-foreground">
          <div>
            <span className="font-medium text-foreground">Feed: </span>
            30s weight cache, 3× pool size, O(n) in-memory scoring, cursor pagination, exploration ratio, diversity penalty. No N+1.
          </div>
          <div>
            <span className="font-medium text-foreground">Admin APIs: </span>
            30s cache on all dashboards (analytics, trending, SEO, system health). count/groupBy aggregation (no findMany-then-count). All queries parallel via Promise.all.
          </div>
          <div>
            <span className="font-medium text-foreground">Search: </span>
            Case-insensitive ILIKE, 300ms debounced suggestions, AbortController stale-request cancellation, rate-limited.
          </div>
          <div>
            <span className="font-medium text-foreground">Caching: </span>
            In-memory per-process (switch to Redis for multi-instance). Settings 30s, dashboard 30s, ranking weights 30s.
          </div>
          <div>
            <span className="font-medium text-foreground">Images: </span>
            Lazy loading on all avatars + article covers. aspect-ratio 1/1 + object-cover. No next/image (plain {"<img>"} for external URLs).
          </div>
          <div>
            <span className="font-medium text-foreground">Frontend: </span>
            Optimistic UI on Like/Follow/Message. Key-based remount for URL-driven views. Polling with visibility checks (15s messages, 60s notifications).
          </div>
          <div>
            <span className="font-medium text-foreground">N+1 Protection: </span>
            All list endpoints use _count aggregation (LEFT JOIN + COUNT(*)). Batch queries for isLiked/isFollowing. No per-item queries.
          </div>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <p className="text-center text-[10px] text-muted-foreground">
        Health checks use real service pings. "Not monitored" means no reliable health check exists (spec §2). Performance targets are guidelines — measure actual deployment for real numbers.
      </p>
    </div>
  );
}

function StatusBadge({ status, large }: { status: string; large?: boolean }) {
  const config: Record<string, { icon: React.ComponentType<{ className?: string }>; color: string; label: string }> = {
    healthy: { icon: CheckCircle, color: "text-green-600 dark:text-green-400", label: "Healthy" },
    degraded: { icon: AlertTriangle, color: "text-amber-600 dark:text-amber-400", label: "Degraded" },
    unavailable: { icon: XCircle, color: "text-destructive", label: "Unavailable" },
    not_monitored: { icon: HelpCircle, color: "text-muted-foreground", label: "Not Monitored" },
    unknown: { icon: HelpCircle, color: "text-muted-foreground", label: "Unknown" },
  };
  const c = config[status] ?? config.unknown;
  const Icon = c.icon;
  return (
    <span className={cn("flex items-center gap-1", large ? "text-base font-bold" : "text-xs font-medium", c.color)}>
      <Icon className={large ? "h-5 w-5" : "h-3.5 w-3.5"} />
      {c.label}
    </span>
  );
}

function QuickStat({ label, value, icon: Icon, rating }: { label: string; value: string; icon: React.ComponentType<{ className?: string }>; rating?: string }) {
  const color = rating === "excellent" ? "text-green-500" : rating === "good" ? "text-blue-500" : rating === "slow" ? "text-amber-500" : rating === "critical" ? "text-destructive" : "text-muted-foreground";
  return (
    <Card>
      <CardContent className="p-2.5">
        <div className="flex items-center gap-2">
          <Icon className={cn("h-3.5 w-3.5", color)} />
          <div>
            <p className="text-sm font-bold">{value}</p>
            <p className="text-[10px] text-muted-foreground">{label}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function MetricBox({ label, value, rating }: { label: string; value: string; rating?: string }) {
  const color = rating === "excellent" ? "text-green-600 dark:text-green-400" : rating === "good" ? "text-blue-600 dark:text-blue-400" : rating === "slow" ? "text-amber-600 dark:text-amber-400" : rating === "critical" ? "text-destructive" : "text-muted-foreground";
  return (
    <div className="rounded-lg border p-2 text-center">
      <p className={cn("text-sm font-bold", color)}>{value}</p>
      <p className="text-[10px] text-muted-foreground">{label}</p>
    </div>
  );
}

function ServiceIcon({ name }: { name: string }) {
  const icons: Record<string, React.ComponentType<{ className?: string }>> = {
    Application: Server, Database, Authentication: Lock, API: Globe,
    Messaging: MessageSquare, Search, Algorithm: Brain, Trending: TrendingUp,
    SEO: FileText, "Resend (Email)": Mail, "Cloudinary (Storage)": Cloud,
    Cache: Zap, Jobs: Activity,
  };
  const Icon = icons[name] ?? Activity;
  return <Icon className="h-4 w-4 text-muted-foreground" />;
}
