"use client";

import { useEffect, useState, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { api, ApiClientError } from "@/lib/client/api";
import { formatDateTime, formatRelativeTime } from "@/lib/client/format";
import { toast } from "sonner";
import { ChevronLeft, ChevronRight, Search, ScrollText, Shield } from "lucide-react";
import { cn } from "@/lib/utils";

interface LogEntry {
  id: string;
  adminId: string;
  admin: { id: string; fullName: string; email: string; role: string };
  action: string;
  targetType: string | null;
  targetId: string | null;
  metadata: Record<string, unknown> | null;
  ipAddress: string | null;
  userAgent: string | null;
  createdAt: string;
}

export function AdminAudit() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(50);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [inputQ, setInputQ] = useState("");
  const [action, setAction] = useState("");
  const [targetType, setTargetType] = useState("");
  const [sortBy, setSortBy] = useState("newest");

  useEffect(() => {
    const t = setTimeout(() => { setQ(inputQ); setPage(1); }, 300);
    return () => clearTimeout(t);
  }, [inputQ]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), pageSize: String(pageSize), sortBy });
      if (q) params.set("q", q);
      if (action) params.set("action", action);
      if (targetType) params.set("targetType", targetType);
      const data = await api.get<{ logs: LogEntry[]; pagination: { total: number } }>(`/api/v1/admin/audit?${params}`);
      setLogs(data.logs);
      setTotal(data.pagination.total);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load audit logs.");
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, q, action, targetType, sortBy]);

  useEffect(() => { void load(); }, [load]);

  const totalPages = Math.ceil(total / pageSize);

  const actionOptions = [
    "", "admin.dashboard.view", "admin.users.list", "admin.user.view",
    "admin.user.suspend", "admin.user.ban", "admin.user.unsuspend", "admin.user.unban",
    "admin.user.verify", "admin.user.unverify", "admin.user.set_role", "admin.user.delete",
    "admin.content.list", "admin.content.view", "admin.content.delete",
    "admin.report.view", "admin.report.update", "admin.report.resolve", "admin.report.reject",
    "admin.report.review", "admin.report.suspend_user", "admin.report.ban_user",
    "admin.algorithm.update", "admin.algorithm.rollback", "admin.audit.search",
  ];

  const targetTypeOptions = ["", "user", "post", "article", "report", "conversation"];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
          <ScrollText className="h-6 w-6" /> Audit Logs
        </h2>
        <p className="text-sm text-muted-foreground">
          {total.toLocaleString()} total records. Append-only — logs cannot be modified or deleted (spec §33).
        </p>
      </div>

      {/* Search + Filters */}
      <Card className="p-4">
        <div className="flex flex-wrap gap-2">
          <div className="relative min-w-48 flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search action, admin, target ID…" value={inputQ} onChange={(e) => setInputQ(e.target.value)} className="pl-8" />
          </div>
          <Select value={action || "all"} onValueChange={(v) => { setAction(v === "all" ? "" : v); setPage(1); }}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Action" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All actions</SelectItem>
              {actionOptions.filter(Boolean).map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={targetType || "all"} onValueChange={(v) => { setTargetType(v === "all" ? "" : v); setPage(1); }}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Target" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {targetTypeOptions.filter(Boolean).map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={(v) => { setSortBy(v); setPage(1); }}>
            <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="oldest">Oldest</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Audit log list */}
      <Card>
        {loading ? (
          <div className="space-y-2 p-4">
            {[0,1,2,3,4,5].map(i => <Skeleton key={i} className="h-16 w-full rounded-lg" />)}
          </div>
        ) : logs.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
            <ScrollText className="h-10 w-10 text-muted-foreground/50" />
            <p className="text-sm font-medium">No audit logs found.</p>
            <p className="max-w-sm text-xs text-muted-foreground">Try adjusting your search or filters.</p>
          </div>
        ) : (
          <div className="divide-y divide-border/60">
            {logs.map((log) => (
              <div key={log.id} className="p-4 hover:bg-accent/30">
                {/* Top row: action + admin + timestamp */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] font-mono">{log.action}</Badge>
                    {log.targetType && <Badge variant="secondary" className="text-[10px]">{log.targetType}</Badge>}
                  </div>
                  <span className="shrink-0 text-xs text-muted-foreground">{formatRelativeTime(log.createdAt)}</span>
                </div>
                {/* Admin info */}
                <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                  <Shield className="h-3 w-3" />
                  <span className="font-medium text-foreground">{log.admin.fullName}</span>
                  <span>({log.admin.role})</span>
                  <span>·</span>
                  <span>{log.admin.email}</span>
                </div>
                {/* Target + metadata */}
                {(log.targetId || log.metadata) && (
                  <div className="mt-1.5 flex flex-wrap gap-2 text-[10px] text-muted-foreground">
                    {log.targetId && <span className="rounded bg-muted px-1.5 py-0.5">target: {log.targetId.slice(0, 12)}{log.targetId.length > 12 ? "…" : ""}</span>}
                    {log.ipAddress && <span className="rounded bg-muted px-1.5 py-0.5">IP: {log.ipAddress}</span>}
                    {log.metadata && Object.keys(log.metadata).length > 0 && (
                      <span className="rounded bg-muted px-1.5 py-0.5">
                        {Object.entries(log.metadata).slice(0, 3).map(([k, v]) => `${k}: ${typeof v === "string" ? v.slice(0, 30) : String(v)}`).join(" · ")}
                      </span>
                    )}
                  </div>
                )}
                {/* Full timestamp */}
                <p className="mt-1 text-[10px] text-muted-foreground">{formatDateTime(log.createdAt)}</p>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t p-3">
            <p className="text-xs text-muted-foreground">Page {page} of {totalPages} · {total.toLocaleString()} logs</p>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
