"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import { Database, Activity, Lock, RefreshCw } from "lucide-react";

interface DbInfo {
  provider: string;
  connected: boolean;
  latencyMs: number;
  error: string | null;
  urlHint: string;
  tables: { users: number; messages: number };
  migrations: { applied: number; method: string };
}

export function AdminDatabase() {
  const [info, setInfo] = useState<DbInfo | null>(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const data = await api.get<{ database: DbInfo }>("/api/v1/admin/database");
      setInfo(data.database);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load database info");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Database</h2>
        <p className="text-sm text-muted-foreground">Connection status and health.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Database className="h-4 w-4" /> Connection</CardTitle>
          <CardDescription>Current database provider and connectivity.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {loading || !info ? (
            <p className="py-4 text-center text-sm text-muted-foreground">Loading…</p>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground">Provider</p>
                  <p className="font-medium capitalize">{info.provider}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Status</p>
                  <Badge variant={info.connected ? "default" : "destructive"}>{info.connected ? "Connected" : "Disconnected"}</Badge>
                </div>
                <div>
                  <p className="text-muted-foreground">Latency</p>
                  <p className="font-medium">{info.latencyMs}ms</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Migrations</p>
                  <p className="font-medium">{info.migrations.applied} ({info.migrations.method})</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Users</p>
                  <p className="font-medium">{info.tables.users}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Messages</p>
                  <p className="font-medium">{info.tables.messages}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 border-t pt-3">
                <Button size="sm" variant="outline" onClick={() => load()}>
                  <RefreshCw className="mr-1 h-3 w-3" /> Test connection
                </Button>
                <Badge variant="outline"><Activity className="mr-1 h-3 w-3" /> {info.urlHint}</Badge>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <Card className="border-blue-500/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><Lock className="h-4 w-4" /> Portability</CardTitle>
          <CardDescription>The application is database-agnostic via Prisma.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>Current provider: <strong className="text-foreground capitalize">{info?.provider ?? "—"}</strong></p>
          <p>To switch providers (e.g. from SQLite dev to PostgreSQL production), update <code className="rounded bg-muted px-1">DATABASE_URL</code> and the Prisma datasource provider, then run migrations.</p>
          <p>No application code changes are required — all data access goes through <code className="rounded bg-muted px-1">lib/database</code>.</p>
          <p className="border-t pt-2"><strong className="text-foreground">Credentials are never exposed.</strong> The connection string is configured via environment variables only.</p>
        </CardContent>
      </Card>
    </div>
  );
}
