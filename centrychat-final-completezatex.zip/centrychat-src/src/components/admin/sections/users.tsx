"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Skeleton } from "@/components/ui/skeleton";
import { api, ApiClientError } from "@/lib/client/api";
import { formatDateTime, formatNumber, formatRelativeTime } from "@/lib/client/format";
import { toast } from "sonner";
import {
  Search, ChevronLeft, ChevronRight, ShieldBan, UserCheck, ShieldCheck,
  Trash2, MailCheck, BadgeCheck, Loader2, Users as UsersIcon, TrendingUp,
  Filter, ArrowUpDown, Activity, Eye, Heart, MessageCircle, Share2,
  FileText, UserPlus, X,
} from "lucide-react";
import { useAuthStore, isSuperAdmin } from "@/lib/client/auth-store";
import { cn } from "@/lib/utils";

// ── Types ──────────────────────────────────────────────────────────────────

interface AdminUser {
  id: string;
  fullName: string;
  email: string;
  username: string;
  emailVerified: string | null;
  role: string;
  status: string;
  isVerified: boolean;
  lastSeenAt: string;
  createdAt: string;
  twoFactorEnabled: boolean;
  avatarColor: string | null;
  avatarUrl: string | null;
  bio: string | null;
  _count: {
    followers: number;
    following: number;
    posts: number;
    articles: number;
  };
}

interface UserDetail {
  user: {
    id: string;
    fullName: string;
    email: string;
    username: string;
    role: string;
    status: string;
    isVerified: boolean;
    emailVerified: string | null;
    lastSeenAt: string;
    createdAt: string;
    twoFactorEnabled: boolean;
    bio: string | null;
    avatarColor: string | null;
    avatarUrl: string | null;
    language: string;
    stats: {
      posts: number;
      publishedArticles: number;
      draftArticles: number;
      followers: number;
      following: number;
      likesReceived: number;
      commentsReceived: number;
      viewsReceived: number;
      sharesReceived: number;
      engagementRate: number;
    };
    recentPosts: { id: string; content: string; createdAt: string; likeCount: number; commentCount: number; viewCount: number }[];
    recentArticles: { id: string; title: string; excerpt: string | null; coverImage: string | null; publishedAt: string | null; readingTime: number; likeCount: number; commentCount: number; viewCount: number }[];
  };
  sessions: { id: string; ipAddress: string | null; userAgent: string | null; createdAt: string; lastActiveAt: string }[];
  reports: { id: string; reason: string; status: string; createdAt: string }[];
}

type SortBy = "createdAt" | "fullName" | "lastSeenAt" | "followers" | "following" | "posts" | "articles";
type FilterType = "" | "verified" | "new" | "inactive" | "admins" | "super_admins" | "normal";

// ── Component ──────────────────────────────────────────────────────────────

export function AdminUsers() {
  const router = useRouter();
  const { user: me } = useAuthStore();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [q, setQ] = useState("");
  const [inputQ, setInputQ] = useState("");
  const [role, setRole] = useState("");
  const [status, setStatus] = useState("");
  const [filter, setFilter] = useState<FilterType>("");
  const [sortBy, setSortBy] = useState<SortBy>("createdAt");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [detail, setDetail] = useState<UserDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailTab, setDetailTab] = useState<"overview" | "posts" | "articles">("overview");
  const [actionDialog, setActionDialog] = useState<{ userId: string; action: string; userName: string } | null>(null);
  const [actionReason, setActionReason] = useState("");
  const [actionLoading, setActionLoading] = useState(false);
  const [bulkDialog, setBulkDialog] = useState<{ action: string } | null>(null);
  const [bulkLoading, setBulkLoading] = useState(false);
  // Separate dialog + state for the bulk verify/unverify action (spec §5, §6).
  // The bulk-verify API endpoint has a DIFFERENT response shape than bulk-action
  // (it returns `requested` / `updated` / `skipped` / `skippedReasons` with
  // `notFound` / `insufficientRank` / `alreadySet`), so it gets its own dialog
  // state + handler. Using a single shared dialog would conflate the two response
  // shapes and produce confusing toasts.
  const [bulkVerifyDialog, setBulkVerifyDialog] = useState<{ verified: boolean } | null>(null);
  const [bulkVerifyLoading, setBulkVerifyLoading] = useState(false);

  // ── Debounced search (spec §2) ─────────────────────────────────────
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setQ(inputQ);
      setPage(1);
    }, 300); // 300ms debounce
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [inputQ]);

  // ── Load users ────────────────────────────────────────────────────
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: String(page), pageSize: String(pageSize),
        sortBy, sortDir,
      });
      if (q) params.set("q", q);
      if (role) params.set("role", role);
      if (status) params.set("status", status);
      if (filter) params.set("filter", filter);
      const data = await api.get<{ users: AdminUser[]; pagination: { total: number } }>(`/api/v1/admin/users?${params}`);
      setUsers(data.users);
      setTotal(data.pagination.total);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load users. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, q, role, status, filter, sortBy, sortDir]);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => { setSelectedIds(new Set()); }, [page, role, status, filter, q, sortBy, sortDir]);

  // ── Toggle selection ───────────────────────────────────────────────
  function toggleUser(id: string, checked: boolean) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id); else next.delete(id);
      return next;
    });
  }
  function toggleSelectAll(checked: boolean) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (checked) { for (const u of users) next.add(u.id); }
      else { for (const u of users) next.delete(u.id); }
      return next;
    });
  }

  // ── View user detail ──────────────────────────────────────────────
  async function viewUser(u: AdminUser) {
    setSelectedUser(u);
    setDetail(null);
    setDetailTab("overview");
    setDetailLoading(true);
    try {
      const data = await api.get<UserDetail>(`/api/v1/admin/users/${u.id}`);
      setDetail(data);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load user details");
    } finally {
      setDetailLoading(false);
    }
  }

  // ── Single user action ────────────────────────────────────────────
  async function performAction() {
    if (!actionDialog) return;
    setActionLoading(true);
    try {
      const { userId, action } = actionDialog;
      if (action === "VERIFY" || action === "UNVERIFY") {
        await api.post(`/api/v1/admin/users/${userId}/verify`, { verified: action === "VERIFY" });
      } else {
        await api.post(`/api/v1/admin/users/${userId}/action`, { action, reason: actionReason || undefined });
      }
      toast.success(`Action "${action}" applied`);
      setActionDialog(null);
      setActionReason("");
      await load();
      if (selectedUser?.id === userId) {
        setSelectedUser(null);
        setDetail(null);
      }
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Action failed");
    } finally {
      setActionLoading(false);
    }
  }

  // ── Bulk action ───────────────────────────────────────────────────
  async function performBulkAction() {
    if (!bulkDialog || selectedIds.size === 0) return;
    setBulkLoading(true);
    try {
      const data = await api.post<{
        requested: number; updated: number; skipped: number;
        skippedReasons: { notFound: number; insufficientRank: number; alreadySet: number };
        selfExcluded: number;
      }>("/api/v1/admin/users/bulk-action", {
        userIds: [...selectedIds],
        action: bulkDialog.action,
      });
      if (data.updated === data.requested) {
        toast.success(`Successfully ${bulkDialog.action.toLowerCase()}d ${data.updated} user(s).`);
      } else {
        const parts = [`Updated: ${data.updated}`];
        if (data.skippedReasons.alreadySet) parts.push(`Already set: ${data.skippedReasons.alreadySet}`);
        if (data.skippedReasons.insufficientRank) parts.push(`Permission denied: ${data.skippedReasons.insufficientRank}`);
        toast.success(`${bulkDialog.action} — ${parts.join(" · ")}`);
      }
      setSelectedIds(new Set());
      setBulkDialog(null);
      await load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Bulk action failed");
    } finally {
      setBulkLoading(false);
    }
  }

  // ── Bulk verify / unverify (spec §5, §6, §7) ─────────────────────
  // Calls the EXISTING /api/v1/admin/users/bulk-verify endpoint. The
  // endpoint enforces server-side authorization (requireAdmin) + the
  // rank guardrail (an ADMIN cannot verify a SUPER_ADMIN). The frontend
  // is just a thin shell — every security check happens server-side.
  //
  // The endpoint response includes a `skippedReasons` breakdown so we can
  // surface partial-failure info to the admin (spec §14 — never claim
  // "success" when some failed).
  async function performBulkVerify() {
    if (!bulkVerifyDialog || selectedIds.size === 0) return;
    setBulkVerifyLoading(true);
    try {
      const data = await api.post<{
        requested: number;
        updated: number;
        skipped: number;
        skippedReasons: {
          notFound: number;
          insufficientRank: number;
          alreadySet: number;
        };
      }>("/api/v1/admin/users/bulk-verify", {
        userIds: [...selectedIds],
        verified: bulkVerifyDialog.verified,
      });
      const actionLabel = bulkVerifyDialog.verified ? "verified" : "unverified";
      if (data.updated === data.requested) {
        toast.success(`Successfully ${actionLabel} ${data.updated} user(s).`);
      } else {
        // Spec §14 — surface the partial-failure breakdown so the admin
        // sees the truth. Never claim "success" when some failed.
        const parts = [`Updated: ${data.updated}`];
        if (data.skippedReasons.alreadySet) {
          parts.push(`Already ${actionLabel}: ${data.skippedReasons.alreadySet}`);
        }
        if (data.skippedReasons.insufficientRank) {
          parts.push(`Permission denied: ${data.skippedReasons.insufficientRank}`);
        }
        if (data.skippedReasons.notFound) {
          parts.push(`Not found: ${data.skippedReasons.notFound}`);
        }
        toast.success(`${bulkVerifyDialog.verified ? "Verify" : "Unverify"} — ${parts.join(" · ")}`);
      }
      setSelectedIds(new Set());
      setBulkVerifyDialog(null);
      await load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Bulk verify failed");
    } finally {
      setBulkVerifyLoading(false);
    }
  }

  // ── Permission helpers ────────────────────────────────────────────
  const canModify = (u: AdminUser) => !!me && (isSuperAdmin(me) || u.role === "USER" || u.role === "MODERATOR");
  const totalPages = Math.ceil(total / pageSize);

  const sortOptions: { value: SortBy; label: string }[] = [
    { value: "createdAt", label: "Newest" },
    { value: "createdAt", label: "Oldest" },
    { value: "followers", label: "Most Followers" },
    { value: "following", label: "Most Following" },
    { value: "posts", label: "Most Posts" },
    { value: "articles", label: "Most Articles" },
    { value: "lastSeenAt", label: "Most Active" },
    { value: "fullName", label: "Name (A-Z)" },
  ];

  const filterOptions: { value: FilterType; label: string }[] = [
    { value: "", label: "All Users" },
    { value: "verified", label: "Verified" },
    { value: "new", label: "New (7 days)" },
    { value: "inactive", label: "Inactive (7 days)" },
    { value: "admins", label: "Admins" },
    { value: "super_admins", label: "Super Admins" },
    { value: "normal", label: "Normal Users" },
  ];

  return (
    <div className="space-y-6">
      {/* ── Header ─────────────────────────────────────────────────── */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">User Management</h2>
        <p className="text-sm text-muted-foreground">{total.toLocaleString()} total users</p>
      </div>

      {/* ── Search + Filters + Sort ────────────────────────────────── */}
      <Card className="p-4">
        <div className="flex flex-wrap gap-2">
          {/* Search (spec §2) */}
          <div className="relative min-w-48 flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search name, email, or username…"
              value={inputQ}
              onChange={(e) => setInputQ(e.target.value)}
              className="pl-8"
            />
          </div>
          {/* Role filter */}
          <Select value={role || "all"} onValueChange={(v) => { setRole(v === "all" ? "" : v); setPage(1); }}>
            <SelectTrigger className="w-32"><SelectValue placeholder="Role" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All roles</SelectItem>
              <SelectItem value="USER">User</SelectItem>
              <SelectItem value="MODERATOR">Moderator</SelectItem>
              <SelectItem value="ADMIN">Admin</SelectItem>
              <SelectItem value="SUPER_ADMIN">Super Admin</SelectItem>
            </SelectContent>
          </Select>
          {/* Status filter */}
          <Select value={status || "all"} onValueChange={(v) => { setStatus(v === "all" ? "" : v); setPage(1); }}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="ACTIVE">Active</SelectItem>
              <SelectItem value="SUSPENDED">Suspended</SelectItem>
              <SelectItem value="BANNED">Banned</SelectItem>
              <SelectItem value="PENDING_VERIFICATION">Pending</SelectItem>
            </SelectContent>
          </Select>
          {/* Extended filter (spec §4) */}
          <Select value={filter || "all"} onValueChange={(v) => { setFilter(v === "all" ? "" : v as FilterType); setPage(1); }}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Filter" /></SelectTrigger>
            <SelectContent>
              {filterOptions.map((f) => (
                <SelectItem key={f.value || "all"} value={f.value || "all"}>{f.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {/* Sort (spec §5) */}
          <Select value={sortBy} onValueChange={(v) => { setSortBy(v as SortBy); setPage(1); }}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Sort by" /></SelectTrigger>
            <SelectContent>
              {sortOptions.map((s, i) => (
                <SelectItem key={`${s.value}-${i}`} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {/* Sort direction */}
          <Button variant="outline" size="icon" onClick={() => setSortDir(sortDir === "asc" ? "desc" : "asc")} title={sortDir === "asc" ? "Ascending" : "Descending"}>
            <ArrowUpDown className="h-4 w-4" />
          </Button>
        </div>
      </Card>

      {/* ── Bulk action bar (spec §23) ─────────────────────────────── */}
      {selectedIds.size > 0 && (
        <Card className="sticky top-2 z-20 border-primary/40 bg-primary/5 p-3 shadow-md">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm font-medium">
              {selectedIds.size} user(s) selected <span className="ml-1 text-xs text-muted-foreground">(on this page)</span>
            </p>
            <div className="flex flex-wrap gap-2">
              {/* Verify / Unverify buttons (spec §3, §5, §6).
                  These call the EXISTING /api/v1/admin/users/bulk-verify
                  endpoint. Server-side requireAdmin() + rank guardrails
                  enforce all permissions — the frontend is just a shell. */}
              <Button
                size="sm"
                variant="outline"
                disabled={bulkLoading || bulkVerifyLoading}
                onClick={() => setBulkVerifyDialog({ verified: true })}
                title="Give the verification badge to the selected users"
              >
                <BadgeCheck className="mr-1 h-3.5 w-3.5" /> Verify
              </Button>
              <Button
                size="sm"
                variant="outline"
                disabled={bulkLoading || bulkVerifyLoading}
                onClick={() => setBulkVerifyDialog({ verified: false })}
                title="Remove the verification badge from the selected users"
              >
                <X className="mr-1 h-3.5 w-3.5" /> Remove Verification
              </Button>
              {/* Separator between verify actions + status actions — purely visual. */}
              <span className="hidden sm:mx-1 sm:inline-block sm:h-6 sm:w-px sm:bg-border" aria-hidden />
              <Button size="sm" variant="outline" disabled={bulkLoading || bulkVerifyLoading} onClick={() => setBulkDialog({ action: "SUSPEND" })}>
                <ShieldBan className="mr-1 h-3.5 w-3.5" /> Suspend
              </Button>
              <Button size="sm" variant="destructive" disabled={bulkLoading || bulkVerifyLoading} onClick={() => setBulkDialog({ action: "BAN" })}>
                <ShieldBan className="mr-1 h-3.5 w-3.5" /> Ban
              </Button>
              <Button size="sm" variant="outline" disabled={bulkLoading || bulkVerifyLoading} onClick={() => setBulkDialog({ action: "UNSUSPEND" })}>
                <UserCheck className="mr-1 h-3.5 w-3.5" /> Activate
              </Button>
              <Button size="sm" variant="ghost" disabled={bulkLoading || bulkVerifyLoading} onClick={() => setSelectedIds(new Set())}>Clear</Button>
            </div>
          </div>
        </Card>
      )}

      {/* ── User table (desktop) / cards (mobile) (spec §27) ──────── */}
      <Card>
        {loading ? (
          <div className="space-y-2 p-4">
            {[0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-14 w-full rounded-lg" />)}
          </div>
        ) : users.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
            <UsersIcon className="h-10 w-10 text-muted-foreground/50" />
            <p className="text-sm font-medium">No users found.</p>
            <p className="max-w-sm text-xs text-muted-foreground">Try adjusting your search or filters.</p>
          </div>
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden overflow-x-auto md:block">
              <table className="w-full text-sm">
                <thead className="border-b bg-muted/50">
                  <tr>
                    <th className="w-10 px-4 py-3 text-left font-medium">
                      <Checkbox
                        checked={users.length > 0 && users.every((u) => selectedIds.has(u.id))}
                        onCheckedChange={(c) => toggleSelectAll(c === true)}
                        aria-label="Select all on this page"
                      />
                    </th>
                    <th className="px-4 py-3 text-left font-medium">User</th>
                    <th className="px-4 py-3 text-left font-medium">Role</th>
                    <th className="px-4 py-3 text-left font-medium">Status</th>
                    <th className="px-4 py-3 text-center font-medium">Followers</th>
                    <th className="px-4 py-3 text-center font-medium">Posts</th>
                    <th className="px-4 py-3 text-center font-medium">Articles</th>
                    <th className="px-4 py-3 text-left font-medium">Last seen</th>
                    <th className="px-4 py-3 text-left font-medium">Joined</th>
                    <th className="px-4 py-3 text-right font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u.id} className={selectedIds.has(u.id) ? "border-b bg-primary/5" : "border-b hover:bg-muted/30"}>
                      <td className="px-4 py-3">
                        <Checkbox checked={selectedIds.has(u.id)} onCheckedChange={(c) => toggleUser(u.id, c === true)} aria-label={`Select ${u.fullName}`} />
                      </td>
                      <td className="px-4 py-3">
                        <button onClick={() => viewUser(u)} className="flex items-center gap-2 text-left hover:underline">
                          <Avatar name={u.fullName} color={u.avatarColor} src={u.avatarUrl} size="sm" />
                          <div>
                            <p className="flex items-center gap-1 font-medium">
                              {u.fullName}
                              {u.isVerified && <BadgeCheck className="h-3.5 w-3.5 text-blue-500" />}
                            </p>
                            <p className="text-xs text-muted-foreground">@{u.username}</p>
                          </div>
                        </button>
                      </td>
                      <td className="px-4 py-3"><Badge variant="outline">{u.role}</Badge></td>
                      <td className="px-4 py-3">
                        <Badge variant={u.status === "ACTIVE" ? "default" : u.status === "BANNED" ? "destructive" : "secondary"}>
                          {u.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-center tabular-nums">{formatNumber(u._count.followers)}</td>
                      <td className="px-4 py-3 text-center tabular-nums">{formatNumber(u._count.posts)}</td>
                      <td className="px-4 py-3 text-center tabular-nums">{formatNumber(u._count.articles)}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{formatRelativeTime(u.lastSeenAt)}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{formatRelativeTime(u.createdAt)}</td>
                      <td className="px-4 py-3 text-right">
                        <Button size="sm" variant="ghost" onClick={() => viewUser(u)}>View</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile cards (spec §27) */}
            <div className="space-y-2 p-2 md:hidden">
              {users.map((u) => (
                <div key={u.id} className={cn("rounded-lg border p-3", selectedIds.has(u.id) && "border-primary bg-primary/5")}>
                  <div className="flex items-start gap-2">
                    <Checkbox checked={selectedIds.has(u.id)} onCheckedChange={(c) => toggleUser(u.id, c === true)} aria-label={`Select ${u.fullName}`} />
                    <button onClick={() => viewUser(u)} className="flex min-w-0 flex-1 items-center gap-2 text-left">
                      <Avatar name={u.fullName} color={u.avatarColor} src={u.avatarUrl} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-1 truncate font-medium">
                          {u.fullName}
                          {u.isVerified && <BadgeCheck className="h-3.5 w-3.5 text-blue-500" />}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">@{u.username}</p>
                      </div>
                    </button>
                    <Button size="sm" variant="ghost" onClick={() => viewUser(u)}>View</Button>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2 text-xs">
                    <Badge variant="outline">{u.role}</Badge>
                    <Badge variant={u.status === "ACTIVE" ? "default" : u.status === "BANNED" ? "destructive" : "secondary"}>{u.status}</Badge>
                    <span className="text-muted-foreground">👥 {formatNumber(u._count.followers)}</span>
                    <span className="text-muted-foreground">📝 {formatNumber(u._count.posts)}</span>
                    <span className="text-muted-foreground">📖 {formatNumber(u._count.articles)}</span>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t p-3">
            <p className="text-xs text-muted-foreground">Page {page} of {totalPages} · {total.toLocaleString()} users</p>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* ── Bulk verify / unverify confirmation (spec §5, §6, §18) ──── */}
      <AlertDialog
        open={bulkVerifyDialog !== null}
        onOpenChange={(o) => !o && !bulkVerifyLoading && setBulkVerifyDialog(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {bulkVerifyDialog?.verified
                ? `Verify ${selectedIds.size} user(s)?`
                : `Remove verification from ${selectedIds.size} user(s)?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {bulkVerifyDialog?.verified
                ? "The verification badge will be added to the selected users. This action is recorded in the audit log."
                : "The verification badge will be removed from the selected users. This action is recorded in the audit log."}
              {" "}
              Users that already have the requested state will be skipped (no-op).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={bulkVerifyLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={bulkVerifyLoading}
              onClick={(e) => {
                e.preventDefault();
                void performBulkVerify();
              }}
            >
              {bulkVerifyLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {bulkVerifyDialog?.verified ? "Verify" : "Remove Verification"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── Bulk action confirmation (spec §23) ─────────────────────── */}
      <AlertDialog open={bulkDialog !== null} onOpenChange={(o) => !o && !bulkLoading && setBulkDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {bulkDialog?.action === "SUSPEND" ? "Suspend selected users?" :
               bulkDialog?.action === "BAN" ? "Ban selected users?" :
               "Activate selected users?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {bulkDialog?.action === "BAN"
                ? "These accounts will no longer be able to access the platform. This action is recorded in the audit log."
                : `This will affect ${selectedIds.size} user(s). This action is recorded in the audit log.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={bulkLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={bulkLoading}
              onClick={(e) => { e.preventDefault(); void performBulkAction(); }}
              className={cn(bulkDialog?.action === "BAN" && "bg-destructive text-destructive-foreground hover:bg-destructive/90")}
            >
              {bulkLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── Single action confirmation with reason (spec §9, §10) ───── */}
      <AlertDialog open={actionDialog !== null} onOpenChange={(o) => !o && !actionLoading && (setActionDialog(null), setActionReason(""))}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {actionDialog?.action === "SUSPEND" ? `Suspend @${actionDialog?.userName}?` :
               actionDialog?.action === "BAN" ? `Ban @${actionDialog?.userName}?` :
               actionDialog?.action === "DELETE" ? `Delete @${actionDialog?.userName}?` :
               `Perform "${actionDialog?.action}" on @${actionDialog?.userName}?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {actionDialog?.action === "BAN"
                ? "This account will no longer be able to access the platform."
                : actionDialog?.action === "DELETE"
                ? "This will permanently delete the account and all associated content. This cannot be undone."
                : "This action is recorded in the audit log."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {(actionDialog?.action === "SUSPEND" || actionDialog?.action === "BAN") && (
            <div className="space-y-2 py-2">
              <Label htmlFor="reason">Reason (optional)</Label>
              <Textarea
                id="reason"
                value={actionReason}
                onChange={(e) => setActionReason(e.target.value)}
                placeholder="e.g. Spam, harassment, violation of terms…"
                rows={2}
                maxLength={500}
              />
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={actionLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={actionLoading}
              onClick={(e) => { e.preventDefault(); void performAction(); }}
              className={cn(
                (actionDialog?.action === "BAN" || actionDialog?.action === "DELETE") &&
                "bg-destructive text-destructive-foreground hover:bg-destructive/90"
              )}
            >
              {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {actionDialog?.action === "SUSPEND" ? "Suspend" :
               actionDialog?.action === "BAN" ? "Ban" :
               actionDialog?.action === "DELETE" ? "Delete" : "Confirm"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── User detail dialog (spec §6, §7) ────────────────────────── */}
      <Dialog open={!!selectedUser} onOpenChange={(o) => !o && (setSelectedUser(null), setDetail(null))}>
        <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
          {selectedUser && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <Avatar name={selectedUser.fullName} color={selectedUser.avatarColor} src={selectedUser.avatarUrl} size="md" />
                  <div>
                    <p className="flex items-center gap-1">
                      {selectedUser.fullName}
                      {selectedUser.isVerified && <BadgeCheck className="h-4 w-4 text-blue-500" />}
                    </p>
                    <p className="text-sm font-normal text-muted-foreground">@{selectedUser.username}</p>
                  </div>
                </DialogTitle>
              </DialogHeader>

              {/* Badges */}
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline">{selectedUser.role}</Badge>
                <Badge variant={selectedUser.status === "ACTIVE" ? "default" : "destructive"}>{selectedUser.status}</Badge>
                {selectedUser.emailVerified && <Badge variant="secondary">Email verified</Badge>}
                {selectedUser.twoFactorEnabled && <Badge variant="secondary">2FA</Badge>}
              </div>

              {/* Tabs (spec §7) */}
              <div className="flex gap-1 border-b">
                {(["overview", "posts", "articles"] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setDetailTab(tab)}
                    className={cn("border-b-2 px-3 py-2 text-sm font-medium capitalize transition-colors",
                      detailTab === tab ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground")}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              {detailLoading ? (
                <div className="space-y-3 py-4">
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                </div>
              ) : detail ? (
                <>
                  {/* Overview tab */}
                  {detailTab === "overview" && (
                    <div className="space-y-4 py-2">
                      {/* User info */}
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div><p className="text-xs text-muted-foreground">Email</p><p className="truncate">{detail.user.email}</p></div>
                        <div><p className="text-xs text-muted-foreground">Joined</p><p>{formatDateTime(detail.user.createdAt)}</p></div>
                        <div><p className="text-xs text-muted-foreground">Last seen</p><p>{formatDateTime(detail.user.lastSeenAt)}</p></div>
                        <div><p className="text-xs text-muted-foreground">Language</p><p>{detail.user.language}</p></div>
                      </div>
                      {detail.user.bio && (
                        <div><p className="text-xs text-muted-foreground">Bio</p><p className="text-sm" dir="auto">{detail.user.bio}</p></div>
                      )}

                      {/* Engagement stats (spec §14) */}
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                        <StatBox label="Posts" value={detail.user.stats.posts} icon={FileText} />
                        <StatBox label="Articles" value={detail.user.stats.publishedArticles} icon={FileText} />
                        <StatBox label="Followers" value={detail.user.stats.followers} icon={UserPlus} />
                        <StatBox label="Following" value={detail.user.stats.following} icon={UserPlus} />
                        <StatBox label="Likes Recv" value={detail.user.stats.likesReceived} icon={Heart} color="text-red-500" />
                        <StatBox label="Comments Recv" value={detail.user.stats.commentsReceived} icon={MessageCircle} color="text-sky-500" />
                        <StatBox label="Views Recv" value={detail.user.stats.viewsReceived} icon={Eye} color="text-amber-500" />
                        <StatBox label="Shares Recv" value={detail.user.stats.sharesReceived} icon={Share2} color="text-teal-500" />
                      </div>

                      {/* Engagement rate */}
                      <div className="rounded-lg border p-3">
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-sm font-medium">
                            <TrendingUp className="h-4 w-4 text-primary" /> Engagement Rate
                          </span>
                          <span className="text-lg font-bold text-primary">{detail.user.stats.engagementRate}%</span>
                        </div>
                        <p className="mt-1 text-xs text-muted-foreground">
                          (Likes + Comments + Shares) / Unique Views × 100
                        </p>
                      </div>

                      {/* Action buttons (spec §8-§12, §19-§21) */}
                      {canModify(selectedUser) && (
                        <div className="flex flex-wrap gap-2 border-t pt-4">
                          {selectedUser.status === "ACTIVE" && (
                            <Button size="sm" variant="outline" onClick={() => setActionDialog({ userId: selectedUser.id, action: "SUSPEND", userName: selectedUser.username })}>
                              <ShieldBan className="mr-1 h-3 w-3" /> Suspend
                            </Button>
                          )}
                          {selectedUser.status === "SUSPENDED" && (
                            <Button size="sm" variant="outline" onClick={() => setActionDialog({ userId: selectedUser.id, action: "UNSUSPEND", userName: selectedUser.username })}>
                              <UserCheck className="mr-1 h-3 w-3" /> Unsuspend
                            </Button>
                          )}
                          {selectedUser.status !== "BANNED" && (
                            <Button size="sm" variant="destructive" onClick={() => setActionDialog({ userId: selectedUser.id, action: "BAN", userName: selectedUser.username })}>
                              <ShieldBan className="mr-1 h-3 w-3" /> Ban
                            </Button>
                          )}
                          {selectedUser.status === "BANNED" && (
                            <Button size="sm" variant="outline" onClick={() => setActionDialog({ userId: selectedUser.id, action: "UNBAN", userName: selectedUser.username })}>
                              <UserCheck className="mr-1 h-3 w-3" /> Unban
                            </Button>
                          )}
                          {!selectedUser.emailVerified && (
                            <Button size="sm" variant="outline" onClick={() => setActionDialog({ userId: selectedUser.id, action: "VERIFY_EMAIL", userName: selectedUser.username })}>
                              <MailCheck className="mr-1 h-3 w-3" /> Verify email
                            </Button>
                          )}
                          {selectedUser.isVerified ? (
                            <Button size="sm" variant="outline" onClick={() => setActionDialog({ userId: selectedUser.id, action: "UNVERIFY", userName: selectedUser.username })}>
                              <BadgeCheck className="mr-1 h-3 w-3" /> Unverify
                            </Button>
                          ) : (
                            <Button size="sm" variant="outline" onClick={() => setActionDialog({ userId: selectedUser.id, action: "VERIFY", userName: selectedUser.username })}>
                              <BadgeCheck className="mr-1 h-3 w-3 text-blue-500" /> Verify
                            </Button>
                          )}
                          {isSuperAdmin(me) && (
                            <Select onValueChange={(r) => setActionDialog({ userId: selectedUser.id, action: "SET_ROLE", userName: selectedUser.username })}>
                              <SelectTrigger className="w-36"><SelectValue placeholder="Change role" /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="USER">User</SelectItem>
                                <SelectItem value="MODERATOR">Moderator</SelectItem>
                                <SelectItem value="ADMIN">Admin</SelectItem>
                                <SelectItem value="SUPER_ADMIN">Super Admin</SelectItem>
                              </SelectContent>
                            </Select>
                          )}
                          {isSuperAdmin(me) && selectedUser.id !== me?.id && (
                            <Button size="sm" variant="destructive" onClick={() => setActionDialog({ userId: selectedUser.id, action: "DELETE", userName: selectedUser.username })}>
                              <Trash2 className="mr-1 h-3 w-3" /> Delete
                            </Button>
                          )}
                        </div>
                      )}

                      {/* Sessions + Reports (if any) */}
                      {detail.sessions.length > 0 && (
                        <div className="border-t pt-4">
                          <p className="mb-2 text-sm font-medium">Active Sessions ({detail.sessions.length})</p>
                          <div className="space-y-1 text-xs">
                            {detail.sessions.map((s) => (
                              <div key={s.id} className="rounded border p-2">
                                <p>{s.ipAddress ?? "unknown IP"}</p>
                                <p className="text-muted-foreground">{s.userAgent ?? "unknown device"}</p>
                                <p className="text-muted-foreground">Last active: {formatDateTime(s.lastActiveAt)}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                      {detail.reports.length > 0 && (
                        <div className="border-t pt-4">
                          <p className="mb-2 text-sm font-medium">Related Reports ({detail.reports.length})</p>
                          <div className="space-y-1 text-xs">
                            {detail.reports.map((r) => (
                              <div key={r.id} className="rounded border p-2">
                                <p className="font-medium">{r.reason}</p>
                                <p className="text-muted-foreground">Status: {r.status} · {formatDateTime(r.createdAt)}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Posts tab (spec §7) */}
                  {detailTab === "posts" && (
                    <div className="space-y-2 py-2">
                      {detail.user.recentPosts.length === 0 ? (
                        <p className="py-6 text-center text-sm text-muted-foreground">No posts yet.</p>
                      ) : (
                        detail.user.recentPosts.map((p) => (
                          <div key={p.id} className="rounded-lg border p-3 hover:bg-accent/30">
                            <p className="line-clamp-2 text-sm" dir="auto">{p.content}</p>
                            <div className="mt-2 flex gap-3 text-xs text-muted-foreground">
                              <span>❤️ {p.likeCount}</span>
                              <span>💬 {p.commentCount}</span>
                              <span>👁️ {p.viewCount}</span>
                              <span className="ml-auto">{formatRelativeTime(p.createdAt)}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {/* Articles tab (spec §7) */}
                  {detailTab === "articles" && (
                    <div className="space-y-2 py-2">
                      {detail.user.recentArticles.length === 0 ? (
                        <p className="py-6 text-center text-sm text-muted-foreground">No published articles yet.</p>
                      ) : (
                        detail.user.recentArticles.map((a) => (
                          <div key={a.id} className="flex gap-3 rounded-lg border p-3 hover:bg-accent/30">
                            {a.coverImage && (
                              <img src={a.coverImage} alt="" className="h-12 w-12 shrink-0 rounded object-cover" loading="lazy" />
                            )}
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-medium" dir="auto">{a.title}</p>
                              {a.excerpt && <p className="line-clamp-1 text-xs text-muted-foreground" dir="auto">{a.excerpt}</p>}
                              <div className="mt-1 flex gap-3 text-xs text-muted-foreground">
                                <span>❤️ {a.likeCount}</span>
                                <span>💬 {a.commentCount}</span>
                                <span>👁️ {a.viewCount}</span>
                                <span>⏱️ {a.readingTime} min</span>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </>
              ) : null}
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── Sub-component: StatBox ─────────────────────────────────────────────────

function StatBox({ label, value, icon: Icon, color }: { label: string; value: number; icon: React.ComponentType<{ className?: string }>; color?: string }) {
  return (
    <div className="rounded-lg border p-2 text-center">
      <Icon className={cn("mx-auto mb-1 h-4 w-4", color ?? "text-muted-foreground")} />
      <p className="text-lg font-bold">{formatNumber(value)}</p>
      <p className="text-[10px] text-muted-foreground">{label}</p>
    </div>
  );
}
