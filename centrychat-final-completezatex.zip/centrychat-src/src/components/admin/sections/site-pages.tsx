"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import {
  Loader2,
  Save,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  FileText,
  ExternalLink,
  RotateCcw,
  Eye,
  EyeOff,
  ArrowLeft,
} from "lucide-react";
import type { SitePageRow, SitePageSection, SitePageContent } from "@/lib/site-pages";

/**
 * AdminSitePages — admin section for managing the 4 site pages.
 *
 * Two views:
 *   1. LIST view (default): shows all 4 pages as cards with:
 *        - Title + slug
 *        - Published / Draft badge
 *        - Last updated timestamp
 *        - Edit button (opens editor)
 *        - View public page link (opens /<slug> in new tab)
 *   2. EDITOR view (when a page is selected): full editor with:
 *        - Page Settings (title, SEO title, SEO description, isPublished)
 *        - Intro (title + content)
 *        - Sections (add/delete/reorder)
 *        - Contact block (only for /contact)
 *        - Sticky Save button
 *
 * Behavior:
 *   - Loads the list on mount via GET /api/v1/admin/site-pages.
 *   - Clicking "Edit" loads the full page via GET /api/v1/admin/site-pages/:slug.
 *   - All edits are local state until "Save Changes" is clicked.
 *   - Save calls PUT /api/v1/admin/site-pages/:slug.
 *   - On success: toast + the list reflects the new updatedAt.
 *   - The public page reflects the update within 30s (cache invalidation).
 *
 * Validation:
 *   - Light client-side validation (non-empty title + intro + sections).
 *   - Server re-validates via Zod (source of truth).
 */

// ── Types ───────────────────────────────────────────────────────────────

interface ListResponse {
  pages: SitePageRow[];
}
interface SingleResponse {
  page: SitePageRow;
}

const PAGE_META: Record<
  string,
  { label: string; description: string }
> = {
  about: { label: "About Us", description: "Public About page" },
  privacy: { label: "Privacy Policy", description: "Privacy Policy page" },
  terms: { label: "Terms of Service", description: "Terms of Service page" },
  contact: { label: "Contact", description: "Contact information + form" },
};

// ── Component ───────────────────────────────────────────────────────────

export function AdminSitePages() {
  const [pages, setPages] = useState<SitePageRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [editingSlug, setEditingSlug] = useState<string | null>(null);
  const [editor, setEditor] = useState<EditorState | null>(null);

  // Load list on mount.
  const loadList = useCallback(async () => {
    setLoading(true);
    try {
      const d = await api.get<ListResponse>("/api/v1/admin/site-pages");
      setPages(d.pages);
    } catch (e) {
      toast.error(
        e instanceof ApiClientError ? e.message : "Failed to load site pages"
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadList();
  }, [loadList]);

  // Open the editor for a slug.
  async function openEditor(slug: string) {
    setEditingSlug(slug);
    setEditor({ loading: true, data: null });
    try {
      const d = await api.get<SingleResponse>(
        `/api/v1/admin/site-pages/${slug}`
      );
      setEditor({ loading: false, data: d.page });
    } catch (e) {
      toast.error(
        e instanceof ApiClientError ? e.message : "Failed to load page"
      );
      setEditor({ loading: false, data: null });
    }
  }

  function closeEditor() {
    setEditingSlug(null);
    setEditor(null);
    void loadList(); // refresh the list to show new updatedAt
  }

  // ── Render ───────────────────────────────────────────────────────────

  if (loading && !pages) {
    return (
      <div className="py-8 text-center text-muted-foreground">
        <Loader2 className="mx-auto h-6 w-6 animate-spin" />
      </div>
    );
  }

  // Editor view
  if (editingSlug && editor) {
    return (
      <SitePageEditor
        slug={editingSlug}
        state={editor}
        onClose={closeEditor}
      />
    );
  }

  // List view
  if (!pages) {
    return (
      <div className="py-8 text-center text-muted-foreground">
        Failed to load site pages.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Pages &amp; Legal</h2>
        <p className="text-sm text-muted-foreground">
          Manage the public informational + legal pages. Changes go live within 30 seconds of saving.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {pages.map((page) => {
          const meta = PAGE_META[page.slug] ?? {
            label: page.title,
            description: `/${page.slug}`,
          };
          return (
            <Card key={page.slug}>
              <CardHeader className="flex flex-row items-start justify-between space-y-0">
                <div className="space-y-1">
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    {meta.label}
                  </CardTitle>
                  <CardDescription className="font-mono text-xs">
                    /{page.slug}
                  </CardDescription>
                </div>
                <Badge variant={page.isPublished ? "default" : "secondary"}>
                  {page.isPublished ? "Published" : "Draft"}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  {page.content.intro.content.slice(0, 100)}
                  {page.content.intro.content.length > 100 ? "..." : ""}
                </p>
                <p className="text-xs text-muted-foreground">
                  Last updated: {formatRelativeTime(page.updatedAt)}
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="default"
                    onClick={() => openEditor(page.slug)}
                  >
                    Edit
                  </Button>
                  <a
                    href={`/${page.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex h-9 items-center gap-1.5 rounded-md border border-input bg-background px-3 text-sm font-medium hover:bg-accent"
                  >
                    <ExternalLink className="h-4 w-4" />
                    View
                  </a>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

// ── Editor ──────────────────────────────────────────────────────────────

interface EditorState {
  loading: boolean;
  data: SitePageRow | null;
}

function SitePageEditor({
  slug,
  state,
  onClose,
}: {
  slug: string;
  state: EditorState;
  onClose: () => void;
}) {
  const [data, setData] = useState<SitePageRow | null>(state.data);
  const [saving, setSaving] = useState(false);
  const meta = PAGE_META[slug] ?? { label: slug, description: "" };

  // Sync local state when the parent passes new data.
  useEffect(() => {
    setData(state.data);
  }, [state.data]);

  // ── Section operations ───────────────────────────────────────────────

  function addSection() {
    if (!data) return;
    const newSection: SitePageSection = {
      id: crypto.randomUUID(),
      title: "",
      content: "",
    };
    setData({
      ...data,
      content: { ...data.content, sections: [...data.content.sections, newSection] },
    });
  }

  function deleteSection(id: string) {
    if (!data) return;
    setData({
      ...data,
      content: {
        ...data.content,
        sections: data.content.sections.filter((s) => s.id !== id),
      },
    });
  }

  function moveSection(id: string, direction: "up" | "down") {
    if (!data) return;
    const idx = data.content.sections.findIndex((s) => s.id === id);
    if (idx === -1) return;
    const newIdx = direction === "up" ? idx - 1 : idx + 1;
    if (newIdx < 0 || newIdx >= data.content.sections.length) return;
    const newSections = [...data.content.sections];
    [newSections[idx], newSections[newIdx]] = [
      newSections[newIdx],
      newSections[idx],
    ];
    setData({
      ...data,
      content: { ...data.content, sections: newSections },
    });
  }

  function updateSection(id: string, field: "title" | "content", value: string) {
    if (!data) return;
    setData({
      ...data,
      content: {
        ...data.content,
        sections: data.content.sections.map((s) =>
          s.id === id ? { ...s, [field]: value } : s
        ),
      },
    });
  }

  // Update a single field in the contact block. Ensures all 4 fields stay
  // present (the SitePageContent.contact type requires them all — the Zod
  // schema allows optional, but we normalize to required strings when reading).
  function updateContactField(
    field: "title" | "content" | "email" | "website",
    value: string
  ) {
    if (!data || !data.content.contact) return;
    setData({
      ...data,
      content: {
        ...data.content,
        contact: {
          title: data.content.contact.title,
          content: data.content.contact.content,
          email: data.content.contact.email,
          website: data.content.contact.website,
          [field]: value,
        },
      },
    });
  }

  // ── Save ─────────────────────────────────────────────────────────────

  async function save() {
    if (!data) return;
    if (!data.title.trim()) {
      toast.error("Title cannot be empty");
      return;
    }
    if (!data.content.intro.title.trim() || !data.content.intro.content.trim()) {
      toast.error("Intro title and content cannot be empty");
      return;
    }
    for (const s of data.content.sections) {
      if (!s.title.trim() || !s.content.trim()) {
        toast.error("Every section must have a title and content");
        return;
      }
    }
    setSaving(true);
    try {
      const d = await api.put<SingleResponse>(
        `/api/v1/admin/site-pages/${slug}`,
        {
          title: data.title,
          content: data.content,
          seoTitle: data.seoTitle,
          seoDescription: data.seoDescription,
          isPublished: data.isPublished,
        }
      );
      setData(d.page);
      toast.success("Changes saved successfully");
    } catch (e) {
      toast.error(
        e instanceof ApiClientError ? e.message : "Failed to save changes"
      );
    } finally {
      setSaving(false);
    }
  }

  // ── Reset to defaults ────────────────────────────────────────────────

  async function resetToDefaults() {
    try {
      // Fetch the public version (which returns defaults when the page
      // is a draft / doesn't exist). Then we keep it in local state —
      // the admin must click "Save Changes" to persist.
      const d = await api.get<{ page: { content: SitePageContent; title: string; seoTitle: string; seoDescription: string } | null }>(
        `/api/v1/site-pages/${slug}`
      );
      if (!d.page) {
        // Page is a draft — fetch the admin version instead (which lazy-creates
        // with defaults).
        const admin = await api.get<SingleResponse>(
          `/api/v1/admin/site-pages/${slug}`
        );
        if (admin.page && data) {
          setData({
            ...data,
            title: admin.page.title,
            content: admin.page.content,
            seoTitle: admin.page.seoTitle,
            seoDescription: admin.page.seoDescription,
          });
        }
        toast.info("Defaults loaded — click Save Changes to persist");
        return;
      }
      if (data) {
        setData({
          ...data,
          title: d.page.title,
          content: d.page.content,
          seoTitle: d.page.seoTitle,
          seoDescription: d.page.seoDescription,
        });
      }
      toast.info("Defaults loaded — click Save Changes to persist");
    } catch (e) {
      toast.error(
        e instanceof ApiClientError ? e.message : "Failed to load defaults"
      );
    }
  }

  // ── Render ───────────────────────────────────────────────────────────

  if (state.loading || !data) {
    return (
      <div className="py-8 text-center text-muted-foreground">
        <Loader2 className="mx-auto h-6 w-6 animate-spin" />
      </div>
    );
  }

  const isContactPage = slug === "contact";

  return (
    <div className="space-y-6">
      {/* Header with back button */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <Button variant="ghost" size="icon" onClick={onClose} aria-label="Back to list">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h2 className="text-2xl font-bold tracking-tight">{meta.label}</h2>
            <p className="text-sm text-muted-foreground">
              <code className="rounded bg-muted px-1">/{slug}</code>
              {" — "}
              {meta.description}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={resetToDefaults}
            title="Load default content into the editor (does not save)"
          >
            <RotateCcw className="mr-1.5 h-4 w-4" />
            Reset to defaults
          </Button>
          <a
            href={`/${slug}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-9 items-center gap-1.5 rounded-md border border-input bg-background px-3 text-sm font-medium hover:bg-accent"
          >
            <ExternalLink className="h-4 w-4" />
            View public page
          </a>
        </div>
      </div>

      {/* Page Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Page Settings
          </CardTitle>
          <CardDescription>
            The page title + SEO overrides + publish toggle.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="pageTitle">Page title</Label>
            <Input
              id="pageTitle"
              value={data.title}
              onChange={(e) => setData({ ...data, title: e.target.value })}
              maxLength={200}
            />
            <p className="text-xs text-muted-foreground">
              Shown as the page&apos;s main heading + browser tab title (when SEO title is empty).
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="seoTitle">SEO title (optional)</Label>
            <Input
              id="seoTitle"
              value={data.seoTitle}
              onChange={(e) => setData({ ...data, seoTitle: e.target.value })}
              maxLength={200}
              placeholder={`${data.title} | Platform`}
            />
            <p className="text-xs text-muted-foreground">
              Overrides the browser tab title + social-media preview title.
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="seoDescription">SEO description (optional)</Label>
            <Textarea
              id="seoDescription"
              value={data.seoDescription}
              onChange={(e) =>
                setData({ ...data, seoDescription: e.target.value })
              }
              maxLength={300}
              rows={3}
              placeholder="A short description for search engines + social-media previews."
            />
            <p className="text-xs text-muted-foreground">
              {data.seoDescription.length}/300 characters. Leave empty to auto-generate from the intro content.
            </p>
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border/60 p-3">
            <div>
              <Label htmlFor="isPublished" className="text-sm font-medium">
                Published
              </Label>
              <p className="text-xs text-muted-foreground">
                When published, the page is visible at <code className="rounded bg-muted px-1">/{slug}</code>.
                When draft, visitors see a 404.
              </p>
            </div>
            <Button
              id="isPublished"
              variant={data.isPublished ? "default" : "outline"}
              size="sm"
              onClick={() => setData({ ...data, isPublished: !data.isPublished })}
            >
              {data.isPublished ? (
                <>
                  <Eye className="mr-1.5 h-4 w-4" />
                  Published
                </>
              ) : (
                <>
                  <EyeOff className="mr-1.5 h-4 w-4" />
                  Draft
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Intro */}
      <Card>
        <CardHeader>
          <CardTitle>Intro</CardTitle>
          <CardDescription>
            The first block on the page — welcomes the visitor.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="introTitle">Intro title</Label>
            <Input
              id="introTitle"
              value={data.content.intro.title}
              onChange={(e) =>
                setData({
                  ...data,
                  content: {
                    ...data.content,
                    intro: { ...data.content.intro, title: e.target.value },
                  },
                })
              }
              maxLength={200}
              placeholder="Welcome"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="introContent">Intro content</Label>
            <Textarea
              id="introContent"
              value={data.content.intro.content}
              onChange={(e) =>
                setData({
                  ...data,
                  content: {
                    ...data.content,
                    intro: { ...data.content.intro, content: e.target.value },
                  },
                })
              }
              maxLength={5000}
              rows={4}
            />
            <p className="text-xs text-muted-foreground">
              {data.content.intro.content.length}/5000 characters.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Sections */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>Sections</CardTitle>
            <CardDescription>
              Ordered list of content blocks. Use the arrows to reorder.
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={addSection}>
            <Plus className="mr-1.5 h-4 w-4" />
            Add Section
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {data.content.sections.length === 0 && (
            <p className="py-4 text-center text-sm text-muted-foreground">
              No sections yet. Click &quot;Add Section&quot; to create one.
            </p>
          )}
          {data.content.sections.map((section, idx) => (
            <div
              key={section.id}
              className="space-y-3 rounded-lg border border-border/60 p-4"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                  Section {idx + 1}
                </span>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => moveSection(section.id, "up")}
                    disabled={idx === 0}
                    aria-label="Move section up"
                    title="Move up"
                  >
                    <ArrowUp className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => moveSection(section.id, "down")}
                    disabled={idx === data.content.sections.length - 1}
                    aria-label="Move section down"
                    title="Move down"
                  >
                    <ArrowDown className="h-4 w-4" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        aria-label="Delete section"
                        title="Delete section"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete section?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will remove &quot;{section.title || "Untitled section"}&quot; from the page.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => deleteSection(section.id)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor={`section-title-${section.id}`}>Title</Label>
                <Input
                  id={`section-title-${section.id}`}
                  value={section.title}
                  onChange={(e) =>
                    updateSection(section.id, "title", e.target.value)
                  }
                  maxLength={200}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor={`section-content-${section.id}`}>Content</Label>
                <Textarea
                  id={`section-content-${section.id}`}
                  value={section.content}
                  onChange={(e) =>
                    updateSection(section.id, "content", e.target.value)
                  }
                  maxLength={5000}
                  rows={4}
                />
                <p className="text-xs text-muted-foreground">
                  {section.content.length}/5000 characters.
                </p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Contact block — only for /contact */}
      {isContactPage && data.content.contact && (
        <Card>
          <CardHeader>
            <CardTitle>Contact Information</CardTitle>
            <CardDescription>
              Shown above the contact form on the /contact page. Leave email + website empty to hide them.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="contactTitle">Contact title</Label>
              <Input
                id="contactTitle"
                value={data.content.contact.title}
                onChange={(e) => updateContactField("title", e.target.value)}
                maxLength={200}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contactContent">Contact content</Label>
              <Textarea
                id="contactContent"
                value={data.content.contact.content}
                onChange={(e) => updateContactField("content", e.target.value)}
                maxLength={5000}
                rows={3}
              />
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="contactEmail">Email (optional)</Label>
                <Input
                  id="contactEmail"
                  type="email"
                  value={data.content.contact.email}
                  onChange={(e) => updateContactField("email", e.target.value)}
                  maxLength={254}
                  placeholder="hello@example.com"
                />
                <p className="text-xs text-muted-foreground">
                  This is also the recipient for the contact form submissions.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactWebsite">Website (optional)</Label>
                <Input
                  id="contactWebsite"
                  type="url"
                  value={data.content.contact.website}
                  onChange={(e) => updateContactField("website", e.target.value)}
                  maxLength={2048}
                  placeholder="https://example.com"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Save bar — sticky at the bottom */}
      <div className="sticky bottom-4 flex justify-end">
        <Button
          onClick={save}
          disabled={saving}
          size="lg"
          className="shadow-lg"
        >
          {saving ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Save className="mr-2 h-4 w-4" />
          )}
          {saving ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </div>
  );
}

// ── Helpers ────────────────────────────────────────────────────────────

function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  const diff = Date.now() - date.getTime();
  const seconds = Math.floor(diff / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return date.toLocaleDateString();
}
