"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { Loader2, Save, Palette, ShieldCheck } from "lucide-react";

interface Customization {
  brandColor: string;
  customCss: string;
  platformName: string;
  platformDescription: string;
}

export function AdminCustomization() {
  const [data, setData] = useState<Customization | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    void api.get<{ customization: Customization }>("/api/v1/admin/customization").then((d) => setData(d.customization)).catch((e) => {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load customization");
    });
  }, []);

  async function save() {
    if (!data) return;
    setSaving(true);
    try {
      await api.put("/api/v1/admin/customization", data);
      toast.success("Customization saved");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  }

  if (!data) return <div className="py-8 text-center text-muted-foreground">Loading…</div>;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Customization</h2>
        <p className="text-sm text-muted-foreground">Safe branding & appearance customization.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Palette className="h-4 w-4" /> Branding</CardTitle>
          <CardDescription>Platform name, description, and primary color.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Platform name</Label>
            <Input id="name" value={data.platformName} onChange={(e) => setData({ ...data, platformName: e.target.value })} maxLength={60} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="desc">Description</Label>
            <Input id="desc" value={data.platformDescription} onChange={(e) => setData({ ...data, platformDescription: e.target.value })} maxLength={200} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="color">Brand color</Label>
            <div className="flex items-center gap-2">
              <input type="color" value={data.brandColor} onChange={(e) => setData({ ...data, brandColor: e.target.value })} className="h-10 w-12 rounded border" />
              <Input value={data.brandColor} onChange={(e) => setData({ ...data, brandColor: e.target.value })} className="max-w-40" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Custom CSS</CardTitle>
          <CardDescription>Scoped CSS applied to the user app. Validated for safety.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Textarea
            value={data.customCss}
            onChange={(e) => setData({ ...data, customCss: e.target.value })}
            rows={8}
            placeholder="/* e.g. */ .message-bubble { border-radius: 8px; }"
            className="font-mono text-xs"
          />
          <p className="text-xs text-muted-foreground">Disallowed: <code>@import</code>, <code>url()</code>, <code>expression()</code>, <code>javascript:</code>. Max 20KB.</p>
        </CardContent>
      </Card>

      <Card className="border-green-500/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><ShieldCheck className="h-4 w-4 text-green-500" /> Safe Customization Policy</CardTitle>
        </CardHeader>
        <CardContent className="space-y-1 text-sm text-muted-foreground">
          <p>Only explicitly safe categories are supported:</p>
          <ul className="ml-4 list-disc">
            <li>CSS (scoped & sanitized — no remote imports)</li>
            <li>Scoped HTML (sanitized on render)</li>
            <li>JSON configuration (validated against schema)</li>
          </ul>
          <p className="mt-2"><strong className="text-foreground">No arbitrary backend code execution.</strong> No <code>eval()</code>, <code>new Function()</code>, <code>child_process</code>, shell commands, or raw SQL.</p>
        </CardContent>
      </Card>

      <Button onClick={save} disabled={saving} size="lg">
        {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
        Save customization
      </Button>
    </div>
  );
}
