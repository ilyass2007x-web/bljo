"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import {
  Loader2,
  Save,
  Plus,
  Pencil,
  Trash2,
  Power,
  PowerOff,
  Search,
  DollarSign,
  Activity,
  Layers,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";

/**
 * AdminAdSense — the AdSense management section in the Admin Dashboard.
 *
 * Four panels (spec §47):
 *   1. Status cards — AdSense status, Publisher ID, Active Ad Units,
 *      Total Placements.
 *   2. Ad Units table — list, search, filter, edit, toggle, delete.
 *   3. Settings — publisher ID, enabled flag, role gating, frequency,
 *      excluded routes.
 *   4. Create/Edit dialog — full form for ad unit fields.
 *
 * All mutations go through the /api/v1/admin/adsense/* endpoints (admin-
 * gated server-side). The cache invalidates on save so changes appear
 * within 60s on the public site (spec §43).
 */

interface AdUnitDTO {
  id: string;
  name: string;
  description: string | null;
  slotId: string;
  format: string;
  placement: string;
  priority: number;
  active: boolean;
  devices: string[];
  pages: string[];
  rotation: boolean;
  createdAt: string;
  updatedAt: string;
}

interface AdSenseSettings {
  enabled: boolean;
  publisherId: string;
  showToGuests: boolean;
  showToUsers: boolean;
  showToAdmin: boolean;
  maxAdsPerPage: number;
  minDistanceSlots: number;
  excludedRoutes: string[];
}

const AD_FORMATS = ["DISPLAY", "RESPONSIVE", "IN_FEED", "IN_ARTICLE"] as const;
const AD_PLACEMENTS: Record<string, string> = {
  HOME_TOP: "Home — Top",
  HOME_FEED: "Home — In Feed",
  HOME_BOTTOM: "Home — Bottom",
  ARTICLE_TOP: "Article — Top",
  ARTICLE_AFTER_INTRO: "Article — After Intro",
  ARTICLE_MIDDLE: "Article — Middle",
  ARTICLE_BEFORE_END: "Article — Before End",
  ARTICLE_BOTTOM: "Article — Bottom",
  POST_FEED: "Posts — Between Posts",
  PROFILE_TOP: "Profile — Top",
  PROFILE_FEED: "Profile — In Feed",
  SEARCH_TOP: "Search — Top",
  SEARCH_RESULTS: "Search — In Results",
  GLOBAL_HEADER: "Global — Header",
  GLOBAL_FOOTER: "Global — Footer",
};
const AD_DEVICES = ["DESKTOP", "TABLET", "MOBILE"] as const;
const AD_PAGES = ["HOME", "ARTICLE", "POST", "PROFILE", "SEARCH", "REELS"] as const;

export function AdminAdSense() {
  const [tab, setTab] = useState<"status" | "units" | "settings">("status");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Google AdSense</h2>
        <p className="text-sm text-muted-foreground">
          Manage ad units, placements, and AdSense configuration. Changes take effect within 60 seconds.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b">
        {(["status", "units", "settings"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`border-b-2 px-4 py-2 text-sm font-medium capitalize transition-colors ${
              tab === t
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t === "status" ? "Status" : t === "units" ? "Ad Units" : "Settings"}
          </button>
        ))}
      </div>

      {tab === "status" && <StatusPanel />}
      {tab === "units" && <UnitsPanel />}
      {tab === "settings" && <SettingsPanel />}
    </div>
  );
}

// ── Status Panel ─────────────────────────────────────────────────────────

function StatusPanel() {
  const [settings, setSettings] = useState<AdSenseSettings | null>(null);
  const [units, setUnits] = useState<AdUnitDTO[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const [settingsData, unitsData] = await Promise.all([
        api.get<{ settings: AdSenseSettings }>("/api/v1/admin/adsense/settings"),
        api.get<{ units: AdUnitDTO[] }>("/api/v1/admin/adsense/units"),
      ]);
      setSettings(settingsData.settings);
      setUnits(unitsData.units);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load AdSense status");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  if (loading || !settings) {
    return <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>;
  }

  const activeCount = units.filter((u) => u.active).length;
  const inactiveCount = units.length - activeCount;
  const placementsCount = new Set(units.filter((u) => u.active).map((u) => u.placement)).size;
  const publisherConfigured = !!settings.publisherId && /^ca-pub-\d{16}$/.test(settings.publisherId);

  return (
    <div className="space-y-6">
      {/* Top status cards (spec §47) */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">AdSense Status</CardTitle>
            {settings.enabled ? (
              <ToggleRight className="h-4 w-4 text-green-500" />
            ) : (
              <ToggleLeft className="h-4 w-4 text-muted-foreground" />
            )}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{settings.enabled ? "Enabled" : "Disabled"}</div>
            <p className="text-xs text-muted-foreground">
              {settings.enabled ? "Ads are rendering" : "Master switch off"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Publisher ID</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-sm font-mono">
              {publisherConfigured ? (
                <Badge variant="default" className="bg-green-500">{settings.publisherId}</Badge>
              ) : (
                <Badge variant="destructive">Not configured</Badge>
              )}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {publisherConfigured ? "Valid format" : "Enter a ca-pub-XXXXXXXXXXXXXXXX ID"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Active Ad Units</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCount}</div>
            <p className="text-xs text-muted-foreground">{inactiveCount} inactive</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Placements</CardTitle>
            <Layers className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{placementsCount}</div>
            <p className="text-xs text-muted-foreground">distinct active slots</p>
          </CardContent>
        </Card>
      </div>

      {/* Status details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Configuration Overview</CardTitle>
          <CardDescription>Current AdSense settings (read-only here — edit in the Settings tab)</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <DetailRow label="AdSense Script" value={settings.enabled && publisherConfigured ? "Active" : "Inactive"} />
            <DetailRow label="Show to Guests" value={settings.showToGuests ? "Yes" : "No"} />
            <DetailRow label="Show to Users" value={settings.showToUsers ? "Yes" : "No"} />
            <DetailRow label="Show to Admins" value={settings.showToAdmin ? "Yes" : "No"} />
            <DetailRow label="Max Ads per Page" value={String(settings.maxAdsPerPage)} />
            <DetailRow label="Min Distance Between Ads" value={`${settings.minDistanceSlots} items`} />
          </div>
          <div className="pt-2">
            <Label className="text-xs text-muted-foreground">Excluded Routes ({settings.excludedRoutes.length})</Label>
            <div className="mt-1 flex flex-wrap gap-1">
              {settings.excludedRoutes.length === 0 ? (
                <span className="text-xs text-muted-foreground">None — ads can appear everywhere</span>
              ) : (
                settings.excludedRoutes.map((r) => (
                  <Badge key={r} variant="outline" className="text-xs">{r}</Badge>
                ))
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active units by placement — quick reference */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Active Units by Placement</CardTitle>
          <CardDescription>Where ads are currently rendering</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {units.filter((u) => u.active).length === 0 ? (
              <p className="text-sm text-muted-foreground">No active ad units. Create one in the Ad Units tab.</p>
            ) : (
              units.filter((u) => u.active).map((u) => (
                <div key={u.id} className="flex items-center justify-between rounded-lg border p-2 text-sm">
                  <div>
                    <span className="font-medium">{u.name}</span>
                    <span className="ml-2 text-xs text-muted-foreground">{AD_PLACEMENTS[u.placement] ?? u.placement}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">{u.format}</Badge>
                    <Badge variant="outline" className="text-xs">Priority {u.priority}</Badge>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded border bg-muted/30 px-3 py-2">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-sm font-medium">{value}</span>
    </div>
  );
}

// ── Units Panel ─────────────────────────────────────────────────────────

function UnitsPanel() {
  const [units, setUnits] = useState<AdUnitDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all");
  const [placementFilter, setPlacementFilter] = useState<string>("all");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<AdUnitDTO | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AdUnitDTO | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set("search", search.trim());
      if (statusFilter !== "all") params.set("status", statusFilter);
      if (placementFilter !== "all") params.set("placement", placementFilter);
      const data = await api.get<{ units: AdUnitDTO[] }>(`/api/v1/admin/adsense/units?${params}`);
      setUnits(data.units);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load ad units");
    } finally {
      setLoading(false);
    }
  }, [search, statusFilter, placementFilter]);

  useEffect(() => { void load(); }, [load]);

  async function toggleActive(unit: AdUnitDTO) {
    try {
      const data = await api.patch<{ unit: AdUnitDTO }>(`/api/v1/admin/adsense/units/${unit.id}`, {
        active: !unit.active,
      });
      setUnits((prev) => prev.map((u) => (u.id === unit.id ? data.unit : u)));
      toast.success(`"${unit.name}" ${unit.active ? "disabled" : "enabled"}`);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to toggle unit");
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    try {
      await api.delete(`/api/v1/admin/adsense/units/${deleteTarget.id}`);
      setUnits((prev) => prev.filter((u) => u.id !== deleteTarget.id));
      toast.success(`"${deleteTarget.name}" deleted`);
      setDeleteTarget(null);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to delete unit");
    }
  }

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, description, or slot ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8"
          />
        </div>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
          <SelectTrigger className="w-[140px]"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
        <Select value={placementFilter} onValueChange={setPlacementFilter}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Placement" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Placements</SelectItem>
            {Object.entries(AD_PLACEMENTS).map(([key, label]) => (
              <SelectItem key={key} value={key}>{label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          onClick={() => { setEditing(null); setEditorOpen(true); }}
        >
          <Plus className="mr-1.5 h-4 w-4" />
          Create Ad Unit
        </Button>
      </div>

      {/* Table (spec §25) */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>
          ) : units.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">
              <p className="text-sm">No ad units found. Create your first ad unit to get started.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Format</TableHead>
                  <TableHead>Placement</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {units.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{u.name}</div>
                        <div className="text-xs text-muted-foreground">Slot: {u.slotId}</div>
                      </div>
                    </TableCell>
                    <TableCell><Badge variant="outline" className="text-xs">{u.format}</Badge></TableCell>
                    <TableCell>
                      <div className="text-xs">
                        <div>{AD_PLACEMENTS[u.placement] ?? u.placement}</div>
                        <div className="text-muted-foreground font-mono">{u.placement}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {u.active ? (
                        <Badge className="bg-green-500">Active</Badge>
                      ) : (
                        <Badge variant="secondary">Inactive</Badge>
                      )}
                    </TableCell>
                    <TableCell>{u.priority}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => { setEditing(u); setEditorOpen(true); }}
                          title="Edit"
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => toggleActive(u)}
                          title={u.active ? "Disable" : "Enable"}
                        >
                          {u.active ? <PowerOff className="h-4 w-4" /> : <Power className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          onClick={() => setDeleteTarget(u)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Editor dialog */}
      <UnitEditorDialog
        open={editorOpen}
        unit={editing}
        onClose={() => setEditorOpen(false)}
        onSaved={() => { setEditorOpen(false); void load(); }}
      />

      {/* Delete confirmation (spec §53) */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete &quot;{deleteTarget?.name}&quot;?</AlertDialogTitle>
            <AlertDialogDescription>
              This ad unit will be permanently deleted. This action cannot be undone.
              Any pages currently rendering this ad will simply stop showing it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ── Unit Editor Dialog ──────────────────────────────────────────────────

function UnitEditorDialog({
  open,
  unit,
  onClose,
  onSaved,
}: {
  open: boolean;
  unit: AdUnitDTO | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [slotId, setSlotId] = useState("");
  const [format, setFormat] = useState<string>("RESPONSIVE");
  const [placement, setPlacement] = useState<string>("ARTICLE_TOP");
  const [priority, setPriority] = useState(10);
  const [active, setActive] = useState(true);
  const [devices, setDevices] = useState<string[]>([]);
  const [pages, setPages] = useState<string[]>([]);
  const [rotation, setRotation] = useState(false);
  const [saving, setSaving] = useState(false);

  // Hydrate form fields when the dialog opens / when `unit` changes.
  useEffect(() => {
    if (!open) return;
    if (unit) {
      setName(unit.name);
      setDescription(unit.description ?? "");
      setSlotId(unit.slotId);
      setFormat(unit.format);
      setPlacement(unit.placement);
      setPriority(unit.priority);
      setActive(unit.active);
      setDevices(unit.devices);
      setPages(unit.pages);
      setRotation(unit.rotation);
    } else {
      // Reset for create mode.
      setName("");
      setDescription("");
      setSlotId("");
      setFormat("RESPONSIVE");
      setPlacement("ARTICLE_TOP");
      setPriority(10);
      setActive(true);
      setDevices([]);
      setPages([]);
      setRotation(false);
    }
  }, [open, unit]);

  async function save() {
    if (!name.trim() || !slotId.trim()) {
      toast.error("Name and Slot ID are required");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: name.trim(),
        description: description.trim() || null,
        slotId: slotId.trim(),
        format,
        placement,
        priority,
        active,
        devices,
        pages,
        rotation,
      };
      if (unit) {
        await api.patch(`/api/v1/admin/adsense/units/${unit.id}`, payload);
        toast.success(`"${name}" updated`);
      } else {
        await api.post("/api/v1/admin/adsense/units", payload);
        toast.success(`"${name}" created`);
      }
      onSaved();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to save ad unit");
    } finally {
      setSaving(false);
    }
  }

  function toggleArrayItem(arr: string[], item: string): string[] {
    return arr.includes(item) ? arr.filter((x) => x !== item) : [...arr, item];
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{unit ? "Edit Ad Unit" : "Create Ad Unit"}</DialogTitle>
          <DialogDescription>
            Configure the ad unit. Slot ID + placement + format are validated server-side.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="ad-name">Name</Label>
            <Input
              id="ad-name"
              placeholder="e.g. Article Top Banner"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={100}
            />
            <p className="text-xs text-muted-foreground">Human-friendly name shown in admin (2-100 chars).</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="ad-desc">Description (optional)</Label>
            <Input
              id="ad-desc"
              placeholder="e.g. 728x90 leaderboard above the article"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={500}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="ad-slot">Ad Slot ID</Label>
              <Input
                id="ad-slot"
                placeholder="1234567890"
                value={slotId}
                onChange={(e) => setSlotId(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">Numeric ID from Google AdSense (5-20 digits).</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ad-priority">Priority</Label>
              <Input
                id="ad-priority"
                type="number"
                min={1}
                max={100}
                value={priority}
                onChange={(e) => setPriority(Number(e.target.value) || 10)}
              />
              <p className="text-xs text-muted-foreground">Lower = higher priority (1-100).</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="ad-format">Format</Label>
              <Select value={format} onValueChange={setFormat}>
                <SelectTrigger id="ad-format"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {AD_FORMATS.map((f) => (
                    <SelectItem key={f} value={f}>{f}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ad-placement">Placement</Label>
              <Select value={placement} onValueChange={setPlacement}>
                <SelectTrigger id="ad-placement"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  {Object.entries(AD_PLACEMENTS).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Device targeting */}
          <div className="space-y-2">
            <Label>Device Targeting</Label>
            <p className="text-xs text-muted-foreground">Leave empty for all devices.</p>
            <div className="flex flex-wrap gap-3">
              {AD_DEVICES.map((d) => (
                <label key={d} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={devices.includes(d)}
                    onCheckedChange={() => setDevices((prev) => toggleArrayItem(prev, d))}
                  />
                  {d}
                </label>
              ))}
            </div>
          </div>

          {/* Page targeting */}
          <div className="space-y-2">
            <Label>Page Targeting</Label>
            <p className="text-xs text-muted-foreground">Leave empty for all eligible pages.</p>
            <div className="flex flex-wrap gap-3">
              {AD_PAGES.map((p) => (
                <label key={p} className="flex items-center gap-2 text-sm">
                  <Checkbox
                    checked={pages.includes(p)}
                    onCheckedChange={() => setPages((prev) => toggleArrayItem(prev, p))}
                  />
                  {p}
                </label>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-3 rounded-lg border p-3">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="ad-active">Active</Label>
                <p className="text-xs text-muted-foreground">When off, the ad never renders.</p>
              </div>
              <Switch id="ad-active" checked={active} onCheckedChange={setActive} />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="ad-rotation">Enable Rotation</Label>
                <p className="text-xs text-muted-foreground">Rotate between units with the same placement (A/B testing).</p>
              </div>
              <Switch id="ad-rotation" checked={rotation} onCheckedChange={setRotation} />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={save} disabled={saving}>
            {saving ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Save className="mr-1.5 h-4 w-4" />}
            {unit ? "Save Changes" : "Create Unit"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Settings Panel ──────────────────────────────────────────────────────

function SettingsPanel() {
  const [settings, setSettings] = useState<AdSenseSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Local draft state — only committed to the server on Save.
  const [enabled, setEnabled] = useState(false);
  const [publisherId, setPublisherId] = useState("");
  const [showToGuests, setShowToGuests] = useState(true);
  const [showToUsers, setShowToUsers] = useState(true);
  const [showToAdmin, setShowToAdmin] = useState(false);
  const [maxAdsPerPage, setMaxAdsPerPage] = useState(5);
  const [minDistanceSlots, setMinDistanceSlots] = useState(3);
  const [excludedRoutesText, setExcludedRoutesText] = useState("");

  const load = useCallback(async () => {
    try {
      const data = await api.get<{ settings: AdSenseSettings }>("/api/v1/admin/adsense/settings");
      setSettings(data.settings);
      setEnabled(data.settings.enabled);
      setPublisherId(data.settings.publisherId);
      setShowToGuests(data.settings.showToGuests);
      setShowToUsers(data.settings.showToUsers);
      setShowToAdmin(data.settings.showToAdmin);
      setMaxAdsPerPage(data.settings.maxAdsPerPage);
      setMinDistanceSlots(data.settings.minDistanceSlots);
      setExcludedRoutesText(data.settings.excludedRoutes.join(", "));
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load settings");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function save() {
    // Validate publisherId format (spec §2 + §54).
    const trimmedPub = publisherId.trim();
    if (trimmedPub && !/^ca-pub-\d{16}$/.test(trimmedPub)) {
      toast.error('Publisher ID must be "ca-pub-XXXXXXXXXXXXXXXX" (16 digits) or empty.');
      return;
    }
    // Parse excluded routes — comma-separated string → array.
    const excludedRoutesArr = excludedRoutesText
      .split(",")
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    setSaving(true);
    try {
      const data = await api.put<{ settings: AdSenseSettings }>("/api/v1/admin/adsense/settings", {
        enabled,
        publisherId: trimmedPub,
        showToGuests,
        showToUsers,
        showToAdmin,
        maxAdsPerPage,
        minDistanceSlots,
        excludedRoutes: excludedRoutesArr,
      });
      setSettings(data.settings);
      toast.success("AdSense settings saved. Changes take effect within 60 seconds.");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to save settings");
    } finally {
      setSaving(false);
    }
  }

  if (loading || !settings) {
    return <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>;
  }

  const publisherValid = !publisherId.trim() || /^ca-pub-\d{16}$/.test(publisherId.trim());

  return (
    <div className="space-y-6">
      {/* Master settings card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">AdSense Configuration</CardTitle>
          <CardDescription>
            The Publisher ID is a public value (visible in AdSense page source). It&apos;s safe to expose to the client.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label htmlFor="ads-enabled">Enable AdSense</Label>
              <p className="text-xs text-muted-foreground">Master switch. When off, no ads render + no script loads.</p>
            </div>
            <Switch id="ads-enabled" checked={enabled} onCheckedChange={setEnabled} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="publisher-id">Google AdSense Publisher ID</Label>
            <Input
              id="publisher-id"
              placeholder="ca-pub-XXXXXXXXXXXXXXXX"
              value={publisherId}
              onChange={(e) => setPublisherId(e.target.value)}
              className={!publisherValid ? "border-destructive" : ""}
            />
            {!publisherValid ? (
              <p className="text-xs text-destructive">
                Invalid format. Expected &quot;ca-pub-&quot; followed by 16 digits.
              </p>
            ) : (
              <p className="text-xs text-muted-foreground">
                Find this in your AdSense dashboard under Settings → Account → Account information.
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Audience gating (spec §33 + §34) */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Audience Targeting</CardTitle>
          <CardDescription>Choose who sees ads. Respects Google&apos;s policies — never exclude required ads.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label htmlFor="show-guests">Show Ads to Logged-out Visitors</Label>
              <p className="text-xs text-muted-foreground">Anonymous visitors (Google referrers, Incognito).</p>
            </div>
            <Switch id="show-guests" checked={showToGuests} onCheckedChange={setShowToGuests} />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label htmlFor="show-users">Show Ads to Logged-in Users</Label>
              <p className="text-xs text-muted-foreground">Authenticated non-admin users.</p>
            </div>
            <Switch id="show-users" checked={showToUsers} onCheckedChange={setShowToUsers} />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label htmlFor="show-admin">Show Ads to Admins</Label>
              <p className="text-xs text-muted-foreground">Useful for testing. Off by default so admins see the clean UI.</p>
            </div>
            <Switch id="show-admin" checked={showToAdmin} onCheckedChange={setShowToAdmin} />
          </div>
        </CardContent>
      </Card>

      {/* Frequency control (spec §19) */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Frequency Control</CardTitle>
          <CardDescription>Conservative defaults to comply with Google AdSense policies.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="max-ads">Maximum Ads per Page</Label>
            <Input
              id="max-ads"
              type="number"
              min={1}
              max={20}
              value={maxAdsPerPage}
              onChange={(e) => setMaxAdsPerPage(Number(e.target.value) || 5)}
            />
            <p className="text-xs text-muted-foreground">
              Hard cap on how many ad slots can render on a single page (1-20).
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="min-distance">Minimum Distance Between Ads (in feed items)</Label>
            <Input
              id="min-distance"
              type="number"
              min={0}
              max={20}
              value={minDistanceSlots}
              onChange={(e) => setMinDistanceSlots(Number(e.target.value) || 3)}
            />
            <p className="text-xs text-muted-foreground">
              In feeds (Home, Profile, Search), this many non-ad items must appear between two ads.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Excluded routes (spec §35) */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Excluded Routes</CardTitle>
          <CardDescription>
            Comma-separated SPA view query-strings where ads are forbidden. Defaults exclude auth flows, admin, settings, messages.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <Input
            placeholder="/?view=messages, /?view=admin, /?view=settings"
            value={excludedRoutesText}
            onChange={(e) => setExcludedRoutesText(e.target.value)}
          />
          <p className="text-xs text-muted-foreground">
            Each entry is matched against the URL&apos;s query string. Example: <code>?view=messages</code> excludes the messaging page.
          </p>
        </CardContent>
      </Card>

      {/* Save button */}
      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => load()} disabled={saving}>Reset</Button>
        <Button onClick={save} disabled={saving || !publisherValid}>
          {saving ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Save className="mr-1.5 h-4 w-4" />}
          Save Settings
        </Button>
      </div>
    </div>
  );
}
