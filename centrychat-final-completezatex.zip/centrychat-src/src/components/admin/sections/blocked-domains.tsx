"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  ShieldBan,
  Plus,
  Search,
  Pencil,
  Trash2,
  Globe,
  Activity,
  CheckCircle2,
  XCircle,
  Loader2,
  FlaskConical,
} from "lucide-react";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";

/**
 * AdminBlockedDomains — the "Blocked Domains" admin section.
 *
 * Features:
 *   - Top stat cards (Total Domains, Active Rules, Hits Today, Hits This Week)
 *   - Blocked Domains table (search + status filter + pagination)
 *   - Add Domain dialog (domain, reason, notes, blockSubdomains, isActive)
 *   - Edit Domain dialog
 *   - Enable/Disable toggle (inline)
 *   - Delete (with confirmation)
 *   - "Test URL" tool (admin can verify a URL against the blocklist)
 *   - "Blocked Activity" tab (the hit audit trail)
 *
 * Security: all mutations go through /api/v1/admin/blocked-domains which
 * requires requireAdmin() server-side. The client never trusts frontend
 * state for authorization.
 */

interface BlockedDomainRule {
  id: string;
  domain: string;
  normalizedDomain: string;
  reason: string | null;
  notes: string | null;
  isActive: boolean;
  blockSubdomains: boolean;
  hitCount: number;
  createdAt: string;
  updatedAt: string;
  createdBy: string | null;
  creatorName: string | null;
  creatorUsername: string | null;
}

interface BlocklistStats {
  totalDomains: number;
  activeRules: number;
  disabledRules: number;
  hitsToday: number;
  hitsThisWeek: number;
}

interface BlockedHit {
  id: string;
  domain: string;
  normalizedDomain: string;
  reason: string | null;
  context: string;
  attemptedUrl: string;
  createdAt: string;
  user: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
  } | null;
}

type Tab = "rules" | "activity" | "test";

export function AdminBlockedDomains() {
  const [tab, setTab] = useState<Tab>("rules");
  const [rules, setRules] = useState<BlockedDomainRule[]>([]);
  const [stats, setStats] = useState<BlocklistStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "disabled">("all");
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<BlockedDomainRule | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.set("q", search);
      params.set("status", statusFilter);
      const res = await api.get<{ rules: BlockedDomainRule[]; stats: BlocklistStats }>(
        `/api/v1/admin/blocked-domains?${params.toString()}`
      );
      setRules(res.rules);
      setStats(res.stats);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to load blocked domains.");
    } finally {
      setLoading(false);
    }
  }, [search, statusFilter]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex flex-col gap-2">
        <h1 className="flex items-center gap-2 text-2xl font-bold">
          <ShieldBan className="h-6 w-6 text-primary" />
          Blocked Domains
        </h1>
        <p className="text-sm text-muted-foreground">
          Block malicious domains from being used in any user-generated content (articles, posts, comments, profiles, messages).
        </p>
      </div>

      {/* Top stat cards */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        <StatCard
          icon={<ShieldBan className="h-5 w-5" />}
          label="Blocked Domains"
          value={stats?.totalDomains ?? 0}
          loading={loading}
        />
        <StatCard
          icon={<CheckCircle2 className="h-5 w-5 text-green-500" />}
          label="Active Rules"
          value={stats?.activeRules ?? 0}
          loading={loading}
        />
        <StatCard
          icon={<Activity className="h-5 w-5 text-orange-500" />}
          label="Blocked Today"
          value={stats?.hitsToday ?? 0}
          loading={loading}
        />
        <StatCard
          icon={<Activity className="h-5 w-5 text-blue-500" />}
          label="Blocked This Week"
          value={stats?.hitsThisWeek ?? 0}
          loading={loading}
        />
      </div>

      {/* Tab switcher */}
      <div className="flex gap-2 border-b">
        <TabButton active={tab === "rules"} onClick={() => setTab("rules")}>
          Blocked Domains
        </TabButton>
        <TabButton active={tab === "activity"} onClick={() => setTab("activity")}>
          Blocked Activity
        </TabButton>
        <TabButton active={tab === "test"} onClick={() => setTab("test")}>
          Test URL
        </TabButton>
      </div>

      {tab === "rules" && (
        <RulesTab
          rules={rules}
          loading={loading}
          search={search}
          setSearch={setSearch}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          onAdd={() => setAddDialogOpen(true)}
          onEdit={(rule) => setEditingRule(rule)}
          onReload={load}
        />
      )}

      {tab === "activity" && <ActivityTab />}

      {tab === "test" && <TestUrlTab />}

      {/* Add Domain dialog */}
      <AddDomainDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onSaved={load}
      />

      {/* Edit Domain dialog */}
      <EditDomainDialog
        rule={editingRule}
        onOpenChange={(open) => !open && setEditingRule(null)}
        onSaved={load}
      />
    </div>
  );
}

// ── Stat Card ──────────────────────────────────────────────────────────

function StatCard({
  icon,
  label,
  value,
  loading,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  loading: boolean;
}) {
  return (
    <Card>
      <CardContent className="p-4 md:p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground md:text-sm">{label}</p>
            {loading ? (
              <Skeleton className="mt-1 h-7 w-12" />
            ) : (
              <p className="text-2xl font-bold tabular-nums md:text-3xl">{value}</p>
            )}
          </div>
          <div className="rounded-lg bg-muted p-2">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Tab Button ─────────────────────────────────────────────────────────

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`border-b-2 px-4 py-2 text-sm font-medium transition-colors ${
        active
          ? "border-primary text-primary"
          : "border-transparent text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

// ── Rules Tab ──────────────────────────────────────────────────────────

function RulesTab({
  rules,
  loading,
  search,
  setSearch,
  statusFilter,
  setStatusFilter,
  onAdd,
  onEdit,
  onReload,
}: {
  rules: BlockedDomainRule[];
  loading: boolean;
  search: string;
  setSearch: (s: string) => void;
  statusFilter: "all" | "active" | "disabled";
  setStatusFilter: (s: "all" | "active" | "disabled") => void;
  onAdd: () => void;
  onEdit: (rule: BlockedDomainRule) => void;
  onReload: () => void;
}) {
  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 gap-2">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search domains..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as "all" | "active" | "disabled")}
            className="h-9 rounded-md border border-input bg-background px-3 text-sm"
          >
            <option value="all">All</option>
            <option value="active">Active</option>
            <option value="disabled">Disabled</option>
          </select>
        </div>
        <Button onClick={onAdd}>
          <Plus className="mr-2 h-4 w-4" />
          Add Domain
        </Button>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-2 p-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : rules.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 p-12 text-center">
              <Globe className="h-10 w-10 text-muted-foreground" />
              <p className="text-sm font-medium">No blocked domains yet</p>
              <p className="text-xs text-muted-foreground">
                Add a domain to start blocking it across all user-generated content.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Domain</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Subdomains</TableHead>
                  <TableHead className="text-center">Hits</TableHead>
                  <TableHead>Created By</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rules.map((rule) => (
                  <BlockedDomainRow
                    key={rule.id}
                    rule={rule}
                    onEdit={() => onEdit(rule)}
                    onReload={onReload}
                  />
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ── Blocked Domain Row (with inline enable/disable + delete) ───────────

function BlockedDomainRow({
  rule,
  onEdit,
  onReload,
}: {
  rule: BlockedDomainRule;
  onEdit: () => void;
  onReload: () => void;
}) {
  const [toggling, setToggling] = useState(false);

  async function toggleActive() {
    setToggling(true);
    try {
      await api.patch(`/api/v1/admin/blocked-domains/${rule.id}`, {
        isActive: !rule.isActive,
      });
      toast.success(rule.isActive ? "Rule disabled." : "Rule enabled.");
      onReload();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to toggle rule.");
    } finally {
      setToggling(false);
    }
  }

  return (
    <TableRow>
      <TableCell className="font-mono text-sm">{rule.domain}</TableCell>
      <TableCell>
        {rule.isActive ? (
          <Badge className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400">
            BLOCKED
          </Badge>
        ) : (
          <Badge variant="secondary">DISABLED</Badge>
        )}
      </TableCell>
      <TableCell>
        {rule.blockSubdomains ? (
          <Badge variant="outline">*.domain</Badge>
        ) : (
          <Badge variant="outline">exact</Badge>
        )}
      </TableCell>
      <TableCell className="text-center tabular-nums">{rule.hitCount}</TableCell>
      <TableCell className="text-sm text-muted-foreground">
        {rule.creatorName ?? "—"}
      </TableCell>
      <TableCell className="text-sm text-muted-foreground">
        {new Date(rule.createdAt).toLocaleDateString()}
      </TableCell>
      <TableCell className="text-right">
        <div className="flex justify-end gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleActive}
            disabled={toggling}
          >
            {toggling ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : rule.isActive ? (
              <XCircle className="h-4 w-4" />
            ) : (
              <CheckCircle2 className="h-4 w-4" />
            )}
          </Button>
          <Button variant="ghost" size="sm" onClick={onEdit}>
            <Pencil className="h-4 w-4" />
          </Button>
          <DeleteDomainDialog rule={rule} onDeleted={onReload} />
        </div>
      </TableCell>
    </TableRow>
  );
}

// ── Delete Domain Dialog (with confirmation) ───────────────────────────

function DeleteDomainDialog({
  rule,
  onDeleted,
}: {
  rule: BlockedDomainRule;
  onDeleted: () => void;
}) {
  const [deleting, setDeleting] = useState(false);

  async function handleDelete() {
    setDeleting(true);
    try {
      await api.delete(`/api/v1/admin/blocked-domains/${rule.id}`);
      toast.success(`Domain "${rule.domain}" deleted.`);
      onDeleted();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to delete rule.");
    } finally {
      setDeleting(false);
    }
  }

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <Trash2 className="h-4 w-4 text-destructive" />
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete blocked domain?</AlertDialogTitle>
          <AlertDialogDescription>
            This will permanently delete the block rule for <strong>{rule.domain}</strong>.
            All {rule.hitCount} hit records will also be deleted.
            This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={deleting}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Delete Permanently"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

// ── Add Domain Dialog ──────────────────────────────────────────────────

function AddDomainDialog({
  open,
  onOpenChange,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
}) {
  const [domain, setDomain] = useState("");
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState("");
  const [blockSubdomains, setBlockSubdomains] = useState(true);
  const [isActive, setIsActive] = useState(true);
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    if (!domain.trim()) {
      toast.error("Domain is required.");
      return;
    }
    setSaving(true);
    try {
      await api.post("/api/v1/admin/blocked-domains", {
        domain,
        reason: reason || undefined,
        notes: notes || undefined,
        blockSubdomains,
        isActive,
      });
      toast.success("Domain blocked successfully.");
      setDomain("");
      setReason("");
      setNotes("");
      setBlockSubdomains(true);
      setIsActive(true);
      onOpenChange(false);
      onSaved();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to block domain.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Block Domain</DialogTitle>
          <DialogDescription>
            Add a domain to the global blocklist. URLs from this domain will be rejected in all user-generated content.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="block-domain">Domain</Label>
            <Input
              id="block-domain"
              placeholder="example.com"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              The domain will be normalized (lowercase, no protocol/port/www).
            </p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="block-reason">Reason (optional)</Label>
            <Input
              id="block-reason"
              placeholder="e.g. Phishing campaigns"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="block-notes">Notes (private, admin-only)</Label>
            <Textarea
              id="block-notes"
              placeholder="Internal notes about this rule..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label htmlFor="block-subdomains">Block subdomains</Label>
              <p className="text-xs text-muted-foreground">
                Also block www.example.com, cdn.example.com, etc.
              </p>
            </div>
            <Switch
              id="block-subdomains"
              checked={blockSubdomains}
              onCheckedChange={setBlockSubdomains}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label htmlFor="block-active">Active</Label>
              <p className="text-xs text-muted-foreground">
                When disabled, the rule exists but is not enforced.
              </p>
            </div>
            <Switch
              id="block-active"
              checked={isActive}
              onCheckedChange={setIsActive}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldBan className="mr-2 h-4 w-4" />}
            Block Domain
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Edit Domain Dialog ─────────────────────────────────────────────────

function EditDomainDialog({
  rule,
  onOpenChange,
  onSaved,
}: {
  rule: BlockedDomainRule | null;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
}) {
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState("");
  const [blockSubdomains, setBlockSubdomains] = useState(true);
  const [isActive, setIsActive] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (rule) {
      setReason(rule.reason ?? "");
      setNotes(rule.notes ?? "");
      setBlockSubdomains(rule.blockSubdomains);
      setIsActive(rule.isActive);
    }
  }, [rule]);

  async function handleSave() {
    if (!rule) return;
    setSaving(true);
    try {
      await api.patch(`/api/v1/admin/blocked-domains/${rule.id}`, {
        reason: reason || null,
        notes: notes || null,
        blockSubdomains,
        isActive,
      });
      toast.success("Rule updated.");
      onOpenChange(false);
      onSaved();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to update rule.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!rule} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Block Rule</DialogTitle>
          <DialogDescription>
            Update the rule for <strong className="font-mono">{rule?.domain}</strong>.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="edit-reason">Reason</Label>
            <Input
              id="edit-reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="edit-notes">Notes (private)</Label>
            <Textarea
              id="edit-notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label htmlFor="edit-subdomains">Block subdomains</Label>
              <p className="text-xs text-muted-foreground">
                Also block www., cdn., etc.
              </p>
            </div>
            <Switch
              id="edit-subdomains"
              checked={blockSubdomains}
              onCheckedChange={setBlockSubdomains}
            />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label htmlFor="edit-active">Active</Label>
              <p className="text-xs text-muted-foreground">
                Disabled rules are not enforced.
              </p>
            </div>
            <Switch
              id="edit-active"
              checked={isActive}
              onCheckedChange={setIsActive}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Activity Tab (Blocked Activity) ────────────────────────────────────

function ActivityTab() {
  const [hits, setHits] = useState<BlockedHit[]>([]);
  const [loading, setLoading] = useState(true);
  const [contextFilter, setContextFilter] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (contextFilter) params.set("context", contextFilter);
      const res = await api.get<{ hits: BlockedHit[] }>(
        `/api/v1/admin/blocked-domains/hits?${params.toString()}`
      );
      setHits(res.hits);
    } catch {
      toast.error("Failed to load blocked activity.");
    } finally {
      setLoading(false);
    }
  }, [contextFilter]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <select
          value={contextFilter}
          onChange={(e) => setContextFilter(e.target.value)}
          className="h-9 rounded-md border border-input bg-background px-3 text-sm"
        >
          <option value="">All contexts</option>
          <option value="ARTICLE">Article</option>
          <option value="POST">Post</option>
          <option value="COMMENT">Comment</option>
          <option value="REPLY">Reply</option>
          <option value="PROFILE">Profile</option>
          <option value="MESSAGE">Message</option>
          <option value="MEDIA">Media</option>
          <option value="OTHER">Other</option>
        </select>
      </div>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="space-y-2 p-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          ) : hits.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 p-12 text-center">
              <Activity className="h-10 w-10 text-muted-foreground" />
              <p className="text-sm font-medium">No blocked activity yet</p>
              <p className="text-xs text-muted-foreground">
                When a user tries to submit a blocked domain, it will appear here.
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Domain</TableHead>
                  <TableHead>Context</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Attempted URL</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {hits.map((hit) => (
                  <TableRow key={hit.id}>
                    <TableCell className="font-mono text-sm">{hit.domain}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{hit.context}</Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {hit.user ? hit.user.fullName : "Anonymous"}
                    </TableCell>
                    <TableCell className="max-w-xs truncate font-mono text-xs text-muted-foreground" title={hit.attemptedUrl}>
                      {hit.attemptedUrl}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(hit.createdAt).toLocaleString()}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ── Test URL Tab ───────────────────────────────────────────────────────

function TestUrlTab() {
  const [url, setUrl] = useState("");
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<{
    blocked: boolean;
    domain: string | null;
    rule?: { domain: string; normalizedDomain: string; reason: string | null };
    error?: string;
  } | null>(null);

  async function handleTest() {
    if (!url.trim()) return;
    setTesting(true);
    setResult(null);
    try {
      const res = await api.post<{
        blocked: boolean;
        domain: string | null;
        rule?: { domain: string; normalizedDomain: string; reason: string | null };
        error?: string;
      }>("/api/v1/admin/blocked-domains/test", { url });
      setResult(res);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Test failed.");
    } finally {
      setTesting(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FlaskConical className="h-5 w-5" />
            Test URL
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Check whether a URL would be blocked by the current blocklist rules.
            This does not record a hit — it&apos;s for verification only.
          </p>
          <div className="flex gap-2">
            <Input
              placeholder="https://example.com/video"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleTest()}
            />
            <Button onClick={handleTest} disabled={testing || !url.trim()}>
              {testing ? <Loader2 className="h-4 w-4 animate-spin" /> : "Test"}
            </Button>
          </div>

          {result && (
            <div className="rounded-lg border p-4">
              <div className="space-y-2">
                <div>
                  <span className="text-sm font-medium">Domain: </span>
                  <span className="font-mono text-sm">{result.domain ?? "—"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">Status:</span>
                  {result.blocked ? (
                    <Badge className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400">
                      🚫 BLOCKED
                    </Badge>
                  ) : (
                    <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                      ✅ ALLOWED
                    </Badge>
                  )}
                </div>
                {result.rule && (
                  <div>
                    <span className="text-sm font-medium">Matched rule: </span>
                    <span className="font-mono text-sm">{result.rule.normalizedDomain}</span>
                    {result.rule.reason && (
                      <p className="mt-1 text-xs text-muted-foreground">
                        Reason: {result.rule.reason}
                      </p>
                    )}
                  </div>
                )}
                {result.error && (
                  <p className="text-xs text-orange-500">{result.error}</p>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
