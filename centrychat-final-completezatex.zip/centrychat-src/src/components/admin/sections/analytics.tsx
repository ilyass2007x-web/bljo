"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber } from "@/lib/client/format";
import { toast } from "sonner";
import {
  Users, FileText, Heart, MessageCircle, Eye, Share2, TrendingUp,
  UserPlus, Activity, BarChart3, ArrowUp, ArrowDown, Minus,
} from "lucide-react";
import { cn } from "@/lib/utils";

type Range = "24h" | "7d" | "30d" | "90d" | "1y";
type GrowthMetric = "users" | "posts" | "articles" | "likes" | "comments" | "shares" | "views" | "follows";

interface AnalyticsData {
  range: string;
  users: {
    total: number; newInRange: number; newInPrev: number; activeRecently: number;
    growth: number | null; dailyBuckets: { date: string; count: number }[];
  } | null;
  content: {
    totalPosts: number; totalArticles: number; totalDrafts: number;
    postsInRange: number; articlesInRange: number;
    postsGrowth: number | null; articlesGrowth: number | null;
    postBuckets: { date: string; count: number }[];
    articleBuckets: { date: string; count: number }[];
  } | null;
  engagement: {
    likes: number; comments: number; shares: number; uniqueViews: number;
    postLikes: number; articleLikes: number; postComments: number; articleComments: number;
    postShares: number; articleShares: number; postViews: number; articleViews: number;
    engagementRate: number;
    likesGrowth: number | null; commentsGrowth: number | null;
    sharesGrowth: number | null; viewsGrowth: number | null;
    dailyBuckets: { date: string; count: number }[];
  } | null;
  follows: {
    newFollows: number; newFollowsPrev: number; growth: number | null;
    dailyBuckets: { date: string; count: number }[];
  } | null;
  topContent: {
    posts: { type: string; id: string; title: string; author: { fullName: string; username: string };
      createdAt: string; engagement: number; likes: number; comments: number; views: number }[];
    articles: { type: string; id: string; title: string; author: { fullName: string; username: string };
      coverImage: string | null; publishedAt: string | null; engagement: number; likes: number; comments: number; views: number }[];
  } | null;
  topCreators: { id: string; fullName: string; username: string; isVerified: boolean; role: string;
    postsInPeriod: number; articlesInPeriod: number; followers: number; activity: number }[] | null;
  postsVsArticles: {
    posts: { likes: number; comments: number; shares: number; views: number };
    articles: { likes: number; comments: number; shares: number; views: number };
  } | null;
}

export function AdminAnalytics() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState<Range>("30d");
  const [growthMetric, setGrowthMetric] = useState<GrowthMetric>("users");

  const fetch = useCallback(async (r: Range) => {
    setLoading(true);
    try {
      const res = await api.get<{ analytics: AnalyticsData }>(`/api/v1/admin/analytics?range=${r}`);
      setData(res.analytics);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load analytics.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void fetch(range); }, [range, fetch]);

  // Get growth chart data based on selected metric.
  const growthData = (() => {
    if (!data) return [];
    switch (growthMetric) {
      case "users": return data.users?.dailyBuckets ?? [];
      case "posts": return data.content?.postBuckets ?? [];
      case "articles": return data.content?.articleBuckets ?? [];
      case "likes": case "comments": case "shares": return data.engagement?.dailyBuckets ?? [];
      case "views": return []; // views don't have daily buckets in this iteration
      case "follows": return data.follows?.dailyBuckets ?? [];
      default: return [];
    }
  })();

  return (
    <div className="space-y-6">
      {/* Header + Range Selector */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Analytics Center</h2>
          <p className="text-sm text-muted-foreground">Complete platform analytics. All numbers come from real database data.</p>
        </div>
        <div className="flex flex-wrap gap-1 rounded-lg border bg-muted/30 p-1">
          {(["24h", "7d", "30d", "90d", "1y"] as Range[]).map(r => (
            <button key={r} onClick={() => setRange(r)}
              className={cn("rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                range === r ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>
              {r === "24h" ? "24 Hours" : r === "7d" ? "7 Days" : r === "30d" ? "30 Days" : r === "90d" ? "90 Days" : "1 Year"}
            </button>
          ))}
        </div>
      </div>

      {/* ── User Metrics (spec §3) ──────────────────────────────── */}
      <Section title="User Analytics" icon={Users}>
        {data?.users ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <MetricCard label="Total Users" value={data.users.total} />
            <MetricCard label="New Users" value={data.users.newInRange} growth={data.users.growth} />
            <MetricCard label="Active (15m)" value={data.users.activeRecently} sub="Proxy via lastSeenAt" />
            <MetricCard label="Previous Period" value={data.users.newInPrev} sub="For comparison" />
          </div>
        ) : <SectionError />}
      </Section>

      {/* ── Content Metrics (spec §4) ───────────────────────────── */}
      <Section title="Content Analytics" icon={FileText}>
        {data?.content ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <MetricCard label="Total Posts" value={data.content.totalPosts} />
            <MetricCard label="Published Articles" value={data.content.totalArticles} />
            <MetricCard label="Draft Articles" value={data.content.totalDrafts} />
            <MetricCard label="New Posts" value={data.content.postsInRange} growth={data.content.postsGrowth} />
            <MetricCard label="New Articles" value={data.content.articlesInRange} growth={data.content.articlesGrowth} />
          </div>
        ) : <SectionError />}
      </Section>

      {/* ── Engagement Metrics (spec §5, §6) ────────────────────── */}
      <Section title="Engagement Analytics" icon={Heart}>
        {data?.engagement ? (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-5">
              <MetricCard label="Likes" value={data.engagement.likes} growth={data.engagement.likesGrowth} icon={Heart} color="text-red-500" />
              <MetricCard label="Comments" value={data.engagement.comments} growth={data.engagement.commentsGrowth} icon={MessageCircle} color="text-sky-500" />
              <MetricCard label="Shares" value={data.engagement.shares} growth={data.engagement.sharesGrowth} icon={Share2} color="text-teal-500" />
              <MetricCard label="Unique Views" value={data.engagement.uniqueViews} growth={data.engagement.viewsGrowth} icon={Eye} color="text-amber-500" />
              <MetricCard label="Eng. Rate" value={data.engagement.engagementRate} suffix="%" icon={TrendingUp} color="text-primary" />
            </div>
            {/* Posts vs Articles (spec §14) */}
            {data.postsVsArticles && (
              <div className="mt-4 rounded-lg border p-3">
                <p className="mb-3 text-sm font-medium">Posts vs Articles Comparison</p>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Badge variant="outline" className="mb-2">Posts</Badge>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <span>Likes: {formatNumber(data.postsVsArticles.posts.likes)}</span>
                      <span>Comments: {formatNumber(data.postsVsArticles.posts.comments)}</span>
                      <span>Shares: {formatNumber(data.postsVsArticles.posts.shares)}</span>
                      <span>Views: {formatNumber(data.postsVsArticles.posts.views)}</span>
                    </div>
                  </div>
                  <div>
                    <Badge variant="outline" className="mb-2">Articles</Badge>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <span>Likes: {formatNumber(data.postsVsArticles.articles.likes)}</span>
                      <span>Comments: {formatNumber(data.postsVsArticles.articles.comments)}</span>
                      <span>Shares: {formatNumber(data.postsVsArticles.articles.shares)}</span>
                      <span>Views: {formatNumber(data.postsVsArticles.articles.views)}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        ) : <SectionError />}
      </Section>

      {/* ── Follow Metrics (spec §9) ─────────────────────────────── */}
      <Section title="Follow Analytics" icon={UserPlus}>
        {data?.follows ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <MetricCard label="New Follows" value={data.follows.newFollows} growth={data.follows.growth} />
            <MetricCard label="Previous Period" value={data.follows.newFollowsPrev} sub="For comparison" />
          </div>
        ) : <SectionError />}
      </Section>

      {/* ── Growth Chart (spec §11) ──────────────────────────────── */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <div>
            <CardTitle className="text-sm font-semibold">Growth Chart</CardTitle>
            <p className="text-xs text-muted-foreground">Daily trends over the selected period.</p>
          </div>
          <div className="flex gap-1 rounded-lg border bg-muted/30 p-1 flex-wrap">
            {(["users", "posts", "articles", "likes", "comments", "shares", "follows"] as GrowthMetric[]).map(m => (
              <button key={m} onClick={() => setGrowthMetric(m)}
                className={cn("rounded-md px-2 py-1 text-xs font-medium capitalize transition-colors",
                  growthMetric === m ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>
                {m}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <Skeleton className="h-48 w-full rounded-lg" />
          ) : growthData.length === 0 ? (
            <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">No data for this metric in this period.</div>
          ) : (
            <MiniChart data={growthData} />
          )}
        </CardContent>
      </Card>

      {/* ── Top Content (spec §7) ───────────────────────────────── */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Section title="Top Posts" icon={BarChart3}>
          {data?.topContent && data.topContent.posts.length > 0 ? (
            <div className="space-y-2">
              {data.topContent.posts.map((p, i) => (
                <div key={p.id} className="flex items-center gap-2 rounded-lg border p-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-muted text-[10px] font-bold">{i + 1}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-medium" dir="auto">{p.title}</p>
                    <p className="truncate text-[10px] text-muted-foreground">by {p.author.fullName}</p>
                  </div>
                  <div className="flex shrink-0 gap-2 text-[10px] text-muted-foreground">
                    <span>❤️ {p.likes}</span><span>💬 {p.comments}</span><span>👁️ {p.views}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : <EmptyState text="No posts in this period." />}
        </Section>

        <Section title="Top Articles" icon={BarChart3}>
          {data?.topContent && data.topContent.articles.length > 0 ? (
            <div className="space-y-2">
              {data.topContent.articles.map((a, i) => (
                <div key={a.id} className="flex items-center gap-2 rounded-lg border p-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-muted text-[10px] font-bold">{i + 1}</span>
                  {a.coverImage && <img src={a.coverImage} alt="" className="h-8 w-8 shrink-0 rounded object-cover" loading="lazy" />}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-medium" dir="auto">{a.title}</p>
                    <p className="truncate text-[10px] text-muted-foreground">by {a.author.fullName}</p>
                  </div>
                  <div className="flex shrink-0 gap-2 text-[10px] text-muted-foreground">
                    <span>❤️ {a.likes}</span><span>💬 {a.comments}</span><span>👁️ {a.views}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : <EmptyState text="No articles in this period." />}
        </Section>
      </div>

      {/* ── Top Creators (spec §8) ──────────────────────────────── */}
      <Section title="Top Creators" icon={Users}>
        {data?.topCreators && data.topCreators.length > 0 ? (
          <div className="space-y-2">
            {data.topCreators.map((c, i) => (
              <div key={c.id} className="flex items-center gap-2 rounded-lg border p-2">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-muted text-[10px] font-bold">{i + 1}</span>
                <Avatar name={c.fullName} size="sm" className="h-6 w-6 text-[10px]" />
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-1 truncate text-xs font-medium">
                    {c.fullName}{c.isVerified && <VerifiedBadge size={10} />}
                  </p>
                  <p className="truncate text-[10px] text-muted-foreground">@{c.username}</p>
                </div>
                <div className="flex shrink-0 gap-2 text-[10px] text-muted-foreground">
                  <span>📝 {c.postsInPeriod}</span>
                  <span>📖 {c.articlesInPeriod}</span>
                  <span>👥 {c.followers}</span>
                </div>
              </div>
            ))}
          </div>
        ) : <EmptyState text="No creator activity in this period." />}
      </Section>

      {/* Data accuracy notice (spec §25) */}
      <p className="text-center text-[10px] text-muted-foreground">
        All metrics come from real database data. Active users uses lastSeenAt as a proxy. Traffic source analytics not available.
      </p>
    </div>
  );
}

// ── Sub-components ──────────────────────────────────────────────────────────

function Section({ title, icon: Icon, children }: { title: string; icon: React.ComponentType<{ className?: string }>; children: React.ReactNode }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm font-semibold">
          <Icon className="h-4 w-4 text-muted-foreground" /> {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {children}
      </CardContent>
    </Card>
  );
}

function MetricCard({ label, value, growth, sub, suffix, icon: Icon, color }: {
  label: string; value: number; growth?: number | null; sub?: string; suffix?: string;
  icon?: React.ComponentType<{ className?: string }>; color?: string;
}) {
  return (
    <div className="rounded-lg border p-3">
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-medium text-muted-foreground">{label}</p>
        {Icon && <Icon className={cn("h-3.5 w-3.5", color ?? "text-muted-foreground")} />}
      </div>
      <p className="mt-1 text-xl font-bold">{formatNumber(value)}{suffix}</p>
      {growth !== undefined && growth !== null && (
        <p className={cn("mt-0.5 flex items-center gap-0.5 text-[10px]",
          growth > 0 ? "text-green-600 dark:text-green-400" : growth < 0 ? "text-destructive" : "text-muted-foreground")}>
          {growth > 0 ? <ArrowUp className="h-2.5 w-2.5" /> : growth < 0 ? <ArrowDown className="h-2.5 w-2.5" /> : <Minus className="h-2.5 w-2.5" />}
          {Math.abs(growth)}% vs prev
        </p>
      )}
      {growth === null && (
        <p className="mt-0.5 text-[10px] text-muted-foreground">No comparison available</p>
      )}
      {sub && <p className="mt-0.5 text-[10px] text-muted-foreground">{sub}</p>}
    </div>
  );
}

function SectionError() {
  return <p className="py-4 text-center text-sm text-destructive">Unable to load this section.</p>;
}

function EmptyState({ text }: { text: string }) {
  return <p className="py-6 text-center text-sm text-muted-foreground">{text}</p>;
}

/** Lightweight inline SVG line chart (no external library — spec §11). */
function MiniChart({ data }: { data: { date: string; count: number }[] }) {
  const values = data.map(d => d.count);
  const maxVal = Math.max(1, ...values);
  const width = 600;
  const height = 200;
  const pad = 30;

  const points = data.map((d, i) => {
    const x = pad + (i / Math.max(1, data.length - 1)) * (width - 2 * pad);
    const y = height - pad - (d.count / maxVal) * (height - 2 * pad);
    return { x, y, value: d.count, date: d.date };
  });

  const pathD = points.length > 0
    ? points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ")
    : "";

  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ minWidth: 300, height: 200 }}>
        {[0, 0.25, 0.5, 0.75, 1].map(ratio => {
          const y = height - pad - ratio * (height - 2 * pad);
          const val = Math.round(maxVal * ratio);
          return (
            <g key={ratio}>
              <line x1={pad} y1={y} x2={width - pad} y2={y} stroke="currentColor" strokeWidth={0.5} className="text-border" />
              <text x={pad - 5} y={y + 3} textAnchor="end" fontSize={9} className="text-muted-foreground">{val}</text>
            </g>
          );
        })}
        {pathD && (
          <>
            <path d={`${pathD} L ${(points[points.length-1]!.x).toFixed(1)} ${height-pad} L ${pad} ${height-pad} Z`} fill="currentColor" className="text-primary/10" />
            <path d={pathD} fill="none" stroke="currentColor" strokeWidth={2} className="text-primary" />
            {points.length <= 31 && points.map((p, i) => (
              <circle key={i} cx={p.x} cy={p.y} r={2} fill="currentColor" className="text-primary" />
            ))}
          </>
        )}
        {data.length > 0 && (
          <>
            <text x={pad} y={height - 8} textAnchor="start" fontSize={9} className="text-muted-foreground">{data[0]!.date}</text>
            <text x={width - pad} y={height - 8} textAnchor="end" fontSize={9} className="text-muted-foreground">{data[data.length-1]!.date}</text>
          </>
        )}
      </svg>
    </div>
  );
}
