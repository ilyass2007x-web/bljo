"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import { Mail, Loader2, Send, CheckCircle2, AlertCircle } from "lucide-react";

interface EmailStatus {
  provider: string;
  configured: boolean;
  customSender: boolean;
  hint: string;
}

/**
 * AdminEmail — Resend integration status + test-email sender.
 *
 * Lets the admin:
 *  1. See if RESEND_API_KEY is configured (without revealing the key).
 *  2. See if RESEND_FROM_EMAIL is set (without revealing the address).
 *  3. Send a test email to a recipient address to verify Resend works.
 *
 * All actions go through the server-side /api/v1/admin/email/* endpoints.
 * The browser NEVER touches RESEND_API_KEY directly.
 */
export function AdminEmail() {
  const [status, setStatus] = useState<EmailStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [recipient, setRecipient] = useState("");
  const [sending, setSending] = useState(false);

  async function loadStatus() {
    setLoading(true);
    try {
      const data = await api.get<{ data: EmailStatus }>("/api/v1/admin/email/status");
      // The api wrapper returns { ok, data } — but the api helper already
      // unwraps it to `data`. So the result IS the `data` field.
      setStatus(data.data ?? (data as unknown as EmailStatus));
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load email status");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadStatus();
  }, []);

  async function sendTest() {
    if (!recipient.trim()) {
      toast.error("Enter a recipient email address");
      return;
    }
    setSending(true);
    try {
      const result = await api.post<{ sent: boolean; to: string; provider: string }>(
        "/api/v1/admin/email/test",
        { to: recipient.trim().toLowerCase() }
      );
      toast.success(`Test email sent to ${result.to} via ${result.provider}.`);
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to send test email";
      toast.error(msg);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Status card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email Service
          </CardTitle>
          <CardDescription>
            Resend integration status. The API key is read server-side only — it is never
            exposed to the browser.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {loading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Loading…
            </div>
          ) : status ? (
            <>
              <div className="flex items-center justify-between gap-3">
                <span className="text-sm">Provider</span>
                <Badge variant="secondary">{status.provider}</Badge>
              </div>
              <div className="flex items-center justify-between gap-3">
                <span className="text-sm">API key configured</span>
                {status.provider === "resend" ? (
                  status.configured ? (
                    <Badge className="gap-1 bg-emerald-600 hover:bg-emerald-600">
                      <CheckCircle2 className="h-3 w-3" /> Yes
                    </Badge>
                  ) : (
                    <Badge variant="destructive" className="gap-1">
                      <AlertCircle className="h-3 w-3" /> No
                    </Badge>
                  )
                ) : (
                  <Badge variant="outline">N/A</Badge>
                )}
              </div>
              <div className="flex items-center justify-between gap-3">
                <span className="text-sm">Custom sender (RESEND_FROM_EMAIL)</span>
                <Badge variant={status.customSender ? "default" : "outline"}>
                  {status.customSender ? "Set" : "Default (onboarding@resend.dev)"}
                </Badge>
              </div>
              <p className="rounded-md bg-muted p-3 text-xs text-muted-foreground">
                {status.hint}
              </p>
            </>
          ) : (
            <p className="text-sm text-muted-foreground">Failed to load status.</p>
          )}
        </CardContent>
      </Card>

      {/* Test email card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="h-4 w-4" />
            Send Test Email
          </CardTitle>
          <CardDescription>
            Sends a simple email to the recipient address through the configured provider.
            Rate-limited to 5 sends per 5 minutes per admin.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2">
            <Label htmlFor="test-recipient">Recipient email</Label>
            <Input
              id="test-recipient"
              type="email"
              placeholder="you@example.com"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              autoComplete="off"
            />
            <p className="text-xs text-muted-foreground">
              The sender address is controlled by the server (RESEND_FROM_EMAIL).
              The recipient must be supplied by you, but cannot influence the sender.
            </p>
          </div>
          <Button onClick={sendTest} disabled={sending || !recipient.trim()}>
            {sending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending…
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4 rtl-flip" />
                Send test email
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
