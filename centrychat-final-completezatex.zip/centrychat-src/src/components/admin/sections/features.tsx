"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { Loader2 } from "lucide-react";

interface Flag {
  key: string;
  enabled: boolean;
  configuration: string | null;
  updatedAt: string | null;
}

const FLAG_LABELS: Record<string, { label: string; description: string }> = {
  messaging: { label: "Messaging", description: "Enable/disable sending messages." },
  search: { label: "User Search", description: "Allow searching for other users." },
  notifications: { label: "Notifications", description: "In-app notification delivery." },
  read_receipts: { label: "Read Receipts", description: "Show read status on messages." },
  email_verification: { label: "Email Verification", description: "Require email verification before messaging." },
  reports: { label: "Reports", description: "Allow users to submit reports." },
  dark_mode: { label: "Dark Mode", description: "Allow theme switching." },
  registration: { label: "Registration", description: "Allow new user self-registration." },
  // Video Chat — also exposed via the dedicated Admin → Video Chat section
  // (with a prominent master toggle at the top of the Overview tab). Listed
  // here too so admins browsing the Feature Flags page can find it.
  video_chat: {
    label: "Video Chat",
    description:
      "Master switch for the Video Chat feature. When OFF, all video chat API routes return 403 + users see \"Video chat is not enabled. An administrator must enable it from the admin panel.\" Also configurable from Admin → Video Chat → Overview.",
  },
};

export function AdminFeatures() {
  const [flags, setFlags] = useState<Flag[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);

  async function load() {
    try {
      const data = await api.get<{ flags: Flag[] }>("/api/v1/admin/features");
      setFlags(data.flags);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load features");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  async function toggle(key: string, enabled: boolean) {
    setUpdating(key);
    try {
      const data = await api.put<{ flags: Flag[] }>("/api/v1/admin/features", { key, enabled });
      setFlags(data.flags);
      toast.success(`Feature "${key}" ${enabled ? "enabled" : "disabled"}`);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update feature");
    } finally {
      setUpdating(null);
    }
  }

  if (loading) return <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Feature Flags</h2>
        <p className="text-sm text-muted-foreground">Toggle platform features on or off. Changes take effect within 30 seconds (cache).</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {flags.map((f) => {
          const meta = FLAG_LABELS[f.key] ?? { label: f.key, description: "" };
          return (
            <Card key={f.key}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <div>
                  <CardTitle className="text-base">{meta.label}</CardTitle>
                  <CardDescription className="mt-1">{meta.description}</CardDescription>
                </div>
                <Switch
                  checked={f.enabled}
                  onCheckedChange={(v) => toggle(f.key, v)}
                  disabled={updating === f.key}
                />
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <Badge variant="outline">{f.enabled ? "ON" : "OFF"}</Badge>
                  {f.updatedAt && <span>Updated {new Date(f.updatedAt).toLocaleDateString()}</span>}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
