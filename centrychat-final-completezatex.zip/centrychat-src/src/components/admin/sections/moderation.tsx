"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber, formatRelativeTime, formatDateTime } from "@/lib/client/format";
import { toast } from "sonner";
import {
  Search, Flag, ShieldBan, UserCheck, Eye, CheckCircle, XCircle,
  Loader2, AlertTriangle, MessageSquareX, FileText, TrendingUp,
  Clock, ChevronLeft, ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ── Types ──────────────────────────────────────────────────────────────────

interface ReportItem {
  id: string;
  reason: string;
  description: string;
  status: string;
  priority: string;
  assignedToId: string | null;
  notes: string | null;
  resolutionNote: string | null;
  createdAt: string;
  resolvedAt: string | null;
  reporter: { id: string; fullName: string; username: string; avatarColor: string | null; avatarUrl: string | null; isVerified: boolean } | null;
  target: { id: string; fullName: string; username: string; avatarColor: string | null; avatarUrl: string | null; isVerified: boolean; status: string; role: string } | null;
  targetUserId: string | null;
  targetMessageId: string | null;
  targetPostId: string | null;
  targetArticleId: string | null;
  targetCommentId: string | null;
}

interface ReportStats {
  pending: number; today: number; thisWeek: number;
  resolved: number; rejected: number; avgResolutionHours: number;
  reportsByReason: { reason: string; count: number }[];
}

interface ReportDetail {
  report: any;
  reportedMessage: any;
  previousReports: any[];
  totalReportsAgainstUser: number;
}

type StatusFilter = "" | "OPEN" | "INVESTIGATING" | "RESOLVED" | "DISMISSED" | "HIGH_PRIORITY";

// ── Component ──────────────────────────────────────────────────────────────

export function AdminModeration() {
  const router = useRouter();
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [stats, setStats] = useState<ReportStats | null>(null);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [inputQ, setInputQ] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("");
  const [sortBy, setSortBy] = useState("newest");
  const [selectedReport, setSelectedReport] = useState<ReportItem | null>(null);
  const [detail, setDetail] = useState<ReportDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [actionDialog, setActionDialog] = useState<{ reportId: string; action: string; title: string } | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [notesDraft, setNotesDraft] = useState("");
  const [priorityDraft, setPriorityDraft] = useState("");

  // Debounced search.
  useEffect(() => {
    const t = setTimeout(() => { setQ(inputQ); setPage(1); }, 300);
    return () => clearTimeout(t);
  }, [inputQ]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), pageSize: String(pageSize), sortBy });
      if (q) params.set("q", q);
      if (statusFilter === "HIGH_PRIORITY") {
        params.set("priority", "HIGH");
      } else if (statusFilter) {
        params.set("status", statusFilter);
      }
      const data = await api.get<{ reports: ReportItem[]; pagination: { total: number }; stats: ReportStats }>(`/api/v1/admin/reports?${params}`);
      setReports(data.reports);
      setTotal(data.pagination.total);
      setStats(data.stats);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load reports. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, q, statusFilter, sortBy]);

  useEffect(() => { void load(); }, [load]);

  async function viewReport(r: ReportItem) {
    setSelectedReport(r);
    setDetail(null);
    setNotesDraft(r.notes ?? "");
    setPriorityDraft(r.priority);
    setDetailLoading(true);
    try {
      const data = await api.get<ReportDetail>(`/api/v1/admin/reports/${r.id}`);
      setDetail(data);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load report details");
    } finally {
      setDetailLoading(false);
    }
  }

  async function performAction() {
    if (!actionDialog) return;
    setActionLoading(true);
    try {
      await api.post(`/api/v1/admin/reports/${actionDialog.reportId}`, { action: actionDialog.action });
      toast.success(`Action "${actionDialog.action}" applied`);
      setActionDialog(null);
      void load();
      setSelectedReport(null);
      setDetail(null);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Action failed");
    } finally {
      setActionLoading(false);
    }
  }

  async function saveNotes() {
    if (!selectedReport) return;
    try {
      await api.patch(`/api/v1/admin/reports/${selectedReport.id}`, { notes: notesDraft });
      toast.success("Notes saved");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to save notes");
    }
  }

  async function savePriority() {
    if (!selectedReport) return;
    try {
      await api.patch(`/api/v1/admin/reports/${selectedReport.id}`, { priority: priorityDraft });
      toast.success("Priority updated");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update priority");
    }
  }

  const totalPages = Math.ceil(total / pageSize);

  const statusOptions: { value: StatusFilter; label: string; color?: string }[] = [
    { value: "", label: "All Reports" },
    { value: "OPEN", label: "Pending" },
    { value: "INVESTIGATING", label: "Under Review" },
    { value: "RESOLVED", label: "Resolved" },
    { value: "DISMISSED", label: "Rejected" },
    { value: "HIGH_PRIORITY", label: "High Priority" },
  ];

  function statusLabel(s: string): string {
    return s === "OPEN" ? "Pending" : s === "INVESTIGATING" ? "Under Review" : s === "RESOLVED" ? "Resolved" : s === "DISMISSED" ? "Rejected" : s;
  }

  function statusBadgeVariant(s: string): "default" | "secondary" | "destructive" | "outline" {
    return s === "OPEN" ? "default" : s === "INVESTIGATING" ? "secondary" : s === "RESOLVED" ? "outline" : s === "DISMISSED" ? "destructive" : "outline";
  }

  function priorityBadgeVariant(p: string): "default" | "secondary" | "destructive" | "outline" {
    return p === "CRITICAL" ? "destructive" : p === "HIGH" ? "default" : p === "NORMAL" ? "secondary" : "outline";
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Moderation & Reports Center</h2>
        <p className="text-sm text-muted-foreground">Review and resolve user-submitted reports.</p>
      </div>

      {/* Statistics (spec §15, §16) */}
      {stats && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <StatCard label="Pending" value={stats.pending} icon={Flag} color="text-amber-500" />
          <StatCard label="Today" value={stats.today} icon={Clock} color="text-blue-500" />
          <StatCard label="This Week" value={stats.thisWeek} icon={Clock} color="text-sky-500" />
          <StatCard label="Resolved" value={stats.resolved} icon={CheckCircle} color="text-green-500" />
          <StatCard label="Rejected" value={stats.rejected} icon={XCircle} color="text-red-500" />
          <StatCard label="Avg Resolve" value={stats.avgResolutionHours} suffix="h" icon={TrendingUp} color="text-purple-500" />
        </div>
      )}

      {/* Search + Filters */}
      <Card className="p-4">
        <div className="flex flex-wrap gap-2">
          <div className="relative min-w-48 flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search report ID, username, reason…" value={inputQ} onChange={(e) => setInputQ(e.target.value)} className="pl-8" />
          </div>
          <div className="flex gap-1 rounded-lg border bg-muted/30 p-1 flex-wrap">
            {statusOptions.map((s) => (
              <button key={s.value || "all"} onClick={() => { setStatusFilter(s.value); setPage(1); }}
                className={cn("rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                  statusFilter === s.value ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>
                {s.label}
              </button>
            ))}
          </div>
          <Select value={sortBy} onValueChange={(v) => { setSortBy(v); setPage(1); }}>
            <SelectTrigger className="w-32"><SelectValue placeholder="Sort" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="oldest">Oldest</SelectItem>
              <SelectItem value="priority">Priority</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Report list */}
      <Card>
        {loading ? (
          <div className="space-y-2 p-4">
            {[0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-16 w-full rounded-lg" />)}
          </div>
        ) : reports.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
            <CheckCircle className="h-10 w-10 text-green-500/50" />
            <p className="text-sm font-medium">No reports require attention.</p>
            <p className="max-w-sm text-xs text-muted-foreground">All clear! When users submit reports, they'll appear here for review.</p>
          </div>
        ) : (
          <div className="divide-y divide-border/60">
            {reports.map((r) => (
              <div key={r.id} className="flex items-start gap-3 p-4 hover:bg-accent/30">
                <div className="min-w-0 flex-1">
                  {/* Badges */}
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant={statusBadgeVariant(r.status)} className="text-[10px]">{statusLabel(r.status)}</Badge>
                    <Badge variant={priorityBadgeVariant(r.priority)} className="text-[10px]">{r.priority}</Badge>
                    <Badge variant="outline" className="text-[10px]">{r.reason}</Badge>
                  </div>
                  {/* Target */}
                  <div className="mt-2 flex items-center gap-2">
                    {r.target ? (
                      <button onClick={() => router.push(`/?view=admin&section=users`)} className="flex items-center gap-1.5 text-xs hover:underline">
                        <Avatar name={r.target.fullName} color={r.target.avatarColor} src={r.target.avatarUrl} size="sm" className="h-5 w-5 text-[9px]" />
                        <span className="truncate">{r.target.fullName}</span>
                        {r.target.isVerified && <VerifiedBadge size={10} />}
                        <span className="truncate text-muted-foreground">@{r.target.username}</span>
                      </button>
                    ) : r.targetMessageId ? (
                      <span className="text-xs text-muted-foreground">Reported message</span>
                    ) : (
                      <span className="text-xs text-muted-foreground">Unknown target</span>
                    )}
                    <span className="text-xs text-muted-foreground">· {formatRelativeTime(r.createdAt)}</span>
                  </div>
                  {/* Description preview */}
                  {r.description && (
                    <p className="mt-1 line-clamp-1 text-xs text-muted-foreground" dir="auto">{r.description}</p>
                  )}
                </div>
                <Button size="sm" variant="ghost" onClick={() => viewReport(r)}>Review</Button>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t p-3">
            <p className="text-xs text-muted-foreground">Page {page} of {totalPages} · {total} reports</p>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* ── Report detail dialog (spec §5, §6) ─────────────────────── */}
      <Dialog open={!!selectedReport} onOpenChange={(o) => !o && (setSelectedReport(null), setDetail(null))}>
        <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
          {selectedReport && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Flag className="h-4 w-4" />
                  Report {selectedReport.id.slice(0, 8)}
                </DialogTitle>
              </DialogHeader>

              {detailLoading ? (
                <div className="space-y-3 py-4">
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-32 w-full" />
                </div>
              ) : detail ? (
                <div className="space-y-4">
                  {/* Status + priority + reason */}
                  <div className="flex flex-wrap gap-2">
                    <Badge variant={statusBadgeVariant(selectedReport.status)}>{statusLabel(selectedReport.status)}</Badge>
                    <Badge variant={priorityBadgeVariant(selectedReport.priority)}>{selectedReport.priority}</Badge>
                    <Badge variant="outline">{selectedReport.reason}</Badge>
                    {selectedReport.targetMessageId && <Badge variant="outline">Message Report</Badge>}
                  </div>

                  {/* Description */}
                  {selectedReport.description && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">Report Description</p>
                      <p className="mt-1 rounded-lg border p-3 text-sm" dir="auto">{selectedReport.description}</p>
                    </div>
                  )}

                  {/* Content preview (spec §6) */}
                  {detail.reportedMessage && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">Reported Message</p>
                      <div className="mt-1 rounded-lg border border-amber-500/30 bg-amber-500/5 p-3">
                        <p className="text-sm" dir="auto">{detail.reportedMessage.content}</p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          From {detail.reportedMessage.sender?.fullName} · {formatRelativeTime(detail.reportedMessage.createdAt)}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Reporter (spec §11 — admin-only) */}
                  {selectedReport.reporter && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">Reporter (admin-only — never shown to reported user)</p>
                      <div className="mt-1 flex items-center gap-2 rounded-lg border p-2">
                        <Avatar name={selectedReport.reporter.fullName} color={selectedReport.reporter.avatarColor} src={selectedReport.reporter.avatarUrl} size="sm" />
                        <div>
                          <p className="text-sm font-medium">{selectedReport.reporter.fullName}</p>
                          <p className="text-xs text-muted-foreground">@{selectedReport.reporter.username}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Target user info */}
                  {selectedReport.target && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">Reported User</p>
                      <div className="mt-1 flex items-center justify-between rounded-lg border p-2">
                        <div className="flex items-center gap-2">
                          <Avatar name={selectedReport.target.fullName} color={selectedReport.target.avatarColor} src={selectedReport.target.avatarUrl} size="sm" />
                          <div>
                            <p className="flex items-center gap-1 text-sm font-medium">
                              {selectedReport.target.fullName}
                              {selectedReport.target.isVerified && <VerifiedBadge size={12} />}
                            </p>
                            <p className="text-xs text-muted-foreground">@{selectedReport.target.username} · {selectedReport.target.status}</p>
                          </div>
                        </div>
                        <Button size="sm" variant="ghost" onClick={() => router.push(`/?view=admin&section=users`)}>
                          View User
                        </Button>
                      </div>
                      {detail.totalReportsAgainstUser > 0 && (
                        <p className="mt-2 text-xs text-amber-600 dark:text-amber-400">
                          ⚠ {detail.totalReportsAgainstUser} previous report(s) against this user (spec §9 — requires human review, does NOT auto-ban)
                        </p>
                      )}
                    </div>
                  )}

                  {/* Previous reports (spec §9) */}
                  {detail.previousReports.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">Previous Reports ({detail.totalReportsAgainstUser})</p>
                      <div className="mt-1 space-y-1">
                        {detail.previousReports.map((pr) => (
                          <div key={pr.id} className="flex items-center justify-between rounded border p-2 text-xs">
                            <span>{pr.reason}</span>
                            <Badge variant={statusBadgeVariant(pr.status)} className="text-[10px]">{statusLabel(pr.status)}</Badge>
                            <span className="text-muted-foreground">{formatRelativeTime(pr.createdAt)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Priority selector (spec §13) */}
                  <div className="flex items-end gap-2">
                    <div className="flex-1">
                      <Label className="text-xs">Priority</Label>
                      <Select value={priorityDraft} onValueChange={setPriorityDraft}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="LOW">Low</SelectItem>
                          <SelectItem value="NORMAL">Normal</SelectItem>
                          <SelectItem value="HIGH">High</SelectItem>
                          <SelectItem value="CRITICAL">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button size="sm" variant="outline" onClick={savePriority}>Set</Button>
                  </div>

                  {/* Internal notes (spec §18 — NEVER public) */}
                  <div>
                    <Label className="text-xs">Internal Notes (never visible to users)</Label>
                    <Textarea
                      value={notesDraft}
                      onChange={(e) => setNotesDraft(e.target.value)}
                      placeholder="Add internal moderation notes…"
                      rows={3}
                      maxLength={2000}
                      className="mt-1"
                    />
                    <Button size="sm" variant="outline" className="mt-1" onClick={saveNotes}>Save Notes</Button>
                  </div>

                  {/* Resolution note */}
                  {selectedReport.resolutionNote && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground">Resolution Note</p>
                      <p className="mt-1 rounded-lg border p-2 text-sm">{selectedReport.resolutionNote}</p>
                    </div>
                  )}

                  {/* Metadata */}
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div><p className="text-xs text-muted-foreground">Created</p><p>{formatDateTime(selectedReport.createdAt)}</p></div>
                    {selectedReport.resolvedAt && (
                      <div><p className="text-xs text-muted-foreground">Resolved</p><p>{formatDateTime(selectedReport.resolvedAt)}</p></div>
                    )}
                  </div>

                  {/* Moderation actions (spec §7, §8) */}
                  <div className="flex flex-wrap gap-2 border-t pt-4">
                    {selectedReport.status !== "RESOLVED" && (
                      <Button size="sm" variant="outline" onClick={() => setActionDialog({ reportId: selectedReport.id, action: "REVIEW", title: "Mark Under Review" })}>
                        <Eye className="mr-1 h-3 w-3" /> Under Review
                      </Button>
                    )}
                    {selectedReport.status !== "RESOLVED" && (
                      <Button size="sm" variant="outline" onClick={() => setActionDialog({ reportId: selectedReport.id, action: "RESOLVE", title: "Resolve" })}>
                        <CheckCircle className="mr-1 h-3 w-3" /> Resolve
                      </Button>
                    )}
                    {selectedReport.status !== "DISMISSED" && (
                      <Button size="sm" variant="outline" onClick={() => setActionDialog({ reportId: selectedReport.id, action: "REJECT", title: "Dismiss" })}>
                        <XCircle className="mr-1 h-3 w-3" /> Dismiss
                      </Button>
                    )}
                    {selectedReport.targetUserId && (
                      <>
                        <Button size="sm" variant="outline" onClick={() => setActionDialog({ reportId: selectedReport.id, action: "SUSPEND_USER", title: "Suspend User" })}>
                          <ShieldBan className="mr-1 h-3 w-3" /> Suspend User
                        </Button>
                        <Button size="sm" variant="destructive" onClick={() => setActionDialog({ reportId: selectedReport.id, action: "BAN_USER", title: "Ban User" })}>
                          <ShieldBan className="mr-1 h-3 w-3" /> Ban User
                        </Button>
                      </>
                    )}
                    {selectedReport.targetMessageId && (
                      <Button size="sm" variant="destructive" onClick={() => setActionDialog({ reportId: selectedReport.id, action: "DELETE_MESSAGE", title: "Delete Message" })}>
                        <MessageSquareX className="mr-1 h-3 w-3" /> Delete Message
                      </Button>
                    )}
                  </div>
                </div>
              ) : (
                <p className="py-6 text-center text-sm text-muted-foreground">Unable to load this report.</p>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Action confirmation (spec §8) ──────────────────────────── */}
      <AlertDialog open={actionDialog !== null} onOpenChange={(o) => !o && !actionLoading && setActionDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{actionDialog?.title}?</AlertDialogTitle>
            <AlertDialogDescription>
              {actionDialog?.action === "BAN_USER"
                ? "This account will no longer be able to access the platform. This action is recorded in the audit log."
                : actionDialog?.action === "SUSPEND_USER"
                ? "This account will be temporarily suspended. This action is recorded in the audit log."
                : actionDialog?.action === "DELETE_MESSAGE"
                ? "The reported message will be deleted. This action is recorded in the audit log."
                : "This action will update the report status. It is recorded in the audit log."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={actionLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={actionLoading}
              onClick={(e) => { e.preventDefault(); void performAction(); }}
              className={cn(
                (actionDialog?.action === "BAN_USER" || actionDialog?.action === "DELETE_MESSAGE") &&
                "bg-destructive text-destructive-foreground hover:bg-destructive/90"
              )}
            >
              {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {actionDialog?.title}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ── Sub-component: StatCard ────────────────────────────────────────────────

function StatCard({ label, value, icon: Icon, color, suffix }: {
  label: string; value: number; icon: React.ComponentType<{ className?: string }>; color?: string; suffix?: string;
}) {
  return (
    <Card>
      <CardContent className="p-3">
      <div className="flex items-center gap-2">
        <Icon className={cn("h-4 w-4", color ?? "text-muted-foreground")} />
        <div>
          <p className="text-lg font-bold">{formatNumber(value)}{suffix}</p>
          <p className="text-[10px] text-muted-foreground">{label}</p>
        </div>
      </div>
      </CardContent>
    </Card>
  );
}
