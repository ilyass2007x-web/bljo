"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { Loader2, Save } from "lucide-react";

interface Setting {
  key: string;
  value: string;
  type: string;
  description: string;
  updatedAt: string | null;
}

export function AdminSettings() {
  const [settings, setSettings] = useState<Setting[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [drafts, setDrafts] = useState<Record<string, string>>({});

  async function load() {
    try {
      const data = await api.get<{ settings: Setting[] }>("/api/v1/admin/settings");
      setSettings(data.settings);
      const d: Record<string, string> = {};
      for (const s of data.settings) d[s.key] = s.value;
      setDrafts(d);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load settings");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  async function save(key: string) {
    setSaving(key);
    try {
      const data = await api.put<{ settings: Setting[] }>("/api/v1/admin/settings", { key, value: drafts[key] ?? "" });
      setSettings(data.settings);
      toast.success(`Setting "${key}" updated`);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update setting");
    } finally {
      setSaving(null);
    }
  }

  if (loading) return <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>;

  const groups: Record<string, Setting[]> = {};
  for (const s of settings) {
    const g = s.key.split(".")[0] ?? "general";
    (groups[g] ??= []).push(s);
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Platform Settings</h2>
        <p className="text-sm text-muted-foreground">Configurable values stored in the database.</p>
      </div>
      {Object.entries(groups).map(([group, items]) => (
        <Card key={group}>
          <CardHeader>
            <CardTitle className="text-base capitalize">{group}</CardTitle>
            <CardDescription>{items.length} setting(s)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {items.map((s) => (
              <div key={s.key} className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <Label htmlFor={s.key} className="text-xs font-mono">{s.key}</Label>
                  {s.type === "boolean" ? (
                    <Switch
                      checked={drafts[s.key] === "true"}
                      onCheckedChange={(v) => setDrafts((d) => ({ ...d, [s.key]: String(v) }))}
                    />
                  ) : null}
                </div>
                <p className="text-xs text-muted-foreground">{s.description}</p>
                {s.type !== "boolean" && (
                  <Input id={s.key} value={drafts[s.key] ?? ""} onChange={(e) => setDrafts((d) => ({ ...d, [s.key]: e.target.value }))} />
                )}
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted-foreground">
                    {s.updatedAt ? `Updated ${new Date(s.updatedAt).toLocaleDateString()}` : "Default value"}
                  </p>
                  <Button size="sm" variant="outline" onClick={() => save(s.key)} disabled={saving === s.key}>
                    {saving === s.key ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Save className="mr-1 h-3 w-3" />}
                    Save
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
