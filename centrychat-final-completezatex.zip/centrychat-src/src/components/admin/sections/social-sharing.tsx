"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { Loader2, Save, Share2, Image as ImageIcon, Globe, Eye, CheckCircle, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Admin → Social Sharing / Open Graph section (PHASE-10).
 *
 * Provides explicit admin controls for:
 *   - Site OG Title (maps to platform.name — used as og:site_name on article
 *     pages + og:title on the homepage)
 *   - Site OG Description (maps to platform.description — used as
 *     og:description on the homepage; article pages use their own excerpt)
 *   - Default OG Image (maps to platform.default_og_image — used as the
 *     og:image fallback when an article has no coverImage AND no video
 *     thumbnail; see resolveArticleOgImage() in src/lib/seo/article.ts)
 *
 * These settings are stored in PlatformSetting (DB) via the existing
 * PUT /api/v1/admin/settings endpoint. Changes propagate within 30s
 * (the getSetting cache TTL) to all SEO surfaces.
 *
 * SECURITY:
 *   - requireAdmin() is enforced server-side on the settings PUT endpoint.
 *   - Input is validated: OG image must be a valid http(s):// URL.
 *   - No file upload (URLs only) — the project doesn't have a media
 *     upload system for admins; images are stored as external URLs.
 */
interface SocialSharingData {
  siteOgTitle: string;        // platform.name
  siteOgDescription: string; // platform.description
  defaultOgImage: string;   // platform.default_og_image
  logoUrl: string;          // platform.logo_url (used in JSON-LD publisher.logo)
  resolvedBaseUrl: string;  // for displaying absolute URLs in the preview
}

export function AdminSocialSharing() {
  const [data, setData] = useState<SocialSharingData | null>(null);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  // ── Draft state for the editable fields (PHASE-12 fix) ─────────────
  // ALL useState calls MUST be at the top of the component — BEFORE any
  // conditional `return` statements. The previous version had these
  // useState + useEffect calls AFTER `if (loading) return` and
  // `if (!data) return`, which violates the React Hooks rules:
  //   - First render: loading=true → 3 hooks called → `if (loading) return`
  //   - Second render: loading=false → 6 hooks called (the 3 draft useStates
  //     + the sync useEffect became reachable)
  //   - React detects: "Rendered more hooks than during the previous render"
  //   - This throws + triggers the global Error Boundary → "Something went wrong"
  // The fix: initialize drafts with empty strings (NOT from `data` — `data`
  // is null on first render), then sync them via the useEffect below when
  // `data` changes. This keeps the hook count constant across renders.
  const [titleDraft, setTitleDraft] = useState("");
  const [descDraft, setDescDraft] = useState("");
  const [ogImageDraft, setOgImageDraft] = useState("");

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      // Use the existing /api/v1/admin/seo endpoint which returns the
      // resolved base URL + platform settings.
      const res = await api.get<{ seo: any }>("/api/v1/admin/seo");
      const seo = res.seo;
      const newData: SocialSharingData = {
        siteOgTitle: seo.platform?.name || "",
        siteOgDescription: seo.platform?.description || "",
        defaultOgImage: "", // populated below from settings
        logoUrl: "",
        resolvedBaseUrl: seo.platform?.resolvedBaseUrl || seo.platform?.baseUrl || "",
      };
      // Fetch the raw settings (default_og_image + logo_url are not in the
      // seo endpoint response — they're in the settings list).
      try {
        const settingsRes = await api.get<{ settings: { key: string; value: string }[] }>("/api/v1/admin/settings");
        const settings = settingsRes.settings || [];
        const ogImg = settings.find((s) => s.key === "platform.default_og_image");
        const logo = settings.find((s) => s.key === "platform.logo_url");
        newData.defaultOgImage = ogImg?.value || "";
        newData.logoUrl = logo?.value || "";
      } catch {
        // Non-fatal — the SEO endpoint already gave us the basics.
      }
      setData(newData);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load social sharing settings.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void fetch(); }, [fetch]);

  // Sync drafts whenever `data` changes (initial load + after save refresh).
  // This runs AFTER the data is loaded, so the drafts get the real values.
  useEffect(() => {
    if (data) {
      setTitleDraft(data.siteOgTitle);
      setDescDraft(data.siteOgDescription);
      setOgImageDraft(data.defaultOgImage);
    }
  }, [data]);

  async function saveSetting(key: string, value: string) {
    setSaving(true);
    try {
      await api.put("/api/v1/admin/settings", { key, value });
      toast.success(`${key} updated. Changes propagate to all pages within 30 seconds.`);
      void fetch(); // refresh to show the saved state
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to save setting.");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 w-full rounded-lg" />
      </div>
    );
  }

  if (!data) {
    return <Card><CardContent className="py-6 text-center text-sm text-destructive">Unable to load social sharing settings.</CardContent></Card>;
  }

  // ── Live OG Preview (computed from draft state) ───────────────────
  // Build a live preview of how the OG card would look when the homepage
  // URL is shared on WhatsApp/Facebook/X. Uses the current draft values
  // (which may differ from the saved state until the user clicks Save).
  const previewImage = ogImageDraft?.trim()
    ? ogImageDraft.trim()
    : `${data.resolvedBaseUrl}/og-default.png`;
  const previewTitle = titleDraft?.trim() || "Platform";
  const previewDesc = descDraft?.trim() || "A self-hostable messaging platform.";
  const previewUrl = data.resolvedBaseUrl || "https://centrychat.netlify.app";

  // Validate the OG image URL
  const ogImageValid = !ogImageDraft?.trim() || /^https?:\/\/.+/i.test(ogImageDraft.trim());
  const ogImageIsHttps = ogImageDraft?.trim().startsWith("https://");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Share2 className="h-6 w-6 text-primary" /> Social Sharing / Open Graph
        </h2>
        <p className="text-sm text-muted-foreground">
          Control how your site appears when shared on WhatsApp, Facebook, X, LinkedIn, Telegram, and other platforms. Changes propagate to all pages within 30 seconds.
        </p>
      </div>

      {/* Site OG Title */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <Globe className="h-4 w-4" /> Site OG Title
          </CardTitle>
          <CardDescription>
            Used as <code className="text-xs">og:site_name</code> on article pages + <code className="text-xs">og:title</code> on the homepage. Same as the Platform Name in Customization.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input
            value={titleDraft}
            onChange={(e) => setTitleDraft(e.target.value)}
            placeholder="CentryChat"
            maxLength={60}
          />
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground">{titleDraft.length}/60 characters</span>
            <Button
              size="sm"
              onClick={() => saveSetting("platform.name", titleDraft)}
              disabled={saving || titleDraft === data.siteOgTitle || !titleDraft.trim()}
            >
              {saving ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Save className="mr-1 h-3 w-3" />}
              Save
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Site OG Description */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <Globe className="h-4 w-4" /> Site OG Description
          </CardTitle>
          <CardDescription>
            Used as <code className="text-xs">og:description</code> on the homepage. Article pages use their own excerpt (not this value). Same as the Platform Description in Customization.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Textarea
            value={descDraft}
            onChange={(e) => setDescDraft(e.target.value)}
            placeholder="A secure, portable, self-hostable messaging platform."
            maxLength={200}
            rows={3}
          />
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground">{descDraft.length}/200 characters</span>
            <Button
              size="sm"
              onClick={() => saveSetting("platform.description", descDraft)}
              disabled={saving || descDraft === data.siteOgDescription || !descDraft.trim()}
            >
              {saving ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Save className="mr-1 h-3 w-3" />}
              Save
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Default OG Image */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <ImageIcon className="h-4 w-4" /> Default OG Image
          </CardTitle>
          <CardDescription>
            Used as <code className="text-xs">og:image</code> when an article has <strong>no cover image</strong> AND <strong>no video thumbnail</strong>. Article pages with a real cover image use the article's cover (not this default). Recommended size: 1200×630px, PNG/JPG, HTTPS, publicly accessible.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input
            value={ogImageDraft}
            onChange={(e) => setOgImageDraft(e.target.value)}
            placeholder="https://centrychat.netlify.app/og-default.png"
            maxLength={500}
            className={cn("font-mono text-sm", !ogImageValid && "border-destructive")}
          />
          {/* Validation badges */}
          <div className="flex flex-wrap gap-2">
            <Badge variant={ogImageDraft?.trim() ? "default" : "outline"} className="text-[10px]">
              {ogImageDraft?.trim() ? <CheckCircle className="mr-0.5 h-2.5 w-2.5" /> : <XCircle className="mr-0.5 h-2.5 w-2.5" />}
              {ogImageDraft?.trim() ? "Set" : "Not set (uses /og-default.png)"}
            </Badge>
            {ogImageDraft?.trim() && (
              <>
                <Badge variant={ogImageValid ? "default" : "destructive"} className="text-[10px]">
                  {ogImageValid ? <CheckCircle className="mr-0.5 h-2.5 w-2.5" /> : <XCircle className="mr-0.5 h-2.5 w-2.5" />}
                  Valid URL
                </Badge>
                <Badge variant={ogImageIsHttps ? "default" : "destructive"} className="text-[10px]">
                  {ogImageIsHttps ? <CheckCircle className="mr-0.5 h-2.5 w-2.5" /> : <XCircle className="mr-0.5 h-2.5 w-2.5" />}
                  HTTPS
                </Badge>
              </>
            )}
          </div>
          {/* Image preview */}
          {ogImageDraft?.trim() && ogImageValid && (
            <div className="overflow-hidden rounded-lg border">
              <img
                src={ogImageDraft.trim()}
                alt="OG image preview"
                className="h-40 w-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = "none";
                }}
              />
            </div>
          )}
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground">
              {ogImageDraft?.trim() ? "Custom default OG image" : "Falls back to /og-default.png (builtin)"}
            </span>
            <Button
              size="sm"
              onClick={() => saveSetting("platform.default_og_image", ogImageDraft)}
              disabled={saving || ogImageDraft === data.defaultOgImage || !ogImageValid}
            >
              {saving ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Save className="mr-1 h-3 w-3" />}
              Save
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* ── Live OG Preview ─────────────────────────────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <Eye className="h-4 w-4" /> Live OG Preview (Homepage)
          </CardTitle>
          <CardDescription>
            How the homepage URL <code className="text-xs">{previewUrl}</code> would look when shared on WhatsApp/Facebook/X. This is a PREVIEW using the current draft values (click Save to apply).
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-hidden rounded-lg border bg-muted/30">
            {/* OG image */}
            <div className="aspect-[1.91/1] w-full bg-muted relative">
              <img
                src={previewImage}
                alt="OG preview"
                className="h-full w-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.opacity = "0.3";
                }}
              />
            </div>
            {/* OG text */}
            <div className="p-3 space-y-1">
              <p className="text-[10px] text-muted-foreground uppercase">{previewUrl}</p>
              <p className="font-semibold text-sm line-clamp-2">{previewTitle}</p>
              <p className="text-xs text-muted-foreground line-clamp-2">{previewDesc}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Article OG Fallback Chain Explanation */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold">Article OG Image Fallback Chain</CardTitle>
          <CardDescription>How the OG image is resolved for each article page (in priority order):</CardDescription>
        </CardHeader>
        <CardContent>
          <ol className="space-y-2 text-sm">
            <li className="flex items-start gap-2">
              <Badge variant="outline" className="text-[10px] mt-0.5">1</Badge>
              <span><strong>Article coverImage</strong> — the real cover image set by the author. Must be a valid HTTPS image URL (not a YouTube/Vimeo embed URL).</span>
            </li>
            <li className="flex items-start gap-2">
              <Badge variant="outline" className="text-[10px] mt-0.5">2</Badge>
              <span><strong>Video thumbnail</strong> — when the article has a videoUrl (YouTube/Vimeo), the video's thumbnail is used (e.g. <code className="text-xs">i.ytimg.com/vi/ID/hqdefault.jpg</code>).</span>
            </li>
            <li className="flex items-start gap-2">
              <Badge variant="outline" className="text-[10px] mt-0.5">3</Badge>
              <span><strong>Default OG Image</strong> (this section) — the admin-configured fallback. Used when the article has no cover AND no video thumbnail.</span>
            </li>
            <li className="flex items-start gap-2">
              <Badge variant="outline" className="text-[10px] mt-0.5">4</Badge>
              <span><strong>Builtin /og-default.png</strong> — the platform-branded 1200×630 PNG in <code className="text-xs">public/</code>. Last resort.</span>
            </li>
          </ol>
        </CardContent>
      </Card>
    </div>
  );
}
