"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import { Loader2, Plus, Trash2, Key } from "lucide-react";

interface ExternalApi {
  id: string;
  name: string;
  provider: string;
  baseUrl: string | null;
  apiKeyHint: string | null;
  status: string;
  description: string | null;
}

const PROVIDERS = ["storage", "email", "ai", "analytics", "payment", "search", "notification"];

export function AdminApis() {
  const [apis, setApis] = useState<ExternalApi[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: "", provider: "storage", baseUrl: "", apiKey: "", description: "" });

  async function load() {
    setLoading(true);
    try {
      const data = await api.get<{ apis: ExternalApi[] }>("/api/v1/admin/apis");
      setApis(data.apis);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load APIs");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  async function addApi() {
    if (!form.name) return;
    setAdding(true);
    try {
      await api.post("/api/v1/admin/apis", {
        name: form.name,
        provider: form.provider,
        baseUrl: form.baseUrl || undefined,
        apiKey: form.apiKey || undefined,
        description: form.description || undefined,
        status: "disabled",
      });
      toast.success("API added");
      setForm({ name: "", provider: "storage", baseUrl: "", apiKey: "", description: "" });
      void load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed");
    } finally {
      setAdding(false);
    }
  }

  async function toggleApi(id: string, status: string) {
    const newStatus = status === "enabled" ? "disabled" : "enabled";
    try {
      await api.patch(`/api/v1/admin/apis/${id}`, { status: newStatus });
      toast.success(`API ${newStatus}`);
      void load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed");
    }
  }

  async function deleteApi(id: string) {
    try {
      await api.delete(`/api/v1/admin/apis/${id}`);
      toast.success("API deleted");
      void load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed");
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">API Management</h2>
        <p className="text-sm text-muted-foreground">Configure external service integrations. API keys are masked and never fully exposed.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Add API Integration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label className="text-xs">Name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="My Cloud Storage" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Provider</Label>
              <Select value={form.provider} onValueChange={(v) => setForm({ ...form, provider: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PROVIDERS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Base URL</Label>
              <Input value={form.baseUrl} onChange={(e) => setForm({ ...form, baseUrl: e.target.value })} placeholder="https://api.example.com" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">API Key</Label>
              <Input type="password" value={form.apiKey} onChange={(e) => setForm({ ...form, apiKey: e.target.value })} placeholder="sk_..." />
            </div>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Description</Label>
            <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Optional description" />
          </div>
          <Button onClick={addApi} disabled={adding}>
            {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add API
          </Button>
        </CardContent>
      </Card>

      {loading ? (
        <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>
      ) : apis.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">No external APIs configured.</Card>
      ) : (
        <Card>
          <div className="divide-y">
            {apis.map((a) => (
              <div key={a.id} className="flex items-center gap-3 p-3">
                <Key className="h-4 w-4 text-muted-foreground" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium">{a.name}</p>
                    <Badge variant="outline">{a.provider}</Badge>
                    <Badge variant={a.status === "enabled" ? "default" : "secondary"}>{a.status}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {a.baseUrl && <span>{a.baseUrl} · </span>}
                    {a.apiKeyHint && <span className="font-mono">{a.apiKeyHint}</span>}
                  </p>
                </div>
                <Button size="sm" variant="outline" onClick={() => toggleApi(a.id, a.status)}>
                  {a.status === "enabled" ? "Disable" : "Enable"}
                </Button>
                <Button size="sm" variant="ghost" onClick={() => deleteApi(a.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card className="border-amber-500/30">
        <CardHeader>
          <CardTitle className="text-base">API Key Security</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-1">
          <p>• API keys are stored encrypted and never returned in full to the frontend.</p>
          <p>• Only a masked hint is shown (e.g. <code className="rounded bg-muted px-1">sk_live_************1234</code>).</p>
          <p>• Keys are never logged, never placed in HTML, and never sent to the client.</p>
        </CardContent>
      </Card>
    </div>
  );
}
