"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar } from "@/components/shared/avatar";
import { useAuthStore } from "@/lib/client/auth-store";
import { formatDateTime } from "@/lib/client/format";

export function AdminAccount() {
  const { user } = useAuthStore();
  if (!user) return null;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Admin Account</h2>
        <p className="text-sm text-muted-foreground">Your administrator profile.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Profile</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Avatar name={user.fullName} color={user.avatarColor} size="xl" />
            <div>
              <p className="text-lg font-semibold">{user.fullName}</p>
              <p className="text-sm text-muted-foreground">{user.email}</p>
              <div className="mt-2 flex flex-wrap gap-1">
                <Badge variant="default">{user.role}</Badge>
                <Badge variant={user.status === "ACTIVE" ? "secondary" : "destructive"}>{user.status}</Badge>
                {user.emailVerified && <Badge variant="outline">Verified</Badge>}
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><p className="text-muted-foreground">Member since</p><p>{formatDateTime(user.createdAt)}</p></div>
            <div><p className="text-muted-foreground">Last seen</p><p>{formatDateTime(user.lastSeenAt)}</p></div>
            <div><p className="text-muted-foreground">2FA</p><p>{user.twoFactorEnabled ? "Enabled" : "Not enabled"}</p></div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-amber-500/40">
        <CardHeader>
          <CardTitle className="text-base">Two-Factor Authentication</CardTitle>
          <CardDescription>Protect your admin account with TOTP.</CardDescription>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          <p>2FA via authenticator apps (TOTP) is architected but not yet enabled for this account. Use a future update to enable it from this screen with recovery codes.</p>
          <p className="mt-2">All admin sessions are revocable from the <strong className="text-foreground">Security</strong> tab.</p>
        </CardContent>
      </Card>
    </div>
  );
}
