"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import { Database, HardDrive, Mail, Server, Cloud, Zap, Loader2, RefreshCw } from "lucide-react";

interface Infrastructure {
  database: { name: string; connected: boolean; latencyMs: number; urlHint: string; error: string | null };
  storage: { name: string; configured: boolean };
  email: { name: string; configured: boolean };
  cache: { name: string };
  jobs: { name: string };
  realtime: { name: string; configured: boolean };
  externalApis: { enabled: { provider: string; count: number }[] };
}

export function AdminInfrastructure() {
  const [infra, setInfra] = useState<Infrastructure | null>(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const data = await api.get<{ infrastructure: Infrastructure }>("/api/v1/admin/infrastructure");
      setInfra(data.infrastructure);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load infrastructure");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  if (loading || !infra) return <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>;

  const providers = [
    { key: "database", label: "Database", icon: Database, data: infra.database, statusText: infra.database.connected ? "Connected" : "Error" },
    { key: "storage", label: "Storage", icon: HardDrive, data: infra.storage, statusText: infra.storage.configured ? "Configured" : "Not configured" },
    { key: "email", label: "Email", icon: Mail, data: infra.email, statusText: infra.email.configured ? "Configured" : "Not configured" },
    { key: "realtime", label: "Realtime", icon: Zap, data: infra.realtime, statusText: infra.realtime.configured ? "Configured" : "Not configured" },
    { key: "cache", label: "Cache", icon: Server, data: infra.cache, statusText: "Active" },
    { key: "jobs", label: "Jobs", icon: Cloud, data: infra.jobs, statusText: "Active" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Infrastructure</h2>
          <p className="text-sm text-muted-foreground">All provider connections and status.</p>
        </div>
        <Button variant="outline" size="sm" onClick={load}><RefreshCw className="mr-1 h-3 w-3" /> Refresh</Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {providers.map((p) => (
          <Card key={p.key}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <p.icon className="h-4 w-4 text-muted-foreground" />
                {p.label}
              </CardTitle>
              <Badge variant={p.statusText === "Connected" || p.statusText === "Configured" || p.statusText === "Active" ? "default" : "destructive"}>
                {p.statusText}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between"><span className="text-muted-foreground">Provider</span><span className="font-medium">{p.data.name}</span></div>
                {"latencyMs" in p.data && typeof p.data.latencyMs === "number" && (
                  <div className="flex justify-between"><span className="text-muted-foreground">Latency</span><span>{p.data.latencyMs}ms</span></div>
                )}
                {"urlHint" in p.data && Boolean(p.data.urlHint) && (
                  <div className="flex justify-between"><span className="text-muted-foreground">URL</span><span className="font-mono">{String(p.data.urlHint)}</span></div>
                )}
                {"error" in p.data && Boolean(p.data.error) && (
                  <div className="text-destructive">{String(p.data.error)}</div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {infra.externalApis.enabled.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">External APIs</CardTitle>
            <CardDescription>Enabled integrations</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            {infra.externalApis.enabled.map((a) => (
              <Badge key={a.provider} variant="secondary">{a.provider}: {a.count}</Badge>
            ))}
          </CardContent>
        </Card>
      )}

      <Card className="border-blue-500/30">
        <CardHeader>
          <CardTitle className="text-base">Provider Abstraction</CardTitle>
          <CardDescription>The app uses provider interfaces for all infrastructure.</CardDescription>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-1">
          <p>Switching providers requires only changing environment variables — no code changes.</p>
          <p className="border-t pt-2"><strong className="text-foreground">Security:</strong> Secrets are never exposed to the frontend. The admin panel shows only connection status and safe hints.</p>
        </CardContent>
      </Card>
    </div>
  );
}
