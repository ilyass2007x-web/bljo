"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber } from "@/lib/client/format";
import { toast } from "sonner";
import {
  Shield, Lock, Key, Eye, AlertTriangle, CheckCircle, XCircle,
  Activity, Server, Cookie, FileText,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SecurityData {
  security: {
    headers: { active: { header: string; value: string }[]; csp: string; appliedVia: string };
    rateLimits: Record<string, { limit: number; windowSeconds: number }> & { note: string };
    session: { cookieName: string; ttlSeconds: number; httpOnly: boolean; sameSite: string; secure: string; signed: boolean; encrypted: boolean; note: string };
    password: { algorithm: string; memoryCost: string; timeCost: number; parallelism: number; note: string };
    validation: Record<string, string>;
    xssProtection: Record<string, string>;
    idorProtection: Record<string, string>;
    corsPolicy: { configured: string; note: string };
    csrfProtection: { mechanism: string; note: string };
    audit: { totalLogs: number; today: number; thisWeek: number; topActions: { action: string; count: number }[]; immutable: boolean; appendOnly: boolean; note: string };
    envVars: { key: string; set: boolean }[];
    dataSafety: Record<string, string>;
  };
}

export function AdminSecurity() {
  const [data, setData] = useState<SecurityData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<SecurityData>("/api/v1/admin/security");
      setData(res);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load security data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void fetch(); }, [fetch]);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        {[0,1,2,3,4].map(i => <Skeleton key={i} className="h-24 w-full rounded-lg" />)}
      </div>
    );
  }

  if (!data) {
    return <Card><CardContent className="py-6 text-center text-sm text-destructive">Unable to load security data.</CardContent></Card>;
  }

  const s = data.security;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
          <Shield className="h-6 w-6" /> Security Center
        </h2>
        <p className="text-sm text-muted-foreground">Read-only overview of the platform's security posture. No secrets exposed.</p>
      </div>

      {/* Security Overview Cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        <OverviewCard label="Security Headers" value={`${s.headers.active.length} active`} ok icon={Lock} />
        <OverviewCard label="CSP" value="Active" ok icon={Shield} />
        <OverviewCard label="Password Hash" value={s.password.algorithm} ok icon={Key} />
        <OverviewCard label="Rate Limits" value={`${Object.keys(s.rateLimits).filter(k => k !== "note").length} presets`} ok icon={Activity} />
      </div>

      {/* Audit Log Stats */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold"><FileText className="h-4 w-4" /> Audit Log Stats</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-lg border p-2 text-center">
              <p className="text-xl font-bold">{formatNumber(s.audit.totalLogs)}</p>
              <p className="text-[10px] text-muted-foreground">Total Logs</p>
            </div>
            <div className="rounded-lg border p-2 text-center">
              <p className="text-xl font-bold">{s.audit.today}</p>
              <p className="text-[10px] text-muted-foreground">Today</p>
            </div>
            <div className="rounded-lg border p-2 text-center">
              <p className="text-xl font-bold">{s.audit.thisWeek}</p>
              <p className="text-[10px] text-muted-foreground">This Week</p>
            </div>
          </div>
          {s.audit.topActions.length > 0 && (
            <div className="mt-3 space-y-1">
              <p className="text-xs font-medium text-muted-foreground">Top Actions</p>
              {s.audit.topActions.map(a => (
                <div key={a.action} className="flex items-center justify-between text-xs">
                  <span className="font-mono">{a.action}</span>
                  <Badge variant="secondary" className="text-[10px]">{a.count}</Badge>
                </div>
              ))}
            </div>
          )}
          <p className="mt-2 text-[10px] text-muted-foreground">{s.audit.note}</p>
        </CardContent>
      </Card>

      {/* Security Headers */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold"><Lock className="h-4 w-4" /> Security Headers</CardTitle>
          <p className="text-xs text-muted-foreground">Applied via {s.headers.appliedVia}</p>
        </CardHeader>
        <CardContent className="space-y-1">
          {s.headers.active.map(h => (
            <div key={h.header} className="flex items-center justify-between rounded border px-2 py-1 text-xs">
              <span className="font-mono font-medium">{h.header}</span>
              <span className="truncate text-muted-foreground max-w-60">{h.value}</span>
            </div>
          ))}
          <div className="flex items-center justify-between rounded border px-2 py-1 text-xs">
            <span className="font-mono font-medium">Content-Security-Policy</span>
            <CheckCircle className="h-3 w-3 text-green-500" />
          </div>
          <p className="mt-1 text-[10px] text-muted-foreground">{s.headers.csp}</p>
        </CardContent>
      </Card>

      {/* Session + Password */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><Cookie className="h-4 w-4" /> Session Security</CardTitle></CardHeader>
          <CardContent className="space-y-1 text-xs">
            <Row label="Cookie" value={s.session.cookieName} />
            <Row label="TTL" value={`${Math.round(s.session.ttlSeconds / 86400)} days`} />
            <Row label="HttpOnly" value={s.session.httpOnly ? "Yes" : "No"} ok={s.session.httpOnly} />
            <Row label="SameSite" value={s.session.sameSite} ok />
            <Row label="Signed" value={s.session.signed ? "Yes" : "No"} ok={s.session.signed} />
            <Row label="Encrypted" value={s.session.encrypted ? "Yes" : "No"} ok={s.session.encrypted} />
            <p className="mt-2 text-[10px] text-muted-foreground">{s.session.note}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><Key className="h-4 w-4" /> Password Security</CardTitle></CardHeader>
          <CardContent className="space-y-1 text-xs">
            <Row label="Algorithm" value={s.password.algorithm} ok />
            <Row label="Memory Cost" value={s.password.memoryCost} ok />
            <Row label="Time Cost" value={String(s.password.timeCost)} ok />
            <Row label="Parallelism" value={String(s.password.parallelism)} ok />
            <p className="mt-2 text-[10px] text-muted-foreground">{s.password.note}</p>
          </CardContent>
        </Card>
      </div>

      {/* Input Validation */}
      <Card>
        <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><CheckCircle className="h-4 w-4" /> Input Validation</CardTitle></CardHeader>
        <CardContent>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {Object.entries(s.validation).map(([k, v]) => (
              <div key={k} className="rounded border p-2 text-xs">
                <p className="font-medium">{k}</p>
                <p className="text-muted-foreground">{v}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* XSS + IDOR Protection */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><Eye className="h-4 w-4" /> XSS Protection</CardTitle></CardHeader>
          <CardContent className="space-y-1 text-xs">
            {Object.entries(s.xssProtection).map(([k, v]) => (
              <div key={k}>
                <span className="font-medium capitalize">{k.replace(/([A-Z])/g, " $1").trim()}:</span>{" "}
                <span className="text-muted-foreground">{v}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><Shield className="h-4 w-4" /> IDOR Protection</CardTitle></CardHeader>
          <CardContent className="space-y-1 text-xs">
            {Object.entries(s.idorProtection).map(([k, v]) => (
              <div key={k}>
                <span className="font-medium capitalize">{k.replace(/([A-Z])/g, " $1").trim()}:</span>{" "}
                <span className="text-muted-foreground">{v}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* CSRF + CORS */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><AlertTriangle className="h-4 w-4" /> CSRF Protection</CardTitle></CardHeader>
          <CardContent className="space-y-1 text-xs">
            <Row label="Mechanism" value={s.csrfProtection.mechanism} ok />
            <p className="mt-1 text-[10px] text-muted-foreground">{s.csrfProtection.note}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><Server className="h-4 w-4" /> CORS Policy</CardTitle></CardHeader>
          <CardContent className="space-y-1 text-xs">
            <Row label="Configured" value={s.corsPolicy.configured} ok />
            <p className="mt-1 text-[10px] text-muted-foreground">{s.corsPolicy.note}</p>
          </CardContent>
        </Card>
      </div>

      {/* Environment Variables (status only — NOT values) */}
      <Card>
        <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><Lock className="h-4 w-4" /> Environment Variables (status only)</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {s.envVars.map(v => (
              <div key={v.key} className="flex items-center justify-between rounded border px-2 py-1 text-xs">
                <span className="font-mono">{v.key}</span>
                {v.set ? <CheckCircle className="h-3 w-3 text-green-500" /> : <XCircle className="h-3 w-3 text-destructive" />}
              </div>
            ))}
          </div>
          <p className="mt-2 text-[10px] text-muted-foreground">{s.dataSafety.secretsNotInClient}</p>
        </CardContent>
      </Card>

      {/* Data Safety */}
      <Card>
        <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-sm font-semibold"><Shield className="h-4 w-4" /> Data Safety</CardTitle></CardHeader>
        <CardContent className="space-y-1 text-xs">
          {Object.entries(s.dataSafety).map(([k, v]) => (
            <div key={k}>
              <span className="font-medium capitalize">{k.replace(/([A-Z])/g, " $1").trim()}:</span>{" "}
              <span className="text-muted-foreground">{v}</span>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <p className="text-center text-[10px] text-muted-foreground">
        Security is continuously improved. This dashboard shows the current security posture — not a guarantee of "100% secure" (spec §41).
      </p>
    </div>
  );
}

function OverviewCard({ label, value, ok, icon: Icon }: { label: string; value: string; ok?: boolean; icon: React.ComponentType<{ className?: string }> }) {
  return (
    <Card>
      <CardContent className="p-3">
        <div className="flex items-center gap-2">
          <Icon className={cn("h-4 w-4", ok ? "text-green-500" : "text-muted-foreground")} />
          <div>
            <p className="text-sm font-bold">{value}</p>
            <p className="text-[10px] text-muted-foreground">{label}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function Row({ label, value, ok }: { label: string; value: string; ok?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="flex items-center gap-1.5 font-medium">
        {ok !== undefined && (ok ? <CheckCircle className="h-3 w-3 text-green-500" /> : <XCircle className="h-3 w-3 text-destructive" />)}
        <span dir="auto">{value}</span>
      </span>
    </div>
  );
}
