"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import {
  Brain, Save, RotateCcw, Play, ArrowUp, ArrowDown, Minus, Loader2,
  TrendingUp, Settings2, Eye, Shield,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ── Types ──────────────────────────────────────────────────────────────────

interface WeightConfig {
  recencyDecay: number; likeWeight: number; commentWeight: number;
  shareWeight: number; viewWeight: number; engagementRateWeight: number;
  followingBoost: number; explorationBoost: number; explorationRatio: number;
  diversityPenalty: number; velocityBonus: number; qualityWeight: number;
  newContentBoost: number; selfPenalty: number; velocityCap: number;
}

interface AlgorithmStatus {
  weights: { current: WeightConfig; defaults: WeightConfig; hasOverrides: boolean };
}

interface SimulateResult {
  content: { id: string; type: string; preview: string };
  current: { score: number; components: Record<string, number> };
  new: { score: number; components: Record<string, number> };
  delta: number;
  currentWeights: WeightConfig;
  newWeights: WeightConfig;
  hasChanges: boolean;
}

const WEIGHT_LABELS: Record<keyof WeightConfig, string> = {
  recencyDecay: "Recency Decay (1.0 = ~3h half-life)",
  likeWeight: "Like Weight",
  commentWeight: "Comment Weight",
  shareWeight: "Share Weight",
  viewWeight: "View Weight (passive)",
  engagementRateWeight: "Engagement Rate Weight",
  followingBoost: "Following Boost",
  explorationBoost: "Exploration Boost (discovery)",
  explorationRatio: "Exploration Ratio (0-1)",
  diversityPenalty: "Diversity Penalty (per repeat author)",
  velocityBonus: "Velocity Bonus (trending)",
  qualityWeight: "Quality Weight",
  newContentBoost: "New Content Boost",
  selfPenalty: "Self-Post Penalty",
  velocityCap: "Velocity Cap (max engagement/hour)",
};

const WEIGHT_KEYS = Object.keys(WEIGHT_LABELS) as (keyof WeightConfig)[];

export function AdminRecommendation() {
  const [status, setStatus] = useState<AlgorithmStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [draftWeights, setDraftWeights] = useState<WeightConfig | null>(null);
  const [saving, setSaving] = useState(false);
  const [rollingBack, setRollingBack] = useState(false);

  // Simulation state.
  const [simContentId, setSimContentId] = useState("");
  const [simContentType, setSimContentType] = useState<"post" | "article">("post");
  const [simResult, setSimResult] = useState<SimulateResult | null>(null);
  const [simLoading, setSimLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.get<AlgorithmStatus>("/api/v1/admin/algorithm");
      setStatus(data);
      setDraftWeights({ ...data.weights.current });
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load algorithm status");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  // Check if draft differs from current.
  const hasChanges = status && draftWeights
    ? JSON.stringify(status.weights.current) !== JSON.stringify(draftWeights)
    : false;

  async function saveWeights() {
    if (!draftWeights) return;
    setSaving(true);
    try {
      // Validate: no NaN/Infinity/negative-invalid values (spec §33).
      for (const k of WEIGHT_KEYS) {
        const v = draftWeights[k];
        if (!Number.isFinite(v)) {
          toast.error(`${WEIGHT_LABELS[k]} must be a finite number`);
          setSaving(false);
          return;
        }
        if (v < -1000 || v > 1000) {
          toast.error(`${WEIGHT_LABELS[k]} must be between -1000 and 1000`);
          setSaving(false);
          return;
        }
      }
      await api.patch("/api/v1/admin/algorithm", { weights: draftWeights });
      toast.success("Algorithm configuration saved + activated. Previous configuration backed up for rollback.");
      await load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to save");
    } finally {
      setSaving(false);
    }
  }

  async function rollback() {
    setRollingBack(true);
    try {
      await api.post("/api/v1/admin/algorithm/rollback");
      toast.success("Rolled back to previous configuration");
      await load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Rollback failed");
    } finally {
      setRollingBack(false);
    }
  }

  async function runSimulation() {
    if (!simContentId.trim()) {
      toast.error("Enter a content ID to simulate");
      return;
    }
    setSimLoading(true);
    setSimResult(null);
    try {
      // Use the draft weights as the "new" configuration for comparison.
      const data = await api.post<SimulateResult>("/api/v1/admin/algorithm/simulate", {
        contentId: simContentId.trim(),
        contentType: simContentType,
        weights: hasChanges ? draftWeights : undefined,
      });
      setSimResult(data);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Simulation failed");
    } finally {
      setSimLoading(false);
    }
  }

  function resetToDefaults() {
    if (status) setDraftWeights({ ...status.weights.defaults });
    toast.info("Reset to defaults (not saved yet — click Save to activate)");
  }

  function resetToCurrent() {
    if (status) setDraftWeights({ ...status.weights.current });
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 w-full rounded-lg" />
        <Skeleton className="h-64 w-full rounded-lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Algorithm Control Center</h2>
        <p className="text-sm text-muted-foreground">
          Configure the feed ranking algorithm. All changes are backed up for rollback. Every number uses real platform data.
        </p>
      </div>

      {/* Status indicators */}
      <div className="flex flex-wrap gap-2">
        <Badge variant={status?.weights.hasOverrides ? "default" : "outline"}>
          {status?.weights.hasOverrides ? "Custom Configuration Active" : "Default Configuration Active"}
        </Badge>
        {hasChanges && <Badge variant="secondary">Draft has unsaved changes</Badge>}
      </div>

      {/* ── Feed Ranking Weights (spec §3, §4) ─────────────────── */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <div>
            <CardTitle className="flex items-center gap-2 text-sm font-semibold">
              <Brain className="h-4 w-4" /> Feed Ranking Weights
            </CardTitle>
            <p className="text-xs text-muted-foreground">15 configurable signals. All values use real database data.</p>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" onClick={resetToCurrent} disabled={!hasChanges}>Discard</Button>
            <Button size="sm" variant="ghost" onClick={resetToDefaults}>Reset to Defaults</Button>
            <Button size="sm" onClick={saveWeights} disabled={saving || !hasChanges}>
              {saving ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Save className="mr-1 h-3.5 w-3.5" />}
              Save & Activate
            </Button>
            <Button size="sm" variant="outline" onClick={rollback} disabled={rollingBack || !status?.weights.hasOverrides}>
              {rollingBack ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="mr-1 h-3.5 w-3.5" />}
              Rollback
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {draftWeights && (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {WEIGHT_KEYS.map(key => (
                <WeightInput
                  key={key}
                  label={WEIGHT_LABELS[key]}
                  value={draftWeights[key]}
                  defaultValue={status?.weights.defaults[key] ?? 0}
                  currentValue={status?.weights.current[key] ?? 0}
                  onChange={(v) => setDraftWeights(prev => prev ? { ...prev, [key]: v } : prev)}
                />
              ))}
            </div>
          )}
          {/* Safe rollout notice (spec §21) */}
          <p className="mt-4 text-[10px] text-muted-foreground">
            Saving activates the new configuration immediately. The previous configuration is backed up for rollback.
            If the feed breaks, use Rollback to restore. The public feed always falls back to DEFAULT_RANKING_WEIGHTS if settings are invalid.
          </p>
        </CardContent>
      </Card>

      {/* ── Algorithm Simulation (spec §17, §18) ─────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <Play className="h-4 w-4" /> Algorithm Simulation
          </CardTitle>
          <p className="text-xs text-muted-foreground">Test how content scores under different configurations. Shows the full score breakdown.</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Input */}
          <div className="flex flex-wrap gap-2">
            <Input
              placeholder="Content ID (e.g. clx...)"
              value={simContentId}
              onChange={(e) => setSimContentId(e.target.value)}
              className="flex-1"
            />
            <Select value={simContentType} onValueChange={(v) => setSimContentType(v as "post" | "article")}>
              <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="post">Post</SelectItem>
                <SelectItem value="article">Article</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={runSimulation} disabled={simLoading}>
              {simLoading ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" /> : <Play className="mr-1 h-3.5 w-3.5" />}
              Simulate
            </Button>
          </div>

          {/* Results */}
          {simResult && (
            <div className="space-y-3">
              {/* Content preview */}
              <div className="rounded-lg border p-2">
                <Badge variant="outline" className="mb-1 text-[10px]">{simResult.content.type}</Badge>
                <p className="truncate text-xs text-muted-foreground" dir="auto">{simResult.content.preview}</p>
              </div>

              {/* Score comparison */}
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg border p-3">
                  <p className="text-xs font-medium text-muted-foreground">Current Algorithm</p>
                  <p className="text-2xl font-bold">{simResult.current.score}</p>
                </div>
                <div className={cn("rounded-lg border p-3", simResult.hasChanges && "border-primary")}>
                  <p className="text-xs font-medium text-muted-foreground">{simResult.hasChanges ? "New Configuration" : "Same as Current"}</p>
                  <p className="text-2xl font-bold">{simResult.new.score}</p>
                </div>
              </div>

              {/* Delta */}
              {simResult.hasChanges && (
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">Score change:</span>
                  <span className={cn("flex items-center gap-0.5 font-medium",
                    simResult.delta > 0 ? "text-green-600 dark:text-green-400" :
                    simResult.delta < 0 ? "text-destructive" : "text-muted-foreground")}>
                    {simResult.delta > 0 ? <ArrowUp className="h-3.5 w-3.5" /> :
                     simResult.delta < 0 ? <ArrowDown className="h-3.5 w-3.5" /> : <Minus className="h-3.5 w-3.5" />}
                    {simResult.delta > 0 ? "+" : ""}{simResult.delta}
                  </span>
                </div>
              )}

              {/* Component breakdown */}
              <div>
                <p className="mb-2 text-xs font-medium text-muted-foreground">Score Breakdown (spec §17)</p>
                <div className="space-y-1">
                  {Object.entries(simResult.new.components).map(([k, v]) => {
                    const currentVal = simResult.current.components[k] ?? 0;
                    const diff = v - currentVal;
                    return (
                      <div key={k} className="flex items-center justify-between rounded border px-2 py-1 text-xs">
                        <span className="capitalize">{k}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-muted-foreground">{currentVal}</span>
                          <span>→</span>
                          <span className="font-medium">{v}</span>
                          {simResult.hasChanges && diff !== 0 && (
                            <span className={cn("text-[10px]", diff > 0 ? "text-green-600" : "text-destructive")}>
                              ({diff > 0 ? "+" : ""}{Math.round(diff * 10) / 10})
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Algorithm Architecture Summary (spec §1 audit) ──────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <Settings2 className="h-4 w-4" /> Algorithm Architecture
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-xs text-muted-foreground">
          <div>
            <p className="font-medium text-foreground">Feed Ranking Engine (src/lib/content/ranking.ts)</p>
            <p>15 scoring components: recency (exponential decay), engagement (weighted sum), engagement rate (normalized), following boost, exploration boost (discovery), diversity penalty, velocity (capped), quality (content-length + media signals), new content boost (removed if zero engagement), self penalty, spam penalty.</p>
          </div>
          <div>
            <p className="font-medium text-foreground">Trending Engine</p>
            <p>48-hour window. Elevated velocity (2.5×) + recency (1.5×). Following/exploration disabled (global). Stronger diversity (2×). Self-content excluded. Velocity capped at 20/hour.</p>
          </div>
          <div>
            <p className="font-medium text-foreground">Unified Feed (GET /api/v1/feed/unified)</p>
            <p>Candidate pool: 3× page size (capped 100). Followed + exploration content. Cursor-based pagination. 30s weight cache. In-memory scoring (O(n)).</p>
          </div>
          <div>
            <p className="font-medium text-foreground">Anti-Spam (spec §9)</p>
            <p>All engagement from UNIQUE interactions (DB @@unique constraints). Velocity capped. Shares counted from Interaction tables (one row per event). Spam penalty for very short content + zero engagement after 24h (soft signal, never a hard ban).</p>
          </div>
          <div>
            <p className="font-medium text-foreground">Safety (spec §27, §28)</p>
            <p>Deleted/private content never appears (DB-level status filters). Draft articles excluded from feed. Author diversity (progressive penalty). Content diversity via exploration ratio.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ── Sub-component: WeightInput ────────────────────────────────────────────

function WeightInput({ label, value, defaultValue, currentValue, onChange }: {
  label: string; value: number; defaultValue: number; currentValue: number;
  onChange: (v: number) => void;
}) {
  const isChanged = value !== currentValue;
  const isDefault = value === defaultValue;
  return (
    <div className="rounded-lg border p-2.5">
      <Label className="text-[10px] leading-tight text-muted-foreground">{label}</Label>
      <div className="mt-1 flex items-center gap-2">
        <Input
          type="number"
          value={value}
          onChange={(e) => {
            const v = parseFloat(e.target.value);
            onChange(Number.isFinite(v) ? v : 0);
          }}
          step="0.1"
          className={cn("h-8 text-sm", isChanged && "border-primary")}
        />
        {isChanged && !isDefault && <Badge variant="secondary" className="text-[8px]">modified</Badge>}
        {isDefault && !isChanged && <span className="text-[8px] text-muted-foreground">default</span>}
      </div>
      <p className="mt-0.5 text-[8px] text-muted-foreground">default: {defaultValue} · current: {currentValue}</p>
    </div>
  );
}
