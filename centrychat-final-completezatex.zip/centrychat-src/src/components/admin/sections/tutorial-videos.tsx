"use client";

import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { Loader2, Save, Video as VideoIcon, Youtube, ExternalLink } from "lucide-react";
// IMPORTANT: import the client-safe constants/types/helpers from `./shared`,
// NOT from `@/lib/tutorial-videos` (which imports `db` + PrismaClient at the
// top level). Importing from `@/lib/tutorial-videos` here would pull
// PrismaClient into the browser bundle, throwing the
// "PrismaClient is unable to run in this browser environment" error
// and triggering the global-error.tsx boundary.
import {
  validateYouTubeUrl,
  TUTORIAL_LOCATIONS,
  TUTORIAL_LOCATION_META,
  type TutorialLocation,
} from "@/lib/tutorial-videos/shared";

/**
 * AdminTutorialVideos — admin section for configuring per-location
 * YouTube tutorial videos.
 *
 * Features:
 *   - One Card per tutorial location (PROFILE_IMAGE_TUTORIAL,
 *     ARTICLE_IMAGE_TUTORIAL). Each is fully independent (spec §9).
 *   - YouTube URL input with live validation + thumbnail preview.
 *   - Enable/Disable switch + Save button.
 *   - The thumbnail is AUTO-derived from the YouTube video ID — no
 *     separate thumbnail input (spec §4).
 *
 * Security:
 *   - Admin-only UI (the parent AdminPanel gates this section).
 *   - The server route `/api/v1/admin/tutorial-videos` independently
 *     enforces `requireAdmin()` — the UI is NOT the security boundary.
 *   - YouTube URLs are validated on the client (instant feedback) AND
 *     on the server (source of truth).
 *
 * Future-ready (spec §10): adding a new tutorial location is a 1-line
 * change in `src/lib/tutorial-videos/index.ts` (append to
 * `TUTORIAL_LOCATIONS`). This component automatically renders a new
 * Card for it because it iterates over `TUTORIAL_LOCATIONS`.
 */

interface TutorialRecord {
  youtubeUrl: string;
  enabled: boolean;
  videoId: string;
  updatedAt?: string;
}

interface TutorialListEntry {
  location: TutorialLocation;
  record: TutorialRecord | null;
}

interface CardState {
  youtubeUrl: string;
  enabled: boolean;
  /** True when the local input has unsaved changes. */
  dirty: boolean;
  /** Live-parsed YouTube info for thumbnail preview. Null when invalid. */
  parsed: ReturnType<typeof validateYouTubeUrl> | null;
  saving: boolean;
}

export function AdminTutorialVideos() {
  const [loading, setLoading] = useState(true);
  const [states, setStates] = useState<Record<TutorialLocation, CardState>>(
    () => initialStates()
  );

  useEffect(() => {
    void (async () => {
      try {
        const data = await api.get<{ tutorials: TutorialListEntry[] }>(
          "/api/v1/admin/tutorial-videos"
        );
        setStates(mergeLoaded(initialStates(), data.tutorials));
      } catch (e) {
        toast.error(
          e instanceof ApiClientError ? e.message : "Failed to load tutorial videos"
        );
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  function updateCard(
    location: TutorialLocation,
    patch: Partial<CardState>
  ): void {
    setStates((prev) => {
      const cur = prev[location];
      // Re-parse the YouTube URL whenever it changes so the thumbnail
      // preview stays in sync. Done here (not in onChange) so we don't
      // need to duplicate the parsing logic across handlers.
      const youtubeUrl = patch.youtubeUrl !== undefined ? patch.youtubeUrl : cur.youtubeUrl;
      const parsed = validateYouTubeUrl(youtubeUrl);
      const dirty =
        patch.dirty !== undefined
          ? patch.dirty
          : cur.dirty ||
            // Mark dirty when url/enabled differ from a "freshly loaded"
            // state. We compute this lazily — the actual comparison happens
            // in the save handler.
            false;
      return {
        ...prev,
        [location]: { ...cur, ...patch, youtubeUrl, parsed, dirty },
      };
    });
  }

  async function save(location: TutorialLocation): Promise<void> {
    const cur = states[location];
    if (!cur.parsed) {
      toast.error(
        "Invalid YouTube URL. Use https://youtube.com/watch?v=… or https://youtu.be/…"
      );
      return;
    }
    updateCard(location, { saving: true });
    try {
      await api.patch("/api/v1/admin/tutorial-videos", {
        location,
        youtubeUrl: cur.youtubeUrl.trim(),
        enabled: cur.enabled,
      });
      toast.success(`${TUTORIAL_LOCATION_META[location].label} saved.`);
      updateCard(location, { saving: false, dirty: false });
    } catch (e) {
      toast.error(
        e instanceof ApiClientError ? e.message : "Failed to save tutorial video"
      );
      updateCard(location, { saving: false });
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12 text-muted-foreground">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
        Loading tutorial videos…
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
          <VideoIcon className="h-5 w-5" /> Tutorial Videos
        </h2>
        <p className="text-sm text-muted-foreground">
          Configure per-location YouTube tutorials shown to users. Each location is independent.
        </p>
      </div>

      {TUTORIAL_LOCATIONS.map((location) => {
        const meta = TUTORIAL_LOCATION_META[location];
        const s = states[location];
        return (
          <Card key={location}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Youtube className="h-4 w-4 text-red-600" />
                {meta.label}
              </CardTitle>
              <CardDescription>{meta.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* YouTube URL input + live thumbnail preview */}
              <div className="space-y-2">
                <Label htmlFor={`yt-${location}`}>YouTube URL</Label>
                <Input
                  id={`yt-${location}`}
                  value={s.youtubeUrl}
                  onChange={(e) =>
                    updateCard(location, {
                      youtubeUrl: e.target.value,
                      dirty: true,
                    })
                  }
                  placeholder="https://youtube.com/watch?v=…  or  https://youtu.be/…"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  aria-invalid={!s.parsed && s.youtubeUrl.length > 0}
                />
                {/* Live preview — thumbnail derived from the URL. */}
                {s.parsed ? (
                  <div className="flex items-center gap-3 rounded-lg border bg-muted/20 p-2">
                    <img
                      src={s.parsed.thumbnailUrl}
                      alt="YouTube thumbnail preview"
                      className="h-14 w-24 rounded object-cover"
                      loading="lazy"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-medium text-foreground">
                        Video ID: {s.parsed.videoId}
                      </p>
                      <a
                        href={s.youtubeUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-xs text-primary hover:underline"
                      >
                        Open on YouTube <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                ) : s.youtubeUrl.length > 0 ? (
                  <p className="text-xs text-destructive">
                    Invalid YouTube URL. Use https://youtube.com/watch?v=… or https://youtu.be/…
                  </p>
                ) : null}
              </div>

              {/* Enable/Disable + Save */}
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <Switch
                    id={`enable-${location}`}
                    checked={s.enabled}
                    onCheckedChange={(checked) =>
                      updateCard(location, { enabled: checked, dirty: true })
                    }
                  />
                  <Label htmlFor={`enable-${location}`} className="cursor-pointer text-sm">
                    {s.enabled ? "Enabled" : "Disabled"}
                  </Label>
                </div>
                <Button
                  onClick={() => save(location)}
                  disabled={s.saving || !s.parsed}
                >
                  {s.saving ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="mr-2 h-4 w-4" />
                  )}
                  Save
                </Button>
              </div>

              {/* Last-updated timestamp (when available). */}
              {states[location] && (
                <LastUpdatedHint location={location} />
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

/** Fetches the saved record's updatedAt timestamp from the server. */
function LastUpdatedHint({ location }: { location: TutorialLocation }) {
  const [ts, setTs] = useState<string | null>(null);
  useEffect(() => {
    // Re-fetch the list on mount to get the latest server-side
    // updatedAt. This is intentionally cheap (admin-only route).
    void api
      .get<{ tutorials: TutorialListEntry[] }>("/api/v1/admin/tutorial-videos")
      .then((d) => {
        const entry = d.tutorials.find((t) => t.location === location);
        setTs(entry?.record?.updatedAt ?? null);
      })
      .catch(() => setTs(null));
  }, [location]);
  if (!ts) return null;
  return (
    <p className="text-xs text-muted-foreground">
      Last updated: {new Date(ts).toLocaleString()}
    </p>
  );
}

// ── Helpers ─────────────────────────────────────────────────────────────

function initialStates(): Record<TutorialLocation, CardState> {
  const out = {} as Record<TutorialLocation, CardState>;
  for (const loc of TUTORIAL_LOCATIONS) {
    out[loc] = {
      youtubeUrl: "",
      enabled: false,
      dirty: false,
      parsed: null,
      saving: false,
    };
  }
  return out;
}

function mergeLoaded(
  base: Record<TutorialLocation, CardState>,
  tutorials: TutorialListEntry[]
): Record<TutorialLocation, CardState> {
  const out = { ...base };
  for (const { location, record } of tutorials) {
    if (!record) continue;
    out[location] = {
      youtubeUrl: record.youtubeUrl,
      enabled: record.enabled,
      dirty: false,
      parsed: validateYouTubeUrl(record.youtubeUrl),
      saving: false,
    };
  }
  return out;
}
