"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import { Loader2, Plus, Trash2, GripVertical } from "lucide-react";

interface Section {
  id: string;
  name: string;
  type: string;
  enabled: boolean;
  position: number;
  maxItems: number;
  visibility: string;
}

const SECTION_TYPES = ["HOME", "FOR_YOU", "POSTS", "REELS", "TRENDING", "FOLLOWING", "POPULAR_USERS", "RECOMMENDED", "STORIES"];

export function AdminHomepage() {
  const [sections, setSections] = useState<Section[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [newSection, setNewSection] = useState({ name: "", type: "POSTS", position: 0 });

  async function load() {
    setLoading(true);
    try {
      const data = await api.get<{ sections: Section[] }>("/api/v1/admin/homepage-sections");
      setSections(data.sections);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load sections");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { void load(); }, []);

  async function toggleSection(id: string, enabled: boolean) {
    try {
      await api.patch(`/api/v1/admin/homepage-sections/${id}`, { enabled });
      toast.success(enabled ? "Section enabled" : "Section disabled");
      void load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed");
    }
  }

  async function deleteSection(id: string) {
    try {
      await api.delete(`/api/v1/admin/homepage-sections/${id}`);
      toast.success("Section deleted");
      void load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed");
    }
  }

  async function addSection() {
    if (!newSection.name) return;
    setAdding(true);
    try {
      await api.post("/api/v1/admin/homepage-sections", {
        name: newSection.name,
        type: newSection.type,
        position: newSection.position,
        enabled: false,
      });
      toast.success("Section added");
      setNewSection({ name: "", type: "POSTS", position: sections.length });
      void load();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed");
    } finally {
      setAdding(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Homepage Sections</h2>
        <p className="text-sm text-muted-foreground">Control which sections appear on the homepage and their order.</p>
      </div>

      <Card className="p-4">
        <h3 className="mb-3 text-sm font-medium">Add Section</h3>
        <div className="flex flex-wrap items-end gap-2">
          <div className="space-y-1">
            <Label className="text-xs">Name</Label>
            <Input value={newSection.name} onChange={(e) => setNewSection({ ...newSection, name: e.target.value })} placeholder="Reels" className="w-40" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Type</Label>
            <Select value={newSection.type} onValueChange={(v) => setNewSection({ ...newSection, type: v })}>
              <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
              <SelectContent>
                {SECTION_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={addSection} disabled={adding}>
            {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add
          </Button>
        </div>
      </Card>

      {loading ? (
        <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>
      ) : sections.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">No homepage sections yet.</Card>
      ) : (
        <Card>
          <div className="divide-y">
            {sections.map((s) => (
              <div key={s.id} className="flex items-center gap-3 p-3">
                <GripVertical className="h-4 w-4 text-muted-foreground" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium">{s.name}</p>
                    <Badge variant="outline">{s.type}</Badge>
                    <Badge variant={s.enabled ? "default" : "secondary"}>{s.enabled ? "ON" : "OFF"}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">Position: {s.position} · Max items: {s.maxItems}</p>
                </div>
                <Switch checked={s.enabled} onCheckedChange={(v) => toggleSection(s.id, v)} />
                <Button size="sm" variant="ghost" onClick={() => deleteSection(s.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
