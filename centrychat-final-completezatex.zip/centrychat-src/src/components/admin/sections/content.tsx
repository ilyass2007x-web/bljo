"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber, formatRelativeTime } from "@/lib/client/format";
import { toast } from "sonner";
import {
  Search, FileText, Heart, MessageCircle, Eye, Share2, TrendingUp,
  Loader2, Trash2, Send, EyeOff, AlertTriangle, Flag, ChevronLeft,
  BarChart3,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { ArticleTrafficModal } from "@/components/admin/analytics/article-modal";

// ── Types ──────────────────────────────────────────────────────────────────

interface ContentItem {
  type: "post" | "article";
  id: string;
  content?: string;
  title?: string;
  excerpt?: string | null;
  coverImage?: string | null;
  videoUrl?: string | null;
  status?: string;
  publishedAt?: string | null;
  readingTime?: number;
  createdAt: string;
  updatedAt: string;
  author: {
    id: string; fullName: string; username: string;
    avatarColor: string | null; avatarUrl: string | null; isVerified: boolean;
  };
  counts: { likes: number; comments: number; views: number; shares: number };
  reportCount: number;
  engagement: number;
  engagementRate: number;
}

interface ContentDetail {
  type: "post" | "article";
  content: any;
  stats: { likes: number; comments: number; views: number; shares: number; engagementRate: number; reportCount: number };
}

type SortBy = "newest" | "oldest" | "views" | "likes" | "comments" | "shares" | "engagement";
type ContentType = "all" | "posts" | "articles";
type StatusFilter = "all" | "published" | "drafts" | "reported";

// ── Component ──────────────────────────────────────────────────────────────

export function AdminContent() {
  const router = useRouter();
  const [items, setItems] = useState<ContentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [inputQ, setInputQ] = useState("");
  const [type, setType] = useState<ContentType>("all");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [sortBy, setSortBy] = useState<SortBy>("newest");
  const [selected, setSelected] = useState<ContentItem | null>(null);
  const [detail, setDetail] = useState<ContentDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [actionDialog, setActionDialog] = useState<{ id: string; type: string; action: string; title: string } | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  // PHASE 12 — per-article analytics modal state. Opened from the
  // "Analytics" button on a published article's detail panel.
  const [analyticsArticleId, setAnalyticsArticleId] = useState<string | null>(null);
  const [analyticsArticleTitle, setAnalyticsArticleTitle] = useState("");
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  // Debounced search.
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => { setQ(inputQ); }, 300);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [inputQ]);

  // Fetch first page.
  const fetchFirst = useCallback(async () => {
    setLoading(true);
    setItems([]);
    setNextCursor(null);
    try {
      const params = new URLSearchParams({ limit: "20", sortBy });
      if (q) params.set("q", q);
      if (type !== "all") params.set("type", type);
      if (statusFilter !== "all") params.set("status", statusFilter);
      const data = await api.get<{ items: ContentItem[]; nextCursor: string | null }>(`/api/v1/admin/content?${params}`);
      setItems(data.items);
      setNextCursor(data.nextCursor);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load content. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [q, type, statusFilter, sortBy]);

  useEffect(() => { void fetchFirst(); }, [fetchFirst]);

  // Load more (infinite scroll).
  const loadMore = useCallback(async () => {
    if (!nextCursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const params = new URLSearchParams({ limit: "20", sortBy, cursor: nextCursor });
      if (q) params.set("q", q);
      if (type !== "all") params.set("type", type);
      if (statusFilter !== "all") params.set("status", statusFilter);
      const data = await api.get<{ items: ContentItem[]; nextCursor: string | null }>(`/api/v1/admin/content?${params}`);
      setItems((prev) => [...prev, ...data.items]);
      setNextCursor(data.nextCursor);
    } catch { /* silent — user can scroll to retry */ } finally {
      setLoadingMore(false);
    }
  }, [nextCursor, loadingMore, q, type, statusFilter, sortBy]);

  useEffect(() => {
    if (!nextCursor || loadingMore) return;
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => { if (entries[0]?.isIntersecting) void loadMore(); },
      { rootMargin: "300px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [nextCursor, loadingMore, loadMore]);

  // View detail.
  async function viewDetail(item: ContentItem) {
    setSelected(item);
    setDetail(null);
    setDetailLoading(true);
    try {
      const data = await api.get<ContentDetail>(`/api/v1/admin/content/${item.id}?type=${item.type}`);
      setDetail(data);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load content details");
    } finally {
      setDetailLoading(false);
    }
  }

  // Perform action.
  async function performAction() {
    if (!actionDialog) return;
    setActionLoading(true);
    try {
      await api.post(`/api/v1/admin/content/${actionDialog.id}/action?type=${actionDialog.type}`, { action: actionDialog.action });
      toast.success(`${actionDialog.action} applied`);
      setActionDialog(null);
      // Remove from list if deleted, or refresh.
      if (actionDialog.action === "DELETE") {
        setItems((prev) => prev.filter((i) => i.id !== actionDialog.id));
      } else {
        void fetchFirst();
      }
      setSelected(null);
      setDetail(null);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Action failed");
    } finally {
      setActionLoading(false);
    }
  }

  const sortOptions: { value: SortBy; label: string }[] = [
    { value: "newest", label: "Newest" },
    { value: "oldest", label: "Oldest" },
    { value: "views", label: "Most Viewed" },
    { value: "likes", label: "Most Liked" },
    { value: "comments", label: "Most Commented" },
    { value: "shares", label: "Most Shared" },
    { value: "engagement", label: "Highest Engagement" },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Content Management</h2>
        <p className="text-sm text-muted-foreground">Manage Posts and Articles from one place.</p>
      </div>

      {/* Search + Filters */}
      <Card className="p-4">
        <div className="flex flex-wrap gap-2">
          <div className="relative min-w-48 flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search content, author…" value={inputQ} onChange={(e) => setInputQ(e.target.value)} className="pl-8" />
          </div>
          {/* Type filter */}
          <div className="flex gap-1 rounded-lg border bg-muted/30 p-1">
            {(["all", "posts", "articles"] as ContentType[]).map((t) => (
              <button key={t} onClick={() => setType(t)}
                className={cn("rounded-md px-3 py-1.5 text-xs font-medium capitalize transition-colors",
                  type === t ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>
                {t}
              </button>
            ))}
          </div>
          {/* Status filter */}
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="published">Published</SelectItem>
              <SelectItem value="drafts">Drafts</SelectItem>
              <SelectItem value="reported">Reported</SelectItem>
            </SelectContent>
          </Select>
          {/* Sort */}
          <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortBy)}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Sort by" /></SelectTrigger>
            <SelectContent>
              {sortOptions.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Content list */}
      <Card>
        {loading ? (
          <div className="space-y-2 p-4">
            {[0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-16 w-full rounded-lg" />)}
          </div>
        ) : items.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
            <FileText className="h-10 w-10 text-muted-foreground/50" />
            <p className="text-sm font-medium">No content found.</p>
            <p className="max-w-sm text-xs text-muted-foreground">Try adjusting your search or filters.</p>
          </div>
        ) : (
          <div className="divide-y divide-border/60">
            {items.map((item) => (
              <div key={`${item.type}-${item.id}`} className="flex items-start gap-3 p-4 hover:bg-accent/30">
                {/* Cover image for articles */}
                {item.type === "article" && item.coverImage && (
                  <img src={item.coverImage} alt="" className="hidden h-12 w-12 shrink-0 rounded object-cover sm:block" loading="lazy" />
                )}
                <div className="min-w-0 flex-1">
                  {/* Title / preview */}
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="shrink-0 text-[10px]">{item.type}</Badge>
                    {item.type === "article" && item.status && (
                      <Badge variant={item.status === "PUBLISHED" ? "default" : "secondary"} className="shrink-0 text-[10px]">{item.status}</Badge>
                    )}
                    {item.reportCount > 0 && (
                      <Badge variant="destructive" className="shrink-0 text-[10px]">
                        <Flag className="mr-0.5 h-2.5 w-2.5" />{item.reportCount}
                      </Badge>
                    )}
                  </div>
                  <p className="mt-1 line-clamp-2 text-sm font-medium" dir="auto">
                    {item.type === "article" ? item.title : item.content?.slice(0, 150)}
                  </p>
                  {/* Author */}
                  <div className="mt-1.5 flex items-center gap-2">
                    <button onClick={() => router.push(`/?view=admin&section=users`)} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:underline">
                      <Avatar name={item.author.fullName} color={item.author.avatarColor} src={item.author.avatarUrl} size="sm" className="h-5 w-5 text-[9px]" />
                      <span className="truncate">{item.author.fullName}</span>
                      {item.author.isVerified && <VerifiedBadge size={10} />}
                      <span className="truncate">@{item.author.username}</span>
                    </button>
                    <span className="text-xs text-muted-foreground">· {formatRelativeTime(item.createdAt)}</span>
                  </div>
                  {/* Engagement stats */}
                  <div className="mt-1.5 flex flex-wrap gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-0.5"><Heart className="h-3 w-3" />{formatNumber(item.counts.likes)}</span>
                    <span className="flex items-center gap-0.5"><MessageCircle className="h-3 w-3" />{formatNumber(item.counts.comments)}</span>
                    <span className="flex items-center gap-0.5"><Eye className="h-3 w-3" />{formatNumber(item.counts.views)}</span>
                    <span className="flex items-center gap-0.5"><Share2 className="h-3 w-3" />{formatNumber(item.counts.shares)}</span>
                    <span className="flex items-center gap-0.5"><TrendingUp className="h-3 w-3" />{item.engagementRate}%</span>
                  </div>
                </div>
                <Button size="sm" variant="ghost" onClick={() => viewDetail(item)}>View</Button>
              </div>
            ))}
          </div>
        )}

        {/* Infinite scroll sentinel */}
        {nextCursor && !loading && (
          <div ref={sentinelRef} className="flex items-center justify-center py-8">
            <Button variant="ghost" size="sm" onClick={() => loadMore()} disabled={loadingMore}>
              {loadingMore ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null}
              {loadingMore ? "Loading…" : "Load more"}
            </Button>
          </div>
        )}
      </Card>

      {/* ── Content detail dialog (spec §7) ─────────────────────── */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && (setSelected(null), setDetail(null))}>
        <DialogContent className="max-h-[85vh] max-w-2xl overflow-y-auto">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Badge variant="outline">{selected.type}</Badge>
                  {selected.type === "article" && selected.status && (
                    <Badge variant={selected.status === "PUBLISHED" ? "default" : "secondary"}>{selected.status}</Badge>
                  )}
                  {selected.reportCount > 0 && (
                    <Badge variant="destructive"><Flag className="mr-0.5 h-3 w-3" />{selected.reportCount}</Badge>
                  )}
                </DialogTitle>
              </DialogHeader>

              {detailLoading ? (
                <div className="space-y-3 py-4">
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-32 w-full" />
                </div>
              ) : detail ? (
                <div className="space-y-4">
                  {/* Title (articles only) */}
                  {selected.type === "article" && detail.content.title && (
                    <h3 className="text-lg font-bold" dir="auto">{detail.content.title}</h3>
                  )}

                  {/* Content preview */}
                  {selected.type === "article" && detail.content.coverImage && (
                    <img src={detail.content.coverImage} alt="" className="max-h-48 w-full rounded-lg object-cover" />
                  )}

                  <div className="rounded-lg border p-3">
                    <p className="line-clamp-6 text-sm" dir="auto">
                      {selected.type === "article" ? detail.content.content?.slice(0, 500) : detail.content.content}
                    </p>
                  </div>

                  {/* Author */}
                  <div className="flex items-center gap-2">
                    <Avatar name={detail.content.author?.fullName ?? selected.author.fullName} size="sm" src={detail.content.author?.avatarUrl ?? selected.author.avatarUrl} color={detail.content.author?.avatarColor ?? selected.author.avatarColor} />
                    <div>
                      <p className="text-sm font-medium">{detail.content.author?.fullName ?? selected.author.fullName}</p>
                      <p className="text-xs text-muted-foreground">@{detail.content.author?.username ?? selected.author.username}</p>
                    </div>
                    <Button size="sm" variant="ghost" className="ml-auto" onClick={() => router.push(`/?view=admin&section=users`)}>
                      View User
                    </Button>
                  </div>

                  {/* Stats grid */}
                  <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
                    <StatBox label="Likes" value={detail.stats.likes} icon={Heart} color="text-red-500" />
                    <StatBox label="Comments" value={detail.stats.comments} icon={MessageCircle} color="text-sky-500" />
                    <StatBox label="Views" value={detail.stats.views} icon={Eye} color="text-amber-500" />
                    <StatBox label="Shares" value={detail.stats.shares} icon={Share2} color="text-teal-500" />
                    <StatBox label="Eng. Rate" value={detail.stats.engagementRate} suffix="%" icon={TrendingUp} color="text-primary" />
                    <StatBox label="Reports" value={detail.stats.reportCount} icon={Flag} color="text-destructive" />
                  </div>

                  {/* Metadata */}
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div><p className="text-xs text-muted-foreground">Created</p><p>{formatRelativeTime(detail.content.createdAt)}</p></div>
                    <div><p className="text-xs text-muted-foreground">Updated</p><p>{formatRelativeTime(detail.content.updatedAt)}</p></div>
                    {selected.type === "article" && detail.content.readingTime != null && (
                      <div><p className="text-xs text-muted-foreground">Reading time</p><p>{detail.content.readingTime} min</p></div>
                    )}
                    {selected.type === "article" && detail.content.publishedAt && (
                      <div><p className="text-xs text-muted-foreground">Published</p><p>{formatRelativeTime(detail.content.publishedAt)}</p></div>
                    )}
                  </div>

                  {/* Actions (spec §8, §9, §21) */}
                  <div className="flex flex-wrap gap-2 border-t pt-4">
                    {/* Publish / Unpublish (articles only) */}
                    {selected.type === "article" && selected.status === "DRAFT" && (
                      <Button size="sm" variant="outline" onClick={() => setActionDialog({ id: selected.id, type: selected.type, action: "PUBLISH", title: selected.title ?? "article" })}>
                        <Send className="mr-1 h-3 w-3" /> Publish
                      </Button>
                    )}
                    {selected.type === "article" && selected.status === "PUBLISHED" && (
                      <Button size="sm" variant="outline" onClick={() => setActionDialog({ id: selected.id, type: selected.type, action: "UNPUBLISH", title: selected.title ?? "article" })}>
                        <EyeOff className="mr-1 h-3 w-3" /> Unpublish
                      </Button>
                    )}
                    {/* View public (articles only — opens /articles/[id]) */}
                    {selected.type === "article" && selected.status === "PUBLISHED" && (
                      <Button size="sm" variant="ghost" onClick={() => window.open(`/articles/${selected.id}`, "_blank")}>
                        <Eye className="mr-1 h-3 w-3" /> View Public
                      </Button>
                    )}
                    {/* PHASE 12 — Article Analytics button (articles only).
                        Opens the same ArticleTrafficModal used by the Traffic
                        Analytics dashboard. Available for both PUBLISHED and
                        DRAFT articles — drafts can still receive views if they
                        were ever published (e.g. unpublished after publication),
                        and the admin may want to inspect their traffic. */}
                    {selected.type === "article" && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setAnalyticsArticleId(selected.id);
                          setAnalyticsArticleTitle(selected.title ?? "Untitled article");
                        }}
                      >
                        <BarChart3 className="mr-1 h-3 w-3" /> Analytics
                      </Button>
                    )}
                    {/* Delete */}
                    <Button size="sm" variant="destructive" onClick={() => setActionDialog({ id: selected.id, type: selected.type, action: "DELETE", title: selected.type === "article" ? selected.title ?? "article" : "post" })}>
                      <Trash2 className="mr-1 h-3 w-3" /> Delete
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="py-6 text-center text-sm text-muted-foreground">Failed to load details.</p>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ── Action confirmation (spec §9, §21) ───────────────────── */}
      <AlertDialog open={actionDialog !== null} onOpenChange={(o) => !o && !actionLoading && setActionDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {actionDialog?.action === "DELETE" ? "Delete this content?" :
               actionDialog?.action === "PUBLISH" ? "Publish this article?" :
               "Unpublish this article?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {actionDialog?.action === "DELETE"
                ? `This will permanently delete "${actionDialog?.title}" and all its interactions (likes, comments, views, shares). This action cannot be undone.`
                : actionDialog?.action === "PUBLISH"
                ? "This will make the article publicly visible."
                : "This will set the article back to draft status. It will no longer be publicly visible."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={actionLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={actionLoading}
              onClick={(e) => { e.preventDefault(); void performAction(); }}
              className={cn(actionDialog?.action === "DELETE" && "bg-destructive text-destructive-foreground hover:bg-destructive/90")}
            >
              {actionLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {actionDialog?.action === "DELETE" ? "Delete" : actionDialog?.action === "PUBLISH" ? "Publish" : "Unpublish"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* PHASE 12 — Per-article Traffic Analytics modal (opened by the
          "Analytics" button on a selected article). Reuses the SAME
          ArticleTrafficModal component used by the Traffic Analytics
          dashboard — no duplicate UI. */}
      <ArticleTrafficModal
        articleId={analyticsArticleId}
        articleTitle={analyticsArticleTitle}
        range="30d"
        onClose={() => {
          setAnalyticsArticleId(null);
          setAnalyticsArticleTitle("");
        }}
      />
    </div>
  );
}

// ── Sub-component ──────────────────────────────────────────────────────────

function StatBox({ label, value, icon: Icon, color, suffix }: {
  label: string; value: number; icon: React.ComponentType<{ className?: string }>; color?: string; suffix?: string;
}) {
  return (
    <div className="rounded-lg border p-2 text-center">
      <Icon className={cn("mx-auto mb-1 h-3.5 w-3.5", color ?? "text-muted-foreground")} />
      <p className="text-sm font-bold">{formatNumber(value)}{suffix}</p>
      <p className="text-[10px] text-muted-foreground">{label}</p>
    </div>
  );
}
