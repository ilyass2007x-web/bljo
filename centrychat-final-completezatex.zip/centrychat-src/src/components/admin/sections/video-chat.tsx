"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Video, Settings, Activity, Users, TrendingUp, AlertTriangle, Save, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { isVideoChatClientEnabled } from "@/lib/video-chat/enabled";

/**
 * AdminVideoChat — the "Video Chat" admin section.
 *
 * Two tabs:
 *   1. Overview — statistics (active sessions, P2P success rate, reports)
 *   2. TURN Settings — configure STUN/TURN servers
 *
 * The TURN credential is shown (admin-only) + editable. It's NEVER exposed
 * to non-admin users.
 */

type Tab = "overview" | "matchmaking" | "turn" | "reports" | "safety";

interface Stats {
  activeSessions: number;
  usersSearching: number;
  connectedToday: number;
  p2pSuccessRate: number;
  turnUsageRate: number;
  failedRate: number;
  avgCallDurationSec: number;
  totalReports: number;
}

interface TurnSettings {
  turnEnabled: boolean;
  turnUrl: string;
  turnUsername: string;
  turnCredential: string;
  turnProtocol: string;
  turnPort: number;
  turnTls: boolean;
  stunUrl: string;
  maxDurationSec: number;
  queueTimeoutSec: number;
  minAccountAgeHours: number;
  debugLogging: boolean;
}

interface Report {
  id: string;
  sessionId: string;
  reason: string;
  description: string | null;
  status: string;
  createdAt: string;
  reporter: { id: string; fullName: string; username: string };
  reported: { id: string; fullName: string; username: string };
}

export function AdminVideoChat() {
  const [tab, setTab] = useState<Tab>("overview");
  const [stats, setStats] = useState<Stats | null>(null);
  const [settings, setSettings] = useState<TurnSettings | null>(null);
  const [reports, setReports] = useState<Report[]>([]);
  // Master enable/disable flag for the video_chat feature. Fetched from the
  // existing /api/v1/admin/features endpoint (the SAME source of truth the
  // Admin → Features section uses). When OFF, every video chat API route
  // returns 403 + users see the "Video chat is not enabled..." message.
  const [videoChatEnabled, setVideoChatEnabled] = useState<boolean | null>(null);
  const [togglingEnabled, setTogglingEnabled] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      // Fetch the feature flag in parallel with the existing requests so we
      // can render the master toggle alongside the stats + TURN settings.
      // We don't filter the flags list server-side (the existing endpoint
      // returns all flags) — we just pick out `video_chat` client-side.
      const [statsRes, settingsRes, flagsRes] = await Promise.all([
        api.get<{ stats: Stats }>("/api/v1/admin/video-chat/stats"),
        api.get<{ settings: TurnSettings }>("/api/v1/admin/video-chat/settings"),
        api.get<{ flags: { key: string; enabled: boolean }[] }>("/api/v1/admin/features"),
      ]);
      setStats(statsRes.stats);
      setSettings(settingsRes.settings);
      // PHASE 1 FIX (defensive): `flagsRes.flags` MAY be undefined if the
      // API ever returns an unexpected shape (e.g. partial 200 with an
      // empty body). The GET endpoint currently always returns `{ flags }`,
      // but guarding here means the admin UI degrades gracefully instead
      // of throwing `TypeError: Cannot read properties of undefined
      // (reading 'find')` and leaving the Switch stuck on the Skeleton.
      const loadFlags = flagsRes.flags ?? [];
      const vcFlag = loadFlags.find((f) => f.key === "video_chat");
      setVideoChatEnabled(vcFlag ? vcFlag.enabled : false);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to load video chat data.");
    } finally {
      setLoading(false);
    }
  }, []);

  // Toggle the video_chat feature flag via the EXISTING
  // /api/v1/admin/features PUT endpoint (requires admin server-side — see
  // src/app/api/v1/admin/features/route.ts). No new API endpoint, no
  // duplicate permission logic. The server enforces requireAdmin() on every
  // call, so a normal user cannot enable Video Chat by calling this endpoint
  // directly.
  const toggleVideoChat = useCallback(async (enabled: boolean) => {
    setTogglingEnabled(true);
    try {
      const res = await api.put<{ flags: { key: string; enabled: boolean }[] }>(
        "/api/v1/admin/features",
        { key: "video_chat", enabled }
      );
      // PHASE 1 FIX (defensive): `res.flags` is normally populated by the
      // PUT route's final `listFeatureFlags()` call. If the route ever
      // returns an unexpected shape (or returns an empty body during a
      // future regression), the original code did `res.flags.find(...)`
      // which throws `TypeError` — surfacing to the admin as a generic
      // "Failed to update Video Chat setting" toast and silently reverting
      // the Switch. Guarding here keeps the failure mode explicit and
      // prevents the cascade into the catch branch.
      const toggleFlags = res.flags ?? [];
      const vcFlag = toggleFlags.find((f) => f.key === "video_chat");
      setVideoChatEnabled(vcFlag ? vcFlag.enabled : enabled);
      toast.success(`Video Chat ${enabled ? "enabled" : "disabled"}.`);
    } catch (err) {
      toast.error(
        err instanceof ApiClientError ? err.message : "Failed to update Video Chat setting."
      );
      // Revert the optimistic UI by re-reading from server state — the
      // Switch's `checked` prop is bound to `videoChatEnabled`, so a re-render
      // with the previous value flips it back automatically.
      void load();
    } finally {
      setTogglingEnabled(false);
    }
  }, [load]);

  useEffect(() => {
    void load();
  }, [load]);

  const loadReports = useCallback(async () => {
    try {
      const res = await api.get<{ reports: Report[] }>("/api/v1/admin/video-chat/reports");
      setReports(res.reports);
    } catch {
      toast.error("Failed to load reports.");
    }
  }, []);

  useEffect(() => {
    if (tab === "reports") void loadReports();
  }, [tab, loadReports]);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold">
          <Video className="h-6 w-6 text-primary" />
          Video Chat
          {/* Master Status badge — reflects the COMBINED state of:
              - VIDEO_CHAT_ENABLED env var (hard kill switch)
              - video_chat FeatureFlag (admin toggle)
              When EITHER is off, the feature is fully disabled and all
              API routes return 403. The env var takes precedence — even
              if the FeatureFlag is ON, the env var can disable globally
              via Netlify Environment Variables without a DB round-trip. */}
          {isVideoChatClientEnabled() ? (
            <Badge className="bg-green-100 text-green-700">Env: Enabled</Badge>
          ) : (
            <Badge className="bg-red-100 text-red-700">Env: Disabled</Badge>
          )}
        </h1>
        <p className="text-sm text-muted-foreground">
          P2P-first video chat. TURN is optional and OFF by default.
        </p>
        {!isVideoChatClientEnabled() && (
          <div className="mt-3 rounded-md border border-yellow-300 bg-yellow-50 p-3 text-sm text-yellow-900 dark:border-yellow-700 dark:bg-yellow-950/40 dark:text-yellow-200">
            <strong className="font-semibold">Video Chat is currently DISABLED via environment variable.</strong>
            <p className="mt-1">
              The <code className="rounded bg-muted px-1 py-0.5">VIDEO_CHAT_ENABLED</code> env var is not set to
              <code className="ml-1 rounded bg-muted px-1 py-0.5">&quot;true&quot;</code>. To re-enable, set
              both <code className="ml-1 rounded bg-muted px-1 py-0.5">VIDEO_CHAT_ENABLED=true</code> and
              <code className="ml-1 rounded bg-muted px-1 py-0.5">NEXT_PUBLIC_VIDEO_CHAT_ENABLED=true</code> in
              your Netlify Environment Variables, then redeploy. The FeatureFlag toggle below is preserved
              but has no effect while the env var is off.
            </p>
          </div>
        )}
      </div>

      <div className="flex gap-2 border-b">
        <TabButton active={tab === "overview"} onClick={() => setTab("overview")}>Overview</TabButton>
        <TabButton active={tab === "matchmaking"} onClick={() => setTab("matchmaking")}>Matchmaking</TabButton>
        <TabButton active={tab === "turn"} onClick={() => setTab("turn")}>TURN Settings</TabButton>
        <TabButton active={tab === "reports"} onClick={() => setTab("reports")}>Reports</TabButton>
        <TabButton active={tab === "safety"} onClick={() => setTab("safety")}>Safety</TabButton>
      </div>

      {/*
        ── Master Video Chat enable/disable toggle ────────────────────────────
        Rendered ABOVE the tab content so it is always visible regardless of
        which tab the admin is on. This is the primary admin control: until
        this Switch is ON, every video chat API route returns 403 + normal
        users see "Video chat is not enabled. An administrator must enable it
        from the admin panel." on their Start Video Chat screen.

        Source of truth: the `video_chat` FeatureFlag row (DB) — the SAME
        flag the Features admin section toggles. No second setting, no
        duplicate API. Changes take effect IMMEDIATELY (setFeatureFlag
        invalidates the cache — see src/lib/features/index.ts).

        Server-side authorization: PUT /api/v1/admin/features calls
        requireAdmin() — non-admins cannot toggle this (the request is
        rejected with 401/403 before reaching the DB).
      */}
      <EnableVideoChatCard
        enabled={videoChatEnabled}
        loading={loading || togglingEnabled}
        onToggle={toggleVideoChat}
        envDisabled={!isVideoChatClientEnabled()}
      />

      {tab === "overview" && (
        <OverviewTab stats={stats} loading={loading} />
      )}

      {tab === "matchmaking" && (
        <MatchmakingTab stats={stats} loading={loading} />
      )}

      {tab === "turn" && settings && (
        <TurnSettingsTab settings={settings} onSaved={load} />
      )}

      {tab === "reports" && (
        <ReportsTab reports={reports} loading={loading} />
      )}

      {tab === "safety" && settings && (
        <SafetyTab settings={settings} stats={stats} loading={loading} />
      )}
    </div>
  );
}

function TabButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`border-b-2 px-4 py-2 text-sm font-medium transition-colors ${
        active ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

function StatCard({ icon, label, value, sublabel }: { icon: React.ReactNode; label: string; value: string | number; sublabel?: string }) {
  return (
    <Card>
      <CardContent className="p-4 md:p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground md:text-sm">{label}</p>
            <p className="mt-1 text-2xl font-bold tabular-nums md:text-3xl">{value}</p>
            {sublabel && <p className="mt-1 text-xs text-muted-foreground">{sublabel}</p>}
          </div>
          <div className="rounded-lg bg-muted p-2">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

/**
 * EnableVideoChatCard — the MASTER on/off switch for the entire Video Chat
 * feature.
 *
 * This is a thin UI wrapper around the existing `video_chat` FeatureFlag.
 * It calls the EXISTING `/api/v1/admin/features` PUT endpoint (the same one
 * the Features admin section uses) — no duplicate API, no duplicate
 * permission logic, no duplicate DB column.
 *
 * Why this card exists (in addition to the Features list):
 *   The Features section shows `video_chat` as one of many flags in a flat
 *   list. Admins looking specifically at the Video Chat section expected to
 *   find the master toggle HERE — but only found TURN settings. This card
 *   surfaces the master toggle in the natural location + makes it
 *   visually impossible to miss.
 *
 * Behavior:
 *   - `enabled === null` → loading state (Skeleton). Never render the
 *     Switch with a stale value — always show a placeholder until the
 *     server-confirmed value arrives.
 *   - `enabled === false` → prominent warning styling (yellow badge +
 *     "Disabled" label). The card explains that users currently see the
 *     "Video chat is not enabled..." message.
 *   - `enabled === true` → success styling (green badge + "Enabled"
 *     label). The card reminds the admin that the feature is live.
 *   - `loading` disables the Switch to prevent double-clicks while the
 *     PUT request is in-flight.
 *   - `onToggle(enabled)` is called with the NEW desired value (true if
 *     currently OFF, false if currently ON).
 *
 * Cache: the server-side `setFeatureFlag` deletes the cached `feature:video_chat`
 * entry immediately after the upsert, so the change is reflected on the
 * next /api/v1/video-chat/config request (no 30s wait).
 */
function EnableVideoChatCard({
  enabled,
  loading,
  onToggle,
  envDisabled,
}: {
  enabled: boolean | null;
  loading: boolean;
  onToggle: (enabled: boolean) => void;
  /**
   * When true, the VIDEO_CHAT_ENABLED env var is not "true" — the Switch
   * is forcibly disabled (the FeatureFlag toggle has no effect while the
   * env var is off). The card shows a clear notice explaining how to
   * re-enable via Netlify Environment Variables.
   */
  envDisabled: boolean;
}) {
  // While we don't yet know the server-side value, show a Skeleton — NEVER
  // render the Switch with a guessed value (would cause a hydration
  // mismatch + risk showing the wrong state for a moment).
  if (enabled === null) {
    return <Skeleton className="h-28 w-full" />;
  }

  // Effective state: if the env var is off, the feature is OFF regardless
  // of the FeatureFlag. We show this in the badge so the admin understands
  // the actual user-visible state.
  const effectivelyEnabled = enabled && !envDisabled;

  return (
    <Card
      className={
        // Subtle visual cue: green left border when ON, yellow when OFF,
        // red when env-disabled (overrides everything).
        envDisabled
          ? "border-l-4 border-l-red-500"
          : effectivelyEnabled
            ? "border-l-4 border-l-green-500"
            : "border-l-4 border-l-yellow-500"
      }
    >
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
        <div className="space-y-1">
          <CardTitle className="flex items-center gap-2 text-base">
            <Video className="h-5 w-5 text-primary" />
            Video Chat
            {envDisabled ? (
              <Badge className="bg-red-100 text-red-700">Disabled (Env)</Badge>
            ) : effectivelyEnabled ? (
              <Badge className="bg-green-100 text-green-700">Enabled</Badge>
            ) : (
              <Badge className="bg-yellow-100 text-yellow-700">Disabled</Badge>
            )}
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Allow users to start video chat sessions. When disabled, every
            video chat API route returns 403 and users see the message
            &ldquo;Video chat is currently disabled.&rdquo;
          </p>
          {envDisabled && (
            <p className="mt-2 text-xs text-red-600 dark:text-red-400">
              <strong>Env kill switch active:</strong> The <code className="rounded bg-muted px-1 py-0.5">VIDEO_CHAT_ENABLED</code> env var
              is set to <code className="rounded bg-muted px-1 py-0.5">&quot;false&quot;</code> (or unset). Toggle below
              is preserved but has no effect until the env var is set to <code className="rounded bg-muted px-1 py-0.5">&quot;true&quot;</code> in Netlify.
            </p>
          )}
        </div>
        <div className="flex items-center gap-3">
          {loading && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
          <Switch
            checked={enabled}
            // Disable the toggle when env var is off OR when a request is in-flight.
            disabled={loading || envDisabled}
            onCheckedChange={(v) => onToggle(v)}
            aria-label="Toggle Video Chat"
          />
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-xs text-muted-foreground">
          Source of truth: the <code className="rounded bg-muted px-1 py-0.5">video_chat</code> feature flag
          (shared with the Admin → Features section). Changes take effect immediately.
          Also configurable from Admin → Features.
          {envDisabled && " Env var override is currently in effect — see notice above."}
        </p>
      </CardContent>
    </Card>
  );
}

function OverviewTab({ stats, loading }: { stats: Stats | null; loading: boolean }) {
  if (loading || !stats) {
    return (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-28" />)}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        <StatCard icon={<Activity className="h-5 w-5 text-green-500" />} label="Active Sessions" value={stats.activeSessions} />
        <StatCard icon={<Users className="h-5 w-5 text-blue-500" />} label="Users Searching" value={stats.usersSearching} />
        <StatCard icon={<TrendingUp className="h-5 w-5 text-purple-500" />} label="P2P Success Rate" value={`${(stats.p2pSuccessRate * 100).toFixed(1)}%`} />
        <StatCard icon={<AlertTriangle className="h-5 w-5 text-orange-500" />} label="TURN Usage" value={`${(stats.turnUsageRate * 100).toFixed(1)}%`} />
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        <StatCard icon={<Activity className="h-5 w-5" />} label="Connected Today" value={stats.connectedToday} />
        <StatCard icon={<AlertTriangle className="h-5 w-5 text-red-500" />} label="Failed Rate" value={`${(stats.failedRate * 100).toFixed(1)}%`} />
        <StatCard icon={<Activity className="h-5 w-5" />} label="Avg Duration" value={`${Math.floor(stats.avgCallDurationSec / 60)}m ${stats.avgCallDurationSec % 60}s`} />
        <StatCard icon={<AlertTriangle className="h-5 w-5" />} label="Total Reports" value={stats.totalReports} />
      </div>

      <Card>
        <CardContent className="p-4">
          <h3 className="mb-2 font-semibold">How P2P Works</h3>
          <p className="text-sm text-muted-foreground">
            Centry uses direct peer-to-peer WebRTC whenever possible. Video/audio travels
            directly between users — never through Centry servers. TURN is a fallback
            relay, OFF by default. Enable it only if the P2P success rate is too low
            (typically due to symmetric NAT or restrictive firewalls).
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function TurnSettingsTab({ settings, onSaved }: { settings: TurnSettings; onSaved: () => void }) {
  const [draft, setDraft] = useState<TurnSettings>(settings);
  const [saving, setSaving] = useState(false);

  useEffect(() => { setDraft(settings); }, [settings]);

  async function handleSave() {
    setSaving(true);
    try {
      await api.put("/api/v1/admin/video-chat/settings", draft);
      toast.success("TURN settings saved.");
      onSaved();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to save settings.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            TURN Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label htmlFor="turn-enabled">Enable TURN</Label>
              <p className="text-xs text-muted-foreground">
                When ON, TURN is used as a fallback when P2P fails. OFF by default (P2P-first).
              </p>
            </div>
            <Switch id="turn-enabled" checked={draft.turnEnabled} onCheckedChange={(v) => setDraft({ ...draft, turnEnabled: v })} />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="turn-url">TURN Server URL</Label>
              <Input id="turn-url" placeholder="turn:turn.example.com" value={draft.turnUrl} onChange={(e) => setDraft({ ...draft, turnUrl: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="turn-port">TURN Port</Label>
              <Input id="turn-port" type="number" placeholder="3478" value={draft.turnPort} onChange={(e) => setDraft({ ...draft, turnPort: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="turn-username">TURN Username</Label>
              <Input id="turn-username" placeholder="username" value={draft.turnUsername} onChange={(e) => setDraft({ ...draft, turnUsername: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="turn-credential">TURN Credential</Label>
              <Input id="turn-credential" type="password" placeholder="secret" value={draft.turnCredential} onChange={(e) => setDraft({ ...draft, turnCredential: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="turn-protocol">TURN Protocol</Label>
              <select
                id="turn-protocol"
                value={draft.turnProtocol}
                onChange={(e) => setDraft({ ...draft, turnProtocol: e.target.value })}
                className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
              >
                <option value="udp">UDP</option>
                <option value="tcp">TCP</option>
                <option value="tls">TLS</option>
              </select>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <Label htmlFor="turn-tls">TURN over TLS</Label>
                <p className="text-xs text-muted-foreground">Secure (port 5349)</p>
              </div>
              <Switch id="turn-tls" checked={draft.turnTls} onCheckedChange={(v) => setDraft({ ...draft, turnTls: v })} />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="stun-url">STUN URL</Label>
            <Input id="stun-url" placeholder="stun:stun.l.google.com:19302" value={draft.stunUrl} onChange={(e) => setDraft({ ...draft, stunUrl: e.target.value })} />
            <p className="text-xs text-muted-foreground">Free Google STUN is the default. Used for P2P candidate discovery.</p>
          </div>

          <div className="rounded-lg bg-muted p-3 text-sm">
            <p className="font-medium">Current Status: {draft.turnEnabled ? <Badge className="ml-1 bg-green-100 text-green-700">TURN ON</Badge> : <Badge className="ml-1 bg-yellow-100 text-yellow-700">P2P Only (TURN OFF)</Badge>}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Matchmaking Limits</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-3">
          <div className="space-y-2">
            <Label htmlFor="max-duration">Max Call Duration (sec)</Label>
            <Input id="max-duration" type="number" value={draft.maxDurationSec} onChange={(e) => setDraft({ ...draft, maxDurationSec: Number(e.target.value) })} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="queue-timeout">Queue Timeout (sec)</Label>
            <Input id="queue-timeout" type="number" value={draft.queueTimeoutSec} onChange={(e) => setDraft({ ...draft, queueTimeoutSec: Number(e.target.value) })} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="min-age">Min Account Age (hours)</Label>
            <Input id="min-age" type="number" value={draft.minAccountAgeHours} onChange={(e) => setDraft({ ...draft, minAccountAgeHours: Number(e.target.value) })} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Debug Diagnostics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div className="space-y-0.5">
              <Label htmlFor="debug-logging">Client Debug Logging</Label>
              <p className="text-xs text-muted-foreground">
                When ON, users' browsers emit <code>[VIDEO]</code> diagnostic logs (state transitions, ICE events, signaling milestones — never SDP / ICE payloads / credentials). Helps diagnose "stuck on Connecting..." issues. OFF by default — turn ON only when actively debugging.
              </p>
            </div>
            <Switch id="debug-logging" checked={draft.debugLogging} onCheckedChange={(v) => setDraft({ ...draft, debugLogging: v })} />
          </div>
          <div className="rounded-lg bg-muted p-3 text-sm">
            <p className="font-medium">Current Status: {draft.debugLogging ? <Badge className="ml-1 bg-blue-100 text-blue-700">Logging ON</Badge> : <Badge className="ml-1 bg-muted text-muted-foreground">Silent</Badge>}</p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
          Save Configuration
        </Button>
      </div>
    </div>
  );
}

function ReportsTab({ reports, loading }: { reports: Report[]; loading: boolean }) {
  if (loading) {
    return <div className="space-y-2">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>;
  }

  if (reports.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 p-12 text-center">
        <AlertTriangle className="h-10 w-10 text-muted-foreground" />
        <p className="text-sm font-medium">No video chat reports</p>
        <p className="text-xs text-muted-foreground">Reports from video chat sessions will appear here.</p>
      </div>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Reason</TableHead>
              <TableHead>Reporter</TableHead>
              <TableHead>Reported</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {reports.map((r) => (
              <TableRow key={r.id}>
                <TableCell><Badge variant="outline">{r.reason}</Badge></TableCell>
                <TableCell className="text-sm">{r.reporter.fullName}</TableCell>
                <TableCell className="text-sm">{r.reported.fullName}</TableCell>
                <TableCell className="max-w-xs truncate text-sm text-muted-foreground">{r.description ?? "—"}</TableCell>
                <TableCell><Badge variant="secondary">{r.status}</Badge></TableCell>
                <TableCell className="text-sm text-muted-foreground">{new Date(r.createdAt).toLocaleString()}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

// ── Matchmaking Tab ────────────────────────────────────────────────────

function MatchmakingTab({ stats, loading }: { stats: Stats | null; loading: boolean }) {
  if (loading || !stats) {
    return <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-28" />)}</div>;
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard icon={<Users className="h-5 w-5 text-blue-500" />} label="Users Searching" value={stats.usersSearching} />
        <StatCard icon={<Activity className="h-5 w-5 text-green-500" />} label="Active Matches" value={stats.activeSessions} />
        <StatCard icon={<TrendingUp className="h-5 w-5 text-purple-500" />} label="Connected Today" value={stats.connectedToday} />
        <StatCard icon={<Activity className="h-5 w-5" />} label="Avg Duration" value={`${Math.floor(stats.avgCallDurationSec / 60)}m ${stats.avgCallDurationSec % 60}s`} />
      </div>

      <Card>
        <CardContent className="p-4">
          <h3 className="mb-2 font-semibold">Matchmaking Algorithm</h3>
          <p className="text-sm text-muted-foreground">
            The matchmaking engine uses <strong>mutual compatibility</strong> — both users
            must accept each other&apos;s gender + country preferences. We never silently
            broaden a user&apos;s filters. If no compatible partner is found, the user
            stays in the queue until timeout (60s default).
          </p>
          <div className="mt-3 space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <Badge variant="outline">Priority 1</Badge>
              <span>Exact gender + exact country</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline">Priority 2</Badge>
              <span>Exact gender + worldwide</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline">Priority 3</Badge>
              <span>Any gender + exact country</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline">Priority 4</Badge>
              <span>Anyone + worldwide</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h3 className="mb-2 font-semibold">Connection Quality</h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-green-600">{(stats.p2pSuccessRate * 100).toFixed(1)}%</p>
              <p className="text-xs text-muted-foreground">P2P Success</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-blue-600">{(stats.turnUsageRate * 100).toFixed(1)}%</p>
              <p className="text-xs text-muted-foreground">TURN Usage</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-red-600">{(stats.failedRate * 100).toFixed(1)}%</p>
              <p className="text-xs text-muted-foreground">Failed</p>
            </div>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">
            If P2P success rate drops below ~70%, consider enabling TURN in the TURN Settings tab.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

// ── Safety Tab ─────────────────────────────────────────────────────────

function SafetyTab({ settings, stats, loading }: { settings: TurnSettings; stats: Stats | null; loading: boolean }) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-500" />
            Age Safety
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label>Minimum Account Age (hours)</Label>
              <p className="text-xs text-muted-foreground">
                New accounts must wait this long before using Video Chat. 0 = no restriction.
              </p>
            </div>
            <Badge variant="outline">{settings.minAccountAgeHours}h</Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            Video Chat connects strangers via live video. The minimum account age helps
            prevent abuse by requiring users to wait before accessing the feature.
            Configure this in the TURN Settings tab.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            Report Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading || !stats ? (
            <Skeleton className="h-20" />
          ) : (
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg border p-4 text-center">
                <p className="text-3xl font-bold text-red-600">{stats.totalReports}</p>
                <p className="text-xs text-muted-foreground">Total Reports</p>
              </div>
              <div className="rounded-lg border p-4 text-center">
                <p className="text-3xl font-bold text-orange-600">{stats.failedRate > 0 ? `${(stats.failedRate * 100).toFixed(1)}%` : "0%"}</p>
                <p className="text-xs text-muted-foreground">Connection Failure Rate</p>
              </div>
            </div>
          )}
          <p className="mt-3 text-xs text-muted-foreground">
            Review individual reports in the Reports tab. Users with repeated reports
            can be suspended from the admin Users section.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h3 className="mb-2 font-semibold">Privacy Protections</h3>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>✓ No video/audio is ever recorded or stored</li>
            <li>✓ No IP addresses are exposed to the other user</li>
            <li>✓ No email or database IDs are exposed during matching</li>
            <li>✓ Gender + country are used ONLY for compatibility matching</li>
            <li>✓ Block system prevents matched users from ever meeting again</li>
            <li>✓ TURN credentials are server-side only (never NEXT_PUBLIC_*)</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
