"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Bot, Activity, AlertTriangle, Plus, Save, Loader2, Trash2, Edit2, FlaskConical,
  ShieldCheck, ShieldX, Clock, ChevronRight, Settings2,
} from "lucide-react";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";

/**
 * AdminAI Moderation — the "AI Moderation" admin section.
 *
 * 5 tabs:
 *   1. Overview  — global status + statistics
 *   2. Providers — list + add + edit + delete + test providers
 *   3. Policy    — enable/disable, content types, per-category thresholds + actions
 *   4. Reviews   — pending AI-flagged content review queue with admin override
 *   5. Audit     — recent audit log entries for AI moderation
 *
 * SECURITY:
 *   - All mutations go through the existing /api/v1/admin/ai-moderation/* routes
 *     which call requireAdmin() server-side. The UI hides the buttons for
 *     non-admins, but that's a UX nicety — the server enforces authorization.
 *   - API keys NEVER appear in the UI. Only the masked form (••••••1234)
 *     is shown. New keys are entered into a password field + sent over HTTPS.
 */

type Tab = "overview" | "providers" | "policy" | "reviews" | "audit";

interface ProviderRow {
  id: string;
  name: string;
  type: string;
  model: string;
  endpoint: string | null;
  priority: number;
  supportsText: boolean;
  supportsImage: boolean;
  supportsVideo: boolean;
  healthStatus: string;
  lastHealthCheck: string | null;
  lastHealthError: string | null;
  totalRequests: number;
  failedRequests: number;
  hasApiKey: boolean;
  apiKeyMasked: string;
  createdAt: string;
  updatedAt: string;
}

interface Stats {
  totalResults: number;
  allowed: number;
  flagged: number;
  hidden: number;
  blocked: number;
  deleted: number;
  pendingReviews: number;
  reviewedApprove: number;
  reviewedReject: number;
  reviewedOverride: number;
  warnings: number;
  restrictions: number;
  suspensions: number;
  bans: number;
  providerErrors: number;
  fallbackUsage: number;
  avgProcessingTimeMs: number;
  topCategories: Array<{ category: string; count: number }>;
  last7Days: Array<{ date: string; count: number }>;
  providers: Array<{
    id: string; name: string; type: string; model: string; priority: number;
    healthStatus: string; totalRequests: number; failedRequests: number;
    failureRate: number; lastHealthCheck: string | null;
  }>;
}

interface ReviewItem {
  id: string;
  status: string;
  resultId: string;
  providerName: string;
  modelName: string;
  contentType: string;
  contentId: string | null;
  categoryScores: Record<string, number | null>;
  score: number;
  confidence: number | null;
  reason: string;
  action: string;
  policyVersion: number;
  fallbackFrom: string | null;
  processingTimeMs: number;
  createdAt: string;
  reviewedAt: string | null;
  reviewerId: string | null;
  reviewerName: string | null;
  adminNotes: string | null;
  appliedActions: string[];
  userId: string | null;
  userFullName: string | null;
  userUsername: string | null;
}

interface Policy {
  enabled: boolean;
  contentTypes: string[];
  categories: Record<string, {
    threshold: number;
    contentAction: string;
    userAction: string;
    restrictionDurationSec?: number;
  }>;
  timeoutMs: number;
  maxRetries: number;
  failureMode: "FAIL_OPEN" | "FAIL_CLOSED";
  retentionDays: number;
  escalationRules?: Array<{
    violationCount: number;
    userAction: string;
    restrictionDurationSec?: number;
  }>;
}

const PROVIDER_TYPES = [
  { value: "openai", label: "OpenAI" },
  { value: "gemini", label: "Google Gemini" },
  { value: "huggingface", label: "Hugging Face" },
  { value: "custom", label: "Custom API" },
  { value: "local", label: "Local / Self-hosted" },
];

const CONTENT_ACTIONS = [
  { value: "ALLOW", label: "Allow" },
  { value: "FLAG_FOR_REVIEW", label: "Flag for Review" },
  { value: "HIDE_CONTENT", label: "Hide Content" },
  { value: "BLOCK_CONTENT", label: "Block Content" },
  { value: "DELETE_CONTENT", label: "Delete Content" },
];

const USER_ACTIONS = [
  { value: "NONE", label: "None" },
  { value: "WARN_USER", label: "Warn User" },
  { value: "RESTRICT_USER", label: "Restrict User" },
  { value: "SUSPEND_USER", label: "Suspend User" },
  { value: "BAN_USER", label: "Ban User" },
];

const CATEGORIES = [
  "sexual", "explicit", "nudity", "suggestive",
  "violence", "graphicViolence", "hate", "harassment",
  "bullying", "selfHarm", "spam", "scam", "illegal",
];

const CONTENT_TYPES = [
  { value: "post", label: "Posts" },
  { value: "article", label: "Articles" },
  { value: "post_comment", label: "Post Comments" },
  { value: "article_comment", label: "Article Comments" },
  { value: "profile_bio", label: "Profile Bio" },
  { value: "profile_full_name", label: "Profile Name" },
];

export function AdminAIModeration() {
  const [tab, setTab] = useState<Tab>("overview");
  const [stats, setStats] = useState<Stats | null>(null);
  const [encryptionKeyConfigured, setEncryptionKeyConfigured] = useState(true);
  const [loadingStats, setLoadingStats] = useState(true);

  const loadStats = useCallback(async () => {
    setLoadingStats(true);
    try {
      const res = await api.get<{ stats: Stats; encryptionKeyConfigured: boolean }>("/api/v1/admin/ai-moderation/stats");
      setStats(res.stats);
      setEncryptionKeyConfigured(res.encryptionKeyConfigured);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to load AI moderation stats.");
    } finally {
      setLoadingStats(false);
    }
  }, []);

  useEffect(() => { void loadStats(); }, [loadStats]);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-bold">
          <Bot className="h-6 w-6 text-primary" />
          AI Moderation
        </h1>
        <p className="text-sm text-muted-foreground">
          Multi-provider AI content moderation. Pluggable adapters for OpenAI, Gemini, Hugging Face, and custom endpoints.
        </p>
      </div>

      {!encryptionKeyConfigured && (
        <Card className="border-l-4 border-l-red-500 bg-red-50 dark:bg-red-950/20">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-red-600" />
              <div className="text-sm">
                <p className="font-semibold text-red-700 dark:text-red-300">MODERATION_ENCRYPTION_KEY is not set</p>
                <p className="mt-1 text-red-600 dark:text-red-400">
                  Provider API keys cannot be encrypted/decrypted without this environment variable.
                  Set it in Netlify Environment Variables (generate with <code className="rounded bg-muted px-1">openssl rand -hex 32</code>).
                  Provider configuration + testing will fail until this is fixed.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex gap-2 border-b overflow-x-auto">
        <TabButton active={tab === "overview"} onClick={() => setTab("overview")}>Overview</TabButton>
        <TabButton active={tab === "providers"} onClick={() => setTab("providers")}>Providers</TabButton>
        <TabButton active={tab === "policy"} onClick={() => setTab("policy")}>Policy</TabButton>
        <TabButton active={tab === "reviews"} onClick={() => setTab("reviews")}>Reviews</TabButton>
      </div>

      {tab === "overview" && (
        <OverviewTab stats={stats} loading={loadingStats} />
      )}
      {tab === "providers" && (
        <ProvidersTab stats={stats} onStatsRefresh={loadStats} />
      )}
      {tab === "policy" && <PolicyTab />}
      {tab === "reviews" && <ReviewsTab />}
    </div>
  );
}

function TabButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`whitespace-nowrap border-b-2 px-4 py-2 text-sm font-medium transition-colors ${
        active ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

function StatCard({ icon, label, value, sublabel }: { icon: React.ReactNode; label: string; value: string | number; sublabel?: string }) {
  return (
    <Card>
      <CardContent className="p-4 md:p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground md:text-sm">{label}</p>
            <p className="mt-1 text-2xl font-bold tabular-nums md:text-3xl">{value}</p>
            {sublabel && <p className="mt-1 text-xs text-muted-foreground">{sublabel}</p>}
          </div>
          <div className="rounded-lg bg-muted p-2">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function OverviewTab({ stats, loading }: { stats: Stats | null; loading: boolean }) {
  if (loading || !stats) {
    return <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{[...Array(8)].map((_, i) => <Skeleton key={i} className="h-28" />)}</div>;
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        <StatCard icon={<Activity className="h-5 w-5 text-blue-500" />} label="Total Results" value={stats.totalResults} />
        <StatCard icon={<ShieldCheck className="h-5 w-5 text-green-500" />} label="Allowed" value={stats.allowed} />
        <StatCard icon={<AlertTriangle className="h-5 w-5 text-amber-500" />} label="Flagged" value={stats.flagged} />
        <StatCard icon={<ShieldX className="h-5 w-5 text-red-500" />} label="Blocked/Deleted" value={stats.blocked + stats.deleted} />
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        <StatCard icon={<Clock className="h-5 w-5 text-purple-500" />} label="Pending Reviews" value={stats.pendingReviews} />
        <StatCard icon={<Activity className="h-5 w-5" />} label="Avg Processing" value={`${stats.avgProcessingTimeMs.toFixed(0)}ms`} />
        <StatCard icon={<AlertTriangle className="h-5 w-5 text-orange-500" />} label="Provider Errors" value={stats.providerErrors} />
        <StatCard icon={<Activity className="h-5 w-5 text-cyan-500" />} label="Fallback Usage" value={stats.fallbackUsage} />
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        <StatCard icon={<AlertTriangle className="h-5 w-5 text-yellow-500" />} label="Warnings" value={stats.warnings} />
        <StatCard icon={<ShieldX className="h-5 w-5 text-orange-500" />} label="Restrictions" value={stats.restrictions} />
        <StatCard icon={<ShieldX className="h-5 w-5 text-red-500" />} label="Suspensions" value={stats.suspensions} />
        <StatCard icon={<ShieldX className="h-5 w-5 text-red-700" />} label="Bans" value={stats.bans} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Provider Health</CardTitle>
        </CardHeader>
        <CardContent>
          {stats.providers.length === 0 ? (
            <p className="text-sm text-muted-foreground">No providers configured. Go to the Providers tab to add one.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Provider</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Health</TableHead>
                  <TableHead>Requests</TableHead>
                  <TableHead>Failure Rate</TableHead>
                  <TableHead>Last Check</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stats.providers.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="font-medium">{p.name}</div>
                      <div className="text-xs text-muted-foreground">{p.type} · {p.model}</div>
                    </TableCell>
                    <TableCell><Badge variant="outline">#{p.priority}</Badge></TableCell>
                    <TableCell>
                      <HealthBadge status={p.healthStatus} />
                    </TableCell>
                    <TableCell className="text-sm tabular-nums">{p.totalRequests}</TableCell>
                    <TableCell className="text-sm tabular-nums">{(p.failureRate * 100).toFixed(1)}%</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {p.lastHealthCheck ? new Date(p.lastHealthCheck).toLocaleString() : "—"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Top Violation Categories (last 30 days)</CardTitle>
        </CardHeader>
        <CardContent>
          {stats.topCategories.length === 0 ? (
            <p className="text-sm text-muted-foreground">No violations recorded yet.</p>
          ) : (
            <div className="space-y-2">
              {stats.topCategories.map((c) => (
                <div key={c.category} className="flex items-center justify-between">
                  <span className="text-sm">{c.category}</span>
                  <Badge variant="secondary">{c.count}</Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function HealthBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; className: string }> = {
    healthy: { label: "Healthy", className: "bg-green-100 text-green-700" },
    degraded: { label: "Degraded", className: "bg-yellow-100 text-yellow-700" },
    offline: { label: "Offline", className: "bg-red-100 text-red-700" },
    unknown: { label: "Unknown", className: "bg-slate-100 text-slate-700" },
  };
  const info = map[status] ?? map.unknown;
  return <Badge className={info.className}>{info.label}</Badge>;
}

function ProvidersTab({ stats, onStatsRefresh }: { stats: Stats | null; onStatsRefresh: () => void }) {
  const [providers, setProviders] = useState<ProviderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingProvider, setEditingProvider] = useState<ProviderRow | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<{ providers: ProviderRow[] }>("/api/v1/admin/ai-moderation/providers");
      setProviders(res.providers);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to load providers.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function handleDelete(id: string, name: string) {
    if (!confirm(`Delete provider "${name}"? This will NOT delete historical results (their providerId becomes NULL — the provider name snapshot is preserved for audit).`)) return;
    try {
      await api.delete(`/api/v1/admin/ai-moderation/providers/${id}`);
      toast.success("Provider deleted.");
      void load();
      void onStatsRefresh();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to delete provider.");
    }
  }

  async function handleTest(id: string) {
    try {
      const res = await api.post<{ result: { healthy: boolean; reason: string; latencyMs: number } }>(
        "/api/v1/admin/ai-moderation/providers/test",
        { providerId: id }
      );
      if (res.result.healthy) {
        toast.success(`Test passed (${res.result.latencyMs}ms). ${res.result.reason}`);
      } else {
        toast.error(`Test failed: ${res.result.reason}`);
      }
      void load();
      void onStatsRefresh();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Test request failed.");
    }
  }

  async function handleToggleActive(provider: ProviderRow) {
    const newPriority = provider.priority === 0 ? 1 : 0;
    try {
      await api.patch(`/api/v1/admin/ai-moderation/providers/${provider.id}`, { priority: newPriority });
      toast.success(newPriority > 0 ? "Provider activated." : "Provider deactivated.");
      void load();
      void onStatsRefresh();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to update provider.");
    }
  }

  if (loading) {
    return <div className="space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Providers</h2>
          <p className="text-sm text-muted-foreground">Configure AI moderation providers. Lower priority = higher precedence (1 = primary).</p>
        </div>
        <Button onClick={() => setShowAddDialog(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Provider
        </Button>
      </div>

      {providers.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Bot className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
            <p className="font-medium">No providers configured</p>
            <p className="mt-1 text-sm text-muted-foreground">Add a provider to start using AI moderation.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {providers.map((p) => (
            <Card key={p.id}>
              <CardContent className="p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{p.name}</span>
                      <Badge variant="outline">{p.type}</Badge>
                      <HealthBadge status={p.healthStatus} />
                      {p.priority === 0 ? (
                        <Badge className="bg-slate-100 text-slate-700">Inactive</Badge>
                      ) : p.priority === 1 ? (
                        <Badge className="bg-blue-100 text-blue-700">Primary</Badge>
                      ) : (
                        <Badge variant="secondary">Fallback #{p.priority}</Badge>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Model: <code className="rounded bg-muted px-1 text-xs">{p.model}</code>
                      {p.endpoint && <span className="ml-2">· Endpoint: <code className="rounded bg-muted px-1 text-xs">{p.endpoint.slice(0, 60)}{p.endpoint.length > 60 ? "…" : ""}</code></span>}
                    </div>
                    <div className="flex flex-wrap gap-1 text-xs text-muted-foreground">
                      {p.supportsText && <Badge variant="outline">Text</Badge>}
                      {p.supportsImage && <Badge variant="outline">Image</Badge>}
                      {p.supportsVideo && <Badge variant="outline">Video</Badge>}
                      {p.hasApiKey && <Badge variant="outline">Key: {p.apiKeyMasked}</Badge>}
                      <Badge variant="outline">{p.totalRequests} req</Badge>
                      <Badge variant="outline">{p.failedRequests} failed</Badge>
                    </div>
                    {p.lastHealthError && (
                      <p className="text-xs text-red-600 dark:text-red-400">Last error: {p.lastHealthError}</p>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1">
                    <Button size="sm" variant="outline" onClick={() => handleTest(p.id)}>
                      <FlaskConical className="mr-1 h-3 w-3" />
                      Test
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setEditingProvider(p)}>
                      <Edit2 className="mr-1 h-3 w-3" />
                      Edit
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleToggleActive(p)}>
                      {p.priority === 0 ? "Activate" : "Deactivate"}
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDelete(p.id, p.name)}>
                      <Trash2 className="mr-1 h-3 w-3" />
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {showAddDialog && (
        <ProviderFormDialog
          mode="create"
          onClose={() => setShowAddDialog(false)}
          onSaved={() => {
            setShowAddDialog(false);
            void load();
            void onStatsRefresh();
          }}
        />
      )}
      {editingProvider && (
        <ProviderFormDialog
          mode="edit"
          provider={editingProvider}
          onClose={() => setEditingProvider(null)}
          onSaved={() => {
            setEditingProvider(null);
            void load();
            void onStatsRefresh();
          }}
        />
      )}
    </div>
  );
}

function ProviderFormDialog({
  mode, provider, onClose, onSaved,
}: {
  mode: "create" | "edit";
  provider?: ProviderRow;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState(provider?.name ?? "");
  const [type, setType] = useState(provider?.type ?? "openai");
  const [model, setModel] = useState(provider?.model ?? "");
  const [apiKey, setApiKey] = useState("");
  const [endpoint, setEndpoint] = useState(provider?.endpoint ?? "");
  const [priority, setPriority] = useState(provider?.priority ?? 1);
  const [supportsText, setSupportsText] = useState(provider?.supportsText ?? true);
  const [supportsImage, setSupportsImage] = useState(provider?.supportsImage ?? false);
  const [supportsVideo, setSupportsVideo] = useState(provider?.supportsVideo ?? false);
  const [testBeforeSave, setTestBeforeSave] = useState(true);
  const [saving, setSaving] = useState(false);

  const requiresApiKey = type === "openai" || type === "gemini" || type === "huggingface";
  const requiresEndpoint = type === "custom" || type === "local";

  async function handleSave() {
    setSaving(true);
    try {
      const body: Record<string, unknown> = {
        name, type, model, priority,
        supportsText, supportsImage, supportsVideo,
        testBeforeSave,
      };
      // Only send apiKey when the admin entered a new one (create mode) or
      // when changing it (edit mode). On edit, leaving the field empty
      // preserves the existing key.
      if (apiKey) body.apiKey = apiKey;
      if (endpoint) body.endpoint = endpoint;

      if (mode === "create") {
        await api.post("/api/v1/admin/ai-moderation/providers", body);
        toast.success("Provider created.");
      } else if (provider) {
        await api.patch(`/api/v1/admin/ai-moderation/providers/${provider.id}`, body);
        toast.success("Provider updated.");
      }
      onSaved();
    } catch (err) {
      const msg = err instanceof ApiClientError ? err.message : "Failed to save provider.";
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  }

  async function handleTestDraft() {
    if (!model) {
      toast.error("Enter a model identifier first.");
      return;
    }
    if (requiresApiKey && !apiKey && mode === "create") {
      toast.error("Enter an API key first.");
      return;
    }
    if (requiresEndpoint && !endpoint) {
      toast.error("Enter an endpoint first.");
      return;
    }
    setSaving(true);
    try {
      const res = await api.post<{ result: { healthy: boolean; reason: string; latencyMs: number } }>(
        "/api/v1/admin/ai-moderation/providers/test",
        {
          draftConfig: {
            type, model,
            apiKey: apiKey || undefined,
            endpoint: endpoint || undefined,
          },
        }
      );
      if (res.result.healthy) {
        toast.success(`Test passed (${res.result.latencyMs}ms). ${res.result.reason}`);
      } else {
        toast.error(`Test failed: ${res.result.reason}`);
      }
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Test request failed.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Add Provider" : `Edit: ${provider?.name}`}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="p-name">Display Name</Label>
              <Input id="p-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="OpenAI Production" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-type">Provider Type</Label>
              <Select value={type} onValueChange={setType} disabled={mode === "edit"}>
                <SelectTrigger id="p-type"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PROVIDER_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-model">Model</Label>
              <Input id="p-model" value={model} onChange={(e) => setModel(e.target.value)} placeholder="omni-moderation-latest" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-priority">Priority (1 = primary, 0 = inactive)</Label>
              <Input id="p-priority" type="number" min={0} max={99} value={priority} onChange={(e) => setPriority(Number(e.target.value))} />
            </div>
            {requiresApiKey && (
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="p-key">API Key {mode === "edit" && provider?.hasApiKey ? `(leave empty to keep: ${provider.apiKeyMasked})` : ""}</Label>
                <Input id="p-key" type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="sk-..." autoComplete="off" />
              </div>
            )}
            {requiresEndpoint && (
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="p-endpoint">Endpoint URL</Label>
                <Input id="p-endpoint" value={endpoint} onChange={(e) => setEndpoint(e.target.value)} placeholder="https://my-moderation-service.com/moderate" />
              </div>
            )}
          </div>

          <div className="rounded-lg border p-3 space-y-3">
            <Label>Capabilities</Label>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2">
                <Switch checked={supportsText} onCheckedChange={setSupportsText} id="cap-text" />
                <Label htmlFor="cap-text">Text</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={supportsImage} onCheckedChange={setSupportsImage} id="cap-image" />
                <Label htmlFor="cap-image">Image</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={supportsVideo} onCheckedChange={setSupportsVideo} id="cap-video" />
                <Label htmlFor="cap-video">Video</Label>
              </div>
            </div>
          </div>

          {mode === "create" && (
            <div className="flex items-center gap-2 rounded-lg border p-3">
              <Switch checked={testBeforeSave} onCheckedChange={setTestBeforeSave} id="test-save" />
              <Label htmlFor="test-save" className="cursor-pointer">
                Test before save (recommended — refuses to save if the provider returns an error)
              </Label>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={handleTestDraft} disabled={saving}>
            <FlaskConical className="mr-2 h-4 w-4" />
            Test
          </Button>
          <Button onClick={handleSave} disabled={saving || !name || !model}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            {mode === "create" ? "Create Provider" : "Save Changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PolicyTab() {
  const [policy, setPolicy] = useState<Policy | null>(null);
  const [version, setVersion] = useState(0);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<{ policy: Policy; version: number }>("/api/v1/admin/ai-moderation/policy");
      setPolicy(res.policy);
      setVersion(res.version);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to load policy.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function handleSave() {
    if (!policy) return;
    setSaving(true);
    try {
      const res = await api.put<{ version: number }>("/api/v1/admin/ai-moderation/policy", policy);
      setVersion(res.version);
      toast.success(`Policy saved (version ${res.version}).`);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to save policy.");
    } finally {
      setSaving(false);
    }
  }

  function updateCategory(cat: string, field: string, value: number | string) {
    setPolicy((p) => {
      if (!p) return p;
      const current = p.categories[cat] ?? { threshold: 0.85, contentAction: "FLAG_FOR_REVIEW", userAction: "NONE" };
      return {
        ...p,
        categories: {
          ...p.categories,
          [cat]: { ...current, [field]: value },
        },
      };
    });
  }

  function toggleContentType(ct: string) {
    setPolicy((p) => {
      if (!p) return p;
      const has = p.contentTypes.includes(ct);
      return {
        ...p,
        contentTypes: has ? p.contentTypes.filter((x) => x !== ct) : [...p.contentTypes, ct],
      };
    });
  }

  if (loading || !policy) {
    return <div className="space-y-4">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-32 w-full" />)}</div>;
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Global Status</span>
            <Badge variant="outline">v{version}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div>
              <Label>Enable AI Moderation</Label>
              <p className="text-xs text-muted-foreground">When OFF, the AI pipeline is bypassed (the rule-based engine continues to run unchanged).</p>
            </div>
            <Switch checked={policy.enabled} onCheckedChange={(v) => setPolicy({ ...policy, enabled: v })} />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="pol-timeout">Per-call timeout (ms)</Label>
              <Input id="pol-timeout" type="number" min={1000} max={60000} value={policy.timeoutMs} onChange={(e) => setPolicy({ ...policy, timeoutMs: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pol-retries">Max retries (on 429/5xx)</Label>
              <Input id="pol-retries" type="number" min={0} max={5} value={policy.maxRetries} onChange={(e) => setPolicy({ ...policy, maxRetries: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pol-retention">Retention (days, 0 = never)</Label>
              <Input id="pol-retention" type="number" min={0} max={3650} value={policy.retentionDays} onChange={(e) => setPolicy({ ...policy, retentionDays: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pol-failure">When all providers fail</Label>
              <Select value={policy.failureMode} onValueChange={(v) => setPolicy({ ...policy, failureMode: v as "FAIL_OPEN" | "FAIL_CLOSED" })}>
                <SelectTrigger id="pol-failure"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="FAIL_OPEN">Fail Open (allow content)</SelectItem>
                  <SelectItem value="FAIL_CLOSED">Fail Closed (flag for review)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Content Types</CardTitle></CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            {CONTENT_TYPES.map((ct) => (
              <div key={ct.value} className="flex items-center gap-2">
                <Switch
                  checked={policy.contentTypes.includes(ct.value)}
                  onCheckedChange={() => toggleContentType(ct.value)}
                  id={`ct-${ct.value}`}
                />
                <Label htmlFor={`ct-${ct.value}`}>{ct.label}</Label>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Per-Category Thresholds + Actions</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {CATEGORIES.map((cat) => {
            const cp = policy.categories[cat] ?? { threshold: 0.85, contentAction: "FLAG_FOR_REVIEW", userAction: "NONE" };
            return (
              <div key={cat} className="grid grid-cols-1 gap-3 rounded-lg border p-3 md:grid-cols-4 md:items-end">
                <div className="md:col-span-1">
                  <Label className="text-sm font-medium capitalize">{cat}</Label>
                  <p className="text-xs text-muted-foreground">Trigger when score ≥ threshold</p>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Threshold (0..1)</Label>
                  <Input type="number" min={0} max={1} step={0.05} value={cp.threshold}
                    onChange={(e) => updateCategory(cat, "threshold", Number(e.target.value))} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Content Action</Label>
                  <Select value={cp.contentAction} onValueChange={(v) => updateCategory(cat, "contentAction", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {CONTENT_ACTIONS.map((a) => <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">User Action</Label>
                  <Select value={cp.userAction} onValueChange={(v) => updateCategory(cat, "userAction", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {USER_ACTIONS.map((a) => <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
          Save Policy (bumps version)
        </Button>
      </div>
    </div>
  );
}

function ReviewsTab() {
  const [items, setItems] = useState<ReviewItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [statusFilter, setStatusFilter] = useState<string>("PENDING");
  const [loading, setLoading] = useState(true);
  const [actionItem, setActionItem] = useState<ReviewItem | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: String(page),
        pageSize: String(pageSize),
      });
      if (statusFilter) params.set("status", statusFilter);
      const res = await api.get<{ items: ReviewItem[]; total: number }>(`/api/v1/admin/ai-moderation/reviews?${params}`);
      setItems(res.items);
      setTotal(res.total);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to load reviews.");
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, statusFilter]);

  useEffect(() => { void load(); }, [load]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-xl font-semibold">Review Queue</h2>
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="PENDING">Pending</SelectItem>
            <SelectItem value="APPROVED">Approved</SelectItem>
            <SelectItem value="REJECTED">Rejected</SelectItem>
            <SelectItem value="OVERRIDDEN">Overridden</SelectItem>
            <SelectItem value="">All</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="space-y-2">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}</div>
      ) : items.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            No review items{statusFilter ? ` with status "${statusFilter}"` : ""}.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {items.map((item) => (
            <Card key={item.id}>
              <CardContent className="p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1 flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant="outline">{item.contentType}</Badge>
                      <Badge variant="secondary">{item.action}</Badge>
                      <Badge variant="outline">Score: {item.score.toFixed(2)}</Badge>
                      {item.fallbackFrom && <Badge className="bg-purple-100 text-purple-700">Fallback from {item.fallbackFrom}</Badge>}
                      <span className="text-xs text-muted-foreground">
                        {new Date(item.createdAt).toLocaleString()}
                      </span>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">Provider:</span>{" "}
                      <code className="rounded bg-muted px-1 text-xs">{item.providerName}</code> /{" "}
                      <code className="rounded bg-muted px-1 text-xs">{item.modelName}</code>
                    </div>
                    {item.userFullName && (
                      <div className="text-sm">
                        <span className="text-muted-foreground">User:</span>{" "}
                        <span className="font-medium">{item.userFullName}</span>
                        <span className="text-muted-foreground"> (@{item.userUsername})</span>
                      </div>
                    )}
                    <div className="text-sm text-muted-foreground">
                      Reason: <span className="text-foreground">{item.reason}</span>
                    </div>
                    {Object.entries(item.categoryScores).filter(([, v]) => v !== null && v !== undefined && (v as number) > 0).length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-1">
                        {Object.entries(item.categoryScores)
                          .filter(([, v]) => v !== null && v !== undefined && (v as number) > 0)
                          .sort(([, a], [, b]) => (b as number) - (a as number))
                          .slice(0, 5)
                          .map(([cat, score]) => (
                            <Badge key={cat} variant="outline" className="text-xs">
                              {cat}: {(score as number).toFixed(2)}
                            </Badge>
                          ))}
                      </div>
                    )}
                    {item.reviewedAt && (
                      <div className="text-xs text-muted-foreground">
                        Reviewed by {item.reviewerName ?? "—"} on {new Date(item.reviewedAt).toLocaleString()}
                        {item.appliedActions.length > 0 && ` · Applied: ${item.appliedActions.join(", ")}`}
                      </div>
                    )}
                  </div>
                  {item.status === "PENDING" && (
                    <Button size="sm" onClick={() => setActionItem(item)}>
                      <Settings2 className="mr-1 h-3 w-3" />
                      Review
                      <ChevronRight className="ml-1 h-3 w-3" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {total > pageSize && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {page} of {Math.ceil(total / pageSize)} ({total} total)
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(page - 1)}>Previous</Button>
            <Button variant="outline" size="sm" disabled={page * pageSize >= total} onClick={() => setPage(page + 1)}>Next</Button>
          </div>
        </div>
      )}

      {actionItem && (
        <ReviewActionDialog
          item={actionItem}
          onClose={() => setActionItem(null)}
          onDone={() => {
            setActionItem(null);
            void load();
          }}
        />
      )}
    </div>
  );
}

function ReviewActionDialog({
  item, onClose, onDone,
}: {
  item: ReviewItem;
  onClose: () => void;
  onDone: () => void;
}) {
  const [status, setStatus] = useState<"APPROVED" | "REJECTED" | "OVERRIDDEN">("APPROVED");
  const [notes, setNotes] = useState("");
  const [overrideContentAction, setOverrideContentAction] = useState<string>("");
  const [overrideUserAction, setOverrideUserAction] = useState<string>("");
  const [saving, setSaving] = useState(false);

  async function handleApply() {
    setSaving(true);
    try {
      const body: Record<string, unknown> = { status, notes: notes || undefined };
      if (overrideContentAction) body.overrideContentAction = overrideContentAction;
      if (overrideUserAction) body.overrideUserAction = overrideUserAction;
      await api.patch(`/api/v1/admin/ai-moderation/reviews/${item.id}`, body);
      toast.success("Review action applied.");
      onDone();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to apply review action.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Review AI Decision</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Card>
            <CardContent className="space-y-2 p-4 text-sm">
              <div><span className="text-muted-foreground">AI Decision:</span> <Badge variant="outline">{item.action}</Badge></div>
              <div><span className="text-muted-foreground">Score:</span> {item.score.toFixed(2)}</div>
              <div><span className="text-muted-foreground">Reason:</span> {item.reason}</div>
              {item.contentId && (
                <div className="text-xs text-muted-foreground">Content ID: <code className="rounded bg-muted px-1">{item.contentId}</code></div>
              )}
            </CardContent>
          </Card>

          <div className="space-y-2">
            <Label>Admin Decision</Label>
            <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="APPROVED">Approve (override AI's BLOCK/HIDE — keep content public)</SelectItem>
                <SelectItem value="REJECTED">Reject (confirm AI's decision OR escalate)</SelectItem>
                <SelectItem value="OVERRIDDEN">Override (apply custom action below)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {status === "OVERRIDDEN" && (
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Override Content Action</Label>
                <Select value={overrideContentAction} onValueChange={setOverrideContentAction}>
                  <SelectTrigger><SelectValue placeholder="(no override)" /></SelectTrigger>
                  <SelectContent>
                    {CONTENT_ACTIONS.map((a) => <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Override User Action</Label>
                <Select value={overrideUserAction} onValueChange={setOverrideUserAction}>
                  <SelectTrigger><SelectValue placeholder="(no override)" /></SelectTrigger>
                  <SelectContent>
                    {USER_ACTIONS.map((a) => <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="notes">Notes (audit trail, optional)</Label>
            <Input id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Reason for override..." />
          </div>
        </div>
        <DialogFooter>
          <Button onClick={handleApply} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
            Apply Decision
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
