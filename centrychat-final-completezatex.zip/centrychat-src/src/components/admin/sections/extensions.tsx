"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Puzzle, Lock, ShieldCheck } from "lucide-react";

export function AdminExtensions() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Extensions</h2>
        <p className="text-sm text-muted-foreground">Predefined, trusted modules that extend the platform safely.</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Puzzle className="h-4 w-4" /> Installed Extensions</CardTitle>
          <CardDescription>No extensions are installed.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Extensions are predefined modules from the trusted source codebase. They can provide settings, UI components, navigation items, API endpoints, migrations, and feature flags.</p>
        </CardContent>
      </Card>
      <Card className="border-amber-500/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base"><Lock className="h-4 w-4 text-amber-500" /> Security Policy</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p className="flex items-start gap-2"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-green-500" /> Extensions must be installed from the trusted codebase.</p>
          <p className="flex items-start gap-2"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-green-500" /> The admin panel <strong className="text-foreground">never</strong> executes arbitrary uploaded JavaScript.</p>
          <p className="flex items-start gap-2"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-green-500" /> No <code className="rounded bg-muted px-1">eval()</code>, <code className="rounded bg-muted px-1">new Function()</code>, <code className="rounded bg-muted px-1">child_process</code>, or raw SQL execution is exposed.</p>
          <p className="flex items-start gap-2"><Badge variant="outline">Safe</Badge> CSS / scoped HTML / JSON configuration only — see Customization.</p>
        </CardContent>
      </Card>
    </div>
  );
}
