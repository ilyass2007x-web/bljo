"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import { Server, Cpu, HardDrive, Cloud } from "lucide-react";

interface SystemInfo {
  system: {
    environment: string;
    nodeVersion: string;
    platform: string;
    uptimeSeconds: number;
    memoryUsageMb: number;
  };
  providers: {
    database: { name: string; ok: boolean; latencyMs: number };
    storage: { name: string };
    email: { name: string };
    cache: { name: string };
    jobs: { name: string };
    realtime: { name: string };
  };
}

export function AdminSystem() {
  const [info, setInfo] = useState<SystemInfo | null>(null);

  useEffect(() => {
    void api.get<SystemInfo>("/api/v1/admin/system").then(setInfo).catch((e) => {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load system info");
    });
  }, []);

  if (!info) return <div className="py-8 text-center text-muted-foreground">Loading…</div>;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">System</h2>
        <p className="text-sm text-muted-foreground">Runtime environment and provider status.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Server className="h-4 w-4" /> Runtime</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-3 text-sm md:grid-cols-3">
          <div><p className="text-muted-foreground">Environment</p><p className="font-medium">{info.system.environment}</p></div>
          <div><p className="text-muted-foreground">Node.js</p><p className="font-medium">{info.system.nodeVersion}</p></div>
          <div><p className="text-muted-foreground">Platform</p><p className="font-medium">{info.system.platform}</p></div>
          <div><p className="text-muted-foreground">Uptime</p><p className="font-medium">{Math.floor(info.system.uptimeSeconds / 60)}m</p></div>
          <div><p className="text-muted-foreground"><HardDrive className="inline h-3 w-3" /> Memory</p><p className="font-medium">{info.system.memoryUsageMb} MB</p></div>
          <div><p className="text-muted-foreground"><Cpu className="inline h-3 w-3" /> Architecture</p><p className="font-medium">{info.system.platform}</p></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Cloud className="h-4 w-4" /> Providers</CardTitle>
          <CardDescription>All infrastructure access goes through abstractions.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {Object.entries(info.providers).map(([key, p]) => (
            <div key={key} className="flex items-center justify-between rounded-lg border p-3 text-sm">
              <span className="capitalize">{key}</span>
              <div className="flex items-center gap-2">
                <Badge variant="outline">{p.name}</Badge>
                {"ok" in p && <Badge variant={p.ok ? "default" : "destructive"}>{p.ok ? "ok" : "down"}</Badge>}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
