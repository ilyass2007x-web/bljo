"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { api, ApiClientError } from "@/lib/client/api";
import { formatNumber } from "@/lib/client/format";
import { toast } from "sonner";
import {
  Search, TrendingUp, CheckCircle, XCircle, AlertTriangle,
  BarChart3, Clock, ArrowUp, ArrowDown, Minus,
} from "lucide-react";
import { cn } from "@/lib/utils";

type Range = "24h" | "7d" | "30d" | "90d" | "1y";

interface SearchAnalytics {
  range: string;
  volume: {
    total: number; successful: number; failed: number;
    successRate: number; avgResultCount: number;
  };
  topSearched: { query: string; count: number }[];
  zeroResult: { query: string; count: number }[];
  trending: { query: string; count: number }[];
  dailyBuckets: { date: string; count: number }[];
  ctr: null;
  filterUsage: null;
}

export function AdminSearchAnalytics() {
  const [data, setData] = useState<SearchAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState<Range>("7d");

  const fetch = useCallback(async (r: Range) => {
    setLoading(true);
    try {
      const res = await api.get<{ analytics: SearchAnalytics }>(`/api/v1/admin/search-analytics?range=${r}`);
      setData(res.analytics);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Unable to load search analytics.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void fetch(range); }, [range, fetch]);

  return (
    <div className="space-y-6">
      {/* Header + Range Selector */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Search Analytics</h2>
          <p className="text-sm text-muted-foreground">All metrics come from real SearchQueryLog data.</p>
        </div>
        <div className="flex flex-wrap gap-1 rounded-lg border bg-muted/30 p-1">
          {(["24h", "7d", "30d", "90d", "1y"] as Range[]).map(r => (
            <button key={r} onClick={() => setRange(r)}
              className={cn("rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                range === r ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>
              {r === "24h" ? "24 Hours" : r === "7d" ? "7 Days" : r === "30d" ? "30 Days" : r === "90d" ? "90 Days" : "1 Year"}
            </button>
          ))}
        </div>
      </div>

      {/* ── Search Volume Stats (spec §15, §18) ─────────────────── */}
      {loading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[0,1,2,3].map(i => <Skeleton key={i} className="h-20 rounded-lg" />)}
        </div>
      ) : data ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-5">
          <StatCard label="Total Searches" value={data.volume.total} icon={Search} color="text-blue-500" />
          <StatCard label="Successful" value={data.volume.successful} icon={CheckCircle} color="text-green-500" />
          <StatCard label="Zero Results" value={data.volume.failed} icon={XCircle} color="text-red-500" />
          <StatCard label="Success Rate" value={data.volume.successRate} suffix="%" icon={TrendingUp} color="text-primary" />
          <StatCard label="Avg Results" value={data.volume.avgResultCount} icon={BarChart3} color="text-purple-500" />
        </div>
      ) : (
        <Card><CardContent className="py-6 text-center text-sm text-destructive">Unable to load search analytics.</CardContent></Card>
      )}

      {/* ── Search Trend Chart (spec §21) ───────────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-sm font-semibold">
            <TrendingUp className="h-4 w-4" /> Search Volume Over Time
          </CardTitle>
          <p className="text-xs text-muted-foreground">Daily search count for the selected period.</p>
        </CardHeader>
        <CardContent>
          {loading ? <Skeleton className="h-48 w-full rounded-lg" /> :
           data && data.dailyBuckets.length > 0 ? <MiniChart data={data.dailyBuckets} /> :
           <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">No search data for this period.</div>}
        </CardContent>
      </Card>

      {/* ── Top Searched + Zero Results + Trending ──────────────── */}
      <div className="grid gap-4 lg:grid-cols-3">
        {/* Top Searched (spec §16) */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold">
              <Search className="h-4 w-4" /> Top Searched Queries
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              [0,1,2,3].map(i => <Skeleton key={i} className="mb-2 h-8 w-full" />)
            ) : data && data.topSearched.length > 0 ? (
              <div className="space-y-1">
                {data.topSearched.map((q, i) => (
                  <div key={q.query} className="flex items-center justify-between rounded border px-2 py-1 text-xs">
                    <span className="flex items-center gap-2 truncate">
                      <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-muted text-[8px] font-bold">{i+1}</span>
                      <span className="truncate" dir="auto">{q.query}</span>
                    </span>
                    <Badge variant="secondary" className="text-[10px]">{formatNumber(q.count)}</Badge>
                  </div>
                ))}
              </div>
            ) : <EmptyState text="No searches in this period." />}
          </CardContent>
        </Card>

        {/* Zero-Result Queries (spec §17) */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold">
              <AlertTriangle className="h-4 w-4 text-amber-500" /> Zero-Result Queries
            </CardTitle>
            <p className="text-xs text-muted-foreground">High demand, no results → missing content.</p>
          </CardHeader>
          <CardContent>
            {loading ? (
              [0,1,2,3].map(i => <Skeleton key={i} className="mb-2 h-8 w-full" />)
            ) : data && data.zeroResult.length > 0 ? (
              <div className="space-y-1">
                {data.zeroResult.map((q, i) => (
                  <div key={q.query} className="flex items-center justify-between rounded border border-amber-500/20 bg-amber-500/5 px-2 py-1 text-xs">
                    <span className="flex items-center gap-2 truncate">
                      <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-[8px] font-bold text-amber-600">{i+1}</span>
                      <span className="truncate" dir="auto">{q.query}</span>
                    </span>
                    <Badge variant="outline" className="text-[10px] text-amber-600">{q.count}× 0 results</Badge>
                  </div>
                ))}
              </div>
            ) : <EmptyState text="No zero-result searches." />}
          </CardContent>
        </Card>

        {/* Trending Searches (spec §14) */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold">
              <TrendingUp className="h-4 w-4" /> Trending Searches (24h)
            </CardTitle>
            <p className="text-xs text-muted-foreground">What users are searching for right now.</p>
          </CardHeader>
          <CardContent>
            {loading ? (
              [0,1,2,3].map(i => <Skeleton key={i} className="mb-2 h-8 w-full" />)
            ) : data && data.trending.length > 0 ? (
              <div className="space-y-1">
                {data.trending.map((q, i) => (
                  <div key={q.query} className="flex items-center justify-between rounded border px-2 py-1 text-xs">
                    <span className="flex items-center gap-2 truncate">
                      <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-muted text-[8px] font-bold">{i+1}</span>
                      <span className="truncate" dir="auto">{q.query}</span>
                    </span>
                    <Badge variant="secondary" className="text-[10px]">{q.count} searches</Badge>
                  </div>
                ))}
              </div>
            ) : <EmptyState text="No trending searches today." />}
          </CardContent>
        </Card>
      </div>

      {/* ── Not Tracked (spec §19, §20 — honesty) ───────────────── */}
      <Card>
        <CardContent className="py-4">
          <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
            <div>
              <span className="font-medium">CTR (Click-Through Rate):</span> Not tracked yet. Future: track whether users click search results.
            </div>
            <div>
              <span className="font-medium">Filter Usage:</span> Not tracked yet. Future: track which search categories (All/People/Posts/Articles) are used most.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ── Sub-components ──────────────────────────────────────────────────────────

function StatCard({ label, value, icon: Icon, color, suffix }: {
  label: string; value: number; icon: React.ComponentType<{ className?: string }>; color?: string; suffix?: string;
}) {
  return (
    <Card>
      <CardContent className="p-3">
        <div className="flex items-center gap-2">
          <Icon className={cn("h-4 w-4", color ?? "text-muted-foreground")} />
          <div>
            <p className="text-lg font-bold">{formatNumber(value)}{suffix}</p>
            <p className="text-[10px] text-muted-foreground">{label}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function EmptyState({ text }: { text: string }) {
  return <p className="py-6 text-center text-sm text-muted-foreground">{text}</p>;
}

function MiniChart({ data }: { data: { date: string; count: number }[] }) {
  const values = data.map(d => d.count);
  const maxVal = Math.max(1, ...values);
  const width = 600, height = 200, pad = 30;
  const points = data.map((d, i) => ({
    x: pad + (i / Math.max(1, data.length - 1)) * (width - 2 * pad),
    y: height - pad - (d.count / maxVal) * (height - 2 * pad),
  }));
  const pathD = points.length > 0
    ? points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ") : "";
  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ minWidth: 300, height: 200 }}>
        {[0, 0.25, 0.5, 0.75, 1].map(ratio => {
          const y = height - pad - ratio * (height - 2 * pad);
          const val = Math.round(maxVal * ratio);
          return (
            <g key={ratio}>
              <line x1={pad} y1={y} x2={width - pad} y2={y} stroke="currentColor" strokeWidth={0.5} className="text-border" />
              <text x={pad - 5} y={y + 3} textAnchor="end" fontSize={9} className="text-muted-foreground">{val}</text>
            </g>
          );
        })}
        {pathD && (
          <>
            <path d={`${pathD} L ${(points[points.length-1]!.x).toFixed(1)} ${height-pad} L ${pad} ${height-pad} Z`} fill="currentColor" className="text-primary/10" />
            <path d={pathD} fill="none" stroke="currentColor" strokeWidth={2} className="text-primary" />
            {points.length <= 31 && points.map((p, i) => (
              <circle key={i} cx={p.x} cy={p.y} r={2} fill="currentColor" className="text-primary" />
            ))}
          </>
        )}
        {data.length > 0 && (
          <>
            <text x={pad} y={height - 8} textAnchor="start" fontSize={9} className="text-muted-foreground">{data[0]!.date}</text>
            <text x={width - pad} y={height - 8} textAnchor="end" fontSize={9} className="text-muted-foreground">{data[data.length-1]!.date}</text>
          </>
        )}
      </svg>
    </div>
  );
}
