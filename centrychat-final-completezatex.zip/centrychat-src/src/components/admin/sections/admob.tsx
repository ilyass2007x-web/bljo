"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import {
  Loader2,
  Save,
  Plus,
  Pencil,
  Trash2,
  Power,
  PowerOff,
  Search,
  Smartphone,
  Activity,
  Layers,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";

/**
 * AdminAdMob — the AdMob management section in the Admin Dashboard.
 *
 * Four tabs (spec §24 + §53):
 *   1. Overview — status cards + active units summary.
 *   2. Applications — Android + iOS app settings (App ID, package name, enable).
 *   3. Ad Units — table with search/filter + create/edit dialog.
 *   4. Settings — global enable, environment, min app versions, config version.
 *
 * SEPARATE from AdSense (spec §30 + §31). The admin nav has both "AdSense"
 * and "AdMob" as distinct sections.
 */

interface AdMobAdUnitDTO {
  id: string;
  name: string;
  description: string | null;
  platform: string;
  adUnitId: string;
  format: string;
  placement: string;
  priority: number;
  active: boolean;
  environment: string;
  fallbackAdUnitId: string | null;
  createdAt: string;
  updatedAt: string;
}

interface AdMobAppDTO {
  id: string;
  platform: string;
  appName: string;
  packageName: string | null;
  admobAppId: string;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

interface AdMobSettingsDTO {
  enabled: boolean;
  configVersion: number;
  environment: string;
  androidMinVersion: string;
  iosMinVersion: string;
}

const ADMOB_FORMATS = ["BANNER", "INTERSTITIAL", "REWARDED", "NATIVE", "APP_OPEN"] as const;
const ADMOB_PLACEMENTS: Record<string, string> = {
  APP_HOME_TOP: "App — Home Top",
  APP_HOME_BOTTOM: "App — Home Bottom",
  APP_FEED: "App — In Feed",
  APP_FEED_BETWEEN_POSTS: "App — Between Posts",
  APP_ARTICLE_TOP: "App — Article Top",
  APP_ARTICLE_MIDDLE: "App — Article Middle",
  APP_ARTICLE_BOTTOM: "App — Article Bottom",
  APP_REELS: "App — Reels",
  APP_PROFILE: "App — Profile",
  APP_SEARCH: "App — Search",
  APP_APP_OPEN: "App — App Open",
  APP_INTERSTITIAL: "App — Interstitial",
  APP_REWARDED: "App — Rewarded",
};
const ADMOB_ENVIRONMENTS = ["ALL", "DEVELOPMENT", "PRODUCTION"] as const;

export function AdminAdMob() {
  const [tab, setTab] = useState<"overview" | "apps" | "units" | "settings">("overview");

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Google AdMob</h2>
        <p className="text-sm text-muted-foreground">
          Mobile app ad management (Android + iOS). Configuration changes take effect within 60 seconds — no app update required.
        </p>
      </div>

      <div className="flex gap-1 border-b">
        {(["overview", "apps", "units", "settings"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`border-b-2 px-4 py-2 text-sm font-medium capitalize transition-colors ${
              tab === t
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t === "apps" ? "Applications" : t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === "overview" && <OverviewPanel />}
      {tab === "apps" && <AppsPanel />}
      {tab === "units" && <UnitsPanel />}
      {tab === "settings" && <SettingsPanel />}
    </div>
  );
}

// ── Overview Panel ───────────────────────────────────────────────────────

function OverviewPanel() {
  const [settings, setSettings] = useState<AdMobSettingsDTO | null>(null);
  const [apps, setApps] = useState<AdMobAppDTO[]>([]);
  const [units, setUnits] = useState<AdMobAdUnitDTO[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [s, a, u] = await Promise.all([
          api.get<{ settings: AdMobSettingsDTO }>("/api/v1/admin/admob/settings"),
          api.get<{ apps: AdMobAppDTO[] }>("/api/v1/admin/admob/apps"),
          api.get<{ units: AdMobAdUnitDTO[] }>("/api/v1/admin/admob/units"),
        ]);
        setSettings(s.settings);
        setApps(a.apps);
        setUnits(u.units);
      } catch (e) {
        toast.error(e instanceof ApiClientError ? e.message : "Failed to load AdMob status");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading || !settings) {
    return <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>;
  }

  const activeCount = units.filter((u) => u.active).length;
  const inactiveCount = units.length - activeCount;
  const androidApp = apps.find((a) => a.platform === "ANDROID");
  const iosApp = apps.find((a) => a.platform === "IOS");

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">AdMob Status</CardTitle>
            {settings.enabled ? <ToggleRight className="h-4 w-4 text-green-500" /> : <ToggleLeft className="h-4 w-4 text-muted-foreground" />}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{settings.enabled ? "Enabled" : "Disabled"}</div>
            <p className="text-xs text-muted-foreground">Config v{settings.configVersion}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Android App</CardTitle>
            <Smartphone className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-sm">
              {androidApp?.enabled ? (
                <Badge className="bg-green-500">Active</Badge>
              ) : (
                <Badge variant="secondary">Inactive</Badge>
              )}
            </div>
            <p className="mt-1 truncate text-xs font-mono text-muted-foreground">
              {androidApp?.admobAppId || "Not configured"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">iOS App</CardTitle>
            <Smartphone className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-sm">
              {iosApp?.enabled ? (
                <Badge className="bg-green-500">Active</Badge>
              ) : (
                <Badge variant="secondary">Inactive</Badge>
              )}
            </div>
            <p className="mt-1 truncate text-xs font-mono text-muted-foreground">
              {iosApp?.admobAppId || "Not configured"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Total Ad Units</CardTitle>
            <Layers className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{units.length}</div>
            <p className="text-xs text-muted-foreground">{activeCount} active · {inactiveCount} inactive</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Active Ad Units</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCount}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Environment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold capitalize">{settings.environment}</div>
            <p className="text-xs text-muted-foreground">
              {settings.environment === "development" ? "Test ads only" : "Production ads"}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Mobile Config API</CardTitle>
          <CardDescription>The endpoint the mobile app fetches to get its ad configuration</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border bg-muted/30 p-3">
            <code className="text-xs break-all">
              GET /api/v1/mobile/ads/config?platform=android&appVersion=1.0.0
            </code>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Rate-limited: 60 requests/min per IP. Cached: 60s server-side. The app should cache locally + re-fetch when the version changes.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

// ── Apps Panel ───────────────────────────────────────────────────────────

function AppsPanel() {
  const [apps, setApps] = useState<AdMobAppDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const data = await api.get<{ apps: AdMobAppDTO[] }>("/api/v1/admin/admob/apps");
      setApps(data.apps);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load apps");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function saveApp(platform: string, field: string, value: string | boolean) {
    setSaving(platform);
    try {
      const body: Record<string, unknown> = { platform };
      body[field] = value;
      const data = await api.put<{ app: AdMobAppDTO }>("/api/v1/admin/admob/apps", body);
      setApps((prev) => prev.map((a) => (a.platform === platform ? data.app : a)));
      toast.success(`${platform} app updated`);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update app");
    } finally {
      setSaving(null);
    }
  }

  if (loading) {
    return <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>;
  }

  return (
    <div className="space-y-6">
      {apps.map((app) => (
        <Card key={app.platform}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Smartphone className="h-4 w-4" />
              {app.platform === "ANDROID" ? "Android App" : "iOS App"}
            </CardTitle>
            <CardDescription>
              {app.platform === "ANDROID" ? "Package name + AdMob App ID" : "Bundle ID + AdMob App ID"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <AppField
              label="App Name"
              value={app.appName}
              onSave={(v) => saveApp(app.platform, "appName", v)}
              saving={saving === app.platform}
              placeholder={app.platform === "ANDROID" ? "CentryChat Android" : "CentryChat iOS"}
            />
            <AppField
              label={app.platform === "ANDROID" ? "Package Name" : "Bundle ID"}
              value={app.packageName || ""}
              onSave={(v) => saveApp(app.platform, "packageName", v)}
              saving={saving === app.platform}
              placeholder="com.centrychat.app"
            />
            <AppField
              label="AdMob App ID"
              value={app.admobAppId}
              onSave={(v) => saveApp(app.platform, "admobAppId", v)}
              saving={saving === app.platform}
              placeholder="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY"
              mono
            />
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <Label>Ads Enabled ({app.platform})</Label>
                <p className="text-xs text-muted-foreground">When off, the mobile app shows NO ads for this platform.</p>
              </div>
              <Switch
                checked={app.enabled}
                onCheckedChange={(v) => saveApp(app.platform, "enabled", v)}
                disabled={saving === app.platform}
              />
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function AppField({
  label,
  value,
  onSave,
  saving,
  placeholder,
  mono,
}: {
  label: string;
  value: string;
  onSave: (v: string) => void;
  saving: boolean;
  placeholder?: string;
  mono?: boolean;
}) {
  const [draft, setDraft] = useState(value);
  const [editing, setEditing] = useState(false);

  useEffect(() => { setDraft(value); }, [value]);

  return (
    <div className="space-y-1">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {!editing ? (
        <div className="flex items-center gap-2">
          <code className={`flex-1 truncate rounded border bg-muted/30 px-3 py-2 text-sm ${mono ? "font-mono" : ""}`}>
            {value || <span className="text-muted-foreground">—</span>}
          </code>
          <Button variant="outline" size="sm" onClick={() => setEditing(true)}>Edit</Button>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <Input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={placeholder}
            className={mono ? "font-mono" : ""}
          />
          <Button
            size="sm"
            onClick={() => { onSave(draft); setEditing(false); }}
            disabled={saving}
          >
            {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
          </Button>
          <Button variant="outline" size="sm" onClick={() => { setDraft(value); setEditing(false); }}>
            Cancel
          </Button>
        </div>
      )}
    </div>
  );
}

// ── Units Panel ──────────────────────────────────────────────────────────

function UnitsPanel() {
  const [units, setUnits] = useState<AdMobAdUnitDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [platformFilter, setPlatformFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<AdMobAdUnitDTO | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AdMobAdUnitDTO | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set("search", search.trim());
      if (platformFilter !== "all") params.set("platform", platformFilter);
      if (statusFilter !== "all") params.set("status", statusFilter);
      const data = await api.get<{ units: AdMobAdUnitDTO[] }>(`/api/v1/admin/admob/units?${params}`);
      setUnits(data.units);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load ad units");
    } finally {
      setLoading(false);
    }
  }, [search, platformFilter, statusFilter]);

  useEffect(() => { void load(); }, [load]);

  async function toggleActive(unit: AdMobAdUnitDTO) {
    try {
      const data = await api.patch<{ unit: AdMobAdUnitDTO }>(`/api/v1/admin/admob/units/${unit.id}`, {
        active: !unit.active,
      });
      setUnits((prev) => prev.map((u) => (u.id === unit.id ? data.unit : u)));
      toast.success(`"${unit.name}" ${unit.active ? "disabled" : "enabled"}`);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to toggle");
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    try {
      await api.delete(`/api/v1/admin/admob/units/${deleteTarget.id}`);
      setUnits((prev) => prev.filter((u) => u.id !== deleteTarget.id));
      toast.success(`"${deleteTarget.name}" deleted`);
      setDeleteTarget(null);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to delete");
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search by name or ad unit ID..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" />
        </div>
        <Select value={platformFilter} onValueChange={setPlatformFilter}>
          <SelectTrigger className="w-[120px]"><SelectValue placeholder="Platform" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Platforms</SelectItem>
            <SelectItem value="ANDROID">Android</SelectItem>
            <SelectItem value="IOS">iOS</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v)}>
          <SelectTrigger className="w-[120px]"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
        <Button onClick={() => { setEditing(null); setEditorOpen(true); }}>
          <Plus className="mr-1.5 h-4 w-4" /> Create Ad Unit
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>
          ) : units.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">No ad units found.</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Platform</TableHead>
                  <TableHead>Format</TableHead>
                  <TableHead>Placement</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {units.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell>
                      <div className="font-medium">{u.name}</div>
                      <div className="text-xs font-mono text-muted-foreground">{u.adUnitId}</div>
                    </TableCell>
                    <TableCell><Badge variant="outline" className="text-xs">{u.platform}</Badge></TableCell>
                    <TableCell><Badge variant="outline" className="text-xs">{u.format}</Badge></TableCell>
                    <TableCell className="text-xs">{ADMOB_PLACEMENTS[u.placement] ?? u.placement}</TableCell>
                    <TableCell>{u.active ? <Badge className="bg-green-500">Active</Badge> : <Badge variant="secondary">Inactive</Badge>}</TableCell>
                    <TableCell>{u.priority}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditing(u); setEditorOpen(true); }} title="Edit"><Pencil className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleActive(u)} title={u.active ? "Disable" : "Enable"}>{u.active ? <PowerOff className="h-4 w-4" /> : <Power className="h-4 w-4" />}</Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(u)} title="Delete"><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <UnitEditorDialog open={editorOpen} unit={editing} onClose={() => setEditorOpen(false)} onSaved={() => { setEditorOpen(false); void load(); }} />

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete &quot;{deleteTarget?.name}&quot;?</AlertDialogTitle>
            <AlertDialogDescription>This ad unit will be permanently deleted. The mobile app will stop showing this ad on the next config refresh.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function UnitEditorDialog({ open, unit, onClose, onSaved }: { open: boolean; unit: AdMobAdUnitDTO | null; onClose: () => void; onSaved: () => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [platform, setPlatform] = useState("ANDROID");
  const [adUnitId, setAdUnitId] = useState("");
  const [format, setFormat] = useState("BANNER");
  const [placement, setPlacement] = useState("APP_HOME_BOTTOM");
  const [priority, setPriority] = useState(10);
  const [active, setActive] = useState(true);
  const [environment, setEnvironment] = useState("ALL");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (unit) {
      setName(unit.name); setDescription(unit.description ?? ""); setPlatform(unit.platform);
      setAdUnitId(unit.adUnitId); setFormat(unit.format); setPlacement(unit.placement);
      setPriority(unit.priority); setActive(unit.active); setEnvironment(unit.environment);
    } else {
      setName(""); setDescription(""); setPlatform("ANDROID"); setAdUnitId("");
      setFormat("BANNER"); setPlacement("APP_HOME_BOTTOM"); setPriority(10);
      setActive(true); setEnvironment("ALL");
    }
  }, [open, unit]);

  async function save() {
    if (!name.trim() || !adUnitId.trim()) { toast.error("Name and Ad Unit ID are required"); return; }
    setSaving(true);
    try {
      const payload = { name: name.trim(), description: description.trim() || null, platform, adUnitId: adUnitId.trim(), format, placement, priority, active, environment };
      if (unit) {
        await api.patch(`/api/v1/admin/admob/units/${unit.id}`, payload);
        toast.success("Updated");
      } else {
        await api.post("/api/v1/admin/admob/units", payload);
        toast.success("Created");
      }
      onSaved();
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to save");
    } finally { setSaving(false); }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>{unit ? "Edit Ad Unit" : "Create Ad Unit"}</DialogTitle>
          <DialogDescription>AdMob ad unit for {platform}. Ad Unit ID must match the format ca-app-pub-XXX/YYY.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={100} placeholder="e.g. Home Banner Android" />
          </div>
          <div className="space-y-2">
            <Label>Description (optional)</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} maxLength={500} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Platform</Label>
              <Select value={platform} onValueChange={setPlatform} disabled={!!unit}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="ANDROID">Android</SelectItem><SelectItem value="IOS">iOS</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Ad Unit ID</Label>
              <Input value={adUnitId} onChange={(e) => setAdUnitId(e.target.value)} placeholder="ca-app-pub-XXX/YYY" className="font-mono text-xs" disabled={!!unit} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Format</Label>
              <Select value={format} onValueChange={setFormat}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ADMOB_FORMATS.map((f) => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Placement</Label>
              <Select value={placement} onValueChange={setPlacement}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-[300px]">{Object.entries(ADMOB_PLACEMENTS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Priority</Label>
              <Input type="number" min={1} max={100} value={priority} onChange={(e) => setPriority(Number(e.target.value) || 10)} />
            </div>
            <div className="space-y-2">
              <Label>Environment</Label>
              <Select value={environment} onValueChange={setEnvironment}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ADMOB_ENVIRONMENTS.map((e) => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div><Label>Active</Label><p className="text-xs text-muted-foreground">When off, the ad never shows.</p></div>
            <Switch checked={active} onCheckedChange={setActive} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={save} disabled={saving}>
            {saving ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Save className="mr-1.5 h-4 w-4" />}
            {unit ? "Save Changes" : "Create Unit"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Settings Panel ───────────────────────────────────────────────────────

function SettingsPanel() {
  const [settings, setSettings] = useState<AdMobSettingsDTO | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [environment, setEnvironment] = useState("production");
  const [androidMin, setAndroidMin] = useState("1.0.0");
  const [iosMin, setIosMin] = useState("1.0.0");

  const load = useCallback(async () => {
    try {
      const data = await api.get<{ settings: AdMobSettingsDTO }>("/api/v1/admin/admob/settings");
      setSettings(data.settings);
      setEnabled(data.settings.enabled);
      setEnvironment(data.settings.environment);
      setAndroidMin(data.settings.androidMinVersion);
      setIosMin(data.settings.iosMinVersion);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to load settings");
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function save() {
    setSaving(true);
    try {
      const data = await api.put<{ settings: AdMobSettingsDTO }>("/api/v1/admin/admob/settings", {
        enabled, environment, androidMinVersion: androidMin, iosMinVersion: iosMin,
      });
      setSettings(data.settings);
      toast.success("AdMob settings saved. Config version bumped.");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to save");
    } finally { setSaving(false); }
  }

  if (loading || !settings) {
    return <div className="py-8 text-center text-muted-foreground"><Loader2 className="mx-auto h-6 w-6 animate-spin" /></div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader><CardTitle className="text-base">Global AdMob Settings</CardTitle></CardHeader>
        <CardContent className="space-y-5">
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div><Label>Enable AdMob</Label><p className="text-xs text-muted-foreground">Master switch for all mobile app ads.</p></div>
            <Switch checked={enabled} onCheckedChange={setEnabled} />
          </div>
          <div className="space-y-2">
            <Label>Environment</Label>
            <Select value={environment} onValueChange={setEnvironment}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="production">Production (real ads)</SelectItem>
                <SelectItem value="development">Development (test ads only)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              In development mode, only ad units with environment=DEVELOPMENT or ALL appear in the config.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Minimum App Versions</CardTitle><CardDescription>Apps below these versions get enabled=false (spec §22).</CardDescription></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Android Minimum Version</Label>
            <Input value={androidMin} onChange={(e) => setAndroidMin(e.target.value)} placeholder="1.0.0" />
          </div>
          <div className="space-y-2">
            <Label>iOS Minimum Version</Label>
            <Input value={iosMin} onChange={(e) => setIosMin(e.target.value)} placeholder="1.0.0" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Configuration Version</CardTitle></CardHeader>
        <CardContent>
          <p className="text-sm">Current version: <Badge variant="outline" className="font-mono">v{settings.configVersion}</Badge></p>
          <p className="mt-2 text-xs text-muted-foreground">
            The version auto-increments on every config change (settings, apps, ad units). The mobile app uses this to detect when to refresh its cache.
          </p>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => load()} disabled={saving}>Reset</Button>
        <Button onClick={save} disabled={saving}>
          {saving ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Save className="mr-1.5 h-4 w-4" />}
          Save Settings
        </Button>
      </div>
    </div>
  );
}
