"use client";

import { Component, type ErrorInfo, type ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, RefreshCw } from "lucide-react";

/**
 * SectionErrorBoundary — wraps a single admin section so a rendering bug
 * in ONE section doesn't crash the ENTIRE admin panel.
 *
 * PHASE-12 fix: previously, ANY rendering error in any admin section
 * component would bubble up to the global Error Boundary
 * (src/app/global-error.tsx) → showing "Something went wrong" for the
 * ENTIRE page (including the admin nav sidebar). The user had to reload
 * + would lose their place in the admin panel.
 *
 * This boundary catches the error at the SECTION level + shows a graceful
 * inline error card WITHIN the section's content area. The admin nav
 * sidebar stays functional — the user can click another section to
 * continue working.
 *
 * USAGE in admin-panel.tsx:
 *   <SectionErrorBoundary sectionName="SEO">
 *     <AdminSEO />
 *   </SectionErrorBoundary>
 *
 * SECURITY: the actual error message is NOT shown to the user in
 * production (could leak DB structure or internal paths). Only a generic
 * "Something went wrong in this section" message is shown. The real error
 * is logged to the browser console (visible in dev tools) + can be
 * picked up by error monitoring (Sentry, etc.) in the future.
 *
 * RECOVERY: the "Try again" button calls `setState({ hasError: false })`
 * which re-renders the section. If the underlying bug is fixed (e.g. the
 * API returns a valid response on retry), the section recovers. If not,
 * the error card stays + the admin can navigate to another section.
 */
interface SectionErrorBoundaryProps {
  children: ReactNode;
  /** The display name of the section (e.g. "SEO", "Users", "Settings"). */
  sectionName?: string;
}

interface SectionErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

export class SectionErrorBoundary extends Component<
  SectionErrorBoundaryProps,
  SectionErrorBoundaryState
> {
  constructor(props: SectionErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): SectionErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log to browser console — visible in dev tools. In production, this
    // can be picked up by error monitoring (Sentry, LogRocket, etc.).
    // We do NOT send the error to a server endpoint here (would need an
    // API route + could leak internal details). The browser console is
    // sufficient for debugging.
    console.error(
      `[Admin Section Error] ${this.props.sectionName ?? "Unknown"}:`,
      error,
      errorInfo
    );
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: undefined });
  };

  render() {
    if (this.state.hasError) {
      const sectionName = this.props.sectionName ?? "this section";
      return (
        <Card className="border-destructive/30">
          <CardContent className="flex flex-col items-center justify-center gap-4 py-12 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10">
              <AlertTriangle className="h-6 w-6 text-destructive" />
            </div>
            <div>
              <h3 className="text-base font-semibold">{sectionName} — Something went wrong</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                An unexpected error occurred while loading this section. You can try again, or navigate to another section — the rest of the admin panel is unaffected.
              </p>
            </div>
            <Button onClick={this.handleRetry} variant="outline" size="sm">
              <RefreshCw className="mr-2 h-3.5 w-3.5" />
              Try again
            </Button>
            {process.env.NODE_ENV === "development" && this.state.error && (
              <details className="mt-2 w-full max-w-2xl text-left">
                <summary className="cursor-pointer text-xs text-muted-foreground">
                  Error details (dev only)
                </summary>
                <pre className="mt-2 overflow-auto rounded border bg-muted/30 p-3 text-[10px] text-destructive">
                  {this.state.error.message}
                  {"\n\n"}
                  {this.state.error.stack}
                </pre>
              </details>
            )}
          </CardContent>
        </Card>
      );
    }

    return this.props.children;
  }
}
