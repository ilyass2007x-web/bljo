"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  LayoutDashboard,
  Users,
  Flag,
  Shield,
  ShieldAlert,
  Bell,
  ToggleLeft,
  Settings2,
  Database,
  Server,
  ScrollText,
  UserCog,
  Palette,
  BarChart3,
  Search,
  TrendingUp,
  Globe,
  Activity,
  Menu,
  ArrowLeft,
  LogOut,
  Moon,
  Sun,
  Mail,
  MessageSquareLock,
  FileText,
  Video,
  DollarSign,
  Smartphone,
  Share2,
  Hash,
  Folder,
  ShieldBan,
  Bot,
} from "lucide-react";
import { useTheme } from "next-themes";
import { useAuthStore } from "@/lib/client/auth-store";
import { api } from "@/lib/client/api";
import { cn } from "@/lib/utils";
import { NotificationCenter } from "@/components/shared/notification-center";
import { AdminDashboard } from "./sections/dashboard";
import { AdminContent } from "./sections/content";
import { AdminAnalytics } from "./sections/analytics";
import { AdminSearchAnalytics } from "./sections/search-analytics";
import { AdminTrending } from "./sections/trending";
import { AdminSEO } from "./sections/seo";
import { AdminUsers } from "./sections/users";
import { AdminReports } from "./sections/reports";
import { AdminModeration } from "./sections/moderation";
// Content Safety — centralized moderation engine dashboard + queue (separate
// from the user-submitted Reports system above). Shows what the automated
// moderation engine blocked/flagged across posts, articles, comments, replies,
// and profile bios.
import { AdminContentSafety } from "./sections/content-safety";
import { AdminNotifications } from "./sections/notifications";
import { AdminFeatures } from "./sections/features";
import { AdminExtensions } from "./sections/extensions";
import { AdminSettings } from "./sections/settings";
import { AdminSecurity } from "./sections/security";
import { AdminDatabase } from "./sections/database";
import { AdminSystem } from "./sections/system";
import { AdminSystemHealth } from "./sections/system-health";
import { AdminAudit } from "./sections/audit";
import { AdminAccount } from "./sections/account";
import { AdminCustomization } from "./sections/customization";
import { AdminInfrastructure } from "./sections/infrastructure";
import { AdminHomepage } from "./sections/homepage";
import { AdminApis } from "./sections/apis";
import { AdminRecommendation } from "./sections/recommendation";
import { AdminEmail } from "./sections/email";
import { AdminTutorialVideos } from "./sections/tutorial-videos";
import { AdminAdSense } from "./sections/adsense";
import { AdminAdMob } from "./sections/admob";
import { AdminSocialSharing } from "./sections/social-sharing";
// Phase 2 — Topics: admin section for managing topics.
import { AdminTopics } from "./sections/topics";
// Phase 5 — Collections: minimal admin section (feature flag toggle +
// public collections moderation list).
import { AdminCollections } from "./sections/collections";
// Pages & Legal — admin CMS for /about, /privacy, /terms, /contact.
import { AdminSitePages } from "./sections/site-pages";
// Traffic Analytics — visitor sources, article traffic, realtime.
import { AdminTrafficAnalytics } from "./sections/traffic-analytics";
// Blocked Domains — admin-controlled global domain/URL blocklist.
import { AdminBlockedDomains } from "./sections/blocked-domains";
// Video Chat — admin dashboard + TURN configuration.
import { AdminVideoChat } from "./sections/video-chat";
import { AdminAIModeration } from "./sections/ai-moderation";
import { SectionErrorBoundary } from "./section-error-boundary";

type Section =
  | "dashboard"
  | "content"
  | "users"
  | "analytics"
  | "search-analytics"
  | "trending"
  | "seo"
  | "reports"
  | "moderation"
  | "content-safety"
  | "notifications"
  | "features"
  | "extensions"
  | "homepage"
  | "customization"
  | "recommendation"
  | "tutorial-videos"
  | "settings"
  | "security"
  | "infrastructure"
  | "email"
  | "database"
  | "system"
  | "system-health"
  | "apis"
  | "audit"
  | "adsense"
  | "admob"
  | "social-sharing"
  | "topics"
  | "collections"
  | "site-pages"
  | "traffic-analytics"
  | "blocked-domains"
  | "video-chat"
  | "ai-moderation"
  | "account";

const NAV: { id: Section; label: string; icon: typeof Users }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "content", label: "Content", icon: FileText },
  { id: "users", label: "Users", icon: Users },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "traffic-analytics", label: "Traffic Analytics", icon: TrendingUp },
  { id: "search-analytics", label: "Search Analytics", icon: Search },
  { id: "trending", label: "Trending", icon: TrendingUp },
  { id: "seo", label: "SEO", icon: Globe },
  { id: "reports", label: "Reports", icon: Flag },
  { id: "moderation", label: "Moderation", icon: Shield },
  // Content Safety — automated moderation engine (separate from the
  // user-submitted Reports system above).
  { id: "content-safety", label: "Content Safety", icon: ShieldAlert },
  { id: "notifications", label: "Notifications", icon: Bell },
  { id: "features", label: "Features", icon: ToggleLeft },
  { id: "extensions", label: "Extensions", icon: ToggleLeft },
  { id: "homepage", label: "Homepage", icon: LayoutDashboard },
  { id: "customization", label: "Customization", icon: Palette },
  { id: "recommendation", label: "Recommendation", icon: ToggleLeft },
  { id: "tutorial-videos", label: "Tutorial Videos", icon: Video },
  { id: "adsense", label: "AdSense", icon: DollarSign },
  { id: "admob", label: "AdMob", icon: Smartphone },
  { id: "social-sharing", label: "Social Sharing", icon: Share2 },
  { id: "settings", label: "Settings", icon: Settings2 },
  { id: "security", label: "Security", icon: Shield },
  { id: "infrastructure", label: "Infrastructure", icon: Server },
  { id: "email", label: "Email", icon: Mail },
  { id: "database", label: "Database", icon: Database },
  { id: "system", label: "System", icon: Server },
  { id: "system-health", label: "System Health", icon: Activity },
  { id: "apis", label: "APIs", icon: Settings2 },
  { id: "audit", label: "Audit Logs", icon: ScrollText },
  // Phase 2 — Topics: admin can manage topics here.
  { id: "topics", label: "Topics", icon: Hash },
  // Phase 5 — Collections: minimal admin section (toggle feature flag +
  // view public collections).
  { id: "collections", label: "Collections", icon: Folder },
  // Pages & Legal — CMS for /about, /privacy, /terms, /contact.
  { id: "site-pages", label: "Pages & Legal", icon: FileText },
  // Blocked Domains — global domain/URL blocklist.
  { id: "blocked-domains", label: "Blocked Domains", icon: ShieldBan },
  // Video Chat — admin dashboard + TURN settings.
  { id: "video-chat", label: "Video Chat", icon: Video },
  // AI Moderation — multi-provider content moderation with admin-configurable policies.
  { id: "ai-moderation", label: "AI Moderation", icon: Bot },
  { id: "account", label: "Admin Account", icon: UserCog },
];

export function AdminPanel() {
  const router = useRouter();
  const { user, clear } = useAuthStore();
  const { theme, setTheme } = useTheme();
  const [section, setSection] = useState<Section>("dashboard");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  async function logout() {
    try {
      await api.post("/api/v1/auth/logout");
    } catch {
      /* ignore */
    }
    clear();
    router.push("/");
  }

  const nav = (
    <nav className="flex flex-col gap-0.5 p-2">
      {NAV.map((item) => (
        <button
          key={item.id}
          onClick={() => {
            setSection(item.id);
            setMobileNavOpen(false);
          }}
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors hover:bg-accent",
            section === item.id ? "bg-accent text-accent-foreground" : "text-muted-foreground"
          )}
        >
          <item.icon className="h-4 w-4" />
          {item.label}
        </button>
      ))}
    </nav>
  );

  return (
    <div className="flex h-screen flex-col bg-background">
      <header className="flex h-14 shrink-0 items-center justify-between border-b px-3 md:px-4">
        <div className="flex items-center gap-2">
          <Sheet open={mobileNavOpen} onOpenChange={setMobileNavOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <div className="flex h-14 items-center gap-2 border-b px-4">
                <MessageSquareLock className="h-5 w-5 text-primary" />
                <span className="font-semibold">Admin Panel</span>
              </div>
              <div className="flex h-[calc(100vh-3.5rem)] flex-col">
                <div className="flex-1 overflow-y-auto">{nav}</div>
              </div>
            </SheetContent>
          </Sheet>
          <div className="flex items-center gap-2">
            <MessageSquareLock className="h-5 w-5 text-primary" />
            <span className="hidden font-semibold sm:inline">Admin Panel</span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <NotificationCenter enabled={!!user} onNavigate={() => router.push("/")} />
          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={() => router.push("/")} title="Back to app">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" onClick={logout} title="Sign out">
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        <aside className="hidden w-60 shrink-0 border-r lg:block">
          <div className="flex h-full flex-col">
            <div className="flex-1 overflow-y-auto">{nav}</div>
            {user && (
              <div className="border-t p-3 text-xs text-muted-foreground">
                <p className="truncate font-medium text-foreground">{user.fullName}</p>
                <p className="truncate">{user.email}</p>
                <p className="mt-1">{user.role}</p>
              </div>
            )}
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-6xl p-4 md:p-6">
            {/* PHASE-12 fix: wrap EACH section in a SectionErrorBoundary so a
                rendering bug in ONE section doesn't crash the ENTIRE admin
                panel. The boundary catches the error at the section level +
                shows a graceful inline error card. The nav sidebar stays
                functional — the user can click another section to continue. */}
            <SectionErrorBoundary sectionName="Dashboard">
              {section === "dashboard" && <AdminDashboard />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Content">
              {section === "content" && <AdminContent />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Users">
              {section === "users" && <AdminUsers />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Analytics">
              {section === "analytics" && <AdminAnalytics />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Traffic Analytics">
              {section === "traffic-analytics" && <AdminTrafficAnalytics />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Search Analytics">
              {section === "search-analytics" && <AdminSearchAnalytics />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Trending">
              {section === "trending" && <AdminTrending />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="SEO">
              {section === "seo" && <AdminSEO />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Reports">
              {section === "reports" && <AdminReports />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Moderation">
              {section === "moderation" && <AdminModeration />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Content Safety">
              {section === "content-safety" && <AdminContentSafety />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Notifications">
              {section === "notifications" && <AdminNotifications />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Features">
              {section === "features" && <AdminFeatures />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Extensions">
              {section === "extensions" && <AdminExtensions />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Customization">
              {section === "customization" && <AdminCustomization />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Settings">
              {section === "settings" && <AdminSettings />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Security">
              {section === "security" && <AdminSecurity />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Infrastructure">
              {section === "infrastructure" && <AdminInfrastructure />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Email">
              {section === "email" && <AdminEmail />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Database">
              {section === "database" && <AdminDatabase />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="System">
              {section === "system" && <AdminSystem />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="System Health">
              {section === "system-health" && <AdminSystemHealth />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Homepage">
              {section === "homepage" && <AdminHomepage />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Recommendation">
              {section === "recommendation" && <AdminRecommendation />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Tutorial Videos">
              {section === "tutorial-videos" && <AdminTutorialVideos />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="APIs">
              {section === "apis" && <AdminApis />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Audit Logs">
              {section === "audit" && <AdminAudit />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="AdSense">
              {section === "adsense" && <AdminAdSense />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="AdMob">
              {section === "admob" && <AdminAdMob />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Social Sharing">
              {section === "social-sharing" && <AdminSocialSharing />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Topics">
              {section === "topics" && <AdminTopics />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Collections">
              {section === "collections" && <AdminCollections />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Pages & Legal">
              {section === "site-pages" && <AdminSitePages />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Blocked Domains">
              {section === "blocked-domains" && <AdminBlockedDomains />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Video Chat">
              {section === "video-chat" && <AdminVideoChat />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="AI Moderation">
              {section === "ai-moderation" && <AdminAIModeration />}
            </SectionErrorBoundary>
            <SectionErrorBoundary sectionName="Admin Account">
              {section === "account" && <AdminAccount />}
            </SectionErrorBoundary>
          </div>
        </main>
      </div>
    </div>
  );
}
