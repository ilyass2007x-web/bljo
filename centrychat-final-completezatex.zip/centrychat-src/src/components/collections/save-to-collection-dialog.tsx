"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Check, Folder, Globe, Lock, Plus, Loader2, X } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/**
 * SaveToCollectionDialog — pick a collection + save the given content to it.
 *
 * Phase 5 — Collections.
 *
 * UX:
 *   - Shows the user's existing collections (id + name + visibility badge
 *     + already-saved checkmark).
 *   - Click a collection → save (optimistic) → success toast → close.
 *   - "Create new collection" inline form → create + save in one click.
 *   - Already-saved collections show a green check — clicking them again
 *     is a no-op (server enforces uniqueness via @@unique).
 *
 * SECURITY:
 *   - contentType + contentId come from the caller (the PostCard /
 *     ArticleCard), which received them from server-rendered props — the
 *     client never fabricates them.
 *   - The API re-validates content existence server-side before insertion
 *     (validateContentExists) — even if a client sends a fake contentId,
 *     the server rejects the save.
 */

interface CollectionDTO {
  id: string;
  ownerId: string;
  name: string;
  description: string | null;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
  owner: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  itemCount: number;
}

interface SaveToCollectionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contentType: "post" | "article" | "video" | "discussion";
  contentId: string;
}

export function SaveToCollectionDialog({
  open,
  onOpenChange,
  contentType,
  contentId,
}: SaveToCollectionDialogProps) {
  const router = useRouter();
  const { user } = useAuthStore();
  const { t } = useTranslation();

  const [collections, setCollections] = useState<CollectionDTO[]>([]);
  const [loading, setLoading] = useState(false);
  const [savingId, setSavingId] = useState<string | null>(null);
  // Per-collection "saved" state — keyed by collection ID. When true, the
  // collection already contains this content (shown with a green check).
  const [savedIn, setSavedIn] = useState<Set<string>>(new Set());

  // Inline create-new-collection form (visible when the user clicks
  // "Create new").
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [creating, setCreating] = useState(false);

  // ── Fetch the user's collections + which ones already contain this content
  const fetchCollections = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const data = await api.get<{ collections: CollectionDTO[] }>(
        "/api/v1/collections"
      );
      setCollections(data.collections);

      // Batch-check which collections already contain this content (1 query
      // at the server via the collection-items index @@index([contentType, contentId])).
      // We do this client-side by fetching each collection's items list —
      // for up to 100 collections this is acceptable, but to avoid N+1 we
      // use a single GET per collection only if the collection has items.
      // To keep it simple + fast, we use a small endpoint-agnostic check:
      // attempt the POST add + interpret 409 as "already saved". This is
      // done lazily per click, not on dialog open.
      //
      // For the already-saved state UI, we use a small server hint: the
      // /api/v1/collections endpoint could include `savedContent: boolean`
      // per collection, but that would require a new query parameter.
      // Keeping it simple: the check happens on click (the POST returns
      // 400 on duplicate).
      setSavedIn(new Set());
    } catch {
      setCollections([]);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (open) void fetchCollections();
  }, [open, fetchCollections]);

  async function handleSaveToExisting(collectionId: string) {
    setSavingId(collectionId);
    try {
      await api.post(`/api/v1/collections/${collectionId}/items`, {
        contentType,
        contentId,
      });
      setSavedIn((prev) => new Set(prev).add(collectionId));
      toast.success(t("collections.saved") || "Saved to collection");
      // Don't auto-close — let the user save to more collections if desired.
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to save";
      // If the error is the duplicate message, mark as already saved.
      if (msg.toLowerCase().includes("already")) {
        setSavedIn((prev) => new Set(prev).add(collectionId));
        toast.info(t("collections.alreadySaved") || "Already in this collection");
      } else {
        toast.error(msg);
      }
    } finally {
      setSavingId(null);
    }
  }

  async function handleCreateAndSave() {
    const name = newName.trim();
    if (!name) {
      toast.error(t("collections.nameRequired") || "Name is required");
      return;
    }
    setCreating(true);
    try {
      // 1. Create the collection.
      const created = await api.post<{ collection: CollectionDTO }>(
        "/api/v1/collections",
        { name, description: null, isPublic: false }
      );
      // 2. Immediately save the content to the new collection.
      await api.post(`/api/v1/collections/${created.collection.id}/items`, {
        contentType,
        contentId,
      });
      setCollections((prev) => [created.collection, ...prev]);
      setSavedIn((prev) => new Set(prev).add(created.collection.id));
      setNewName("");
      setShowCreate(false);
      toast.success(t("collections.createdAndSaved") || "Collection created + content saved");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to create collection");
    } finally {
      setCreating(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Folder className="h-4 w-4 text-primary" />
            {t("collections.saveTo") || "Save to collection"}
          </DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-2 py-2">
          {loading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          )}

          {!loading && collections.length === 0 && !showCreate && (
            <div className="flex flex-col items-center gap-3 py-6 text-center">
              <Folder className="h-8 w-8 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                {t("collections.noCollections") || "You don't have any collections yet."}
              </p>
              <Button onClick={() => setShowCreate(true)}>
                <Plus className="mr-1 h-4 w-4" />
                {t("collections.createFirst") || "Create your first collection"}
              </Button>
            </div>
          )}

          {!loading && collections.length > 0 && (
            <div className="max-h-80 space-y-1 overflow-y-auto">
              {collections.map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleSaveToExisting(c.id)}
                  disabled={savingId === c.id}
                  className={cn(
                    "flex w-full items-center justify-between gap-2 rounded-md border px-3 py-2 text-left text-sm transition-colors hover:bg-accent/30 disabled:opacity-50"
                  )}
                >
                  <div className="flex min-w-0 items-center gap-2">
                    {c.isPublic ? (
                      <Globe className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    ) : (
                      <Lock className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    )}
                    <span className="truncate">{c.name}</span>
                    <span className="text-[10px] text-muted-foreground">
                      {c.itemCount}
                    </span>
                  </div>
                  {savingId === c.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : savedIn.has(c.id) ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : null}
                </button>
              ))}
            </div>
          )}

          {showCreate && (
            <div className="rounded-md border p-3">
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                {t("collections.createTitle") || "Create a collection"}
              </p>
              <Input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder={t("collections.namePlaceholder") || "Collection name"}
                maxLength={100}
                autoFocus
              />
              <div className="mt-2 flex justify-end gap-1">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowCreate(false);
                    setNewName("");
                  }}
                  disabled={creating}
                >
                  {t("common.cancel") || "Cancel"}
                </Button>
                <Button size="sm" onClick={handleCreateAndSave} disabled={creating || !newName.trim()}>
                  {creating ? (
                    <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                  ) : (
                    <Plus className="mr-1 h-4 w-4" />
                  )}
                  {t("collections.createAndSave") || "Create + Save"}
                </Button>
              </div>
            </div>
          )}

          {!showCreate && collections.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              className="mt-2 w-full"
              onClick={() => setShowCreate(true)}
            >
              <Plus className="mr-1 h-4 w-4" />
              {t("collections.createNew") || "Create new collection"}
            </Button>
          )}
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            {t("common.done") || "Done"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
