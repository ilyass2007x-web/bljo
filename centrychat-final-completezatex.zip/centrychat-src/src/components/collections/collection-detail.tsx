"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  ArrowLeft,
  Loader2,
  Folder,
  Globe,
  Lock,
  Trash2,
  Pencil,
  Share2,
  X,
} from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/**
 * CollectionDetailPage — single collection view + edit controls (for owner).
 *
 * Phase 5 — Collections.
 *
 * Routing: /?view=collection&id=<id>
 *
 * Visibility (server-side enforced):
 *   - Owner: sees everything (incl. private + edit/delete controls).
 *   - Non-owner: sees the collection ONLY if isPublic=true. Otherwise
 *     the API returns 404 (no information leakage).
 *
 * Layout:
 *   - MainNav
 *   - Back button + collection name + visibility badge
 *   - Description + item count + owner row (avatar, name, verified)
 *   - Edit/Delete/Share buttons (owner only)
 *   - Items list (ordered by position) with content hydration cards
 *     (post / article / video / discussion).
 *   - Reorder buttons (owner only): up / down arrows per item.
 *   - Remove button (owner only) per item.
 */

interface CollectionOwner {
  id: string;
  fullName: string;
  username: string;
  avatarColor: string | null;
  avatarUrl: string | null;
  isVerified: boolean;
}

interface CollectionDTO {
  id: string;
  ownerId: string;
  name: string;
  description: string | null;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
  owner: CollectionOwner;
  itemCount: number;
}

interface HydratedContent {
  contentType: "post" | "article" | "video" | "discussion";
  contentId: string;
  title: string | null;
  excerpt: string | null;
  coverImage: string | null;
  videoUrl: string | null;
  authorId: string | null;
  authorFullName: string | null;
  authorUsername: string | null;
  authorAvatarColor: string | null;
  authorAvatarUrl: string | null;
  authorIsVerified: boolean;
  createdAt: string | null;
  parentPostId: string | null;
  parentArticleId: string | null;
}

interface CollectionItemDTO {
  id: string;
  collectionId: string;
  contentType: "post" | "article" | "video" | "discussion";
  contentId: string;
  position: number;
  addedAt: string;
  content: HydratedContent | null;
}

interface CollectionItemProps {
  collectionId: string;
  item: CollectionItemDTO;
  isOwner: boolean;
  onRemoved: (itemId: string) => void;
  onReorder: (itemId: string, newPosition: number) => void;
}

export function CollectionDetailPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const collectionId = searchParams.get("id") ?? "";
  const { user } = useAuthStore();
  const { t, fmtRelative } = useTranslation();

  const [collection, setCollection] = useState<CollectionDTO | null>(null);
  const [items, setItems] = useState<CollectionItemDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Edit dialog state.
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({
    name: "",
    description: "",
    isPublic: false,
  });
  const [saving, setSaving] = useState(false);

  // Share dialog state.
  const [shareOpen, setShareOpen] = useState(false);
  const [shareRecipient, setShareRecipient] = useState("");
  const [sharing, setSharing] = useState(false);

  const fetchCollection = useCallback(async () => {
    if (!collectionId) return;
    setLoading(true);
    setError(null);
    try {
      // Fetch collection + items in parallel.
      const [collData, itemsData] = await Promise.all([
        api.get<{ collection: CollectionDTO }>(
          `/api/v1/collections/${collectionId}`
        ),
        api.get<{ items: CollectionItemDTO[]; nextCursor: string | null }>(
          `/api/v1/collections/${collectionId}/items?limit=50`
        ),
      ]);
      setCollection(collData.collection);
      setItems(itemsData.items);
    } catch (e) {
      if (e instanceof ApiClientError) {
        setError(e.message);
      } else {
        setError("Failed to load collection");
      }
    } finally {
      setLoading(false);
    }
  }, [collectionId]);

  useEffect(() => {
    void fetchCollection();
  }, [fetchCollection]);

  const isOwner = !!(collection && user && collection.ownerId === user.id);

  function openEdit() {
    if (!collection) return;
    setEditForm({
      name: collection.name,
      description: collection.description ?? "",
      isPublic: collection.isPublic,
    });
    setEditOpen(true);
  }

  async function handleSaveEdit() {
    if (!collection) return;
    setSaving(true);
    try {
      const data = await api.patch<{ collection: CollectionDTO }>(
        `/api/v1/collections/${collection.id}`,
        {
          name: editForm.name.trim(),
          description: editForm.description.trim() || null,
          isPublic: editForm.isPublic,
        }
      );
      setCollection(data.collection);
      setEditOpen(false);
      toast.success(t("collections.updatedToast") || "Collection updated");
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to update collection";
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!collection) return;
    try {
      await api.delete(`/api/v1/collections/${collection.id}`);
      toast.success(t("collections.deleted") || "Collection deleted");
      router.push("/?view=collections");
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to delete collection";
      toast.error(msg);
    }
  }

  async function handleShare() {
    if (!collection) return;
    const recipientId = shareRecipient.trim();
    if (!recipientId) {
      toast.error(t("collections.recipientRequired") || "Recipient ID is required");
      return;
    }
    setSharing(true);
    try {
      const data = await api.post<{
        ok: boolean;
        shared: boolean;
        recipient: { id: string; username: string; fullName: string };
      }>(`/api/v1/collections/${collection.id}/share`, { recipientId });
      setShareOpen(false);
      setShareRecipient("");
      toast.success(
        `${t("collections.sharedWith") || "Shared with"} ${data.recipient.fullName}`
      );
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to share collection";
      toast.error(msg);
    } finally {
      setSharing(false);
    }
  }

  function handleRemovedItem(itemId: string) {
    setItems((prev) => prev.filter((i) => i.id !== itemId));
    setCollection((c) => (c ? { ...c, itemCount: Math.max(0, c.itemCount - 1) } : c));
  }

  function handleReorderItem(itemId: string, newPosition: number) {
    // Optimistic local reorder: move the item to the new position, rewrite
    // positions 0..N-1 locally. The server will be the source of truth on
    // next refresh; the API also rewrites positions deterministically.
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.id === itemId);
      if (idx === -1) return prev;
      const next = [...prev];
      const [moved] = next.splice(idx, 1);
      const clamped = Math.max(0, Math.min(newPosition, next.length));
      next.splice(clamped, 0, moved);
      return next.map((it, i) => ({ ...it, position: i }));
    });
  }

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile sticky header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()} title="Back">
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium">{collection?.name ?? "Collection"}</p>
          <p className="truncate text-xs text-muted-foreground">
            {collection?.itemCount ?? 0} {t("collections.items") || "items"}
          </p>
        </div>
        {isOwner && (
          <Button size="sm" variant="ghost" onClick={openEdit} aria-label="Edit">
            <Pencil className="h-4 w-4" />
          </Button>
        )}
      </header>

      <div className="mx-auto max-w-3xl">
        {/* Desktop header */}
        <div className="hidden items-center gap-3 border-b px-4 py-3 md:flex md:px-6">
          <Button variant="ghost" size="icon" onClick={() => router.back()} title="Back">
            <ArrowLeft className="h-5 w-5 rtl-flip" />
          </Button>
          <Folder className="h-5 w-5 text-primary" />
          <h1 className="min-w-0 flex-1 truncate text-lg font-semibold">
            {collection?.name ?? "Collection"}
          </h1>
          {collection && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              {collection.isPublic ? (
                <>
                  <Globe className="h-3.5 w-3.5" />
                  {t("collections.public") || "Public"}
                </>
              ) : (
                <>
                  <Lock className="h-3.5 w-3.5" />
                  {t("collections.private") || "Private"}
                </>
              )}
            </div>
          )}
          {isOwner && collection && (
            <>
              {collection.isPublic && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShareOpen(true)}
                  aria-label={t("collections.share") || "Share"}
                >
                  <Share2 className="h-4 w-4" />
                </Button>
              )}
              <Button
                size="sm"
                variant="ghost"
                onClick={openEdit}
                aria-label={t("common.edit") || "Edit"}
              >
                <Pencil className="h-4 w-4" />
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-destructive"
                    aria-label={t("collections.delete") || "Delete"}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>
                      {t("collections.deleteConfirmTitle") || "Delete this collection?"}
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      {t("collections.deleteConfirmDesc") ||
                        "This collection and all its items will be permanently removed. The underlying content (posts/articles/videos) will not be affected."}
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>
                      {t("common.cancel") || "Cancel"}
                    </AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleDelete}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      {t("common.delete") || "Delete"}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </>
          )}
        </div>

        <div className="p-4 md:p-6">
          {loading && (
            <div className="flex flex-col gap-3">
              <Skeleton className="h-16 w-full rounded-lg" />
              <Skeleton className="h-32 w-full rounded-lg" />
              <Skeleton className="h-32 w-full rounded-lg" />
            </div>
          )}

          {!loading && error && (
            <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
              {error}
              <Button
                variant="ghost"
                size="sm"
                className="ml-2"
                onClick={() => fetchCollection()}
              >
                {t("common.retry") || "Retry"}
              </Button>
            </div>
          )}

          {!loading && !error && collection && (
            <>
              {/* Owner + description */}
              <div className="mb-4 flex items-start gap-3 rounded-lg border p-3">
                <Avatar
                  name={collection.owner.fullName}
                  color={collection.owner.avatarColor}
                  src={collection.owner.avatarUrl}
                  size="sm"
                  className="cursor-pointer"
                  onClick={() =>
                    router.push(
                      `/?view=profile&username=${encodeURIComponent(collection.owner.username)}`
                    )
                  }
                />
                <div className="min-w-0 flex-1">
                  <button
                    onClick={() =>
                      router.push(
                        `/?view=profile&username=${encodeURIComponent(collection.owner.username)}`
                      )
                    }
                    className="flex items-center gap-1 text-sm font-medium hover:underline"
                  >
                    <span className="truncate">{collection.owner.fullName}</span>
                    {collection.owner.isVerified && <VerifiedBadge size={12} />}
                  </button>
                  {collection.description && (
                    <p className="mt-1 text-xs text-muted-foreground">
                      {collection.description}
                    </p>
                  )}
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    {t("collections.updatedLabel") || "Updated"} {fmtRelative(collection.updatedAt)}
                  </p>
                </div>
              </div>

              {/* Items list */}
              {items.length === 0 ? (
                <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
                  {isOwner
                    ? (t("collections.emptyItems") ||
                      "No items yet. Use the Save button on any post or article to add content here.")
                    : (t("collections.emptyItemsViewer") || "This collection has no items yet.")}
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  {items.map((item, index) => (
                    <CollectionItemCard
                      key={item.id}
                      collectionId={collection.id}
                      item={item}
                      isOwner={isOwner}
                      onRemoved={handleRemovedItem}
                      onReorder={handleReorderItem}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Edit dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {t("collections.editTitle") || "Edit collection"}
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-3 py-2">
            <div>
              <label className="text-xs font-medium text-muted-foreground">
                {t("collections.name") || "Name"}
              </label>
              <Input
                value={editForm.name}
                onChange={(e) => setEditForm((f) => ({ ...f, name: e.target.value }))}
                maxLength={100}
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">
                {t("collections.description") || "Description (optional)"}
              </label>
              <Textarea
                value={editForm.description}
                onChange={(e) => setEditForm((f) => ({ ...f, description: e.target.value }))}
                maxLength={500}
                rows={3}
              />
            </div>
            <div className="flex items-center justify-between rounded-md border p-3">
              <div className="flex items-center gap-2">
                {editForm.isPublic ? (
                  <Globe className="h-4 w-4 text-primary" />
                ) : (
                  <Lock className="h-4 w-4 text-muted-foreground" />
                )}
                <div>
                  <p className="text-sm font-medium">
                    {t("collections.visibility") || "Public collection"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {t("collections.visibilityDesc") ||
                      "Public collections can be viewed by other users + appear in search."}
                  </p>
                </div>
              </div>
              <Switch
                checked={editForm.isPublic}
                onCheckedChange={(v) => setEditForm((f) => ({ ...f, isPublic: v }))}
                aria-label={t("collections.visibility") || "Public"}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditOpen(false)} disabled={saving}>
              {t("common.cancel") || "Cancel"}
            </Button>
            <Button
              onClick={handleSaveEdit}
              disabled={saving || !editForm.name.trim()}
            >
              {saving && <Loader2 className="mr-1 h-4 w-4 animate-spin" />}
              {t("common.save") || "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Share dialog */}
      <Dialog open={shareOpen} onOpenChange={setShareOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {t("collections.shareTitle") || "Share collection"}
            </DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <p className="mb-2 text-xs text-muted-foreground">
              {t("collections.shareDesc") ||
                "Enter the recipient's user ID to share this public collection with them."}
            </p>
            <Input
              value={shareRecipient}
              onChange={(e) => setShareRecipient(e.target.value)}
              placeholder={t("collections.recipientPlaceholder") || "Recipient user ID"}
            />
            <p className="mt-2 text-[10px] text-muted-foreground">
              {t("collections.shareNote") ||
                "The recipient will receive a notification with a link to the collection."}
            </p>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setShareOpen(false)} disabled={sharing}>
              {t("common.cancel") || "Cancel"}
            </Button>
            <Button onClick={handleShare} disabled={sharing || !shareRecipient.trim()}>
              {sharing && <Loader2 className="mr-1 h-4 w-4 animate-spin" />}
              <Share2 className="mr-1 h-4 w-4" />
              {t("collections.share") || "Share"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ── Single item card ───────────────────────────────────────────────────────

function CollectionItemCard({
  collectionId,
  item,
  isOwner,
  onRemoved,
  onReorder,
}: CollectionItemProps) {
  const router = useRouter();
  const { t, fmtRelative } = useTranslation();
  const [removing, setRemoving] = useState(false);
  const [reordering, setReordering] = useState(false);

  async function handleRemove() {
    setRemoving(true);
    try {
      await api.delete(`/api/v1/collections/${collectionId}/items/${item.id}`);
      onRemoved(item.id);
      toast.success(t("collections.itemRemoved") || "Item removed");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to remove item");
    } finally {
      setRemoving(false);
    }
  }

  async function handleReorder(direction: "up" | "down") {
    setReordering(true);
    const newPosition = direction === "up" ? item.position - 1 : item.position + 1;
    onReorder(item.id, newPosition); // optimistic local reorder
    try {
      await api.patch(
        `/api/v1/collections/${collectionId}/items/${item.id}`,
        { position: newPosition }
      );
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to reorder");
      // Revert optimistic update — caller should refetch.
    } finally {
      setReordering(false);
    }
  }

  function openContent() {
    if (!item.content) return;
    const c = item.content;
    if (c.contentType === "post") {
      router.push(`/?view=comments&postId=${encodeURIComponent(c.contentId)}`);
    } else if (c.contentType === "article" || c.contentType === "video") {
      router.push(`/articles/${encodeURIComponent(c.contentId)}`);
    } else if (c.contentType === "discussion") {
      // Deep-link to the parent post/article's comments with the target
      // comment highlighted.
      if (c.parentPostId) {
        router.push(
          `/?view=comments&postId=${encodeURIComponent(c.parentPostId)}&commentId=${encodeURIComponent(c.contentId)}`
        );
      } else if (c.parentArticleId) {
        router.push(`/articles/${encodeURIComponent(c.parentArticleId)}`);
      }
    }
  }

  if (!item.content) {
    return (
      <div className="flex items-center justify-between gap-2 rounded-lg border p-3 text-sm text-muted-foreground">
        <span>
          {t("collections.itemUnavailable") || "This content is no longer available."}
        </span>
        {isOwner && (
          <Button
            size="sm"
            variant="ghost"
            onClick={handleRemove}
            disabled={removing}
            aria-label={t("common.remove") || "Remove"}
          >
            {removing ? <Loader2 className="h-4 w-4 animate-spin" /> : <X className="h-4 w-4" />}
          </Button>
        )}
      </div>
    );
  }

  const c = item.content;
  return (
    <div
      className="group flex items-start gap-3 rounded-lg border p-3 transition-colors hover:bg-accent/30 cursor-pointer"
      onClick={openContent}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          openContent();
        }
      }}
    >
      <Avatar
        name={c.authorFullName ?? "?"}
        color={c.authorAvatarColor}
        src={c.authorAvatarUrl}
        size="sm"
        className="mt-0.5 shrink-0"
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 text-xs">
          <span className="truncate font-medium">{c.authorFullName}</span>
          {c.authorIsVerified && <VerifiedBadge size={10} />}
          <span className="truncate text-muted-foreground">
            @{c.authorUsername}
          </span>
          <span className="text-muted-foreground">·</span>
          <span className="text-[10px] uppercase text-muted-foreground">
            {c.contentType}
          </span>
        </div>
        <p className="mt-1 line-clamp-2 text-sm">
          {c.title ?? c.excerpt ?? ""}
        </p>
        <p className="mt-1 text-[10px] text-muted-foreground">
          {fmtRelative(c.createdAt ?? item.addedAt)}
        </p>
      </div>
      {isOwner && (
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 opacity-0 transition-opacity group-hover:opacity-100"
            disabled={reordering}
            onClick={(e) => {
              e.stopPropagation();
              void handleReorder("up");
            }}
            aria-label={t("collections.moveUp") || "Move up"}
          >
            ↑
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 opacity-0 transition-opacity group-hover:opacity-100"
            disabled={reordering}
            onClick={(e) => {
              e.stopPropagation();
              void handleReorder("down");
            }}
            aria-label={t("collections.moveDown") || "Move down"}
          >
            ↓
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 opacity-0 transition-opacity group-hover:opacity-100"
            disabled={removing}
            onClick={(e) => {
              e.stopPropagation();
              void handleRemove();
            }}
            aria-label={t("common.remove") || "Remove"}
          >
            {removing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <X className="h-4 w-4 text-destructive" />
            )}
          </Button>
        </div>
      )}
    </div>
  );
}
