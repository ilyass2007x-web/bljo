"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  ArrowLeft,
  Plus,
  Loader2,
  Folder,
  Globe,
  Lock,
  Trash2,
  Pencil,
  FolderOpen,
} from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/**
 * CollectionsPage — the user's own collections list + create flow.
 *
 * Phase 5 — Collections. The whole page is gated by the `collections`
 * feature flag (checked server-side on every API call; the page itself
 * also gates the UI so users see a "feature disabled" state instead of
 * API errors when the admin hasn't enabled collections).
 *
 * Layout (spec §26):
 *   - MainNav (desktop top bar + mobile bottom bar)
 *   - Mobile sticky header ("My Collections" + back button)
 *   - Desktop header with title + "New collection" button
 *   - Empty state: "Create your first collection" CTA
 *   - Grid of collection cards: name, description, visibility badge,
 *     item count, updated time. Click → /?view=collection&id=<id>.
 *   - Create dialog: name + description + isPublic switch.
 *
 * SECURITY:
 *   - ownerId is NEVER sent from the client — the API derives it from
 *     the session. The create form only sends { name, description, isPublic }.
 *   - The page only shows the user's OWN collections (the API filters by
 *     ownerId from the session). Other users' public collections are
 *     discoverable via Search (with `type: "collection"` results).
 */

interface CollectionDTO {
  id: string;
  ownerId: string;
  name: string;
  description: string | null;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
  owner: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  itemCount: number;
}

export function CollectionsPage() {
  const router = useRouter();
  const { user } = useAuthStore();
  const { t, fmtRelative } = useTranslation();

  const [collections, setCollections] = useState<CollectionDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [featureDisabled, setFeatureDisabled] = useState(false);

  // Create dialog state.
  const [createOpen, setCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState({
    name: "",
    description: "",
    isPublic: false,
  });
  const [creating, setCreating] = useState(false);

  const fetchCollections = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.get<{ collections: CollectionDTO[] }>(
        "/api/v1/collections"
      );
      setCollections(data.collections);
      // If the API returns an empty array, that COULD mean (a) the user has
      // no collections OR (b) the feature is disabled. We can't tell from
      // the response alone — assume the feature is enabled (the empty state
      // is the more common case; the create dialog will surface a
      // "Collections feature is disabled" error if it's actually disabled).
      setFeatureDisabled(false);
    } catch (e) {
      if (e instanceof ApiClientError) {
        setError(e.message);
      } else {
        setError("Failed to load collections");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchCollections();
  }, [fetchCollections]);

  async function handleCreate() {
    const name = createForm.name.trim();
    if (!name) {
      toast.error(t("collections.nameRequired") || "Name is required");
      return;
    }
    setCreating(true);
    try {
      const data = await api.post<{ collection: CollectionDTO }>(
        "/api/v1/collections",
        {
          name,
          description: createForm.description.trim() || null,
          isPublic: createForm.isPublic,
        }
      );
      setCollections((prev) => [data.collection, ...prev]);
      setCreateOpen(false);
      setCreateForm({ name: "", description: "", isPublic: false });
      toast.success(t("collections.created") || "Collection created");
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to create collection";
      toast.error(msg);
      // If the error indicates the feature is disabled, surface the state.
      if (msg.toLowerCase().includes("disabled")) {
        setFeatureDisabled(true);
      }
    } finally {
      setCreating(false);
    }
  }

  async function handleDelete(id: string) {
    try {
      await api.delete(`/api/v1/collections/${id}`);
      setCollections((prev) => prev.filter((c) => c.id !== id));
      toast.success(t("collections.deleted") || "Collection deleted");
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to delete collection";
      toast.error(msg);
    }
  }

  function openCollection(id: string) {
    router.push(`/?view=collection&id=${encodeURIComponent(id)}`);
  }

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile sticky header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()} title="Back">
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium">
            {t("collections.title") || "Collections"}
          </p>
          <p className="truncate text-xs text-muted-foreground">
            {collections.length} {t("collections.collections") || "collections"}
          </p>
        </div>
        <Button
          size="sm"
          onClick={() => setCreateOpen(true)}
          disabled={featureDisabled}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </header>

      <div className="mx-auto max-w-4xl">
        {/* Desktop header */}
        <div className="hidden items-center justify-between gap-3 border-b px-4 py-3 md:flex md:px-6">
          <div className="flex items-center gap-3">
            <Folder className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-semibold">
              {t("collections.title") || "Collections"}
            </h1>
            <span className="text-sm text-muted-foreground">
              · {collections.length}
            </span>
          </div>
          <Button
            size="sm"
            onClick={() => setCreateOpen(true)}
            disabled={featureDisabled}
          >
            <Plus className="mr-1 h-4 w-4" />
            {t("collections.new") || "New collection"}
          </Button>
        </div>

        <div className="p-4 md:p-6">
          {featureDisabled && (
            <div className="rounded-lg border border-dashed p-8 text-center text-sm text-muted-foreground">
              {t("collections.disabled") ||
                "Collections feature is currently disabled. Contact an admin to enable it."}
            </div>
          )}

          {!featureDisabled && loading && (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-32 w-full rounded-lg" />
              ))}
            </div>
          )}

          {!featureDisabled && !loading && error && (
            <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
              {error}
              <Button
                variant="ghost"
                size="sm"
                className="ml-2"
                onClick={() => fetchCollections()}
              >
                {t("common.retry") || "Retry"}
              </Button>
            </div>
          )}

          {!featureDisabled && !loading && !error && collections.length === 0 && (
            <div className="flex flex-col items-center justify-center gap-4 rounded-lg border border-dashed p-12 text-center">
              <FolderOpen className="h-10 w-10 text-muted-foreground" />
              <div>
                <p className="font-medium">
                  {t("collections.empty") || "No collections yet"}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {t("collections.emptyDesc") ||
                    "Create your first collection to start saving content."}
                </p>
              </div>
              <Button onClick={() => setCreateOpen(true)}>
                <Plus className="mr-1 h-4 w-4" />
                {t("collections.createFirst") || "Create your first collection"}
              </Button>
            </div>
          )}

          {!featureDisabled && !loading && !error && collections.length > 0 && (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {collections.map((c) => (
                <div
                  key={c.id}
                  className={cn(
                    "group relative flex flex-col gap-2 rounded-lg border p-4 transition-colors hover:bg-accent/30 cursor-pointer"
                  )}
                  onClick={() => openCollection(c.id)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      openCollection(c.id);
                    }
                  }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Folder className="h-4 w-4 text-primary" />
                      <span className="line-clamp-1 font-medium">{c.name}</span>
                    </div>
                    {c.isPublic ? (
                      <Globe className="h-3.5 w-3.5 text-muted-foreground" aria-label="Public" />
                    ) : (
                      <Lock className="h-3.5 w-3.5 text-muted-foreground" aria-label="Private" />
                    )}
                  </div>
                  {c.description && (
                    <p className="line-clamp-2 text-xs text-muted-foreground">
                      {c.description}
                    </p>
                  )}
                  <div className="mt-auto flex items-center justify-between pt-2 text-[10px] text-muted-foreground">
                    <span>
                      {c.itemCount} {t("collections.items") || "items"}
                    </span>
                    <span>{fmtRelative(c.updatedAt)}</span>
                  </div>
                  {/* Owner row — only shown for collections the user owns (always true here). */}
                  <div className="flex items-center gap-1.5 border-t pt-2 text-xs">
                    <Avatar
                      name={c.owner.fullName}
                      color={c.owner.avatarColor}
                      src={c.owner.avatarUrl}
                      size="sm"
                      className="h-5 w-5 text-[10px]"
                    />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        router.push(
                          `/?view=profile&username=${encodeURIComponent(c.owner.username)}`
                        );
                      }}
                      className="flex items-center gap-1 truncate hover:underline"
                    >
                      <span className="truncate">{c.owner.fullName}</span>
                      {c.owner.isVerified && <VerifiedBadge size={10} />}
                    </button>
                  </div>
                  {/* Delete button (only on hover, for owner) */}
                  {c.ownerId === user?.id && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="absolute right-1 top-1 h-7 w-7 p-0 opacity-0 transition-opacity group-hover:opacity-100"
                          onClick={(e) => e.stopPropagation()}
                          aria-label={t("collections.delete") || "Delete"}
                        >
                          <Trash2 className="h-3.5 w-3.5 text-destructive" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent onClick={(e) => e.stopPropagation()}>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            {t("collections.deleteConfirmTitle") || "Delete this collection?"}
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            {t("collections.deleteConfirmDesc") ||
                              "This collection and all its items will be permanently removed. The underlying content (posts/articles/videos) will not be affected."}
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>
                            {t("common.cancel") || "Cancel"}
                          </AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDelete(c.id)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            {t("common.delete") || "Delete"}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Create dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {t("collections.createTitle") || "Create a collection"}
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-3 py-2">
            <div>
              <label htmlFor="coll-name" className="text-xs font-medium text-muted-foreground">
                {t("collections.name") || "Name"}
              </label>
              <Input
                id="coll-name"
                value={createForm.name}
                onChange={(e) => setCreateForm((f) => ({ ...f, name: e.target.value }))}
                placeholder={t("collections.namePlaceholder") || "My favorite posts"}
                maxLength={100}
                autoFocus
              />
            </div>
            <div>
              <label htmlFor="coll-desc" className="text-xs font-medium text-muted-foreground">
                {t("collections.description") || "Description (optional)"}
              </label>
              <Textarea
                id="coll-desc"
                value={createForm.description}
                onChange={(e) => setCreateForm((f) => ({ ...f, description: e.target.value }))}
                placeholder={t("collections.descriptionPlaceholder") || "What's this collection about?"}
                maxLength={500}
                rows={3}
              />
            </div>
            <div className="flex items-center justify-between rounded-md border p-3">
              <div className="flex items-center gap-2">
                {createForm.isPublic ? (
                  <Globe className="h-4 w-4 text-primary" />
                ) : (
                  <Lock className="h-4 w-4 text-muted-foreground" />
                )}
                <div>
                  <p className="text-sm font-medium">
                    {t("collections.visibility") || "Public collection"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {t("collections.visibilityDesc") ||
                      "Public collections can be viewed by other users + appear in search."}
                  </p>
                </div>
              </div>
              <Switch
                checked={createForm.isPublic}
                onCheckedChange={(v) => setCreateForm((f) => ({ ...f, isPublic: v }))}
                aria-label={t("collections.visibility") || "Public"}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setCreateOpen(false)}
              disabled={creating}
            >
              {t("common.cancel") || "Cancel"}
            </Button>
            <Button onClick={handleCreate} disabled={creating || !createForm.name.trim()}>
              {creating && <Loader2 className="mr-1 h-4 w-4 animate-spin" />}
              {t("collections.create") || "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
