"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, Loader2, Bell, Palette, LogOut, Sun, Moon, Monitor } from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "next-themes";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation, useLanguage } from "@/lib/client/i18n-store";
import { CompactLanguageSelector } from "@/components/shared/compact-language-selector";
import { MainNav } from "@/components/shared/main-nav";
import { cn } from "@/lib/utils";

/**
 * SettingsScreen — application-wide settings ONLY.
 *
 * Per spec §10, profile information editing is intentionally NOT here.
 * Profile fields (full name, username, bio, avatar) live in
 * Edit Profile (`/?view=edit-profile`).
 *
 * Sections:
 *  1. Language — right-aligned compact selector (popover picker)
 *  2. Appearance — Light / Dark / System theme picker
 *  3. Notifications — per-category switches
 *  4. Account — read-only account info
 *  5. Sign out — ends the session
 */
export function SettingsScreen() {
  const router = useRouter();
  const { user, fetchUser, clear } = useAuthStore();
  const { t, fmtDateTime } = useTranslation();
  const { language, setLanguage } = useLanguage();
  const { theme, setTheme } = useTheme();

  const [selectedLang, setSelectedLang] = useState(user?.language ?? language);
  const [savingLang, setSavingLang] = useState(false);
  const [savingNotifs, setSavingNotifs] = useState(false);
  const [notifPrefs, setNotifPrefs] = useState<Record<string, boolean>>({
    message: true,
    security: true,
    system: true,
    account: true,
    moderation: true,
  });

  // Load notification preferences.
  useEffect(() => {
    void api
      .get<{ user: { notificationPrefs: Record<string, boolean> | null } }>("/api/v1/profile")
      .then((d) => {
        if (d.user?.notificationPrefs) {
          setNotifPrefs(d.user.notificationPrefs);
        }
      })
      .catch(() => {});
  }, []);

  if (!user) return null;

  async function saveLanguage(lang: string) {
    setSelectedLang(lang);
    setSavingLang(true);
    try {
      // Update the UI immediately (no page refresh).
      setLanguage(lang);
      // Persist to the database.
      await api.patch("/api/v1/profile", { language: lang });
      await fetchUser();
      toast.success(t("settings.languageUpdated"));
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to update language");
    } finally {
      setSavingLang(false);
    }
  }

  async function saveTheme(next: "light" | "dark" | "system") {
    setTheme(next);
    toast.success(t("settings.themeUpdated"));
  }

  async function logout() {
    try {
      await api.post("/api/v1/auth/logout");
    } catch {
      /* ignore */
    }
    clear();
    router.push("/");
  }

  const themeOptions: { value: "light" | "dark" | "system"; label: string; icon: typeof Sun }[] = [
    { value: "light", label: t("settings.themeLight"), icon: Sun },
    { value: "dark", label: t("settings.themeDark"), icon: Moon },
    { value: "system", label: t("settings.themeSystem"), icon: Monitor },
  ];

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile-only slim header — desktop uses MainNav's top bar */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()} title={t("nav.backToApp")}>
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <h1 className="text-lg font-semibold">{t("settings.title")}</h1>
      </header>

      <div className="mx-auto max-w-2xl space-y-6 p-4 md:p-6">
        {/* Language */}
        <Card>
          <CardHeader>
            <CardTitle>{t("settings.language")}</CardTitle>
            <CardDescription>{t("settings.languageDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="p-2">
            <CompactLanguageSelector
              value={selectedLang}
              onChange={saveLanguage}
              label={t("settings.language")}
              description={savingLang ? t("common.loading") : undefined}
            />
          </CardContent>
        </Card>

        {/* Appearance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="h-4 w-4" />
              {t("settings.appearance")}
            </CardTitle>
            <CardDescription>{t("settings.appearanceDesc")}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-2">
              {themeOptions.map((opt) => {
                const Icon = opt.icon;
                const active = (theme ?? "system") === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => void saveTheme(opt.value)}
                    className={cn(
                      "flex flex-col items-center gap-1.5 rounded-lg border p-3 text-xs font-medium transition-colors hover:bg-accent",
                      active ? "border-primary bg-accent text-accent-foreground" : "border-border"
                    )}
                    aria-pressed={active}
                  >
                    <Icon className="h-5 w-5" />
                    <span>{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-4 w-4" />
              {t("notifications.settings.title")}
            </CardTitle>
            <CardDescription>{t("notifications.settings.description")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {([
              { key: "message", label: t("notifications.settings.message"), desc: t("notifications.settings.messageDesc") },
              { key: "system", label: t("notifications.settings.system"), desc: t("notifications.settings.systemDesc") },
              { key: "account", label: t("notifications.settings.account"), desc: t("notifications.settings.accountDesc") },
              // "moderation" is intentionally EXCLUDED from the normal user
              // Settings UI per spec Task 1. Moderation notifications are
              // ADMIN-only (sent to admins/super-admins when reports are
              // filed, users are suspended, etc.). Normal users never receive
              // MODERATION-type notifications, so the toggle is meaningless
              // to them. The backend notification system (NotificationType =
              // "MODERATION" in src/lib/notifications.ts) is NOT removed —
              // it continues to work for admin notifications. The
              // notificationPrefs field in the DB is also NOT removed — it
              // just no longer has a "moderation" key set by normal users.
              // If an admin wants to control moderation notifications, they
              // can do so via the admin Settings panel (which uses a
              // different code path).
              { key: "security", label: t("notifications.settings.security"), desc: t("notifications.settings.securityDesc") },
            ] as const).map((item) => (
              <div key={item.key} className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
                <Switch
                  checked={notifPrefs[item.key] ?? true}
                  disabled={item.key === "security" || savingNotifs}
                  onCheckedChange={async (v) => {
                    const next = { ...notifPrefs, [item.key]: v };
                    setNotifPrefs(next);
                    setSavingNotifs(true);
                    try {
                      await api.patch("/api/v1/profile", { notificationPrefs: next });
                      toast.success(t("settings.profileUpdated"));
                    } catch {
                      toast.error("Failed to update notification settings");
                    } finally {
                      setSavingNotifs(false);
                    }
                  }}
                />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Account */}
        <Card>
          <CardHeader>
            <CardTitle>{t("settings.account")}</CardTitle>
            <CardDescription>{t("settings.accountDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex justify-between gap-2">
              <span className="text-muted-foreground">{t("auth.email")}</span>
              <span className="truncate" dir="auto">{user.email}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-muted-foreground">{t("profile.username")}</span>
              <span className="truncate">@{user.username}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-muted-foreground">{t("settings.memberSince")}</span>
              <span>{fmtDateTime(user.createdAt)}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-muted-foreground">{t("settings.lastSeen")}</span>
              <span>{fmtDateTime(user.lastSeenAt)}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-muted-foreground">{t("settings.twoFactor")}</span>
              <span>{user.twoFactorEnabled ? t("settings.twoFactorEnabled") : t("settings.twoFactorNotEnabled")}</span>
            </div>
            <div className="flex flex-wrap gap-1 pt-2">
              <Badge variant="secondary">{user.role}</Badge>
              <Badge variant={user.status === "ACTIVE" ? "default" : "destructive"}>{user.status}</Badge>
              {user.emailVerified && <Badge variant="outline">✓</Badge>}
            </div>
          </CardContent>
        </Card>

        {/* Sign out */}
        <Card>
          <CardContent className="p-0">
            <button
              type="button"
              onClick={logout}
              className="flex w-full items-center gap-3 px-4 py-3 text-sm font-medium text-destructive transition-colors hover:bg-destructive/10"
            >
              <LogOut className="h-4 w-4 rtl-flip" />
              <span>{t("settings.logout")}</span>
            </button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
