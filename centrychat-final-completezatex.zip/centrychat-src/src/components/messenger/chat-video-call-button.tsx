"use client";

import { Video } from "lucide-react";
import { cn } from "@/lib/utils";
import { isVideoChatClientEnabled } from "@/lib/video-chat/enabled";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

/**
 * ChatVideoCallButton — the icon shown in the chat header that opens
 * the Video Call preview dialog.
 *
 * ── ALWAYS visible on all devices (spec §1) ──
 *
 * No `hidden` / `display:none` breakpoints. The button is shown on:
 *   - Desktop (PC)
 *   - Laptop
 *   - Tablet
 *   - Mobile (smartphone)
 *
 * The button is rendered as an actual <button> with proper accessibility
 * attributes (aria-label, focus states, keyboard support) per spec §15.
 *
 * ── Tooltip on Desktop (spec §1) ──
 *
 * The Tooltip wraps the button. On touch devices, the tooltip doesn't
 * interfere (it only shows on hover/focus — Radix handles the
 * touch-vs-mouse distinction).
 *
 * ── Disabled state ──
 *
 * When `disabled` is true (e.g. video calling not supported by this
 * browser, or feature flag off), the button shows but is grayed out
 * with an explanatory tooltip.
 */
interface ChatVideoCallButtonProps {
  onClick: () => void;
  /** Whether the button is interactive. */
  disabled?: boolean;
  /** Tooltip + aria-label text shown when disabled. */
  disabledReason?: string;
  /** Optional active state (call in progress) — shows the icon in primary color. */
  active?: boolean;
  className?: string;
}

export function ChatVideoCallButton({
  onClick,
  disabled = false,
  disabledReason,
  active = false,
  className,
}: ChatVideoCallButtonProps) {
  // DISABLED (TEMPORARY): when NEXT_PUBLIC_VIDEO_CHAT_ENABLED is not "true",
  // the button is NOT rendered. The icon, tooltip, and accessibility
  // attributes all disappear from the chat header — same visual result as
  // if the component were never mounted. The component itself is preserved
  // (this is a `return null`, not a deletion) so re-enabling the env var
  // immediately restores the button without code changes.
  if (!isVideoChatClientEnabled()) {
    return null;
  }

  const tooltipText = disabled
    ? (disabledReason ?? "Video calling unavailable")
    : "Start video call";

  return (
    <TooltipProvider delayDuration={300}>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            onClick={onClick}
            disabled={disabled}
            aria-label={tooltipText}
            title={tooltipText}
            className={cn(
              "inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background",
              disabled
                ? "cursor-not-allowed text-muted-foreground/40"
                : active
                  ? "bg-primary text-primary-foreground hover:bg-primary/90"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
              className,
            )}
          >
            <Video className="h-[18px] w-[18px]" aria-hidden="true" />
            <span className="sr-only">{tooltipText}</span>
          </button>
        </TooltipTrigger>
        {!disabled && (
          <TooltipContent side="bottom" align="center">
            {tooltipText}
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  );
}
