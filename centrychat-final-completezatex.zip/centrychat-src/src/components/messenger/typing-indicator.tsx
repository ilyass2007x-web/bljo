"use client";

import { useTranslation } from "@/lib/client/i18n-store";
import { cn } from "@/lib/utils";

interface TypingIndicatorProps {
  /** Users currently typing in the conversation. */
  typingUsers: { userId: string; fullName: string }[];
}

/**
 * Displays "Ahmed is typing… ✍️" (or localized equivalent) above the message
 * input. Supports 1, 2, or many typers (future group support).
 *
 * The animation is subtle — three pulsing dots — and does not interfere with
 * mobile keyboards, scroll position, or the send button.
 */
export function TypingIndicator({ typingUsers }: TypingIndicatorProps) {
  const { t } = useTranslation();

  if (typingUsers.length === 0) return null;

  let text: string;
  if (typingUsers.length === 1) {
    text = t("typing.isTyping", { name: typingUsers[0]!.fullName || "…" });
  } else if (typingUsers.length === 2) {
    text = t("typing.twoTyping", {
      name1: typingUsers[0]!.fullName,
      name2: typingUsers[1]!.fullName,
    });
  } else {
    text = t("typing.manyTyping", { count: typingUsers.length });
  }

  return (
    <div
      className="flex items-center gap-2 px-4 py-1.5 text-xs text-muted-foreground"
      role="status"
      aria-live="polite"
      dir="auto"
    >
      <span className="flex items-center gap-0.5">
        <span className="h-1.5 w-1.5 animate-typing-bounce rounded-full bg-current [animation-delay:0ms]" />
        <span className="h-1.5 w-1.5 animate-typing-bounce rounded-full bg-current [animation-delay:150ms]" />
        <span className="h-1.5 w-1.5 animate-typing-bounce rounded-full bg-current [animation-delay:300ms]" />
      </span>
      <span className="animate-fade-in">{text}</span>
    </div>
  );
}
