"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar } from "@/components/shared/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Send,
  Search,
  LogOut,
  Settings,
  Check,
  CheckCheck,
  Edit2,
  Trash2,
  PanelLeft,
  Shield,
  Moon,
  Sun,
  Home,
  MessageSquare,
  Clock,
  X,
  ArrowDown,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { useTheme } from "next-themes";
import { api, ApiClientError, type ConversationListItem, type MessageDTO, type UserSearchResult } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useRealtime } from "@/hooks/use-realtime";
import { useTypingIndicator } from "@/hooks/use-typing-indicator";
import { TypingIndicator } from "@/components/messenger/typing-indicator";
import { MessageText } from "@/components/messenger/message-text";
import { NotificationCenter } from "@/components/shared/notification-center";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { FollowButton } from "@/components/shared/follow-button";
import { PostComposer } from "@/components/posts/post-composer";
import { useTranslation, useLanguage } from "@/lib/client/i18n-store";
import { usePlatformName } from "@/lib/client/platform";
import { isVideoChatClientEnabled } from "@/lib/video-chat/enabled";
import { cn } from "@/lib/utils";
// Chat Video Call — code-split so the WebRTC code only loads when the user
// actually opens a video call dialog. This keeps the messenger bundle small
// for users who never use video calling. Spec §17 (performance).
import dynamic from "next/dynamic";
const ChatVideoCallDialog = dynamic(
  () => import("@/components/messenger/chat-video-call-dialog").then((m) => m.ChatVideoCallDialog),
  { ssr: false, loading: () => null }
);
import { ChatVideoCallButton } from "@/components/messenger/chat-video-call-button";
import type { CallPeer } from "@/lib/chat-video-call/types";

export function Messenger() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, clear } = useAuthStore();
  const { theme, setTheme } = useTheme();
  const { t, fmtRelative } = useTranslation();
  // Dynamic platform name — fetched from /api/v1/settings/public on mount,
  // falls back to the i18n locale value while loading. Updates automatically
  // when the admin changes Platform Name in Settings.
  const platformName = usePlatformName(t("app.name"));
  const [conversations, setConversations] = useState<ConversationListItem[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [messages, setMessages] = useState<MessageDTO[]>([]);
  const [draft, setDraft] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<UserSearchResult[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [unreadMessages, setUnreadMessages] = useState(0);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [messagesError, setMessagesError] = useState<string | null>(null);
  const [searchHistory, setSearchHistory] = useState<{ id: string; query: string; targetUsername?: string | null; targetFullName?: string | null }[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const threadRef = useRef<HTMLDivElement>(null);
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Smart scroll: track whether the user is near the bottom of the messages
  // container. If they are, new messages auto-scroll. If they're reading old
  // messages (scrolled up), we show a "New messages" indicator instead.
  const isNearBottomRef = useRef(true);
  const [showNewMessagesIndicator, setShowNewMessagesIndicator] = useState(false);

  // ── Chat Video Call state ──────────────────────────────────────────
  // `videoCallOpen` controls the visibility of the ChatVideoCallDialog.
  // `incomingVideoCall` is set when the recipient receives an incoming
  // call via realtime — passed to the dialog so it opens in "incoming" mode.
  // When the user clicks the video call icon in the chat header, we set
  // `videoCallOpen` to true WITHOUT setting `incomingVideoCall`, which the
  // dialog detects as a "manual open" (preview flow rather than incoming).
  const [videoCallOpen, setVideoCallOpen] = useState(false);
  const [incomingVideoCall, setIncomingVideoCall] = useState<
    { callId: string; caller: CallPeer } | null
  >(null);

  // ── Cross-conversation race-condition guards (Bug 2 fix) ───────────
  // When the user switches conversations quickly, async fetches (loadMessages,
  // pollNewMessages, sendMessage's in-flight POST) and realtime events can
  // arrive AFTER the active conversation has already changed. Without guards,
  // a stale response would overwrite the new conversation's messages with
  // the old conversation's messages — that's the "Conversation A messages
  // appear inside Conversation B" bug.
  //
  //   selectedIdRef   — always holds the LATEST active conversation id. Used
  //                     by async callbacks to verify the response still
  //                     belongs to the active conversation before mutating
  //                     `messages`.
  //   requestSeqRef   — monotonic counter incremented on every loadMessages
  //                     call. The response carries the seq it was issued with;
  //                     if a newer request has been issued in the meantime,
  //                     the older response is discarded (no overwrite).
  const selectedIdRef = useRef<string | null>(null);
  const requestSeqRef = useRef(0);
  useEffect(() => {
    selectedIdRef.current = selectedId;
  }, [selectedId]);

  const loadConversations = useCallback(async () => {
    try {
      const data = await api.get<{ conversations: ConversationListItem[] }>("/api/v1/conversations");
      setConversations(data.conversations);
      // Calculate total unread messages for the nav badge.
      const total = data.conversations.reduce((sum, c) => sum + c.unreadCount, 0);
      setUnreadMessages(total);
    } catch {
      /* ignore */
    }
  }, []);

  const loadMessages = useCallback(async (id: string) => {
    // Allocate a unique sequence number for this load request. Any newer
    // loadMessages call will increment requestSeqRef past this value, and
    // we'll detect that the response is stale and discard it. This prevents
    // "Conversation A messages appear inside Conversation B" when the user
    // switches conversations quickly (Bug 2 root cause).
    const mySeq = ++requestSeqRef.current;
    setLoadingMessages(true);
    setMessagesError(null);
    try {
      const data = await api.get<{ messages: MessageDTO[] }>(`/api/v1/conversations/${id}/messages?limit=50`);
      // Discard the response if a newer loadMessages has started, or if
      // the active conversation has changed since this request was issued.
      if (mySeq !== requestSeqRef.current) return;
      if (selectedIdRef.current !== id) return;
      setMessages(data.messages);
      setMessagesError(null);
      // Refresh conversations to update unread counts.
      void loadConversations();
    } catch (err) {
      // Only show the error if this is still the active request and the
      // active conversation hasn't changed.
      if (mySeq === requestSeqRef.current && selectedIdRef.current === id) {
        const msg = err instanceof ApiClientError ? err.message : "Failed to load messages";
        setMessagesError(msg);
      }
    } finally {
      // Only clear the loading spinner if this is still the active request.
      if (mySeq === requestSeqRef.current) {
        setLoadingMessages(false);
      }
    }
  }, [loadConversations]);

  /**
   * Lightweight poll for new messages — merges new messages into the existing
   * list WITHOUT reloading everything. This is the fallback when realtime is
   * unavailable (e.g. serverless). Deduplicates by message ID.
   *
   * Also syncs readAt changes — if the recipient read our messages, the
   * server returns the updated readAt, and we update the local state so the
   * checkmarks turn blue.
   *
   * Race-condition guard: the poll is started for a specific conversation id.
   * If the user switches conversations while the poll is in flight, the
   * response is discarded — never applied to the new active conversation.
   * Without this guard, switching from Conversation A → B could let a late
   * A-poll response inject A's messages into B (Bug 2 root cause).
   */
  const pollNewMessages = useCallback(async (id: string) => {
    try {
      const data = await api.get<{ messages: MessageDTO[] }>(`/api/v1/conversations/${id}/messages?limit=50`);
      // Discard if the active conversation changed while the poll was in flight.
      if (selectedIdRef.current !== id) return;
      setMessages((prev) => {
        const existingMap = new Map(prev.map((m) => [m.id, m]));
        const newOnes: MessageDTO[] = [];
        for (const msg of data.messages) {
          const existing = existingMap.get(msg.id);
          if (!existing) {
            // New message — add it.
            newOnes.push(msg);
          } else if (existing.readAt !== msg.readAt) {
            // readAt changed (recipient read the message) — update it.
            existingMap.set(msg.id, { ...existing, readAt: msg.readAt });
          }
        }
        if (newOnes.length === 0) {
          // Check if any readAt changed — if not, return prev to avoid re-render.
          const changed = [...existingMap.values()].some((m, i) => m !== prev[i]);
          return changed ? [...existingMap.values()] : prev;
        }
        // Merge new messages into the existing list. Both `prev` and
      // `data.messages` are oldest-first (the server returns them in
      // that order — see listMessages in src/lib/messaging.ts which
      // does `.reverse()` on the DB result).
      //
      // New messages (not in `prev`) must be APPENDED to the end —
      // NOT prepended. Prepending would place the newest message at
      // the TOP of the thread (off-screen when the user is scrolled
      // to the bottom), making it look like the message didn't arrive.
      // This was the root cause of "must refresh to see new messages":
      // the poll DID fetch the new message, but placed it at index 0
      // (top) instead of at the end (bottom). After a refresh,
      // loadMessages set the correct oldest-first order, which is
      // why refresh "fixed" it.
      return [...existingMap.values(), ...newOnes];
      });
      // Update conversation list (unread count, last message).
      void loadConversations();
    } catch {
      /* silent — polling failure is non-fatal */
    }
  }, [loadConversations]);

  useEffect(() => {
    void loadConversations();
    // Poll for conversations as a realtime fallback (every 10s — reduced
    // from 5s to cut network traffic + CPU on mobile. Pauses when the
    // tab is not visible — spec §3 + §26).
    const interval = setInterval(() => {
      if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
      void loadConversations();
    }, 10000);
    return () => clearInterval(interval);
  }, [loadConversations]);

  // Auto-select conversation from URL param (e.g. ?conversation=xxx from profile → Message button).
  useEffect(() => {
    const convId = searchParams.get("conversation");
    if (convId && convId !== selectedId) {
      setSelectedId(convId);
    }
  }, [searchParams, selectedId]);

  // ── Conversation-switch reset (Bug 2 fix) ──────────────────────────
  // When the active conversation changes, IMMEDIATELY clear the messages
  // state so the user sees a loading state — never the previous
  // conversation's messages bleeding into the new one. Also clear the
  // error state and the "new messages" indicator (it doesn't apply to a
  // different conversation). The next loadMessages effect will fetch the
  // correct messages for the new conversation.
  //
  // This runs SYNCHRONOUSLY during the render after selectedId changes,
  // BEFORE the user can see any stale content. Without it, the React commit
  // phase would briefly render the previous conversation's messages under
  // the new conversation's header (a flash of wrong content), and a slow
  // loadMessages response could leave them there indefinitely.
  useEffect(() => {
    setMessages([]);
    setMessagesError(null);
    setShowNewMessagesIndicator(false);
    isNearBottomRef.current = true;
  }, [selectedId]);

  useEffect(() => {
    if (selectedId) void loadMessages(selectedId);
  }, [selectedId, loadMessages]);

  // Poll for new messages in the active conversation every 5s (reduced
  // from 3s — the realtime `message:new` handler provides instant message
  // delivery; this poll is ONLY a fallback for when realtime is broken
  // on Netlify serverless). Pauses when the tab is not visible — spec §3.
  useEffect(() => {
    if (!selectedId) return;
    const interval = setInterval(() => {
      if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
      void pollNewMessages(selectedId);
    }, 5000);
    return () => clearInterval(interval);
  }, [selectedId, pollNewMessages]);

  // Typing handler ref — allows useRealtime to delegate to the typing hook
  // without creating a circular dependency.
  const typingHandlerRef = useRef<(payload: unknown) => void>(() => {});

  // Realtime handlers.
  // IMPORTANT: these handlers are recreated on every render, but the realtime
  // hook stores them in a ref that updates AFTER the render commits. To avoid
  // any window where a handler closure has a STALE selectedId (which would
  // route a new message into the wrong conversation — Bug 2 root cause), we
  // read from selectedIdRef.current (kept fresh by an effect above) instead
  // of the closure-captured selectedId.
  const { connected: realtimeConnected, emitTyping, setActiveConversation } = useRealtime(!!user, {
    "message:new": (payload) => {
      const msg = payload as MessageDTO & { recipientIds?: string[] };
      // SAFETY LAYER: only render messages that belong to the CURRENTLY
      // active conversation. Using the ref (not the closure) guarantees we
      // always see the latest selectedId even if the handler closure is
      // briefly stale (e.g., during the React render window between a
      // selectedId state update and the ref-sync effect in useRealtime).
      const activeId = selectedIdRef.current;
      if (msg.conversationId === activeId) {
        // Add the message instantly (dedup by ID — the polling fallback may
        // also fetch it, and the sender's optimistic add may already have
        // placed it). Do NOT call loadMessages() here — that would reload
        // everything, cause UI flicker, and potentially duplicate messages.
        setMessages((prev) => {
          if (prev.some((m) => m.id === msg.id)) return prev;
          return [...prev, msg];
        });

        // If the user is currently viewing this conversation, mark the new
        // message as read immediately (batch API call). This also broadcasts
        // a `message:read` event back to the sender so they see ✓✓ blue.
        void api.post(`/api/v1/conversations/${activeId}/messages/read`).catch(() => {
          // Non-fatal — the 3-second polling fallback will also mark it as read.
        });
      }
      // Always refresh the conversation list (updates last message + unread count).
      void loadConversations();
    },
    "message:read": (payload) => {
      // The recipient just opened the conversation and read our messages.
      // Update the local messages' readAt field so the checkmarks turn blue.
      // SAFETY: only apply if the event is for the active conversation.
      const p = payload as { conversationId?: string; readAt?: string; messageIds?: string[] };
      if (!p?.conversationId || !p?.readAt || !p?.messageIds) return;
      if (p.conversationId !== selectedIdRef.current) return;
      setMessages((prev) =>
        prev.map((m) =>
          p.messageIds!.includes(m.id) && m.readAt === null
            ? { ...m, readAt: p.readAt! }
            : m
        )
      );
    },
    "message:update": (payload) => {
      // SAFETY: only apply if the updated message belongs to the active
      // conversation. Without this check, an edit in Conversation A could
      // replace a message in Conversation B if both happen to share a
      // message ID (extremely unlikely but defensive).
      const msg = payload as MessageDTO;
      if (msg.conversationId !== selectedIdRef.current) return;
      setMessages((prev) => prev.map((m) => (m.id === msg.id ? msg : m)));
    },
    "message:delete": (payload) => {
      // SAFETY: only apply if the deleted message belongs to the active
      // conversation. We don't have conversationId in the delete payload,
      // so we check whether the message exists in our local list (which
      // is already filtered to the active conversation).
      const p = payload as { messageId: string; conversationId?: string };
      if (p.conversationId && p.conversationId !== selectedIdRef.current) return;
      setMessages((prev) =>
        prev.map((m) => (m.id === p.messageId ? { ...m, content: t("messenger.messageDeleted"), deletedAt: new Date().toISOString() } : m))
      );
    },
    "typing.start": (payload) => {
      // Enrich with the sender's name from the conversation list (the realtime
      // service doesn't have access to user names, so it sends an empty string).
      const p = payload as { conversationId?: string; userId?: string; fullName?: string };
      if (p && !p.fullName && p.conversationId) {
        const conv = conversations.find((c) => c.id === p.conversationId);
        if (conv?.otherUser) {
          p.fullName = conv.otherUser.fullName;
        }
      }
      typingHandlerRef.current(p);
    },
    "typing.stop": (payload) => {
      const p = payload as { conversationId?: string; userId?: string; fullName?: string };
      if (p && !p.fullName && p.conversationId) {
        const conv = conversations.find((c) => c.id === p.conversationId);
        if (conv?.otherUser) {
          p.fullName = conv.otherUser.fullName;
        }
      }
      typingHandlerRef.current(p);
    },
    // ── Chat Video Call: incoming call ────────────────────────────────
    // The caller POSTed /api/v1/conversations/[id]/call/start, the server
    // broadcast this event. We open the dialog in "incoming" mode.
    // SAFETY: only handle calls for the CURRENTLY active conversation (so a
    // call ringing in Conversation A doesn't pop a dialog while the user is
    // viewing Conversation B — they'll see the missed-call badge instead).
    //
    // DISABLED (TEMPORARY): when NEXT_PUBLIC_VIDEO_CHAT_ENABLED is not
    // "true", the handler is a no-op — the realtime event is consumed
    // without opening the dialog. The caller's ring will eventually time
    // out server-side (RING_TIMEOUT_MS) and they'll see "No answer." This
    // prevents the disabled feature from interrupting the user.
    "conversation:call:incoming": (payload) => {
      if (!isVideoChatClientEnabled()) return;
      const p = payload as {
        callId: string;
        conversationId: string;
        caller: CallPeer;
        expiresAt: number;
      };
      if (!p?.callId || !p?.conversationId || !p?.caller) return;
      // Only open the dialog if the user is currently viewing this
      // conversation. Otherwise, the user will see the next time they open
      // it (we don't proactively interrupt them while they're in another
      // conversation — that would be jarring UX).
      if (p.conversationId !== selectedIdRef.current) return;
      // If the user is already in a call, ignore (the server already
      // returned "busy" to the caller — but defensive: don't double-open).
      if (videoCallOpen) return;
      setIncomingVideoCall({ callId: p.callId, caller: p.caller });
      setVideoCallOpen(true);
    },
    // ── Chat Video Call: accept / reject / end / busy events ──────────
    // The hook handles state transitions internally based on these events.
    // We don't need to do anything here — the hook is mounted inside the
    // dialog and will react to these events when its dialog is open.
    // The only event we need to handle at the messenger level is "end" —
    // because if the OTHER side ends the call, our dialog should close
    // (the hook handles it, but we also close the dialog container).
    "conversation:call:event": (payload) => {
      const p = payload as {
        callId: string;
        conversationId: string;
        action: "accept" | "reject" | "end" | "busy";
        byUserId: string;
      };
      if (!p?.callId) return;
      // The hook handles the actual WebRTC/state transitions. The dialog
      // closes itself when the hook's state transitions to "ended"/"idle".
      // We don't need to do anything here — this handler exists so the
      // event is consumed (otherwise React might warn about unhandled
      // realtime events).
      void p;
    },
  });

  // Typing indicator — ephemeral realtime state (never stored in DB).
  const { typingUsers, onLocalTyping, onLocalStop, onRemoteTyping } = useTypingIndicator({
    conversationId: selectedId,
    currentUserId: user?.id,
    emitTyping,
  });

  // Keep the typing handler ref updated so useRealtime can delegate to it.
  useEffect(() => {
    typingHandlerRef.current = onRemoteTyping as (payload: unknown) => void;
  }, [onRemoteTyping]);

  // Notify the realtime service which conversation is active.
  useEffect(() => {
    setActiveConversation(selectedId);
  }, [selectedId, setActiveConversation]);

  // Smart scroll logic:
  // - On conversation open (loadingMessages goes from true→false): scroll to
  //   bottom instantly (no smooth animation — the user should see the latest
  //   message immediately).
  // - On new messages: if the user is near the bottom (within ~150px), auto-
  //   scroll smoothly. If they're reading old messages, show a "New messages"
  //   indicator instead of forcing them down.
  // - On send: always scroll to bottom (the user just sent a message, they
  //   expect to see it).
  const scrollToBottom = useCallback((behavior: "smooth" | "auto" = "smooth") => {
    const container = threadRef.current;
    if (!container) return;
    container.scrollTo({ top: container.scrollHeight, behavior });
    isNearBottomRef.current = true;
    setShowNewMessagesIndicator(false);
  }, []);

  // Track scroll position to know if user is near bottom.
  const onScroll = useCallback(() => {
    const container = threadRef.current;
    if (!container) return;
    const { scrollTop, scrollHeight, clientHeight } = container;
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
    isNearBottomRef.current = distanceFromBottom < 150;
    if (isNearBottomRef.current) {
      setShowNewMessagesIndicator(false);
    }
  }, []);

  // On messages change: smart auto-scroll.
  useEffect(() => {
    if (messages.length === 0) return;
    // If loading just finished (conversation opened), scroll to bottom instantly.
    if (!loadingMessages) {
      if (isNearBottomRef.current) {
        // Use requestAnimationFrame to ensure DOM is updated before scrolling.
        requestAnimationFrame(() => scrollToBottom("smooth"));
      } else {
        // User is reading old messages — show indicator.
        setShowNewMessagesIndicator(true);
      }
    }
  }, [messages, loadingMessages, scrollToBottom]);

  // On conversation open: scroll to bottom instantly.
  useEffect(() => {
    if (selectedId && !loadingMessages) {
      requestAnimationFrame(() => scrollToBottom("auto"));
    }
  }, [selectedId, loadingMessages, scrollToBottom]);

  // ── FIX 8: Incoming-call polling fallback for Netlify ──────────────
  //
  // On Netlify production, the realtime socket.io service is NOT
  // running (it's a separate process on port 3003 in dev only). The
  // `broadcastRealtime` call in /call/start POSTs to localhost:3003
  // which silently fails — the recipient never receives the
  // `conversation:call:incoming` realtime event.
  //
  // This effect polls the new /call/incoming endpoint every 5s when
  // the user is viewing a conversation. If there's an unanswered
  // incoming call for the current user, we open the ChatVideoCallDialog
  // in "incoming" mode — the same UI the realtime event would have
  // triggered.
  //
  // DUPLICATE-EVENT HANDLING:
  //   The `ChatVideoCallDialog` already dedupes by callId (via
  //   `incomingCallIdRef`). If both the realtime event AND this poll
  //   fire for the same callId (e.g. in dev where realtime IS running),
  //   only the first opens the dialog.
  //
  // LOAD:
  //   One GET every 5s per active conversation view. The endpoint is
  //   lightweight (one Redis GET + one conversation-membership DB
  //   query). Acceptable for the typical 1-2 concurrent messenger
  //   views per user.
  //
  // POLLING STOPPED:
  //   - When the user navigates away from a conversation (selectedId
  //     changes → effect cleanup clears the interval).
  //   - When the dialog is already open (videoCallOpen=true — no need
  //     to poll, the user is already in a call).
  //   - When the user logs out (user becomes null → no auth).
  useEffect(() => {
    // DISABLED (TEMPORARY): when NEXT_PUBLIC_VIDEO_CHAT_ENABLED is not
    // "true", the incoming-call polling is SKIPPED entirely. No API
    // request is sent, no interval is created. This saves 1 request per
    // 5s per active conversation view — and keeps the network quiet
    // while the feature is intentionally disabled.
    if (!isVideoChatClientEnabled()) return;
    if (!user || !selectedId || videoCallOpen) return;
    let cancelled = false;
    const INCOMING_POLL_MS = 5_000;
    const pollOnce = async () => {
      if (cancelled) return;
      try {
        const result = await api.get<{ call: { callId: string; conversationId: string; caller: CallPeer; expiresAt: number } | null }>(
          `/api/v1/conversations/${selectedId}/call/incoming`
        );
        if (cancelled || !result.call) return;
        // Only open if the user is still viewing this conversation
        // (might have switched during the await) AND the dialog isn't
        // already open (defensive — the realtime event might have fired).
        if (selectedIdRef.current !== selectedId) return;
        if (videoCallOpen) return;
        setIncomingVideoCall({ callId: result.call.callId, caller: result.call.caller });
        setVideoCallOpen(true);
      } catch {
        // Network error or 403 (feature flag off) — silent, keep polling.
      }
    };
    // Fire immediately on conversation open (catches calls that started
    // while the user was viewing another conversation or just logged in).
    void pollOnce();
    const interval = setInterval(pollOnce, INCOMING_POLL_MS);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [user, selectedId, videoCallOpen]);

  const selected = conversations.find((c) => c.id === selectedId) ?? null;

  async function sendMessage() {
    if (!selectedId || !draft.trim()) return;
    const content = draft.trim();
    const sentInConversation = selectedId;  // capture at send time
    setDraft("");
    onLocalStop(); // stop typing indicator when sending

    // ── Bug 1 fix: TRUE optimistic UI ───────────────────────────────
    // Add the message to the UI IMMEDIATELY with a temporary client-only
    // ID (prefixed `temp:` so it can never collide with a real DB cuid).
    // The user sees their message the instant they hit Send — no waiting
    // for the network round-trip. When the server responds, we REPLACE
    // the temp message with the real one (matched by tempId). If the
    // request fails, we remove the temp message so the user sees the
    // failure instantly (and the draft is restored).
    const tempId = `temp:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
    const optimisticMessage: MessageDTO = {
      id: tempId,
      conversationId: sentInConversation,
      senderId: user?.id ?? "",
      senderName: user?.fullName ?? "",
      content,
      createdAt: new Date().toISOString(),
      readAt: null,
      editedAt: null,
      deletedAt: null,
      mine: true,
    };
    setMessages((prev) => [...prev, optimisticMessage]);
    requestAnimationFrame(() => scrollToBottom("smooth"));

    try {
      const data = await api.post<{ message: MessageDTO }>(`/api/v1/conversations/${sentInConversation}/messages`, { content });
      // SAFETY LAYER: only reconcile if the active conversation is STILL
      // the one we sent the message in. If the user switched conversations
      // while the POST was in flight, the temp message was already
      // cleared by the conversation-switch reset effect. The real message
      // will be picked up by the realtime/polling fallback when the user
      // returns to the original conversation (Bug 2 root cause).
      if (selectedIdRef.current === sentInConversation) {
        setMessages((prev) => {
          // Case 1: realtime event already inserted the real message —
          // just remove the temp placeholder, don't add a duplicate.
          if (prev.some((m) => m.id === data.message.id)) {
            return prev.filter((m) => m.id !== tempId);
          }
          // Case 2: replace the temp placeholder in-place with the real
          // message (preserves position in the thread).
          if (prev.some((m) => m.id === tempId)) {
            return prev.map((m) => (m.id === tempId ? data.message : m));
          }
          // Case 3: temp placeholder is gone (e.g., conversation was
          // reloaded while the POST was in flight) — just append the
          // real message at the end.
          return [...prev, data.message];
        });
      }
      void loadConversations();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to send message");
      // Remove the optimistic message — the send failed, the user should
      // not see a phantom message stuck in the thread.
      if (selectedIdRef.current === sentInConversation) {
        setMessages((prev) => prev.filter((m) => m.id !== tempId));
        // Only restore the draft if the user is still in the same
        // conversation (don't override a draft they may have started
        // typing in the new one).
        setDraft(content);
      }
    }
  }

  async function startConversation(userId: string) {
    try {
      const data = await api.post<{ conversation: { id: string } }>("/api/v1/conversations", { userId });
      setSelectedId(data.conversation.id);
      setSearchOpen(false);
      setMobileSidebarOpen(false);
      await loadConversations();
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to start conversation");
    }
  }

  async function deleteMessage(id: string) {
    // Capture the active conversation at call time — if the user switches
    // conversations while the DELETE is in flight, we won't apply the
    // optimistic UI to the NEW conversation's message list.
    const activeAtCall = selectedIdRef.current;
    try {
      await api.delete(`/api/v1/messages/${id}`);
      if (selectedIdRef.current === activeAtCall) {
        setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, content: "[message deleted]", deletedAt: new Date().toISOString() } : m)));
      }
      toast.success("Message deleted");
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to delete message");
    }
  }

  async function editMessage(id: string) {
    const msg = messages.find((m) => m.id === id);
    if (!msg) return;
    const content = window.prompt("Edit message", msg.content);
    if (!content || content === msg.content) return;
    const activeAtCall = selectedIdRef.current;
    try {
      const data = await api.patch<{ message: MessageDTO }>(`/api/v1/messages/${id}`, { content });
      if (selectedIdRef.current === activeAtCall) {
        setMessages((prev) => prev.map((m) => (m.id === id ? data.message : m)));
      }
      toast.success("Message updated");
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to edit message");
    }
  }

  // Debounced search — avoids sending a request for every keystroke.
  function doSearch(q: string) {
    setSearchQuery(q);
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    if (q.trim().length < 2) {
      setSearchResults([]);
      return;
    }
    searchDebounceRef.current = setTimeout(async () => {
      try {
        const data = await api.get<{ users: UserSearchResult[] }>(`/api/v1/users/search?q=${encodeURIComponent(q)}`);
        setSearchResults(data.users);
      } catch {
        setSearchResults([]);
      }
    }, 300); // 300ms debounce
  }

  // Load search history when the search dialog opens.
  async function loadSearchHistory() {
    try {
      const data = await api.get<{ history: { id: string; query: string; targetUsername?: string | null; targetFullName?: string | null }[] }>("/api/v1/search-history");
      setSearchHistory(data.history);
    } catch {
      /* ignore */
    }
  }

  // Save a search to history (called when user clicks a result).
  async function saveSearch(query: string, target?: { id: string; username: string; fullName: string }) {
    try {
      await api.post("/api/v1/search-history", {
        query: query.trim(),
        targetUserId: target?.id,
        targetUsername: target?.username,
        targetFullName: target?.fullName,
      });
    } catch {
      /* ignore */
    }
  }

  async function deleteSearchHistoryItem(id: string) {
    setSearchHistory((prev) => prev.filter((h) => h.id !== id));
    try {
      await api.delete(`/api/v1/search-history/${id}`);
    } catch {
      /* ignore */
    }
  }

  async function clearSearchHistory() {
    setSearchHistory([]);
    try {
      await api.delete("/api/v1/search-history");
    } catch {
      /* ignore */
    }
  }

  // Navigate to a user's profile from search results.
  function openProfileFromSearch(u: UserSearchResult) {
    void saveSearch(searchQuery, { id: u.id, username: u.username, fullName: u.fullName });
    setSearchOpen(false);
    router.push(`/?view=profile&username=${encodeURIComponent(u.username)}`);
  }

  async function logout() {
    try {
      await api.post("/api/v1/auth/logout");
    } catch {
      /* ignore */
    }
    clear();
    router.push("/");
  }

  if (!user) return null;

  return (
    <div className="flex h-screen flex-col bg-background pb-14 md:pb-0">
      {/* ===================================================================== */}
      {/* MOBILE TOP BAR — minimal, per spec §3                                  */}
      {/* Only brand + search (for new chat). No Home/Messages/Notifications/   */}
      {/* Profile — those live in the bottom nav. No hamburger (per spec §1).    */}
      {/* ===================================================================== */}
      <header className="flex h-14 shrink-0 items-center justify-between border-b px-3 md:hidden">
        <div className="flex items-center gap-2 min-w-0">
          <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <MessageSquare className="h-4 w-4" />
          </span>
          <span className="truncate text-sm font-semibold">{platformName}</span>
        </div>
        <div className="flex items-center gap-1">
          {(user.role === "ADMIN" || user.role === "SUPER_ADMIN") && (
            <Button variant="ghost" size="icon" onClick={() => router.push("/?view=admin")} title={t("nav.adminPanel")}>
              <Shield className="h-5 w-5" />
            </Button>
          )}
          <Button variant="ghost" size="icon" onClick={() => setSearchOpen(true)} title={t("nav.newChat")}>
            <Search className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* ===================================================================== */}
      {/* DESKTOP TOP BAR — unchanged (per spec §13: do not modify desktop)      */}
      {/* Contains: Home, Messages, Notifications, Search, Profile, Theme,      */}
      {/* Admin, Logout.                                                        */}
      {/* ===================================================================== */}
      <header className="hidden h-14 shrink-0 items-center justify-between border-b px-3 md:flex">
        <div className="flex items-center gap-1">
          {/* Home button (current view = messenger) */}
          <button
            onClick={() => router.push("/")}
            className="relative flex items-center gap-2 rounded-lg bg-accent px-3 py-2 text-sm font-medium text-accent-foreground transition-colors"
          >
            <PanelLeft className="h-5 w-5 text-primary rtl-flip" />
            <span className="hidden sm:inline">{platformName}</span>
          </button>

          {/* Messages button */}
          <button
            onClick={() => router.push("/?view=messages")}
            className="relative flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent"
          >
            <MessageSquare className="h-5 w-5" />
            <span className="hidden sm:inline">Messages</span>
            {unreadMessages > 0 && (
              <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
                {unreadMessages > 99 ? "99+" : unreadMessages}
              </span>
            )}
          </button>

          {/* Notifications */}
          <NotificationCenter
            enabled={!!user}
            onNavigate={(target) => {
              if (target.conversationId) {
                setSelectedId(target.conversationId);
                setMobileSidebarOpen(false);
              }
            }}
          />

          {/* New chat / search */}
          <Button variant="ghost" size="icon" onClick={() => setSearchOpen(true)} title={t("nav.newChat")}>
            <Search className="h-5 w-5" />
          </Button>

          {/* Compose new post (Phase 1 — text only) */}
          <PostComposer />
        </div>

        <div className="flex items-center gap-1">
          {/* Profile — opens own profile */}
          <button
            onClick={() => user && router.push(`/?view=profile&username=${encodeURIComponent(user.username)}`)}
            className="rounded-lg p-1.5 transition-colors hover:bg-accent"
            title="Profile"
          >
            <Avatar name={user.fullName} color={user.avatarColor} src={user.avatarUrl} size="sm" />
          </button>

          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} title={t("nav.toggleTheme")}>
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>

          {(user.role === "ADMIN" || user.role === "SUPER_ADMIN") && (
            <Button variant="ghost" size="icon" onClick={() => router.push("/?view=admin")} title={t("nav.adminPanel")}>
              <Shield className="h-5 w-5" />
            </Button>
          )}

          <Button variant="ghost" size="icon" onClick={logout} title={t("auth.signOut")}>
            <LogOut className="h-5 w-5 rtl-flip" />
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar (desktop) */}
        <aside className="hidden w-80 shrink-0 border-r md:block">
          <ConversationSidebar
            conversations={conversations}
            selectedId={selectedId}
            // When the admin selects a conversation from the sidebar, we
            // update BOTH the React state (selectedId) AND the URL
            // (?conversation=<id>) via router.replace. This keeps the
            // URL in sync with the active conversation — so the browser
            // back button, bookmarks, and page refresh all land on the
            // correct conversation. Per spec §1: "URL/state changes
            // correctly". Using `replace` (not `push`) so we don't
            // pollute the browser history with every conversation switch.
            onSelect={(id) => {
              setSelectedId(id);
              router.replace(`/?conversation=${id}`, { scroll: false });
            }}
            onNewChat={() => setSearchOpen(true)}
            user={user}
            onLogout={logout}
          />
        </aside>

        {/* Thread */}
        <main className="flex flex-1 flex-col overflow-hidden">
          {selected ? (
            <>
              <div className="flex h-14 shrink-0 items-center gap-1 border-b px-4">
                {/* Clickable profile area (navigates to the other user's profile).
                    This is a div with role=button so the video call icon can be a
                    separate sibling button without nesting interactive elements
                    (which is invalid HTML + breaks accessibility). */}
                <button
                  type="button"
                  className="flex min-w-0 flex-1 items-center gap-3 self-stretch text-left transition-colors hover:bg-accent/50 focus-visible:outline-none focus-visible:inset-ring-2 focus-visible:inset-ring-ring rounded-md"
                  onClick={() => {
                    if (selected.otherUser?.username) {
                      router.push(`/?view=profile&username=${encodeURIComponent(selected.otherUser.username)}`);
                    }
                  }}
                  aria-label={`Open ${selected.otherUser?.fullName ?? "user"}'s profile`}
                >
                  <Avatar name={selected.otherUser?.fullName ?? "?"} color={selected.otherUser?.avatarColor} src={selected.otherUser?.avatarUrl} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-1 truncate font-medium" dir="auto">
                      {selected.otherUser?.fullName ?? "Conversation"}
                      {selected.otherUser?.isVerified && <VerifiedBadge size={14} />}
                    </p>
                    <p className="flex items-center gap-1 truncate text-xs text-muted-foreground">
                      {/* Presence indicator — based on lastSeenAt from DB.
                          Online = lastSeenAt within the last 60 seconds.
                          Offline = lastSeenAt older than 60 seconds.
                          The 3-second polling on conversations keeps this
                          reasonably fresh without adding a new request. */}
                      {selected.otherUser?.lastSeenAt && (() => {
                        const lastSeen = new Date(selected.otherUser.lastSeenAt).getTime();
                        const isOnline = Date.now() - lastSeen < 60_000;
                        return (
                          <>
                            <span
                              className={cn(
                                "h-2 w-2 shrink-0 rounded-full",
                                isOnline ? "bg-green-500" : "bg-muted-foreground/40"
                              )}
                            />
                            <span>
                              {isOnline
                                ? "Online"
                                : t("messenger.offline") || "Offline"}
                            </span>
                          </>
                        );
                      })()}
                    </p>
                  </div>
                </button>
                {/* ── Video Call icon ──────────────────────────────────────
                    Spec §1: the icon must be visible on Desktop, Laptop,
                    Tablet, and Mobile. No `hidden`/`display:none` breakpoints.
                    The button is accessible (aria-label, tooltip on desktop,
                    keyboard-focusable). Clicking opens the ChatVideoCallDialog
                    in "preview" mode (live camera preview + mic/cam toggles
                    + Start Call button) — does NOT request camera permission
                    until the user actually clicks the icon (spec §14).

                    The conversation must exist (selected is truthy — we're
                    inside the `selected ?` branch) AND the other user must
                    exist (selected.otherUser is truthy). If the conversation
                    is a group (no otherUser), the button is disabled — the
                    server-side API also rejects group conversations, so this
                    is defense-in-depth.

                    DISABLED (TEMPORARY): the entire button is gated on
                    `isVideoChatClientEnabled()`. When the env var is not
                    "true", the ChatVideoCallButton component itself ALSO
                    returns null (defense-in-depth — see chat-video-call-button.tsx),
                    so wrapping it here is belt-and-suspenders: even if a
                    future change forgets to gate the import site, the
                    component never renders. */}
                {isVideoChatClientEnabled() && (
                  <ChatVideoCallButton
                    onClick={() => {
                      // Opening the dialog from the icon = manual open = preview flow.
                      // Clear any stale incoming call state first.
                      setIncomingVideoCall(null);
                      setVideoCallOpen(true);
                    }}
                    disabled={!selected.otherUser}
                    disabledReason={
                      !selected.otherUser
                        ? "Video calls are only available in direct conversations"
                        : undefined
                    }
                    active={videoCallOpen}
                  />
                )}
              </div>

              {/* Messages container — plain div (not ScrollArea) for reliable
                  scroll events + mobile keyboard support. The container is
                  the ONLY scrollable element; header + input are fixed. */}
              <div
                ref={threadRef}
                onScroll={onScroll}
                className="relative flex-1 overflow-y-auto overflow-x-hidden px-4"
              >
                <div className="space-y-2 py-4">
                  {loadingMessages ? (
                    <div className="flex items-center justify-center py-8 text-sm text-muted-foreground">
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {t("messenger.loading") || "Loading…"}
                    </div>
                  ) : messagesError ? (
                    /* Error state — shows inside the messages area (not a
                       full-page crash). Header + input remain visible so the
                       user can still navigate. Retry button re-fetches. */
                    <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
                      <p className="text-sm text-muted-foreground">{messagesError}</p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => selectedId && void loadMessages(selectedId)}
                      >
                        Try again
                      </Button>
                    </div>
                  ) : messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-16 text-center">
                      <p className="text-sm text-muted-foreground">{t("messenger.noMessages")}</p>
                      <p className="text-xs text-muted-foreground">{t("messenger.sayHello")}</p>
                    </div>
                  ) : (
                    messages.map((m) => <MessageBubble key={m.id} message={m} onEdit={editMessage} onDelete={deleteMessage} />)
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* "New messages" indicator — shown when new messages arrive
                    and the user is scrolled up reading old ones. Clicking it
                    scrolls to the bottom. */}
                {showNewMessagesIndicator && (
                  <button
                    onClick={() => scrollToBottom("smooth")}
                    className="sticky bottom-2 left-1/2 z-10 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground shadow-lg transition-all hover:scale-105"
                  >
                    <ArrowDown className="h-3 w-3" />
                    New messages
                  </button>
                )}
              </div>

              <TypingIndicator typingUsers={typingUsers} />
              <div className="flex items-end gap-2 border-t p-3">
                <textarea
                  value={draft}
                  onChange={(e) => {
                    setDraft(e.target.value);
                    onLocalTyping();
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      void sendMessage();
                    }
                  }}
                  placeholder={t("messenger.typeMessage")}
                  rows={1}
                  className="flex max-h-32 min-h-10 flex-1 resize-none rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                />
                <Button onClick={sendMessage} disabled={!draft.trim()} size="icon" aria-label={t("common.send")}>
                  <Send className="h-4 w-4 rtl-flip" />
                </Button>
              </div>
            </>
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                <Search className="h-8 w-8 text-muted-foreground" />
              </div>
              <div>
                <p className="font-medium">{t("messenger.selectConversation")}</p>
                <p className="text-sm text-muted-foreground">{t("messenger.selectConversationDesc")}</p>
              </div>
              <Button onClick={() => setSearchOpen(true)} variant="outline" className="mt-2">
                <Search className="mr-2 h-4 w-4" /> {t("messenger.findSomeone")}
              </Button>
            </div>
          )}
        </main>

        {/* ── Chat Video Call Dialog ─────────────────────────────────────
            Rendered when `videoCallOpen` is true. Two open modes:

            1. Manual (caller): user clicked the video icon in the header.
               `incomingVideoCall` is null — dialog opens in "preview" mode
               (live camera + mic/cam toggles + Start Call button).
            2. Incoming (recipient): realtime `conversation:call:incoming`
               event arrived. `incomingVideoCall` is set — dialog opens in
               "incoming" mode (Accept / Reject buttons).

            When the dialog closes (via X, Escape, or backdrop click), we
            clear the incoming state + close. The hook handles all cleanup
            (MediaStream, RTCPeerConnection, intervals, listeners).

            DISABLED (TEMPORARY): the entire block is gated on
            `isVideoChatClientEnabled()`. When the env var is not "true",
            the dialog NEVER mounts — no WebRTC, no getUserMedia, no
            permission prompt. The state setters above (`videoCallOpen`,
            `incomingVideoCall`) are still safe to call (no-op), but the
            UI never actually opens. The ChatVideoCallDialog component
            itself is preserved via the dynamic import above. */}
        {videoCallOpen && selected && isVideoChatClientEnabled() && (
          <ChatVideoCallDialog
            open={videoCallOpen}
            onOpenChange={(o) => {
              if (!o) {
                setVideoCallOpen(false);
                setIncomingVideoCall(null);
              }
            }}
            conversationId={selected.id}
            peer={
              selected.otherUser
                ? {
                    id: selected.otherUser.id,
                    fullName: selected.otherUser.fullName,
                    username: selected.otherUser.username,
                    avatarColor: selected.otherUser.avatarColor,
                    avatarUrl: selected.otherUser.avatarUrl,
                    isVerified: selected.otherUser.isVerified,
                  }
                : null
            }
            incomingCall={incomingVideoCall}
          />
        )}
      </div>

      {/* Mobile bottom navigation — primary mobile nav per spec §12 */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 flex h-14 items-center justify-around border-t bg-background/95 backdrop-blur md:hidden">
        <button
          onClick={() => router.push("/")}
          className="flex flex-col items-center gap-0.5 px-3 py-1.5 text-[10px] font-medium text-primary"
        >
          <Home className="h-5 w-5" />
          <span>{t("nav.home")}</span>
        </button>
        <button
          onClick={() => router.push("/?view=messages")}
          className="relative flex flex-col items-center gap-0.5 px-3 py-1.5 text-[10px] font-medium text-muted-foreground"
        >
          <MessageSquare className="h-5 w-5" />
          <span>{t("nav.messages")}</span>
          {unreadMessages > 0 && (
            <span className="absolute right-1 top-0 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
              {unreadMessages > 99 ? "99+" : unreadMessages}
            </span>
          )}
        </button>
        <div className="flex flex-col items-center">
          <NotificationCenter enabled={!!user} onNavigate={(target) => { if (target.conversationId) { setSelectedId(target.conversationId); setMobileSidebarOpen(false); } }} />
          <span className="text-[10px] font-medium text-muted-foreground">{t("nav.alerts")}</span>
        </div>
        <button
          onClick={() => user && router.push(`/?view=profile&username=${encodeURIComponent(user.username)}`)}
          className="flex flex-col items-center gap-0.5 px-3 py-1.5 text-[10px] font-medium text-muted-foreground"
        >
          <Avatar name={user.fullName} color={user.avatarColor} src={user.avatarUrl} size="sm" />
          <span>{t("nav.profile")}</span>
        </button>
      </nav>

      {/* Search dialog */}
      <Dialog
        open={searchOpen}
        onOpenChange={(open) => {
          setSearchOpen(open);
          if (open) void loadSearchHistory();
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("messenger.findUser")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input
              autoFocus
              placeholder={t("messenger.searchByNameOrEmail")}
              value={searchQuery}
              onChange={(e) => doSearch(e.target.value)}
            />
            <ScrollArea className="max-h-80">
              <div className="space-y-1">
                {searchQuery.trim().length < 2 ? (
                  /* Show search history when search box is empty or too short */
                  searchHistory.length > 0 ? (
                    <div>
                      <div className="flex items-center justify-between px-2 py-1">
                        <p className="text-xs font-semibold text-muted-foreground">Recent Searches</p>
                        <button
                          onClick={clearSearchHistory}
                          className="text-xs text-primary hover:underline"
                        >
                          Clear All
                        </button>
                      </div>
                      {searchHistory.map((h) => (
                        <div
                          key={h.id}
                          className="flex items-center gap-3 rounded-lg p-2 hover:bg-accent"
                        >
                          <button
                            onClick={() => {
                              setSearchQuery(h.query);
                              doSearch(h.query);
                            }}
                            className="flex min-w-0 flex-1 items-center gap-2 text-left"
                          >
                            <Clock className="h-4 w-4 shrink-0 text-muted-foreground" />
                            <div className="min-w-0">
                              <p className="truncate text-sm font-medium" dir="auto">
                                {h.targetFullName || h.query}
                              </p>
                              {h.targetUsername && (
                                <p className="truncate text-xs text-muted-foreground">@{h.targetUsername}</p>
                              )}
                            </div>
                          </button>
                          <button
                            onClick={() => deleteSearchHistoryItem(h.id)}
                            className="shrink-0 rounded p-1 text-muted-foreground hover:text-foreground"
                            title="Remove"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="py-4 text-center text-sm text-muted-foreground">
                      {t("messenger.typeAtLeast2")}
                    </p>
                  )
                ) : searchResults.length === 0 ? (
                  <p className="py-4 text-center text-sm text-muted-foreground">
                    {t("messenger.noUsersFound")}
                  </p>
                ) : (
                  searchResults.map((u) => (
                    <div
                      key={u.id}
                      className="flex w-full items-center gap-3 rounded-lg p-2 hover:bg-accent"
                    >
                      {/* User card — clicking opens PROFILE (not messages) */}
                      <button
                        onClick={() => openProfileFromSearch(u)}
                        className="flex min-w-0 flex-1 items-center gap-3 text-left"
                      >
                        <Avatar name={u.fullName} color={u.avatarColor} src={u.avatarUrl} size="sm" />
                        <div className="min-w-0">
                          <p className="flex items-center gap-1 truncate text-sm font-medium" dir="auto">
                            {u.fullName}
                            {u.isVerified && <VerifiedBadge size={12} />}
                          </p>
                          <p className="truncate text-xs text-muted-foreground">@{u.username}</p>
                        </div>
                      </button>

                      {/* Follow button — separate from profile navigation */}
                      {u.id !== user.id && (
                        <FollowButton
                          targetUserId={u.id}
                          targetUsername={u.username}
                          isFollowing={u.isFollowing ?? false}
                          isFollowedBy={u.isFollowedBy ?? false}
                          size="sm"
                        />
                      )}

                      {/* Message button — ONLY this opens the conversation */}
                      {u.id !== user.id && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => startConversation(u.id)}
                          className="shrink-0"
                        >
                          <MessageSquare className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ConversationSidebar({
  conversations,
  selectedId,
  onSelect,
  onNewChat,
  user,
  onLogout,
}: {
  conversations: ConversationListItem[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  user: { fullName: string; email: string; avatarColor: string | null; role: string };
  onLogout: () => void;
}) {
  const { t, fmtRelative } = useTranslation();
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b p-3">
        <div className="flex items-center gap-2">
          <Avatar name={user.fullName} color={user.avatarColor} size="sm" />
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{user.fullName}</p>
            <p className="truncate text-xs text-muted-foreground">{user.email}</p>
          </div>
        </div>
        <Button size="sm" variant="ghost" onClick={onNewChat} title={t("nav.newChat")}>
          <Search className="h-4 w-4" />
        </Button>
      </div>
      <ScrollArea className="flex-1">
        <div className="space-y-0.5 p-2">
          {conversations.length === 0 ? (
            <div className="px-3 py-8 text-center text-sm text-muted-foreground">
              {t("messenger.noConversations")}
              <Button onClick={onNewChat} variant="link" size="sm" className="mt-1 block w-full">
                {t("messenger.startOne")}
              </Button>
            </div>
          ) : (
            conversations.map((c) => (
              <button
                key={c.id}
                onClick={() => onSelect(c.id)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-accent",
                  selectedId === c.id && "bg-accent"
                )}
              >
                <Avatar name={c.otherUser?.fullName ?? "?"} color={c.otherUser?.avatarColor} src={c.otherUser?.avatarUrl} size="md" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="flex items-center gap-1 truncate text-sm font-medium" dir="auto">
                      {c.otherUser?.fullName ?? c.title}
                      {c.otherUser?.isVerified && <VerifiedBadge size={12} />}
                    </p>
                    {c.lastMessage && (
                      <span className="shrink-0 text-[10px] text-muted-foreground">
                        {fmtRelative(c.lastMessage.createdAt)}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-xs text-muted-foreground" dir="auto">
                      {c.lastMessage ? c.lastMessage.content : t("messenger.noMessages")}
                    </p>
                    {c.unreadCount > 0 && (
                      <Badge variant="default" className="h-5 shrink-0 px-1.5 text-[10px]">
                        {c.unreadCount > 9 ? "9+" : c.unreadCount}
                      </Badge>
                    )}
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </ScrollArea>
      <div className="border-t p-2">
        <Button variant="ghost" size="sm" onClick={onLogout} className="w-full justify-start">
          <LogOut className="mr-2 h-4 w-4 rtl-flip" /> {t("auth.signOut")}
        </Button>
      </div>
    </div>
  );
}

function MessageBubble({
  message,
  onEdit,
  onDelete,
}: {
  message: MessageDTO;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  const { t, fmtRelative } = useTranslation();
  return (
    <div className={cn("flex", message.mine ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "group relative max-w-[75%] rounded-2xl px-3 py-2 text-sm md:max-w-[60%]",
          message.mine
            ? "bg-primary text-primary-foreground"
            : "bg-muted text-foreground"
        )}
      >
        {/* Message content — rendered with URLs as clickable links.
            The MessageText component is purely a RENDERING helper: it
            splits the content by URL matches + renders URLs as <a>
            elements with target=_blank rel=noopener. Everything else
            (plain text, emoji, line breaks) is preserved EXACTLY as-is.
            Messages without URLs have ZERO behavior or styling change —
            the fast path renders a single text node identical to the
            previous `{message.content}` behavior. The parent <p> still
            has `whitespace-pre-wrap break-words` for line breaks + word
            wrapping. */}
        <p className="whitespace-pre-wrap break-words" dir="auto">
          <MessageText content={message.content} />
        </p>
        <div className={cn("mt-0.5 flex items-center gap-1 text-[10px]", message.mine ? "text-primary-foreground/70" : "text-muted-foreground")}>
          {message.editedAt && <span>{t("messenger.edited")}</span>}
          {message.deletedAt && <span>{t("messenger.deleted")}</span>}
          <span>{fmtRelative(message.createdAt)}</span>
          {message.mine && !message.deletedAt && (
            // Read receipts: ✓ (single check, muted) when unread, ✓✓ (double
            // check, blue) when read. The blue color signals to the sender
            // that the recipient has seen the message.
            message.readAt
              ? <CheckCheck className="h-3 w-3 rtl-flip text-blue-400" />
              : <Check className="h-3 w-3 rtl-flip" />
          )}
        </div>
        {message.mine && !message.deletedAt && (
          <div className="absolute -left-12 top-1/2 hidden -translate-y-1/2 gap-1 group-hover:flex rtl:-right-12 rtl:left-auto">
            <button onClick={() => onEdit(message.id)} className="rounded bg-background p-1 shadow hover:bg-accent" title={t("common.edit")}>
              <Edit2 className="h-3 w-3" />
            </button>
            <button onClick={() => onDelete(message.id)} className="rounded bg-background p-1 shadow hover:bg-accent" title={t("common.delete")}>
              <Trash2 className="h-3 w-3" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
