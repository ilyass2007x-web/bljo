"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MainNav } from "@/components/shared/main-nav";
import { useTranslation } from "@/lib/client/i18n-store";
import { api, type ConversationListItem } from "@/lib/client/api";
import { useRealtime } from "@/hooks/use-realtime";
import { Search, MessageSquare, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * MessagesPage — dedicated page showing all conversations.
 *
 * Features:
 * - Lists all conversations with avatar, name, username, verified badge, last message, time, unread count
 * - Search conversations by name/username
 * - Real-time updates: new messages move conversation to top + update unread count
 * - Click a conversation → opens the messenger with that conversation selected
 */
export function MessagesPage() {
  const router = useRouter();
  const { t, fmtRelative } = useTranslation();
  const [conversations, setConversations] = useState<ConversationListItem[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const loadConversations = useCallback(async () => {
    try {
      const data = await api.get<{ conversations: ConversationListItem[] }>("/api/v1/conversations");
      setConversations(data.conversations);
    } catch {
      /* ignore */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadConversations();
    // Poll for updates (5s fallback).
    const interval = setInterval(loadConversations, 5000);
    return () => clearInterval(interval);
  }, [loadConversations]);

  // Realtime: when a new message arrives, refresh the list.
  useRealtime(true, {
    "message:new": () => {
      void loadConversations();
    },
  });

  // Filter conversations by search query.
  // Null-safe: a conversation can have `otherUser === null` (e.g. the other
  // member was deleted, suspended, or left). Skipping those rows from search
  // matching is correct — they should not crash the page when the user types
  // in the search box.
  const filtered = search.trim()
    ? conversations.filter((c) => {
        const q = search.toLowerCase();
        const fullName = c.otherUser?.fullName?.toLowerCase() ?? "";
        const username = c.otherUser?.username?.toLowerCase() ?? "";
        const lastContent = c.lastMessage?.content?.toLowerCase() ?? "";
        return (
          fullName.includes(q) ||
          username.includes(q) ||
          lastContent.includes(q)
        );
      })
    : conversations;

  // Sort by updatedAt (most recent first).
  const sorted = [...filtered].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <MainNav />

      <div className="mx-auto w-full max-w-2xl flex-1 p-4 pb-20 md:pb-4">
        {/* Header */}
        <div className="mb-4 flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-primary" />
          <h1 className="text-xl font-bold">Messages</h1>
        </div>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search conversations..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>

        {/* Conversation list */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : sorted.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
              <MessageSquare className="h-8 w-8 text-muted-foreground" />
            </div>
            <div>
              <p className="font-medium">{t("messenger.noConversations")}</p>
              <p className="text-sm text-muted-foreground">{t("messenger.selectConversationDesc")}</p>
            </div>
            <Button variant="outline" onClick={() => router.push("/")}>
              <Search className="mr-2 h-4 w-4" />
              {t("messenger.findSomeone")}
            </Button>
          </div>
        ) : (
          <ScrollArea className="h-[calc(100vh-12rem)]">
            <div className="space-y-1">
              {sorted.map((c) => (
                <button
                  key={c.id}
                  onClick={() => router.push(`/?conversation=${c.id}`)}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-xl p-3 text-left transition-colors hover:bg-accent",
                    c.unreadCount > 0 && "bg-accent/30"
                  )}
                >
                  {/* Avatar */}
                  <Avatar
                    name={c.otherUser?.fullName ?? "?"}
                    color={c.otherUser?.avatarColor}
                    src={c.otherUser?.avatarUrl}
                    size="md"
                    onClick={() => c.otherUser?.username && router.push(`/?view=profile&username=${encodeURIComponent(c.otherUser.username)}`)}
                  />

                  {/* Content */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex min-w-0 items-center gap-1">
                        <p className="truncate text-sm font-medium" dir="auto">
                          {c.otherUser?.fullName ?? c.title}
                        </p>
                        {c.otherUser?.isVerified && <VerifiedBadge size={13} />}
                        <span className="truncate text-xs text-muted-foreground">
                          @{c.otherUser?.username}
                        </span>
                      </div>
                      {c.lastMessage && (
                        <span className="shrink-0 text-[10px] text-muted-foreground">
                          {fmtRelative(c.lastMessage.createdAt)}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <p className={cn("truncate text-xs", c.unreadCount > 0 ? "font-medium text-foreground" : "text-muted-foreground")} dir="auto">
                        {c.lastMessage ? c.lastMessage.content : t("messenger.noMessages")}
                      </p>
                      {c.unreadCount > 0 && (
                        <Badge variant="default" className="h-5 shrink-0 px-1.5 text-[10px]">
                          {c.unreadCount > 99 ? "99+" : c.unreadCount}
                        </Badge>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </ScrollArea>
        )}
      </div>
    </div>
  );
}
