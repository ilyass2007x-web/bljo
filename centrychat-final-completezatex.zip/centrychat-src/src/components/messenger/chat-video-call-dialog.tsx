"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Mic,
  MicOff,
  Video as VideoIcon,
  VideoOff,
  PhoneOff,
  Phone,
  PhoneIncoming,
  X,
  AlertTriangle,
  Loader2,
  Volume2,
  UserCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useChatVideoCall } from "@/hooks/use-chat-video-call";
import {
  type CallPeer,
  isVideoCallSupported,
  getUnsupportedReason,
} from "@/lib/chat-video-call/types";

/**
 * ChatVideoCallDialog — the full-screen (mobile) / large-modal (desktop)
 * video call container.
 *
 * Renders different UI based on the call state machine:
 *
 *   idle / busy     → not shown (caller of `open` decides visibility)
 *   preview         → live camera preview + mic/cam toggles + Start/Cancel
 *   calling         → "Ringing…" + recipient avatar + Cancel button
 *   connecting      → "Connecting…" spinner
 *   connected       → Remote video (large) + local video (PiP) + controls
 *   incoming         → Incoming call UI (recipient) — Accept / Reject
 *   ended           → "Call ended" + Close button
 *   failed          → Error message + Retry / Close buttons
 *
 * ── Responsive layout ────────────────────────────────────────────────
 *
 *   Desktop:  max-w-3xl modal with 16:9 video area + side panel.
 *   Tablet:   same modal shape, scaled down.
 *   Mobile:   full-screen (`w-screen h-[100dvh]`) with safe-area insets
 *             so iOS Safari's URL bar + home indicator don't cover
 *             controls.
 *
 *   We use `100dvh` (dynamic viewport height) instead of `100vh` so
 *   mobile browsers' dynamic toolbars don't cause the controls to
 *   disappear when the URL bar shows/hides. Spec §5.
 *
 * ── Cleanup ──────────────────────────────────────────────────────────
 *
 *   The hook's useEffect cleans up MediaStream + RTCPeerConnection on
 *   unmount. The dialog calls `cancelCall` or `endCall` before close,
 *   so closing the dialog always tears down the call.
 */

interface ChatVideoCallDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  conversationId: string | null;
  /** The other participant's profile (used in the header). */
  peer: CallPeer | null;
  /** Incoming call info — when set, the dialog opens in "incoming" mode. */
  incomingCall?: { callId: string; caller: CallPeer } | null;
}

export function ChatVideoCallDialog({
  open,
  onOpenChange,
  conversationId,
  peer,
  incomingCall,
}: ChatVideoCallDialogProps) {
  const supported = isVideoCallSupported();
  const unsupportedReason = getUnsupportedReason();

  // Track whether this dialog is in "incoming call" mode for the
  // current incomingCall payload. We reset when the callId changes.
  const incomingCallIdRef = useRef<string | null>(null);

  // Local UI state for "incoming" — set when an incoming call arrives
  // and the user hasn't accepted/rejected yet.
  const [incomingState, setIncomingState] = useState<{
    callId: string;
    caller: CallPeer;
  } | null>(null);

  const call = useChatVideoCall({
    conversationId,
    onIncomingCall: useCallback((payload) => {
      // The messenger passes the incoming call via props, so we don't
      // need to do anything here — the dialog opens via parent state.
      // But if a second incoming call arrives while we're already in
      // a call, we should auto-reject it.
      void payload;
    }, []),
    onCallEvent: useCallback(() => {
      // The hook handles state transitions internally based on the
      // realtime events (we don't need to do anything here).
    }, []),
  });

  // Track whether this dialog session was initiated by an incoming call.
  // Set when the dialog opens with an incomingCall prop, cleared when the
  // dialog closes. Used to distinguish the recipient's `requesting-permission`
  // state (after they clicked Accept — should show "Connecting…" UI) from
  // the caller's `requesting-permission` state (before they click Start
  // Call — should show the preview UI).
  const wasIncomingRef = useRef(false);

  // Sync the incomingCall prop to the hook's acceptIncomingCall action.
  useEffect(() => {
    if (!open) return;
    if (!incomingCall) return;
    if (call.state !== "idle" && call.state !== "incoming") return;
    if (incomingCallIdRef.current === incomingCall.callId) return;

    incomingCallIdRef.current = incomingCall.callId;
    wasIncomingRef.current = true;
    setIncomingState(incomingCall);
    // Transition the hook to "incoming" state (purely visual — the
    // actual accept/reject happens via the buttons).
    // We can't set the hook's state directly, so we use the dialog's
    // own incomingState to render the UI. When the user accepts, we
    // call call.acceptIncomingCall which transitions to connecting.
  }, [open, incomingCall, call.state]);

  // When the user opens the dialog manually (no incoming call), trigger
  // startCall which sets the hook to "preview" state.
  useEffect(() => {
    if (!open) return;
    if (incomingCall) return; // incoming call — don't auto-preview.
    if (call.state !== "idle") return; // already in progress.
    if (!supported) return; // unsupported — dialog will show error.
    void call.startCall();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, incomingCall]);

  // Cleanup when the dialog closes (Escape, X button, backdrop click).
  const handleClose = useCallback(() => {
    // If a call is in progress (any non-idle state), end it.
    if (call.state === "idle") {
      onOpenChange(false);
      return;
    }
    // Use endCall for connected/connecting, cancelCall for ringing/preview.
    if (call.state === "connected" || call.state === "connecting") {
      void call.endCall().then(() => onOpenChange(false));
    } else {
      void call.cancelCall().then(() => onOpenChange(false));
    }
  }, [call, onOpenChange]);

  // After ended/failed, the user clicks "Close" — reset + dismiss.
  const handleDismiss = useCallback(() => {
    call.reset();
    setIncomingState(null);
    incomingCallIdRef.current = null;
    onOpenChange(false);
  }, [call, onOpenChange]);

  // After "busy", the user clicks "Close" — reset + dismiss.
  const handleBusyDismiss = useCallback(() => {
    call.reset();
    onOpenChange(false);
  }, [call, onOpenChange]);

  // Reset wasIncomingRef when the dialog closes.
  useEffect(() => {
    if (!open) {
      wasIncomingRef.current = false;
      setIncomingState(null);
      incomingCallIdRef.current = null;
    }
  }, [open]);

  // Accept an incoming call.
  const handleAcceptIncoming = useCallback(() => {
    if (!incomingState) return;
    void call.acceptIncomingCall(incomingState.callId, incomingState.caller);
    setIncomingState(null);
  }, [call, incomingState]);

  // Reject an incoming call.
  const handleRejectIncoming = useCallback(() => {
    if (!incomingState) return;
    void call.rejectIncomingCall(incomingState.callId);
    setIncomingState(null);
    incomingCallIdRef.current = null;
    onOpenChange(false);
  }, [call, incomingState, onOpenChange]);

  // ── Unsupported browser ─────────────────────────────────────────────
  if (open && !supported) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md p-6">
          <DialogTitle className="sr-only">Video call unavailable</DialogTitle>
          <DialogDescription className="sr-only">
            Your browser does not support video calling.
          </DialogDescription>
          <div className="flex flex-col items-center gap-4 py-4 text-center">
            <AlertTriangle className="h-12 w-12 text-amber-500" aria-hidden />
            <h2 className="text-lg font-semibold">Video call unavailable</h2>
            <p className="text-sm text-muted-foreground">{unsupportedReason}</p>
            <Button onClick={() => onOpenChange(false)}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!open) return null;

  // Determine which "view" to render based on the state.
  const showIncoming = incomingState !== null && call.state !== "connected";
  // Preview is only shown for the CALLER (manual open from video icon).
  // The recipient's `requesting-permission` (after Accept) should show
  // ConnectingView instead — they already accepted, they shouldn't see
  // a "Start Call" button.
  const showPreview =
    !showIncoming &&
    !wasIncomingRef.current &&
    (call.state === "requesting-permission" || call.state === "preview");
  // The recipient (wasIncomingRef=true) sees ConnectingView during
  // `requesting-permission` (their camera is being acquired after they
  // clicked Accept — show a "Connecting…" UI, not the preview).
  const showRecipientConnecting =
    !showIncoming &&
    wasIncomingRef.current &&
    call.state === "requesting-permission";
  const showRinging = call.state === "calling";
  const showConnecting =
    call.state === "connecting" || showRecipientConnecting;
  const showConnected = call.state === "connected";
  const showReconnecting = call.state === "reconnecting";
  const showEnded = call.state === "ended";
  const showFailed = call.state === "failed";
  const showBusy = call.state === "busy";

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent
        className={cn(
          "overflow-hidden p-0 gap-0 bg-background border-0",
          // Full-screen on mobile (with safe-area support), modal on desktop.
          "fixed inset-0 sm:inset-auto sm:top-1/2 sm:left-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2",
          "sm:max-w-3xl sm:rounded-2xl sm:border",
          "h-[100dvh] sm:h-[80vh] sm:min-h-[500px]",
          "w-screen sm:w-[min(900px,95vw)]",
        )}
        // Disable the default close X (we render our own to ensure
        // cleanup happens via handleClose).
        showCloseButton={false}
      >
        <DialogTitle className="sr-only">
          Video call
        </DialogTitle>
        <DialogDescription className="sr-only">
          Video call in progress.
        </DialogDescription>

        {/* ── INCOMING CALL (recipient) ─────────────────────────────── */}
        {showIncoming && incomingState && (
          <IncomingCallView
            caller={incomingState.caller}
            onAccept={handleAcceptIncoming}
            onReject={handleRejectIncoming}
          />
        )}

        {/* ── PRE-CALL PREVIEW (camera + mic test) ─────────────────── */}
        {showPreview && (
          <PreviewView
            peer={peer}
            localVideoRef={call.localVideoRef}
            cameraOn={call.cameraOn}
            micOn={call.micOn}
            onToggleCamera={call.toggleCamera}
            onToggleMic={call.toggleMic}
            onStartCall={call.confirmCall}
            onCancel={handleClose}
            loading={call.state === "requesting-permission"}
          />
        )}

        {/* ── RINGING (caller's view) ───────────────────────────────── */}
        {showRinging && (
          <RingingView
            peer={peer}
            onCancel={handleClose}
          />
        )}

        {/* ── CONNECTING (spinner) ─────────────────────────────────── */}
        {showConnecting && (
          <ConnectingView
            peer={peer}
            localVideoRef={call.localVideoRef}
            onCancel={handleClose}
          />
        )}

        {/* ── CONNECTED (active call) ──────────────────────────────── */}
        {(showConnected || showReconnecting) && (
          <ConnectedView
            peer={peer}
            localVideoRef={call.localVideoRef}
            remoteVideoRef={call.remoteVideoRef}
            cameraOn={call.cameraOn}
            micOn={call.micOn}
            onToggleCamera={call.toggleCamera}
            onToggleMic={call.toggleMic}
            onEndCall={handleClose}
            reconnecting={showReconnecting}
          />
        )}

        {/* ── ENDED ───────────────────────────────────────────────── */}
        {showEnded && (
          <EndStateView
            title="Call ended"
            message="The call has ended."
            peer={peer}
            onClose={handleDismiss}
          />
        )}

        {/* ── FAILED ──────────────────────────────────────────────── */}
        {showFailed && (
          <EndStateView
            title="Call failed"
            message={call.error ?? "The call could not be completed."}
            peer={peer}
            onClose={handleDismiss}
          />
        )}

        {/* ── BUSY ────────────────────────────────────────────────── */}
        {showBusy && (
          <EndStateView
            title="Line busy"
            message="The other person is already in a call. Please try again later."
            peer={peer}
            onClose={handleBusyDismiss}
          />
        )}
      </DialogContent>
    </Dialog>
  );
}

// ── Sub-components ────────────────────────────────────────────────────

interface SubViewProps {
  peer: CallPeer | null;
}

function PeerHeader({ peer }: SubViewProps) {
  if (!peer) return null;
  return (
    <div className="flex items-center gap-2 px-4 py-3 border-b">
      <Avatar
        name={peer.fullName}
        color={peer.avatarColor}
        src={peer.avatarUrl}
        size="sm"
      />
      <div className="min-w-0 flex-1">
        <p className="flex items-center gap-1 truncate font-medium" dir="auto">
          {peer.fullName}
          {peer.isVerified && <VerifiedBadge size={14} />}
        </p>
        <p className="truncate text-xs text-muted-foreground">
          @{peer.username}
        </p>
      </div>
    </div>
  );
}

// ── Incoming Call (recipient's view) ──────────────────────────────────
function IncomingCallView({
  caller,
  onAccept,
  onReject,
}: {
  caller: CallPeer;
  onAccept: () => void;
  onReject: () => void;
}) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-6 p-6 text-center">
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <Avatar
            name={caller.fullName}
            color={caller.avatarColor}
            src={caller.avatarUrl}
            size="lg"
          />
          <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 animate-ping rounded-full bg-primary/30 px-3 py-1" />
        </div>
        <div>
          <p className="flex items-center justify-center gap-1 text-lg font-semibold" dir="auto">
            {caller.fullName}
            {caller.isVerified && <VerifiedBadge size={16} />}
          </p>
          <p className="text-sm text-muted-foreground">Incoming video call…</p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <Button
          variant="destructive"
          size="lg"
          onClick={onReject}
          aria-label="Reject call"
          className="rounded-full"
        >
          <PhoneOff className="h-5 w-5" aria-hidden />
          Decline
        </Button>
        <Button
          size="lg"
          onClick={onAccept}
          aria-label="Accept call"
          className="rounded-full bg-green-600 hover:bg-green-700"
        >
          <Phone className="h-5 w-5" aria-hidden />
          Accept
        </Button>
      </div>
    </div>
  );
}

// ── Preview View (live camera + mic/cam toggles + Start Call) ─────────
function PreviewView({
  peer,
  localVideoRef,
  cameraOn,
  micOn,
  onToggleCamera,
  onToggleMic,
  onStartCall,
  onCancel,
  loading,
}: SubViewProps & {
  localVideoRef: React.RefObject<HTMLVideoElement | null>;
  cameraOn: boolean;
  micOn: boolean;
  onToggleCamera: () => void;
  onToggleMic: () => void;
  onStartCall: () => void;
  onCancel: () => void;
  loading: boolean;
}) {
  return (
    <div className="flex h-full flex-col">
      <PeerHeader peer={peer} />
      <div className="relative flex-1 overflow-hidden bg-black">
        {/* Live camera preview */}
        <video
          ref={localVideoRef}
          autoPlay
          playsInline
          muted
          className="h-full w-full object-cover"
          aria-label="Your camera preview"
        />
        {/* Loading overlay (while permission is being requested) */}
        {loading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/80 text-white">
            <Loader2 className="h-8 w-8 animate-spin" aria-hidden />
            <p className="text-sm">Requesting camera and microphone…</p>
          </div>
        )}
        {/* Camera off overlay (when user toggles camera off) */}
        {!cameraOn && !loading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/80 text-white">
            <VideoOff className="h-8 w-8" aria-hidden />
            <p className="text-sm">Camera is off</p>
          </div>
        )}
        {/* Toggle buttons (top-right floating, won't cover the face) */}
        <div className="absolute right-3 top-3 flex gap-2">
          <button
            type="button"
            onClick={onToggleMic}
            disabled={loading}
            aria-label={micOn ? "Mute microphone" : "Unmute microphone"}
            className={cn(
              "inline-flex h-10 w-10 items-center justify-center rounded-full transition-colors",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              micOn
                ? "bg-white/20 text-white hover:bg-white/30"
                : "bg-red-500 text-white hover:bg-red-600",
            )}
          >
            {micOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
          </button>
          <button
            type="button"
            onClick={onToggleCamera}
            disabled={loading}
            aria-label={cameraOn ? "Turn camera off" : "Turn camera on"}
            className={cn(
              "inline-flex h-10 w-10 items-center justify-center rounded-full transition-colors",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              cameraOn
                ? "bg-white/20 text-white hover:bg-white/30"
                : "bg-red-500 text-white hover:bg-red-600",
            )}
          >
            {cameraOn ? <VideoIcon className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {/* Footer: Start Call + Cancel */}
      <div
        className="flex shrink-0 items-center justify-between gap-3 border-t bg-background px-4 py-3"
        style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}
      >
        <Button
          variant="ghost"
          onClick={onCancel}
          disabled={loading}
          aria-label="Cancel"
        >
          <X className="h-4 w-4" aria-hidden />
          Cancel
        </Button>
        <Button
          onClick={onStartCall}
          disabled={loading}
          aria-label="Start video call"
          className="bg-green-600 hover:bg-green-700"
        >
          <Phone className="h-4 w-4" aria-hidden />
          Start Call
        </Button>
      </div>
    </div>
  );
}

// ── Ringing View (caller's view while waiting for answer) ─────────────
function RingingView({
  peer,
  onCancel,
}: SubViewProps & { onCancel: () => void }) {
  return (
    <div className="flex h-full flex-col">
      <PeerHeader peer={peer} />
      <div className="flex flex-1 flex-col items-center justify-center gap-6 p-6 text-center">
        <div className="relative">
          {peer && (
            <Avatar
              name={peer.fullName}
              color={peer.avatarColor}
              src={peer.avatarUrl}
              size="lg"
            />
          )}
          <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-primary/20" />
        </div>
        <div className="flex flex-col items-center gap-2">
          <p className="text-lg font-semibold" dir="auto">
            {peer?.fullName ?? "Calling…"}
          </p>
          <p className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
            Ringing…
          </p>
        </div>
      </div>
      <div
        className="flex shrink-0 items-center justify-center border-t bg-background px-4 py-4"
        style={{ paddingBottom: "max(1rem, env(safe-area-inset-bottom))" }}
      >
        <Button
          variant="destructive"
          onClick={onCancel}
          aria-label="Cancel call"
          className="rounded-full"
        >
          <PhoneOff className="h-4 w-4" aria-hidden />
          Cancel
        </Button>
      </div>
    </div>
  );
}

// ── Connecting View ───────────────────────────────────────────────────
function ConnectingView({
  peer,
  localVideoRef,
  onCancel,
}: SubViewProps & {
  localVideoRef: React.RefObject<HTMLVideoElement | null>;
  onCancel: () => void;
}) {
  return (
    <div className="flex h-full flex-col">
      <PeerHeader peer={peer} />
      <div className="relative flex-1 overflow-hidden bg-black">
        <video
          ref={localVideoRef}
          autoPlay
          playsInline
          muted
          className="h-full w-full object-cover opacity-50"
          aria-label="Your camera"
        />
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-white">
          <Loader2 className="h-8 w-8 animate-spin" aria-hidden />
          <p className="text-sm">Connecting…</p>
        </div>
      </div>
      <div
        className="flex shrink-0 items-center justify-center border-t bg-background px-4 py-4"
        style={{ paddingBottom: "max(1rem, env(safe-area-inset-bottom))" }}
      >
        <Button
          variant="destructive"
          onClick={onCancel}
          aria-label="Cancel call"
          className="rounded-full"
        >
          <PhoneOff className="h-4 w-4" aria-hidden />
          Cancel
        </Button>
      </div>
    </div>
  );
}

// ── Connected View (active call: remote video large + local PiP + controls)
function ConnectedView({
  peer,
  localVideoRef,
  remoteVideoRef,
  cameraOn,
  micOn,
  onToggleCamera,
  onToggleMic,
  onEndCall,
  reconnecting,
}: SubViewProps & {
  localVideoRef: React.RefObject<HTMLVideoElement | null>;
  remoteVideoRef: React.RefObject<HTMLVideoElement | null>;
  cameraOn: boolean;
  micOn: boolean;
  onToggleCamera: () => void;
  onToggleMic: () => void;
  onEndCall: () => void;
  reconnecting: boolean;
}) {
  return (
    <div className="flex h-full flex-col">
      {/* Compact header (name + reconnecting indicator) */}
      <div className="flex shrink-0 items-center justify-between gap-2 border-b bg-background px-4 py-2">
        <div className="flex min-w-0 items-center gap-2">
          {peer && (
            <Avatar
              name={peer.fullName}
              color={peer.avatarColor}
              src={peer.avatarUrl}
              size="sm"
            />
          )}
          <p className="truncate text-sm font-medium" dir="auto">
            {peer?.fullName ?? "Video call"}
          </p>
          {reconnecting && (
            <span className="flex items-center gap-1 rounded-full bg-amber-500/15 px-2 py-0.5 text-xs text-amber-600 dark:text-amber-400">
              <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
              Reconnecting…
            </span>
          )}
        </div>
      </div>

      {/* Main video area: remote fills, local is PiP */}
      <div className="relative flex-1 overflow-hidden bg-black">
        <video
          ref={remoteVideoRef}
          autoPlay
          playsInline
          className="h-full w-full object-cover"
          aria-label={`${peer?.fullName ?? "Peer"}'s video`}
        />
        {/* Local video PiP — bottom-right, doesn't cover the user's face */}
        <div className="absolute bottom-4 right-4 h-24 w-32 overflow-hidden rounded-lg border-2 border-white/30 shadow-lg sm:h-32 sm:w-44">
          <video
            ref={localVideoRef}
            autoPlay
            playsInline
            muted
            className="h-full w-full object-cover"
            aria-label="Your video"
          />
          {!cameraOn && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/80 text-white">
              <VideoOff className="h-5 w-5" aria-hidden />
            </div>
          )}
        </div>
        {/* Reconnecting overlay (covers everything) */}
        {reconnecting && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/60 text-white">
            <Loader2 className="h-8 w-8 animate-spin" aria-hidden />
            <p className="text-sm">Reconnecting…</p>
          </div>
        )}
      </div>

      {/* Controls bar */}
      <div
        className="flex shrink-0 items-center justify-center gap-3 border-t bg-background px-4 py-3"
        style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}
      >
        <CallControlButton
          active={micOn}
          onClick={onToggleMic}
          onIcon={<Mic className="h-5 w-5" aria-hidden />}
          offIcon={<MicOff className="h-5 w-5" aria-hidden />}
          onLabel="Mute microphone"
          offLabel="Unmute microphone"
        />
        <CallControlButton
          active={cameraOn}
          onClick={onToggleCamera}
          onIcon={<VideoIcon className="h-5 w-5" aria-hidden />}
          offIcon={<VideoOff className="h-5 w-5" aria-hidden />}
          onLabel="Turn camera off"
          offLabel="Turn camera on"
        />
        {/* Speaker button — visual indicator only (WebRTC audio output
            device selection requires enumerateDevices + setSinkId,
            which is not universally supported — kept as visual placeholder
            for spec §6 + §7 architecture readiness). */}
        <CallControlButton
          active={true}
          onClick={() => {
            // Placeholder for future speaker toggle (e.g. audio output device switch).
          }}
          onIcon={<Volume2 className="h-5 w-5" aria-hidden />}
          offIcon={<Volume2 className="h-5 w-5" aria-hidden />}
          onLabel="Speaker on"
          offLabel="Speaker on"
          disabled
        />
        <button
          type="button"
          onClick={onEndCall}
          aria-label="End call"
          className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-red-600 text-white transition-colors hover:bg-red-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        >
          <PhoneOff className="h-5 w-5" aria-hidden />
        </button>
      </div>
    </div>
  );
}

// Reusable on/off toggle button (used for mic/camera/speaker).
function CallControlButton({
  active,
  onClick,
  onIcon,
  offIcon,
  onLabel,
  offLabel,
  disabled,
}: {
  active: boolean;
  onClick: () => void;
  onIcon: React.ReactNode;
  offIcon: React.ReactNode;
  onLabel: string;
  offLabel: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={active ? onLabel : offLabel}
      className={cn(
        "inline-flex h-12 w-12 items-center justify-center rounded-full transition-colors",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
        disabled && "cursor-not-allowed opacity-50",
        active
          ? "bg-muted text-foreground hover:bg-accent"
          : "bg-red-500 text-white hover:bg-red-600",
      )}
    >
      {active ? onIcon : offIcon}
    </button>
  );
}

// ── End State View (ended/failed/busy) ─────────────────────────────────
function EndStateView({
  title,
  message,
  peer,
  onClose,
}: {
  title: string;
  message: string;
  peer: CallPeer | null;
  onClose: () => void;
}) {
  return (
    <div className="flex h-full flex-col">
      <PeerHeader peer={peer} />
      <div className="flex flex-1 flex-col items-center justify-center gap-4 p-6 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
          <UserCircle2 className="h-8 w-8 text-muted-foreground" aria-hidden />
        </div>
        <h2 className="text-lg font-semibold">{title}</h2>
        <p className="max-w-xs text-sm text-muted-foreground">{message}</p>
      </div>
      <div
        className="flex shrink-0 items-center justify-center border-t bg-background px-4 py-4"
        style={{ paddingBottom: "max(1rem, env(safe-area-inset-bottom))" }}
      >
        <Button onClick={onClose} aria-label="Close">
          Close
        </Button>
      </div>
    </div>
  );
}
