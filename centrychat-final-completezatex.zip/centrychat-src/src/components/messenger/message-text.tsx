"use client";

import { memo } from "react";

/**
 * MessageText — renders a message's text content with URLs converted into
 * clickable `<a>` elements. Everything else (plain text, emoji, line breaks,
 * punctuation) is preserved EXACTLY as-is.
 *
 * WHY THIS EXISTS (spec §1-§4):
 *   The messenger previously rendered message content as a plain string:
 *     <p>{message.content}</p>
 *   URLs inside the message were NOT clickable — the user had to copy-paste
 *   them into the browser. This component makes URLs clickable while
 *   leaving all other text untouched.
 *
 * WHAT IT DOES NOT DO (spec §8, §9):
 *   - NO link previews (no og:image, no title, no description, no card).
 *   - NO URL resolution API call.
 *   - NO media resolver invocation.
 *   - NO database changes.
 *   - NO changes to message sending / receiving / storage.
 *   - NO changes to the message bubble UI / layout / styling.
 *
 * The component is purely a RENDERING helper — it takes a string, splits it
 * by URL matches, returns an array of React nodes (text + <a> elements).
 *
 * SECURITY (spec §5):
 *   - The URL regex ONLY matches `http://` and `https://` schemes.
 *     `javascript:`, `data:`, `vbscript:`, `file:`, `blob:`, `about:` are
 *     NEVER matched — they render as plain text (not clickable).
 *   - The matched URL is used VERBATIM as the `href` — we do NOT decode,
 *     re-encode, or transform it. This prevents any clever bypass where an
 *     attacker could construct a URL that the regex matches but the browser
 *     interprets as a different scheme.
 *   - The `<a>` element uses `target="_blank" rel="noopener noreferrer"` —
 *     the new tab cannot access `window.opener` (anti-reverse-tabnabbing).
 *   - React escapes the URL automatically when interpolating it into the
 *     `href` attribute — no manual HTML escaping needed (no XSS via the
 *     URL string itself).
 *
 * PRESERVATION (spec §10):
 *   - Plain text segments are rendered as-is (no escaping beyond what React
 *     already does).
 *   - Emoji, line breaks, tabs, multiple spaces — all preserved.
 *   - The parent `<p className="whitespace-pre-wrap break-words">` handles
 *     line breaks and word wrapping. We don't touch that.
 *
 * RESPONSIVE (spec §11):
 *   - Long URLs are wrapped via `break-all` on the `<a>` element — prevents
 *     horizontal overflow inside the message bubble.
 *   - The link inherits the parent's text color (no separate styling) so it
 *     looks natural inside the bubble for both "mine" (primary bg) and
 *     "theirs" (muted bg) messages. An underline is added so the user can
 *     tell it's clickable.
 */

// ── URL detection regex ────────────────────────────────────────────────────
//
// Matches `http://` or `https://` followed by one or more non-whitespace
// characters (excluding `<`, `>`, `"`, `'` — these are URL-breaking chars
// that browsers don't include in URLs anyway, so excluding them here
// prevents greedy matching across HTML-like content).
//
// The regex is GLOBAL (`g` flag) so we can iterate all matches in a single
// pass via `String.prototype.split` with a capturing group — `split`
// returns the captured groups interleaved with the non-matching segments,
// which is exactly what we need to render text + links.
//
// We deliberately do NOT use a more permissive scheme like `ftp://`,
// `mailto:`, or `tel:` — the spec only asks for http/https. Adding more
// schemes would expand the attack surface (e.g. `javascript:` could be
// sneaked in if we accidentally matched it).
const URL_REGEX = /(https?:\/\/[^\s<>"']+)/g;

/**
 * Trailing punctuation to strip from a matched URL.
 *
 * When a URL appears at the end of a sentence, the user typically types:
 *   "شوف هاد الفيديو https://youtube.com/watch?v=123."
 *                                                              ^ trailing dot
 * The browser would include the dot in the URL, which often 404s. We strip
 * these trailing chars so the URL points to what the user actually meant.
 *
 * The chars stripped are the common sentence-ending punctuation in both
 * English + Arabic contexts.
 */
const TRAILING_PUNCTUATION = ".,;:!?)]}\"'";

function stripTrailingPunctuation(url: string): string {
  // Strip any trailing chars that are in the TRAILING_PUNCTUATION set.
  // We do this in a loop because there may be multiple (e.g. "...!").
  let end = url.length;
  while (end > 0 && TRAILING_PUNCTUATION.includes(url[end - 1]!)) {
    end--;
  }
  return url.slice(0, end);
}

/**
 * Split a string into segments: alternating plain text + URL strings.
 * Used internally by the component to render each segment appropriately.
 *
 * Example:
 *   "hello https://example.com world"
 *   → ["hello ", "https://example.com", " world"]
 *
 * Example with multiple URLs:
 *   "https://a.com and https://b.com"
 *   → ["", "https://a.com", " and ", "https://b.com", ""]
 */
function splitByUrls(text: string): string[] {
  // `String.prototype.split` with a capturing group includes the captured
  // groups in the result array. This is exactly what we need — the array
  // alternates between non-matching text and matched URLs.
  return text.split(URL_REGEX);
}

/**
 * Check whether a string looks like a URL (matches the URL_REGEX). Used to
 * distinguish URL segments from plain-text segments in the split result.
 */
function looksLikeUrl(s: string): boolean {
  return URL_REGEX.test(s);
}

/**
 * MessageText — the React component.
 *
 * Renders the content with URLs as clickable links. When the content has NO
 * URLs, the output is functionally identical to rendering the string directly
 * — React renders a single text node with no wrapping element, so the parent
 * `<p>` sees the same children as before.
 *
 * This means: messages without URLs have ZERO behavior or styling change.
 * The `whitespace-pre-wrap break-words` on the parent `<p>` continues to
 * handle line breaks + word wrapping.
 */
function MessageTextImpl({ content }: { content: string }) {
  // Edge case: empty content — render nothing. The parent <p> will be empty.
  if (!content) return null;

  // Split the content by URL matches.
  const segments = splitByUrls(content);

  // If there's only ONE segment and it's not a URL, the content has NO URLs —
  // render it as a single text node (identical to the previous behavior).
  // This is the fast path for the vast majority of messages.
  if (segments.length === 1) {
    return <>{segments[0]}</>;
  }

  // Render each segment: URLs become <a>, plain text stays as text.
  return (
    <>
      {segments.map((segment, i) => {
        if (looksLikeUrl(segment)) {
          // Strip trailing punctuation so the URL is clean.
          const cleanUrl = stripTrailingPunctuation(segment);
          // Safety re-check: after stripping, the URL must STILL match the
          // http(s):// pattern. If somehow it doesn't (shouldn't happen
          // given the regex, but defensive), render as plain text.
          if (!/^https?:\/\//i.test(cleanUrl)) {
            return <span key={i}>{segment}</span>;
          }
          return (
            <a
              key={i}
              href={cleanUrl}
              target="_blank"
              rel="noopener noreferrer"
              // `break-all` allows long URLs to wrap inside the bubble
              // without overflowing horizontally. The parent <p> already
              // has `break-words` but `break-all` is more aggressive — it
              // breaks mid-URL if necessary (better than horizontal scroll).
              className="underline break-all"
              // Inherit the parent's text color — the link looks natural
              // inside both "mine" (primary bg) and "theirs" (muted bg)
              // bubbles. We only add an underline so the user knows it's
              // clickable.
            >
              {cleanUrl}
            </a>
          );
        }
        // Plain text segment — render as-is. React escapes it automatically
        // (no XSS via the message content). The `key` is the array index
        // (stable because the content string is immutable per render).
        return <span key={i}>{segment}</span>;
      })}
    </>
  );
}

/**
 * Memoized export — the component is pure (same input → same output), so
 * React.memo prevents unnecessary re-renders when the parent re-renders
 * for unrelated reasons (e.g. typing indicator, online status changes).
 *
 * The comparison is a simple reference equality on `content` — if the
 * message content hasn't changed, we skip the re-render. This is correct
 * because the output depends ONLY on `content`.
 */
export const MessageText = memo(MessageTextImpl);
