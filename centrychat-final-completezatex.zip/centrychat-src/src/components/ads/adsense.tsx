"use client";

import { useEffect, useState, useRef, createContext, useContext, useCallback, type ReactNode } from "react";
import { api } from "@/lib/client/api";
import type {
  PublicAdsConfig,
  PublicAdUnit,
  AdPlacement,
} from "@/lib/ads/manager";

/**
 * AdSense client integration
 * ==========================
 *
 * Three exported pieces:
 *
 *   1. <AdSenseScript /> — loads the AdSense library ONCE per page (spec §3 + §4).
 *      Uses next/script semantics: the <script> tag is inserted into <head>
 *      with `async` + `crossOrigin="anonymous"`. The script is only inserted
 *      when AdSense is enabled AND a publisherId is configured.
 *
 *   2. <AdsProvider /> — fetches /api/v1/ads/config ONCE on mount, stores
 *      the result in React context. Every <AdSlot> reads from this context
 *      (no N+1 fetches). Also handles the route-exclusion check.
 *
 *   3. <AdSlot placement="ARTICLE_TOP" /> — the public component used in
 *      page bodies. Reads the config from context, resolves the winning
 *      unit for the placement, lazy-renders the ad tag when it enters
 *      the viewport (IntersectionObserver), reserves space to prevent CLS,
 *      and gracefully degrades when ads are disabled / blocked / failed.
 *
 * SSR + HYDRATION SAFETY (spec §4):
 *   - All AdSense code is client-only ("use client").
 *   - The <script> tag is added via useEffect (not SSR) — the server-rendered
 *     HTML has NO AdSense script tag, so there's no hydration mismatch.
 *   - The <AdSlot>'s reserved space is rendered as an empty <div> with a
 *     min-height on SSR — when the ad loads, it fills the space without
 *     shifting the layout (spec §31 — Core Web Vitals / CLS).
 *
 * AD BLOCK RESILIENCE (spec §29 + §58):
 *   - If the AdSense script fails to load (ad blocker, network error),
 *     the <AdSlot>'s reserved space collapses to 0 height after a 3s
 *     timeout — no permanent empty box.
 *   - The page continues working normally. Ads are OPTIONAL.
 *
 * PERFORMANCE (spec §30):
 *   - The AdSense script uses `strategy="afterInteractive"` (loads after
 *     the page is interactive — doesn't block First Contentful Paint).
 *   - Each <AdSlot> uses IntersectionObserver to defer the actual
 *     `(adsbygoogle = window.adsbygoogle || []).push({})` call until the
 *     slot is near the viewport. Out-of-view slots don't fire ad requests.
 */

// ── Context ──────────────────────────────────────────────────────────────

interface AdsContextValue {
  config: PublicAdsConfig | null;
  loading: boolean;
  /** Counter incremented on each successful ad render — used for maxAdsPerPage + minDistanceSlots checks. */
  renderedCount: number;
  /** Called by <AdSlot> when it actually renders an ad (not when it reserves space). */
  registerRender: () => void;
  /** Whether the current route is excluded. */
  isExcludedRoute: boolean;
}

const AdsContext = createContext<AdsContextValue>({
  config: null,
  loading: true,
  renderedCount: 0,
  registerRender: () => {},
  isExcludedRoute: false,
});

export const useAdsConfig = () => useContext(AdsContext);

// ── Route exclusion check (client-side) ──────────────────────────────────

/**
 * Check whether the current SPA route is in the excludedRoutes list.
 *
 * The excludedRoutes are SPA view query-strings (e.g. "?view=messages") —
 * we match against `window.location.search` (the URLSearchParams). A route
 * matches if ANY of the excluded entries is a substring of the current
 * search string.
 *
 * Example: excludedRoutes=["?view=messages"] + URL is
 * "/?view=messages&conversation=abc" → MATCH → ads forbidden.
 */
function checkExcludedRoute(excludedRoutes: string[]): boolean {
  if (typeof window === "undefined") return false;
  const search = window.location.search.toLowerCase();
  if (!search) return false;
  return excludedRoutes.some((route) => {
    const r = route.toLowerCase();
    // Normalize: the excluded entry might be "/?view=messages" or "?view=messages".
    // We just check if "view=messages" appears in the search string.
    const normalized = r.replace(/^\/?\?/, "");
    return search.includes(normalized);
  });
}

// ── Provider ─────────────────────────────────────────────────────────────

export function AdsProvider({ children }: { children: ReactNode }) {
  const [config, setConfig] = useState<PublicAdsConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [renderedCount, setRenderedCount] = useState(0);
  const [isExcludedRoute, setIsExcludedRoute] = useState(false);

  // Fetch the config ONCE on mount. The /api/v1/ads/config endpoint is
  // unauthenticated + cached server-side (30s settings + 60s units), so
  // this is a cheap call.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await api.get<PublicAdsConfig>("/api/v1/ads/config");
        if (cancelled) return;
        setConfig(data);
        setIsExcludedRoute(checkExcludedRoute(data.excludedRoutes ?? []));
      } catch {
        if (cancelled) return;
        // Failed to load config — assume ads disabled. The page continues.
        setConfig(null);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Re-check excluded route on navigation. The SPA navigates via
  // window.history.pushState — we listen to popstate + a custom event
  // the router dispatches. (Next.js doesn't fire popstate on pushState,
  // but our SPA uses ?view= which DOES update the searchParams + triggers
  // a re-render of the page component.)
  useEffect(() => {
    function onPop() {
      if (config) setIsExcludedRoute(checkExcludedRoute(config.excludedRoutes ?? []));
    }
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, [config]);

  const registerRender = useCallback(() => {
    setRenderedCount((n) => n + 1);
  }, []);

  return (
    <AdsContext.Provider
      value={{ config, loading, renderedCount, registerRender, isExcludedRoute }}
    >
      {children}
    </AdsContext.Provider>
  );
}

// ── AdSense script loader ────────────────────────────────────────────────

/**
 * Renders the AdSense library script tag ONCE per page.
 *
 * Must be rendered INSIDE <AdsProvider> (it reads the config to decide
 * whether to load). Place it in the root layout's <body>.
 *
 * The script is inserted via next/script semantics (we use a manual
 * approach instead of the next/script component because we need
 * conditional loading based on the config — next/script doesn't support
 * that cleanly).
 *
 * The script src is:
 *   https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX
 *
 * We add `async` + `crossOrigin="anonymous"` per Google's official docs.
 */
export function AdSenseScript() {
  const { config, loading } = useAdsConfig();

  useEffect(() => {
    if (loading) return;
    if (!config) return;
    if (!config.enabled) return;
    if (!config.publisherId) return;

    // Avoid double-loading — check if the script already exists.
    const existing = document.getElementById("adsbygoogle-js");
    if (existing) return;

    const script = document.createElement("script");
    script.id = "adsbygoogle-js";
    script.async = true;
    script.crossOrigin = "anonymous";
    script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(config.publisherId)}`;
    // The `data-ad-client` attribute is recommended by Google for some
    // verification flows + matches the script src's client param.
    script.setAttribute("data-ad-client", config.publisherId);

    document.head.appendChild(script);

    return () => {
      // Don't remove the script on unmount — it's a global library
      // that should persist across SPA navigations. Removing it would
      // break already-rendered ads.
    };
  }, [config, loading]);

  return null;
}

// ── AdSlot component ─────────────────────────────────────────────────────

/**
 * <AdSlot placement="ARTICLE_TOP" />
 *
 * The PUBLIC component used in page bodies. Renders nothing when:
 *   - ads are disabled (config.enabled=false)
 *   - publisherId is not configured
 *   - the current route is excluded
 *   - maxAdsPerPage has been reached
 *   - no active unit exists for the placement
 *
 * Otherwise, renders a reserved-space container (prevents CLS) + lazy-loads
 * the actual ad when the container enters the viewport (IntersectionObserver).
 *
 * RESPONSIVE BEHAVIOR (spec §14):
 *   - The container is `width: 100%; min-height: 100px` (mobile) or 120px
 *     (desktop) by default. The AdSense ad fills this space.
 *   - For IN_FEED format, the container has the same padding as a feed card
 *     so the ad blends in visually.
 *   - For IN_ARTICLE format, the container has the article's max-width.
 *
 * AD BLOCK RESILIENCE (spec §29 + §58):
 *   - After 3s, if no ad has filled the container, the reserved space
 *     collapses to 0 height (no permanent empty box).
 *   - The IntersectionObserver is disconnected after the ad renders (no
 *     repeated ad requests on scroll).
 *
 * LABELING (spec §36):
 *   - A small "Advertisement" label is rendered above the ad (text-xs,
 *     uppercase, muted-foreground). This satisfies Google's labeling
 *     requirement without making the ad look like content.
 */
export function AdSlot({
  placement,
  className,
}: {
  placement: AdPlacement;
  className?: string;
}) {
  const { config, loading, renderedCount, registerRender, isExcludedRoute } = useAdsConfig();
  const containerRef = useRef<HTMLDivElement | null>(null);
  const adPushedRef = useRef(false);
  const [adRendered, setAdRendered] = useState(false);
  const [adFailed, setAdFailed] = useState(false);

  // Resolve the winning unit for this placement (client-side).
  const unit: PublicAdUnit | null = config && config.enabled
    ? resolveAdUnitForPlacement(config.activeUnits, placement)
    : null;

  // Decide whether to render at all.
  const shouldRender =
    !loading &&
    !!config &&
    config.enabled &&
    !!config.publisherId &&
    !isExcludedRoute &&
    !!unit &&
    renderedCount < config.maxAdsPerPage;

  // IntersectionObserver — lazy-load the ad when near viewport.
  useEffect(() => {
    if (!shouldRender) return;
    if (!unit) return;
    const el = containerRef.current;
    if (!el) return;

    let observer: IntersectionObserver | null = null;
    let collapseTimer: ReturnType<typeof setTimeout> | null = null;

    observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting && !adPushedRef.current) {
            adPushedRef.current = true;

            // Push the ad to AdSense. The (adsbygoogle = ...) pattern is
            // Google's official lazy-loading approach.
            try {
              const w = window as unknown as { adsbygoogle?: unknown[] };
              w.adsbygoogle = w.adsbygoogle || [];
              (w.adsbygoogle as unknown[]).push({});
              setAdRendered(true);
              registerRender();
            } catch {
              // AdSense not loaded (ad blocker, script error). Collapse.
              setAdFailed(true);
            }

            // Collapse the reserved space if no ad fills it within 3s.
            collapseTimer = setTimeout(() => {
              if (!adRendered) setAdFailed(true);
            }, 3000);
          }
        }
      },
      { rootMargin: "200px", threshold: 0 }
    );

    observer.observe(el);

    return () => {
      observer?.disconnect();
      if (collapseTimer) clearTimeout(collapseTimer);
    };
  }, [shouldRender, unit, adRendered, registerRender]);

  if (!shouldRender) return null;

  // Format-specific container styles (spec §14 + §31 — prevent CLS).
  const containerClass =
    unit?.format === "IN_FEED"
      ? "w-full min-h-[120px] py-2"
      : unit?.format === "IN_ARTICLE"
      ? "mx-auto w-full max-w-[728px] min-h-[120px] py-4"
      : unit?.format === "DISPLAY"
      ? "mx-auto flex min-h-[90px] items-center justify-center py-2"
      : "w-full min-h-[100px] py-2"; // RESPONSIVE default

  // When ad failed to render (ad blocker, no fill, etc.), collapse the
  // reserved space — no permanent empty box.
  if (adFailed) return null;

  return (
    <div
      className={`${containerClass} ${className ?? ""}`}
      ref={containerRef}
      // The data-ad-slot + data-ad-format + data-ad-layout attributes are
      // the OFFICIAL AdSense ad tag attributes (per Google's docs).
      // The `style="display:block"` is required by AdSense for responsive ads.
    >
      {/* "Advertisement" label — Google requires clear labeling (spec §36) */}
      <div className="mb-1 text-center text-[10px] uppercase tracking-wider text-muted-foreground/60">
        Advertisement
      </div>
      <ins
        className="adsbygoogle block min-h-[100px]"
        style={{ display: "block", width: "100%" }}
        data-ad-client={config?.publisherId}
        data-ad-slot={unit?.slotId}
        data-ad-format={unit?.format === "IN_ARTICLE" ? "fluid" : "auto"}
        data-ad-layout={unit?.format === "IN_FEED" ? "in-feed" : undefined}
        data-full-width-responsive={unit?.format === "RESPONSIVE" ? "true" : "false"}
      />
    </div>
  );
}

// Helper to resolve the winning unit (moved here for client-side use).
function resolveAdUnitForPlacement(
  units: PublicAdUnit[],
  placement: AdPlacement
): PublicAdUnit | null {
  const matching = units.filter((u) => u.placement === placement);
  if (matching.length === 0) return null;
  matching.sort((a, b) => {
    if (a.priority !== b.priority) return a.priority - b.priority;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
  });
  return matching[0] ?? null;
}
