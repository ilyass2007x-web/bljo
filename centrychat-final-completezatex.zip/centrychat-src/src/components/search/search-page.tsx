"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { PostCard, type PostDTO } from "@/components/posts/post-card";
import { ArticleCard, type ArticleCardDTO } from "@/components/articles/article-card";
import { PlaylistCard } from "@/components/playlists/playlist-card";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import {
  Search as SearchIcon,
  X,
  Loader2,
  Hash,
  TrendingUp,
  Clock,
  UserPlus,
  ArrowLeft,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ── Types ──────────────────────────────────────────────────────────────────

interface UserSuggestion {
  id: string;
  fullName: string;
  username: string;
  avatarColor: string | null;
  avatarUrl: string | null;
  isVerified: boolean;
  rank: number;
}

interface PostSuggestion {
  id: string;
  content: string;
  createdAt: string;
  author: {
    id: string; fullName: string; username: string;
    avatarColor: string | null; avatarUrl: string | null; isVerified: boolean;
  };
  rank: number;
}

interface ArticleSuggestion {
  id: string;
  title: string;
  excerpt: string | null;
  coverImage: string | null;
  publishedAt: string | null;
  author: {
    id: string; fullName: string; username: string;
    avatarColor: string | null; avatarUrl: string | null; isVerified: boolean;
  };
  rank: number;
}

interface TopicSuggestion {
  tag: string;
  count: number;
  rank: number;
}

interface SuggestionsResponse {
  people: UserSuggestion[];
  posts: PostSuggestion[];
  articles: ArticleSuggestion[];
  topics: TopicSuggestion[];
  counts: { people: number; posts: number; articles: number; topics: number };
  rateLimited?: boolean;
}

interface FullSearchResult {
  type: "user" | "post" | "article" | "collection" | "playlist";
  rank: number;
  data: any;
}

interface FullSearchResponse {
  results: FullSearchResult[];
  counts: {
    users: number;
    posts: number;
    articles: number;
    collections?: number;
    playlists?: number;
  };
}

interface SearchHistoryItem {
  id: string;
  query: string;
  targetUserId: string | null;
  targetUsername: string | null;
  targetFullName: string | null;
  createdAt: string;
}

type Tab = "all" | "people" | "posts" | "articles" | "playlists" | "topics";

// ── Component ──────────────────────────────────────────────────────────────

/**
 * SearchPage — the dedicated Smart Global Search SPA view.
 *
 * URL: /?view=search&q=<query>&tab=<tab>
 *
 * Layout (spec §1, §27, §28):
 *   - Top: large clean search input + clear button + search icon.
 *   - Below: live suggestions (debounced 250-300ms) grouped by category:
 *       People / Posts / Articles / Topics
 *   - After Enter: full search results page with tabs:
 *       All / People / Posts / Articles / Topics
 *   - Empty search state (spec §30): recent searches + suggested users.
 *   - Mobile: full-width. Desktop: centered max-w-2xl.
 *
 * Behavior (spec §3, §4, §5):
 *   - Live suggestions appear IMMEDIATELY as the user types (debounced).
 *   - Stale requests are cancelled via AbortController (no overwrite).
 *   - Only categories with results are shown.
 *   - Clicking a suggestion navigates to the right page.
 */
export function SearchPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { t } = useTranslation();
  const { user } = useAuthStore();

  // ── URL state ───────────────────────────────────────────────────────
  // The query + active tab are reflected in the URL so the user can
  // refresh/share/use the back button (spec §26).
  const initialQ = searchParams.get("q") ?? "";
  const initialTab = (searchParams.get("tab") as Tab) ?? "all";

  const [query, setQuery] = useState(initialQ);
  const [activeTab, setActiveTab] = useState<Tab>(initialTab);
  const [inputValue, setInputValue] = useState(initialQ);

  // ── Suggestions state (live, debounced) ────────────────────────────
  const [suggestions, setSuggestions] = useState<SuggestionsResponse | null>(null);
  const [suggestionsLoading, setSuggestionsLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // ── Full search state (after Enter) ────────────────────────────────
  const [fullResults, setFullResults] = useState<FullSearchResult[]>([]);
  const [fullLoading, setFullLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  // ── Search history ─────────────────────────────────────────────────
  const [history, setHistory] = useState<SearchHistoryItem[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // ── Trending suggestions (when search is empty) ───────────────────
  const [trendingTopics, setTrendingTopics] = useState<TopicSuggestion[]>([]);
  const [suggestedUsers, setSuggestedUsers] = useState<UserSuggestion[]>([]);

  // ── Debounce + AbortController for stale-request cancellation ──────
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  // ── Live suggestions fetch (debounced) ─────────────────────────────
  const fetchSuggestions = useCallback((q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (abortRef.current) abortRef.current.abort();

    if (q.trim().length < 2) {
      setSuggestions(null);
      setSuggestionsLoading(false);
      setShowSuggestions(false);
      return;
    }

    setSuggestionsLoading(true);
    setShowSuggestions(true);

    debounceRef.current = setTimeout(async () => {
      const controller = new AbortController();
      abortRef.current = controller;
      try {
        const data = await api.get<SuggestionsResponse>(
          `/api/v1/search/suggest?q=${encodeURIComponent(q.trim())}`,
          { signal: controller.signal }
        );
        // Check if this request is still the latest (not stale).
        if (!controller.signal.aborted) {
          setSuggestions(data);
          setSuggestionsLoading(false);
        }
      } catch (e) {
        if (e instanceof ApiClientError && e.message === "The user aborted a request") return;
        if (!controller.signal.aborted) {
          setSuggestions(null);
          setSuggestionsLoading(false);
        }
      }
    }, 280); // 280ms debounce (spec §4: 250-350ms)
  }, []);

  // ── Full search (after Enter or tab change) ────────────────────────
  const fetchFullResults = useCallback(async (q: string, tab: Tab) => {
    if (q.trim().length < 2) {
      setFullResults([]);
      setHasSearched(false);
      return;
    }
    setFullLoading(true);
    setHasSearched(true);
    try {
      const data = await api.get<FullSearchResponse>(
        `/api/v1/search/all?q=${encodeURIComponent(q.trim())}&limit=50`
      );
      setFullResults(data.results);
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Search failed";
      toast.error(msg);
      setFullResults([]);
    } finally {
      setFullLoading(false);
    }
  }, []);

  // ── Search history + trending (loaded on mount) ────────────────────
  useEffect(() => {
    void (async () => {
      setHistoryLoading(true);
      try {
        const [histRes] = await Promise.all([
          api.get<{ history: SearchHistoryItem[] }>("/api/v1/search-history").catch(() => ({ history: [] as SearchHistoryItem[] })),
        ]);
        setHistory(histRes.history);
      } finally {
        setHistoryLoading(false);
      }
    })();
  }, []);

  // ── Trending topics + suggested users (loaded when input is empty) ──
  useEffect(() => {
    if (query.trim().length > 0) return;
    void (async () => {
      try {
        // Trending: fetch trending feed (from the previous task).
        const trending = await api.get<{ items: any[] }>(
          "/api/v1/feed/trending?limit=20"
        ).catch(() => ({ items: [] as any[] }));

        // Extract hashtags from trending posts/articles.
        const topicCounts = new Map<string, number>();
        for (const item of trending.items) {
          const text = item.type === "post" ? item.post?.content : item.article?.title + " " + (item.article?.excerpt ?? "");
          if (!text) continue;
          // Simple hashtag extraction.
          const matches = text.match(/#[\p{L}\p{N}_]{1,64}/giu) ?? [];
          for (const m of matches) {
            const tag = m.slice(1).toLowerCase();
            topicCounts.set(tag, (topicCounts.get(tag) ?? 0) + 1);
          }
        }
        const topics: TopicSuggestion[] = Array.from(topicCounts.entries())
          .map(([tag, count]) => ({ tag, count, rank: 0 }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 8);
        setTrendingTopics(topics);

        // Suggested users (top 5 by activity).
        const suggested = await api.get<{ users: any[] }>(
          "/api/v1/users/suggested?limit=5"
        ).catch(() => ({ users: [] as any[] }));
        setSuggestedUsers(
          suggested.users.map((u) => ({
            id: u.id,
            fullName: u.fullName,
            username: u.username,
            avatarColor: u.avatarColor,
            avatarUrl: u.avatarUrl,
            isVerified: u.isVerified,
            rank: 0,
          }))
        );
      } catch {
        // Non-fatal.
      }
    })();
  }, [query]);

  // ── Initial URL-driven search (on mount or URL change) ─────────────
  useEffect(() => {
    if (initialQ.trim().length >= 2) {
      setQuery(initialQ);
      setInputValue(initialQ);
      setActiveTab(initialTab);
      setHasSearched(true);
      void fetchFullResults(initialQ, initialTab);
    }
  }, [initialQ, initialTab, fetchFullResults]);

  // ── Input change handler (debounced live suggestions) ──────────────
  function handleInputChange(value: string) {
    setInputValue(value);
    setQuery(value);
    fetchSuggestions(value);

    // Update the URL without triggering a re-fetch (just for shareability).
    if (value.trim().length >= 2) {
      const params = new URLSearchParams(searchParams.toString());
      params.set("view", "search");
      params.set("q", value.trim());
      if (activeTab !== "all") params.set("tab", activeTab);
      else params.delete("tab");
      window.history.replaceState(null, "", `/?${params.toString()}`);
    }
  }

  // ── Submit handler (Enter or search icon click) ────────────────────
  function handleSubmit(e?: React.FormEvent) {
    e?.preventDefault();
    if (query.trim().length < 2) return;
    setShowSuggestions(false);
    setHasSearched(true);
    void fetchFullResults(query, activeTab);

    // Update the URL.
    const params = new URLSearchParams();
    params.set("view", "search");
    params.set("q", query.trim());
    if (activeTab !== "all") params.set("tab", activeTab);
    router.push(`/?${params.toString()}`);

    // Save to search history (best-effort).
    void api.post("/api/v1/search-history", { query: query.trim() }).catch(() => {});
  }

  // ── Tab change handler ─────────────────────────────────────────────
  function handleTabChange(tab: Tab) {
    setActiveTab(tab);
    if (hasSearched) {
      const params = new URLSearchParams();
      params.set("view", "search");
      params.set("q", query.trim());
      if (tab !== "all") params.set("tab", tab);
      router.push(`/?${params.toString()}`);
    }
  }

  // ── Clear search ───────────────────────────────────────────────────
  function handleClear() {
    setInputValue("");
    setQuery("");
    setSuggestions(null);
    setShowSuggestions(false);
    setFullResults([]);
    setHasSearched(false);
    router.push("/?view=search");
  }

  // ── Clear all history ──────────────────────────────────────────────
  async function handleClearHistory() {
    try {
      await api.delete("/api/v1/search-history");
      setHistory([]);
      toast.success("Search history cleared");
    } catch {
      toast.error("Failed to clear history");
    }
  }

  async function handleRemoveHistoryItem(id: string) {
    try {
      await api.delete(`/api/v1/search-history/${id}`);
      setHistory((prev) => prev.filter((h) => h.id !== id));
    } catch {
      // Non-fatal.
    }
  }

  // ── Filtered results based on active tab ───────────────────────────
  const filteredResults = fullResults.filter((r) => {
    if (activeTab === "all") return true;
    if (activeTab === "people") return r.type === "user";
    if (activeTab === "posts") return r.type === "post";
    if (activeTab === "articles") return r.type === "article";
    if (activeTab === "playlists") return r.type === "playlist";
    if (activeTab === "topics") return false; // topics use a different UI
    return true;
  });

  const hasAnySuggestions =
    !!suggestions &&
    (suggestions.people.length > 0 ||
      suggestions.posts.length > 0 ||
      suggestions.articles.length > 0 ||
      suggestions.topics.length > 0);

  // ── Empty search state ──────────────────────────────────────────────
  const showEmptyState = query.trim().length === 0;

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.push("/")} title="Back">
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <p className="text-sm font-medium">Search</p>
      </header>

      <div className="mx-auto max-w-2xl px-4 py-6 md:py-10">
        {/* Search bar */}
        <form onSubmit={handleSubmit} className="relative">
          <SearchIcon className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            value={inputValue}
            onChange={(e) => handleInputChange(e.target.value)}
            placeholder="Search people, posts, articles, topics..."
            className="h-12 pl-11 pr-10 text-base"
            autoFocus
            aria-label="Search"
            enterKeyHint="search"
          />
          {inputValue && (
            <button
              type="button"
              onClick={handleClear}
              aria-label="Clear search"
              className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground hover:bg-accent hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </form>

        {/* ── Empty search state ────────────────────────────────────── */}
        {showEmptyState && (
          <div className="mt-6 space-y-8">
            {/* Recent searches */}
            {history.length > 0 && (
              <section>
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    Recent searches
                  </h2>
                  <Button variant="ghost" size="sm" onClick={handleClearHistory} className="h-7 text-xs">
                    Clear all
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {history.map((h) => (
                    <div
                      key={h.id}
                      className="group flex items-center gap-1 rounded-full border bg-background px-3 py-1.5 text-sm hover:bg-accent"
                    >
                      <button
                        onClick={() => {
                          setInputValue(h.query);
                          setQuery(h.query);
                          void fetchFullResults(h.query, "all");
                          setHasSearched(true);
                          setShowSuggestions(false);
                          router.push(`/?view=search&q=${encodeURIComponent(h.query)}`);
                        }}
                        className="truncate"
                      >
                        {h.query}
                      </button>
                      <button
                        onClick={() => handleRemoveHistoryItem(h.id)}
                        aria-label="Remove"
                        className="text-muted-foreground hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Trending topics */}
            {trendingTopics.length > 0 && (
              <section>
                <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-muted-foreground">
                  <TrendingUp className="h-4 w-4" />
                  Trending topics
                </h2>
                <div className="flex flex-wrap gap-2">
                  {trendingTopics.map((topic) => (
                    <button
                      key={topic.tag}
                      onClick={() => router.push(`/topics/${encodeURIComponent(topic.tag)}`)}
                      className="rounded-full border bg-background px-3 py-1.5 text-sm font-medium text-primary hover:bg-accent"
                    >
                      #{topic.tag}
                    </button>
                  ))}
                </div>
              </section>
            )}

            {/* Suggested users */}
            {suggestedUsers.length > 0 && (
              <section>
                <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-muted-foreground">
                  <UserPlus className="h-4 w-4" />
                  People to follow
                </h2>
                <div className="space-y-1">
                  {suggestedUsers.map((u) => (
                    <button
                      key={u.id}
                      onClick={() => router.push(`/?view=profile&username=${encodeURIComponent(u.username)}`)}
                      className="flex w-full items-center gap-3 rounded-lg p-2 text-left hover:bg-accent"
                    >
                      <Avatar
                        name={u.fullName}
                        color={u.avatarColor}
                        src={u.avatarUrl}
                        size="sm"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="flex items-center gap-1 truncate text-sm font-medium" dir="auto">
                          {u.fullName}
                          {u.isVerified && <VerifiedBadge size={12} />}
                        </p>
                        <p className="truncate text-xs text-muted-foreground">@{u.username}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </section>
            )}

            {/* No data at all */}
            {history.length === 0 && trendingTopics.length === 0 && suggestedUsers.length === 0 && !historyLoading && (
              <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                  <SearchIcon className="h-7 w-7 text-muted-foreground" />
                </div>
                <p className="text-base font-semibold">Start searching</p>
                <p className="max-w-sm text-sm text-muted-foreground">
                  Search for people, posts, articles, or topics. Start typing to see live suggestions.
                </p>
              </div>
            )}
          </div>
        )}

        {/* ── Live suggestions (while typing, before Enter) ─────────── */}
        {!showEmptyState && showSuggestions && !hasSearched && (
          <div className="mt-3 space-y-4">
            {suggestionsLoading && (
              <div className="space-y-2">
                <Skeleton className="h-12 w-full rounded-lg" />
                <Skeleton className="h-12 w-full rounded-lg" />
                <Skeleton className="h-12 w-full rounded-lg" />
              </div>
            )}

            {!suggestionsLoading && !hasAnySuggestions && query.trim().length >= 2 && (
              <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                  <SearchIcon className="h-7 w-7 text-muted-foreground" />
                </div>
                <p className="text-sm font-medium">No suggestions for &ldquo;{query}&rdquo;</p>
                <p className="max-w-sm text-xs text-muted-foreground">
                  Press Enter to see full results.
                </p>
              </div>
            )}

            {!suggestionsLoading && hasAnySuggestions && (
              <>
                {/* People */}
                {suggestions!.people.length > 0 && (
                  <SuggestionSection title="People" icon={<UserPlus className="h-4 w-4" />}>
                    {suggestions!.people.map((u) => (
                      <SuggestionRow
                        key={u.id}
                        onClick={() => router.push(`/?view=profile&username=${encodeURIComponent(u.username)}`)}
                      >
                        <Avatar name={u.fullName} color={u.avatarColor} src={u.avatarUrl} size="sm" />
                        <div className="min-w-0 flex-1">
                          <p className="flex items-center gap-1 truncate text-sm font-medium" dir="auto">
                            {u.fullName}
                            {u.isVerified && <VerifiedBadge size={12} />}
                          </p>
                          <p className="truncate text-xs text-muted-foreground">@{u.username}</p>
                        </div>
                      </SuggestionRow>
                    ))}
                  </SuggestionSection>
                )}

                {/* Posts */}
                {suggestions!.posts.length > 0 && (
                  <SuggestionSection title="Posts" icon={<SearchIcon className="h-4 w-4" />}>
                    {suggestions!.posts.map((p) => (
                      <SuggestionRow
                        key={p.id}
                        onClick={() => router.push(`/?view=comments&postId=${p.id}`)}
                      >
                        <Avatar name={p.author.fullName} color={p.author.avatarColor} src={p.author.avatarUrl} size="sm" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm" dir="auto">{p.content}</p>
                          <p className="truncate text-xs text-muted-foreground">@{p.author.username}</p>
                        </div>
                      </SuggestionRow>
                    ))}
                  </SuggestionSection>
                )}

                {/* Articles */}
                {suggestions!.articles.length > 0 && (
                  <SuggestionSection title="Articles" icon={<SearchIcon className="h-4 w-4" />}>
                    {suggestions!.articles.map((a) => (
                      <SuggestionRow
                        key={a.id}
                        onClick={() => router.push(`/articles/${a.id}`)}
                      >
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded bg-muted">
                          {a.coverImage ? (
                            <img src={a.coverImage} alt="" className="h-full w-full rounded object-cover" loading="lazy" />
                          ) : (
                            <SearchIcon className="h-4 w-4 text-muted-foreground" />
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium" dir="auto">{a.title}</p>
                          {a.excerpt && (
                            <p className="truncate text-xs text-muted-foreground" dir="auto">{a.excerpt}</p>
                          )}
                        </div>
                      </SuggestionRow>
                    ))}
                  </SuggestionSection>
                )}

                {/* Topics */}
                {suggestions!.topics.length > 0 && (
                  <SuggestionSection title="Topics" icon={<Hash className="h-4 w-4" />}>
                    {suggestions!.topics.map((topic) => (
                      <SuggestionRow
                        key={topic.tag}
                        onClick={() => router.push(`/topics/${encodeURIComponent(topic.tag)}`)}
                      >
                        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                          <Hash className="h-4 w-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium">#{topic.tag}</p>
                          <p className="text-xs text-muted-foreground">
                            {topic.count} {topic.count === 1 ? "post" : "posts"}
                          </p>
                        </div>
                      </SuggestionRow>
                    ))}
                  </SuggestionSection>
                )}

                <div className="flex justify-center pt-2">
                  <Button variant="outline" size="sm" onClick={() => handleSubmit()}>
                    See all results for &ldquo;{query}&rdquo;
                    <span className="ml-1 text-xs text-muted-foreground">↵</span>
                  </Button>
                </div>
              </>
            )}
          </div>
        )}

        {/* ── Full search results (after Enter) ──────────────────────── */}
        {hasSearched && !showSuggestions && (
          <div className="mt-4">
            {/* Tabs */}
            <div className="sticky top-14 z-10 -mx-4 mb-4 flex gap-1 overflow-x-auto border-b bg-background/80 px-4 backdrop-blur md:top-0">
              {(["all", "people", "posts", "articles", "playlists", "topics"] as Tab[]).map((tab) => (
                <button
                  key={tab}
                  onClick={() => handleTabChange(tab)}
                  className={cn(
                    "shrink-0 border-b-2 px-3 py-2.5 text-sm font-medium capitalize transition-colors",
                    activeTab === tab
                      ? "border-primary text-primary"
                      : "border-transparent text-muted-foreground hover:text-foreground"
                  )}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* Topics tab — shows hashtags derived from the query */}
            {activeTab === "topics" && (
              <div className="space-y-2">
                {query.trim().length >= 2 ? (
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => router.push(`/topics/${encodeURIComponent(query.replace(/^#/, "").trim())}`)}
                      className="rounded-full border bg-background px-4 py-2 text-sm font-medium text-primary hover:bg-accent"
                    >
                      #{query.replace(/^#/, "").trim()}
                    </button>
                    {suggestions?.topics.map((topic) => (
                      <button
                        key={topic.tag}
                        onClick={() => router.push(`/topics/${encodeURIComponent(topic.tag)}`)}
                        className="rounded-full border bg-background px-4 py-2 text-sm font-medium hover:bg-accent"
                      >
                        #{topic.tag} <span className="text-xs text-muted-foreground">({topic.count})</span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="py-8 text-center text-sm text-muted-foreground">
                    Type a topic name to explore.
                  </p>
                )}
              </div>
            )}

            {/* Other tabs — list results */}
            {activeTab !== "topics" && (
              <>
                {fullLoading ? (
                  <div className="space-y-2">
                    {[0, 1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-16 w-full rounded-lg" />
                    ))}
                  </div>
                ) : filteredResults.length === 0 ? (
                  <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
                    <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                      <SearchIcon className="h-7 w-7 text-muted-foreground" />
                    </div>
                    <p className="text-sm font-medium">No results found for &ldquo;{query}&rdquo;</p>
                    <p className="max-w-sm text-xs text-muted-foreground">
                      Try different keywords or check your spelling.
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-border/60">
                    {filteredResults.map((r) => {
                      if (r.type === "user") {
                        const u = r.data;
                        return (
                          <button
                            key={`u-${u.id}`}
                            onClick={() => router.push(`/?view=profile&username=${encodeURIComponent(u.username)}`)}
                            className="flex w-full items-center gap-3 p-4 text-left hover:bg-accent/5"
                          >
                            <Avatar name={u.fullName} color={u.avatarColor} src={u.avatarUrl} size="md" />
                            <div className="min-w-0 flex-1">
                              <p className="flex items-center gap-1 truncate text-sm font-semibold" dir="auto">
                                {u.fullName}
                                {u.isVerified && <VerifiedBadge size={14} />}
                              </p>
                              <p className="truncate text-xs text-muted-foreground">@{u.username}</p>
                            </div>
                          </button>
                        );
                      }
                      if (r.type === "post") {
                        return (
                          <PostCard
                            key={`p-${r.data.id}`}
                            post={r.data as PostDTO}
                          />
                        );
                      }
                      if (r.type === "playlist") {
                        // Render the playlist card. Per spec §6: playlists
                        // are integrated with search but DO NOT MIX with
                        // Post Topics — they're a separate `type: "playlist"`
                        // result.
                        return (
                          <PlaylistCard
                            key={`pl-${r.data.id}`}
                            playlist={r.data}
                            showOwner
                          />
                        );
                      }
                      // article
                      return (
                        <ArticleCard
                          key={`a-${r.data.id}`}
                          article={r.data as ArticleCardDTO}
                        />
                      );
                    })}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Sub-components for the suggestions section ─────────────────────────────

function SuggestionSection({
  title,
  icon,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section>
      <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {icon}
        {title}
      </h3>
      <div className="space-y-1">{children}</div>
    </section>
  );
}

function SuggestionRow({
  onClick,
  children,
}: {
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-accent"
    >
      {children}
    </button>
  );
}
