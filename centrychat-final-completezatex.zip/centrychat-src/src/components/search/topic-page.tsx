"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { PostCard, type PostDTO } from "@/components/posts/post-card";
import { ArticleCard, type ArticleCardDTO } from "@/components/articles/article-card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Hash, Loader2 } from "lucide-react";
import { useTranslation } from "@/lib/client/i18n-store";

type UnifiedFeedItem =
  | { type: "post"; post: PostDTO }
  | { type: "article"; article: ArticleCardDTO };

interface TopicPageProps {
  tag: string;
  initialItems: UnifiedFeedItem[];
  initialNextCursor: string | null;
}

/**
 * TopicPage — public, SEO-friendly topic page. Renders the initial
 * server-rendered items + fetches more via cursor pagination when the
 * user scrolls.
 *
 * URL: /topics/<tag> (e.g. /topics/football)
 *
 * The tag is shown as a header (`#football`) + the posts/articles that
 * contain the hashtag are listed chronologically (newest first).
 */
export function TopicPage({ tag, initialItems, initialNextCursor }: TopicPageProps) {
  const router = useRouter();
  const { t } = useTranslation();
  const [items, setItems] = useState<UnifiedFeedItem[]>(initialItems);
  const [nextCursor, setNextCursor] = useState<string | null>(initialNextCursor);
  const [loadingMore, setLoadingMore] = useState(false);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  const loadMore = useCallback(async () => {
    if (!nextCursor || loadingMore) return;
    setLoadingMore(true);
    try {
      const data = await fetch(
        `/api/v1/search/topic/${encodeURIComponent(tag)}?limit=20&cursor=${encodeURIComponent(nextCursor)}`,
        { credentials: "include" }
      ).then((r) => r.json());
      if (data?.data) {
        setItems((prev) => [...prev, ...data.data.items]);
        setNextCursor(data.data.nextCursor);
      }
    } catch {
      // Non-fatal — user can retry by scrolling.
    } finally {
      setLoadingMore(false);
    }
  }, [nextCursor, loadingMore, tag]);

  useEffect(() => {
    if (!nextCursor || loadingMore) return;
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) void loadMore();
      },
      { rootMargin: "300px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [nextCursor, loadingMore, loadMore]);

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()} title="Back">
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <p className="truncate text-sm font-medium">#{tag}</p>
      </header>

      <div className="mx-auto max-w-2xl px-4 py-6 md:py-10">
        {/* Desktop back */}
        <Button variant="ghost" onClick={() => router.back()} className="mb-4 hidden md:flex">
          <ArrowLeft className="mr-2 h-4 w-4 rtl-flip" /> Back
        </Button>

        {/* Topic header */}
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Hash className="h-7 w-7" />
          </div>
          <div>
            <h1 className="text-2xl font-bold" dir="auto">#{tag}</h1>
            <p className="text-sm text-muted-foreground">
              {items.length === 0
                ? "No posts or articles yet."
                : `${items.length}+ posts and articles about this topic`}
            </p>
          </div>
        </div>

        {/* Items */}
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-3 py-20 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
              <Hash className="h-7 w-7 text-muted-foreground" />
            </div>
            <p className="text-base font-semibold">No posts found</p>
            <p className="max-w-sm text-sm text-muted-foreground">
              No posts or articles have used <span className="font-semibold">#{tag}</span> yet.
              Be the first to post about this topic!
            </p>
            <Button variant="outline" onClick={() => router.push("/?view=article-editor")}>
              Write an Article
            </Button>
          </div>
        ) : (
          <div className="divide-y divide-border/60">
            {items.map((item) =>
              item.type === "post" ? (
                <PostCard key={`post-${item.post.id}`} post={item.post} />
              ) : (
                <ArticleCard key={`article-${item.article.id}`} article={item.article} />
              )
            )}
          </div>
        )}

        {/* Infinite scroll sentinel */}
        {nextCursor && (
          <div ref={sentinelRef} className="flex items-center justify-center py-8">
            <Button variant="ghost" size="sm" onClick={() => loadMore()} disabled={loadingMore}>
              {loadingMore ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null}
              {loadingMore
                ? (t("posts.loadingMore") || "Loading…")
                : (t("posts.loadMore") || "Load more")}
            </Button>
          </div>
        )}

        {/* Skeleton for initial SSR (shown briefly if data is loading) */}
        {items.length === 0 && !nextCursor && (
          <div className="divide-y divide-border/60">
            {[0, 1, 2].map((i) => (
              <div key={i} className="flex gap-3 p-4 md:px-6">
                <Skeleton className="h-10 w-10 shrink-0 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-full" />
                  <Skeleton className="h-3 w-3/4" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
