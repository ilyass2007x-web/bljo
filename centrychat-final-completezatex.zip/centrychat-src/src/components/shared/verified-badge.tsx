"use client";

import { BadgeCheck } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Verified badge — shows a blue checkmark next to a user's name.
 * Only displayed if isVerified is true (database-controlled).
 */
export function VerifiedBadge({ size = 16, className }: { size?: number; className?: string }) {
  return (
    <BadgeCheck
      style={{ width: size, height: size }}
      className={cn("text-blue-500 fill-blue-500/20 shrink-0", className)}
      aria-label="Verified"
    />
  );
}
