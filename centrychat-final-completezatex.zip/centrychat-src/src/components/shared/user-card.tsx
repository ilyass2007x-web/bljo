"use client";

import { useRouter } from "next/navigation";
import { Avatar } from "./avatar";
import { VerifiedBadge } from "./verified-badge";
import { FollowButton } from "./follow-button";
import { cn } from "@/lib/utils";

export interface UserCardData {
  id: string;
  fullName: string;
  username: string;
  avatarColor: string | null;
  avatarUrl?: string | null;
  isVerified: boolean;
  bio?: string | null;
  isFollowing?: boolean;
  isFollowedBy?: boolean;
}

interface UserCardProps {
  user: UserCardData;
  /** Current user ID (to hide follow button for own profile). */
  currentUserId?: string;
  /** Show the follow button (default: true). */
  showFollowButton?: boolean;
  /** Show the bio (default: false). */
  showBio?: boolean;
  /** Layout variant. */
  variant?: "default" | "compact";
  className?: string;
  /** Called when follow state changes (for updating parent lists). */
  onFollowStateChange?: (userId: string, isFollowing: boolean) => void;
}

/**
 * Reusable UserCard — displays a user with avatar, name, username, verified badge,
 * and a FollowButton with correct Follow/Follow Back/Following state.
 *
 * Used in:
 * - Search results
 * - Followers/Following lists
 * - User suggestions
 * - Recommended users
 * - Notifications (where applicable)
 *
 * Clicking the avatar or name navigates to the user's profile.
 */
export function UserCard({
  user,
  currentUserId,
  showFollowButton = true,
  showBio = false,
  variant = "default",
  className,
  onFollowStateChange,
}: UserCardProps) {
  const router = useRouter();
  const isOwnProfile = currentUserId === user.id;

  function navigateToProfile() {
    router.push(`/?view=profile&username=${encodeURIComponent(user.username)}`);
  }

  return (
    <div
      className={cn(
        "flex items-center gap-3 rounded-lg p-2 transition-colors hover:bg-accent",
        variant === "compact" && "p-1.5",
        className
      )}
    >
      {/* Avatar — clickable to profile */}
      <Avatar
        name={user.fullName}
        color={user.avatarColor}
        src={user.avatarUrl}
        size={variant === "compact" ? "sm" : "md"}
        onClick={navigateToProfile}
      />

      {/* Name + username */}
      <div className="min-w-0 flex-1">
        <button
          onClick={navigateToProfile}
          className="flex items-center gap-1 text-sm font-medium hover:underline"
          dir="auto"
        >
          <span className="truncate">{user.fullName}</span>
          {user.isVerified && <VerifiedBadge size={13} />}
        </button>
        <button
          onClick={navigateToProfile}
          className="block w-full truncate text-left text-xs text-muted-foreground hover:underline"
        >
          @{user.username}
        </button>
        {showBio && user.bio && (
          <p className="mt-0.5 truncate text-xs text-muted-foreground" dir="auto">
            {user.bio}
          </p>
        )}
      </div>

      {/* Follow button — uses the reusable FollowButton with auto state detection */}
      {showFollowButton && !isOwnProfile && (
        <FollowButton
          targetUserId={user.id}
          targetUsername={user.username}
          isFollowing={user.isFollowing ?? false}
          isFollowedBy={user.isFollowedBy ?? false}
          size="sm"
          onStateChange={(state) => onFollowStateChange?.(user.id, state.isFollowing)}
        />
      )}
    </div>
  );
}
