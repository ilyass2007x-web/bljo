"use client";

import { getInitials } from "@/lib/avatar";
import { cn } from "@/lib/utils";

interface AvatarProps {
  name: string;
  color?: string | null;
  /** Optional profile picture URL (future: when storage is configured). */
  src?: string | null;
  size?: "sm" | "md" | "lg" | "xl" | "2xl";
  className?: string;
  /** Click handler — when provided, the avatar becomes a button. */
  onClick?: () => void;
  /** Fires when the inner <img> successfully loads. */
  onLoad?: () => void;
  /** Fires when the inner <img> fails to load (broken URL / network error). */
  onError?: () => void;
}

const SIZE_CLASSES = {
  sm: "h-8 w-8 text-xs",
  md: "h-10 w-10 text-sm",
  lg: "h-12 w-12 text-base",
  xl: "h-16 w-16 text-xl",
  "2xl": "h-24 w-24 text-2xl",
};

export function Avatar({
  name,
  color,
  src,
  size = "md",
  className,
  onClick,
  onLoad,
  onError,
}: AvatarProps) {
  const initials = getInitials(name);
  const bg = color ?? "#0f172a";
  const content = src ? (
    <img
      src={src}
      alt={name}
      // Lazy-load avatar images — most avatars are below the fold (post
      // cards, conversation lists, search results). Loading them lazily
      // prevents blocking the initial page render + saves bandwidth on
      // mobile (spec §13 — "images below the viewport should not block
      // initial page rendering").
      loading="lazy"
      // aspect-ratio 1/1 + object-cover (per spec §7) — guarantees the
      // image is never stretched or distorted, regardless of original
      // dimensions. The circular container (rounded-full overflow-hidden)
      // crops the image to a circle cleanly.
      className="h-full w-full rounded-full object-cover"
      draggable={false}
      onLoad={(e) => {
        // Only fire onLoad when the image actually has natural
        // dimensions. A 0×0 natural size means the response was
        // technically "successful" (200 OK) but didn't return a real
        // image (e.g. an HTML error page, a 1×1 tracking pixel, or a
        // corrupted file). In that case, treat it as an error so the
        // parent can fall back to the initials avatar — otherwise the
        // preview would show a blank circle forever.
        const img = e.currentTarget;
        if (img.naturalWidth > 0 && img.naturalHeight > 0) {
          onLoad?.();
        } else {
          // Defer to onError to keep the contract simple (either
          // "loaded with real dimensions" or "failed"). Both callers
          // (EditProfileScreen + AvatarWithLightbox) treat this as
          // the error state.
          onError?.();
        }
      }}
      onError={() => onError?.()}
    />
  ) : (
    <span>{initials}</span>
  );

  const base = (
    <div
      className={cn(
        "flex shrink-0 items-center justify-center overflow-hidden rounded-full font-semibold text-white select-none aspect-square",
        SIZE_CLASSES[size],
        className
      )}
      style={src ? undefined : { backgroundColor: bg }}
      aria-label={name}
    >
      {content}
    </div>
  );

  if (onClick) {
    return (
      <button
        onClick={onClick}
        className="shrink-0 rounded-full transition-opacity hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        aria-label={`View ${name}'s profile`}
      >
        {base}
      </button>
    );
  }
  return base;
}
