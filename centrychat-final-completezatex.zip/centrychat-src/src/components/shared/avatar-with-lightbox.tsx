"use client";

import { useState } from "react";
import { Avatar } from "./avatar";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { X, AlertCircle, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useTranslation } from "@/lib/client/i18n-store";

interface AvatarWithLightboxProps {
  name: string;
  color?: string | null;
  src?: string | null;
  size?: "sm" | "md" | "lg" | "xl" | "2xl";
  /** If provided, clicking opens the lightbox. If null, just a regular avatar. */
  enableLightbox?: boolean;
  /** Optional: navigate to profile on click instead of lightbox. */
  onProfileClick?: () => void;
  /** Optional className applied to the avatar wrapper. */
  className?: string;
}

/**
 * Avatar with optional lightbox viewer (Instagram-style).
 *
 * Behavior priority:
 *   1. If `onProfileClick` is provided → clicking navigates to profile.
 *   2. If `enableLightbox` is true AND `src` exists → clicking opens a
 *      full-size image viewer modal.
 *   3. Otherwise → the avatar is non-interactive.
 *
 * The lightbox:
 *   - Dark, soft overlay background (covers the Profile page beneath).
 *   - Large circular image centered on screen.
 *   - Visible close button (top-right) — accessible + touch-friendly.
 *   - Smooth zoom-in / fade-in open + close animation (handled by Radix Dialog).
 *   - Tap outside / Esc / Back button (browser) → closes.
 *   - Mobile: image scales to fit the viewport — never causes horizontal scroll.
 *   - Desktop: image capped at a reasonable max size (min(85vh, 85vw) for the
 *     inner image; circular so the original aspect ratio doesn't matter —
 *     object-cover handles the cropping inside the circle).
 *   - Broken image → "Image unavailable" placeholder; the dialog can still
 *     be closed.
 *   - Loading state (spinner) shown until the full-size image either loads
 *     or fails.
 *   - Accessible: DialogTitle for screen readers, aria-label on the close
 *     button, role="dialog" semantics provided by Radix Dialog primitive.
 *
 * Performance (spec §13): the full-size image is NOT loaded until the user
 * opens the viewer. The smaller avatar image (passed as `src`) is the only
 * one loaded eagerly on the page. When the viewer opens, the SAME `src`
 * is reused (the browser serves it from cache if cached, or fetches it
 * otherwise — no separate "full-size" URL is requested because the
 * architecture doesn't store a separate high-res variant).
 */
export function AvatarWithLightbox({
  name,
  color,
  src,
  size = "md",
  enableLightbox = false,
  onProfileClick,
  className,
}: AvatarWithLightboxProps) {
  const { t } = useTranslation();
  const [lightboxOpen, setLightboxOpen] = useState(false);

  // If there's a profile click handler, that takes priority — render the
  // avatar as a button that navigates. No lightbox.
  if (onProfileClick) {
    return <Avatar name={name} color={color} src={src} size={size} onClick={onProfileClick} className={className} />;
  }

  // If lightbox is enabled and we have an image, clicking opens the lightbox.
  if (enableLightbox && src) {
    return (
      <>
        <Avatar
          name={name}
          color={color}
          src={src}
          size={size}
          onClick={() => setLightboxOpen(true)}
          className={className}
        />
        <Dialog open={lightboxOpen} onOpenChange={setLightboxOpen}>
          <DialogContent
            showCloseButton={false}
            className="max-w-fit border-0 bg-black/85 p-0 shadow-2xl backdrop-blur-sm sm:rounded-2xl"
            // Disable Radix's default focus-restore behavior interfering with
            // the close button — we provide our own.
            onCloseAutoFocus={(e) => e.preventDefault()}
          >
            {/* Accessible title for screen readers (visually hidden). */}
            <DialogTitle className="sr-only">
              {name}&apos;s {t("profile.profilePicture") || "profile picture"}
            </DialogTitle>
            <DialogDescription className="sr-only">
              {t("profile.profilePictureViewerClose") || "Close"} (Esc)
            </DialogDescription>

            <ProfileImageViewer
              src={src}
              name={name}
              closeLabel={t("profile.profilePictureViewerClose") || "Close"}
              unavailableLabel={t("profile.profilePictureViewerUnavailable") || "Image unavailable"}
              onClose={() => setLightboxOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </>
    );
  }

  // Non-interactive avatar.
  return <Avatar name={name} color={color} src={src} size={size} className={className} />;
}

/**
 * Internal viewer component for the full-size profile image.
 *
 * Handles 3 states:
 *   - loading (spinner)
 *   - loaded (show the image, full circular)
 *   - error (show "Image unavailable")
 *
 * The image element is rendered with `loading="lazy"` would block the
 * image from showing — we want it to load IMMEDIATELY when the viewer
 * opens. So we don't set loading="lazy" here.
 *
 * On mobile, the image is sized via `min(85vh, 85vw)` so it always fits
 * the screen — never causes horizontal scroll.
 */
function ProfileImageViewer({
  src,
  name,
  onClose,
  closeLabel,
  unavailableLabel,
}: {
  src: string;
  name: string;
  onClose: () => void;
  closeLabel: string;
  unavailableLabel: string;
}) {
  // The `src` is fixed during a single open session (the parent passes a
  // stable URL string). Each time the dialog closes + reopens, this
  // component is unmounted + remounted (Radix Dialog renders children only
  // when open) — so the initial "loading" state naturally resets. No
  // useEffect needed.
  const [status, setStatus] = useState<"loading" | "loaded" | "error">("loading");

  return (
    <div className="relative flex flex-col items-center justify-center p-4 sm:p-6">
      {/* Close button — visible on top-right of the modal. Large hit target
          for touch (44px+). Accessible label + keyboard focus ring. */}
      <button
        onClick={onClose}
        aria-label={closeLabel}
        className="absolute top-2 right-2 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-black/60 text-white transition-colors hover:bg-black/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60 focus-visible:ring-offset-2 focus-visible:ring-offset-black/40"
      >
        <X className="h-5 w-5" />
      </button>

      {/* Image container — circular, responsive, with aspect-ratio 1/1
          + object-cover (per spec §7). The `min(85vh, 85vw)` cap ensures
          the image fits both mobile (small viewport) and desktop (large
          viewport) without stretching or scrolling. */}
      <div
        className="relative flex items-center justify-center overflow-hidden rounded-full bg-muted/20"
        style={{
          width: "min(85vh, 85vw)",
          height: "min(85vh, 85vw)",
          aspectRatio: "1 / 1",
        }}
      >
        {status === "loading" && (
          <div className="absolute inset-0 flex items-center justify-center text-white/70">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        )}

        {status === "error" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 px-6 text-center text-white/80">
            <AlertCircle className="h-8 w-8" />
            <p className="text-sm font-medium">{unavailableLabel}</p>
          </div>
        )}

        {status !== "error" && (
          <img
            src={src}
            alt={`${name}'s profile picture`}
            // Load eagerly when the viewer is open — the user is actively
            // waiting to see it. Lazy-loading here would just delay the
            // visible result.
            loading="eager"
            // Hide the image until it loads — we show the spinner underneath.
            className={cn(
              "h-full w-full rounded-full object-cover transition-opacity duration-200",
              status === "loaded" ? "opacity-100" : "opacity-0"
            )}
            onLoad={() => setStatus("loaded")}
            onError={() => setStatus("error")}
            // Block drag-and-drop + context menu (light defense — not a real
            // security boundary, just UX polish).
            draggable={false}
          />
        )}
      </div>

      {/* Caption with the user's name below the image (Instagram-style). */}
      <p className="mt-4 max-w-[85vw] truncate text-center text-sm font-medium text-white/90" dir="auto">
        {name}
      </p>
    </div>
  );
}
