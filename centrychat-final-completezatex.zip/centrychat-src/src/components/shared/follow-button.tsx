"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { UserPlus, UserCheck, Loader2 } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface FollowButtonProps {
  targetUserId: string;
  targetUsername: string;
  isFollowing: boolean;
  isFollowedBy: boolean;
  size?: "sm" | "md" | "lg" | "default" | "icon";
  onStateChange?: (state: { isFollowing: boolean; isFollowedBy: boolean }) => void;
  className?: string;
  showLabel?: boolean;
}

/**
 * Reusable FollowButton — the SINGLE source of truth for follow logic.
 *
 * CROSS-COMPONENT SYNC (spec §10 — "state should also become Following
 * when I open User B's profile"):
 *   When a follow/unfollow action succeeds, the FollowButton dispatches
 *   a `follow:changed` window event. Other FollowButton instances for
 *   the same target user listen for this event and update their state —
 *   so following someone from the Feed immediately updates the Profile
 *   button (if mounted) without requiring a refresh.
 *
 * OPTIMISTIC UI (spec §5 — "immediately update the UI"):
 *   On click, the state flips INSTANTLY. If the API call fails, it
 *   reverts. The old code had a `useEffect` that synced local state
 *   from parent props — which REVERTED the optimistic update after
 *   the loading state cleared (because the parent's props were stale).
 *   The fix: only sync from parent props when the TARGET USER changes
 *   (not on every prop change). After the initial mount, the local
 *   state is the source of truth.
 *
 * States (spec §5):
 *   isFollowing === true                   → "Following"
 *   isFollowing === false && isFollowedBy  → "Follow Back"
 *   isFollowing === false && !isFollowedBy → "Follow"
 *
 * Loading: disabled + spinner, prevents double-clicks (spec §13).
 * Self-follow prevention: returns null if currentUser === target.
 */
export function FollowButton({
  targetUserId,
  targetUsername,
  isFollowing: initialIsFollowing,
  isFollowedBy: initialIsFollowedBy,
  size = "sm",
  onStateChange,
  className,
  showLabel = true,
}: FollowButtonProps) {
  const currentUser = useAuthStore((s) => s.user);
  const [isFollowing, setIsFollowing] = useState(initialIsFollowing);
  const [isFollowedBy, setIsFollowedBy] = useState(initialIsFollowedBy);
  const [loading, setLoading] = useState(false);

  // Track the target user so we can reset state when the button is
  // reused for a different user (e.g., in a list where React recycles
  // components). We use targetUserId (not username) because IDs are
  // immutable + unique — username could change if the user edits it.
  const targetRef = useRef(targetUserId);

  // Only reset local state when the TARGET USER changes — NOT when
  // the parent's isFollowing/isFollowedBy props change.
  //
  // ROOT CAUSE OF PROBLEM 2 (button not updating):
  // The old code had `if (!loading) { setIsFollowing(initialIsFollowing) }`
  // which fired AFTER the API call completed (loading → false). This
  // REVERTED the optimistic update — the button showed "Following"
  // during the request, then snapped back to "Follow" after the
  // loading state cleared, because the parent's props were stale
  // (they reflected the pre-action state).
  //
  // The fix: only sync from parent props when the targetUserId changes.
  // After the initial mount, the local state is the source of truth.
  // Cross-component sync is handled by the `follow:changed` window
  // event (see below).
  useEffect(() => {
    if (targetRef.current !== targetUserId) {
      targetRef.current = targetUserId;
      setIsFollowing(initialIsFollowing);
      setIsFollowedBy(initialIsFollowedBy);
    }
  }, [targetUserId, initialIsFollowing, initialIsFollowedBy]);

  // Cross-component sync: listen for `follow:changed` events from
  // OTHER FollowButton instances. When another FollowButton for the
  // same target user successfully follows/unfollows, this instance
  // updates its state to match — without requiring a page refresh.
  useEffect(() => {
    function onFollowChanged(e: Event) {
      const detail = (e as CustomEvent).detail as {
        targetUserId: string;
        isFollowing: boolean;
        isFollowedBy: boolean;
      };
      if (detail.targetUserId === targetUserId) {
        setIsFollowing(detail.isFollowing);
        setIsFollowedBy(detail.isFollowedBy);
      }
    }
    window.addEventListener("follow:changed", onFollowChanged as EventListener);
    return () => window.removeEventListener("follow:changed", onFollowChanged as EventListener);
  }, [targetUserId]);

  const handleClick = useCallback(async () => {
    if (loading) return; // prevent double-click (spec §13)
    setLoading(true);
    const wasFollowing = isFollowing;

    // Optimistic update — flip immediately.
    const newIsFollowing = !wasFollowing;
    setIsFollowing(newIsFollowing);
    onStateChange?.({ isFollowing: newIsFollowing, isFollowedBy });

    try {
      if (wasFollowing) {
        await api.delete(`/api/v1/users/${targetUsername}/follow`);
      } else {
        await api.post(`/api/v1/users/${targetUsername}/follow`);
      }
      // If we just followed someone who already follows us, they're
      // still following us — keep isFollowedBy = true.
      // If we just unfollowed someone, isFollowedBy doesn't change
      // (their follow relationship to us is independent).
      const newIsFollowedBy = wasFollowing ? isFollowedBy : true;
      setIsFollowedBy(newIsFollowedBy);

      // Broadcast the state change so other FollowButton instances for
      // the same target user update their state without a refresh.
      window.dispatchEvent(new CustomEvent("follow:changed", {
        detail: { targetUserId, isFollowing: newIsFollowing, isFollowedBy: newIsFollowedBy },
      }));
    } catch (err) {
      // Revert on error.
      setIsFollowing(wasFollowing);
      onStateChange?.({ isFollowing: wasFollowing, isFollowedBy });
      toast.error(err instanceof ApiClientError ? err.message : "Failed");
    } finally {
      setLoading(false);
    }
  }, [isFollowing, isFollowedBy, loading, targetUserId, targetUsername, onStateChange]);

  // Self-follow prevention.
  if (currentUser?.id === targetUserId) return null;

  const state = isFollowing ? "following" : isFollowedBy ? "follow_back" : "follow";
  const label = state === "following"
    ? "Following"
    : state === "follow_back"
    ? "Follow Back"
    : "Follow";
  const btnVariant = isFollowing ? "secondary" : "default";

  const Icon = loading
    ? Loader2
    : state === "following"
    ? UserCheck
    : UserPlus;

  const ariaLabel = `${label} @${targetUsername}`;

  return (
    <Button
      onClick={handleClick}
      disabled={loading}
      variant={btnVariant}
      size={size === "md" ? "default" : size}
      className={cn(
        "shrink-0 font-medium min-w-[80px] justify-center",
        isFollowing && "hover:bg-destructive/10 hover:text-destructive",
        className
      )}
      aria-pressed={isFollowing}
      aria-label={ariaLabel}
    >
      <Icon
        className={cn(
          showLabel && "mr-1.5",
          size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4",
          loading && "animate-spin"
        )}
      />
      {showLabel && label}
    </Button>
  );
}
