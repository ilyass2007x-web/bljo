"use client";

import { useEffect, useState } from "react";
import { Loader2, PlayCircle } from "lucide-react";
import { cn } from "@/lib/utils";
// IMPORTANT: import the client-safe constants/types from `./shared`, NOT
// from `@/lib/tutorial-videos` (which imports `db` + PrismaClient at the
// top level). Importing from `@/lib/tutorial-videos` here would pull
// PrismaClient into the browser bundle, throwing the
// "PrismaClient is unable to run in this browser environment" error
// and triggering the global-error.tsx boundary.
import type { TutorialLocation, TutorialVideo } from "@/lib/tutorial-videos/shared";
import { TUTORIAL_LOCATION_META } from "@/lib/tutorial-videos/shared";
import { api } from "@/lib/client/api";

/**
 * TutorialVideoCard — small video preview card shown near the image
 * URL input in the EditProfileScreen / ArticleEditor.
 *
 * Behavior:
 *   - Fetches the tutorial video for the given location from the
 *     PUBLIC endpoint /api/v1/settings/public/tutorial-videos?location=...
 *   - Shows NOTHING when:
 *       * The fetch returns `video: null` (no video configured OR disabled)
 *       * The fetch fails (network error, server down)
 *       * The component is still loading the first time (avoids flicker)
 *   - When a video IS configured + enabled, shows:
 *       * YouTube thumbnail (auto-derived from video ID)
 *       * Card title (per-location, from TUTORIAL_LOCATION_META)
 *       * Click → opens a YouTube embed in a modal-like overlay
 *
 * SECURITY:
 *   - The iframe uses the privacy-enhanced `youtube-nocookie.com` domain
 *     (returned by the resolver helper) + the same sandbox policy as
 *     the existing MediaRenderer embed variant (allow-scripts +
 *     allow-same-origin + allow-presentation + allow-popups + allow-forms;
 *     NOT allow-top-navigation).
 *   - The thumbnail URL is derived from the YouTube video ID — never
 *     user-controlled beyond the admin's YouTube URL input.
 *
 * RESPONSIVE:
 *   - The card is `w-full max-w-md` — fits the article editor + profile
 *     edit forms on both mobile and desktop.
 *   - The thumbnail uses `aspect-video` — same aspect ratio as the
 *     actual YouTube embed, so the layout doesn't shift on click.
 *   - The modal overlay is full-screen with a max-w-3xl video, scrollable
 *     on small screens.
 */
export interface TutorialVideoCardProps {
  /** Which tutorial location to fetch. */
  location: TutorialLocation;
  /** Optional className for the outer container. */
  className?: string;
}

export function TutorialVideoCard({ location, className }: TutorialVideoCardProps) {
  const [video, setVideo] = useState<TutorialVideo | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "hidden">("loading");
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const data = await api.get<{ video: TutorialVideo | null }>(
          `/api/v1/settings/public/tutorial-videos?location=${encodeURIComponent(location)}`
        );
        if (cancelled) return;
        if (data.video) {
          setVideo(data.video);
          setStatus("ready");
        } else {
          // No video configured OR disabled → render nothing.
          setStatus("hidden");
        }
      } catch {
        if (cancelled) return;
        // Network / server error → don't break the editor. Just hide the card.
        setStatus("hidden");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [location]);

  // Loading state: render nothing — we want the card to appear ONLY when
  // a video actually exists. Showing a placeholder would cause layout
  // shift + a flash of "no tutorial" before the fetch resolves.
  if (status === "loading" || status === "hidden" || !video) {
    return null;
  }

  const meta = TUTORIAL_LOCATION_META[location];

  return (
    <>
      {/* The card — clickable to open the embed overlay. */}
      <button
        type="button"
        onClick={() => setPlaying(true)}
        className={cn(
          "group flex w-full max-w-md items-center gap-3 overflow-hidden rounded-xl border bg-card p-2 text-left transition-colors hover:bg-accent/50",
          className
        )}
        aria-label={`Play tutorial: ${meta.cardTitle}`}
      >
        {/* Thumbnail with play overlay. */}
        <div className="relative aspect-video w-28 shrink-0 overflow-hidden rounded-lg bg-muted">
          <img
            src={video.thumbnailUrl}
            alt={meta.cardTitle}
            className="h-full w-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 flex items-center justify-center bg-black/20 transition-opacity group-hover:bg-black/30">
            <PlayCircle className="h-7 w-7 text-white drop-shadow" />
          </div>
        </div>
        {/* Card text. */}
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-medium text-foreground">
            {meta.cardTitle}
          </p>
          <p className="mt-0.5 truncate text-[11px] text-muted-foreground">
            Watch the YouTube tutorial
          </p>
        </div>
      </button>

      {/* Embed overlay — shown when the user clicks the card. */}
      {playing && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setPlaying(false)}
          role="dialog"
          aria-modal="true"
          aria-label={meta.cardTitle}
        >
          <div
            className="relative w-full max-w-3xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative aspect-video w-full overflow-hidden rounded-xl bg-black shadow-2xl">
              <iframe
                src={`${video.embedUrl}?autoplay=1&rel=0`}
                title={meta.cardTitle}
                className="h-full w-full border-0"
                allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; autoplay; fullscreen"
                allowFullScreen
                sandbox="allow-scripts allow-same-origin allow-presentation allow-popups allow-forms"
              />
            </div>
            <button
              type="button"
              onClick={() => setPlaying(false)}
              className="absolute -top-3 -right-3 flex h-8 w-8 items-center justify-center rounded-full bg-background text-foreground shadow-lg ring-1 ring-border hover:bg-accent"
              aria-label="Close tutorial video"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </>
  );
}

/**
 * Convenience wrapper that shows a loading spinner inline while the
 * tutorial is being fetched. Used by callers that want a placeholder
 * instead of a blank space during the initial load.
 */
export function TutorialVideoCardWithPlaceholder(props: TutorialVideoCardProps) {
  return (
    <div className="relative">
      <TutorialVideoCard {...props} />
    </div>
  );
}

// Re-export Loader2 so callers don't need to import it separately.
export { Loader2 };
