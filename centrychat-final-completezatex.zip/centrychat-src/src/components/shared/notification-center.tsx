"use client";

import { Button } from "@/components/ui/button";
import { Bell } from "lucide-react";
import { useTranslation } from "@/lib/client/i18n-store";
import { useNotifications } from "@/hooks/use-notifications";
import { useRealtime } from "@/hooks/use-realtime";
import { useRouter } from "next/navigation";
import { useEffect, useRef } from "react";

interface NotificationCenterProps {
  /** Whether realtime is enabled (user is authenticated). */
  enabled: boolean;
  /** Reserved — kept for backward compatibility with existing call sites.
   *  Navigation is now handled internally (always routes to /?view=notifications). */
  onNavigate?: (target: { targetType?: string | null; targetId?: string | null; conversationId?: string | null; messageId?: string | null }) => void;
  /** Reserved — kept for backward compatibility. Toasts are no longer triggered
   *  from here; the bell badge updates in real time and the user opens the
   *  full Notifications page to see new items. */
  onNewNotification?: (n: { id: string; type: string; title: string; message: string }) => void;
}

/**
 * NotificationCenter — a bell + unread-count badge button.
 *
 * Clicking it opens the dedicated full-screen Notifications page
 * (`/?view=notifications`). Per spec, notifications are NO LONGER shown as
 * a small dropdown / floating popup.
 *
 * The unread badge is kept in sync via:
 *  - Initial fetch from `/api/v1/notifications`
 *  - Realtime `notification:new` socket.io events
 *  - Multi-tab BroadcastChannel (see useNotifications)
 *
 * The old popover UI is intentionally removed; this component now exists solely
 * to render the bell icon and badge in the navigation bars.
 */
export function NotificationCenter({ enabled, onNavigate, onNewNotification }: NotificationCenterProps) {
  const router = useRouter();
  const { t } = useTranslation();
  const { unreadCount, addNotification, refresh } = useNotifications(enabled);

  // Realtime: bump the badge when a new notification arrives.
  const onNewNotificationRef = useRef(onNewNotification);
  useEffect(() => { onNewNotificationRef.current = onNewNotification; });

  useRealtime(enabled, {
    "notification:new": (payload) => {
      const n = payload as { id?: string; type?: string; title?: string; message?: string } | undefined;
      // Skip MESSAGE-type notifications — messages have their own badge
      // (Messages unread count, tracked via conversation unreadCount in
      // main-nav.tsx). Including MESSAGE-type here would double-count:
      // the user would see the same unread message bump BOTH the Messages
      // badge AND the Notifications badge. Per spec §2: new messages
      // must NOT create a notification in the general Notifications system.
      if (!n?.id || n.type === "MESSAGE") return;
      addNotification({
        id: n.id,
        type: n.type ?? "SYSTEM",
        title: n.title ?? "",
        message: n.message ?? "",
        read: false,
        readAt: null,
        targetType: null,
        targetId: null,
        conversationId: null,
        messageId: null,
        senderId: null,
        metadata: null,
        createdAt: new Date().toISOString(),
      });
      onNewNotificationRef.current?.({
        id: n.id,
        type: n.type ?? "SYSTEM",
        title: n.title ?? "",
        message: n.message ?? "",
      });
    },
  });

  // Sync missed notifications when the tab regains focus.
  useEffect(() => {
    if (!enabled) return;
    const onFocus = () => void refresh();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [enabled, refresh]);

  // `onNavigate` is intentionally unused — the page handles its own routing.
  void onNavigate;

  const badge = unreadCount > 0 ? (unreadCount > 99 ? "99+" : String(unreadCount)) : null;

  return (
    <Button
      variant="ghost"
      size="icon"
      className="relative"
      title={t("notifications.title")}
      aria-label={t("notifications.title")}
      onClick={() => router.push("/?view=notifications")}
    >
      <Bell className="h-5 w-5" />
      {badge && (
        <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
          {badge}
        </span>
      )}
    </Button>
  );
}
