"use client";

import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Check, Globe } from "lucide-react";
import { SUPPORTED_LANGUAGES } from "@/lib/i18n";
import { useLanguage } from "@/lib/client/i18n-store";
import { cn } from "@/lib/utils";

interface LanguageSelectorProps {
  value: string;
  onChange: (lang: string) => void;
  className?: string;
}

/**
 * Accessible language selector.
 * - Uses radio group semantics for screen readers.
 * - Shows native language names (English, العربية, Français).
 * - Keyboard navigable (arrow keys via Radix RadioGroup).
 * - Clear focus states.
 */
export function LanguageSelector({ value, onChange, className }: LanguageSelectorProps) {
  return (
    <RadioGroup
      value={value}
      onValueChange={onChange}
      className={cn("grid gap-2 sm:grid-cols-3", className)}
      aria-label="Select language"
    >
      {SUPPORTED_LANGUAGES.map((lang) => (
        <label
          key={lang.code}
          htmlFor={`lang-${lang.code}`}
          className={cn(
            "flex cursor-pointer items-center gap-3 rounded-lg border p-3 transition-colors hover:bg-accent",
            value === lang.code ? "border-primary bg-accent" : "border-border"
          )}
        >
          <RadioGroupItem
            id={`lang-${lang.code}`}
            value={lang.code}
            className="sr-only"
          />
          <div className="flex h-5 w-5 items-center justify-center">
            {value === lang.code ? (
              <Check className="h-5 w-5 text-primary" />
            ) : (
              <Globe className="h-5 w-5 text-muted-foreground" />
            )}
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-medium" dir="auto">
              {lang.nativeName}
            </span>
            <span className="text-xs text-muted-foreground">{lang.englishName}</span>
          </div>
        </label>
      ))}
    </RadioGroup>
  );
}

/** Re-export for convenience. */
export { useLanguage };
