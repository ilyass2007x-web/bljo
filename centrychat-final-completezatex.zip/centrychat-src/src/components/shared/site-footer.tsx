"use client";

import { useRouter } from "next/navigation";
import { useTranslation } from "@/lib/client/i18n-store";
import { cn } from "@/lib/utils";

interface SiteFooterProps {
  /** Dynamic platform name (from platform.name setting). */
  platformName: string;
  /** When set, the matching nav item is highlighted as active.
   *  Pass the current page's slug so the footer reflects where the user is. */
  activeSlug?: "about" | "privacy" | "terms" | "contact";
}

/**
 * SiteFooter — minimal, non-intrusive footer for public-facing pages.
 *
 * Rendered on:
 *   - /about, /privacy, /terms, /contact (via SitePageClient)
 *   - (future: /articles/[id], /topics/[tag] — not yet, to keep the change
 *     minimal + avoid touching the existing article/topic page layouts)
 *
 * NOT rendered on:
 *   - The SPA root / (MainNav already provides navigation; adding a footer
 *     below the infinite-scroll feed would change the existing design)
 *   - Admin panel (full-screen h-screen layout — footer would break it)
 *   - Messenger (full-screen layout)
 *
 * Contents:
 *   - Left: platform name (dynamic)
 *   - Right: About, Privacy, Terms, Contact — ALL real working links
 *
 * Design:
 *   - Uses design-system tokens (bg-background, text-muted-foreground,
 *     border-border) so it inherits dark/light mode automatically.
 *   - Single row on mobile, comfortable spacing on desktop.
 *   - border-t to separate from page content.
 *   - NOT sticky / fixed — flows with the page (doesn't consume vertical
 *     viewport on mobile).
 *
 * Accessibility:
 *   - Single <footer> landmark
 *   - Real <button> elements with clear labels (keyboard-focusable)
 *   - activeSlug highlights the current page (aria-current="page")
 */
export function SiteFooter({ platformName, activeSlug }: SiteFooterProps) {
  const router = useRouter();
  const { t } = useTranslation();

  const links: Array<{
    slug: "about" | "privacy" | "terms" | "contact";
    label: string;
  }> = [
    { slug: "about", label: t("nav.about") || "About" },
    { slug: "privacy", label: t("nav.privacy") || "Privacy" },
    { slug: "terms", label: t("nav.terms") || "Terms" },
    { slug: "contact", label: t("nav.contact") || "Contact" },
  ];

  return (
    <footer className="border-t border-border/60 bg-background">
      <div className="mx-auto flex max-w-3xl flex-col items-start justify-between gap-3 px-4 py-6 text-sm text-muted-foreground md:flex-row md:items-center md:px-6">
        {/* Left: platform name */}
        <p className="font-medium">{platformName}</p>

        {/* Right: navigation links — all real, all working */}
        <nav
          aria-label="Footer"
          className="flex flex-wrap items-center gap-x-4 gap-y-2"
        >
          {links.map((link) => {
            const isActive = activeSlug === link.slug;
            return (
              <button
                key={link.slug}
                type="button"
                onClick={() => router.push(`/${link.slug}`)}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "hover:text-foreground hover:underline",
                  isActive ? "text-foreground font-medium" : "text-muted-foreground"
                )}
              >
                {link.label}
              </button>
            );
          })}
        </nav>
      </div>
    </footer>
  );
}
