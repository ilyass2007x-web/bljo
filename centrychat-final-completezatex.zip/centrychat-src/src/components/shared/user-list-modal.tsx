"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar } from "./avatar";
import { VerifiedBadge } from "./verified-badge";
import { FollowButton } from "./follow-button";
import { Loader2 } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";

interface UserListItem {
  id: string;
  fullName: string;
  username: string;
  avatarColor: string | null;
  avatarUrl?: string | null;
  isVerified: boolean;
  bio?: string | null;
  isFollowing?: boolean;
  isFollowedBy?: boolean;
}

interface UserListModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  username: string;
  type: "followers" | "following";
  currentUserId?: string;
}

export function UserListModal({
  open,
  onOpenChange,
  username,
  type,
  currentUserId,
}: UserListModalProps) {
  const router = useRouter();
  const [users, setUsers] = useState<UserListItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!open) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLoading(true);
    api
      .get<{ users: UserListItem[]; total: number }>(
        `/api/v1/users/${username}/${type}?pageSize=50`
      )
      .then((data) => {
        setUsers(data.users);
      })
      .catch((e) => {
        toast.error(e instanceof ApiClientError ? e.message : "Failed to load");
      })
      .finally(() => setLoading(false));
  }, [open, username, type]);

  function openProfile(uname: string) {
    onOpenChange(false);
    router.push(`/?view=profile&username=${encodeURIComponent(uname)}`);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0">
        <DialogTitle className="sr-only">
          {type === "followers" ? "Followers" : "Following"}
        </DialogTitle>
        <div className="flex items-center justify-between border-b p-4">
          <h3 className="font-semibold">
            {type === "followers" ? "Followers" : "Following"}
          </h3>
        </div>
        <ScrollArea className="max-h-96">
          <div className="p-2">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            ) : users.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                {type === "followers" ? "No followers yet." : "Not following anyone yet."}
              </p>
            ) : (
              <div className="space-y-1">
                {users.map((u) => (
                  <div
                    key={u.id}
                    className="flex items-center gap-3 rounded-lg p-2 hover:bg-accent"
                  >
                    <Avatar
                      name={u.fullName}
                      color={u.avatarColor}
                      src={u.avatarUrl}
                      size="sm"
                      onClick={() => openProfile(u.username)}
                    />
                    <div className="min-w-0 flex-1">
                      <button
                        onClick={() => openProfile(u.username)}
                        className="flex items-center gap-1 text-sm font-medium hover:underline"
                      >
                        <span className="truncate" dir="auto">{u.fullName}</span>
                        {u.isVerified && <VerifiedBadge size={13} />}
                      </button>
                      <p className="text-xs text-muted-foreground truncate">@{u.username}</p>
                    </div>
                    {currentUserId && u.id !== currentUserId && (
                      <FollowButton
                        targetUserId={u.id}
                        targetUsername={u.username}
                        isFollowing={u.isFollowing ?? (type === "following")}
                        isFollowedBy={u.isFollowedBy ?? false}
                        size="sm"
                        onStateChange={(state) => {
                          // Update the user in the list with new follow state.
                          setUsers((prev) =>
                            prev.map((p) =>
                              p.id === u.id ? { ...p, isFollowing: state.isFollowing } : p
                            )
                          );
                        }}
                      />
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
