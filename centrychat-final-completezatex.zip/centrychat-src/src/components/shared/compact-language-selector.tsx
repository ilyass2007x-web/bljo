"use client";

import { useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Check, ChevronRight, Globe } from "lucide-react";
import { SUPPORTED_LANGUAGES } from "@/lib/i18n";
import { cn } from "@/lib/utils";

interface CompactLanguageSelectorProps {
  value: string;
  onChange: (lang: string) => void;
  /** Label shown on the left (e.g. "Language"). */
  label: string;
  /** Optional description below the trigger. */
  description?: string;
}

/**
 * Compact, right-aligned language selector for the Settings page.
 *
 * Layout (LTR):
 *   [icon] Label                       العربية ›
 *                                       (native name)
 *
 * Layout (RTL — automatically flipped by `dir="rtl"` on <html>):
 *   العربية ‹                       [icon] Label
 *                                       (native name)
 *
 * Clicking the trigger opens a popover with the full list of supported
 * languages. Selecting one fires `onChange` and closes the popover.
 */
export function CompactLanguageSelector({
  value,
  onChange,
  label,
  description,
}: CompactLanguageSelectorProps) {
  const [open, setOpen] = useState(false);
  const current = SUPPORTED_LANGUAGES.find((l) => l.code === value);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="flex w-full items-center justify-between gap-3 rounded-lg px-3 py-3 text-start transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label={label}
        >
          <span className="flex items-center gap-2 min-w-0">
            <Globe className="h-4 w-4 shrink-0 text-muted-foreground" />
            <span className="min-w-0">
              <span className="block text-sm font-medium">{label}</span>
              {description && (
                <span className="block text-xs text-muted-foreground truncate">{description}</span>
              )}
            </span>
          </span>
          <span className="flex items-center gap-1 text-sm font-medium text-muted-foreground">
            <span dir="auto" className="text-foreground">
              {current?.nativeName ?? value}
            </span>
            <ChevronRight className="h-4 w-4 rtl-flip" />
          </span>
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-56 p-1">
        <ul role="listbox" className="max-h-72 overflow-y-auto">
          {SUPPORTED_LANGUAGES.map((lang) => {
            const selected = lang.code === value;
            return (
              <li key={lang.code} role="option" aria-selected={selected}>
                <button
                  type="button"
                  onClick={() => {
                    onChange(lang.code);
                    setOpen(false);
                  }}
                  className={cn(
                    "flex w-full items-center justify-between gap-2 rounded-md px-3 py-2 text-sm transition-colors hover:bg-accent",
                    selected && "bg-accent"
                  )}
                >
                  <span className="flex flex-col items-start min-w-0">
                    <span dir="auto" className="font-medium">{lang.nativeName}</span>
                    <span className="text-xs text-muted-foreground">{lang.englishName}</span>
                  </span>
                  {selected && <Check className="h-4 w-4 text-primary" />}
                </button>
              </li>
            );
          })}
        </ul>
      </PopoverContent>
    </Popover>
  );
}
