"use client";

import { useRouter } from "next/navigation";
import { Avatar } from "./avatar";
import { VerifiedBadge } from "./verified-badge";
import { cn } from "@/lib/utils";

interface UserIdentityProps {
  fullName: string;
  username: string;
  avatarColor?: string | null;
  avatarUrl?: string | null;
  isVerified?: boolean;
  avatarSize?: "sm" | "md" | "lg" | "xl";
  /** Show the avatar. Default: true. */
  showAvatar?: boolean;
  /** Show the @username below the name. Default: true. */
  showUsername?: boolean;
  /** Layout: horizontal (avatar + name side by side) or vertical. */
  layout?: "horizontal" | "vertical";
  className?: string;
  /** Override click behavior. Default: navigate to /@username. */
  onClick?: () => void;
}

/**
 * Clickable user identity component — shows avatar, full name, verified badge,
 * and @username. Clicking navigates to the user's profile page.
 *
 * Used everywhere a user's identity appears: messages, search, notifications,
 * conversation list, followers/following lists, etc.
 */
export function UserIdentity({
  fullName,
  username,
  avatarColor,
  avatarUrl,
  isVerified = false,
  avatarSize = "sm",
  showAvatar = true,
  showUsername = true,
  layout = "horizontal",
  className,
  onClick,
}: UserIdentityProps) {
  const router = useRouter();

  const navigateToProfile = () => {
    if (onClick) {
      onClick();
    } else {
      router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
    }
  };

  if (layout === "vertical") {
    return (
      <div className={cn("flex flex-col items-center gap-2", className)}>
        {showAvatar && (
          <Avatar
            name={fullName}
            color={avatarColor}
            src={avatarUrl}
            size={avatarSize}
            onClick={navigateToProfile}
          />
        )}
        <div className="text-center">
          <button
            onClick={navigateToProfile}
            className="flex items-center gap-1 font-medium hover:underline"
            dir="auto"
          >
            {fullName}
            {isVerified && <VerifiedBadge size={14} />}
          </button>
          {showUsername && (
            <button
              onClick={navigateToProfile}
              className="block text-xs text-muted-foreground hover:underline"
            >
              @{username}
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={cn("flex items-center gap-2 min-w-0", className)}>
      {showAvatar && (
        <Avatar
          name={fullName}
          color={avatarColor}
          src={avatarUrl}
          size={avatarSize}
          onClick={navigateToProfile}
        />
      )}
      <div className="min-w-0">
        <button
          onClick={navigateToProfile}
          className="flex items-center gap-1 font-medium hover:underline truncate"
          dir="auto"
        >
          <span className="truncate">{fullName}</span>
          {isVerified && <VerifiedBadge size={14} />}
        </button>
        {showUsername && (
          <button
            onClick={navigateToProfile}
            className="block text-xs text-muted-foreground hover:underline truncate w-full text-left"
          >
            @{username}
          </button>
        )}
      </div>
    </div>
  );
}
