"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/shared/avatar";
import { NotificationCenter } from "@/components/shared/notification-center";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { useRealtime } from "@/hooks/use-realtime";
import { Home, MessageSquare, Moon, Sun, Shield, ShieldCheck, LogOut, LogIn, Bell, Search, Info, User as UserIcon, Video } from "lucide-react";
import { useTheme } from "next-themes";
import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client/api";
import { useNotifications } from "@/hooks/use-notifications";
import { isVideoChatClientEnabled } from "@/lib/video-chat/enabled";
import { cn } from "@/lib/utils";

/**
 * Main navigation bar — provides direct access to:
 * 🏠 Home  💬 Messages  🔔 Notifications  👤 Profile
 *
 * Features:
 * - Real-time unread message badge on 💬
 * - Real-time unread notification badge on 🔔 (handled by NotificationCenter)
 * - Active state highlighting based on current view
 * - Responsive: top bar on desktop, bottom bar on mobile
 * - Theme toggle + admin link + logout
 */
export function MainNav() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, clear } = useAuthStore();
  const { t } = useTranslation();
  const { theme, setTheme } = useTheme();
  const [unreadMessages, setUnreadMessages] = useState(0);

  // Determine the active view for highlighting.
  const view = searchParams.get("view");
  const conversation = searchParams.get("conversation");
  const activeTab = view === "messages" || conversation ? "messages"
    : view === "profile" ? "profile"
    : view === "admin" ? "admin"
    : view === "settings" ? "settings"
    : view === "edit-profile" ? "profile"
    : view === "notifications" ? "notifications"
    : view === "search" ? "search"
    : view === "video-chat" ? "video-chat"
    : "home";

  // Fetch unread message count (total across all conversations).
  const refreshUnread = useCallback(async () => {
    try {
      const data = await api.get<{ conversations: { unreadCount: number }[] }>("/api/v1/conversations");
      const total = data.conversations.reduce((sum, c) => sum + c.unreadCount, 0);
      setUnreadMessages(total);
    } catch {
      /* ignore */
    }
  }, []);

  // Initial fetch + polling fallback (every 15s — less aggressive than
  // the old 5s interval to reduce unnecessary API calls + CPU on mobile).
  // Pauses when the tab is not visible (spec §3 — "avoid wasting bandwidth
  // on mobile" + spec §26 — "optimize for mobile networks").
  // The realtime `message:new` handler provides instant unread count
  // updates — the polling is ONLY a fallback for when realtime is broken
  // (e.g. on Netlify serverless where the socket.io service can't run).
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void refreshUnread();
    const interval = setInterval(() => {
      // Skip polling when the tab is not visible — saves network + CPU.
      if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
      void refreshUnread();
    }, 15000);
    return () => clearInterval(interval);
  }, [refreshUnread]);

  // Realtime: when a new message arrives, increment unread count.
  useRealtime(!!user, {
    "message:new": () => {
      setUnreadMessages((c) => c + 1);
      void refreshUnread(); // sync with server
    },
  });

  async function logout() {
    try {
      await api.post("/api/v1/auth/logout");
    } catch {
      /* ignore */
    }
    clear();
    router.push("/");
  }

  const navItems = [
    { id: "home", label: t("nav.home") || "Home", icon: Home, view: null, badge: 0 },
    { id: "messages", label: t("notifications.title") === "Notifications" ? "Messages" : "الرسائل", icon: MessageSquare, view: "messages", badge: unreadMessages },
  ];

  return (
    <>
      {/* Desktop top bar — hidden on mobile (mobile uses bottom nav only) */}
      <header className="sticky top-0 z-30 hidden h-14 items-center justify-between border-b bg-background/80 px-4 backdrop-blur md:flex">
        <div className="flex items-center gap-1">
          {/* Home — the desktop nav label was previously `t("nav.messenger")`
              which displayed "Messenger" next to a Home icon (misleading).
              Changed to `t("nav.home")` so the label matches the icon + the
              mobile bottom-nav label. The route (`router.push("/")`) is
              UNCHANGED — still goes to the home feed. */}
          <NavButton
            active={activeTab === "home"}
            onClick={() => router.push("/")}
            icon={Home}
            label={t("nav.home")}
          />

          {/* Messages */}
          <NavButton
            active={activeTab === "messages"}
            onClick={() => router.push("/?view=messages")}
            icon={MessageSquare}
            label="Messages"
            badge={unreadMessages}
          />

          {/* Search — opens the dedicated Smart Global Search page */}
          <NavButton
            active={activeTab === "search"}
            onClick={() => router.push("/?view=search")}
            icon={Search}
            label={t("nav.search") || "Search"}
          />

          {/* Video Chat — the EXISTING ?view=video-chat route (VideoChatScreen
              component, code-split in page.tsx). This is the SAME route the
              mobile bottom-nav uses (see below). Added to the desktop header
              so desktop users have the same access as mobile users.

              Previously this was MISSING from the desktop header — the Video
              Chat icon only appeared in the mobile bottom-nav. Desktop users
              had no way to access Video Chat from the main navigation. This
              fix adds it using the SAME NavButton component, SAME icon (Video),
              SAME route, SAME label — consistent with the mobile entry.

              DISABLED (TEMPORARY): When NEXT_PUBLIC_VIDEO_CHAT_ENABLED is not
              "true", the Video Chat icon is hidden from the navigation. The
              underlying route is also blocked in src/app/page.tsx — direct
              URL access (?view=video-chat) redirects to the home feed. The
              VideoChatScreen component, the API routes, and the database
              models are all PRESERVED — flipping the env var back to "true"
              restores the icon + route immediately. */}
          {isVideoChatClientEnabled() && (
            <NavButton
              active={activeTab === "video-chat"}
              onClick={() => router.push("/?view=video-chat")}
              icon={Video}
              label={t("nav.video") || "Video"}
            />
          )}

          {/* About — public About Us page (real /about SSR route).
              Small ghost link — non-intrusive but always discoverable on
              desktop. On mobile, the HomeFeed sticky header has its own
              About link (the bottom nav is already full). */}
          <NavButton
            active={false}
            onClick={() => router.push("/about")}
            icon={Info}
            label={t("nav.about") || "About"}
          />

          {/* Notifications (uses its own popover) */}
          <NotificationCenter
            enabled={!!user}
            onNavigate={(target) => {
              if (target.conversationId) {
                router.push(`/?conversation=${target.conversationId}`);
              }
            }}
          />
        </div>

        {/* Right side: profile, theme, admin, logout */}
        <div className="flex items-center gap-1">
          {/* Profile — when logged in, opens own profile.
              When LOGGED OUT, shows a clean User icon + navigates to
              the login flow (the root `/` renders AuthScreen for
              unauthenticated users). NEVER renders the Avatar fallback
              with name "?" (which produced the broken-looking "?" mark
              in the avatar circle for anonymous visitors). */}
          {user ? (
            <button
              onClick={() => router.push(`/?view=profile&username=${encodeURIComponent(user.username)}`)}
              className={cn(
                "flex items-center gap-2 rounded-lg p-1.5 transition-colors hover:bg-accent",
                activeTab === "profile" && "bg-accent"
              )}
              title={t("nav.profile") || "Profile"}
            >
              <Avatar
                name={user.fullName}
                color={user.avatarColor}
                src={user.avatarUrl}
                size="sm"
              />
            </button>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => router.push("/")}
              title={t("auth.signIn") || "Sign in"}
              aria-label={t("auth.signIn") || "Sign in"}
            >
              <UserIcon className="h-5 w-5" />
            </Button>
          )}

          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} title={t("nav.toggleTheme")}>
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>

          {/* Admin / Super Admin shield — different icons for different roles.
              - SUPER_ADMIN: ShieldCheck (filled, primary color) — clearly
                distinguishes the highest privilege level.
              - ADMIN: Shield (outline) — standard admin access.
              Both link to the same Admin Panel; the server independently
              enforces role-based access on every admin API route. */}
          {user?.role === "SUPER_ADMIN" && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => router.push("/?view=admin")}
              title="Super Admin Control"
              className="relative"
            >
              <ShieldCheck
                className={cn(
                  "h-5 w-5 text-primary",
                  activeTab === "admin" && "scale-110"
                )}
              />
            </Button>
          )}
          {user?.role === "ADMIN" && (
            <Button variant="ghost" size="icon" onClick={() => router.push("/?view=admin")} title={t("nav.adminPanel")}>
              <Shield className={cn("h-5 w-5", activeTab === "admin" && "text-primary")} />
            </Button>
          )}

          {/* Logout — only shown when authenticated. For logged-out
              visitors we show a Sign In button in its place (clearer UX
              than a logout button that does nothing). */}
          {user ? (
            <Button variant="ghost" size="icon" onClick={logout} title={t("auth.signOut")}>
              <LogOut className="h-5 w-5 rtl-flip" />
            </Button>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => router.push("/")} title={t("auth.signIn") || "Sign in"}>
              <LogIn className="h-5 w-5 rtl-flip" />
            </Button>
          )}
        </div>
      </header>

      {/* Mobile bottom bar — primary mobile navigation per spec §15 */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 flex h-14 items-center justify-around border-t bg-background/95 backdrop-blur md:hidden">
        <MobileNavButton
          active={activeTab === "home"}
          onClick={() => router.push("/")}
          icon={Home}
          label={t("nav.home")}
        />
        <MobileNavButton
          active={activeTab === "messages"}
          onClick={() => router.push("/?view=messages")}
          icon={MessageSquare}
          label={t("nav.messages")}
          badge={unreadMessages}
        />
        {/* Video Chat — moved here from the removed Search slot. Uses the
            EXISTING ?view=video-chat route (VideoChatScreen component, code-
            split in page.tsx). No new route, no new component, no duplicate
            video chat system. The Search entry was moved to the mobile
            HomeFeed sticky header (which navigates to /?view=search — the
            full Search page that already includes the "People" tab for
            user search). Desktop already has its own Search button in the
            top header (lines above).

            DISABLED (TEMPORARY): Hidden when NEXT_PUBLIC_VIDEO_CHAT_ENABLED
            is not "true". The mobile bottom bar returns to its 4-item
            layout (Home / Messages / Notifications / Profile) — same as
            before Video Chat was added. The VideoChatScreen component and
            the underlying route are preserved. */}
        {isVideoChatClientEnabled() && (
          <MobileNavButton
            active={activeTab === "video-chat"}
            onClick={() => router.push("/?view=video-chat")}
            icon={Video}
            label={t("nav.video") || "Video"}
          />
        )}
        <MobileNotificationCenter
          onNavigate={(target) => {
            if (target.conversationId) {
              router.push(`/?conversation=${target.conversationId}`);
            }
          }}
        />
        {/* Admin / Super Admin Shield — visible on mobile too (spec §13-15).
            Same role check as the desktop header. Uses the same ShieldCheck
            icon for SUPER_ADMIN and Shield for ADMIN. */}
        {user?.role === "SUPER_ADMIN" && (
          <MobileNavButton
            active={activeTab === "admin"}
            onClick={() => router.push("/?view=admin")}
            icon={ShieldCheck}
            label="Admin"
          />
        )}
        {user?.role === "ADMIN" && (
          <MobileNavButton
            active={activeTab === "admin"}
            onClick={() => router.push("/?view=admin")}
            icon={Shield}
            label="Admin"
          />
        )}
        {/* Profile — when logged in, opens own profile via Avatar.
            When LOGGED OUT, shows a clean User icon + navigates to the
            login flow (the root `/` renders AuthScreen for unauthenticated
            users). This avoids the broken "?" avatar fallback for
            anonymous visitors. */}
        {user ? (
          <MobileNavButton
            active={activeTab === "profile"}
            onClick={() => router.push(`/?view=profile&username=${encodeURIComponent(user.username)}`)}
            icon={undefined}
            label={t("nav.profile")}
            avatar={{ name: user.fullName, color: user.avatarColor, src: user.avatarUrl }}
          />
        ) : (
          <MobileNavButton
            active={false}
            onClick={() => router.push("/")}
            icon={UserIcon}
            label={t("auth.signIn") || "Sign in"}
          />
        )}
      </nav>
    </>
  );
}

// Desktop nav button
function NavButton({ active, onClick, icon: Icon, label, badge }: {
  active: boolean;
  onClick: () => void;
  icon: typeof Home;
  label: string;
  badge?: number;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors hover:bg-accent",
        active && "bg-accent text-accent-foreground"
      )}
    >
      <Icon className="h-5 w-5" />
      <span className="hidden sm:inline">{label}</span>
      {badge && badge > 0 ? (
        <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
          {badge > 99 ? "99+" : badge}
        </span>
      ) : null}
    </button>
  );
}

// Mobile nav button
function MobileNavButton({ active, onClick, icon: Icon, label, badge, avatar }: {
  active: boolean;
  onClick: () => void;
  icon?: typeof Home;
  label: string;
  badge?: number;
  avatar?: { name: string; color: string | null; src?: string | null };
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "relative flex flex-col items-center justify-center gap-0.5 px-3 py-1.5 text-[10px] font-medium transition-colors",
        active ? "text-primary" : "text-muted-foreground"
      )}
    >
      {avatar ? (
        <Avatar name={avatar.name} color={avatar.color} src={avatar.src} size="sm" className={cn(active && "ring-2 ring-primary ring-offset-1")} />
      ) : Icon ? (
        <Icon className="h-5 w-5" />
      ) : null}
      <span>{label}</span>
      {badge && badge > 0 ? (
        <span className="absolute right-1 top-0 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
          {badge > 99 ? "99+" : badge}
        </span>
      ) : null}
    </button>
  );
}

// Mobile notification center — uses the same MobileNavButton layout as
// all other bottom-nav items, with a Bell icon + badge + label.
// This ensures visual consistency with Home, Messages, and Profile buttons.
function MobileNotificationCenter({ onNavigate }: { onNavigate: (target: { conversationId?: string | null }) => void }) {
  const { t } = useTranslation();
  const { unreadCount } = useNotifications(true);

  // Sync missed notifications when the tab regains focus.
  const { refresh } = useNotifications(true);
  useEffect(() => {
    const onFocus = () => void refresh();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [refresh]);

  // Realtime: bump the badge when a new notification arrives.
  useRealtime(true, {
    "notification:new": () => {
      void refresh();
    },
  });

  void onNavigate;

  const router = useRouter();

  return (
    <MobileNavButton
      active={false}
      onClick={() => router.push("/?view=notifications")}
      icon={Bell}
      label={t("nav.alerts") || "Alerts"}
      badge={unreadCount}
    />
  );
}
