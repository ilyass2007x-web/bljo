"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Video, VideoOff, Mic, MicOff, SkipForward, LogOut, Flag, ShieldOff, PhoneOff } from "lucide-react";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { COUNTRIES, getCountryFlag, getCountryName } from "@/lib/countries";
import { isVideoChatClientEnabled } from "@/lib/video-chat/enabled";

/**
 * VideoChatScreen — the main Video Chat view.
 *
 * Lifecycle:
 *   IDLE → SEARCHING → MATCHED → CONNECTING → CONNECTED → ENDED → IDLE
 *
 * The user clicks "Start Video Chat" → joins the matchmaking queue →
 * waits for a match → WebRTC negotiation → video/audio P2P → "Next" or "Leave".
 *
 * Code-split: this component is dynamically imported in page.tsx so the
 * WebRTC code only loads when the user enters ?view=video-chat.
 */

type CallState = "idle" | "searching" | "matched" | "connecting" | "connected" | "ended" | "failed";

interface Peer {
  id: string;
  fullName: string;
  username: string;
  avatarColor: string | null;
  avatarUrl: string | null;
  isVerified: boolean;
}

interface SignalPayload {
  id: string;
  type: "offer" | "answer" | "ice" | "end";
  payload: unknown;
  fromUserId: string;
}

/**
 * Format a getUserMedia / WebRTC error into a human-readable message.
 *
 * Spec §1B: do NOT collapse all errors into "permission denied". Each
 * DOMException name has a specific cause + a specific user message.
 *
 * The caller should display the returned message directly — it's already
 * safe for end users (no technical jargon, no error codes).
 *
 * Handles:
 *   - NotAllowedError / PermissionDeniedError → genuine permission denial
 *   - NotFoundError → no camera or microphone on this device
 *   - NotReadableError → camera/mic in use by another app/tab
 *   - OverconstrainedError → constraints can't be met (e.g. no front camera)
 *   - SecurityError → not HTTPS (or other security issue)
 *   - TypeError → API missing / wrong call signature
 *   - AbortError → unexpected abort (retry)
 *   - Unknown errors → generic message (never leak internals)
 */
function formatGetUserMediaError(err: unknown): string {
  if (err instanceof DOMException) {
    switch (err.name) {
      case "NotAllowedError":
      case "PermissionDeniedError":
        return "Camera or microphone access was denied. Please allow access in your browser settings and try again.";
      case "NotFoundError":
        return "No camera or microphone was found on this device. Please connect a camera and microphone and try again.";
      case "NotReadableError":
        return "Your camera or microphone is being used by another application or browser tab. Please close it and try again.";
      case "OverconstrainedError":
        return "Your camera or microphone does not meet the required constraints. Please try a different device.";
      case "SecurityError":
        return "Camera and microphone access requires a secure (HTTPS) connection. Please use HTTPS.";
      case "AbortError":
        return "Could not start the camera or microphone. Please try again.";
      case "TypeError":
        return "Video chat is not supported by this browser. Please use the latest Chrome, Edge, Firefox, or Safari.";
    }
  }
  // Non-DOMException errors (e.g. "TypeError: navigator.mediaDevices is undefined"
  // when the API is missing entirely — thrown as a plain TypeError, not a DOMException).
  if (err instanceof TypeError) {
    return "Video chat is not supported by this browser. Please use the latest Chrome, Edge, Firefox, or Safari.";
  }
  return "Could not access camera or microphone. Please check your device and try again.";
}

/**
 * Emit a `[VIDEO]` diagnostic log. Gated by `debugLoggingRef.current` —
 * when false (default), this is a no-op. The admin enables it via the
 * Video Chat admin panel (`videochat.debug_logging` PlatformSetting).
 *
 * SECURITY: NEVER pass SDP, ICE candidate payloads, TURN credentials, or
 * session cookies to this function. Only safe metadata.
 */
function debugLog(ref: React.MutableRefObject<boolean>, tag: string, ...args: unknown[]): void {
  if (!ref.current) return;
  console.log(`[VIDEO] ${tag}`, ...args);
}

function debugError(ref: React.MutableRefObject<boolean>, tag: string, ...args: unknown[]): void {
  if (!ref.current) return;
  console.error(`[VIDEO] ${tag}`, ...args);
}

export function VideoChatScreen() {
  const router = useRouter();
  const [state, setState] = useState<CallState>("idle");
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [peer, setPeer] = useState<Peer | null>(null);
  const [isOfferer, setIsOfferer] = useState(false);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reportDialogOpen, setReportDialogOpen] = useState(false);

  // Matchmaking preferences (selected by the user before starting).
  const [desiredGender, setDesiredGender] = useState<"ANY" | "MALE" | "FEMALE">("ANY");
  const [desiredCountry, setDesiredCountry] = useState<string>("WORLDWIDE");

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const iceConfigRef = useRef<{ iceServers: RTCIceServer[] } | null>(null);
  const pollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const signalPollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // ── WebRTC negotiation fix (Connection Reliability) ─────────────────
  // Buffer of remote ICE candidates that arrived BEFORE the remote
  // description (offer/answer) was set. addIceCandidate throws
  // InvalidStateError when called before setRemoteDescription, so we
  // buffer them here and flush immediately after setRemoteDescription
  // succeeds. This is a CLIENT-SIDE buffer only — Redis signaling is
  // unchanged. Cleared in cleanup().
  const pendingIceCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  // Defensive 30s connection timeout: if pc.connectionState doesn't
  // reach "connected" within 30s of entering "connecting", we force-
  // fail the call so the user is never stuck on "Connecting..."
  // forever. Cleared on connected/failed/closed + cleanup.
  const connectionTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Admin-controlled debug-logging flag (mirror of iceConfigRef.current.debugLogging).
  // Gated by PlatformSetting `videochat.debug_logging`. When true, the screen
  // emits [VIDEO] diagnostic logs. Off by default — admin enables on demand.
  const debugLoggingRef = useRef(false);

  // ── Forward-declared refs for callbacks that reference each other ──
  // `initWebRTC` is declared AFTER `startCall` + `startQueuePolling` in
  // the file, but those earlier callbacks need to call it. The original
  // code used `void initWebRTC(...)` which silently discarded rejections
  // (the actual root cause of "stuck on Connecting..." — when initWebRTC
  // threw, the rejection was lost). Now we route through a ref so the
  // closures can `await initWebRTCRef.current(...)` + catch rejections
  // properly. The ref is assigned below when initWebRTC is created.
  const initWebRTCRef = useRef<(sessId: string, offerer: boolean) => Promise<void>>(async () => {
    // Placeholder — replaced when initWebRTC is created below.
  });

  // ── Cleanup on unmount ─────────────────────────────────────────────
  const cleanup = useCallback(async () => {
    debugLog(debugLoggingRef, "cleanup", { sessionId: sessionId?.slice(-6) });
    if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    if (signalPollRef.current) clearInterval(signalPollRef.current);
    if (connectionTimeoutRef.current) {
      clearTimeout(connectionTimeoutRef.current);
      connectionTimeoutRef.current = null;
    }
    pendingIceCandidatesRef.current = [];
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }
    if (sessionId) {
      try {
        await api.patch(`/api/v1/video-chat/sessions/${sessionId}`, {
          action: "end",
          endReason: "user_left",
        });
      } catch {
        // Non-fatal
      }
    }
  }, [sessionId]);

  useEffect(() => {
    return () => { void cleanup(); };
  }, [cleanup]);

  // ── Re-attach local stream to <video> when CallView mounts ──────────
  // PHASE 3 FIX (R2 — local video srcObject timing bug):
  //
  // The previous code tried to bind `localVideoRef.current.srcObject`
  // inside `startCall()` (lines 196-212 below). But `startCall` first
  // calls `setState("searching")` (line 158) → React re-renders → the
  // SearchingView is shown (which has NO `<video>` element). At the
  // moment getUserMedia resolves, `localVideoRef.current === null`,
  // so the `if (localVideoRef.current)` guard at line 196 silently
  // skips the srcObject assignment. The local camera IS captured
  // (LED on, stream held in `localStreamRef.current`) but NEVER bound
  // to the video element.
  //
  // When matching succeeds, state transitions to "matched" / "connecting"
  // / "connected" → the CallView mounts → `<video ref={localVideoRef}>`
  // appears. But there was no effect to bind the stream at this point.
  //
  // This effect re-runs whenever `state` changes (and also when
  // `localStreamRef` updates via the ref read). It checks whether the
  // <video> element exists AND whether its srcObject is already bound.
  // If not, it re-binds. The stream is NOT re-acquired — we reuse the
  // existing `localStreamRef.current`.
  //
  // The effect is intentionally NOT async (returning a Promise from
  // useEffect is invalid React). `video.play()` is fired-and-forgotten
  // via `void` — autoplay rejection is non-fatal (the user will see a
  // black frame until they interact, at which point the browser
  // auto-resumes).
  useEffect(() => {
    const stream = localStreamRef.current;
    const video = localVideoRef.current;
    if (!stream || !video) return;
    // Avoid re-binding if the stream is already attached — React Strict
    // Mode in dev double-invokes effects; we don't want to revoke + re-set
    // the stream unnecessarily.
    if (video.srcObject === stream) return;
    video.srcObject = stream;
    // Mute the local preview so the user doesn't hear themselves
    // (audio feedback loop).
    video.muted = true;
    // playsInline is REQUIRED on iOS Safari for inline playback (without
    // it, the video opens in fullscreen). React doesn't always honor the
    // JSX `playsInline` prop correctly on iOS, so we set it imperatively.
    video.setAttribute("playsinline", "");
    video.setAttribute("autoplay", "");
    // Best-effort play. Autoplay is allowed by the browser because the
    // video is muted (muted+autoplay is universally permitted).
    void video.play().catch(() => {
      // Autoplay rejected — non-fatal. The browser will resume playback
      // on the next user gesture (click / tap anywhere on the page).
    });
    // NOTE: do NOT call URL.revokeObjectURL(stream) — the stream is a
    // MediaStream (not a blob URL), so revokeObjectURL is a no-op.
    // The stream is owned by localStreamRef and is stopped in cleanup()
    // via getTracks().forEach(t => t.stop()).
  }, [state]);

  // ── Get ICE config ─────────────────────────────────────────────────
  const loadIceConfig = useCallback(async (): Promise<boolean> => {
    try {
      const config = await api.get<{ iceServers: RTCIceServer[]; turnEnabled: boolean; debugLogging?: boolean }>(
        "/api/v1/video-chat/config"
      );
      iceConfigRef.current = { iceServers: config.iceServers };
      // Mirror the admin-controlled debug flag so the helpers can read it
      // without re-rendering.
      debugLoggingRef.current = !!config.debugLogging;
      debugLog(debugLoggingRef, "ICE config loaded", {
        turnEnabled: config.turnEnabled,
        iceServerCount: config.iceServers?.length ?? 0,
      });
      return true;
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Failed to load video chat config.");
      return false;
    }
  }, []);

  // ── Start: get camera/mic + join queue ─────────────────────────────
  const startCall = useCallback(async () => {
    setError(null);

    // DISABLED GUARD: short-circuit BEFORE any capability detection or
    // getUserMedia call. This is defense-in-depth — the route in page.tsx
    // should never mount this component when disabled, but if it does
    // (stale navigation, future refactoring), the user sees a clean
    // "Video chat is currently disabled." message instead of a camera
    // permission prompt.
    if (!isVideoChatClientEnabled()) {
      setError("Video chat is currently disabled.");
      setState("failed");
      return;
    }

    setState("searching");

    // ── Capability detection (runs BEFORE getUserMedia) ──────────────
    // Spec §1B/§2: do NOT assume mobile is unsupported. Do NOT assume
    // desktop is supported. Perform REAL capability detection based on
    // the presence of the required WebRTC + media APIs + a secure
    // context. This runs ONLY on the client (inside useCallback, which
    // is only called from a user click — never during SSR).
    if (typeof window === "undefined") {
      // SSR guard — should never happen (startCall is only called from
      // a button click), but defensive.
      setError("Video chat can only be started in the browser.");
      setState("failed");
      return;
    }
    if (!window.isSecureContext) {
      setError("Video chat requires a secure (HTTPS) connection. Please use HTTPS.");
      setState("failed");
      return;
    }
    if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== "function") {
      setError("Your browser does not support camera/microphone access. Please use the latest Chrome, Edge, Firefox, or Safari.");
      setState("failed");
      return;
    }
    if (typeof window.RTCPeerConnection !== "function") {
      setError("Your browser does not support WebRTC. Please use the latest Chrome, Edge, Firefox, or Safari.");
      setState("failed");
      return;
    }

    // 1. Get user media (camera + mic)
    try {
      debugLog(debugLoggingRef, "getUserMedia", { step: "requesting" });
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      localStreamRef.current = stream;
      debugLog(debugLoggingRef, "getUserMedia", {
        step: "granted",
        videoTracks: stream.getVideoTracks().length,
        audioTracks: stream.getAudioTracks().length,
      });
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
        // iOS Safari requires muted + playsInline for autoplay to work.
        // The local preview should be muted (otherwise the user hears
        // themselves — feedback loop).
        localVideoRef.current.muted = true;
        // playsInline is required for iOS Safari to render the video inline
        // (without entering fullscreen). React doesn't set this attribute
        // correctly via the prop — we set it directly.
        localVideoRef.current.setAttribute("playsinline", "");
        localVideoRef.current.setAttribute("autoplay", "");
        try {
          await localVideoRef.current.play();
        } catch {
          // Autoplay might be blocked until user gesture — non-fatal.
          // The video will play once the user interacts.
        }
      }
    } catch (err) {
      // ── GRANULAR error handling (spec §1B) ─────────────────────────
      // Do NOT collapse all errors into "permission denied". Each
      // DOMException name has a specific cause + a specific user message.
      debugError(debugLoggingRef, "getUserMedia failed", {
        error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
      });
      const message = formatGetUserMediaError(err);
      setError(message);
      setState("failed");
      return;
    }

    // 2. Load ICE config
    const ok = await loadIceConfig();
    if (!ok) {
      setState("failed");
      return;
    }

    // 3. Join the matchmaking queue (with the user's preferences)
    try {
      const result = await api.post<{
        status: string;
        sessionId?: string;
        peer?: Peer;
        isOfferer?: boolean;
      }>("/api/v1/video-chat/queue", { desiredGender, desiredCountry });

      if (result.status === "matched" && result.sessionId && result.peer) {
        setSessionId(result.sessionId);
        setPeer(result.peer);
        setIsOfferer(result.isOfferer ?? false);
        setState("matched");
        // Start WebRTC negotiation.
        // FIX: previously `void initWebRTC(...)` discarded any rejection —
        // if initWebRTC threw (missing ICE config / local stream), the
        // UI would stay stuck on "matched" forever. Now we catch + show
        // a user-friendly error. We use a ref (initWebRTCRef) so this
        // closure can reference the function defined later in the file.
        try {
          await initWebRTCRef.current(result.sessionId, result.isOfferer ?? false);
        } catch (err) {
          debugError(debugLoggingRef, "initWebRTC failed (initial match)", {
            sessionId: result.sessionId.slice(-6),
            error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
          });
          setError("Unable to establish video connection. Please try again.");
          setState("failed");
          void cleanup();
        }
      } else if (result.status === "searching") {
        // Start polling the queue
        startQueuePolling();
      }
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Failed to join queue.");
      setState("failed");
    }
  }, [loadIceConfig, desiredGender, desiredCountry, cleanup]);

  // ── Queue polling (every 2s) ───────────────────────────────────────
  const startQueuePolling = useCallback(() => {
    if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    pollIntervalRef.current = setInterval(async () => {
      try {
        const result = await api.get<{
          status: string;
          sessionId?: string;
          peer?: Peer;
          isOfferer?: boolean;
        }>("/api/v1/video-chat/queue");

        if (result.status === "matched" && result.sessionId && result.peer) {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          setSessionId(result.sessionId);
          setPeer(result.peer);
          setIsOfferer(result.isOfferer ?? false);
          setState("matched");
          // FIX: previously `void initWebRTC(...)` discarded any rejection —
          // if initWebRTC threw (missing ICE config / local stream), the
          // UI would stay stuck on "matched" forever. Now we catch + show
          // a user-friendly error. We use a ref (initWebRTCRef) so this
          // closure can reference the function defined later in the file.
          try {
            await initWebRTCRef.current(result.sessionId, result.isOfferer ?? false);
          } catch (err) {
            debugError(debugLoggingRef, "initWebRTC failed (poll match)", {
              sessionId: result.sessionId.slice(-6),
              error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
            });
            setError("Unable to establish video connection. Please try again.");
            setState("failed");
            void cleanup();
          }
        } else if (result.status === "timeout") {
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          setError("No one is available right now. Please try again.");
          setState("failed");
        }
      } catch {
        // Non-fatal — keep polling
      }
    }, 2000);
  }, [cleanup]);

  // ── WebRTC initialization ──────────────────────────────────────────
  // FIX (initWebRTC early return → throw): previously, missing
  // iceConfigRef or localStreamRef caused a silent `return` —
  // leaving pcRef.current = null, no PC created, no timeout set,
  // and the UI stuck on "Connecting..." forever. Now we throw an
  // explicit error so the caller can surface a user-friendly message.
  const initWebRTC = useCallback(async (sessId: string, offerer: boolean) => {
    if (!iceConfigRef.current) {
      throw new Error("ICE configuration is not available.");
    }
    if (!localStreamRef.current) {
      throw new Error("Local media stream is not available.");
    }

    debugLog(debugLoggingRef, "local stream ready", {
      videoTracks: localStreamRef.current.getVideoTracks().length,
      audioTracks: localStreamRef.current.getAudioTracks().length,
      sessionId: sessId.slice(-6),
    });

    setState("connecting");

    const pc = new RTCPeerConnection(iceConfigRef.current);
    pcRef.current = pc;
    debugLog(debugLoggingRef, "peer created", {
      iceServers: iceConfigRef.current.iceServers.length,
      offerer,
      sessionId: sessId.slice(-6),
    });

    // ── WebRTC state diagnostics (gated by debugLoggingRef) ──────────
    // Log all four WebRTC state machines so we can trace exactly where
    // the negotiation stalls. Gated by the admin-controlled
    // `videochat.debug_logging` flag — silent by default.
    //
    // Logged info: sessionId, offerer (yes/no), state names. NO SDP,
    // NO ICE candidate content (those may leak NAT topology / public
    // IPs to anyone reading the console). Only the state names.
    pc.onsignalingstatechange = () => {
      debugLog(debugLoggingRef, "signaling state", {
        signalingState: pc.signalingState,
        sessionId: sessId.slice(-6),
      });
    };
    pc.onicegatheringstatechange = () => {
      debugLog(debugLoggingRef, "ICE gathering state", {
        iceGatheringState: pc.iceGatheringState,
        sessionId: sessId.slice(-6),
      });
    };
    pc.oniceconnectionstatechange = () => {
      debugLog(debugLoggingRef, "ICE connection state", {
        iceConnectionState: pc.iceConnectionState,
        sessionId: sessId.slice(-6),
      });
    };

    // Add local tracks
    localStreamRef.current.getTracks().forEach((track) => {
      pc.addTrack(track, localStreamRef.current!);
    });

    // Remote track handler
    pc.ontrack = (event) => {
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = event.streams[0];
      }
      debugLog(debugLoggingRef, "remote stream received", {
        kind: event.track.kind,
        streamCount: event.streams.length,
        sessionId: sessId.slice(-6),
      });
    };

    // ICE candidate handler → send to peer via signaling
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        debugLog(debugLoggingRef, "ICE candidate sent", {
          type: event.candidate.type,
          protocol: event.candidate.protocol,
          sessionId: sessId.slice(-6),
          // NEVER log the candidate's address — it may leak NAT topology.
        });
        void api.post("/api/v1/video-chat/signal", {
          sessionId: sessId,
          type: "ice",
          payload: event.candidate.toJSON(),
        });
      }
    };

    // ── Connection state handler (Connection Reliability) ─────────────
    // Handles all four connection states correctly:
    //   connected    → UI = connected, clear the 30s timeout
    //   failed       → UI = failed, clear the timeout (fatal — no recovery)
    //   closed       → UI = ended if we were connected, else failed
    //   disconnected → DON'T assume the call ended. WebRTC can recover
    //                  from a transient disconnect (WiFi blip, ICE
    //                  restart). Stay in the current state; if the
    //                  connection doesn't recover, WebRTC will eventually
    //                  fire "failed" which we handle above.
    pc.onconnectionstatechange = () => {
      const connState = pc.connectionState;
      debugLog(debugLoggingRef, "connection state", {
        connState,
        signalingState: pc.signalingState,
        iceConnectionState: pc.iceConnectionState,
        sessionId: sessId.slice(-6),
      });
      if (connState === "connected") {
        // Clear the 30s connection timeout — we made it.
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
          connectionTimeoutRef.current = null;
        }
        setState("connected");
        // Mark session as connected (P2P unless a TURN relay is used)
        const turnServers = iceConfigRef.current?.iceServers.filter(
          (s) => Array.isArray(s.urls) ? s.urls.some((u) => typeof u === "string" && u.startsWith("turn")) : false
        ) ?? [];
        const connectionType = turnServers.length > 0 ? "P2P" : "P2P"; // WebRTC prefers P2P even with TURN available
        void api.patch(`/api/v1/video-chat/sessions/${sessId}`, {
          action: "connected",
          connectionType,
        });
      } else if (connState === "failed") {
        // Fatal — ICE/DTLS negotiation failed. Clear the timeout and
        // surface the error to the user.
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
          connectionTimeoutRef.current = null;
        }
        setState("failed");
        setError("Connection failed. The peer may have left.");
      } else if (connState === "closed") {
        // The PeerConnection was closed (either by us via cleanup or
        // by the peer). Clear the timeout. If we were connected, treat
        // as ended; otherwise treat as failed.
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
          connectionTimeoutRef.current = null;
        }
        setState((prev) =>
          prev === "connected" || prev === "ended" ? "ended" : "failed"
        );
      }
      // NOTE: "disconnected" is intentionally NOT handled here — WebRTC
      // can recover from it. If it doesn't, "failed" will fire later.
    };

    // If offerer, create the offer.
    // FIX: previously the offer POST was outside a try/catch — a failure
    // here would throw and propagate up to startQueuePolling's
    // `void initWebRTC(...)` (the `void` discards the rejection).
    // Now wrapped in try/catch + transitions to failed with a
    // user-friendly message.
    if (offerer) {
      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        debugLog(debugLoggingRef, "offer created", { sessionId: sessId.slice(-6) });
        await api.post("/api/v1/video-chat/signal", {
          sessionId: sessId,
          type: "offer",
          payload: offer,
        });
        debugLog(debugLoggingRef, "offer sent", { sessionId: sessId.slice(-6) });
      } catch (err) {
        debugError(debugLoggingRef, "offer creation/sending failed", {
          sessionId: sessId.slice(-6),
          error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
        });
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
          connectionTimeoutRef.current = null;
        }
        setError("Unable to establish video connection. Please try again.");
        setState("failed");
        return;
      }
    }

    // ── Defensive 30s connection timeout (Connection Reliability) ────
    // Cleared by onconnectionstatechange on connected/failed/closed,
    // and by cleanup(). If we don't reach "connected" within 30s, we
    // force-fail so the user is not stuck on "Connecting..." forever.
    //
    // FIX: with the throw-based guard above, this timeout is guaranteed
    // to be set whenever a PC is successfully created. The error
    // message is user-friendly.
    if (connectionTimeoutRef.current) clearTimeout(connectionTimeoutRef.current);
    connectionTimeoutRef.current = setTimeout(() => {
      const currentPc = pcRef.current;
      if (!currentPc) return; // PC was closed via cleanup — no-op.
      if (currentPc.connectionState !== "connected") {
        debugError(debugLoggingRef, "connection timeout", {
          connectionState: currentPc.connectionState,
          signalingState: currentPc.signalingState,
          iceConnectionState: currentPc.iceConnectionState,
          sessionId: sessId.slice(-6),
        });
        setError("Unable to establish video connection. Please try again.");
        setState("failed");
      }
    }, 30_000);

    // Start polling for signals
    startSignalPolling(sessId);
  }, []);

  // Assign initWebRTC to the forward-declared ref so the earlier
  // startCall + startQueuePolling closures can `await initWebRTCRef.current(...)`
  // + catch rejections. Done in a useEffect to satisfy the React 19
  // `react-hooks/refs` rule (no ref writes during render). The ref is
  // updated after every render that changes `initWebRTC`.
  useEffect(() => {
    initWebRTCRef.current = initWebRTC;
  }, [initWebRTC]);

  // ── Signal polling (every 500ms for low latency) ───────────────────
  // Connection Reliability:
  //   - Each signal is processed in its OWN try/catch so a failure in
  //     one signal does NOT stop the rest of the batch.
  //   - The outer try/catch only catches the HTTP fetch itself (network
  //     error) — the polling loop keeps running.
  //   - ICE candidates that arrive before setRemoteDescription are
  //     buffered in pendingIceCandidatesRef and flushed atomically
  //     after the offer/answer is set.
  //   - Offer handling is atomic: setRemoteDescription → flush queue →
  //     createAnswer → setLocalDescription → POST answer. If any step
  //     fails, the error is logged (dev only, safe info) and the call
  //     is marked failed — we don't leave the caller waiting forever.
  //   - Answer handling checks pc.signalingState === "have-local-offer"
  //     first; if not, the answer is stale (already applied or
  //     unexpected) and we just log + skip.
  const startSignalPolling = useCallback((sessId: string) => {
    if (signalPollRef.current) clearInterval(signalPollRef.current);
    signalPollRef.current = setInterval(async () => {
      // Outer try/catch ONLY for the HTTP fetch. If the fetch fails,
      // we keep polling — the next tick may succeed.
      let result: { signals: SignalPayload[] };
      try {
        result = await api.get<{ signals: SignalPayload[] }>(
          `/api/v1/video-chat/signal?sessionId=${sessId}`
        );
      } catch (err) {
        // Network error — keep polling. Don't swallow silently: log
        // the error name + message (gated by debugLogging — no SDP /
        // no tokens / no ICE payloads).
        debugError(debugLoggingRef, "signal fetch failed", {
          sessionId: sessId.slice(-6),
          error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
        });
        return;
      }

      for (const signal of result.signals) {
        const pc = pcRef.current;
        if (!pc) continue;

        // Per-signal try/catch — a failure here does NOT stop the
        // remaining signals in this batch, and does NOT kill the
        // polling loop.
        try {
          if (signal.type === "offer") {
            // Atomic offer handling:
            //   1. setRemoteDescription(offer)
            //   2. flush queued ICE candidates
            //   3. createAnswer()
            //   4. setLocalDescription(answer)
            //   5. POST answer to peer
            // If any step throws, we log + mark the call as failed —
            // we do NOT continue silently (that would leave the caller
            // waiting for an answer that will never come).
            await pc.setRemoteDescription(
              signal.payload as RTCSessionDescriptionInit
            );
            // Flush any ICE candidates that arrived before the offer.
            const queued = pendingIceCandidatesRef.current;
            pendingIceCandidatesRef.current = [];
            for (const candidate of queued) {
              try {
                await pc.addIceCandidate(candidate);
              } catch (err) {
                debugError(debugLoggingRef, "queued addIceCandidate failed (offer-flush)", {
                  sessionId: sessId.slice(-6),
                  error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
                });
              }
            }
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            await api.post("/api/v1/video-chat/signal", {
              sessionId: sessId,
              type: "answer",
              payload: answer,
            });
          } else if (signal.type === "answer") {
            // Only apply the answer if we are in "have-local-offer"
            // state. If the state is "stable", we already applied it
            // (duplicate signal — rare but possible with polling).
            // If the state is anything else, the answer is stale.
            if (pc.signalingState === "have-local-offer") {
              await pc.setRemoteDescription(
                signal.payload as RTCSessionDescriptionInit
              );
              // Flush queued ICE candidates that arrived before the answer.
              const queued = pendingIceCandidatesRef.current;
              pendingIceCandidatesRef.current = [];
              for (const candidate of queued) {
                try {
                  await pc.addIceCandidate(candidate);
                } catch (err) {
                  debugError(debugLoggingRef, "queued addIceCandidate failed (answer-flush)", {
                    sessionId: sessId.slice(-6),
                    error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
                  });
                }
              }
            } else {
              debugLog(debugLoggingRef, "skipping stale answer", {
                sessionId: sessId.slice(-6),
                signalingState: pc.signalingState,
              });
            }
          } else if (signal.type === "ice") {
            // If we haven't set the remote description yet, queue the
            // candidate. addIceCandidate throws InvalidStateError if
            // called before setRemoteDescription.
            if (!pc.remoteDescription) {
              pendingIceCandidatesRef.current.push(
                signal.payload as RTCIceCandidateInit
              );
            } else {
              try {
                await pc.addIceCandidate(
                  signal.payload as RTCIceCandidateInit
                );
              } catch (err) {
                debugError(debugLoggingRef, "addIceCandidate failed", {
                  sessionId: sessId.slice(-6),
                  error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
                });
                // Don't kill the polling loop — one bad candidate is
                // not fatal. Other candidates + the offer/answer may
                // still succeed.
              }
            }
          } else if (signal.type === "end") {
            setState("ended");
            setError("The other user has left.");
            if (signalPollRef.current) clearInterval(signalPollRef.current);
          }
        } catch (err) {
          // Per-signal error — log safely (no SDP / no payload) and
          // continue with the next signal in the batch. The polling
          // loop is NOT killed.
          debugError(debugLoggingRef, `signal "${signal.type}" failed`, {
            sessionId: sessId.slice(-6),
            error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
          });
          // If this was an offer/answer failure, the negotiation is
          // stuck — mark the call as failed so the user is not left
          // on "Connecting..." forever. ICE failures are non-fatal
          // (handled above).
          if (signal.type === "offer" || signal.type === "answer") {
            if (connectionTimeoutRef.current) {
              clearTimeout(connectionTimeoutRef.current);
              connectionTimeoutRef.current = null;
            }
            setError("Unable to establish video connection. Please try again.");
            setState("failed");
          }
        }
      }
    }, 500);
  }, []);

  // ── Next: end current call + start a new one ───────────────────────
  const handleNext = useCallback(async () => {
    // End the current session
    if (sessionId) {
      try {
        await api.post("/api/v1/video-chat/signal", {
          sessionId,
          type: "end",
          payload: {},
        });
        await api.patch(`/api/v1/video-chat/sessions/${sessionId}`, {
          action: "end",
          endReason: "user_next",
        });
      } catch {
        // Non-fatal
      }
    }

    // Cleanup WebRTC
    if (signalPollRef.current) clearInterval(signalPollRef.current);
    if (connectionTimeoutRef.current) {
      clearTimeout(connectionTimeoutRef.current);
      connectionTimeoutRef.current = null;
    }
    pendingIceCandidatesRef.current = [];
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }

    setSessionId(null);
    setPeer(null);
    setState("idle");

    // Re-join the queue (reuse the existing local stream)
    setTimeout(() => void startCall(), 300);
  }, [sessionId, startCall]);

  // ── Leave: full cleanup + return to idle ───────────────────────────
  const handleLeave = useCallback(async () => {
    if (sessionId) {
      try {
        await api.post("/api/v1/video-chat/signal", {
          sessionId,
          type: "end",
          payload: {},
        });
        await api.patch(`/api/v1/video-chat/sessions/${sessionId}`, {
          action: "end",
          endReason: "user_left",
        });
      } catch {
        // Non-fatal
      }
    }
    await cleanup();
    setSessionId(null);
    setPeer(null);
    setState("idle");
    router.push("/");
  }, [sessionId, cleanup, router]);

  // ── Camera toggle ──────────────────────────────────────────────────
  const toggleCamera = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const videoTrack = stream.getVideoTracks()[0];
    if (videoTrack) {
      videoTrack.enabled = !videoTrack.enabled;
      setCameraOn(videoTrack.enabled);
    }
  }, []);

  // ── Mic toggle ─────────────────────────────────────────────────────
  const toggleMic = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const audioTrack = stream.getAudioTracks()[0];
    if (audioTrack) {
      audioTrack.enabled = !audioTrack.enabled;
      setMicOn(audioTrack.enabled);
    }
  }, []);

  // ── Report ─────────────────────────────────────────────────────────
  const handleReport = useCallback(async (reason: string, description: string) => {
    if (!sessionId || !peer) return;
    try {
      await api.post("/api/v1/video-chat/reports", {
        sessionId,
        reportedId: peer.id,
        reason,
        description: description || undefined,
      });
      toast.success("Report submitted. Thank you.");
      setReportDialogOpen(false);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to submit report.");
    }
  }, [sessionId, peer]);

  // ── Render ─────────────────────────────────────────────────────────
  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="flex h-14 items-center justify-between border-b px-4">
        <h1 className="flex items-center gap-2 text-lg font-bold">
          <Video className="h-5 w-5 text-primary" />
          Centry Video Chat
        </h1>
        <Button variant="ghost" size="sm" onClick={() => router.push("/")}>
          <LogOut className="mr-2 h-4 w-4" />
          Exit
        </Button>
      </header>

      {/* Main content */}
      <main className="flex flex-1 flex-col items-center justify-center p-4">
        {state === "idle" && (
          <IdleView
            onStart={startCall}
            desiredGender={desiredGender}
            setDesiredGender={setDesiredGender}
            desiredCountry={desiredCountry}
            setDesiredCountry={setDesiredCountry}
          />
        )}

        {state === "searching" && (
          <SearchingView
            onCancel={handleLeave}
            desiredGender={desiredGender}
            desiredCountry={desiredCountry}
          />
        )}

        {(state === "matched" || state === "connecting" || state === "connected" || state === "ended" || state === "failed") && (
          <CallView
            state={state}
            peer={peer}
            localVideoRef={localVideoRef}
            remoteVideoRef={remoteVideoRef}
            cameraOn={cameraOn}
            micOn={micOn}
            error={error}
            onToggleCamera={toggleCamera}
            onToggleMic={toggleMic}
            onNext={handleNext}
            onLeave={handleLeave}
            onReport={() => setReportDialogOpen(true)}
          />
        )}
      </main>

      {/* Report dialog */}
      {reportDialogOpen && (
        <ReportDialog
          peerName={peer?.fullName ?? "the user"}
          onSubmit={handleReport}
          onCancel={() => setReportDialogOpen(false)}
        />
      )}
    </div>
  );
}

// ── Sub-views ──────────────────────────────────────────────────────────

function IdleView({
  onStart, desiredGender, setDesiredGender, desiredCountry, setDesiredCountry,
}: {
  onStart: () => void;
  desiredGender: "ANY" | "MALE" | "FEMALE";
  setDesiredGender: (g: "ANY" | "MALE" | "FEMALE") => void;
  desiredCountry: string;
  setDesiredCountry: (c: string) => void;
}) {
  return (
    <div className="flex max-w-md flex-col items-center gap-6 text-center">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
        <Video className="h-10 w-10 text-primary" />
      </div>
      <div>
        <h2 className="text-2xl font-bold">Global Video Chat</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Connect with someone anywhere in the world via direct peer-to-peer video.
          Your video stays between you and the other person — Centry never records or stores it.
        </p>
      </div>

      {/* Matchmaking preferences */}
      <div className="w-full space-y-4 rounded-lg border p-4 text-left">
        <div>
          <label className="mb-1.5 block text-sm font-medium">Who do you want to talk to?</label>
          <select
            value={desiredGender}
            onChange={(e) => setDesiredGender(e.target.value as "ANY" | "MALE" | "FEMALE")}
            className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
          >
            <option value="ANY">Anyone</option>
            <option value="FEMALE">Female</option>
            <option value="MALE">Male</option>
          </select>
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium">Where do you want to meet someone?</label>
          <select
            value={desiredCountry}
            onChange={(e) => setDesiredCountry(e.target.value)}
            className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
          >
            <option value="WORLDWIDE">🌍 Worldwide</option>
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.flag} {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <Button size="lg" onClick={onStart} className="w-full">
        <Video className="mr-2 h-5 w-5" />
        Start Video Chat
      </Button>
      <p className="text-xs text-muted-foreground">
        By starting, you agree to use video chat responsibly. Camera + microphone access required.
      </p>
    </div>
  );
}

function SearchingView({
  onCancel, desiredGender, desiredCountry,
}: {
  onCancel: () => void;
  desiredGender: "ANY" | "MALE" | "FEMALE";
  desiredCountry: string;
}) {
  const genderLabel = desiredGender === "ANY" ? "Anyone" : desiredGender === "MALE" ? "Male" : "Female";
  const countryLabel = desiredCountry === "WORLDWIDE"
    ? "🌍 Worldwide"
    : `${getCountryFlag(desiredCountry)} ${getCountryName(desiredCountry)}`;

  return (
    <div className="flex max-w-md flex-col items-center gap-6 text-center">
      <Loader2 className="h-12 w-12 animate-spin text-primary" />
      <div>
        <h2 className="text-xl font-bold">Looking for someone...</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Searching for a compatible partner.
        </p>
      </div>

      {/* Show the active filters so the user knows what they're searching for */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        <Badge variant="outline" className="text-sm">{genderLabel}</Badge>
        <Badge variant="outline" className="text-sm">{countryLabel}</Badge>
      </div>

      <p className="text-xs text-muted-foreground">
        No exact match yet? Keep waiting or cancel to change your filters.
      </p>

      <Button variant="outline" onClick={onCancel}>
        Cancel
      </Button>
    </div>
  );
}

function CallView({
  state, peer, localVideoRef, remoteVideoRef, cameraOn, micOn, error,
  onToggleCamera, onToggleMic, onNext, onLeave, onReport,
}: {
  state: CallState;
  peer: Peer | null;
  localVideoRef: React.RefObject<HTMLVideoElement | null>;
  remoteVideoRef: React.RefObject<HTMLVideoElement | null>;
  cameraOn: boolean;
  micOn: boolean;
  error: string | null;
  onToggleCamera: () => void;
  onToggleMic: () => void;
  onNext: () => void;
  onLeave: () => void;
  onReport: () => void;
}) {
  return (
    <div className="flex w-full max-w-4xl flex-col gap-4">
      {/* Connection status banner */}
      {state === "connecting" && (
        <div className="flex items-center justify-center gap-2 rounded-lg bg-yellow-500/10 p-3 text-sm text-yellow-600 dark:text-yellow-400">
          <Loader2 className="h-4 w-4 animate-spin" />
          Connecting...
        </div>
      )}
      {state === "connected" && (
        <div className="flex items-center justify-center gap-2 rounded-lg bg-green-500/10 p-3 text-sm text-green-600 dark:text-green-400">
          Connected — P2P
        </div>
      )}
      {error && (
        <div className="flex items-center justify-center gap-2 rounded-lg bg-red-500/10 p-3 text-sm text-red-600 dark:text-red-400">
          <ShieldOff className="h-4 w-4" />
          {error}
        </div>
      )}

      {/* Remote video (main) */}
      {/* PHASE 3 FIX (R3 — broken PiP layout):
          The local PiP used to be a SIBLING of this remote video container,
          positioned `absolute bottom-24 right-4`. Because siblings are NOT
          ancestors in CSS, the PiP's positioning context was the viewport
          (no `relative` ancestor above it) — so the PiP floated at the
          bottom-right of the SCREEN, not the remote video. On mobile, the
          PiP's 128px height + 96px bottom offset extended off-screen
          entirely.

          The fix: make the PiP a CHILD of the remote video container, in
          the top-right corner, with responsive sizes that scale smoothly
          across breakpoints. Since the PiP is now inside the remote
          container (which has `overflow-hidden`), the PiP will NOT be
          clipped as long as its size + position stay within the container
          bounds — which they always do because the PiP is small relative
          to the 16:9 remote video at any width. */}
      <div className="relative aspect-video w-full overflow-hidden rounded-xl bg-black">
        <video
          ref={remoteVideoRef}
          autoPlay
          playsInline
          className="h-full w-full object-cover"
        />
        {peer && (
          <div className="absolute left-3 top-3 flex items-center gap-2 rounded-lg bg-black/50 px-3 py-1.5 text-white">
            <span className="text-sm font-medium">{peer.fullName}</span>
            {peer.isVerified && <Badge variant="secondary">Verified</Badge>}
          </div>
        )}
        {(state === "connecting" || state === "matched") && !error && (
          <div className="absolute inset-0 flex items-center justify-center text-white">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        )}

        {/* Local video (picture-in-picture) — child of remote container.
            Sizes scale smoothly: mobile h-24 w-32, sm h-32 w-44, md h-40 w-56.
            Offset: top-2 right-2 (8px from top-right corner) — always
            within the remote video's bounds, never clipped. */}
        <div className="absolute right-2 top-2 h-24 w-32 overflow-hidden rounded-lg border-2 border-white/40 bg-black shadow-lg sm:h-32 sm:w-44 md:h-40 md:w-56">
          <video
            ref={localVideoRef}
            autoPlay
            playsInline
            muted
            className="h-full w-full object-cover"
          />
          {!cameraOn && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/70 text-white">
              <VideoOff className="h-6 w-6" />
            </div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-2 rounded-xl border bg-card p-3">
        <Button
          variant={micOn ? "outline" : "destructive"}
          size="icon"
          onClick={onToggleMic}
          aria-label={micOn ? "Mute microphone" : "Unmute microphone"}
        >
          {micOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
        </Button>
        <Button
          variant={cameraOn ? "outline" : "destructive"}
          size="icon"
          onClick={onToggleCamera}
          aria-label={cameraOn ? "Turn off camera" : "Turn on camera"}
        >
          {cameraOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={onReport}
          aria-label="Report user"
          disabled={!peer}
        >
          <Flag className="h-5 w-5" />
        </Button>
        <Button
          variant="default"
          onClick={onNext}
          className="mx-2"
          disabled={state !== "connected"}
        >
          <SkipForward className="mr-2 h-4 w-4" />
          Next
        </Button>
        <Button
          variant="destructive"
          size="icon"
          onClick={onLeave}
          aria-label="Leave call"
        >
          <PhoneOff className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}

// ── Report Dialog ──────────────────────────────────────────────────────

function ReportDialog({
  peerName, onSubmit, onCancel,
}: {
  peerName: string;
  onSubmit: (reason: string, description: string) => void;
  onCancel: () => void;
}) {
  const [reason, setReason] = useState("HARASSMENT");
  const [description, setDescription] = useState("");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-lg border bg-card p-6 shadow-lg">
        <h3 className="text-lg font-bold">Report {peerName}</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Help us keep Centry safe. Reports are reviewed by our moderation team.
        </p>
        <div className="mt-4 space-y-3">
          <div>
            <label className="text-sm font-medium">Reason</label>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="mt-1 h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
            >
              <option value="HARASSMENT">Harassment</option>
              <option value="NUDITY">Nudity / Sexual content</option>
              <option value="HATE">Hate / Abusive behavior</option>
              <option value="SPAM">Spam</option>
              <option value="SCAM">Scam</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div>
            <label className="text-sm font-medium">Description (optional)</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={1000}
              rows={3}
              className="mt-1 w-full rounded-md border border-input bg-background p-2 text-sm"
              placeholder="Add details..."
            />
          </div>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button variant="destructive" onClick={() => onSubmit(reason, description)}>
            Submit Report
          </Button>
        </div>
      </div>
    </div>
  );
}
