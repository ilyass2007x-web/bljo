"use client";

import { useRouter } from "next/navigation";
import { Hash, Users } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { TopicFollowButton } from "./topic-follow-button";
import { cn } from "@/lib/utils";

interface TopicCardDTO {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  followerCount: number;
  isFollowed: boolean | null;
}

interface TopicCardProps {
  topic: TopicCardDTO;
  /** Layout variant — "compact" for horizontal lists, "default" for grids. */
  variant?: "default" | "compact";
  className?: string;
}

/**
 * TopicCard — reusable card showing a topic's name + description + follower
 * count + follow button. Clicking the card (not the button) navigates to
 * the topic page.
 */
export function TopicCard({ topic, variant = "default", className }: TopicCardProps) {
  const router = useRouter();

  return (
    <div
      className={cn(
        "rounded-xl border bg-card text-card-foreground shadow-sm hover:shadow-md transition-shadow cursor-pointer",
        variant === "compact" ? "p-3 flex items-center gap-3" : "p-4",
        className
      )}
      onClick={() => router.push(`/topics/${encodeURIComponent(topic.slug)}`)}
    >
      {variant === "compact" ? (
        <>
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Hash className="h-5 w-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-medium truncate">{topic.name}</div>
            {topic.followerCount > 0 && (
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                <Users className="h-3 w-3" />
                {formatCount(topic.followerCount)}
              </div>
            )}
          </div>
          {topic.isFollowed !== null && (
            <TopicFollowButton
              topicSlug={topic.slug}
              topicName={topic.name}
              isFollowed={topic.isFollowed === true}
              size="sm"
              showLabel={false}
              showHashIcon={false}
            />
          )}
        </>
      ) : (
        <>
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Hash className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold leading-tight">{topic.name}</h3>
                {topic.followerCount > 0 && (
                  <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                    <Users className="h-3 w-3" />
                    {formatCount(topic.followerCount)} followers
                  </div>
                )}
              </div>
            </div>
          </div>
          {topic.description && (
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
              {topic.description}
            </p>
          )}
          {topic.isFollowed !== null && (
            <TopicFollowButton
              topicSlug={topic.slug}
              topicName={topic.name}
              isFollowed={topic.isFollowed === true}
              size="sm"
              showHashIcon={false}
            />
          )}
        </>
      )}
    </div>
  );
}

function formatCount(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
  return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
}
