"use client";

import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { UserPlus, UserCheck, Loader2, Hash } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface TopicFollowButtonProps {
  topicSlug: string;
  topicName: string;
  isFollowed: boolean;
  size?: "sm" | "md";
  onStateChange?: (isFollowed: boolean) => void;
  className?: string;
  showLabel?: boolean;
  /** When true, shows the "#" prefix icon. Default true. */
  showHashIcon?: boolean;
}

/**
 * Reusable TopicFollowButton — follow/unfollow a topic.
 *
 * Mirrors the FollowButton pattern: optimistic UI, cross-component sync via
 * the `topic:follow:changed` window event, server-side reconciliation.
 *
 * Phase 2 — Topics system.
 */
export function TopicFollowButton({
  topicSlug,
  topicName,
  isFollowed: initialIsFollowed,
  size = "sm",
  onStateChange,
  className,
  showLabel = true,
  showHashIcon = true,
}: TopicFollowButtonProps) {
  const [isFollowed, setIsFollowed] = useState(initialIsFollowed);
  const [loading, setLoading] = useState(false);

  const handleToggle = useCallback(async () => {
    if (loading) return;
    setLoading(true);
    const wasFollowed = isFollowed;

    // Optimistic update.
    setIsFollowed(!wasFollowed);
    onStateChange?.(!wasFollowed);

    try {
      if (wasFollowed) {
        await api.delete(`/api/v1/topics/${encodeURIComponent(topicSlug)}/follow`);
        toast.success(`Unfollowed ${topicName}`);
      } else {
        await api.post(`/api/v1/topics/${encodeURIComponent(topicSlug)}/follow`);
        toast.success(`Following ${topicName}`);
      }

      // Dispatch a global event for cross-component sync.
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("topic:follow:changed", {
          detail: { topicSlug, isFollowed: !wasFollowed },
        }));
      }
    } catch (e) {
      // Rollback the optimistic update on failure.
      setIsFollowed(wasFollowed);
      onStateChange?.(wasFollowed);
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update follow");
    } finally {
      setLoading(false);
    }
  }, [loading, isFollowed, topicSlug, topicName, onStateChange]);

  return (
    <Button
      size={size === "sm" ? "sm" : "default"}
      variant={isFollowed ? "secondary" : "default"}
      onClick={handleToggle}
      disabled={loading}
      className={cn(className)}
    >
      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : isFollowed ? (
        <>
          <UserCheck className="h-4 w-4 mr-1" />
          {showLabel && "Following"}
        </>
      ) : (
        <>
          {showHashIcon ? (
            <Hash className="h-4 w-4 mr-1" />
          ) : (
            <UserPlus className="h-4 w-4 mr-1" />
          )}
          {showLabel && "Follow"}
        </>
      )}
    </Button>
  );
}
