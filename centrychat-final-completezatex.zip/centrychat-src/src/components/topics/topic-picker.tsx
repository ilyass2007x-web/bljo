"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, X, Check, Loader2, Sparkles, TrendingUp } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// ── Types ───────────────────────────────────────────────────────────────────

interface TopicDTO {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  isActive: boolean;
  followerCount: number;
  isFollowed: boolean | null;
  createdAt: string;
  updatedAt: string;
}

interface TopicPickerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Called when a topic is followed/unfollowed. */
  onFollowChange?: (topic: TopicDTO, isFollowed: boolean) => void;
  /** Initial list of followed topic IDs (skips re-fetching when provided). */
  initialFollowedIds?: Set<string>;
  /** Title for the dialog. */
  title?: string;
  /** Description for the dialog. */
  description?: string;
  /** When true, shows the "Recommended for you" section (requires auth). */
  showRecommended?: boolean;
}

// ── Component ───────────────────────────────────────────────────────────────

export function TopicPicker({
  open,
  onOpenChange,
  onFollowChange,
  title,
  description,
  showRecommended = true,
}: TopicPickerProps) {
  const router = useRouter();
  const { user } = useAuthStore();
  const { t } = useTranslation();

  // ── State ────────────────────────────────────────────────────────────
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<TopicDTO[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [popularTopics, setPopularTopics] = useState<TopicDTO[]>([]);
  const [trendingTopics, setTrendingTopics] = useState<TopicDTO[]>([]);
  const [recommendedTopics, setRecommendedTopics] = useState<TopicDTO[]>([]);
  const [loadingPopular, setLoadingPopular] = useState(true);
  const [followLoadingIds, setFollowLoadingIds] = useState<Set<string>>(new Set());

  // Debounce ref for search.
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── Load popular + trending + recommended on open ───────────────────
  useEffect(() => {
    if (!open) return;
    setLoadingPopular(true);
    (async () => {
      try {
        const [popular, trending] = await Promise.all([
          api.get<{ topics: TopicDTO[] }>("/api/v1/topics?sort=popular&limit=12"),
          api.get<{ topics: TopicDTO[] }>("/api/v1/topics?view=trending&limit=6"),
        ]);
        setPopularTopics(popular.topics);
        setTrendingTopics(trending.topics);
      } catch (e) {
        // Silent — the picker still works with search alone.
        console.warn("Failed to load popular topics:", e);
      } finally {
        setLoadingPopular(false);
      }
    })();

    // Load recommended only when authenticated + showRecommended is true.
    if (showRecommended && user) {
      api.get<{ topics: TopicDTO[] }>("/api/v1/topics?view=recommended&limit=6")
        .then((res) => setRecommendedTopics(res.topics))
        .catch(() => setRecommendedTopics([]));
    }
  }, [open, user, showRecommended]);

  // ── Debounced search ─────────────────────────────────────────────────
  const doSearch = useCallback((q: string) => {
    if (q.trim().length < 2) {
      setSearchResults([]);
      setSearchLoading(false);
      return;
    }
    setSearchLoading(true);
    api.get<{ topics: TopicDTO[] }>(`/api/v1/topics?search=${encodeURIComponent(q)}&limit=20`)
      .then((res) => setSearchResults(res.topics))
      .catch(() => setSearchResults([]))
      .finally(() => setSearchLoading(false));
  }, []);

  useEffect(() => {
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    if (searchQuery.trim().length < 2) {
      setSearchResults([]);
      setSearchLoading(false);
      return;
    }
    searchDebounceRef.current = setTimeout(() => doSearch(searchQuery), 300);
    return () => {
      if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    };
  }, [searchQuery, doSearch]);

  // ── Follow / Unfollow ────────────────────────────────────────────────
  const toggleFollow = useCallback(async (topic: TopicDTO) => {
    const isFollowed = topic.isFollowed === true;
    setFollowLoadingIds((prev) => new Set(prev).add(topic.id));
    try {
      if (isFollowed) {
        await api.delete(`/api/v1/topics/${encodeURIComponent(topic.slug)}/follow`);
        toast.success(`Unfollowed ${topic.name}`);
      } else {
        await api.post(`/api/v1/topics/${encodeURIComponent(topic.slug)}/follow`);
        toast.success(`Following ${topic.name}`);
      }

      // Optimistic update across ALL lists (popular + trending + recommended + search).
      const updatedTopic = { ...topic, isFollowed: !isFollowed };
      const updateFn = (t: TopicDTO) => (t.id === topic.id ? updatedTopic : t);
      setPopularTopics((prev) => prev.map(updateFn));
      setTrendingTopics((prev) => prev.map(updateFn));
      setRecommendedTopics((prev) => prev.map(updateFn));
      setSearchResults((prev) => prev.map(updateFn));

      onFollowChange?.(updatedTopic, !isFollowed);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to update follow");
    } finally {
      setFollowLoadingIds((prev) => {
        const next = new Set(prev);
        next.delete(topic.id);
        return next;
      });
    }
  }, [onFollowChange]);

  const isSearching = searchQuery.trim().length >= 2;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col gap-4 p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b">
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            {title ?? "Discover Topics"}
          </DialogTitle>
          <DialogDescription>
            {description ?? "Follow topics you're interested in to personalize your feed."}
          </DialogDescription>
        </DialogHeader>

        {/* Search input */}
        <div className="px-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              autoFocus
              placeholder="Search topics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-9"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                aria-label="Clear search"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        <ScrollArea className="flex-1 px-6 pb-6">
          {/* Search results — shown when searching */}
          {isSearching ? (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground">
                Search results
              </h3>
              {searchLoading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : searchResults.length === 0 ? (
                <div className="text-sm text-muted-foreground py-8 text-center">
                  No topics found. Try a different search term.
                </div>
              ) : (
                <div className="space-y-2">
                  {searchResults.map((topic) => (
                    <TopicRow
                      key={topic.id}
                      topic={topic}
                      onToggle={toggleFollow}
                      loading={followLoadingIds.has(topic.id)}
                    />
                  ))}
                </div>
              )}
            </div>
          ) : (
            // Default view: trending + recommended + popular
            <div className="space-y-6">
              {/* Trending */}
              {trendingTopics.length > 0 && (
                <section>
                  <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-1.5">
                    <TrendingUp className="h-4 w-4" />
                    Trending now
                  </h3>
                  <div className="space-y-2">
                    {trendingTopics.map((topic) => (
                      <TopicRow
                        key={topic.id}
                        topic={topic}
                        onToggle={toggleFollow}
                        loading={followLoadingIds.has(topic.id)}
                      />
                    ))}
                  </div>
                </section>
              )}

              {/* Recommended (auth only) */}
              {showRecommended && user && recommendedTopics.length > 0 && (
                <section>
                  <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-1.5">
                    <Sparkles className="h-4 w-4" />
                    Recommended for you
                  </h3>
                  <div className="space-y-2">
                    {recommendedTopics.map((topic) => (
                      <TopicRow
                        key={topic.id}
                        topic={topic}
                        onToggle={toggleFollow}
                        loading={followLoadingIds.has(topic.id)}
                      />
                    ))}
                  </div>
                </section>
              )}

              {/* Popular */}
              <section>
                <h3 className="text-sm font-semibold text-muted-foreground mb-3">
                  Popular topics
                </h3>
                {loadingPopular ? (
                  <div className="space-y-2">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : popularTopics.length === 0 ? (
                  <div className="text-sm text-muted-foreground py-8 text-center">
                    No topics yet. Check back later.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {popularTopics.map((topic) => (
                      <TopicRow
                        key={topic.id}
                        topic={topic}
                        onToggle={toggleFollow}
                        loading={followLoadingIds.has(topic.id)}
                      />
                    ))}
                  </div>
                )}
              </section>
            </div>
          )}
        </ScrollArea>

        {/* Footer — Done button */}
        <div className="border-t px-6 py-4 flex justify-between items-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push("/?view=topics")}
          >
            Browse all topics
          </Button>
          <Button onClick={() => onOpenChange(false)}>Done</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ── TopicRow — a single topic row in the picker ─────────────────────────────

function TopicRow({
  topic,
  onToggle,
  loading,
}: {
  topic: TopicDTO;
  onToggle: (topic: TopicDTO) => void;
  loading: boolean;
}) {
  const isFollowed = topic.isFollowed === true;
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border p-3 hover:bg-accent/50 transition-colors">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h4 className="font-medium truncate">{topic.name}</h4>
          {topic.followerCount > 0 && (
            <Badge variant="secondary" className="text-[10px] font-normal">
              {formatCount(topic.followerCount)}
            </Badge>
          )}
        </div>
        {topic.description && (
          <p className="text-xs text-muted-foreground truncate mt-0.5">
            {topic.description}
          </p>
        )}
      </div>
      <Button
        size="sm"
        variant={isFollowed ? "secondary" : "default"}
        onClick={() => onToggle(topic)}
        disabled={loading}
        className="shrink-0"
      >
        {loading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : isFollowed ? (
          <>
            <Check className="h-4 w-4 mr-1" />
            Following
          </>
        ) : (
          "Follow"
        )}
      </Button>
    </div>
  );
}

function formatCount(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
  return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
}
