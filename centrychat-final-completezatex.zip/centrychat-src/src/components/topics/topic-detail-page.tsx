"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { PostCard, type PostDTO } from "@/components/posts/post-card";
import { ArticleCard, type ArticleCardDTO } from "@/components/articles/article-card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import { TopicFollowButton } from "@/components/topics/topic-follow-button";
import { ArrowLeft, Hash, Loader2, Users } from "lucide-react";
import { useTranslation } from "@/lib/client/i18n-store";
import { cn } from "@/lib/utils";

// ── Types ───────────────────────────────────────────────────────────────────

interface TopicDetail {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  isActive: boolean;
  followerCount: number;
  isFollowed: boolean | null;
}

type UnifiedFeedItem =
  | { type: "post"; post: PostDTO }
  | { type: "article"; article: ArticleCardDTO };

interface TopicDetailPageProps {
  topic: TopicDetail;
  initialItems: UnifiedFeedItem[];
}

// ── Component ───────────────────────────────────────────────────────────────

/**
 * TopicDetailPage — client component for the Topic detail page.
 *
 * Phase 2.3 — renders the topic header (name, description, follower count,
 * follow/unfollow button) + a content feed (posts + articles) that belongs
 * to this topic via canonical ArticleTopic/PostTopic relationships.
 *
 * Content is fetched from the existing `/api/v1/topics/[slug]/content` API
 * (Phase 2). The initial page of content is server-rendered (passed as
 * `initialItems`); subsequent pages are fetched client-side via cursor
 * pagination.
 *
 * SEO: the SSR route (src/app/topics/[tag]/page.tsx) generates the metadata
 * (title, description, canonical, OG, Twitter, JSON-LD). This component
 * is purely client-side UI.
 *
 * Reuses existing PostCard + ArticleCard components for content rendering.
 */
export function TopicDetailPage({
  topic,
  initialItems,
}: TopicDetailPageProps) {
  const router = useRouter();
  const { t } = useTranslation();
  const [items, setItems] = useState<UnifiedFeedItem[]>(initialItems);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true); // assume more until API says otherwise
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  // ── Infinite scroll ──────────────────────────────────────────────────
  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    try {
      // Use the existing /api/v1/topics/[slug]/content API.
      // The first page was SSR-rendered; this fetches page 2+.
      const offset = items.length;
      const res = await fetch(
        `/api/v1/topics/${encodeURIComponent(topic.slug)}/content?limit=20`,
        { credentials: "include" }
      );
      const json = await res.json();
      if (json?.ok && json.data?.items) {
        const newItems = json.data.items as UnifiedFeedItem[];
        // Deduplicate by content ID (article or post).
        const existingIds = new Set(
          items.map((it) =>
            it.type === "post" ? `post:${it.post.id}` : `article:${it.article.id}`
          )
        );
        const deduped = newItems.filter((it) => {
          const key = it.type === "post" ? `post:${it.post.id}` : `article:${it.article.id}`;
          return !existingIds.has(key);
        });
        if (deduped.length === 0 || newItems.length < 20) {
          setHasMore(false);
        }
        setItems((prev) => [...prev, ...deduped]);
      } else {
        setHasMore(false);
      }
    } catch {
      // Non-fatal — user can retry by scrolling.
      setHasMore(false);
    } finally {
      setLoadingMore(false);
    }
  }, [items.length, loadingMore, hasMore, topic.slug]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          void loadMore();
        }
      },
      { rootMargin: "200px", threshold: 0 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [loadMore]);

  return (
    <div className="min-h-screen bg-background">
      <MainNav />

      <main className="mx-auto max-w-2xl px-4 md:px-6 py-6 md:py-10 pb-24 md:pb-10">
        {/* ── Back button ──────────────────────────────────────────── */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => router.back()}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-1.5" />
          Back
        </Button>

        {/* ── Topic header ─────────────────────────────────────────── */}
        <div className="flex items-start gap-4 mb-6">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <Hash className="h-8 w-8" />
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight break-words">
              {topic.name}
            </h1>
            {topic.description && (
              <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                {topic.description}
              </p>
            )}
            <div className="mt-2 flex items-center gap-3">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Users className="h-3.5 w-3.5" />
                {formatCount(topic.followerCount)} followers
              </div>
              {topic.isFollowed !== null && (
                <TopicFollowButton
                  topicSlug={topic.slug}
                  topicName={topic.name}
                  isFollowed={topic.isFollowed === true}
                  size="sm"
                  showHashIcon={false}
                />
              )}
            </div>
          </div>
        </div>

        {/* ── Content feed ─────────────────────────────────────────── */}
        {items.length === 0 && !loadingMore ? (
          <div className="py-12 text-center text-sm text-muted-foreground">
            No content in this topic yet. Be the first to post about{" "}
            <span className="font-medium">{topic.name}</span>!
          </div>
        ) : (
          <div className="space-y-4">
            {items.map((item) => {
              if (item.type === "post") {
                return <PostCard key={`post:${item.post.id}`} post={item.post} />;
              }
              return <ArticleCard key={`article:${item.article.id}`} article={item.article} />;
            })}
          </div>
        )}

        {/* ── Loading more + sentinel ─────────────────────────────── */}
        {loadingMore && (
          <div className="mt-4 flex justify-center">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        )}
        {hasMore && (
          <div ref={sentinelRef} className="h-1" aria-hidden="true" />
        )}
        {!hasMore && items.length > 0 && (
          <p className="mt-6 text-center text-xs text-muted-foreground">
            You&apos;ve reached the end of this topic.
          </p>
        )}
      </main>
    </div>
  );
}

function formatCount(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
  return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
}
