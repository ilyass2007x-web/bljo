"use client";

import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, Search, X, Hash, AlertCircle } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { cn } from "@/lib/utils";

// ── Types ───────────────────────────────────────────────────────────────────

interface TopicOption {
  id: string;
  name: string;
  slug: string;
  description: string | null;
}

interface TopicSelectorProps {
  /** Currently selected topic IDs. */
  value: string[];
  /** Callback when the selection changes. */
  onChange: (topicIds: string[]) => void;
  /** Maximum number of selectable topics. Must match the server-side limit. */
  max?: number;
  /** Optional label for the field. */
  label?: string;
  /** Optional placeholder for the search input. */
  placeholder?: string;
  /** Optional className for the wrapper. */
  className?: string;
  /** Optional: when true, the selector is disabled. */
  disabled?: boolean;
}

// ── Component ───────────────────────────────────────────────────────────────

/**
 * TopicSelector — a reusable inline topic picker for content editors.
 *
 * Shows selected topics as removable badges + a search input that queries
 * the existing `GET /api/v1/topics?search=...` API (Phase 2).
 *
 * Features:
 *   - Multi-select with dedup (same topic can't be selected twice).
 *   - Max enforcement (default 5, matches Phase 2.1's MAX_TOPICS_PER_CONTENT).
 *   - Debounced search (300ms) — no request per keystroke.
 *   - Loading + error + empty states.
 *   - Keyboard accessible (Enter to select first result, Backspace to remove last).
 *   - Selected topic names resolved via a batched fetch on mount.
 *   - Mobile-friendly (no overflow, touch-friendly targets).
 *
 * Used by:
 *   - Article editor (create + edit)
 *   - Post composer (create)
 *   - Post card inline edit
 *
 * Security: the component only sends topic IDs to the parent's onChange.
 * The parent (Article/Post form) includes them in the API request body.
 * Server-side validation (Phase 2.1) is the source of truth — this UI
 * validation is defense-in-depth, NOT security.
 */
export function TopicSelector({
  value,
  onChange,
  max = 5,
  label = "Topics",
  placeholder = "Search topics...",
  className,
  disabled = false,
}: TopicSelectorProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<TopicOption[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedTopicMap, setSelectedTopicMap] = useState<Map<string, TopicOption>>(new Map());

  const containerRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isAtMax = value.length >= max;
  const canSelectMore = !isAtMax && !disabled;

  // ── Resolve selected topic names (batched fetch) ─────────────────────
  // When `value` changes (e.g. on edit-load), fetch the topic details
  // for any IDs we don't already have cached. This is 1 query per
  // unknown ID-set, debounced + deduped.
  useEffect(() => {
    const unknownIds = value.filter((id) => !selectedTopicMap.has(id));
    if (unknownIds.length === 0) return;

    let cancelled = false;
    (async () => {
      // Fetch each unknown topic by ID. The existing API doesn't have a
      // batch-by-IDs endpoint, so we fetch them individually. In practice
      // this runs at most `max` times (5) on edit-load, then the results
      // are cached for the component's lifetime.
      const results: TopicOption[] = [];
      for (const id of unknownIds) {
        try {
          // Try the slug-based endpoint — it also accepts IDs (see resolveTopic
          // in lib/topics/index.ts which falls back to ID lookup).
          const res = await api.get<{ topic: TopicOption }>(`/api/v1/topics/${encodeURIComponent(id)}`);
          if (res.topic) results.push(res.topic);
        } catch {
          // Topic may have been deleted/deactivated — skip silently.
        }
      }
      if (cancelled || results.length === 0) return;
      setSelectedTopicMap((prev) => {
        const next = new Map(prev);
        for (const t of results) next.set(t.id, t);
        return next;
      });
    })();

    return () => { cancelled = true; };
  }, [value, selectedTopicMap]);

  // ── Debounced search ─────────────────────────────────────────────────
  const doSearch = useCallback((q: string) => {
    if (q.trim().length < 2) {
      setSearchResults([]);
      setSearchLoading(false);
      setSearchError(null);
      return;
    }
    setSearchLoading(true);
    setSearchError(null);
    api.get<{ topics: TopicOption[] }>(
      `/api/v1/topics?search=${encodeURIComponent(q)}&limit=10`
    )
      .then((res) => {
        // Filter out already-selected topics from the results.
        const selectedSet = new Set(value);
        setSearchResults(res.topics.filter((t) => !selectedSet.has(t.id)));
        setHighlightedIndex(-1);
      })
      .catch((e) => {
        setSearchError(
          e instanceof ApiClientError ? e.message : "Unable to load topics. Please try again."
        );
        setSearchResults([]);
      })
      .finally(() => setSearchLoading(false));
  }, [value]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (searchQuery.trim().length < 2) {
      setSearchResults([]);
      setSearchLoading(false);
      return;
    }
    debounceRef.current = setTimeout(() => doSearch(searchQuery), 300);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [searchQuery, doSearch]);

  // ── Close dropdown when clicking outside ─────────────────────────────
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ── Handlers ─────────────────────────────────────────────────────────
  function selectTopic(topic: TopicOption) {
    if (!canSelectMore) return;
    if (value.includes(topic.id)) return; // dedup
    const newValue = [...value, topic.id];
    onChange(newValue);
    setSelectedTopicMap((prev) => {
      const next = new Map(prev);
      next.set(topic.id, topic);
      return next;
    });
    setSearchQuery(""); // clear search after selecting
    setShowDropdown(false);
    inputRef.current?.focus();
  }

  function removeTopic(topicId: string) {
    onChange(value.filter((id) => id !== topicId));
    // Keep the name in the map (in case the user re-adds it) — no harm.
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Backspace" && searchQuery === "" && value.length > 0) {
      // Remove the last selected topic on Backspace.
      e.preventDefault();
      removeTopic(value[value.length - 1]!);
    } else if (e.key === "ArrowDown" && searchResults.length > 0) {
      e.preventDefault();
      setHighlightedIndex((prev) =>
        prev < searchResults.length - 1 ? prev + 1 : 0
      );
    } else if (e.key === "ArrowUp" && searchResults.length > 0) {
      e.preventDefault();
      setHighlightedIndex((prev) =>
        prev > 0 ? prev - 1 : searchResults.length - 1
      );
    } else if (e.key === "Enter" && highlightedIndex >= 0 && searchResults[highlightedIndex]) {
      e.preventDefault();
      selectTopic(searchResults[highlightedIndex]!);
    } else if (e.key === "Escape") {
      setShowDropdown(false);
    }
  }

  // ── Render ────────────────────────────────────────────────────────────
  const showResults = showDropdown && searchQuery.trim().length >= 2;

  return (
    <div ref={containerRef} className={cn("space-y-2", className)}>
      {label && (
        <label className="text-sm font-medium text-foreground">
          {label}
          {value.length > 0 && (
            <span className="ml-2 text-xs text-muted-foreground">
              ({value.length}/{max})
            </span>
          )}
        </label>
      )}

      {/* Selected topics */}
      {value.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {value.map((topicId) => {
            const topic = selectedTopicMap.get(topicId);
            return (
              <Badge
                key={topicId}
                variant="secondary"
                className="pr-1.5 pl-2 py-1 text-xs gap-1"
              >
                <Hash className="h-3 w-3 text-muted-foreground" />
                {topic?.name ?? topicId}
                {!disabled && (
                  <button
                    type="button"
                    onClick={() => removeTopic(topicId)}
                    className="ml-0.5 rounded-full hover:bg-muted-foreground/20 p-0.5"
                    aria-label={`Remove ${topic?.name ?? topicId}`}
                  >
                    <X className="h-3 w-3" />
                  </button>
                )}
              </Badge>
            );
          })}
        </div>
      )}

      {/* Search input */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
        <Input
          ref={inputRef}
          type="text"
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setShowDropdown(true);
          }}
          onFocus={() => setShowDropdown(true)}
          onKeyDown={onKeyDown}
          placeholder={isAtMax ? `Maximum of ${max} topics selected` : placeholder}
          disabled={disabled || isAtMax}
          className="pl-9"
          aria-label={label}
          aria-expanded={showResults}
          aria-controls="topic-search-results"
          role="combobox"
          autoComplete="off"
        />
        {searchLoading && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
        )}
      </div>

      {/* Dropdown results */}
      {showResults && (
        <div
          id="topic-search-results"
          role="listbox"
          className="absolute z-50 mt-1 w-full max-w-md rounded-md border bg-popover shadow-md max-h-60 overflow-y-auto"
        >
          {searchError ? (
            <div className="p-3 text-sm text-destructive flex items-center gap-2">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {searchError}
            </div>
          ) : searchLoading ? (
            <div className="p-2 space-y-1">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-8 w-full" />
              ))}
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-3 text-sm text-muted-foreground text-center">
              No topics found.
            </div>
          ) : (
            searchResults.map((topic, idx) => (
              <button
                key={topic.id}
                type="button"
                role="option"
                aria-selected={idx === highlightedIndex}
                onClick={() => selectTopic(topic)}
                className={cn(
                  "flex w-full items-center gap-2 px-3 py-2 text-sm text-left hover:bg-accent transition-colors",
                  idx === highlightedIndex && "bg-accent"
                )}
              >
                <Hash className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{topic.name}</div>
                  {topic.description && (
                    <div className="text-xs text-muted-foreground truncate">
                      {topic.description}
                    </div>
                  )}
                </div>
              </button>
            ))
          )}
        </div>
      )}

      {/* Max hint */}
      {isAtMax && value.length > 0 && (
        <p className="text-xs text-muted-foreground">
          You've selected the maximum of {max} topics. Remove one to add another.
        </p>
      )}
    </div>
  );
}
