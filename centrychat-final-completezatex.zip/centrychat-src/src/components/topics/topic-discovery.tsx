"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { TopicCard } from "./topic-card";
import { TopicPicker } from "./topic-picker";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { Search, Sparkles, TrendingUp, Hash, Loader2 } from "lucide-react";

// ── Types ───────────────────────────────────────────────────────────────────

interface TopicDTO {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  isActive: boolean;
  followerCount: number;
  isFollowed: boolean | null;
  createdAt: string;
  updatedAt: string;
}

// ── Component ───────────────────────────────────────────────────────────────

export function TopicDiscoveryPage() {
  const router = useRouter();
  const { user } = useAuthStore();
  const { t } = useTranslation();

  const [activeTab, setActiveTab] = useState<string>("popular");
  const [popularTopics, setPopularTopics] = useState<TopicDTO[]>([]);
  const [trendingTopics, setTrendingTopics] = useState<TopicDTO[]>([]);
  const [recommendedTopics, setRecommendedTopics] = useState<TopicDTO[]>([]);
  const [followedTopics, setFollowedTopics] = useState<TopicDTO[]>([]);
  const [loading, setLoading] = useState(true);

  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<TopicDTO[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);

  const [pickerOpen, setPickerOpen] = useState(false);

  // ── Load all topic lists on mount ─────────────────────────────────
  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [popular, trending] = await Promise.all([
        api.get<{ topics: TopicDTO[] }>("/api/v1/topics?sort=popular&limit=24"),
        api.get<{ topics: TopicDTO[] }>("/api/v1/topics?view=trending&limit=12"),
      ]);
      setPopularTopics(popular.topics);
      setTrendingTopics(trending.topics);

      if (user) {
        const [recommended, followed] = await Promise.all([
          api.get<{ topics: TopicDTO[] }>("/api/v1/topics?view=recommended&limit=12")
            .catch(() => ({ topics: [] as TopicDTO[] })),
          // Followed topics — we filter the popular list (it includes isFollowed).
          Promise.resolve({ topics: popular.topics.filter((tp: TopicDTO) => tp.isFollowed === true) }),
        ]);
        setRecommendedTopics(recommended.topics);
        setFollowedTopics(followed.topics);
      }
    } catch (e) {
      console.warn("Failed to load topics:", e);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    void loadAll();
  }, [loadAll]);

  // ── Debounced search ──────────────────────────────────────────────
  useEffect(() => {
    if (searchQuery.trim().length < 2) {
      setSearchResults([]);
      setSearchLoading(false);
      return;
    }
    setSearchLoading(true);
    const timer = setTimeout(async () => {
      try {
        const res = await api.get<{ topics: TopicDTO[] }>(
          `/api/v1/topics?search=${encodeURIComponent(searchQuery)}&limit=20`
        );
        setSearchResults(res.topics);
      } catch {
        setSearchResults([]);
      } finally {
        setSearchLoading(false);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // ── Render ────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-background">
      <MainNav />

      <main className="mx-auto max-w-4xl px-4 md:px-6 py-6 md:py-10 pb-24 md:pb-10">
        {/* Header */}
        <div className="mb-6 flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
              Discover Topics
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Follow topics to personalize your feed.
            </p>
          </div>
          <Button
            variant="default"
            size="sm"
            onClick={() => setPickerOpen(true)}
            className="shrink-0"
          >
            <Sparkles className="h-4 w-4 mr-1.5" />
            Pick Topics
          </Button>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search topics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>

        {/* Search results (override tabs when searching) */}
        {searchQuery.trim().length >= 2 ? (
          <section>
            <h2 className="text-sm font-semibold text-muted-foreground mb-3">
              Search results for "{searchQuery}"
            </h2>
            {searchLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {[1, 2, 3, 4].map((i) => (
                  <Skeleton key={i} className="h-32 w-full rounded-xl" />
                ))}
              </div>
            ) : searchResults.length === 0 ? (
              <div className="text-sm text-muted-foreground py-8 text-center">
                No topics found. Try a different search.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {searchResults.map((topic) => (
                  <TopicCard key={topic.id} topic={topic} />
                ))}
              </div>
            )}
          </section>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="popular" className="flex items-center gap-1.5">
                <Hash className="h-3.5 w-3.5" />
                Popular
              </TabsTrigger>
              <TabsTrigger value="trending" className="flex items-center gap-1.5">
                <TrendingUp className="h-3.5 w-3.5" />
                Trending
              </TabsTrigger>
              {user && (
                <TabsTrigger value="recommended" className="flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5" />
                  For You
                </TabsTrigger>
              )}
              {user && followedTopics.length > 0 && (
                <TabsTrigger value="following">
                  Following
                </TabsTrigger>
              )}
            </TabsList>

            {/* Popular */}
            <TabsContent value="popular" className="mt-0">
              {loading ? (
                <LoadingGrid />
              ) : popularTopics.length === 0 ? (
                <EmptyState />
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {popularTopics.map((topic) => (
                    <TopicCard key={topic.id} topic={topic} />
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Trending */}
            <TabsContent value="trending" className="mt-0">
              {loading ? (
                <LoadingGrid />
              ) : trendingTopics.length === 0 ? (
                <EmptyState />
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {trendingTopics.map((topic) => (
                    <TopicCard key={topic.id} topic={topic} />
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Recommended (auth only) */}
            {user && (
              <TabsContent value="recommended" className="mt-0">
                {loading ? (
                  <LoadingGrid />
                ) : recommendedTopics.length === 0 ? (
                  <div className="text-sm text-muted-foreground py-8 text-center">
                    No recommendations yet. Interact with content to get
                    personalized recommendations.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {recommendedTopics.map((topic) => (
                      <TopicCard key={topic.id} topic={topic} />
                    ))}
                  </div>
                )}
              </TabsContent>
            )}

            {/* Following (auth only) */}
            {user && followedTopics.length > 0 && (
              <TabsContent value="following" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {followedTopics.map((topic) => (
                    <TopicCard key={topic.id} topic={topic} />
                  ))}
                </div>
              </TabsContent>
            )}
          </Tabs>
        )}
      </main>

      {/* Picker modal */}
      <TopicPicker
        open={pickerOpen}
        onOpenChange={setPickerOpen}
        onFollowChange={() => {
          // Reload when picker closes to reflect new follows.
          void loadAll();
        }}
      />
    </div>
  );
}

function LoadingGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <Skeleton key={i} className="h-32 w-full rounded-xl" />
      ))}
    </div>
  );
}

function EmptyState() {
  return (
    <div className="text-sm text-muted-foreground py-12 text-center">
      No topics yet. Be the first to create one — admins can add topics in
      the Admin Panel.
    </div>
  );
}
