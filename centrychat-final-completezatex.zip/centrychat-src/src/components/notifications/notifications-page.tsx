"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { MainNav } from "@/components/shared/main-nav";
import {
  ArrowLeft,
  Bell,
  CheckCheck,
  Heart,
  MessageSquare,
  Shield,
  AlertTriangle,
  UserCog,
  UserPlus,
  UserCheck,
  AtSign,
  Film,
  BadgeCheck,
  Settings as SettingsIcon,
  Loader2,
} from "lucide-react";
import { useTranslation } from "@/lib/client/i18n-store";
import { useNotifications, type NotificationItem } from "@/hooks/use-notifications";
import { useRealtime } from "@/hooks/use-realtime";
import { translate } from "@/lib/i18n";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

/**
 * NotificationsPage — full-screen notifications experience.
 *
 * Replaces the small popover that previously showed a truncated list.
 *
 * Layout (per spec):
 *   - Header: ← Back   Notifications   [Mark all as read]
 *   - Centered max-w-2xl column on desktop; full width on mobile.
 *   - Notifications grouped by date bucket (Today / Yesterday / This Week / Earlier).
 *   - Each card shows: sender avatar + name + verified + @username
 *                      + message + relative time + unread indicator.
 *   - Click card → mark-as-read + navigate to appropriate target.
 *   - Click sender's name/avatar → always go to that user's profile.
 *
 * Pagination: infinite scroll via IntersectionObserver + cursor (`beforeId`).
 *
 * Realtime: socket.io `notification:new` events prepend to the list and bump
 * the bell badge (the badge is rendered by MainNav / NotificationCenter).
 */
export function NotificationsPage() {
  const router = useRouter();
  const { t, fmtRelative, language } = useTranslation();
  const {
    notifications,
    unreadCount,
    hasMore,
    loading,
    refresh,
    loadMore,
    markAsRead,
    markAllAsRead,
    addNotification,
  } = useNotifications(true);

  // Realtime: prepend new notifications without a page refresh.
  useRealtime(true, {
    "notification:new": (payload) => {
      const n = payload as NotificationItem | undefined;
      if (n?.id) addNotification(n);
    },
  });

  // AUTO MARK-AS-READ (spec §6): when the user opens the Notifications page,
  // automatically mark ALL their unread notifications as read. This is a
  // SINGLE batch request (POST /api/v1/notifications/read-all) — not one
  // request per notification. The server uses authenticatedUser.id from the
  // session, so it only marks the current user's notifications (spec §7).
  //
  // We use a ref guard to ensure this only fires ONCE per page mount (not
  // on every re-render). If new notifications arrive while the page is open
  // (via realtime), they'll be marked as read on the next page visit.
  const autoMarkedRef = useRef(false);
  useEffect(() => {
    if (autoMarkedRef.current) return;
    if (unreadCount > 0 && !loading) {
      autoMarkedRef.current = true;
      void markAllAsRead();
    }
  }, [unreadCount, loading, markAllAsRead]);

  // Refresh on tab focus (catches notifications received while away).
  useEffect(() => {
    const onFocus = () => void refresh();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [refresh]);

  // Infinite scroll — observe the sentinel and call loadMore.
  const sentinelRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (entry?.isIntersecting && hasMore && !loading) {
          void loadMore();
        }
      },
      { rootMargin: "200px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [hasMore, loading, loadMore]);

  const handleClick = useCallback(
    async (n: NotificationItem) => {
      // Mark as read first (updates badge immediately).
      const target = await markAsRead(n.id);
      if (!target) return;

      // ── Phase 2 — Deep-link routing for comment-related notifications ──
      // For COMMENT / COMMENT_LIKE / COMMENT_REPLY / REPLY_LIKE, we route
      // to the CommentsPage (post or article) with ?commentId= (and
      // ?replyId= for reply-targeted notifications). The CommentsPage
      // fetches the target comment directly if it's not in the first
      // page, scrolls to it, and highlights it briefly.
      //
      // The notification's metadata carries everything we need:
      //   - contentType: "post" | "article"
      //   - contentId:   the postId or articleId
      //   - commentId:   the target comment (for COMMENT / COMMENT_LIKE)
      //   - parentCommentId + replyId: for COMMENT_REPLY / REPLY_LIKE
      //
      // We use the metadata rather than target.targetType/targetId
      // because targetType is the parent content type but doesn't tell
      // us which comment to scroll to. The metadata is the source of
      // truth for the deep-link target.
      const meta = (n.metadata ?? {}) as {
        contentType?: string;
        contentId?: string;
        commentId?: string;
        parentCommentId?: string;
        replyId?: string;
      };

      // COMMENT_REPLY + REPLY_LIKE → deep-link to the REPLY.
      if (n.type === "COMMENT_REPLY" || n.type === "REPLY_LIKE") {
        const contentType = meta.contentType;
        const contentId = meta.contentId ?? target.targetId;
        // For replies, the "commentId" in the URL should be the PARENT
        // comment id (so the CommentsPage opens the parent + expands its
        // replies). The "replyId" is the specific reply to scroll to.
        const parentId = meta.parentCommentId ?? meta.commentId;
        const replyId = meta.replyId;
        if (contentId && parentId && replyId) {
          const view = contentType === "article" ? "article-comments" : "comments";
          const idParam = contentType === "article" ? "articleId" : "postId";
          router.push(
            `/?view=${view}&${idParam}=${encodeURIComponent(contentId)}` +
            `&commentId=${encodeURIComponent(parentId)}` +
            `&replyId=${encodeURIComponent(replyId)}`
          );
          return;
        }
        // Fallback: if metadata is incomplete (shouldn't happen, but
        // defensive), open the post/article comments page without a
        // specific comment target.
        if (contentId) {
          const view = contentType === "article" ? "article-comments" : "comments";
          const idParam = contentType === "article" ? "articleId" : "postId";
          router.push(`/?view=${view}&${idParam}=${encodeURIComponent(contentId)}`);
          return;
        }
      }

      // COMMENT + COMMENT_LIKE → deep-link to the COMMENT.
      if (n.type === "COMMENT" || n.type === "COMMENT_LIKE") {
        const contentType = meta.contentType;
        const contentId = meta.contentId ?? target.targetId;
        const commentId = meta.commentId;
        if (contentId && commentId) {
          const view = contentType === "article" ? "article-comments" : "comments";
          const idParam = contentType === "article" ? "articleId" : "postId";
          router.push(
            `/?view=${view}&${idParam}=${encodeURIComponent(contentId)}` +
            `&commentId=${encodeURIComponent(commentId)}`
          );
          return;
        }
        // Fallback: open the post/article without a comment target.
        if (contentId) {
          const view = contentType === "article" ? "article-comments" : "comments";
          const idParam = contentType === "article" ? "articleId" : "postId";
          router.push(`/?view=${view}&${idParam}=${encodeURIComponent(contentId)}`);
          return;
        }
      }

      // LIKE (on a post or article) → open the post/article itself.
      // No comment deep-link needed.
      if (n.type === "LIKE") {
        const contentType = meta.contentType;
        const contentId = meta.contentId ?? target.targetId;
        if (contentType === "article" && contentId) {
          router.push(`/articles/${encodeURIComponent(contentId)}`);
          return;
        }
        if (contentId) {
          // Post like — no standalone post detail page yet; open the
          // post author's profile. Future: when /post/[id] is added,
          // route there instead.
          const username = n.sender?.username;
          if (username) {
            router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
          } else {
            router.push(`/`);
          }
          return;
        }
      }

      // ── Legacy / fallback routing (existing behavior) ──────────────────
      // Route per notification target type (spec §14).
      //   conversation → Messenger with that conversation open
      //   user         → Actor's profile (for FOLLOW notifications)
      //   post         → Post author's profile (fallback when no metadata)
      //   report       → Admin panel
      if (target.targetType === "conversation" && target.conversationId) {
        router.push(`/?conversation=${target.conversationId}`);
        return;
      }
      if (target.targetType === "user" && target.targetId) {
        // Try to use the sender's username for a clean profile URL.
        const username = n.sender?.username;
        if (username) {
          router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
        } else {
          router.push(`/?view=admin`); // admin-side user link (e.g. moderation)
        }
        return;
      }
      if (target.targetType === "article" && target.targetId) {
        // Article like / interaction — open the article reading page.
        router.push(`/articles/${encodeURIComponent(target.targetId)}`);
        return;
      }
      if (target.targetType === "post" && target.targetId) {
        // Fallback for post LIKE without metadata (shouldn't happen —
        // all post likes now carry metadata). Open the post author's
        // profile.
        const username = n.sender?.username;
        if (username) {
          router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
        } else {
          router.push(`/`);
        }
        return;
      }
      if (target.targetType === "report" && target.targetId) {
        router.push(`/?view=admin`);
        return;
      }
      // No target — stay on the page (system/account notifications).
    },
    [markAsRead, router]
  );

  const handleMarkAllRead = useCallback(async () => {
    if (unreadCount === 0) return;
    await markAllAsRead();
    toast.success(t("notifications.markedAllRead"));
  }, [markAllAsRead, unreadCount, t]);

  // Group notifications by date bucket.
  const grouped = useMemo(() => groupByDateBucket(notifications, language), [notifications, language]);

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile-only slim header — desktop uses MainNav's top bar */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()} title={t("nav.backToApp")}>
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <h1 className="flex-1 truncate text-lg font-semibold">{t("notifications.title")}</h1>
        {unreadCount > 0 && (
          <Button variant="ghost" size="sm" onClick={handleMarkAllRead} className="h-8 gap-1 text-xs">
            <CheckCheck className="h-3.5 w-3.5" />
          </Button>
        )}
      </header>

      <div className="mx-auto w-full max-w-2xl px-0 md:px-4 md:py-6">
        {/* Desktop header row */}
        <div className="hidden items-center justify-between px-2 pb-3 md:flex">
          <h1 className="text-2xl font-bold">{t("notifications.title")}</h1>
          {unreadCount > 0 && (
            <Button variant="outline" size="sm" onClick={handleMarkAllRead} className="gap-1.5">
              <CheckCheck className="h-4 w-4" />
              {t("notifications.markAllRead")}
            </Button>
          )}
        </div>

        {/* Loading state — skeleton rows */}
        {loading && notifications.length === 0 ? (
          <NotificationsSkeleton />
        ) : notifications.length === 0 ? (
          <EmptyState
            icon={<Bell className="h-10 w-10 text-muted-foreground/60" />}
            title={t("notifications.noNotifications")}
            description={t("notifications.noNotificationsEmptyDesc")}
          />
        ) : (
          <div className="divide-y md:rounded-xl md:border md:divide-y">
            {grouped.map((group) => (
              <section key={group.bucket} className="md:first:rounded-t-xl md:last:rounded-b-xl">
                {/* Group header */}
                <div className="sticky top-14 z-[5] bg-background/95 px-3 py-2 backdrop-blur md:top-[3.25rem] md:px-4">
                  <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    {group.label}
                  </h2>
                </div>
                {/* Items */}
                <ul role="list" className="divide-y">
                  {group.items.map((n) => (
                    <NotificationCard
                      key={n.id}
                      n={n}
                      t={t}
                      fmtRelative={fmtRelative}
                      onClick={() => void handleClick(n)}
                      onSenderClick={(username) =>
                        router.push(`/?view=profile&username=${encodeURIComponent(username)}`)
                      }
                    />
                  ))}
                </ul>
              </section>
            ))}

            {/* Infinite-scroll sentinel + load-more spinner */}
            <div ref={sentinelRef} className="flex justify-center py-4">
              {hasMore && loading && notifications.length > 0 && (
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// NotificationCard
// ---------------------------------------------------------------------------

interface NotificationCardProps {
  n: NotificationItem;
  t: (key: string, params?: Record<string, string | number>) => string;
  fmtRelative: (iso: string) => string;
  onClick: () => void;
  onSenderClick: (username: string) => void;
}

function NotificationCard({ n, t, fmtRelative, onClick, onSenderClick }: NotificationCardProps) {
  const { title, message } = getLocalizedContent(n, t);
  const iconNode = renderNotificationIcon(n.type);
  const hasSender = !!n.sender;

  return (
    <li className="relative">
      <button
        type="button"
        onClick={onClick}
        className={cn(
          "flex w-full items-start gap-3 px-3 py-3 text-left transition-colors hover:bg-accent/60 md:px-4 md:py-4",
          !n.read && "bg-accent/40"
        )}
      >
        {/* Unread indicator (subtle, left edge) */}
        {!n.read && (
          <span
            aria-hidden
            className="absolute inset-y-2 left-0 w-0.5 rounded-full bg-primary md:inset-y-3"
          />
        )}

        {/* Sender avatar or type-icon fallback */}
        {hasSender && n.sender ? (
          // The Avatar component renders its own <button> when onClick is passed.
          // We stop propagation so that clicking the avatar opens the sender's
          // profile (spec §6) instead of the notification's primary target.
          <span
            onClick={(e) => {
              e.stopPropagation();
              onSenderClick(n.sender!.username);
            }}
            className="mt-0.5 inline-flex shrink-0 rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            title={`@${n.sender.username}`}
          >
            <Avatar
              name={n.sender.fullName}
              color={n.sender.avatarColor}
              src={n.sender.avatarUrl}
              size="md"
            />
          </span>
        ) : (
          <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-muted">
            {iconNode}
          </div>
        )}

        {/* Body */}
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <p className="text-sm leading-snug" dir="auto">
              {hasSender && n.sender ? (
                <>
                  <span
                    role="button"
                    tabIndex={0}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSenderClick(n.sender!.username);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        e.stopPropagation();
                        onSenderClick(n.sender!.username);
                      }
                    }}
                    className="inline-flex items-center gap-1 font-semibold hover:underline cursor-pointer"
                  >
                    <span dir="auto">{n.sender.fullName}</span>
                    {n.sender.isVerified && <VerifiedBadge size={12} />}
                  </span>
                  <span className="ml-1 text-xs font-normal text-muted-foreground" dir="ltr">
                    @{n.sender.username}
                  </span>
                  <br />
                </>
              ) : null}
              <span className="text-foreground">{title}</span>
            </p>
            {/* Unread dot (right side, also visible) */}
            {!n.read && (
              <span
                aria-label="unread"
                className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary"
              />
            )}
          </div>

          {/* Notification message */}
          {message && message !== title && (
            <p className="mt-0.5 line-clamp-2 text-sm text-muted-foreground" dir="auto">
              {message}
            </p>
          )}

          {/* Time */}
          <p className="mt-1 text-xs text-muted-foreground">
            {fmtRelative(n.createdAt)}
          </p>
        </div>
      </button>
    </li>
  );
}

// ---------------------------------------------------------------------------
// Empty state
// ---------------------------------------------------------------------------

function EmptyState({ icon, title, description }: { icon: ReactNode; title: string; description: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-20 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
        {icon}
      </div>
      <div className="space-y-1">
        <p className="text-base font-semibold">{title}</p>
        <p className="mx-auto max-w-xs text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Loading skeleton — full-width notification rows
// ---------------------------------------------------------------------------

function NotificationsSkeleton() {
  return (
    <div className="divide-y md:rounded-xl md:border">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="flex items-start gap-3 px-3 py-4 md:px-4">
          <Skeleton className="h-10 w-10 shrink-0 rounded-full" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-3.5 w-1/2" />
            <Skeleton className="h-3 w-3/4" />
            <Skeleton className="h-2.5 w-16" />
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Notification icon + localized content
// (Moved here from notification-center.tsx so the page is self-contained.
//  The popover-only NotificationCenter continues to import its own copy.)
// ---------------------------------------------------------------------------

function renderNotificationIcon(type: string): ReactNode {
  switch (type) {
    case "MESSAGE":
      return <MessageSquare className="h-4 w-4 text-blue-500" />;
    case "FOLLOW":
      return <UserPlus className="h-4 w-4 text-emerald-500" />;
    case "FOLLOW_BACK":
      return <UserCheck className="h-4 w-4 text-emerald-500" />;
    case "LIKE":
      return <Heart className="h-4 w-4 text-rose-500" />;
    case "COMMENT":
      return <MessageSquare className="h-4 w-4 text-sky-500" />;
    case "COMMENT_REPLY":
      // Reply — use the corner-down-right icon to distinguish from a
      // top-level comment. Same color family (sky) so users learn the
      // visual association: sky = comment thread.
      return <MessageSquare className="h-4 w-4 text-sky-500" />;
    case "COMMENT_LIKE":
      // Someone liked a comment — Heart in the comment color family.
      return <Heart className="h-4 w-4 text-rose-500" />;
    case "REPLY_LIKE":
      // Phase 2 — someone liked a reply. Heart + slightly different tint
      // (rose/pink) to distinguish from COMMENT_LIKE.
      return <Heart className="h-4 w-4 text-rose-500" />;
    case "MENTION":
      return <AtSign className="h-4 w-4 text-violet-500" />;
    case "REEL":
    case "REEL_INTERACTION":
      return <Film className="h-4 w-4 text-pink-500" />;
    case "VERIFICATION":
      return <BadgeCheck className="h-4 w-4 text-blue-500" />;
    case "SECURITY":
      return <Shield className="h-4 w-4 text-red-500" />;
    case "ACCOUNT":
      return <UserCog className="h-4 w-4 text-purple-500" />;
    case "MODERATION":
      return <AlertTriangle className="h-4 w-4 text-amber-500" />;
    case "SYSTEM":
    default:
      return <SettingsIcon className="h-4 w-4 text-muted-foreground" />;
  }
}

function getLocalizedContent(
  n: NotificationItem,
  t: (key: string, params?: Record<string, string | number>) => string
): { title: string; message: string } {
  const senderName = n.sender?.fullName ?? n.title;

  // Phase 2 — read the contentType from metadata so we can show
  // "commented on your article" vs "commented on your post". Falls back
  // to the targetType when metadata is missing (legacy notifications).
  const meta = (n.metadata ?? {}) as { contentType?: string };
  const contentType = meta.contentType ?? n.targetType;

  switch (n.type) {
    case "MESSAGE":
      return {
        title: t("notifications.messageReceived", { name: senderName }),
        message: n.message,
      };
    case "FOLLOW":
      return {
        title: t("notifications.startedFollowingYou", { name: senderName }),
        message: "",
      };
    case "FOLLOW_BACK":
      return {
        title: t("notifications.followedBack", { name: senderName }),
        message: "",
      };
    case "LIKE":
      // Distinguish post likes from article likes via metadata.contentType.
      return contentType === "article"
        ? { title: t("notifications.likedYourArticle", { name: senderName }), message: "" }
        : { title: t("notifications.likedYourPost", { name: senderName }), message: "" };
    case "COMMENT":
      // Distinguish article comments from post comments.
      return contentType === "article"
        ? {
            title: t("notifications.commentedOnYourArticle", { name: senderName }),
            message: n.message,
          }
        : {
            title: t("notifications.commentedOnYourPost", { name: senderName }),
            message: n.message,
          };
    case "COMMENT_REPLY":
      // "X replied to your comment" — same wording for both posts + articles
      // (the deep-link target is in the metadata, not the message).
      return {
        title: t("notifications.repliedToYourComment", { name: senderName }),
        message: n.message,
      };
    case "COMMENT_LIKE":
      return {
        title: t("notifications.likedYourComment", { name: senderName }),
        message: "",
      };
    case "REPLY_LIKE":
      return {
        title: t("notifications.likedYourReply", { name: senderName }),
        message: "",
      };
    case "MENTION":
      return {
        title: t("notifications.mentionedYou", { name: senderName }),
        message: n.message,
      };
    case "REEL":
    case "REEL_INTERACTION":
      return {
        title: t("notifications.reactedToYourReel", { name: senderName }),
        message: "",
      };
    case "VERIFICATION":
      return {
        title: t("notifications.verifiedBadge"),
        message: n.message,
      };
    case "SYSTEM":
      if (n.title === "New user registered") {
        return { title: t("notifications.newUserRegistered"), message: n.message };
      }
      return { title: t("notifications.systemMessage"), message: n.message };
    case "SECURITY":
      return { title: t("notifications.securityAlert"), message: n.message };
    case "ACCOUNT":
      return { title: t("notifications.accountUpdate"), message: n.message };
    case "MODERATION":
      if (n.title === "New report received") {
        return { title: t("notifications.newReportReceived"), message: n.message };
      }
      return { title: t("notifications.moderationAction"), message: n.message };
    default:
      return { title: n.title || senderName, message: n.message };
  }
}

// ---------------------------------------------------------------------------
// Date bucketing — Today / Yesterday / This Week / Earlier
// ---------------------------------------------------------------------------

interface NotificationGroup {
  bucket: "today" | "yesterday" | "thisWeek" | "earlier";
  label: string;
  items: NotificationItem[];
}

function groupByDateBucket(
  notifications: NotificationItem[],
  lang: string
): NotificationGroup[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 7);

  const buckets: NotificationGroup[] = [
    { bucket: "today", label: translate(lang, "notifications.groupToday"), items: [] },
    { bucket: "yesterday", label: translate(lang, "notifications.groupYesterday"), items: [] },
    { bucket: "thisWeek", label: translate(lang, "notifications.groupThisWeek"), items: [] },
    { bucket: "earlier", label: translate(lang, "notifications.groupEarlier"), items: [] },
  ];

  for (const n of notifications) {
    const d = new Date(n.createdAt);
    if (d >= today) buckets[0]!.items.push(n);
    else if (d >= yesterday) buckets[1]!.items.push(n);
    else if (d >= weekAgo) buckets[2]!.items.push(n);
    else buckets[3]!.items.push(n);
  }

  return buckets.filter((g) => g.items.length > 0);
}
