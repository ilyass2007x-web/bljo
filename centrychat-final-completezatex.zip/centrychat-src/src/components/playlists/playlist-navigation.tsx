"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ListMusic,
  ChevronLeft,
  ChevronRight,
  Check,
  ArrowRight,
  Loader2,
} from "lucide-react";
import { api } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { cn } from "@/lib/utils";

/**
 * PlaylistNavigation — the inline section shown inside an Article reading
 * page when the article is part of one or more Playlists (spec §5).
 *
 * For EACH playlist that contains this article:
 *   - Shows the playlist name + a link to /playlist/[slug].
 *   - Shows ALL items in the playlist (ordered by position), with the
 *     current article marked with a checkmark.
 *   - Provides Previous/Next navigation buttons (the previous + next
 *     item relative to the current article's position).
 *
 * Visibility:
 *   - PUBLIC playlists containing this article → visible to anyone.
 *   - PRIVATE playlists containing this article → visible only to the
 *     owner (the /api/v1/playlists/by-article/:articleId endpoint
 *     returns BOTH public + the viewer's own private playlists).
 *
 * Performance:
 *   - One fetch on mount. The endpoint batches + caps at 10 playlists
 *     (with the article's playlists ordered by updatedAt DESC).
 *   - Each playlist's items are NOT fetched (we only show the position +
 *     prev/next of the CURRENT article, not the full item list, to keep
 *     the inline section compact). The user clicks the playlist name to
 *     see the full list on /playlist/[slug].
 *
 * UX (spec §5):
 *   "If you're on Part 3:
 *      Part 1
 *      Part 2
 *      ✓ Part 3   ← current
 *      Part 4
 *      Part 5"
 *
 *   We render a compact "current position" badge + Prev/Next buttons +
 *   a "View full playlist" link. Clicking Prev/Next navigates to the
 *   underlying Article.
 */

interface PlaylistNavigationProps {
  /** The article ID of the page we're rendering on. */
  articleId: string;
}

interface NavArticle {
  id: string;
  title: string | null;
}

interface NavPlaylist {
  id: string;
  name: string;
  slug: string;
  // The position of the current article inside this playlist (1-indexed
  // for display, but the server returns 0-indexed — we normalize).
  currentPosition: number;
  totalItems: number;
  // Previous + next items in the playlist (relative to the current article).
  previous: NavArticle | null;
  next: NavArticle | null;
  isPublic: boolean;
  owner: {
    id: string;
    fullName: string;
    username: string;
  };
}

interface ApiResponse {
  playlists: Array<{
    id: string;
    ownerId: string;
    name: string;
    slug: string;
    description: string | null;
    isPublic: boolean;
    owner: { id: string; fullName: string; username: string };
    itemCount: number;
  }>;
}

export function PlaylistNavigation({ articleId }: PlaylistNavigationProps) {
  const router = useRouter();
  const { user } = useAuthStore();
  const { t } = useTranslation();
  const [playlists, setPlaylists] = useState<NavPlaylist[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .get<ApiResponse>(`/api/v1/playlists/by-article/${articleId}?limit=10`)
      .then(async (data) => {
        if (cancelled) return;
        // For each playlist, fetch the items to determine the current
        // position + prev/next. We do this in parallel (one fetch per
        // playlist — capped at 10 playlists, so max 10 parallel fetches).
        const detailed = await Promise.all(
          data.playlists.map(async (p) => {
            try {
              const itemsResp = await api.get<{
                items: Array<{
                  id: string;
                  articleId: string;
                  position: number;
                  article: { id: string; title: string | null } | null;
                }>;
              }>(`/api/v1/playlists/${p.id}/items?limit=500`);
              const items = itemsResp.items;
              const currentIndex = items.findIndex(
                (i) => i.articleId === articleId
              );
              if (currentIndex === -1) {
                // Article not in this playlist (race condition — item
                // was removed between the two fetches). Skip.
                return null;
              }
              const prev = items[currentIndex - 1]?.article ?? null;
              const next = items[currentIndex + 1]?.article ?? null;
              return {
                id: p.id,
                name: p.name,
                slug: p.slug,
                currentPosition: currentIndex + 1, // 1-indexed for display
                totalItems: items.length,
                previous: prev,
                next: next,
                isPublic: p.isPublic,
                owner: p.owner,
              } as NavPlaylist;
            } catch {
              return null;
            }
          })
        );
        if (cancelled) return;
        setPlaylists(
          detailed.filter((p): p is NavPlaylist => p !== null)
        );
      })
      .catch(() => {
        if (!cancelled) setPlaylists([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [articleId]);

  if (loading) {
    return (
      <div className="mt-8 rounded-xl border border-border/60 p-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          Loading playlist info...
        </div>
      </div>
    );
  }

  if (playlists.length === 0) {
    // The article is not in any playlist — render nothing (the section
    // doesn't appear at all on the article page).
    return null;
  }

  return (
    <div className="mt-8 space-y-3">
      {playlists.map((p) => (
        <div
          key={p.id}
          className="rounded-xl border border-primary/20 bg-primary/5 p-4"
        >
          {/* Playlist header — clickable link */}
          <div className="mb-3 flex items-center justify-between gap-2">
            <Link
              href={`/playlist/${p.slug}`}
              className="flex min-w-0 items-center gap-2 text-sm font-semibold hover:underline"
            >
              <ListMusic className="h-4 w-4 text-primary" />
              <span className="truncate" dir="auto">
                {p.name}
              </span>
            </Link>
            <Badge variant="secondary" className="shrink-0 gap-1 text-[11px]">
              {p.currentPosition} / {p.totalItems}
            </Badge>
          </div>

          {/* Current position + prev/next navigation */}
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="flex flex-1 items-center gap-2 text-xs text-muted-foreground">
              <Check className="h-3.5 w-3.5 text-green-500" />
              <span>
                You&apos;re on part{" "}
                <strong className="text-foreground">{p.currentPosition}</strong>{" "}
                of {p.totalItems}
              </span>
            </div>

            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                disabled={!p.previous}
                onClick={() => p.previous && router.push(`/articles/${p.previous.id}`)}
                className="gap-1"
              >
                <ChevronLeft className="h-4 w-4 rtl-flip" />
                <span className="hidden sm:inline">Previous</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={!p.next}
                onClick={() => p.next && router.push(`/articles/${p.next.id}`)}
                className="gap-1"
              >
                <span className="hidden sm:inline">Next</span>
                <ChevronRight className="h-4 w-4 rtl-flip" />
              </Button>
              <Link href={`/playlist/${p.slug}`}>
                <Button variant="ghost" size="sm" className="gap-1">
                  <ListMusic className="h-4 w-4" />
                  <span className="hidden sm:inline">View all</span>
                </Button>
              </Link>
            </div>
          </div>

          {/* Previous + Next titles (compact preview) */}
          {(p.previous || p.next) && (
            <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {p.previous && (
                <Link
                  href={`/articles/${p.previous.id}`}
                  className="flex items-center gap-2 rounded-md border p-2 text-xs hover:bg-accent/30"
                >
                  <ChevronLeft className="h-3.5 w-3.5 shrink-0 text-muted-foreground rtl-flip" />
                  <div className="min-w-0">
                    <p className="text-[10px] uppercase text-muted-foreground">
                      Previous
                    </p>
                    <p className="truncate" dir="auto">
                      {p.previous.title || "Untitled"}
                    </p>
                  </div>
                </Link>
              )}
              {p.next && (
                <Link
                  href={`/articles/${p.next.id}`}
                  className={cn(
                    "flex items-center gap-2 rounded-md border p-2 text-xs hover:bg-accent/30",
                    !p.previous && "sm:col-start-2"
                  )}
                >
                  <div className="min-w-0 flex-1 text-right">
                    <p className="text-[10px] uppercase text-muted-foreground">
                      Next
                    </p>
                    <p className="truncate" dir="auto">
                      {p.next.title || "Untitled"}
                    </p>
                  </div>
                  <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground rtl-flip" />
                </Link>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
