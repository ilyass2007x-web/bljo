"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, ListMusic, Globe, Lock, Loader2, Plus } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";

/**
 * CreatePlaylistPage — standalone SPA view for creating a new playlist
 * (when the user isn't already on an article page that has the
 * inline "Add to Playlist" dialog).
 *
 * URL: /?view=create-playlist
 *
 * The form lets the user set:
 *   - name (required, 1..120 chars)
 *   - description (optional, 0..1000 chars)
 *   - coverImage (optional — Pinterest / direct image URL, validated
 *     server-side via the shared validateImageSource helper)
 *   - isPublic (default false — safe default)
 *
 * On submit:
 *   - POST /api/v1/playlists with the form data.
 *   - On success: navigate to /playlist/[slug] (the new playlist's page).
 *   - On error: show a toast + keep the form data so the user can retry.
 *
 * Slug is generated server-side — the client never supplies it. The
 * server returns the slug in the response, so we can navigate to
 * /playlist/[slug] immediately after creation.
 */
export function CreatePlaylistPage() {
  const router = useRouter();
  const { t } = useTranslation();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [coverImage, setCoverImage] = useState("");
  const [isPublic, setIsPublic] = useState(false);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      toast.error(t("playlists.nameRequired") || "Name is required");
      return;
    }
    setSaving(true);
    try {
      const data = await api.post<{ playlist: { slug: string } }>(
        "/api/v1/playlists",
        {
          name: name.trim(),
          description: description.trim() || null,
          coverImage: coverImage.trim() || null,
          isPublic,
        }
      );
      toast.success(
        t("playlists.created") || "Playlist created"
      );
      router.push(`/playlist/${data.playlist.slug}`);
    } catch (err) {
      toast.error(
        err instanceof ApiClientError
          ? err.message
          : "Failed to create playlist"
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile-only slim header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.back()}
          title="Back"
        >
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <p className="text-sm font-medium">New Playlist</p>
      </header>

      <div className="mx-auto max-w-xl px-4 py-6 md:py-10">
        <div className="mb-6">
          <h1 className="flex items-center gap-2 text-2xl font-bold">
            <ListMusic className="h-6 w-6 text-primary" />
            Create a Playlist
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Bundle your articles into an ordered series — e.g. &quot;Avatar
            Full Story&quot; with Parts 1–5. Each article keeps its own
            Topic + Author — the Playlist is independent.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium">Name *</label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Avatar Full Story"
              maxLength={120}
              autoFocus
              required
            />
            <p className="mt-1 text-[11px] text-muted-foreground">
              {name.length}/120 characters. A URL-friendly slug is generated
              automatically (e.g. /playlist/avatar-full-story).
            </p>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium">
              Description (optional)
            </label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={1000}
              rows={4}
              placeholder="What's this playlist about?"
            />
            <p className="mt-1 text-[11px] text-muted-foreground">
              {description.length}/1000 characters.
            </p>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium">
              Cover image URL (optional)
            </label>
            <Input
              value={coverImage}
              onChange={(e) => setCoverImage(e.target.value)}
              placeholder="https://..."
              type="url"
            />
            <p className="mt-1 text-[11px] text-muted-foreground">
              Pinterest link or direct image URL. Same rules as Article
              cover images.
            </p>
          </div>

          <div className="flex items-center justify-between rounded-lg border p-3">
            <div className="flex items-center gap-2">
              {isPublic ? (
                <Globe className="h-4 w-4 text-muted-foreground" />
              ) : (
                <Lock className="h-4 w-4 text-muted-foreground" />
              )}
              <div>
                <p className="text-sm font-medium">
                  {isPublic ? "Public" : "Private"}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  {isPublic
                    ? "Anyone can find + view this playlist. Indexed by search engines."
                    : "Only you can view this playlist. Not indexed."}
                </p>
              </div>
            </div>
            <Switch checked={isPublic} onCheckedChange={setIsPublic} />
          </div>

          <div className="flex justify-end gap-2 border-t pt-4">
            <Button
              type="button"
              variant="ghost"
              onClick={() => router.back()}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !name.trim()}>
              {saving ? (
                <Loader2 className="mr-1 h-4 w-4 animate-spin" />
              ) : (
                <Plus className="mr-1 h-4 w-4" />
              )}
              Create Playlist
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
