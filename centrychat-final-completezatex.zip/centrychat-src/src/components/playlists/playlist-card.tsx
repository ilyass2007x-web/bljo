"use client";

import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { ListMusic, Globe, Lock, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * PlaylistCard — lightweight card for Profile + Search + Home.
 *
 * Renders a compact preview of a public playlist: name, description, item
 * count, visibility badge, owner (when relevant). The whole card is a
 * Link to /playlist/[slug] (SEO-friendly + accessible).
 *
 * Used by:
 *   - Profile Screen → Playlists section (spec §8): "Cover, Name, item count".
 *   - Search results → "playlist" result type (spec §19): a separate card
 *     distinct from Post Topics.
 *   - Home feed (future): could be used to surface curated playlists.
 */

export interface PlaylistCardDTO {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  coverImage: string | null;
  isPublic: boolean;
  updatedAt: string;
  owner: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  itemCount: number;
}

interface PlaylistCardProps {
  playlist: PlaylistCardDTO;
  /** Show the owner row (useful for Search results + Home). Hide on Profile. */
  showOwner?: boolean;
  /** Optional className for layout customization. */
  className?: string;
}

export function PlaylistCard({
  playlist,
  showOwner = false,
  className,
}: PlaylistCardProps) {
  return (
    <Link
      href={`/playlist/${playlist.slug}`}
      className={cn(
        "group flex items-start gap-3 rounded-xl border p-3 transition-colors hover:bg-accent/5",
        className
      )}
    >
      {/* Icon / cover placeholder */}
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
        <ListMusic className="h-5 w-5" />
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex items-start justify-between gap-2">
          <p className="line-clamp-1 text-sm font-semibold" dir="auto">
            {playlist.name}
          </p>
          <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5 rtl-flip" />
        </div>

        {playlist.description && (
          <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground" dir="auto">
            {playlist.description}
          </p>
        )}

        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
          <Badge
            variant={playlist.isPublic ? "default" : "secondary"}
            className="gap-1 px-1.5 py-0 text-[10px]"
          >
            {playlist.isPublic ? (
              <>
                <Globe className="h-2.5 w-2.5" />
                Public
              </>
            ) : (
              <>
                <Lock className="h-2.5 w-2.5" />
                Private
              </>
            )}
          </Badge>
          <span className="flex items-center gap-1">
            <ListMusic className="h-3 w-3" />
            {playlist.itemCount} {playlist.itemCount === 1 ? "part" : "parts"}
          </span>
          {showOwner && (
            <span className="truncate">
              • by {playlist.owner.fullName}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
