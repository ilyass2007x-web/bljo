"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Check,
  ListMusic,
  Globe,
  Lock,
  Plus,
  Loader2,
  ExternalLink,
} from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

/**
 * SaveToPlaylistDialog — pick a playlist + add the given Article to it.
 *
 * UX (spec §16):
 *   - Shows the user's existing playlists (id + name + visibility badge +
 *     already-saved checkmark + item count).
 *   - Click a playlist → add (optimistic) → success toast → don't auto-close
 *     (let the user add to more playlists if desired).
 *   - "Create new playlist" inline form → create + add in one click.
 *   - Already-saved playlists show a green check — clicking them again
 *     is a no-op (server enforces uniqueness via @@unique).
 *
 * SECURITY:
 *   - articleId comes from the caller (ArticleActions), which received it
 *     from server-rendered props — the client never fabricates it.
 *   - The API re-validates article existence + PUBLISHED status server-side
 *     before insertion (validateArticleExistsAndPublished) — even if a
 *     client sends a fake articleId, the server rejects the save.
 */

interface PlaylistDTO {
  id: string;
  ownerId: string;
  name: string;
  slug: string;
  description: string | null;
  coverImage: string | null;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
  owner: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  itemCount: number;
}

interface SaveToPlaylistDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  articleId: string;
  /** Optional callback when a save succeeds (for the parent to update UI). */
  onSaved?: () => void;
}

export function SaveToPlaylistDialog({
  open,
  onOpenChange,
  articleId,
  onSaved,
}: SaveToPlaylistDialogProps) {
  const router = useRouter();
  const { user } = useAuthStore();
  const { t } = useTranslation();

  const [playlists, setPlaylists] = useState<PlaylistDTO[]>([]);
  const [loading, setLoading] = useState(false);
  const [savingId, setSavingId] = useState<string | null>(null);
  // Per-playlist "saved" state — keyed by playlist ID. When true, the
  // playlist already contains this article (shown with a green check).
  const [savedIn, setSavedIn] = useState<Set<string>>(new Set());

  // Inline create-new-playlist form (visible when the user clicks
  // "Create new").
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [newIsPublic, setNewIsPublic] = useState(false);
  const [creating, setCreating] = useState(false);

  // ── Fetch the user's playlists + which ones already contain this article
  const fetchPlaylists = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      // Parallel: list playlists + check which already contain this article.
      const [listData, savedData] = await Promise.all([
        api.get<{ playlists: PlaylistDTO[] }>("/api/v1/playlists"),
        api.get<{ playlistIds: Array<{ id: string; name: string; slug: string; isPublic: boolean }> }>(
          `/api/v1/playlists/for-article/${articleId}`
        ),
      ]);
      setPlaylists(listData.playlists);
      setSavedIn(new Set(savedData.playlistIds.map((p) => p.id)));
    } catch {
      setPlaylists([]);
      setSavedIn(new Set());
    } finally {
      setLoading(false);
    }
  }, [user, articleId]);

  useEffect(() => {
    if (open) void fetchPlaylists();
  }, [open, fetchPlaylists]);

  async function handleSaveToExisting(playlistId: string) {
    setSavingId(playlistId);
    try {
      await api.post(`/api/v1/playlists/${playlistId}/items`, { articleId });
      setSavedIn((prev) => new Set(prev).add(playlistId));
      // Bump the local itemCount optimistically.
      setPlaylists((prev) =>
        prev.map((p) =>
          p.id === playlistId ? { ...p, itemCount: p.itemCount + 1 } : p
        )
      );
      toast.success(t("playlists.added") || "Added to playlist");
      onSaved?.();
      // Don't auto-close — let the user add to more playlists if desired.
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to add";
      // If the error is the duplicate message, mark as already saved.
      if (msg.toLowerCase().includes("already")) {
        setSavedIn((prev) => new Set(prev).add(playlistId));
        toast.info(
          t("playlists.alreadyAdded") || "Already in this playlist"
        );
      } else {
        toast.error(msg);
      }
    } finally {
      setSavingId(null);
    }
  }

  async function handleCreateAndSave() {
    const name = newName.trim();
    if (!name) {
      toast.error(t("playlists.nameRequired") || "Name is required");
      return;
    }
    setCreating(true);
    try {
      // 1. Create the playlist.
      const created = await api.post<{ playlist: PlaylistDTO }>(
        "/api/v1/playlists",
        { name, description: null, isPublic: newIsPublic }
      );
      // 2. Immediately save the article to the new playlist.
      await api.post(`/api/v1/playlists/${created.playlist.id}/items`, {
        articleId,
      });
      setPlaylists((prev) => [created.playlist, ...prev]);
      setSavedIn((prev) => new Set(prev).add(created.playlist.id));
      setNewName("");
      setNewIsPublic(false);
      setShowCreate(false);
      toast.success(
        t("playlists.createdAndAdded") ||
          "Playlist created + article added"
      );
      onSaved?.();
    } catch (e) {
      toast.error(
        e instanceof ApiClientError ? e.message : "Failed to create playlist"
      );
    } finally {
      setCreating(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ListMusic className="h-4 w-4 text-primary" />
            {t("playlists.saveTo") || "Add to playlist"}
          </DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-2 py-2">
          {loading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          )}

          {!loading && playlists.length === 0 && !showCreate && (
            <div className="flex flex-col items-center gap-3 py-6 text-center">
              <ListMusic className="h-8 w-8 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                {t("playlists.noPlaylists") ||
                  "You don't have any playlists yet."}
              </p>
              <Button onClick={() => setShowCreate(true)}>
                <Plus className="mr-1 h-4 w-4" />
                {t("playlists.createFirst") || "Create your first playlist"}
              </Button>
            </div>
          )}

          {!loading && playlists.length > 0 && (
            <div className="max-h-80 space-y-1 overflow-y-auto">
              {playlists.map((p) => (
                <button
                  key={p.id}
                  onClick={() => handleSaveToExisting(p.id)}
                  disabled={savingId === p.id}
                  className={cn(
                    "flex w-full items-center justify-between gap-2 rounded-md border px-3 py-2 text-left text-sm transition-colors hover:bg-accent/30 disabled:opacity-50"
                  )}
                >
                  <div className="flex min-w-0 items-center gap-2">
                    {p.isPublic ? (
                      <Globe className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    ) : (
                      <Lock className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    )}
                    <span className="truncate">{p.name}</span>
                    <span className="text-[10px] text-muted-foreground">
                      {p.itemCount}
                    </span>
                    {/* Link to the playlist page (opens in new tab) */}
                    <a
                      href={`/playlist/${p.slug}`}
                      onClick={(e) => e.stopPropagation()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-foreground"
                      title="Open playlist page"
                    >
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                  {savingId === p.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : savedIn.has(p.id) ? (
                    <Check className="h-4 w-4 text-green-500" />
                  ) : (
                    <Plus className="h-4 w-4 text-muted-foreground" />
                  )}
                </button>
              ))}
            </div>
          )}

          {showCreate && (
            <div className="rounded-md border p-3">
              <p className="mb-2 text-xs font-medium text-muted-foreground">
                {t("playlists.createTitle") || "Create a playlist"}
              </p>
              <Input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder={t("playlists.namePlaceholder") || "Playlist name"}
                maxLength={120}
                autoFocus
              />
              <div className="mt-2 flex items-center justify-between rounded-md border p-2">
                <div className="flex items-center gap-2">
                  {newIsPublic ? (
                    <Globe className="h-3.5 w-3.5 text-muted-foreground" />
                  ) : (
                    <Lock className="h-3.5 w-3.5 text-muted-foreground" />
                  )}
                  <span className="text-xs">
                    {newIsPublic ? "Public" : "Private"}
                  </span>
                </div>
                <Switch checked={newIsPublic} onCheckedChange={setNewIsPublic} />
              </div>
              <div className="mt-2 flex justify-end gap-1">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowCreate(false);
                    setNewName("");
                    setNewIsPublic(false);
                  }}
                  disabled={creating}
                >
                  {t("common.cancel") || "Cancel"}
                </Button>
                <Button
                  size="sm"
                  onClick={handleCreateAndSave}
                  disabled={creating || !newName.trim()}
                >
                  {creating ? (
                    <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                  ) : (
                    <Plus className="mr-1 h-4 w-4" />
                  )}
                  {t("playlists.createAndAdd") || "Create + Add"}
                </Button>
              </div>
            </div>
          )}

          {!showCreate && playlists.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              className="mt-2 w-full"
              onClick={() => setShowCreate(true)}
            >
              <Plus className="mr-1 h-4 w-4" />
              {t("playlists.createNew") || "Create new playlist"}
            </Button>
          )}
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            {t("common.done") || "Done"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
