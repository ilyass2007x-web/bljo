"use client";

import { useCallback, useEffect, useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { MainNav } from "@/components/shared/main-nav";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  ArrowLeft,
  Calendar,
  Clock,
  Pencil,
  Trash2,
  Loader2,
  ListMusic,
  Globe,
  Lock,
  GripVertical,
  Plus,
  ExternalLink,
  BookOpen,
} from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { ResolvedMedia } from "@/lib/media/types";
import { MediaRenderer } from "@/components/media/media-renderer";
import { ArticleImageFrame } from "@/components/articles/article-image-frame";
import {
  DndContext,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  closestCenter,
} from "@dnd-kit/core";
import {
  SortableContext,
  verticalListSortingStrategy,
  useSortable,
  arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

/**
 * PlaylistDetailClient — the client component for /playlist/[slug].
 *
 * Receives server-rendered data (the playlist row + items + resolved cover
 * media) as props, then handles all client-side interactions:
 *   - Owner-only: drag-and-drop reorder, edit, delete, add/remove items,
 *     toggle public/private.
 *   - Visitor: browse the playlist, navigate to articles, follow the
 *     owner (via the existing FollowButton).
 *
 * UX (spec §4):
 *   - Cover image at the top (resolved server-side so anonymous visitors
 *     see it without auth).
 *   - Playlist name + description + creator + count + visibility badge.
 *   - Ordered list of items — each is a clickable link to the article
 *     page (/articles/[id]).
 *   - Owner-only: drag handle on each item + Edit/Delete/Add buttons.
 */

// ── Types ────────────────────────────────────────────────────────────────

export interface PlaylistDetailItem {
  id: string;
  playlistId: string;
  articleId: string;
  position: number;
  addedAt: string;
  article: {
    id: string;
    title: string;
    excerpt: string | null;
    coverImage: string | null;
    videoUrl: string | null;
    imageZoom: number | null;
    imagePositionX: number | null;
    imagePositionY: number | null;
    publishedAt: string | null;
    readingTime: number;
    author: {
      id: string;
      fullName: string;
      username: string;
      avatarColor: string | null;
      avatarUrl: string | null;
      isVerified: boolean;
    };
  } | null;
}

export interface PlaylistDetailData {
  id: string;
  ownerId: string;
  name: string;
  slug: string;
  description: string | null;
  coverImage: string | null;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
  owner: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  itemCount: number;
}

interface Props {
  playlist: PlaylistDetailData;
  items: PlaylistDetailItem[];
  initialCoverMedia: ResolvedMedia | null;
  isOwner: boolean;
}

// ── Component ──────────────────────────────────────────────────────────

export function PlaylistDetailClient({
  playlist,
  items: initialItems,
  initialCoverMedia,
  isOwner,
}: Props) {
  const router = useRouter();
  const { user: currentUser } = useAuthStore();
  const { t, language } = useTranslation();

  const [items, setItems] = useState<PlaylistDetailItem[]>(initialItems);
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [reordering, setReordering] = useState(false);

  // Drag-and-drop sensors — a small activation delay so the user can
  // scroll-tap items on touch devices without triggering a drag.
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 5 },
    })
  );

  // Local optimistic state — when a drag ends, we immediately reorder
  // the local list + fire the API in the background.
  const handleDragEnd = useCallback(
    async (event: DragEndEvent) => {
      const { active, over } = event;
      if (!over || active.id === over.id) return;

      const oldIndex = items.findIndex((i) => i.id === active.id);
      const newIndex = items.findIndex((i) => i.id === over.id);
      if (oldIndex === -1 || newIndex === -1) return;

      // Optimistic local reorder.
      const newItems = arrayMove(items, oldIndex, newIndex);
      // Rewrite positions to 0,1,2,... (matches the server's normalize).
      const renumbered = newItems.map((it, idx) => ({
        ...it,
        position: idx,
      }));
      setItems(renumbered);

      // Persist on the server (best-effort — on failure, revert + toast).
      setReordering(true);
      try {
        await api.patch(
          `/api/v1/playlists/${playlist.id}/items/reorder`,
          { orderedItemIds: renumbered.map((i) => i.id) }
        );
        toast.success(t("playlists.reordered") || "Playlist reordered");
      } catch (e) {
        // Revert on failure.
        setItems(initialItems);
        toast.error(
          e instanceof ApiClientError
            ? e.message
            : (t("playlists.reorderFailed") || "Failed to reorder")
        );
      } finally {
        setReordering(false);
      }
    },
    [items, playlist.id, initialItems, t]
  );

  // Remove an item from the playlist (owner only).
  const handleRemoveItem = useCallback(
    async (itemId: string) => {
      // Optimistic removal.
      const prevItems = items;
      setItems((cur) => cur.filter((i) => i.id !== itemId));
      try {
        await api.delete(
          `/api/v1/playlists/${playlist.id}/items/${itemId}`
        );
        toast.success(
          t("playlists.itemRemoved") || "Removed from playlist"
        );
      } catch (e) {
        // Revert on failure.
        setItems(prevItems);
        toast.error(
          e instanceof ApiClientError
            ? e.message
            : "Failed to remove item"
        );
      }
    },
    [items, playlist.id, t]
  );

  // Delete the entire playlist (owner only).
  const handleDeletePlaylist = useCallback(async () => {
    try {
      await api.delete(`/api/v1/playlists/${playlist.id}`);
      toast.success(
        t("playlists.deleted") || "Playlist deleted"
      );
      router.push(`/?view=profile&username=${encodeURIComponent(playlist.owner.username)}`);
    } catch (e) {
      toast.error(
        e instanceof ApiClientError
          ? e.message
          : "Failed to delete playlist"
      );
    }
  }, [playlist.id, playlist.owner.username, router, t]);

  // Format "Joined / Updated" date — locale-aware.
  const updatedDate = useMemo(() => {
    try {
      if (!playlist.updatedAt) return "";
      const date = new Date(playlist.updatedAt);
      if (isNaN(date.getTime())) return "";
      const locale =
        language === "ar" ? "ar" : language === "fr" ? "fr-FR" : "en-US";
      return new Intl.DateTimeFormat(locale, {
        year: "numeric",
        month: "long",
        day: "numeric",
      }).format(date);
    } catch {
      return "";
    }
  }, [playlist.updatedAt, language]);

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile-only slim header with back button + name context */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.push("/")} title={t("nav.backToApp") || "Back"}>
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <div className="min-w-0">
          <p className="truncate font-medium" dir="auto">{playlist.name}</p>
          <p className="truncate text-xs text-muted-foreground">
            {playlist.itemCount} {playlist.itemCount === 1 ? "part" : "parts"}
          </p>
        </div>
      </header>

      <div className="mx-auto max-w-3xl px-4 py-6 md:py-10">
        {/* Cover image */}
        {playlist.coverImage && (
          <div className="mb-6 overflow-hidden rounded-2xl">
            {initialCoverMedia && initialCoverMedia.type === "image" && initialCoverMedia.mediaUrl ? (
              <ArticleImageFrame
                src={initialCoverMedia.mediaUrl}
                alt={playlist.name}
                config={{ zoom: null, positionX: null, positionY: null }}
                variant="full"
                className="w-full max-h-[400px]"
              />
            ) : (
              <div className="aspect-[3/2] w-full bg-muted">
                <MediaRenderer
                  media={initialCoverMedia}
                  loading={false}
                  variant="full"
                  alt={playlist.name}
                  titleHint={playlist.name}
                />
              </div>
            )}
          </div>
        )}

        {/* Header section */}
        <div className="mb-6 flex flex-col gap-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h1 className="text-3xl font-bold leading-tight tracking-tight md:text-4xl" dir="auto">
                {playlist.name}
              </h1>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <Badge variant={playlist.isPublic ? "default" : "secondary"} className="gap-1">
                  {playlist.isPublic ? (
                    <>
                      <Globe className="h-3 w-3" />
                      Public
                    </>
                  ) : (
                    <>
                      <Lock className="h-3 w-3" />
                      Private
                    </>
                  )}
                </Badge>
                <span className="flex items-center gap-1 text-sm text-muted-foreground">
                  <ListMusic className="h-4 w-4" />
                  {playlist.itemCount} {playlist.itemCount === 1 ? "part" : "parts"}
                </span>
                {updatedDate && (
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5" />
                    Updated {updatedDate}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Description */}
          {playlist.description && (
            <p className="text-base text-foreground/90" dir="auto">
              {playlist.description}
            </p>
          )}

          {/* Owner row */}
          <div className="flex items-center gap-3 border-b pb-4">
            <Avatar
              name={playlist.owner.fullName}
              color={playlist.owner.avatarColor}
              src={playlist.owner.avatarUrl}
              size="md"
              className="cursor-pointer"
              onClick={() =>
                router.push(
                  `/?view=profile&username=${encodeURIComponent(playlist.owner.username)}`
                )
              }
            />
            <div className="min-w-0 flex-1">
              <button
                onClick={() =>
                  router.push(
                    `/?view=profile&username=${encodeURIComponent(playlist.owner.username)}`
                  )
                }
                className="flex items-center gap-1.5 text-sm font-semibold hover:underline"
                dir="auto"
              >
                {playlist.owner.fullName}
                {playlist.owner.isVerified && <VerifiedBadge size={14} />}
              </button>
              <p className="text-xs text-muted-foreground">
                @{playlist.owner.username}
              </p>
            </div>
            {/* Owner-only actions */}
            {isOwner && (
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setEditOpen(true)}
                  title={t("common.edit") || "Edit"}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      title={t("common.delete") || "Delete"}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete playlist</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete &quot;{playlist.name}&quot;? This
                        cannot be undone. The articles inside will NOT be deleted —
                        only the playlist itself.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={handleDeletePlaylist}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            )}
          </div>
        </div>

        {/* Items list */}
        <div className="space-y-2">
          <div className="mb-3 flex items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
              <ListMusic className="h-4 w-4" />
              {playlist.itemCount} {playlist.itemCount === 1 ? "part" : "parts"}
            </h2>
            {/* "+ Add Article" button — OWNER ONLY.
                Opens the SAME ArticleEditor the user uses everywhere else,
                but with ?playlistId=<id> in the URL so the editor knows
                to auto-link the new article to this playlist after publish. */}
            {isOwner && (
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  router.push(`/?view=article-editor&playlistId=${playlist.id}`)
                }
                className="gap-1"
                title="Create a new article and add it to this playlist"
              >
                <Plus className="h-4 w-4" />
                <span className="hidden sm:inline">Add Article</span>
                <span className="sm:hidden">Article</span>
              </Button>
            )}
          </div>

          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed p-10 text-center">
              <ListMusic className="h-8 w-8 text-muted-foreground" />
              <p className="text-sm font-medium">This playlist is empty</p>
              <p className="max-w-sm text-xs text-muted-foreground">
                {isOwner
                  ? "Create a new article or add an existing one to start building this playlist."
                  : "The owner hasn't added any articles yet."}
              </p>
              {isOwner && (
                <div className="mt-2 flex flex-wrap items-center justify-center gap-2">
                  <Button
                    variant="default"
                    size="sm"
                    onClick={() =>
                      router.push(`/?view=article-editor&playlistId=${playlist.id}`)
                    }
                  >
                    <Plus className="mr-1 h-4 w-4" />
                    Create Article
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => router.push("/")}
                  >
                    Browse articles
                  </Button>
                </div>
              )}
            </div>
          ) : isOwner ? (
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={items.map((i) => i.id)}
                strategy={verticalListSortingStrategy}
              >
                <div className="space-y-2">
                  {items.map((item, idx) => (
                    <SortablePlaylistItem
                      key={item.id}
                      item={item}
                      index={idx}
                      isOwner={isOwner}
                      onRemove={handleRemoveItem}
                      reordering={reordering}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
          ) : (
            <div className="space-y-2">
              {items.map((item, idx) => (
                <PlaylistItemCard
                  key={item.id}
                  item={item}
                  index={idx}
                  isOwner={false}
                  onRemove={() => {}}
                  reordering={false}
                />
              ))}
            </div>
          )}
        </div>

        {/* Bottom: back button */}
        <div className="mt-12 border-t pt-6">
          <Button variant="ghost" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4 rtl-flip" />
            Back
          </Button>
        </div>
      </div>

      {/* Edit dialog (owner only) */}
      {editOpen && (
        <EditPlaylistDialog
          open={editOpen}
          onOpenChange={setEditOpen}
          playlist={playlist}
          onUpdated={() => {
            // The PlaylistDetailClient can't update its own props (they
            // came from the server), so we just refresh the route to
            // re-fetch. The slug is unchanged (immutable).
            setEditOpen(false);
            router.refresh();
          }}
        />
      )}
    </div>
  );
}

// ── Sortable wrapper (owner-only — adds the drag handle) ──────────────

function SortablePlaylistItem({
  item,
  index,
  isOwner,
  onRemove,
  reordering,
}: {
  item: PlaylistDetailItem;
  index: number;
  isOwner: boolean;
  onRemove: (itemId: string) => void;
  reordering: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: item.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
  };

  return (
    <div ref={setNodeRef} style={style}>
      <PlaylistItemCard
        item={item}
        index={index}
        isOwner={isOwner}
        onRemove={onRemove}
        reordering={reordering}
        dragHandle={
          <button
            {...attributes}
            {...listeners}
            className="cursor-grab rounded p-1 text-muted-foreground hover:bg-accent active:cursor-grabbing"
            aria-label="Drag to reorder"
            title="Drag to reorder"
          >
            <GripVertical className="h-4 w-4" />
          </button>
        }
      />
    </div>
  );
}

// ── Item card ──────────────────────────────────────────────────────────

function PlaylistItemCard({
  item,
  index,
  isOwner,
  onRemove,
  reordering,
  dragHandle,
}: {
  item: PlaylistDetailItem;
  index: number;
  isOwner: boolean;
  onRemove: (itemId: string) => void;
  reordering: boolean;
  dragHandle?: React.ReactNode;
}) {
  const router = useRouter();
  const article = item.article;

  // Article deleted or became a draft — render a placeholder.
  if (!article) {
    return (
      <div className="flex items-center gap-3 rounded-xl border border-dashed p-3">
        {dragHandle}
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-muted text-sm font-bold text-muted-foreground">
          {index + 1}
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-muted-foreground">
            Content no longer available
          </p>
          <p className="text-xs text-muted-foreground">
            This article was deleted or unpublished.
          </p>
        </div>
        {isOwner && (
          <Button
            variant="ghost"
            size="sm"
            className="text-destructive hover:text-destructive"
            onClick={() => onRemove(item.id)}
            disabled={reordering}
            title="Remove from playlist"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="group flex items-start gap-3 rounded-xl border p-3 transition-colors hover:bg-accent/5">
      {dragHandle}
      <Link
        href={`/articles/${article.id}`}
        className="flex min-w-0 flex-1 items-start gap-3"
      >
        {/* Position number */}
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
          {index + 1}
        </div>
        {/* Thumbnail (if cover image) */}
        {article.coverImage && (
          <div className="hidden h-12 w-16 shrink-0 overflow-hidden rounded-md bg-muted sm:block">
            <div className="h-full w-full">
              <ArticleImageFrame
                src={article.coverImage}
                alt={article.title}
                config={{
                  zoom: article.imageZoom,
                  positionX: article.imagePositionX,
                  positionY: article.imagePositionY,
                }}
                variant="mobile"
              />
            </div>
          </div>
        )}
        <div className="min-w-0 flex-1">
          <p className="line-clamp-2 text-sm font-semibold" dir="auto">
            {article.title}
          </p>
          {article.excerpt && (
            <p className="mt-1 line-clamp-2 text-xs text-muted-foreground" dir="auto">
              {article.excerpt}
            </p>
          )}
          <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <BookOpen className="h-3 w-3" />
              {article.readingTime} min
            </span>
            <span>•</span>
            <button
              onClick={(e) => {
                e.preventDefault();
                router.push(
                  `/?view=profile&username=${encodeURIComponent(article.author.username)}`
                );
              }}
              className="flex items-center gap-1 hover:underline"
            >
              {article.author.fullName}
              {article.author.isVerified && <VerifiedBadge size={10} />}
            </button>
          </div>
        </div>
      </Link>
      {isOwner && (
        <Button
          variant="ghost"
          size="sm"
          className="text-destructive hover:text-destructive"
          onClick={() => onRemove(item.id)}
          disabled={reordering}
          title="Remove from playlist"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
}

// ── Edit dialog ────────────────────────────────────────────────────────

function EditPlaylistDialog({
  open,
  onOpenChange,
  playlist,
  onUpdated,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  playlist: PlaylistDetailData;
  onUpdated: () => void;
}) {
  const { t } = useTranslation();
  const [name, setName] = useState(playlist.name);
  const [description, setDescription] = useState(playlist.description ?? "");
  const [isPublic, setIsPublic] = useState(playlist.isPublic);
  const [coverImage, setCoverImage] = useState(playlist.coverImage ?? "");
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    setSaving(true);
    try {
      await api.patch(`/api/v1/playlists/${playlist.id}`, {
        name: name.trim(),
        description: description.trim() || null,
        isPublic,
        coverImage: coverImage.trim() || null,
      });
      toast.success(t("playlists.updated") || "Playlist updated");
      onUpdated();
    } catch (e) {
      toast.error(
        e instanceof ApiClientError ? e.message : "Failed to update playlist"
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Edit playlist</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Name
            </label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={120}
              autoFocus
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Description (optional)
            </label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={1000}
              rows={3}
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-muted-foreground">
              Cover image URL (optional)
            </label>
            <Input
              value={coverImage}
              onChange={(e) => setCoverImage(e.target.value)}
              placeholder="https://..."
            />
            <p className="mt-1 text-[11px] text-muted-foreground">
              Pinterest link or direct image URL.
            </p>
          </div>
          <div className="flex items-center justify-between rounded-md border p-3">
            <div className="flex items-center gap-2">
              {isPublic ? (
                <Globe className="h-4 w-4 text-muted-foreground" />
              ) : (
                <Lock className="h-4 w-4 text-muted-foreground" />
              )}
              <div>
                <p className="text-sm font-medium">
                  {isPublic ? "Public" : "Private"}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  {isPublic
                    ? "Anyone can find + view this playlist."
                    : "Only you can view this playlist."}
                </p>
              </div>
            </div>
            <Switch checked={isPublic} onCheckedChange={setIsPublic} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={saving || !name.trim()}>
            {saving ? (
              <Loader2 className="mr-1 h-4 w-4 animate-spin" />
            ) : null}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
