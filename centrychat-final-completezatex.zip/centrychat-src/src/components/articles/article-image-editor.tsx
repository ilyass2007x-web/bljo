"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import {
  IMAGE_ZOOM_MIN,
  IMAGE_ZOOM_MAX,
  IMAGE_ZOOM_STEP,
  IMAGE_POSITION_MIN,
  IMAGE_POSITION_MAX,
  normalizeImageConfig,
  buildImageTransform,
  isDefaultConfig,
  type ArticleImageConfig,
} from "@/lib/articles/image-config";
import { ZoomIn, ZoomOut, RotateCcw, Move } from "lucide-react";

/**
 * ArticleImageEditor — the live image positioning editor shown in the
 * ArticleEditor when an image URL has been successfully resolved as
 * `type === "image"` by the UniversalMediaResolver.
 *
 * Capabilities (Phase 18 spec §10–§16):
 *   - Zoom slider (100% to 300%, step 5%) + Zoom In / Zoom Out buttons
 *   - Drag-to-position (mouse + touch via Pointer Events)
 *   - Reset button (zoom = 1, position = center)
 *   - Real-time preview — no API calls, just CSS transform updates
 *   - Keyboard: + / - to zoom, arrow keys to move (when editor focused)
 *
 * DRAG vs CLICK vs SCROLL:
 *   - Dragging inside the preview captures pointer events via
 *     setPointerCapture — the image moves but the page does NOT scroll.
 *   - When the user is NOT dragging, `touch-action: pan-y` lets vertical
 *     page-scroll pass through the preview container (so the editor
 *     never traps the user on mobile).
 *   - When dragging is active, `touch-action: none` on the container
 *     prevents the page from scrolling while the user adjusts the image.
 *
 * PERSISTENCE:
 *   - The editor maintains LOCAL React state during editing.
 *   - On any change, it calls `onChange` with the new config so the
 *     parent (ArticleEditor) can store it + send it with the save
 *     request. No API calls happen on every slider movement.
 *   - The parent is the source of truth — this component is fully
 *     controlled (it derives its state from `config` prop).
 */

export interface ArticleImageEditorProps {
  /** Direct image URL (resolved by useMediaResolver). */
  src: string;
  alt: string;
  /** Current config (controlled). */
  config: ArticleImageConfig;
  /** Called on any change with the new config. */
  onChange: (next: ArticleImageConfig) => void;
  /** Optional className for the outer container. */
  className?: string;
}

export function ArticleImageEditor({
  src,
  alt,
  config,
  onChange,
  className,
}: ArticleImageEditorProps) {
  const cfg = normalizeImageConfig(config);

  // ── Drag state ───────────────────────────────────────────────────
  // We track the pointer's position + the container's dimensions at
  // drag start so we can convert pixel deltas to fractional position
  // updates. Pointer Events API handles mouse + touch uniformly.
  const containerRef = useRef<HTMLDivElement>(null);
  const dragStateRef = useRef<{
    pointerId: number;
    startX: number;
    startY: number;
    startConfigX: number;
    startConfigY: number;
    containerWidth: number;
    containerHeight: number;
    moved: boolean;
  } | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // ── Keyboard support (spec §35) ──────────────────────────────────
  // The editor container captures + / - and arrow keys when focused.
  // We attach tabIndex={0} so it's focusable.
  const onKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLDivElement>) => {
      // Don't hijack keyboard when the user is typing in an input.
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) {
        return;
      }
      let handled = true;
      const step = IMAGE_ZOOM_STEP;
      const posStep = 0.05;
      switch (e.key) {
        case "+":
        case "=":
          onChange({ ...cfg, zoom: Math.min(IMAGE_ZOOM_MAX, cfg.zoom + step) });
          break;
        case "-":
        case "_":
          onChange({ ...cfg, zoom: Math.max(IMAGE_ZOOM_MIN, cfg.zoom - step) });
          break;
        case "ArrowLeft":
          onChange({ ...cfg, positionX: Math.max(IMAGE_POSITION_MIN, cfg.positionX - posStep) });
          break;
        case "ArrowRight":
          onChange({ ...cfg, positionX: Math.min(IMAGE_POSITION_MAX, cfg.positionX + posStep) });
          break;
        case "ArrowUp":
          onChange({ ...cfg, positionY: Math.max(IMAGE_POSITION_MIN, cfg.positionY - posStep) });
          break;
        case "ArrowDown":
          onChange({ ...cfg, positionY: Math.min(IMAGE_POSITION_MAX, cfg.positionY + posStep) });
          break;
        default:
          handled = false;
      }
      if (handled) e.preventDefault();
    },
    [cfg, onChange]
  );

  // ── Pointer drag handlers ────────────────────────────────────────
  const onPointerDown = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      // Only main button / single touch starts a drag.
      if (e.button !== 0 && e.pointerType === "mouse") return;
      const el = containerRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        // setPointerCapture can throw on some browsers if the pointer
        // has already been released — non-fatal, the drag just won't
        // be locked to the element.
      }
      dragStateRef.current = {
        pointerId: e.pointerId,
        startX: e.clientX,
        startY: e.clientY,
        startConfigX: cfg.positionX,
        startConfigY: cfg.positionY,
        containerWidth: rect.width,
        containerHeight: rect.height,
        moved: false,
      };
      setIsDragging(true);
    },
    [cfg.positionX, cfg.positionY]
  );

  const onPointerMove = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const st = dragStateRef.current;
      if (!st || st.pointerId !== e.pointerId) return;
      const dx = e.clientX - st.startX;
      const dy = e.clientY - st.startY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) st.moved = true;
      // Convert pixel delta → fractional position. We clamp to the
      // valid range so the image can never be dragged completely out
      // of view.
      const fracX = st.containerWidth > 0 ? dx / st.containerWidth : 0;
      const fracY = st.containerHeight > 0 ? dy / st.containerHeight : 0;
      const newX = Math.max(
        IMAGE_POSITION_MIN,
        Math.min(IMAGE_POSITION_MAX, st.startConfigX + fracX)
      );
      const newY = Math.max(
        IMAGE_POSITION_MIN,
        Math.min(IMAGE_POSITION_MAX, st.startConfigY + fracY)
      );
      onChange({ ...cfg, positionX: newX, positionY: newY });
    },
    [cfg, onChange]
  );

  const endDrag = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const st = dragStateRef.current;
      if (!st || st.pointerId !== e.pointerId) return;
      try {
        containerRef.current?.releasePointerCapture(e.pointerId);
      } catch {
        // non-fatal
      }
      dragStateRef.current = null;
      setIsDragging(false);
    },
    []
  );

  // ── Render ────────────────────────────────────────────────────────
  const zoomPct = Math.round(cfg.zoom * 100);
  const isDefault = isDefaultConfig(cfg);

  // Build the same CSS transform the renderer will use, so the preview
  // is WYSIWYG. We need the container's pixel dimensions for this —
  // we measure them via a ResizeObserver on the container div.
  const [containerPx, setContainerPx] = useState({ width: 0, height: 0 });
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => {
      const rect = el.getBoundingClientRect();
      setContainerPx({ width: rect.width, height: rect.height });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const transform = buildImageTransform(cfg, containerPx);

  return (
    <div className={cn("rounded-xl border bg-muted/20 p-3", className)}>
      {/* Preview — the actual image with the live transform applied. */}
      <div
        ref={containerRef}
        // tabIndex makes the editor keyboard-focusable (spec §35).
        tabIndex={0}
        role="slider"
        aria-label="Image position. Drag to move, + / - to zoom, arrow keys to nudge."
        aria-valuenow={zoomPct}
        aria-valuemin={Math.round(IMAGE_ZOOM_MIN * 100)}
        aria-valuemax={Math.round(IMAGE_ZOOM_MAX * 100)}
        onKeyDown={onKeyDown}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        className={cn(
          "relative aspect-video w-full cursor-grab overflow-hidden rounded-lg bg-muted/40 select-none",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2",
          isDragging && "cursor-grabbing"
        )}
        // CRITICAL: touch-action none while dragging (so the page
        // doesn't scroll during the drag). When NOT dragging, pan-y
        // lets vertical page-scroll pass through.
        style={{ touchAction: isDragging ? "none" : "pan-y" }}
      >
        <img
          src={src}
          alt={alt}
          className="pointer-events-none h-full w-full object-cover"
          style={{
            transform,
            transformOrigin: "center center",
          }}
          draggable={false}
          // Don't load lazily — we want immediate feedback in the editor.
          loading="eager"
        />
        {/* Drag hint — shown when no edits have been made yet. */}
        {isDefault && (
          <div className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-black/50 px-3 py-1 text-[10px] text-white backdrop-blur-sm">
            <Move className="mr-1 inline-block h-3 w-3" />
            Drag to reposition · Use slider to zoom
          </div>
        )}
      </div>

      {/* Controls — zoom slider + buttons + reset. */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="icon"
          className="h-8 w-8"
          onClick={() =>
            onChange({
              ...cfg,
              zoom: Math.max(IMAGE_ZOOM_MIN, cfg.zoom - IMAGE_ZOOM_STEP),
            })
          }
          disabled={cfg.zoom <= IMAGE_ZOOM_MIN}
          aria-label="Zoom out"
          title="Zoom out"
        >
          <ZoomOut className="h-4 w-4" />
        </Button>

        <div className="flex min-w-[140px] flex-1 items-center gap-2">
          <Slider
            value={[cfg.zoom]}
            min={IMAGE_ZOOM_MIN}
            max={IMAGE_ZOOM_MAX}
            step={IMAGE_ZOOM_STEP}
            onValueChange={(v) => {
              const next = v[0];
              if (typeof next === "number" && Number.isFinite(next)) {
                onChange({ ...cfg, zoom: next });
              }
            }}
            aria-label="Zoom level"
            className="flex-1"
          />
          <span className="w-12 shrink-0 text-right text-xs tabular-nums text-muted-foreground">
            {zoomPct}%
          </span>
        </div>

        <Button
          type="button"
          variant="outline"
          size="icon"
          className="h-8 w-8"
          onClick={() =>
            onChange({
              ...cfg,
              zoom: Math.min(IMAGE_ZOOM_MAX, cfg.zoom + IMAGE_ZOOM_STEP),
            })
          }
          disabled={cfg.zoom >= IMAGE_ZOOM_MAX}
          aria-label="Zoom in"
          title="Zoom in"
        >
          <ZoomIn className="h-4 w-4" />
        </Button>

        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-8 gap-1.5"
          onClick={() =>
            onChange({ zoom: 1, positionX: 0, positionY: 0 })
          }
          disabled={isDefault}
          aria-label="Reset image"
          title="Reset image"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          Reset
        </Button>
      </div>
    </div>
  );
}
