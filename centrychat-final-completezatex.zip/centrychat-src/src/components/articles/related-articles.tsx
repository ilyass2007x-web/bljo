import Link from "next/link";
import { Calendar, Clock, Sparkles } from "lucide-react";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { findRelatedArticles, type RelatedArticleDTO } from "@/lib/articles/related";
import { resolveMedia } from "@/lib/media/resolver";
import type { ResolvedMedia } from "@/lib/media/types";
import { ArticleImageFrame } from "@/components/articles/article-image-frame";

/**
 * RelatedArticles — a server-rendered section showing 4-6 related articles
 * below the article content.
 *
 * This is a SERVER COMPONENT (not "use client") so the links are real,
 * crawlable <a href> tags — search engines can follow them to improve
 * internal linking + article discovery (spec §17).
 *
 * The component:
 *   1. Calls findRelatedArticles() server-side (no client-side fetch).
 *   2. Renders each recommendation as a compact card with cover image,
 *      title, excerpt, author, date, reading time.
 *   3. Each card is wrapped in a <Link href="/articles/{id}"> — a real
 *      HTML anchor tag (Next.js Link renders as <a>).
 *   4. Gracefully handles empty results (renders nothing).
 *   5. Gracefully handles errors (renders nothing — never crashes the page).
 *
 * RESPONSIVE DESIGN (spec §18):
 *   - Mobile: single column, full-width cards.
 *   - Desktop (sm+): 2-column grid.
 *   - Images maintain correct aspect ratio (h-32 on desktop, aspect-square
 *     on mobile).
 *   - Titles use line-clamp-2 to prevent layout breakage.
 *
 * NO client-side JavaScript is required for this component to work. The
 * recommendations are computed server-side + rendered as static HTML.
 */

interface RelatedArticlesProps {
  /** The ID of the article currently being viewed. */
  articleId: string;
  /** How many recommendations to show (default 5). */
  limit?: number;
}

export async function RelatedArticles({ articleId, limit = 5 }: RelatedArticlesProps) {
  // Fetch related articles server-side. This never throws — errors return
  // an empty array, and we render nothing in that case.
  let articles: RelatedArticleDTO[] = [];
  try {
    articles = await findRelatedArticles(articleId, limit);
  } catch {
    // Silently fail — the article page must not crash because of the
    // recommendation system (spec §20).
    return null;
  }

  // If no related articles, don't render the section at all.
  if (articles.length === 0) return null;

  // ── Resolve cover images server-side ────────────────────────────────
  // We resolve the cover images in parallel (up to 6 at once). Each
  // resolve is wrapped in .catch(() => null) so a failure on one image
  // doesn't break the others. The resolver has SSRF protection + a 5s
  // timeout, so this is safe + fast.
  const coverMedias = await Promise.all(
    articles.map((a) =>
      a.coverImage
        ? resolveMedia(a.coverImage).catch(() => null as ResolvedMedia | null)
        : Promise.resolve(null as ResolvedMedia | null),
    ),
  );

  return (
    <section
      className="mt-12 border-t pt-8"
      aria-label="Related Articles"
      aria-labelledby="related-articles-heading"
    >
      {/* Section heading */}
      <div className="mb-4 flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-primary" />
        <h2
          id="related-articles-heading"
          className="text-lg font-bold tracking-tight md:text-xl"
        >
          Related Articles
        </h2>
      </div>

      {/* Cards grid — 1 column on mobile, 2 columns on desktop */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {articles.map((article, i) => {
          const coverMedia = coverMedias[i];
          const coverIsImage =
            !!coverMedia && coverMedia.type === "image" && !!coverMedia.mediaUrl;

          return (
            <Link
              key={article.id}
              href={`/articles/${article.id}`}
              className="group flex gap-3 rounded-xl border border-border/60 p-3 transition-all duration-200 hover:border-primary/40 hover:bg-accent/5 hover:shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40"
            >
              {/* Cover image — hidden on mobile if no image, shown as small thumbnail on desktop */}
              {article.coverImage && coverIsImage && coverMedia?.mediaUrl && (
                <div className="hidden shrink-0 overflow-hidden rounded-lg sm:block">
                  <ArticleImageFrame
                    src={coverMedia.mediaUrl}
                    alt={article.title}
                    config={{
                      zoom: article.imageZoom,
                      positionX: article.imagePositionX,
                      positionY: article.imagePositionY,
                    }}
                    variant="card"
                    className="h-20 w-28 rounded-lg"
                  />
                </div>
              )}

              {/* Content */}
              <div className="min-w-0 flex-1">
                {/* Reason badge (optional) */}
                {article.reason && (
                  <span className="mb-1 inline-block rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary">
                    {article.reason}
                  </span>
                )}

                {/* Title */}
                <h3
                  className="line-clamp-2 text-sm font-bold leading-snug transition-colors group-hover:text-primary"
                  dir="auto"
                >
                  {article.title}
                </h3>

                {/* Excerpt */}
                {article.excerpt && (
                  <p
                    className="mt-1 line-clamp-2 text-xs text-muted-foreground"
                    dir="auto"
                  >
                    {article.excerpt}
                  </p>
                )}

                {/* Author + meta */}
                <div className="mt-2 flex items-center gap-1.5">
                  <Avatar
                    name={article.author.fullName}
                    color={article.author.avatarColor}
                    src={article.author.avatarUrl}
                    size="sm"
                    className="h-5 w-5 text-[9px]"
                  />
                  <span
                    className="inline-flex min-w-0 items-center gap-0.5 whitespace-nowrap"
                    dir="auto"
                  >
                    <span className="truncate text-[11px] font-medium" dir="auto">
                      {article.author.fullName}
                    </span>
                    {article.author.isVerified && <VerifiedBadge size={9} />}
                  </span>
                  {article.publishedAt && (
                    <>
                      <span className="text-[11px] text-muted-foreground">·</span>
                      <span className="flex shrink-0 items-center gap-0.5 text-[11px] text-muted-foreground">
                        <Calendar className="h-2.5 w-2.5" />
                        <RelatedArticleDate publishedAt={article.publishedAt} />
                      </span>
                    </>
                  )}
                  <span className="text-[11px] text-muted-foreground">·</span>
                  <span className="flex shrink-0 items-center gap-0.5 text-[11px] text-muted-foreground">
                    <Clock className="h-2.5 w-2.5" />
                    {article.readingTime}m
                  </span>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

/**
 * Format a published date as a short relative string.
 * This is a server-side function (no client hooks) — it renders a static
 * string in the HTML. For "just now", "5m ago", "2h ago", "3d ago", etc.
 */
function RelatedArticleDate({ publishedAt }: { publishedAt: string }) {
  const date = new Date(publishedAt);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);

  if (diffMin < 1) return "now";
  if (diffMin < 60) return `${diffMin}m`;
  if (diffHr < 24) return `${diffHr}h`;
  if (diffDay < 7) return `${diffDay}d`;
  // For older articles, show the date.
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
