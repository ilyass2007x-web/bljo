"use client";

import { useEffect, useState, useMemo, useCallback } from "react";
import { Globe, Search, Loader2, Check, ChevronDown } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import {
  SUPPORTED_TRANSLATION_LANGUAGES,
  type TranslationLanguage,
} from "@/lib/articles/languages";

/**
 * LanguageSelector
 * =================
 *
 * Professional language selector for the Article reading page.
 *
 * DESIGN (spec §16-§24):
 *   - Desktop: Popover dropdown anchored to the Language button.
 *     Two-column grid for language list (compact, organized).
 *   - Mobile: Bottom Sheet (touch-friendly, full-width).
 *     Single-column list (each language is easy to tap).
 *   - Search field at the top (filters by native OR English name).
 *   - "Original" option always at the top (resets to original content).
 *   - Active language marked with a Check icon.
 *   - Smooth fade-in animation.
 *
 * POSITION (spec §15):
 *   Placed in the article header area, near the author info.
 *   NOT at the bottom with Like/Comment/Share.
 *
 * FLOW:
 *   User clicks 🌐 Language → opens selector → picks language →
 *   API call → translation loads → title/description/content swap.
 *   Scroll position preserved. No page refresh.
 */

export interface TranslationResult {
  articleId: string;
  languageCode: string;
  translatedTitle: string;
  translatedDescription: string | null;
  translatedContent: string;
  languageNativeName: string;
  dir: "ltr" | "rtl";
  fromCache: boolean;
}

interface LanguageSelectorProps {
  articleId: string;
  activeLanguage: TranslationLanguage | null;
  setActiveLanguage: (lang: TranslationLanguage | null) => void;
  onTranslationApplied: (result: TranslationResult) => void;
  onResetToOriginal: () => void;
  onLoadingChange?: (loading: boolean) => void;
}

// Popular languages shown first (before "Other Languages" section).
const POPULAR_CODES = ["en", "ar", "fr", "es", "de", "pt", "it"];

export function LanguageSelector({
  articleId,
  activeLanguage,
  setActiveLanguage,
  onTranslationApplied,
  onResetToOriginal,
  onLoadingChange,
}: LanguageSelectorProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Detect mobile for Sheet vs Popover.
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  // Filter languages by search query.
  const filteredLanguages = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return SUPPORTED_TRANSLATION_LANGUAGES;
    return SUPPORTED_TRANSLATION_LANGUAGES.filter(
      (l) =>
        l.nativeName.toLowerCase().includes(q) ||
        l.englishName.toLowerCase().includes(q) ||
        l.code.toLowerCase().includes(q)
    );
  }, [search]);

  // Split into Popular + Other (only when no search).
  const { popularLangs, otherLangs } = useMemo(() => {
    if (search.trim()) {
      return { popularLangs: filteredLanguages, otherLangs: [] };
    }
    const popular = filteredLanguages.filter((l) => POPULAR_CODES.includes(l.code));
    const other = filteredLanguages.filter((l) => !POPULAR_CODES.includes(l.code));
    return { popularLangs: popular, otherLangs: other };
  }, [filteredLanguages, search]);

  // Close on Escape.
  useEffect(() => {
    if (!open) return;
    function onEscape(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("keydown", onEscape);
    return () => document.removeEventListener("keydown", onEscape);
  }, [open]);

  // Reset search when closing.
  useEffect(() => {
    if (!open) setSearch("");
  }, [open]);

  // Fetch translation.
  const fetchTranslation = useCallback(
    async (lang: TranslationLanguage) => {
      setLoading(true);
      onLoadingChange?.(true);
      try {
        const data = await api.get<{ translation: TranslationResult }>(
          `/api/v1/articles/${articleId}/translation?lang=${encodeURIComponent(lang.code)}`
        );
        onTranslationApplied(data.translation);
        setActiveLanguage(lang);
        setOpen(false);
        if (!data.translation.fromCache) {
          toast.success(`Translated to ${lang.nativeName}`);
        }
      } catch (e) {
        const msg = e instanceof ApiClientError
          ? e.message
          : "Unable to translate this article right now. Please try again.";
        toast.error(msg);
      } finally {
        setLoading(false);
        onLoadingChange?.(false);
      }
    },
    [articleId, onTranslationApplied, setActiveLanguage, onLoadingChange]
  );

  const handleSelectOriginal = useCallback(() => {
    onResetToOriginal();
    setActiveLanguage(null);
    setOpen(false);
  }, [onResetToOriginal, setActiveLanguage]);

  const handleSelectLanguage = useCallback(
    (lang: TranslationLanguage) => {
      if (activeLanguage?.code === lang.code) {
        setOpen(false);
        return;
      }
      void fetchTranslation(lang);
    },
    [activeLanguage, fetchTranslation]
  );

  // ── Language item renderer ───────────────────────────────────────────
  const LanguageItem = ({ lang }: { lang: TranslationLanguage }) => {
    const isActive = activeLanguage?.code === lang.code;
    return (
      <button
        onClick={() => handleSelectLanguage(lang)}
        disabled={loading}
        className={cn(
          "flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm transition-colors hover:bg-accent disabled:opacity-50",
          isActive && "bg-primary/10 font-medium"
        )}
      >
        <span className="flex-1 truncate text-left" dir="auto">
          {lang.nativeName}
        </span>
        {lang.dir === "rtl" && (
          <span className="rounded bg-muted px-1 py-0.5 text-[10px] text-muted-foreground">
            RTL
          </span>
        )}
        {isActive && <Check className="h-4 w-4 shrink-0 text-primary" />}
        {loading && isActive && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
      </button>
    );
  };

  // ── Content (shared between Popover + Sheet) ────────────────────────
  const selectorContent = (
    <div className="flex flex-col" style={{ maxHeight: isMobile ? "70vh" : "440px" }}>
      {/* Search */}
      <div className="border-b p-3">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search language…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 pl-8"
            autoFocus
          />
        </div>
      </div>

      {/* Language list */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {/* Original */}
          <button
            onClick={handleSelectOriginal}
            className={cn(
              "mb-1 flex w-full items-center gap-2 rounded-lg border border-primary/20 bg-primary/5 px-3 py-2.5 text-sm font-medium transition-colors hover:bg-primary/10",
              !activeLanguage && "bg-primary/15"
            )}
          >
            <Globe className="h-4 w-4 text-primary" />
            <span className="flex-1 text-left">Original</span>
            {!activeLanguage && <Check className="h-4 w-4 text-primary" />}
          </button>

          {/* Divider */}
          <div className="my-2 h-px bg-border" />

          {/* Popular languages */}
          {popularLangs.length > 0 && (
            <>
              {!search.trim() && (
                <p className="px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                  Popular
                </p>
              )}
              {isMobile ? (
                // Mobile: single column
                <div className="space-y-0.5">
                  {popularLangs.map((lang) => (
                    <LanguageItem key={lang.code} lang={lang} />
                  ))}
                </div>
              ) : (
                // Desktop: two-column grid
                <div className="grid grid-cols-2 gap-0.5">
                  {popularLangs.map((lang) => (
                    <LanguageItem key={lang.code} lang={lang} />
                  ))}
                </div>
              )}
            </>
          )}

          {/* Other languages */}
          {otherLangs.length > 0 && (
            <>
              {!search.trim() && (
                <p className="mt-3 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                  Other languages
                </p>
              )}
              {isMobile ? (
                <div className="space-y-0.5">
                  {otherLangs.map((lang) => (
                    <LanguageItem key={lang.code} lang={lang} />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-0.5">
                  {otherLangs.map((lang) => (
                    <LanguageItem key={lang.code} lang={lang} />
                  ))}
                </div>
              )}
            </>
          )}

          {/* No results */}
          {filteredLanguages.length === 0 && (
            <p className="px-3 py-8 text-center text-sm text-muted-foreground">
              No languages match &quot;{search}&quot;.
            </p>
          )}
        </div>
      </ScrollArea>

      {/* Footer */}
      <div className="border-t p-2 text-center text-[11px] text-muted-foreground">
        {loading
          ? "Translating…"
          : `${SUPPORTED_TRANSLATION_LANGUAGES.length} languages available`}
      </div>
    </div>
  );

  return (
    <div className="relative">
      {/* Trigger button */}
      <button
        onClick={() => setOpen(true)}
        aria-label="Select article language"
        className={cn(
          "flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors hover:bg-accent",
          activeLanguage
            ? "border-primary/30 bg-primary/5 text-primary"
            : "border-border text-muted-foreground"
        )}
      >
        <Globe className="h-4 w-4" />
        <span className="hidden sm:inline">
          {activeLanguage ? (
            <span dir="auto">{activeLanguage.nativeName}</span>
          ) : (
            "Language"
          )}
        </span>
        {/* Mobile: show short label */}
        <span className="sm:hidden">
          {activeLanguage ? (
            <span dir="auto">{activeLanguage.code.toUpperCase()}</span>
          ) : (
            "Language"
          )}
        </span>
        <ChevronDown className="h-3 w-3" />
      </button>

      {/* Desktop: Popover */}
      {!isMobile && open && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setOpen(false)}
          />
          {/* Popover panel */}
          <div
            className="absolute right-0 top-full z-50 mt-1 w-80 origin-top-right rounded-xl border bg-popover shadow-lg"
            style={{ animation: "fadeInScale 150ms ease-out" }}
          >
            {selectorContent}
          </div>
        </>
      )}

      {/* Mobile: Bottom Sheet */}
      {isMobile && (
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetContent side="bottom" className="p-0">
            <SheetHeader className="px-4 pt-4 pb-2">
              <SheetTitle className="flex items-center gap-2">
                <Globe className="h-4 w-4" />
                Select language
              </SheetTitle>
            </SheetHeader>
            {selectorContent}
          </SheetContent>
        </Sheet>
      )}

      {/* Inline animation styles */}
      <style jsx>{`
        @keyframes fadeInScale {
          from {
            opacity: 0;
            transform: scale(0.95) translateY(-4px);
          }
          to {
            opacity: 1;
            transform: scale(1) translateY(0);
          }
        }
      `}</style>
    </div>
  );
}

/**
 * TranslationSkeleton — shown over the article body while translating.
 */
export function TranslationSkeleton() {
  return (
    <div className="space-y-4" aria-label="Translating…">
      <Skeleton className="h-9 w-3/4" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-5/6" />
      <div className="space-y-3 pt-4">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-4/5" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
      </div>
      <div className="space-y-3 pt-4">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
        <Skeleton className="h-4 w-2/3" />
      </div>
    </div>
  );
}

/**
 * TranslationIndicator — small badge shown above the translated content.
 */
export function TranslationIndicator({
  language,
  onReset,
}: {
  language: TranslationLanguage;
  onReset: () => void;
}) {
  return (
    <div className="mb-4 flex items-center gap-2 rounded-lg border border-blue-500/30 bg-blue-500/5 px-3 py-2 text-sm">
      <Globe className="h-4 w-4 text-blue-500" />
      <span className="text-muted-foreground">
        Translated to{" "}
        <span className="font-medium text-foreground" dir="auto">
          {language.nativeName}
        </span>
      </span>
      <button
        onClick={onReset}
        className="ml-auto text-xs text-blue-500 hover:underline"
      >
        View original
      </button>
    </div>
  );
}
