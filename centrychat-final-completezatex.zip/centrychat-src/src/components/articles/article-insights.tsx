"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ArrowLeft,
  Eye,
  Heart,
  MessageCircle,
  Share2,
  TrendingUp,
  Users,
  UserCheck,
  Info,
} from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useTranslation } from "@/lib/client/i18n-store";

interface ArticleInsightsData {
  article: {
    id: string;
    title: string;
    excerpt: string;
    publishedAt: string | null;
  };
  metrics: {
    uniqueViews: number;
    likes: number;
    comments: number;
    shares: number;
    engagementRate: number;
  };
  audience: {
    followerViews: number;
    nonFollowerViews: number;
    followerPercentage: number;
    nonFollowerPercentage: number;
  };
  trafficSources: null;
}

/**
 * ArticleInsights — analytics dashboard for a single article. Mirrors
 * PostInsights but hits the Article insights API endpoint.
 *
 * URL parameter: ?view=article-insights&articleId=X
 *
 * SECURITY (spec §3, §8, §25):
 *   The API verifies ownership server-side. If a non-owner tries to
 *   access this page with someone else's article ID, the API returns
 *   403 and the page shows an error message.
 *
 * URL PARAMETER HANDLING (spec §1, §2):
 *   Uses `useSearchParams()` from `next/navigation` (React-aware, always
 *   returns the current URL params as seen by the React tree). The
 *   parent `<AppInner />` already wraps everything in a Suspense
 *   boundary so this is safe to use.
 *
 * Engagement rate formula (spec §6 / §9):
 *   (Likes + Comments + Shares) / Unique Views × 100
 *   If Unique Views = 0 → 0% (no NaN/Infinity).
 */
export function ArticleInsights() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const articleId = searchParams.get("articleId") ?? "";
  const { t, fmtRelative } = useTranslation();
  const [data, setData] = useState<ArticleInsightsData | null>(null);
  const [loading, setLoading] = useState(!!articleId);
  const [error, setError] = useState<string | null>(articleId ? null : "No article ID provided.");

  // Only fetch when we actually have an articleId. The no-ID case is
  // handled by the initial state above (no setState-in-effect).
  useEffect(() => {
    if (!articleId) return;
    let cancelled = false;
    void (async () => {
      try {
        const result = await api.get<ArticleInsightsData>(`/api/v1/articles/${articleId}/insights`);
        if (!cancelled) {
          setData(result);
          setLoading(false);
        }
      } catch (e) {
        if (!cancelled) {
          setError(e instanceof ApiClientError ? e.message : "Failed to load insights");
          setLoading(false);
        }
      }
    })();
    return () => { cancelled = true; };
  }, [articleId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-14 md:pb-0">
        <MainNav />
        <div className="mx-auto max-w-3xl space-y-4 p-4 md:p-6">
          <Skeleton className="h-8 w-48" />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-24 rounded-lg" />
            ))}
          </div>
          <Skeleton className="h-48 rounded-lg" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-background pb-14 md:pb-0">
        <MainNav />
        <div className="mx-auto max-w-3xl p-4 md:p-6">
          <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
            <p className="text-sm text-destructive">{error ?? "Failed to load insights"}</p>
            <Button variant="outline" onClick={() => router.back()}>
              <ArrowLeft className="mr-2 h-4 w-4 rtl-flip" /> Back
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const m = data.metrics;
  const a = data.audience;
  const hasData = m.uniqueViews > 0 || m.likes > 0 || m.comments > 0;

  const metricCards = [
    { label: "Unique Views", value: m.uniqueViews, icon: Eye, color: "text-blue-500" },
    { label: "Likes", value: m.likes, icon: Heart, color: "text-red-500" },
    { label: "Comments", value: m.comments, icon: MessageCircle, color: "text-sky-500" },
    { label: "Shares", value: m.shares, icon: Share2, color: "text-emerald-500" },
  ];

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <p className="text-sm font-medium">Article Insights</p>
      </header>

      <div className="mx-auto max-w-3xl space-y-6 p-4 md:p-6">
        {/* Desktop back */}
        <Button variant="ghost" onClick={() => router.back()} className="hidden md:flex">
          <ArrowLeft className="mr-2 h-4 w-4 rtl-flip" /> Back to Article
        </Button>

        <h1 className="text-2xl font-bold">Article Insights</h1>

        {/* Article preview */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-start gap-2">
              <div className="min-w-0 flex-1">
                <p className="line-clamp-1 text-sm font-semibold" dir="auto">
                  {data.article.title}
                </p>
                <p className="mt-1 line-clamp-2 text-xs text-muted-foreground" dir="auto">
                  {data.article.excerpt}
                </p>
                <p className="mt-2 text-xs text-muted-foreground">
                  {data.article.publishedAt
                    ? `Published ${fmtRelative(data.article.publishedAt)}`
                    : "Not published yet"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Empty state */}
        {!hasData && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center gap-2 py-12 text-center">
              <TrendingUp className="h-10 w-10 text-muted-foreground/50" />
              <p className="text-sm font-medium">No data yet</p>
              <p className="text-xs text-muted-foreground">
                Analytics will appear as people interact with your article.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Metric cards */}
        {hasData && (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {metricCards.map((card) => {
                const Icon = card.icon;
                return (
                  <Card key={card.label}>
                    <CardContent className="flex flex-col items-center gap-1 p-4">
                      <Icon className={`h-5 w-5 ${card.color}`} />
                      <p className="text-2xl font-bold">{card.value.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">{card.label}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Engagement rate */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-sm">
                  <TrendingUp className="h-4 w-4" />
                  Engagement Rate
                  <span className="group relative">
                    <Info className="h-3.5 w-3.5 text-muted-foreground" />
                    <span className="pointer-events-none absolute left-1/2 bottom-full z-10 mb-1 hidden -translate-x-1/2 whitespace-nowrap rounded bg-foreground px-2 py-1 text-xs text-background group-hover:block">
                      (Likes + Comments + Shares) / Unique Views × 100
                    </span>
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-primary">
                  {m.engagementRate}%
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Based on {m.uniqueViews} unique views
                </p>
              </CardContent>
            </Card>

            {/* Audience breakdown */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Users className="h-4 w-4" />
                  Audience
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <UserCheck className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Followers</span>
                  </div>
                  <span className="text-sm font-medium">
                    {a.followerViews} ({a.followerPercentage}%)
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">Non-followers</span>
                  </div>
                  <span className="text-sm font-medium">
                    {a.nonFollowerViews} ({a.nonFollowerPercentage}%)
                  </span>
                </div>
                {a.followerViews + a.nonFollowerViews > 0 && (
                  <div className="flex h-2 overflow-hidden rounded-full bg-muted">
                    <div
                      className="bg-green-500"
                      style={{ width: `${a.followerPercentage}%` }}
                    />
                    <div
                      className="bg-muted-foreground/40"
                      style={{ width: `${a.nonFollowerPercentage}%` }}
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Traffic sources — not available */}
            <Card>
              <CardContent className="flex flex-col items-center gap-2 py-8 text-center">
                <Info className="h-5 w-5 text-muted-foreground/50" />
                <p className="text-xs text-muted-foreground">
                  Traffic source analytics (Home Feed, Profile, Search, etc.) require
                  additional tracking. This will be available in a future update.
                </p>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
