"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Loader2, MessageSquare } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { COMMENT_MAX_LENGTH } from "@/lib/posts/parser";
import type { ArticleDTO } from "@/components/articles/article-reading-page";
import {
  CommentThread,
  type CommentDTO as ThreadCommentDTO,
} from "@/components/comments/comment-thread";

/**
 * ArticleCommentsPage — full-page Comments view for a single article.
 *
 * Uses the SAME unified <CommentThread> component as the Post CommentsPage.
 * The only differences:
 *   - `kind="article"` (routes the API calls to /api/v1/articles/* and
 *     /api/v1/article-comments/*)
 *   - The article preview at the top instead of a post preview
 *   - Auth: published articles are public, so even logged-out visitors
 *     can READ comments. Posting/commenting still requires auth.
 *
 * Routing: /?view=article-comments&articleId=<articleId>
 *
 * Phase 1 — Likes/Views/Shares/Comments/Replies:
 *   - Top-level comments rendered via <CommentThread kind="article" />
 *   - Replies rendered INSIDE <CommentThread> (one level deep) —
 *     THIS IS THE NEW FEATURE. Articles previously had no reply UI even
 *     though the schema + API supported it. Now both Posts and Articles
 *     share the exact same reply system.
 *   - Like + Reply + Delete available on BOTH comments and replies
 *   - View/Hide replies toggle per comment
 *   - Optimistic UI: likes flip instantly, replies appear instantly
 *     after the API responds, deletes remove locally then sync.
 *
 * Authorization (spec §25):
 *   - Any logged-in user can read comments on a published article.
 *   - Any logged-in user can post a comment / reply.
 *   - Only the comment author or an admin can delete a comment.
 */
export function ArticleCommentsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const articleId = searchParams.get("articleId") ?? "";
  const { user } = useAuthStore();
  const { t, fmtRelative } = useTranslation();

  // ── Phase 2 — Deep-link target from URL ──────────────────────────────
  // When the user clicks a COMMENT / COMMENT_REPLY / COMMENT_LIKE /
  // REPLY_LIKE notification on an ARTICLE, the NotificationsPage navigates
  // to: /?view=article-comments&articleId=<id>&commentId=<id>[&replyId=<id>]
  // We use these to fetch the target comment directly (if not in the first
  // page) + pass highlight props to the matching CommentThread.
  const targetCommentId = searchParams.get("commentId");
  const targetReplyId = searchParams.get("replyId");

  const [article, setArticle] = useState<ArticleDTO | null>(null);
  const [comments, setComments] = useState<ThreadCommentDTO[]>([]);
  const [commentCount, setCommentCount] = useState(0);
  const [loading, setLoading] = useState(!!articleId);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [draft, setDraft] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const cursorRef = useRef<string | null>(null);
  // Stage 3.2 — comment sorting state.
  const [sort, setSort] = useState<"top" | "newest" | "oldest">("newest");

  const fetchInitial = useCallback(async () => {
    if (!articleId) return;
    setArticle(null);
    setComments([]);
    setCommentCount(0);
    setHasMore(false);
    cursorRef.current = null;
    setLoading(true);
    try {
      // Fetch the article (for the preview at the top).
      const articleData = await api.get<{ article: ArticleDTO }>(`/api/v1/articles/${articleId}`);
      setArticle(articleData.article);

      // Fetch the first page of comments. The API returns comments WITH
      // their nested replies + likeCount + isLiked — same shape as the
      // post comments API, so the unified CommentThread component works.
      const commentsData = await api.get<{
        comments: ThreadCommentDTO[];
        nextCursor: string | null;
        commentCount: number;
      }>(`/api/v1/articles/${articleId}/comments?limit=20&sort=${sort}`);
      setComments(commentsData.comments);
      setCommentCount(
        commentsData.commentCount ?? commentsData.comments.length
      );
      cursorRef.current = commentsData.nextCursor;
      setHasMore(!!commentsData.nextCursor && commentsData.comments.length > 0);

      // ── Phase 2 — Targeted comment fetch for deep-link ───────────────
      // Same logic as the Post CommentsPage. If ?commentId= (or ?replyId=)
      // is in the URL and the target isn't in the first page, fetch it
      // DIRECTLY via GET /api/v1/article-comments/:id (single findUnique —
      // no pagination). For replyId, we fetch the parent comment so the
      // reply renders inside it. 404s are silently swallowed (comment was
      // deleted — spec §17).
      const fetchTargetId = targetReplyId ?? targetCommentId;
      if (fetchTargetId) {
        const isAlreadyLoaded =
          commentsData.comments.some((c) => c.id === fetchTargetId) ||
          commentsData.comments.some((c) => c.replies.some((r) => r.id === fetchTargetId));
        if (!isAlreadyLoaded) {
          try {
            const targetData = await api.get<{ comment: ThreadCommentDTO }>(
              `/api/v1/article-comments/${fetchTargetId}`
            );
            let targetComment = targetData.comment;
            if (targetReplyId && targetComment.parentCommentId) {
              const parentData = await api.get<{ comment: ThreadCommentDTO }>(
                `/api/v1/article-comments/${targetComment.parentCommentId}`
              );
              targetComment = parentData.comment;
            }
            setComments((prev) => {
              if (prev.some((c) => c.id === targetComment.id)) return prev;
              return [targetComment, ...prev];
            });
          } catch {
            // 404 = comment deleted. Silently ignore (spec §17).
          }
        }
      }
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to load comments";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }, [articleId, targetCommentId, targetReplyId, sort]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void fetchInitial();
  }, [fetchInitial]);

  const loadMore = useCallback(async () => {
    if (!hasMore || loadingMore || !cursorRef.current) return;
    setLoadingMore(true);
    try {
      const data = await api.get<{
        comments: ThreadCommentDTO[];
        nextCursor: string | null;
      }>(`/api/v1/articles/${articleId}/comments?limit=20&cursor=${encodeURIComponent(cursorRef.current)}&sort=${sort}`);
      setComments((prev) => [...prev, ...data.comments]);
      cursorRef.current = data.nextCursor;
      setHasMore(!!data.nextCursor && data.comments.length > 0);
    } catch {
      setHasMore(false);
    } finally {
      setLoadingMore(false);
    }
  }, [hasMore, loadingMore, articleId, sort]);

  async function submitComment() {
    const trimmed = draft.trim();
    if (!trimmed || !articleId) return;
    setSubmitting(true);
    try {
      const data = await api.post<{ comment: ThreadCommentDTO }>(
        `/api/v1/articles/${articleId}/comments`,
        { content: trimmed }
      );
      // Optimistic prepend — newest first.
      setComments((prev) => [data.comment, ...prev]);
      setCommentCount((c) => c + 1);
      setDraft("");
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to post comment";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  // When a top-level comment is deleted, remove it from the list + bump count.
  const handleCommentDeleted = useCallback((commentId: string) => {
    setComments((prev) => prev.filter((c) => c.id !== commentId));
    setCommentCount((c) => Math.max(0, c - 1));
  }, []);

  // ── Phase 2 — Clear the highlight URL params after the pulse finishes ─
  const handleHighlightDone = useCallback(() => {
    if (!targetCommentId && !targetReplyId) return;
    const params = new URLSearchParams(searchParams.toString());
    params.delete("commentId");
    params.delete("replyId");
    const qs = params.toString();
    router.replace(qs ? `/?${qs}` : "/", { scroll: false });
  }, [targetCommentId, targetReplyId, searchParams, router]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-14 md:pb-0">
        <MainNav />
        <div className="mx-auto max-w-2xl p-4 md:p-6">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="mt-4 h-24 w-full rounded-lg" />
          <Skeleton className="mt-4 h-12 w-full rounded-lg" />
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="mt-4 h-16 w-full rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  if (!articleId) {
    return (
      <div className="min-h-screen bg-background pb-14 md:pb-0">
        <MainNav />
        <div className="mx-auto max-w-2xl p-4 md:p-6">
          <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
            <p className="text-sm text-destructive">No article ID provided.</p>
            <Button variant="outline" onClick={() => router.back()}>
              <ArrowLeft className="mr-2 h-4 w-4 rtl-flip" /> Back
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const charCount = Array.from(draft).length;
  const overLimit = charCount > COMMENT_MAX_LENGTH;
  const canSubmit = !!draft.trim().length && !overLimit && !submitting;

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <p className="truncate text-sm font-medium">
          {t("posts.comments") || "Comments"}
        </p>
        <span className="ml-auto text-xs text-muted-foreground tabular-nums">
          {commentCount.toLocaleString()}
        </span>
      </header>

      <div className="mx-auto max-w-2xl p-4 md:p-6">
        {/* Desktop back */}
        <Button variant="ghost" onClick={() => router.back()} className="mb-4 hidden md:flex">
          <ArrowLeft className="mr-2 h-4 w-4 rtl-flip" /> Back
        </Button>

        {/* Article preview */}
        {article && (
          <div
            className="cursor-pointer rounded-lg border bg-muted/30 p-4 hover:bg-muted/50"
            onClick={() => router.push(`/articles/${article.id}`)}
          >
            <p className="line-clamp-1 text-sm font-semibold" dir="auto">
              {article.title}
            </p>
            {article.excerpt && (
              <p className="mt-1 line-clamp-2 text-xs text-muted-foreground" dir="auto">
                {article.excerpt}
              </p>
            )}
            <div className="mt-2 flex items-center gap-2">
              <Avatar
                name={article.author.fullName}
                color={article.author.avatarColor}
                src={article.author.avatarUrl}
                size="sm"
                className="h-5 w-5 text-[9px]"
              />
              <span className="truncate text-xs text-muted-foreground" dir="auto">
                {article.author.fullName}
              </span>
            </div>
          </div>
        )}

        {/* Comment composer */}
        <div className="mt-4 space-y-2">
          <Textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
                e.preventDefault();
                void submitComment();
              }
            }}
            placeholder={t("posts.commentPlaceholder") || "Write a comment…"}
            maxLength={COMMENT_MAX_LENGTH * 4}
            rows={3}
            className="resize-none text-sm"
            aria-label="Write a comment"
          />
          <div className="flex items-center justify-between gap-2">
            <span
              className={cn(
                "text-xs tabular-nums",
                overLimit ? "font-semibold text-destructive" : "text-muted-foreground"
              )}
            >
              {charCount}/{COMMENT_MAX_LENGTH}
            </span>
            <Button
              size="sm"
              onClick={submitComment}
              disabled={!canSubmit}
            >
              {submitting ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : null}
              {t("posts.postComment") || "Comment"}
            </Button>
          </div>
        </div>

        {/* Comments list — uses the SAME unified <CommentThread> component
            as the Post CommentsPage. The `kind="article"` prop is the
            ONLY difference — it routes the API calls to the article
            endpoints. Everything else (rendering, optimistic UI, replies,
            likes, view/hide replies) is shared code. */}
        <div className="mt-6 space-y-1">
          <h3 className="flex items-center gap-2 text-sm font-semibold">
            <MessageSquare className="h-4 w-4" />
            {commentCount.toLocaleString()}{" "}
            {commentCount === 1
              ? (t("posts.comment") || "comment")
              : (t("posts.comments") || "comments")}
          </h3>

          {/* Stage 3.2 — Comment sorting control */}
          {comments.length > 0 && (
            <div className="flex items-center gap-1 pb-2" role="tablist" aria-label="Comment sort">
              {(["top", "newest", "oldest"] as const).map((s) => (
                <button
                  key={s}
                  role="tab"
                  aria-selected={sort === s}
                  onClick={() => setSort(s)}
                  className={cn(
                    "rounded-md px-2.5 py-1 text-xs font-medium transition-colors",
                    sort === s
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                  )}
                >
                  {s === "top" ? (t("posts.sortTop") || "Top") :
                   s === "newest" ? (t("posts.sortNewest") || "Newest") :
                   (t("posts.sortOldest") || "Oldest")}
                </button>
              ))}
            </div>
          )}

          {comments.length === 0 ? (
            <div className="py-10 text-center text-sm text-muted-foreground">
              {t("posts.noComments") || "No comments yet. Be the first to comment."}
            </div>
          ) : (
            <>
              <div className="divide-y rounded-lg border">
                {comments.map((c) => {
                  // Authorization: comment author OR article author OR admin.
                  const canDelete =
                    user?.id === c.author.id ||
                    user?.id === article?.authorId ||
                    user?.role === "ADMIN" ||
                    user?.role === "SUPER_ADMIN";
                  return (
                    <CommentThread
                      key={c.id}
                      kind="article"
                      contentId={articleId}
                      comment={c}
                      canDelete={canDelete}
                      onDeleted={handleCommentDeleted}
                      // Phase 2 — pass deep-link highlight props (same as
                      // the Post CommentsPage).
                      highlightedCommentId={targetCommentId}
                      highlightedReplyId={targetReplyId}
                      onHighlightDone={handleHighlightDone}
                    />
                  );
                })}
              </div>

              {hasMore && (
                <div className="flex items-center justify-center py-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => loadMore()}
                    disabled={loadingMore}
                  >
                    {loadingMore ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : null}
                    {loadingMore
                      ? (t("posts.loadingMore") || "Loading…")
                      : (t("posts.loadOlder") || "Load older comments")}
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
