"use client";

import { useRouter } from "next/navigation";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Clock, Calendar, Pencil, Trash2, BarChart3, Video as VideoIcon, ArrowRight } from "lucide-react";
import { useTranslation } from "@/lib/client/i18n-store";
import { useAuthStore } from "@/lib/client/auth-store";
import { ArticleActions } from "@/components/articles/article-actions";
import { useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { api, ApiClientError } from "@/lib/client/api";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { MediaRenderer } from "@/components/media/media-renderer";
import { useMediaResolver } from "@/hooks/use-media-resolver";
import { ArticleImageFrame } from "@/components/articles/article-image-frame";

export interface ArticleCardDTO {
  id: string;
  title: string;
  excerpt: string | null;
  coverImage: string | null;
  videoUrl: string | null;
  // Phase 18 — image presentation config. Nullable so old articles
  // (which pre-date the migration) keep working — ArticleImageFrame
  // treats null as the natural default (zoom=1, center).
  imageZoom?: number | null;
  imagePositionX?: number | null;
  imagePositionY?: number | null;
  publishedAt: string | null;
  readingTime: number;
  author: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  // Phase — Article social features. All counts come from the server
  // (computed via Prisma _count + batch queries on ArticleInteraction).
  // `isLiked` is per-current-user; clients must NEVER send these values
  // back to the server — the server is the source of truth.
  likeCount: number;
  commentCount: number;
  viewCount: number;
  shareCount: number;
  isLiked: boolean;
}

interface ArticleCardProps {
  article: ArticleCardDTO;
  /** When true, shows Edit/Delete/Insights buttons (owner only). */
  canManage?: boolean;
  /** Called when the article is deleted (so the parent can remove it
   * from the list without a re-fetch). */
  onDeleted?: (articleId: string) => void;
}

/**
 * ArticleCard — lightweight card for the Home feed + Profile article list.
 * Shows: cover image, title, excerpt, author, date, reading time, AND
 * the unified action bar (Like / Comment / Views / Share) — same as PostCard.
 *
 * Owner-only actions (Edit / Delete / Insights) are shown when
 * `canManage === true`. Per spec §13: "Owner-only actions: Edit, Delete,
 * Insights. Normal visitors: Like, Comment, Share, View."
 *
 * Clicking the card navigates to /articles/[id] (the SEO-friendly
 * server-rendered reading page).
 */
export function ArticleCard({ article, canManage = false, onDeleted }: ArticleCardProps) {
  const router = useRouter();
  const { t, fmtRelative } = useTranslation();
  const currentUser = useAuthStore((s) => s.user);
  const [deleting, setDeleting] = useState(false);

  // Resolve the cover image URL via the UniversalMediaResolver. The card
  // shows a thumbnail when type=image; for embeds/video/preview it shows
  // a small fallback card. The video indicator below still uses the raw
  // `article.videoUrl` boolean — we don't resolve video for the card
  // (the reading page does that).
  //
  // Phase 18 — when the resolver confirms the URL is a direct IMAGE,
  // we render it via ArticleImageFrame (overflow:hidden + transform
  // applied). This is the SINGLE component that guarantees no internal
  // scrolling + no external navigation. The whole card is wrapped in
  // an onClick that navigates to /articles/[id] — clicking the image
  // opens the article, NEVER the Pinterest/external source URL.
  const coverMediaUrl = article.coverImage ?? null;
  const { media: coverMedia, loading: coverLoading } = useMediaResolver(coverMediaUrl, 0);
  // True when the resolver confirmed the URL points at a real image
  // resource (direct image, og:image, etc.). For non-image URLs we
  // fall back to MediaRenderer which shows the resolver's metadata
  // card — that card DOES have an "Open original" link, but it is
  // NOT the article image and it is NOT in the card's click area.
  const coverIsImage =
    !!coverMedia && coverMedia.type === "image" && !!coverMedia.mediaUrl;

  async function handleDelete(e: React.MouseEvent) {
    e.stopPropagation();
    setDeleting(true);
    try {
      await api.delete(`/api/v1/articles/${article.id}`);
      toast.success("Article deleted");
      // Notify any subscribed screen (Home feed, Profile list) so they
      // can remove the article + decrement counts WITHOUT a re-fetch.
      window.dispatchEvent(
        new CustomEvent("post:deleted", { detail: { id: article.id } })
      );
      onDeleted?.(article.id);
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to delete article";
      toast.error(msg);
    } finally {
      setDeleting(false);
    }
  }

  function handleEdit(e: React.MouseEvent) {
    e.stopPropagation();
    router.push(`/?view=article-editor&id=${article.id}`);
  }

  function handleInsights(e: React.MouseEvent) {
    e.stopPropagation();
    router.push(`/?view=article-insights&articleId=${article.id}`);
  }

  return (
    <article
      className={cn(
        "group relative cursor-pointer border-b border-border/60 p-4 transition-all duration-200 hover:bg-accent/5 hover:shadow-sm focus-within:ring-2 focus-within:ring-primary/40 md:p-6",
        "active:scale-[0.997]"
      )}
      onClick={() => router.push(`/articles/${article.id}`)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          router.push(`/articles/${article.id}`);
        }
      }}
      tabIndex={0}
      role="link"
      aria-label={`Read article: ${article.title}`}
    >
      <div className="flex gap-4">
        {/* Cover image — left on desktop. Resolved via UniversalMediaResolver.
            For non-image URLs (embeds, webpages), MediaRenderer shows a
            compact fallback card with an "Open original" link.

            Phase 18 — when the URL resolves as an image, we render it via
            ArticleImageFrame which guarantees:
              - overflow: hidden (NEVER scrolls internally)
              - object-fit: cover (preserves the saved composition)
              - transform: translate(X,Y) scale(zoom) (the saved config)
              - pointer-events: none + draggable=false (no native drag)
              - touch-action: pan-y (page-scroll passes through)

            The image is NOT wrapped in its own <a> tag. The whole card
            has onClick → /articles/[id] (see above). Clicking the image
            therefore opens the article, NEVER the external source URL.

            SMART CARD UX (spec §2 — Card Hover):
              On desktop, the image scales up subtly (1.03) on card hover.
              The transition is fast (200ms) + subtle (no exaggerated zoom).
              The ArticleImageFrame's overflow:hidden guarantees the scaled
              image NEVER overflows its container — no layout shift. */}
        {article.coverImage && (
          <div className="hidden shrink-0 overflow-hidden rounded-lg transition-transform duration-200 group-hover:scale-[1.03] sm:block">
            {coverIsImage ? (
              <ArticleImageFrame
                src={coverMedia!.mediaUrl!}
                alt={article.title}
                config={{
                  zoom: article.imageZoom,
                  positionX: article.imagePositionX,
                  positionY: article.imagePositionY,
                }}
                variant="card"
                className="h-24 w-32 rounded-lg md:h-28 md:w-40"
              />
            ) : (
              <div className="overflow-hidden rounded-lg">
                <MediaRenderer
                  media={coverMedia}
                  loading={coverLoading}
                  variant="card"
                  alt={article.title}
                  className="h-24 w-32 md:h-28 md:w-40"
                />
              </div>
            )}
          </div>
        )}

        <div className="min-w-0 flex-1">
          {/* Title — highlights on card hover (subtle color shift to primary). */}
          <h2
            className="line-clamp-2 text-base font-bold leading-snug transition-colors group-hover:text-primary md:text-lg"
            dir="auto"
          >
            {article.title}
          </h2>

          {/* Excerpt */}
          {article.excerpt && (
            <p className="mt-1 line-clamp-2 text-sm text-muted-foreground" dir="auto">
              {article.excerpt}
            </p>
          )}

          {/* Mobile cover image — square 1:1 per responsive spec.
              Only shown on screens < sm (sm:hidden). Uses ArticleImageFrame
              (Phase 18) for the same overflow:hidden + transform guarantees
              as the desktop variant. The wrapper div constrains the width;
              we override the frame's default dimensions with aspect-square +
              h-auto so the image becomes a perfect square on mobile.
              Desktop cover image (above) is intentionally untouched. */}
          {article.coverImage && (
            <div className="mt-2 sm:hidden">
              {coverIsImage ? (
                <ArticleImageFrame
                  src={coverMedia!.mediaUrl!}
                  alt={article.title}
                  config={{
                    zoom: article.imageZoom,
                    positionX: article.imagePositionX,
                    positionY: article.imagePositionY,
                  }}
                  variant="mobile"
                  className="w-full rounded-lg"
                />
              ) : (
                <div className="overflow-hidden rounded-lg sm:hidden">
                  <MediaRenderer
                    media={coverMedia}
                    loading={coverLoading}
                    variant="card"
                    alt={article.title}
                    className="aspect-square w-full h-auto"
                  />
                </div>
              )}
            </div>
          )}

          {/* Author + meta + (owner-only) Edit/Delete/Insights buttons */}
          <div className="mt-3 flex items-center gap-2">
            <Avatar
              name={article.author.fullName}
              color={article.author.avatarColor}
              src={article.author.avatarUrl}
              size="sm"
              className="h-6 w-6 text-[10px]"
            />
            {/* Author name + verification badge — kept together on the
                SAME LINE via inline-flex + items-center + whitespace-nowrap.
                The badge is OUTSIDE the truncating span so it never gets
                clipped by overflow:hidden when the name is long, and it
                never wraps to a new line. Applies to both mobile + desktop. */}
            <span
              className="inline-flex min-w-0 items-center gap-1 whitespace-nowrap"
              dir="auto"
            >
              <span className="truncate text-xs font-medium" dir="auto">
                {article.author.fullName}
              </span>
              {article.author.isVerified && <VerifiedBadge size={10} />}
            </span>
            <span className="text-xs text-muted-foreground">·</span>
            {article.publishedAt && (
              <span className="flex shrink-0 items-center gap-1 text-xs text-muted-foreground">
                <Calendar className="h-3 w-3" />
                {fmtRelative(article.publishedAt)}
              </span>
            )}
            <span className="text-xs text-muted-foreground">·</span>
            <span className="flex shrink-0 items-center gap-1 text-xs text-muted-foreground">
              <Clock className="h-3 w-3" />
              {article.readingTime} min
            </span>
            {/* Video indicator — small icon if the article has a video.
                Does NOT auto-play (spec §16 — "Do NOT automatically play
                video inside the Home feed"). */}
            {article.videoUrl && (
              <>
                <span className="text-xs text-muted-foreground">·</span>
                <span className="flex shrink-0 items-center gap-1 text-xs text-muted-foreground" title="Has video">
                  <VideoIcon className="h-3 w-3" />
                </span>
              </>
            )}

            {/* Owner actions — pushed to the right. Per spec §13: only
                the owner (canManage=true) sees Edit/Delete/Insights. */}
            {canManage && (
              <div className="ml-auto flex shrink-0 items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-muted-foreground hover:text-primary"
                  onClick={handleInsights}
                  aria-label="Article Insights"
                  title="Article Insights"
                >
                  <BarChart3 className="h-3.5 w-3.5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-muted-foreground hover:text-foreground"
                  onClick={handleEdit}
                  aria-label="Edit article"
                  title="Edit Article"
                >
                  <Pencil className="h-3.5 w-3.5" />
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-muted-foreground hover:text-destructive"
                      onClick={(e) => e.stopPropagation()}
                      aria-label="Delete article"
                      title="Delete Article"
                      disabled={deleting}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent onClick={(e) => e.stopPropagation()}>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete this article?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This article will be permanently deleted. This action cannot be undone.
                        All likes, comments, and views will be removed.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel onClick={(e) => e.stopPropagation()}>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={handleDelete}
                        className={cn("bg-destructive text-destructive-foreground hover:bg-destructive/90")}
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            )}
          </div>

          {/* "Read Article" affordance — small label + arrow shown at the
              bottom of the card content area. Always visible on mobile
              (no hover there), subtle on desktop. The arrow translates ~4px
              to the right on hover, giving a clear "this is clickable" cue
              without being aggressive (spec §2 — Card Hover). */}
          <div className="mt-2 flex items-center gap-1 text-xs font-medium text-primary/80 transition-colors group-hover:text-primary">
            <span>{t("articles.readArticle") || "Read Article"}</span>
            <ArrowRight className="h-3 w-3 transition-transform duration-200 group-hover:translate-x-1 rtl-flip" />
          </div>
        </div>
      </div>

      {/* Action bar — Like / Comment / Views / Share.
          Renders for ALL viewers (visitor + owner). Per spec §12:
          "Make Article actions visually consistent with Posts." */}
      <div className="mt-2 -ml-1 border-t border-border/40 pt-1" onClick={(e) => e.stopPropagation()}>
        <ArticleActions article={article} />
      </div>
    </article>
  );
}
