"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Loader2, X, ImageIcon, VideoIcon, AlertCircle } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { MediaRenderer } from "@/components/media/media-renderer";
import { useMediaResolver } from "@/hooks/use-media-resolver";
import { ArticleImageEditor } from "@/components/articles/article-image-editor";
import { ArticleImageFrame } from "@/components/articles/article-image-frame";
import {
  DEFAULT_IMAGE_CONFIG,
  normalizeImageConfig,
  type ArticleImageConfig,
} from "@/lib/articles/image-config";
import {
  classifyImageSourceKind,
  getDisallowedReason,
} from "@/lib/articles/image-source-classify";
import { TutorialVideoCard } from "@/components/shared/tutorial-video-card";
// Phase 2.2 — Topics: inline topic selector for article assignment.
import { TopicSelector } from "@/components/topics/topic-selector";

export function ArticleEditor() {
  const router = useRouter();
  const params = useSearchParams();
  const editId = params.get("id");
  // Optional playlist context — when the user clicked "+ Add Article" inside
  // a playlist, we open the same ArticleEditor with `?playlistId=<id>`. After
  // successful publish, the new article is auto-linked to this playlist + the
  // user is redirected back to the playlist page (not the article page).
  // When absent, the editor behaves EXACTLY as before (no playlist context).
  const playlistId = params.get("playlistId");
  const { user } = useAuthStore();
  const { t } = useTranslation();

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [coverImage, setCoverImage] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  // Cover image visibility inside the article detail page.
  // Defaults to true (backward compatibility — existing behavior preserved).
  const [showCoverInArticle, setShowCoverInArticle] = useState(true);
  const [status, setStatus] = useState<"DRAFT" | "PUBLISHED">("DRAFT");
  const [loading, setLoading] = useState(!!editId);
  const [saving, setSaving] = useState(false);
  // Phase 18 — image presentation config (zoom + position).
  // Lives in local React state during editing, persisted to the API
  // on save. Initialized from the article's saved config when editing
  // an existing article (see the load effect below).
  const [imageConfig, setImageConfig] = useState<ArticleImageConfig>(DEFAULT_IMAGE_CONFIG);
  // Phase 2.2 — Topics: selected topic IDs for this article.
  // Hydrated from the GET /api/v1/articles/:id response when editing.
  // Sent as `topicIds: string[]` in the POST/PATCH body (Phase 2.1 contract).
  const [topicIds, setTopicIds] = useState<string[]>([]);
  // Live media resolution via UniversalMediaResolver — debounced 500ms.
  // The resolver probes the URL server-side (Content-Type sniffing +
  // OG metadata extraction) and returns a normalized ResolvedMedia object.
  // We resolve BOTH coverImage + videoUrl whenever the user changes them.
  const { media: coverMedia, loading: coverLoading, error: coverError } =
    useMediaResolver(coverImage, 500);
  const { media: videoMedia, loading: videoLoading, error: videoError } =
    useMediaResolver(videoUrl, 500);

  useEffect(() => {
    if (!editId) return;
    void (async () => {
      try {
        const data = await api.get<{ article: any }>(`/api/v1/articles/${editId}`);
        const a = data.article;
        setTitle(a.title ?? "");
        setContent(a.content ?? "");
        setExcerpt(a.excerpt ?? "");
        setCoverImage(a.coverImage ?? "");
        setVideoUrl(a.videoUrl ?? "");
        setShowCoverInArticle(a.showCoverInArticle !== false);
        setStatus(a.status ?? "DRAFT");
        // Phase 18 — hydrate the saved image config. Old articles
        // without these fields get the natural defaults (zoom=1,
        // center) via normalizeImageConfig.
        setImageConfig(normalizeImageConfig({
          zoom: a.imageZoom ?? null,
          positionX: a.imagePositionX ?? null,
          positionY: a.imagePositionY ?? null,
        }));
        // Phase 2.2 — Topics: hydrate the article's existing topic IDs.
        // The GET /api/v1/articles/:id response includes `topicIds: string[]`
        // (added in Phase 2.1). Empty array when the article has no topics.
        setTopicIds(Array.isArray(a.topicIds) ? a.topicIds : []);
      } catch (e) {
        toast.error(e instanceof ApiClientError ? e.message : "Failed to load article");
        router.push("/?view=profile");
      } finally {
        setLoading(false);
      }
    })();
  }, [editId, router]);

  async function save() {
    // ── Frontend validation (matches backend exactly) ────────────────
    // Per spec §2: validation runs BEFORE the request is sent. If anything
    // is invalid, we show the exact error + return early — no API call.
    const trimmedTitle = title.trim();
    if (!trimmedTitle || trimmedTitle.length < 3) {
      toast.error("Title must be at least 3 characters");
      return;
    }
    if (trimmedTitle.length > 200) {
      toast.error("Title must be at most 200 characters");
      return;
    }
    const trimmedContent = content.trim();
    if (!trimmedContent || trimmedContent.length < 10) {
      toast.error("Content must be at least 10 characters");
      return;
    }

    // Phase 18 follow-up — block save when the cover image URL is invalid.
    // The frontend can't bypass the server's validator (defense-in-depth),
    // but we block here too so the user gets instant feedback + no wasted
    // network request. Empty URL is allowed (cover image is optional).
    if (trimmedCover && imagePreviewState !== "ready") {
      toast.error("Invalid image link. Use a direct image URL.");
      return;
    }

    // ── Double-publish prevention (spec §5) ──────────────────────────
    // `saving` flag guards against repeat clicks. The button is disabled
    // while this is true (see the JSX below), so a single request fires.
    // If the user somehow bypasses the disabled state (e.g. by keyboard
    // activation on a focusable button), this guard still catches it.
    if (saving) return;

    setSaving(true);
    try {
      // Per spec §1, §4: ALWAYS publish. No "Save Draft" option in the UI.
      // The DB still supports DRAFT status for backward compatibility with
      // any pre-existing drafts, but the editor never creates new drafts.
      const body = {
        title: trimmedTitle,
        content: trimmedContent,
        excerpt: excerpt.trim() || undefined,
        coverImage: coverImage.trim() || undefined,
        videoUrl: videoUrl.trim() || undefined,
        status: "PUBLISHED" as const,
        // Cover image visibility inside the article detail page.
        showCoverInArticle,
        // Phase 18 — send the current image config so the saved
        // article reproduces the exact visual composition chosen
        // during editing. The server validates + clamps.
        imageZoom: imageConfig.zoom,
        imagePositionX: imageConfig.positionX,
        imagePositionY: imageConfig.positionY,
        // Phase 2.2 — Topics: send the selected topic IDs.
        // The server validates + syncs them (Phase 2.1 contract).
        // Always send — even when empty (clears all topics on edit).
        topicIds,
      };
      // Capture the response so we can dispatch a `post:created` event
      // — this is what makes the article appear in the Home feed
      // immediately after publishing (the Home feed's usePostsFeed hook
      // listens for this event).
      let savedArticle: any = null;
      if (editId) {
        const res = await api.patch<{ article: any }>(`/api/v1/articles/${editId}`, body);
        savedArticle = res.article;
      } else {
        const res = await api.post<{ article: any }>("/api/v1/articles", body);
        savedArticle = res.article;
      }
      toast.success("Article published!");

      // Dispatch `post:created` so the Home feed + Profile feed prepend
      // the article immediately. We always dispatch because we ALWAYS
      // publish (never draft).
      if (savedArticle) {
        const card = articleToCardDTO(savedArticle);
        if (card) {
          window.dispatchEvent(new CustomEvent("post:created", { detail: card }));
        }
      }

      // ── Auto-link to playlist (when ?playlistId=<id> was set) ────────
      // This implements the "Create Article from inside Playlist" workflow.
      // The user clicked "+ Add Article" inside a playlist → we opened the
      // ArticleEditor with the playlist context. After successful publish,
      // we POST the new article to /api/v1/playlists/[playlistId]/items.
      //
      // IDempotency: the server's @@unique([playlistId, articleId])
      // constraint + the explicit pre-insert duplicate check guarantee
      // that re-running this POST (e.g. after a retry) is a no-op —
      // the server returns 400 "already in this playlist" which we
      // treat as success (the article IS in the playlist).
      //
      // Security: the server-side /api/v1/playlists/[id]/items endpoint
      // verifies ownership of the playlist BEFORE inserting. A user can
      // only add articles to playlists THEY own — even if they fabricate
      // a playlistId in the URL.
      if (playlistId && savedArticle?.id) {
        try {
          await api.post(`/api/v1/playlists/${playlistId}/items`, {
            articleId: savedArticle.id,
          });
          toast.success("Article added to playlist");
        } catch (e) {
          // If the error is "already in this playlist", it's a no-op
          // (idempotent) — treat as success. Other errors (ownership,
          // capacity, etc.) are surfaced to the user but DON'T block
          // navigation — the article was already published successfully.
          const msg = e instanceof ApiClientError ? e.message : "";
          if (msg.toLowerCase().includes("already")) {
            // Idempotent — article is already in the playlist.
          } else {
            toast.error(
              e instanceof ApiClientError
                ? e.message
                : "Article published, but couldn't add to playlist"
            );
          }
        }
      }

      // ── Success state (spec §6) ──────────────────────────────────────
      // Navigate to the published article — UNLESS we came from a
      // playlist context, in which case we return to the playlist page
      // so the user sees the new article added to their playlist.
      // NO `window.location.reload()` — we use Next.js client navigation
      // which preserves the in-memory content store + auth state.
      if (playlistId) {
        // Refresh the playlist page so the new article appears in the list.
        // router.refresh() re-runs the server component's loader.
        router.refresh();
        // The playlist slug isn't known client-side (only the id); the
        // /playlist/[slug] route requires the slug. We navigate back to
        // the profile (where the playlist card links to /playlist/[slug]).
        // A future enhancement could expose a /api/v1/playlists/[id] → slug
        // lookup, but for the MVP the profile view is sufficient.
        router.push(`/?view=profile&username=${encodeURIComponent(user?.username ?? "")}`);
      } else if (savedArticle?.id) {
        router.push(`/articles/${savedArticle.id}`);
      } else {
        // Fallback (shouldn't happen — the API always returns the id)
        router.push(`/?view=profile&username=${encodeURIComponent(user?.username ?? "")}`);
      }
    } catch (e) {
      // Show the REAL server error — do not fabricate success.
      const msg = e instanceof ApiClientError ? e.message : "Failed to publish";
      toast.error(msg);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // ── Cover Image preview state (via UniversalMediaResolver) ──────
  //   - "idle"        → URL is empty
  //   - "invalid"      → URL doesn't start with http:// or https://
  //   - "disallowed"   → URL matches a disallowed platform (Instagram / Facebook /
  //                      TikTok / Google / etc.) — instant client-side reject
  //                      before the resolver even runs (no wasted probe).
  //   - "loading"      → resolver is probing the URL
  //   - "ready"        → resolver returned a result. The result is ACCEPTED only
  //                      when `coverMedia.type === "image"` AND the URL is either
  //                      Pinterest or a direct image URL (verified by Content-Type,
  //                      not extension). Otherwise the URL is rejected.
  //
  // When accepted, the resolved mediaUrl is passed to ArticleImageFrame
  // (which renders the live preview + the zoom/position editor).
  const trimmedCover = coverImage.trim();
  const coverKind = classifyImageSourceKind(trimmedCover);
  const coverDisallowedReason = getDisallowedReason(trimmedCover);
  // True when the resolver confirmed an image AND the URL was Pinterest or direct.
  // This is the FRONTEND decision — the SERVER independently re-validates
  // via validateImageSource in the POST/PATCH route (defense-in-depth).
  const coverAccepted =
    !!coverMedia &&
    coverMedia.type === "image" &&
    !!coverMedia.mediaUrl &&
    (coverKind === "pinterest" || coverKind === "direct-image");
  const imagePreviewState:
    | "idle"
    | "invalid"
    | "disallowed"
    | "loading"
    | "ready"
    | "rejected" =
    !trimmedCover ? "idle"
    : !/^https?:\/\//i.test(trimmedCover) ? "invalid"
    : coverKind === "disallowed" ? "disallowed"
    : coverLoading ? "loading"
    : coverAccepted ? "ready"
    : "rejected";

  // ── Video preview state (via UniversalMediaResolver) ───────────
  // Same shape as the cover image preview. The resolver decides whether
  // it's a direct video, a YouTube/Vimeo/etc. embed, or a fallback card.
  const trimmedVideo = videoUrl.trim();
  const videoPreviewState:
    | "idle"
    | "invalid"
    | "loading"
    | "ready" =
    !trimmedVideo ? "idle"
    : !/^https?:\/\//i.test(trimmedVideo) ? "invalid"
    : videoLoading ? "loading"
    : "ready";

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <p className="text-sm font-medium">
          {editId
            ? "Edit Article"
            : playlistId
              ? "Add Article to Playlist"
              : "New Article"}
        </p>
      </header>

      <div className="mx-auto max-w-3xl px-4 py-6 md:py-10">
        {/* Desktop back */}
        <Button variant="ghost" onClick={() => router.back()} className="mb-4 hidden md:flex">
          <ArrowLeft className="mr-2 h-4 w-4 rtl-flip" /> Back
        </Button>

        {/* ── Cover Image URL ───────────────────────────────── */}
        <div className="mb-6">
          <Label htmlFor="coverImage" className="flex items-center gap-1.5">
            <ImageIcon className="h-4 w-4" /> Cover image URL
          </Label>
          <div className="mt-2 flex gap-2">
            <Input
              id="coverImage"
              value={coverImage}
              onChange={(e) => setCoverImage(e.target.value)}
              placeholder="Paste a direct image URL."
              className="flex-1"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              aria-invalid={imagePreviewState === "invalid" || imagePreviewState === "disallowed" || imagePreviewState === "rejected"}
              aria-describedby="coverImage-help"
            />
            {coverImage && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setCoverImage("")}
                title="Remove"
                aria-label="Remove cover image"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Cover preview + status messages — driven by UniversalMediaResolver.
              The resolver probes the URL server-side (Content-Type sniffing +
              OG metadata extraction) and returns the best representation.

              Phase 18 follow-up — only Pinterest + direct image URLs are
              accepted (server-side source of truth via validateImageSource).
              The frontend mirrors the same rule for instant feedback:
                - coverKind === "disallowed" → instant reject (no probe)
                - coverAccepted (resolver confirmed type=image AND Pinterest/direct) → render editor
                - everything else → "rejected" state with the spec error message. */}
          <div id="coverImage-help" aria-live="polite" className="mt-3 space-y-2">
            {imagePreviewState === "ready" && coverMedia && coverMedia.type === "image" && coverMedia.mediaUrl && (
              <>
                {/* Live preview using the same ArticleImageFrame used by the
                    published article card + reading page. This guarantees
                    WYSIWYG — what the author sees here is what readers get. */}
                <ArticleImageFrame
                  src={coverMedia.mediaUrl}
                  alt={title.trim() || "Cover preview"}
                  config={imageConfig}
                  variant="editor"
                  className="rounded-xl"
                />
                {/* The editor itself — zoom slider + drag + reset. */}
                <ArticleImageEditor
                  src={coverMedia.mediaUrl}
                  alt={title.trim() || "Cover preview"}
                  config={imageConfig}
                  onChange={setImageConfig}
                />
                <p className="text-xs text-green-600 dark:text-green-400">
                  ✓ Image detected{coverMedia.contentType ? ` (${coverMedia.contentType})` : ""}.
                  Adjust zoom + position below — the same composition will appear in the published article.
                </p>
              </>
            )}

            {imagePreviewState === "loading" && (
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Loader2 className="h-3 w-3 animate-spin" />
                Resolving media…
              </p>
            )}
            {imagePreviewState === "invalid" && (
              <p className="flex items-center gap-1.5 text-xs text-destructive">
                <AlertCircle className="h-3.5 w-3.5" />
                Invalid image link. Use a direct image URL.
              </p>
            )}
            {imagePreviewState === "disallowed" && (
              <p className="flex items-start gap-1.5 text-xs text-destructive">
                <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span>
                  {coverDisallowedReason ?? "Invalid image link. Use a direct image URL."}
                </span>
              </p>
            )}
            {imagePreviewState === "rejected" && (
              <p className="flex items-start gap-1.5 text-xs text-destructive">
                <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span>
                  Invalid image link. Use a direct image URL.
                </span>
              </p>
            )}
            {imagePreviewState === "idle" && (
              <p className="text-xs text-muted-foreground">
                Use a direct image.
              </p>
            )}
          </div>

          {/* Article Image Tutorial — admin-controlled YouTube video.
              Renders NOTHING when no video is configured OR when the
              admin has disabled it. Uses ONLY the ARTICLE_IMAGE_TUTORIAL
              location — the Profile tutorial is never shown here
              (spec §3 + §9). */}
          <TutorialVideoCard location="ARTICLE_IMAGE_TUTORIAL" className="mt-2" />

          {/* Show cover image inside article — toggle.
              When ON (default): the cover image renders at the top of the
              article detail page (existing behavior).
              When OFF: the cover image is NOT rendered inside the article
              (but still shows on the Home feed Article Card + in SEO/OG
              metadata). This is a display-only toggle — the coverImage
              URL is preserved in the article data. */}
          {coverImage.trim() && (
            <label className="mt-3 flex cursor-pointer items-center gap-2 rounded-lg border p-3 text-sm transition-colors hover:bg-accent/30">
              <input
                type="checkbox"
                checked={showCoverInArticle}
                onChange={(e) => setShowCoverInArticle(e.target.checked)}
                className="h-4 w-4 rounded border-input accent-primary"
              />
              <span>
                <span className="font-medium">Show cover image inside article</span>
                <span className="block text-xs text-muted-foreground">
                  When off, the cover still appears in the Home feed + social sharing previews.
                </span>
              </span>
            </label>
          )}
        </div>

        {/* ── Video URL ──────────────────────────────────────── */}
        <div className="mb-6">
          <Label htmlFor="videoUrl" className="flex items-center gap-1.5">
            <VideoIcon className="h-4 w-4" /> Video URL (optional)
          </Label>
          <div className="mt-2 flex gap-2">
            <Input
              id="videoUrl"
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              placeholder="https://youtube.com/watch?v=…  |  https://vimeo.com/…  |  direct video URL"
              className="flex-1"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              aria-describedby="videoUrl-help"
            />
            {videoUrl && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setVideoUrl("")}
                title="Remove"
                aria-label="Remove video URL"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          {/* Per spec §1, §2: the supported-providers description lists
              ONLY YouTube, Vimeo, and direct video URLs — even though the
              underlying UniversalMediaResolver still supports additional
              platforms (TikTok, Instagram, Facebook, X, Reddit, Pinterest,
              share.google). Those continue to work for backward compatibility
              but are intentionally NOT advertised in the UI. */}
          <p className="mt-1 text-xs text-muted-foreground">
            Supports: YouTube, Vimeo, and direct video URLs
          </p>

          {/* Video preview — driven by UniversalMediaResolver. */}
          <div id="videoUrl-help" aria-live="polite" className="mt-3 space-y-2">
            {videoPreviewState === "ready" && videoMedia && (
              <div className="overflow-hidden rounded-xl">
                <MediaRenderer
                  media={videoMedia}
                  loading={videoLoading}
                  error={videoError}
                  variant="full"
                  alt="Video preview"
                />
              </div>
            )}
            {videoPreviewState === "loading" && (
              <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Loader2 className="h-3 w-3 animate-spin" />
                Resolving video…
              </p>
            )}
            {videoPreviewState === "invalid" && (
              <p className="flex items-center gap-1.5 text-xs text-destructive">
                <AlertCircle className="h-3.5 w-3.5" />
                URL must start with http:// or https://
              </p>
            )}
            {videoPreviewState === "ready" && videoMedia && (videoMedia.type === "image" || videoMedia.type === "preview") && (
              <p className="text-xs text-amber-600 dark:text-amber-400">
                This URL didn&apos;t resolve as a video. It will be shown as a fallback card.
              </p>
            )}
          </div>

          {/* Article Video Tutorial — admin-controlled YouTube video.
              Renders NOTHING when no video is configured OR when the
              admin has disabled it. Uses ONLY the ARTICLE_VIDEO_TUTORIAL
              location — the Profile + Article-image tutorials are never
              shown here (each location is independent per spec §9 of the
              previous Tutorial Videos task). The card shows a thumbnail
              (auto-derived from the YouTube video ID) + a play button
              that opens the embed in an overlay — same UX as the existing
              Profile Image + Article Image tutorials. */}
          <TutorialVideoCard location="ARTICLE_VIDEO_TUTORIAL" className="mt-2" />
        </div>

        {/* ── Phase 2.2 — Topics ─────────────────────────────────── */}
        <div className="mb-6">
          <TopicSelector
            value={topicIds}
            onChange={setTopicIds}
            max={5}
            label="Topics"
            placeholder="Search topics to assign..."
          />
        </div>

        {/* ── Title ──────────────────────────────────────────── */}
        <div className="mb-6">
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Article title..."
            className="border-0 px-0 text-2xl font-bold focus-visible:ring-0 md:text-3xl"
            maxLength={200}
            aria-label="Article title"
          />
          <p className="mt-1 text-xs text-muted-foreground">{title.length}/200</p>
        </div>

        {/* ── Excerpt ────────────────────────────────────────── */}
        <div className="mb-6">
          <Label htmlFor="excerpt">Excerpt (optional — shown as preview)</Label>
          <Input
            id="excerpt"
            value={excerpt}
            onChange={(e) => setExcerpt(e.target.value)}
            placeholder="A short summary of your article..."
            maxLength={300}
            className="mt-2"
          />
          <p className="mt-1 text-xs text-muted-foreground">{excerpt.length}/300</p>
        </div>

        {/* ── Content ────────────────────────────────────────── */}
        <div className="mb-6">
          <Label htmlFor="content">Content</Label>
          <Textarea
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Write your article here..."
            className="mt-2 min-h-[400px] resize-y text-[17px] leading-[1.8]"
            style={{ fontFamily: "inherit" }}
          />
          <p className="mt-1 text-xs text-muted-foreground">{content.length} characters</p>
        </div>

        {/* ── Actions ──────────────────────────────────────────
            Per spec §1, §4: ONLY a Publish button is shown. The "Save
            Draft" option has been removed entirely from the UI. The DB
            schema still supports DRAFT status for backward compatibility
            with pre-existing drafts, but the editor never creates new
            drafts — every save is a publish.

            Per spec §5 (Prevent Double Publish): the button is disabled
            while `saving` is true. The `save()` function also has a
            redundant `if (saving) return;` guard inside, so even if the
            user activates the button via keyboard while it's mid-request,
            no duplicate request fires. */}
        <div className="flex border-t pt-4">
          <Button
            onClick={save}
            disabled={saving}
            className="w-full sm:w-auto"
            aria-label={editId ? "Update published article" : "Publish article"}
          >
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {saving
              ? "Publishing…"
              : editId
                ? "Update Published Article"
                : "Publish"}
          </Button>
        </div>
      </div>
    </div>
  );
}

/**
 * Convert an article API response into the ArticleCardDTO shape that
 * the Home feed + Profile feed expect (the `post:created` event payload
 * uses this same shape).
 *
 * Returns null if the article is missing required fields or is not
 * published (we only dispatch the event for PUBLISHED articles).
 */
function articleToCardDTO(a: any): import("@/components/articles/article-card").ArticleCardDTO | null {
  if (!a || !a.id || !a.title || !a.author) return null;
  return {
    id: a.id,
    title: a.title,
    excerpt: a.excerpt ?? null,
    coverImage: a.coverImage ?? null,
    videoUrl: a.videoUrl ?? null,
    // Phase 18 — propagate the saved image config so the article
    // appears in the Home feed with the correct zoom/position
    // immediately after publishing (no re-fetch needed).
    imageZoom: a.imageZoom ?? null,
    imagePositionX: a.imagePositionX ?? null,
    imagePositionY: a.imagePositionY ?? null,
    publishedAt: a.publishedAt ?? null,
    readingTime: a.readingTime ?? 1,
    author: {
      id: a.author.id,
      fullName: a.author.fullName,
      username: a.author.username,
      avatarColor: a.author.avatarColor ?? null,
      avatarUrl: a.author.avatarUrl ?? null,
      isVerified: a.author.isVerified ?? false,
    },
    // Phase — Article social features. Newly-published article has 0
    // of each — the server's POST response includes the same fields,
    // but for the optimistic event payload we default to 0 so the
    // ArticleCard can render the action row with 0 counts initially.
    likeCount: a.likeCount ?? 0,
    commentCount: a.commentCount ?? 0,
    viewCount: a.viewCount ?? 0,
    shareCount: a.shareCount ?? 0,
    isLiked: a.isLiked ?? false,
  };
}
