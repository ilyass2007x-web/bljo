"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { ArticleCard } from "@/components/articles/article-card";
import type { ArticleCardDTO } from "@/components/articles/article-card";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, FileText, Pencil, Trash2 } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";

interface ProfileArticlesProps {
  /** The profile user's ID */
  profileUserId: string;
  /** The profile user's username (for navigation) */
  profileUsername: string;
  /** Whether the current viewer is the profile owner (shows + + drafts) */
  isOwnProfile: boolean;
}

/**
 * ProfileArticles — shows published (and draft) articles in a user's Profile.
 *
 * For the profile owner: shows drafts + published + a "+" button to create
 * new articles + edit/delete buttons on each article.
 *
 * For visitors: shows only published articles (no +, no drafts, no edit).
 */
export function ProfileArticles({ profileUserId, profileUsername, isOwnProfile }: ProfileArticlesProps) {
  const router = useRouter();
  const { user } = useAuthStore();
  const { t } = useTranslation();
  const [articles, setArticles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const loadArticles = useCallback(async () => {
    try {
      // If own profile, fetch drafts too. The API returns only published
      // for non-owners (server-side authorization).
      const data = await api.get<{ articles: any[] }>(
        `/api/v1/users/${encodeURIComponent(profileUsername)}/articles?limit=50`
      );
      setArticles(data.articles);
    } catch {
      /* ignore */
    } finally {
      setLoading(false);
    }
  }, [profileUsername]);

  useEffect(() => {
    void loadArticles();
  }, [loadArticles]);

  async function handleDelete(articleId: string) {
    if (!confirm("Delete this article? This cannot be undone.")) return;
    try {
      await api.delete(`/api/v1/articles/${articleId}`);
      setArticles((prev) => prev.filter((a) => a.id !== articleId));
      toast.success("Article deleted");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to delete");
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="border-t pt-6">
      {/* Header with + button (only for profile owner) */}
      <div className="mb-4 flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-lg font-bold">
          <FileText className="h-5 w-5 text-primary" />
          Articles
        </h2>
        {isOwnProfile && (
          <Button
            size="sm"
            variant="outline"
            onClick={() => router.push("/?view=article-editor")}
            className="gap-1"
          >
            <Plus className="h-4 w-4" />
            New
          </Button>
        )}
      </div>

      {/* Articles list */}
      {articles.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <FileText className="h-10 w-10 text-muted-foreground/50" />
          <p className="mt-3 text-sm text-muted-foreground">
            {isOwnProfile ? "No articles yet. Create your first article!" : "No articles yet."}
          </p>
          {isOwnProfile && (
            <Button
              variant="outline"
              size="sm"
              className="mt-3"
              onClick={() => router.push("/?view=article-editor")}
            >
              <Plus className="mr-1 h-3.5 w-3.5" /> Create Article
            </Button>
          )}
        </div>
      ) : (
        <div className="rounded-lg border border-border/40">
          {articles.map((a) => (
            <div key={a.id} className="relative">
              <ArticleCard article={a} />
              {/* Owner actions — edit/delete */}
              {isOwnProfile && (
                <div className="absolute right-3 top-3 flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-muted-foreground hover:text-foreground"
                    onClick={(e) => {
                      e.stopPropagation();
                      router.push(`/?view=article-editor&id=${a.id}`);
                    }}
                    title="Edit"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-muted-foreground hover:text-destructive"
                    onClick={(e) => {
                      e.stopPropagation();
                      void handleDelete(a.id);
                    }}
                    title="Delete"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
