"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  Heart,
  MessageCircle,
  Eye,
  Share2,
  BookmarkPlus,
  ListMusic,
} from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { useCollectionsEnabled, usePlaylistsEnabled } from "@/lib/client/platform";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import {
  useContentEngagement,
  useContentStore,
} from "@/lib/client/content-store";
import { SaveToCollectionDialog } from "@/components/collections/save-to-collection-dialog";
import { SaveToPlaylistDialog } from "@/components/playlists/save-to-playlist-dialog";
import type { ArticleCardDTO } from "@/components/articles/article-card";

interface ArticleActionsProps {
  article: ArticleCardDTO;
}

function formatCount(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000) {
    const v = n / 1000;
    return (v >= 100 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, "")) + "K";
  }
  const v = n / 1_000_000;
  return v.toFixed(1).replace(/\.0$/, "") + "M";
}

/**
 * ArticleActions — the action row at the bottom of an Article card or
 * the Article reading page.
 *
 * UNIFIED STATE (spec §1, §12 — Single Source of Truth):
 *   Like / likeCount / commentCount / viewCount / shareCount are read from
 *   the global content store (`useContentEngagement`). When ANY other
 *   component showing the same article.id updates the state, this
 *   component re-renders INSTANTLY with the new value — no Refresh.
 *
 *   This is the spec's central fix: a Like on a Home feed ArticleCard
 *   now appears "liked" on the Article reading page's bottom action row
 *   INSTANTLY — no Refresh required. Both components read from the same
 *   store slice (keyed by `article:${article.id}`).
 *
 * OPTIMISTIC UI (spec §3, §18, §30):
 *   - On click, we flip `liked` + bump `likeCount` INSTANTLY in the store
 *     (every subscribed component re-renders immediately).
 *   - The API call fires in the background.
 *   - On success: we reconcile with the server's authoritative response.
 *   - On failure: we rollback + toast error.
 *
 * DOUBLE-CLICK PREVENTION (spec §21, §29):
 *   - `likeLoading` flag in the store disables the Like button across
 *     ALL components showing this article.
 *
 * AUTH GATE (spec §6, §15):
 *   Like / Follow / Comment / Save require an authenticated account.
 *   When a logged-out visitor clicks Like, we DON'T show a generic
 *   "Failed" toast — instead we prompt them to sign in via a friendly
 *   toast + navigate to the auth screen. Public viewing (reading the
 *   article, seeing counts) is free.
 *
 * Security: the article ID is taken from the article prop (server-
 * sourced) — the user can't spoof it. The server derives the user from
 * the session cookie, never from the request body.
 */
export function ArticleActions({
  article,
}: ArticleActionsProps) {
  const router = useRouter();
  const { t } = useTranslation();
  const { user } = useAuthStore();

  // ── Subscribe to the unified engagement state ────────────────────────
  // This is the KEY change. Previously this component had its own local
  // useState for liked + likeCount + shareCount. Now it reads from the
  // global store — so every component showing this article shares the
  // SAME state.
  const {
    liked,
    likeCount,
    commentCount,
    viewCount,
    shareCount,
    likeLoading,
  } = useContentEngagement("article", article.id, {
    liked: article.isLiked ?? false,
    likeCount: article.likeCount ?? 0,
    commentCount: article.commentCount ?? 0,
    viewCount: article.viewCount ?? 0,
    shareCount: article.shareCount ?? 0,
  });

  // Local state only for the share dialog (UI-only — not engagement state).
  const [shareOpen, setShareOpen] = useState(false);

  // Phase 5 — Collections: Save-to-Collection dialog state. The button is
  // gated by the `collections` feature flag (server-side source of truth
  // mirrored client-side via useCollectionsEnabled). The contentType is
  // "article" OR "video" based on whether the article has a non-empty
  // videoUrl — both are saved to the same polymorphic CollectionItem table,
  // the contentType distinguishes them.
  const collectionsEnabled = useCollectionsEnabled();
  const [saveOpen, setSaveOpen] = useState(false);
  const saveContentType: "article" | "video" =
    typeof article.videoUrl === "string" && article.videoUrl.trim().length > 0
      ? "video"
      : "article";

  // Playlists — gated by the `playlists` feature flag (server-side source of
  // truth mirrored client-side via usePlaylistsEnabled). Unlike Collections
  // (which are polymorphic — post/article/video/discussion), Playlists are
  // article-specific, so we just pass the articleId directly.
  const playlistsEnabled = usePlaylistsEnabled();
  const [playlistOpen, setPlaylistOpen] = useState(false);

  const toggleLike = useCallback(async () => {
    if (likeLoading) return; // prevent double-click

    // ── AUTH GATE (spec §6, §15) ────────────────────────────────────────
    if (!user) {
      toast.info(t("auth.signInToLike") || "Sign in to like this article");
      router.push("/");
      return;
    }

    // Capture current state for rollback.
    const wasLiked = liked;
    const prevCount = likeCount;

    // ── Optimistic update — INSTANTLY flip the state in the store ───────
    // This re-renders EVERY component showing this article (Home feed,
    // Profile articles, Topic page, Search results, Article reading page,
    // etc.) — they all see the new liked + likeCount values immediately.
    useContentStore.getState().patch("article", article.id, {
      liked: !wasLiked,
      likeCount: prevCount + (wasLiked ? -1 : 1),
      likeLoading: true,
    });

    try {
      const data = await api.post<{ liked: boolean; likeCount: number }>(
        `/api/v1/articles/${article.id}/like`
      );
      // ── Reconcile with the server's authoritative response ────────────
      // The server is the source of truth (spec §18).
      useContentStore.getState().patch("article", article.id, {
        liked: data.liked,
        likeCount: data.likeCount,
        likeLoading: false,
      });
    } catch (e) {
      // ── Rollback on failure (spec §30) ────────────────────────────────
      useContentStore.getState().patch("article", article.id, {
        liked: wasLiked,
        likeCount: prevCount,
        likeLoading: false,
      });
      const msg = e instanceof ApiClientError ? e.message : "Failed to toggle like";
      toast.error(msg);
    }
  }, [liked, likeCount, article.id, likeLoading, user, router, t]);

  // ── Share handler — records the share server-side + opens the share
  //    dialog. Optimistically bumps shareCount in the store, then
  //    reconciles with the server's response. ─────────────────────────
  const handleShareClick = useCallback(async () => {
    setShareOpen(true);
    // Optimistically bump the local shareCount — the user sees the
    // number go up immediately across ALL components showing this article.
    const prevShareCount = shareCount;
    useContentStore.getState().patch("article", article.id, {
      shareCount: prevShareCount + 1,
    });
    try {
      const data = await api.post<{ shared: boolean; shareCount: number }>(
        `/api/v1/articles/${article.id}/share`,
        { method: "native" }
      );
      // Reconcile with server's authoritative response.
      useContentStore.getState().patch("article", article.id, {
        shareCount: data.shareCount,
      });
    } catch {
      // Revert on failure — the share didn't actually record.
      useContentStore.getState().patch("article", article.id, {
        shareCount: prevShareCount,
      });
      // Don't toast error — the share dialog opening is still useful
      // even if the server tracking failed.
    }
  }, [shareCount, article.id]);

  // Build the absolute article URL for the share dialog.
  // The article reading page is at /articles/[id] — this is a real
  // server-rendered route (not the SPA ?view= system), so the URL is
  // shareable to non-authenticated users + indexable by search engines.
  const articleUrl = typeof window !== "undefined"
    ? `${window.location.origin}/articles/${article.id}`
    : `/articles/${article.id}`;

  return (
    <>
      <div className="flex items-center justify-between gap-0">
        {/* Like button */}
        <button
          onClick={toggleLike}
          disabled={likeLoading}
          className={cn(
            "group flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-accent/50",
            liked && "text-red-500 hover:bg-red-500/10"
          )}
          aria-pressed={liked}
          aria-label={liked ? (t("posts.unlike") || "Unlike") : (t("posts.like") || "Like")}
        >
          <Heart
            className={cn(
              "h-[18px] w-[18px] transition-all duration-200",
              liked && "fill-current scale-110",
              likeLoading && "opacity-50"
            )}
          />
          {likeCount > 0 && (
            <span className="tabular-nums">{formatCount(likeCount)}</span>
          )}
        </button>

        {/* Comment button — navigates to the comments view.
            Reads commentCount from the unified store. */}
        <button
          onClick={() => router.push(`/?view=article-comments&articleId=${article.id}`)}
          className="group flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-sky-500"
          aria-label={t("posts.comment") || "Comment"}
        >
          <MessageCircle className="h-[18px] w-[18px]" />
          {commentCount > 0 && (
            <span className="tabular-nums">{formatCount(commentCount)}</span>
          )}
        </button>

        {/* Views — display only (smart unique views, no double-counting).
            Reads viewCount from the unified store. */}
        <div
          className="flex flex-1 items-center justify-center gap-1.5 py-2 text-[13px] font-medium text-muted-foreground"
          aria-label={t("posts.views") || "Views"}
          title={`${viewCount.toLocaleString()} ${t("posts.views") || "views"}`}
        >
          <Eye className="h-[18px] w-[18px]" />
          <span className="tabular-nums">{formatCount(viewCount)}</span>
        </div>

        {/* Share button — records the share server-side + opens dialog.
            shareCount is optimistically bumped + reconciled via the store. */}
        <button
          onClick={handleShareClick}
          className="group flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-emerald-500"
          aria-label={t("posts.share") || "Share"}
        >
          <Share2 className="h-[18px] w-[18px]" />
          {shareCount > 0 && (
            <span className="tabular-nums">{formatCount(shareCount)}</span>
          )}
        </button>

        {/* Phase 5 — Collections: Save to Collection button.
            Gated by the `collections` feature flag. */}
        {collectionsEnabled && (
          <button
            onClick={() => setSaveOpen(true)}
            className="group flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-amber-500"
            aria-label={t("collections.save") || "Save to collection"}
            title={t("collections.save") || "Save to collection"}
          >
            <BookmarkPlus className="h-[18px] w-[18px]" />
          </button>
        )}

        {/* Playlists — Add to Playlist button. Gated by the `playlists`
            feature flag. Distinct from the Collections Save button
            (Playlists are ordered article bundles; Collections are
            polymorphic). Per spec §16: "On the Article page there should
            be 'Add to Playlist' that opens the user's playlists + allows
            picking one or creating a new one." */}
        {playlistsEnabled && (
          <button
            onClick={() => setPlaylistOpen(true)}
            className="group flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-violet-500"
            aria-label={t("playlists.addToPlaylist") || "Add to playlist"}
            title={t("playlists.addToPlaylist") || "Add to playlist"}
          >
            <ListMusic className="h-[18px] w-[18px]" />
          </button>
        )}
      </div>

      {/* Share modal — minimal inline share dialog (native share API
          + copy-to-clipboard + social share links). */}
      {shareOpen && (
        <ShareDialogInline
          url={articleUrl}
          title={article.title}
          onClose={() => setShareOpen(false)}
        />
      )}

      {/* Phase 5 — Collections: Save-to-Collection dialog. */}
      {collectionsEnabled && (
        <SaveToCollectionDialog
          open={saveOpen}
          onOpenChange={setSaveOpen}
          contentType={saveContentType}
          contentId={article.id}
        />
      )}

      {/* Playlists — Add-to-Playlist dialog. */}
      {playlistsEnabled && (
        <SaveToPlaylistDialog
          open={playlistOpen}
          onOpenChange={setPlaylistOpen}
          articleId={article.id}
        />
      )}
    </>
  );
}

/**
 * Minimal inline share dialog for articles. Mirrors the post ShareDialog
 * behavior: native share API (mobile), copy-to-clipboard, social share
 * links. Could be replaced with the full ShareDialog component if it
 * were generalized — for now this is a self-contained fallback that
 * avoids coupling article actions to post-specific assumptions.
 */
function ShareDialogInline({
  url,
  title,
  onClose,
}: {
  url: string;
  title: string;
  onClose: () => void;
}) {
  const { t } = useTranslation();
  const [copied, setCopied] = useState(false);

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      toast.success(t("posts.linkCopied") || "Link copied to clipboard");
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error(t("posts.copyFailed") || "Failed to copy link");
    }
  }

  async function nativeShare() {
    if (typeof navigator !== "undefined" && "share" in navigator) {
      try {
        await navigator.share({ title, url });
      } catch {
        // User cancelled — no-op.
      }
    } else {
      copyLink();
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-4" onClick={onClose}>
      <div
        className="w-full max-w-sm rounded-t-2xl bg-background p-4 shadow-xl sm:rounded-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-base font-semibold">{t("posts.sharePost") || "Share"}</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground" aria-label="Close">×</button>
        </div>
        <div className="space-y-2">
          {typeof navigator !== "undefined" && "share" in navigator && (
            <button
              onClick={nativeShare}
              className="flex w-full items-center gap-2 rounded-lg border p-3 text-sm font-medium hover:bg-accent"
            >
              <Share2 className="h-4 w-4" />
              {t("posts.shareVia") || "Share via…"}
            </button>
          )}
          <div className="flex items-center gap-2 rounded-lg border p-3">
            <input
              readOnly
              value={url}
              className="min-w-0 flex-1 bg-transparent text-sm text-muted-foreground outline-none"
              onFocus={(e) => e.currentTarget.select()}
            />
            <button
              onClick={copyLink}
              className="shrink-0 rounded-md bg-primary px-3 py-1 text-xs font-medium text-primary-foreground hover:bg-primary/90"
            >
              {copied ? "✓" : (t("posts.copyLink") || "Copy")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
