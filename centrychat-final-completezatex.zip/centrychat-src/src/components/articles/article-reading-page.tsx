"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowLeft, Pencil, Trash2, BarChart3, Loader2 } from "lucide-react";
import { useTranslation } from "@/lib/client/i18n-store";
import { useAuthStore } from "@/lib/client/auth-store";
import { contentStore } from "@/lib/client/content-store";
import { MediaRenderer } from "@/components/media/media-renderer";
import { useMediaResolver, setCachedMedia } from "@/hooks/use-media-resolver";
import { ArticleActions } from "@/components/articles/article-actions";
import { PlaylistNavigation } from "@/components/playlists/playlist-navigation";
import { ArticleImageFrame } from "@/components/articles/article-image-frame";
import type { ResolvedMedia } from "@/lib/media/types";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { api, ApiClientError } from "@/lib/client/api";
// NOTE (Phase 3.5): `trackArticleView` is intentionally NOT imported here.
// The article_view AnalyticsEvent is now fired by the
// /api/v1/articles/[id]/views endpoint itself (single canonical flow — see
// src/lib/analytics/article-view-tracking.ts). Calling trackArticleView
// from the client would double-count: one event from /views (authoritative)
// + one from /analytics/track (permissive). The /views route is the only
// canonical path for article_view events.
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { AdSlot } from "@/components/ads/adsense";

export interface ArticleDTO {
  id: string;
  authorId: string;
  title: string;
  content: string;
  excerpt: string | null;
  coverImage: string | null;
  videoUrl: string | null;
  // Phase 18 — image presentation config. Nullable so old articles
  // (pre-dating the migration) keep working — ArticleImageFrame
  // treats null as the natural default (zoom=1, center).
  imageZoom?: number | null;
  imagePositionX?: number | null;
  imagePositionY?: number | null;
  // Cover image visibility inside the article detail page.
  // When false: the cover image is NOT rendered inside the article (but
  // still shows on Home feed + SEO/OG metadata). Defaults to true.
  showCoverInArticle?: boolean;
  status: string;
  publishedAt: string | null;
  readingTime: number;
  createdAt: string;
  updatedAt: string;
  author: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  // Phase — Article social features. Same shape as ArticleCardDTO.
  likeCount: number;
  commentCount: number;
  viewCount: number;
  shareCount: number;
  isLiked: boolean;
}

export function ArticleReadingPage({
  article,
  initialCoverMedia = null,
  initialVideoMedia = null,
}: {
  article: ArticleDTO;
  /**
   * Pre-resolved cover media (server-side). When provided, the client-side
   * `useMediaResolver` hook reads from its in-memory cache synchronously
   * — NO API call to /api/v1/media/resolve. This is the ROOT FIX for
   * "Not Media available" appearing for anonymous visitors (Google
   * referrers, Incognito browsers, direct link clicks).
   *
   * The server route /articles/[id]/page.tsx calls `resolveMedia()`
   * directly (the same function the API uses, but invoked from the
   * server component without an auth check). The result is passed here
   * as a prop, and we seed it into the client cache via `setCachedMedia`
   * on mount.
   *
   * When null (server couldn't resolve — external host unreachable, etc.),
   * the client hook will attempt to call the API, which is auth-gated.
   * Logged-in users get a re-resolve; logged-out users see the fallback
   * card. This is acceptable because the server resolution already tried
   * and failed — the client would fail too.
   */
  initialCoverMedia?: ResolvedMedia | null;
  /** Same as initialCoverMedia but for the article's videoUrl. */
  initialVideoMedia?: ResolvedMedia | null;
}) {
  const router = useRouter();
  const { t, fmtRelative } = useTranslation();
  const { user: currentUser, fetchUser } = useAuthStore();
  const [deleting, setDeleting] = useState(false);

  // ── Hydrate the auth store on mount ──────────────────────────────────
  // Problem 3 fix: article pages are rendered as a separate Next.js route
  // (/articles/[id]) which does NOT go through the SPA entry (src/app/page.tsx)
  // where fetchUser() is normally called. Without this call, `currentUser`
  // is always null on article pages — which means:
  //   1. The self-view exclusion (line ~209) never fires client-side.
  //   2. The isOwner/isAdmin checks (line ~153) are always false — the
  //      author can't see Edit/Delete/Insights buttons on their own article.
  //   3. The server-side /views endpoint still correctly identifies the
  //      user via the session cookie, so views ARE recorded. But the
  //      client doesn't know who the user is until this call completes.
  //
  // fetchUser() is a no-op if the session cookie is not present (returns
  // null — anonymous visitor). This is safe for logged-out users: it just
  // confirms they're anonymous, enabling the correct client-side behavior.
  //
  // Runs ONCE on mount. React Strict Mode double-invokes effects in dev,
  // but fetchUser() is idempotent (it just re-fetches /api/v1/auth/me and
  // updates the store — no side effects).
  useEffect(() => {
    void fetchUser();
  }, [fetchUser]);

  // ── Seed the client-side media cache with server-resolved media ──────
  // This runs ONCE on mount (before paint) so the `useMediaResolver` hook
  // below finds the result in cache and skips the API call entirely.
  //
  // Why this is safe:
  //   - The server already validated the URL via `resolveMedia()` (SSRF
  //     protection, scheme check, redirect cap, timeout).
  //   - The cache key is the original URL — if the article's coverImage
  //     changes later, the new URL gets a fresh resolve.
  //   - The cache is module-level (shared across components), so even
  //     if the user navigates to another article with the same cover URL,
  //     they get the cached result instantly.
  //
  // We use a ref guard to ensure this runs ONLY on the first mount —
  // React strict mode double-invokes effects in dev, and we don't want
  // to re-seed the cache with stale data on subsequent renders.
  const seededRef = useRef(false);
  useEffect(() => {
    if (seededRef.current) return;
    seededRef.current = true;
    if (initialCoverMedia && article.coverImage) {
      setCachedMedia(article.coverImage, initialCoverMedia);
    }
    if (initialVideoMedia && article.videoUrl) {
      setCachedMedia(article.videoUrl, initialVideoMedia);
    }
  }, [initialCoverMedia, initialVideoMedia, article.coverImage, article.videoUrl]);

  // Resolve both coverImage + videoUrl via the UniversalMediaResolver.
  // debounceMs=0 means "resolve immediately" — the reading page already
  // has the URL stored in the DB, we don't need to debounce (unlike the
  // editor where the user is actively typing).
  //
  // When the SSR route passed `initialCoverMedia`, the cache is already
  // seeded (above), so this hook returns the resolved media SYNCHRONOUSLY
  // on first render — no loading spinner, no API call, no auth dependency.
  const { media: coverMedia, loading: coverLoading } = useMediaResolver(article.coverImage, 0);
  const { media: videoMedia, loading: videoLoading } = useMediaResolver(article.videoUrl, 0);

  // Owner check — show Edit/Delete/Insights only for the author.
  const isOwner = currentUser?.id === article.authorId;
  const isAdmin = currentUser?.role === "ADMIN" || currentUser?.role === "SUPER_ADMIN";
  const canManage = isOwner || isAdmin;

  // ── Universal view tracking (spec §1, §5, §14) ────────────────────
  // Fires POST /api/v1/articles/:id/views ONCE when the article page
  // is opened. Works for BOTH logged-in users AND anonymous visitors
  // (Google referrers, direct link clicks, Incognito browsers).
  //
  // The endpoint is PUBLIC (no auth required) — it uses the visitor
  // cookie (cc_visitor) for anonymous dedup. The server:
  //   1. Skips known bots/crawlers (Googlebot, WhatsApp, Facebook, etc.).
  //   2. Dedups by userId for logged-in users (DB @@unique constraint).
  //   3. Dedups by anonymousVisitorId for logged-out users (DB @@unique).
  //   4. Rate-limits per IP (60/min — defense-in-depth against cookie rotation).
  //   5. Returns the new viewCount so we can update the UI without re-fetching.
  //
  // ── Phase 3.5: SINGLE canonical view flow ───────────────────────────
  // The /views endpoint is now the SINGLE entry point for valid article
  // views. When a NEW unique view is recorded, the SAME endpoint fires
  // an `article_view` AnalyticsEvent in the background (see
  // src/lib/analytics/article-view-tracking.ts). The public ArticleView
  // count + the admin AnalyticsEvent stream therefore represent the
  // SAME underlying valid view events — no divergence.
  //
  // We NO LONGER call /api/v1/analytics/track separately for article_view
  // (the old `trackArticleView(article.id)` call below). That would have
  // double-counted: one event from the /views route (authoritative, with
  // bot/dedup/self-view exclusion) + one from /analytics/track (permissive,
  // included self-views). The /views route is the only canonical path now.
  //
  // Idempotency (spec §15 — Double Request Protection):
  //   - `viewFiredRef` ensures we only fire ONCE per component mount. React
  //     Strict Mode double-invokes effects in dev, but the ref guard skips
  //     the second invocation.
  //   - The server-side DB dedup is the authoritative guard — even if the
  //     client somehow sends two requests, only one row survives.
  //
  // Error handling (spec §22):
  //   Failures are silently swallowed — view tracking must NEVER break
  //   the article reading experience. The article content is already
  //   rendered server-side; this is fire-and-forget analytics.
  //
  // Author self-view exclusion (spec §6):
  //   Skip the request entirely when the current user is the article's
  //   author — saves a network round-trip (the server also enforces this,
  //   but skipping client-side avoids the unnecessary call).
  //
  // ── Problem 3 fix: wait for auth to hydrate before firing ───────────
  //   The auth store is hydrated by the `fetchUser()` effect above. If we
  //   fire the /views call BEFORE `currentUser` is populated, we'd skip
  //   the self-view check (currentUser is null → not the author → fire).
  //   For the article AUTHOR, this means their self-view would be sent to
  //   the server (which correctly rejects it — returns recorded=false).
  //   For NON-authors (both logged-in and anonymous), the view is recorded
  //   regardless. So waiting for `currentUser` only helps avoid an
  //   unnecessary network call for the author — it doesn't affect whether
  //   the view is recorded for non-authors.
  //
  //   However, we must NOT wait indefinitely. If `fetchUser()` is slow or
  //   fails, we still want to record the view. So we use a SHORT timeout
  //   (1.5s) — if the auth store hasn't hydrated by then, we fire the
  //   /views call anyway (the server will handle the self-view exclusion).
  const viewFiredRef = useRef(false);
  useEffect(() => {
    if (viewFiredRef.current) return; // only fire once per mount
    if (article.status !== "PUBLISHED") return; // drafts don't count

    // Author self-view exclusion (spec §6).
    // The /views endpoint also enforces this server-side, but skipping
    // the call client-side saves a round-trip + avoids polluting the
    // network panel with a 200/recorded=false response.
    if (currentUser && currentUser.id === article.authorId) return; // self-view

    viewFiredRef.current = true;

    // Fire-and-forget — view tracking is best-effort analytics. Failures
    // are silently swallowed (spec §22 — view tracking must NOT break the
    // article reading experience).
    //
    // Problem 3 fix: UPDATE THE UI LIVE after the view is recorded.
    // The /views endpoint returns { recorded: boolean, viewCount: number }.
    // When `recorded === true`, the view count in the DB increased by 1.
    // We patch the content store with the new viewCount so the
    // ArticleActions component (which reads from the content store via
    // useContentEngagement) re-renders with the updated count — INSTANTLY,
    // without requiring a page refresh. This works for BOTH authenticated
    // AND anonymous visitors (the /views endpoint handles both).
    //
    // When `recorded === false` (duplicate view, bot, rate-limited,
    // author self-view), we do NOT patch the store — the count is
    // unchanged in the DB, so the UI should stay unchanged too.
    //
    // The /views endpoint internally fires the article_view AnalyticsEvent
    // for the SAME valid view (Phase 3.5 — single canonical flow). We do
    // NOT call /api/v1/analytics/track separately here.
    void api
      .post<{ recorded: boolean; viewCount: number }>(`/api/v1/articles/${article.id}/views`)
      .then((response) => {
        // Only patch the store if a NEW view was actually recorded.
        // This prevents the UI from flickering on duplicate/bot/rate-limited
        // requests (where the server returns the same count the UI already
        // shows).
        if (response?.recorded && typeof response.viewCount === "number") {
          contentStore.patch("article", article.id, {
            viewCount: response.viewCount,
          });
        }
      })
      .catch(() => {
        // Non-fatal — view tracking failures should NOT break the reading
        // experience. We just silently skip the view record + the UI
        // update (the SSR-rendered count stays as-is).
      });
  }, [article.id, article.authorId, article.status, currentUser]);

  async function handleDelete() {
    setDeleting(true);
    try {
      await api.delete(`/api/v1/articles/${article.id}`);
      toast.success("Article deleted");
      // Notify any subscribed screen so they can remove the article.
      window.dispatchEvent(
        new CustomEvent("post:deleted", { detail: { id: article.id } })
      );
      // Navigate back to the user's profile (or home).
      router.push(`/?view=profile&username=${encodeURIComponent(article.author.username)}`);
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to delete article";
      toast.error(msg);
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile back button */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()} title="Back">
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <p className="truncate text-sm font-medium">Article</p>
        {/* Owner actions on mobile — compact icons in the header */}
        {canManage && (
          <div className="ml-auto flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => router.push(`/?view=article-insights&articleId=${article.id}`)}
              aria-label="Article Insights"
              title="Article Insights"
            >
              <BarChart3 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => router.push(`/?view=article-editor&id=${article.id}`)}
              aria-label="Edit article"
              title="Edit Article"
            >
              <Pencil className="h-4 w-4" />
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                  aria-label="Delete article"
                  title="Delete Article"
                  disabled={deleting}
                >
                  {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this article?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This article will be permanently deleted. This action cannot be undone.
                    All likes, comments, and views will be removed.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDelete}
                    className={cn("bg-destructive text-destructive-foreground hover:bg-destructive/90")}
                  >
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        )}
      </header>

      {/* <main> wraps the article for explicit semantic landmark (spec §16).
          Visually identical to a <div> — <main> has no UA default styling
          beyond display:block, so this changes NOTHING in the rendered
          layout. It only improves accessibility + SEO by giving screen
          readers + search engines a clear "this is the main content"
          signal. The <article> inside remains the primary content
          container; <main> just marks the region. */}
      <main>
        <article className="mx-auto max-w-3xl px-4 py-8 md:py-12">
        {/* Desktop back + owner actions */}
        <div className="mb-6 flex items-center gap-2">
          <Button variant="ghost" onClick={() => router.back()} className="hidden md:flex">
            <ArrowLeft className="mr-2 h-4 w-4 rtl-flip" /> Back
          </Button>
          {canManage && (
            <div className="ml-auto flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push(`/?view=article-insights&articleId=${article.id}`)}
                className="gap-1.5"
              >
                <BarChart3 className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Insights</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => router.push(`/?view=article-editor&id=${article.id}`)}
                className="gap-1.5"
              >
                <Pencil className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Edit</span>
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1.5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                    disabled={deleting}
                  >
                    {deleting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
                    <span className="hidden sm:inline">Delete</span>
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete this article?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This article will be permanently deleted. This action cannot be undone.
                      All likes, comments, and views will be removed.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleDelete}
                      className={cn("bg-destructive text-destructive-foreground hover:bg-destructive/90")}
                    >
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          )}
        </div>

        {/* ARTICLE_TOP ad — rendered ABOVE the cover image so it doesn't
            push the title/cover down (it adds horizontal space above the
            fold). Renders nothing when ads are disabled. */}
        <AdSlot placement="ARTICLE_TOP" />

        {/* Cover image — resolved via UniversalMediaResolver. Handles direct
            images, og:image extraction from webpages, and shows a fallback
            card for embeds/unknown URLs.

            COVER IMAGE VISIBILITY CONTROL:
              When article.showCoverInArticle === false, the cover image is
              NOT rendered inside the article detail page (spec). The cover
              image URL is preserved in the article data — it's still used
              for:
                - Home feed Article Card (always shows the cover)
                - SEO og:image + Twitter card image
                - JSON-LD Article image
              This is a DISPLAY-ONLY toggle — no data is deleted.

              Performance: when false, the image is NOT loaded at all (no
              <img> tag, no network request) — not just hidden via CSS.
              This saves bandwidth + improves loading time.

            Phase 18 — when the URL resolves as an image, we render it via
            ArticleImageFrame (overflow:hidden + transform
            + touch-action: pan-y) so the saved zoom/position is applied
            AND the image can never become an independent scrollable
            container. The image is NOT a link — it lives inside the
            article reading page (the user is already on /articles/[id]). */}
        {article.coverImage && article.showCoverInArticle !== false && (
          <div className="mb-8">
            {coverMedia && coverMedia.type === "image" && coverMedia.mediaUrl ? (
              <ArticleImageFrame
                src={coverMedia.mediaUrl}
                alt={article.title}
                config={{
                  zoom: article.imageZoom,
                  positionX: article.imagePositionX,
                  positionY: article.imagePositionY,
                }}
                variant="full"
                className="rounded-2xl"
              />
            ) : (
              <div className="overflow-hidden rounded-2xl">
                <MediaRenderer
                  media={coverMedia}
                  loading={coverLoading}
                  variant="full"
                  alt={article.title}
                  titleHint={article.title}
                  className="w-full"
                />
              </div>
            )}
          </div>
        )}

        {/* Video — resolved via UniversalMediaResolver. Renders as:
              - <iframe> for YouTube/Vimeo/TikTok/Instagram/Facebook/X/Reddit
              - <video controls> for direct video files
              - fallback card for unknown URLs */}
        {article.videoUrl && (
          <div className="mb-8 overflow-hidden rounded-2xl">
            <MediaRenderer
              media={videoMedia}
              loading={videoLoading}
              variant="full"
              alt={article.title}
              titleHint={article.title}
            />
          </div>
        )}

        {/* Title */}
        <h1 className="text-3xl font-bold leading-tight tracking-tight md:text-4xl" dir="auto">
          {article.title}
        </h1>

        {/* Author + meta */}
        <div className="mt-6 flex flex-wrap items-center gap-3 border-b pb-6">
          <Avatar
            name={article.author.fullName}
            color={article.author.avatarColor}
            src={article.author.avatarUrl}
            size="md"
            className="cursor-pointer"
            onClick={() => router.push(`/?view=profile&username=${encodeURIComponent(article.author.username)}`)}
          />
          <div className="min-w-0 flex-1">
            <button
              onClick={() => router.push(`/?view=profile&username=${encodeURIComponent(article.author.username)}`)}
              className="flex items-center gap-1.5 text-sm font-semibold hover:underline"
              dir="auto"
            >
              {article.author.fullName}
              {article.author.isVerified && <VerifiedBadge size={14} />}
            </button>
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              {article.publishedAt && (
                <span className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {fmtRelative(article.publishedAt)}
                </span>
              )}
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {article.readingTime} min read
              </span>
            </div>
          </div>

        </div>

        {/* ARTICLE_MIDDLE ad — placed BETWEEN the author/meta row and the
            article body. This is the canonical "in-article" placement
            (spec §20). Renders nothing when ads are disabled. */}
        <AdSlot placement="ARTICLE_MIDDLE" />

        {/* Content */}
        <div
          className="mt-8 whitespace-pre-wrap break-words text-[17px] leading-[1.8] text-foreground"
          dir="auto"
        >
          {article.content}
        </div>

        {/* Action bar — Like / Comment / Views / Share.
            Renders for ALL viewers (visitor + owner). Same row as PostCard
            uses for visual consistency (spec §12). */}
        <div className="mt-8 border-t border-border/40 pt-2">
          <ArticleActions article={article} />
        </div>

        {/* Playlist Navigation (spec §5) — when this Article is part of one
            or more Playlists, show the current position + Prev/Next navigation
            + a link to view the full playlist on /playlist/[slug]. Renders
            nothing when the article is not in any playlist. */}
        <PlaylistNavigation articleId={article.id} />

        {/* ARTICLE_BOTTOM ad — placed AFTER the action bar + before the
            desktop back button. This is the bottom-of-article placement
            (spec §20). Renders nothing when ads are disabled. */}
        <AdSlot placement="ARTICLE_BOTTOM" />

        {/* Desktop back button (bottom) */}
        <div className="mt-12 border-t pt-6">
          <Button variant="ghost" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4 rtl-flip" />
            Back
          </Button>
        </div>
        </article>
      </main>
    </div>
  );
}
