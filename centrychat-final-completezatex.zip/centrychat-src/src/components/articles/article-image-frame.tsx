"use client";

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import {
  normalizeImageConfig,
  isDefaultConfig,
  buildImageTransform,
  type ArticleImageConfig,
} from "@/lib/articles/image-config";

/**
 * ArticleImageFrame — the SINGLE renderer for an article cover image.
 *
 * Used by:
 *   - ArticleCard (homepage / profile feed)
 *   - ArticleReadingPage (the published article)
 *   - ArticleEditor (the live preview shown while editing)
 *
 * GUARANTEES (Phase 18 — Image Display Lock):
 *   1. The container is `overflow: hidden` + has a controlled aspect
 *      ratio. The image NEVER creates its own scroll container.
 *      No `overflow: auto`, `overflow: scroll`, `overflow-x/y: auto`.
 *      No nested scrollbars. No touch-scrolling inside the image.
 *      No accidental drag-to-scroll.
 *
 *   2. The image is rendered with `pointer-events: none` (so it can't
 *      capture touch-scroll either) + `draggable={false}` (so it can't
 *      be native-dragged into a new tab).
 *
 *   3. The image NEVER links to its source URL. The caller controls
 *      navigation entirely — this component just renders pixels.
 *
 *   4. The saved zoom/position config (imageZoom, imagePositionX/Y) is
 *      applied via CSS `transform: translate(Xpx, Ypx) scale(zoom)`
 *      with `transform-origin: center center`. NULL config = defaults
 *      (zoom = 1.0, position = center) — old articles render unchanged.
 *
 *   5. The image uses `object-fit: cover` so it fills the container
 *      regardless of its native aspect ratio. Pinterest portraits,
 *      landscapes, squares, and very tall images ALL render correctly
 *      without internal scrolling. The `transform` then crops/zooms
 *      within that fixed frame.
 *
 *   6. Image-load failures show the fallback alt text inline (no
 *      external broken-image icon) — the caller can wrap this in a
 *      <MediaRenderer> fallback for richer handling.
 *
 * NOTE: this component does NOT call useMediaResolver. The caller
 * passes a DIRECT image URL (already resolved by the resolver when
 * available). For URLs that haven't been resolved yet (e.g. the SSR
 * article page where we only have the raw stored `coverImage` URL),
 * the image is loaded directly — if it fails, the alt text shows.
 */

export interface ArticleImageFrameProps {
  /** Direct image URL (already resolved by useMediaResolver when applicable). */
  src: string;
  /** Alt text (article title is a good default). */
  alt: string;
  /** Saved image config (zoom/position). NULL = natural defaults. */
  config?: {
    zoom?: number | null;
    positionX?: number | null;
    positionY?: number | null;
  } | null;
  /**
   * Visual variant:
   *   - "card"      → 4:3 fixed aspect (homepage / profile card)
   *   - "mobile"    → 1:1 square (mobile card variant)
   *   - "full"      → max-h-[400px], fluid width (reading page)
   *   - "editor"    → 16:9 fixed aspect (live preview in editor)
   */
  variant?: "card" | "mobile" | "full" | "editor";
  /** Optional className on the outer container. */
  className?: string;
}

const VARIANT_ASPECT_CLASS: Record<NonNullable<ArticleImageFrameProps["variant"]>, string> = {
  card: "aspect-[4/3]",
  mobile: "aspect-square",
  // "full" variant uses max-height instead of an aspect ratio — the
  // width is fluid (100%) and the height is capped so very tall images
  // don't take over the whole viewport on the reading page.
  full: "max-h-[400px] w-full aspect-auto",
  editor: "aspect-video",
};

export function ArticleImageFrame({
  src,
  alt,
  config = null,
  variant = "card",
  className,
}: ArticleImageFrameProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  // Reset loaded/failed when the src changes — using the React-recommended
  // "store previous prop" pattern (https://react.dev/reference/react/useState#storing-information-from-previous-renders)
  // rather than useEffect+setState (which triggers the lint rule
  // react-hooks/set-state-in-effect + causes a cascading render).
  const [prevSrc, setPrevSrc] = useState(src);
  if (prevSrc !== src) {
    setPrevSrc(src);
    setLoaded(false);
    setFailed(false);
  }

  // The container's pixel dimensions, used to convert fractional
  // position offsets into pixel translate values. We measure via
  // ResizeObserver so the transform stays correct when the viewport
  // resizes (mobile rotation, sidebar collapse, etc.).
  const [containerPx, setContainerPx] = useState<{ width: number; height: number }>({
    width: 0,
    height: 0,
  });

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => {
      const rect = el.getBoundingClientRect();
      setContainerPx({ width: rect.width, height: rect.height });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const cfg: ArticleImageConfig = normalizeImageConfig({
    zoom: config?.zoom ?? null,
    positionX: config?.positionX ?? null,
    positionY: config?.positionY ?? null,
  });

  const transform = isDefaultConfig(cfg)
    ? undefined
    : buildImageTransform(cfg, containerPx);

  return (
    <div
      ref={containerRef}
      className={cn(
        // CRITICAL: overflow-hidden + touch-action: none on the
        // container guarantees the image can NEVER become an
        // independent scrollable element. No `overflow: auto/scroll`,
        // no `overflow-x/y: auto`. See Phase 18 spec §1, §2, §31.
        "relative overflow-hidden bg-muted/30",
        VARIANT_ASPECT_CLASS[variant],
        className
      )}
      // `touch-action: pan-y` lets vertical page-scroll pass THROUGH
      // the container (so users can still scroll the page even when
      // their finger starts on the image). It blocks horizontal pan
      // + pinch-zoom inside the image so the saved zoom/position
      // can't be accidentally modified by touch gestures on the
      // published article (editing only happens in the editor).
      style={{ touchAction: "pan-y" }}
    >
      {!loaded && !failed && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="h-5 w-5 animate-spin rounded-full border-2 border-muted-foreground/30 border-t-muted-foreground" />
        </div>
      )}
      {failed ? (
        <div className="absolute inset-0 flex items-center justify-center p-4 text-center">
          <span className="line-clamp-2 text-xs text-muted-foreground" dir="auto">
            {alt}
          </span>
        </div>
      ) : (
        <img
          src={src}
          alt={alt}
          // pointer-events-none so the image can never capture touch
          // events meant for page-scroll. draggable=false so the
          // browser doesn't let the user native-drag the image into
          // a new tab (which would navigate away from the article).
          className={cn(
            "h-full w-full object-cover transition-opacity duration-200",
            loaded ? "opacity-100" : "opacity-0"
          )}
          style={{
            transform,
            transformOrigin: "center center",
            pointerEvents: "none",
          }}
          draggable={false}
          loading={variant === "full" ? "eager" : "lazy"}
          onLoad={(e) => {
            const img = e.currentTarget;
            if (img.naturalWidth > 0 && img.naturalHeight > 0) {
              setLoaded(true);
            } else {
              setFailed(true);
            }
          }}
          onError={() => setFailed(true)}
        />
      )}
    </div>
  );
}
