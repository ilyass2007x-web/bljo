"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Loader2, MessageSquareLock } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { usePlatformName, usePlatformDescription } from "@/lib/client/platform";
import { COUNTRIES } from "@/lib/countries";

type Mode = "login" | "register" | "forgot" | "reset" | "verify";

export function AuthScreen({ initialMode = "login" }: { initialMode?: Mode }) {
  const router = useRouter();
  const params = useSearchParams();
  const fetchUser = useAuthStore((s) => s.fetchUser);
  const { t } = useTranslation();
  // Dynamic platform name + description — fetched from /api/v1/settings/public
  // on mount, falls back to the i18n locale value while loading. When the
  // admin changes Platform Name in Settings, the next fetch (within 60s)
  // updates these values + the browser tab title (via generateMetadata).
  const platformName = usePlatformName(t("app.name"));
  const platformDescription = usePlatformDescription(t("app.tagline"));

  const [mode, setMode] = useState<Mode>(() => {
    const v = params.get("view");
    // Accept both short ("reset") and email-link ("reset-password") formats.
    if (v === "register" || v === "forgot") return v as Mode;
    if (v === "reset" || v === "reset-password") return "reset";
    if (v === "verify" || v === "verify-email") return "verify";
    return initialMode;
  });
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    username: "",
    password: "",
    confirmPassword: "",
    token: params.get("token") ?? "",
    // Gender + country are REQUIRED for new accounts (used by Video Chat).
    gender: "",
    dateOfBirth: "",
    countryCode: "",
  });
  const [usernameStatus, setUsernameStatus] = useState<{ available: boolean; suggestions?: string[] } | null>(null);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "login") {
        await api.post("/api/v1/auth/login", {
          email: form.email,
          password: form.password,
        });
        await fetchUser();
        toast.success(t("auth.welcomeBack"));
        router.push("/");
      } else if (mode === "register") {
        // ── ISSUE 3 FIX: auto-login after registration ─────────────
        // The server now ALWAYS creates the user as ACTIVE + returns a
        // sessionId. We call fetchUser() to hydrate the auth store from
        // the session cookie, then redirect to the home page — no
        // "Verify your email" blocking screen.
        //
        // The verification email is still sent (via Resend) — it's now
        // informational, not blocking. The user can click it later to
        // confirm their email, but they're already inside the app.
        await api.post("/api/v1/auth/register", {
          fullName: form.fullName,
          email: form.email,
          username: form.username,
          password: form.password,
          confirmPassword: form.confirmPassword,
          // Gender is REQUIRED for new accounts (Video Chat matchmaking).
          gender: form.gender || null,
          // Country is REQUIRED for new accounts (ISO 3166-1 alpha-2 code).
          countryCode: form.countryCode || null,
          // Send DOB only if the user picked a date. <input type="date">
          // emits "" when empty — the server treats that as null.
          dateOfBirth: form.dateOfBirth || null,
        });
        // The server set the session cookie (via createSession). Fetch
        // the user to hydrate the auth store, then redirect to home.
        await fetchUser();
        toast.success(t("auth.accountCreated"));
        router.push("/");
      } else if (mode === "forgot") {
        await api.post("/api/v1/auth/forgot-password", { email: form.email });
        // Only show success toast here — if the API returned an error,
        // we never reach this line (the await throws and we go to catch).
        // The catch block shows the real error message via toast.error().
        toast.success(t("auth.resetSent"));
        setMode("login");
      } else if (mode === "reset") {
        await api.post("/api/v1/auth/reset-password", {
          token: form.token,
          password: form.password,
          confirmPassword: form.confirmPassword,
        });
        toast.success(t("auth.passwordReset"));
        setMode("login");
      } else if (mode === "verify") {
        await api.post("/api/v1/auth/verify-email", { token: form.token });
        toast.success(t("auth.emailVerified"));
        setMode("login");
      }
    } catch (err) {
      let msg: string;
      if (err instanceof ApiClientError) {
        msg = err.message;
        if (err.status === 500) {
          try {
            const diag = await fetch("/api/v1/diagnostics").then((r) => r.json());
            if (diag?.instructions) {
              msg = `${err.message}\n\n${diag.instructions.title}:\n${diag.instructions.steps.join("\n")}`;
            }
          } catch {
            /* ignore */
          }
        }
      } else if (err instanceof TypeError && err.message.includes("fetch")) {
        msg = t("auth.cannotConnect");
      } else {
        msg = "Something went wrong. Please try again.";
      }
      toast.error(msg, { duration: 10000 });
    } finally {
      setLoading(false);
    }
  }

  // Max date for the DOB picker: today (in the user's local timezone).
  // <input type="date"> uses YYYY-MM-DD format; this is what we feed to `max`.
  // The server ALSO validates against future dates (defense-in-depth) — see
  // validateDateOfBirth in src/lib/profile.ts.
  const todayIso = new Date().toISOString().split("T")[0];

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-background to-muted/30 p-4">
      <div className="mb-8 flex flex-col items-center gap-3">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
          <MessageSquareLock className="h-7 w-7" />
        </div>
        <div className="text-center">
          <h1 className="text-2xl font-bold tracking-tight">{platformName}</h1>
          <p className="text-sm text-muted-foreground">{platformDescription}</p>
        </div>
      </div>

      <Card className="w-full max-w-md shadow-xl">
        <CardHeader>
          <CardTitle>
            {mode === "login" && t("auth.signIn")}
            {mode === "register" && t("auth.createAccount")}
            {mode === "forgot" && t("auth.resetPassword")}
            {mode === "reset" && t("auth.resetPassword")}
            {mode === "verify" && t("auth.verifyEmail")}
          </CardTitle>
          <CardDescription>
            {mode === "login" && t("auth.enterCredentials")}
            {mode === "register" && t("auth.createNewAccount")}
            {mode === "forgot" && t("auth.sendResetLinkDesc")}
            {mode === "reset" && t("auth.setNewPassword")}
            {mode === "verify" && t("auth.enterVerificationToken")}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            {mode === "register" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="fullName">{t("auth.fullName")}</Label>
                  <Input id="fullName" value={form.fullName} onChange={set("fullName")} autoComplete="name" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <div className="relative">
                    {/* Visual @ prefix OUTSIDE the input — per spec §2, the
                        prefix can be a visual decoration, but the input value
                        must NOT contain "@3bdo" or any default. The user
                        types their username from scratch. */}
                    <span className="absolute left-3 top-2.5 text-muted-foreground pointer-events-none">@</span>
                    <Input
                      id="username"
                      value={form.username}
                      onChange={(e) => {
                        setForm((f) => ({ ...f, username: e.target.value }));
                        setUsernameStatus(null);
                      }}
                      onBlur={async () => {
                        if (form.username.length < 3) return;
                        try {
                          const res = await api.post<{ available: boolean; suggestions?: string[] }>("/api/v1/username-check", { username: form.username });
                          setUsernameStatus(res);
                        } catch { /* ignore */ }
                      }}
                      className="pl-7"
                      placeholder="Choose a username"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      autoComplete="username"
                      required
                    />
                  </div>
                  {usernameStatus && !usernameStatus.available && (
                    <div className="text-xs text-destructive">
                      This username is already taken.
                      {usernameStatus.suggestions && usernameStatus.suggestions.length > 0 && (
                        <span className="ml-1">
                          Try: {usernameStatus.suggestions.map((s) => (
                            <button
                              key={s}
                              type="button"
                              onClick={() => { setForm((f) => ({ ...f, username: s })); setUsernameStatus(null); }}
                              className="ml-1 text-primary hover:underline"
                            >
                              @{s}
                            </button>
                          ))}
                        </span>
                      )}
                    </div>
                  )}
                  {usernameStatus && usernameStatus.available && (
                    <div className="text-xs text-green-600">✓ Available</div>
                  )}
                </div>

                {/* Gender (required) — used by Video Chat matchmaking. */}
                <div className="space-y-2">
                  <Label htmlFor="gender">
                    Gender <span className="text-xs text-red-500">*</span>
                  </Label>
                  <Select
                    value={form.gender}
                    onValueChange={(value) => setForm((f) => ({ ...f, gender: value }))}
                  >
                    <SelectTrigger id="gender" className="w-full">
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MALE">Male</SelectItem>
                      <SelectItem value="FEMALE">Female</SelectItem>
                      <SelectItem value="PREFER_NOT_TO_SAY">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Country (required) — ISO 3166-1 alpha-2 code. Used by Video Chat. */}
                <div className="space-y-2">
                  <Label htmlFor="country">
                    Country <span className="text-xs text-red-500">*</span>
                  </Label>
                  <Select
                    value={form.countryCode}
                    onValueChange={(value) => setForm((f) => ({ ...f, countryCode: value }))}
                  >
                    <SelectTrigger id="country" className="w-full">
                      <SelectValue placeholder="Select your country" />
                    </SelectTrigger>
                    <SelectContent className="max-h-80">
                      {COUNTRIES.map((c) => (
                        <SelectItem key={c.code} value={c.code}>
                          {c.flag} {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Date of Birth (optional) — native <input type="date">
                    gives a mobile-friendly date picker on iOS/Android.
                    `max={todayIso}` prevents future dates client-side; the
                    server ALSO validates (defense-in-depth). Format is
                    locale-aware on the device (DD/MM/YYYY vs MM/DD/YYYY
                    is handled by the OS date picker UI). */}
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">
                    Date of Birth <span className="text-xs text-muted-foreground">(optional)</span>
                  </Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={form.dateOfBirth}
                    onChange={set("dateOfBirth")}
                    max={todayIso}
                    // Help mobile keyboards show a numeric date-optimized layout.
                    inputMode="numeric"
                  />
                </div>
              </>
            )}

            {(mode === "login" || mode === "register" || mode === "forgot") && (
              <div className="space-y-2">
                <Label htmlFor="email">{t("auth.email")}</Label>
                <Input id="email" type="email" value={form.email} onChange={set("email")} autoComplete="email" required />
              </div>
            )}

            {(mode === "login" || mode === "register" || mode === "reset") && (
              <div className="space-y-2">
                <Label htmlFor="password">{t("auth.password")}</Label>
                <Input
                  id="password"
                  type="password"
                  value={form.password}
                  onChange={set("password")}
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                  required
                />
              </div>
            )}

            {(mode === "register" || mode === "reset") && (
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">{t("auth.confirmPassword")}</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={form.confirmPassword}
                  onChange={set("confirmPassword")}
                  autoComplete="new-password"
                  required
                />
              </div>
            )}

            {(mode === "verify" || mode === "reset") && (
              <div className="space-y-2">
                <Label htmlFor="token">{t("auth.token")}</Label>
                <Input id="token" value={form.token} onChange={set("token")} required />
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {mode === "login" && t("auth.signIn")}
              {mode === "register" && t("auth.createAccount")}
              {mode === "forgot" && t("auth.sendResetLink")}
              {mode === "reset" && t("auth.resetPassword")}
              {mode === "verify" && t("auth.verifyEmail")}
            </Button>
          </form>

          <div className="mt-4 flex flex-col gap-2 text-sm text-muted-foreground">
            {mode === "login" && (
              <>
                <button onClick={() => setMode("forgot")} className="text-left hover:text-foreground hover:underline">
                  {t("auth.forgotPassword")}
                </button>
                <button onClick={() => setMode("register")} className="text-left hover:text-foreground hover:underline">
                  {t("auth.noAccount")}
                </button>
              </>
            )}
            {mode === "register" && (
              <button onClick={() => setMode("login")} className="text-left hover:text-foreground hover:underline">
                {t("auth.haveAccount")}
              </button>
            )}
            {(mode === "forgot" || mode === "reset" || mode === "verify") && (
              <button onClick={() => setMode("login")} className="text-left hover:text-foreground hover:underline">
                {t("auth.backToSignIn")}
              </button>
            )}
          </div>
        </CardContent>
      </Card>

      <p className="mt-6 max-w-md text-center text-xs text-muted-foreground">
        {platformName} — {platformDescription}
      </p>
    </div>
  );
}
