"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Loader2, BadgeCheck, AlertCircle, Link as LinkIcon } from "lucide-react";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { Avatar } from "@/components/shared/avatar";
import { MainNav } from "@/components/shared/main-nav";
// IMPORTANT: import the USERNAME_SCHEMA from `@/lib/username-shared` (pure,
// no DB), NOT from `@/lib/username` (which imports `db` + PrismaClient at
// the top level). Importing from `@/lib/username` here would pull
// PrismaClient into the browser bundle, throwing the
// "PrismaClient is unable to run in this browser environment" error and
// triggering the global-error.tsx boundary.
//
// The `isUsernameAvailable` function is SERVER-ONLY (uses Prisma). Client
// components MUST NOT import it — instead they call the
// /api/v1/username-check endpoint via fetch (see `checkUsername` below).
import { USERNAME_SCHEMA } from "@/lib/username-shared";
import { COUNTRIES } from "@/lib/countries";
import { useMediaResolver } from "@/hooks/use-media-resolver";
import {
  classifyImageSourceKind,
  getDisallowedReason,
} from "@/lib/articles/image-source-classify";
import { TutorialVideoCard } from "@/components/shared/tutorial-video-card";

/**
 * EditProfileScreen — the ONLY place where the user edits profile information.
 *
 * Edits:
 *  - Profile picture (URL or auto-generated initials avatar)
 *  - Full name
 *  - Username
 *  - Bio
 *  - Gender (optional — Male / Female / Prefer not to say)
 *  - Date of Birth (optional — never shown publicly, only stored for the
 *    user's own reference + future anonymized analytics)
 *
 * This screen is intentionally separated from Settings per spec §10:
 *   EDIT PROFILE = profile information only
 *   SETTINGS     = language, appearance, notifications, privacy, security, etc.
 *
 * Privacy:
 *  - Gender + Date of Birth are NEVER exposed on the public profile API
 *    (getProfileByUsername / getProfileById). They are only returned by the
 *    user's OWN /api/v1/profile endpoint (used here for editing).
 *
 * Profile Picture URL:
 *  - The user can paste any direct image URL (http/https only).
 *  - The URL is validated on the client (instant feedback) AND on the server
 *    (security source-of-truth).
 *  - The image is stored in the existing `User.avatarUrl` column — no new
 *    database field. The auto-generated color avatar (`avatarColor`) is
 *    used as a fallback when no URL is set OR when the URL fails to load.
 *  - A live preview is shown in the same circular avatar styling used
 *    throughout the platform.
 *  - If the URL is invalid OR the image cannot be loaded, an inline
 *    "Unable to load this image." message is shown — the page does not break.
 */
export function EditProfileScreen() {
  const router = useRouter();
  const { user, fetchUser } = useAuthStore();
  const { t } = useTranslation();

  const [fullName, setFullName] = useState(user?.fullName ?? "");
  const [username, setUsername] = useState(user?.username ?? "");
  const [usernameError, setUsernameError] = useState<string | null>(null);
  const [usernameStatus, setUsernameStatus] = useState<"idle" | "available" | "taken" | "invalid">("idle");
  const [bio, setBio] = useState(user?.bio ?? "");
  // Gender: stored as "MALE" | "FEMALE" | "PREFER_NOT_TO_SAY" | null.
  // The empty string "" represents "not set" in the form (same as null on
  // the server — see normalizeGender in src/lib/profile.ts).
  const [gender, setGender] = useState<string>(user?.gender ?? "");
  // Country: ISO 3166-1 alpha-2 code or empty string for "not set".
  // Existing accounts may have null — they can set it here.
  const [countryCode, setCountryCode] = useState<string>(user?.countryCode ?? "");
  // DOB: stored as YYYY-MM-DD string (the format <input type="date"> uses)
  // or empty string for "not set".
  //
  // DEFENSIVE NORMALIZATION (Date-of-Birth optional bug fix):
  //   The server now returns DOB as YYYY-MM-DD via `formatDateOfBirthForInput`
  //   in `toSafeUser()` (see src/lib/auth/index.ts). However, a user who is
  //   ALREADY logged in may still have a STALE cached `user.dateOfBirth`
  //   from before this fix shipped — that stale value could be a full ISO
  //   datetime string like "2007-01-01T00:00:00.000Z" (the old broken
  //   format). If we feed that directly to `<input type="date">`, the
  //   browser marks the input `:invalid` and shows the native "please enter
  //   a valid value" popup (which some user-agents localize as
  //   "أكد تاريخ الازدياد" — the exact bug the user reported).
  //
  //   To be bulletproof, we normalize here: take only the first 10 chars
  //   (the YYYY-MM-DD prefix) when the value looks like an ISO datetime.
  //   This is idempotent — if the value is already YYYY-MM-DD (the new
  //   correct format), the slice is a no-op. If the value is null/empty,
  //   we use "" (the form's "not set" sentinel).
  function normalizeDobForInput(value: string | null | undefined): string {
    if (!value) return "";
    const trimmed = value.trim();
    if (!trimmed) return "";
    // YYYY-MM-DD is exactly 10 chars. Anything longer is a full ISO datetime
    // — slice to keep only the date portion.
    if (/^\d{4}-\d{2}-\d{2}/.test(trimmed)) {
      return trimmed.slice(0, 10);
    }
    // Unknown format — let the server-side validator reject it on Save.
    // Returning the raw value keeps the field visibly "wrong" so the user
    // can fix it manually, rather than silently clearing their data.
    return trimmed;
  }
  const [dateOfBirth, setDateOfBirth] = useState<string>(
    normalizeDobForInput(user?.dateOfBirth)
  );
  // Profile picture URL — optional. The user's existing URL (if any) is the
  // initial value. The avatar is generated from the name when the URL is empty.
  const [avatarUrl, setAvatarUrl] = useState<string>(user?.avatarUrl ?? "");
  // Live state of the URL preview image — driven by the UniversalMediaResolver.
  // The resolver probes the URL server-side (Content-Type sniffing + OG
  // metadata extraction) and returns the best representation.
  const { media: avatarMedia, loading: avatarResolving } =
    useMediaResolver(avatarUrl, 500);
  // Legacy state for the <Avatar> component's onLoad/onError handlers.
  // We still use this to track whether the resolved image URL successfully
  // loaded in the <img> element (the resolver can return an image URL,
  // but the <img> is the final arbiter of whether it actually renders).
  const [avatarLoadStatus, setAvatarLoadStatus] = useState<"loading" | "loaded" | "error">("loading");
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingUsername, setSavingUsername] = useState(false);
  const [checkingUsername, setCheckingUsername] = useState(false);

  if (!user) return null;

  async function checkUsername(value: string) {
    setUsername(value);
    setUsernameError(null);
    const trimmed = value.trim();
    if (!trimmed) {
      setUsernameStatus("idle");
      return;
    }
    // Skip check if unchanged from current username.
    if (trimmed.toLowerCase() === user!.username.toLowerCase()) {
      setUsernameStatus("idle");
      return;
    }
    const parsed = USERNAME_SCHEMA.safeParse(trimmed);
    if (!parsed.success) {
      setUsernameStatus("invalid");
      setUsernameError(parsed.error.issues[0]?.message ?? "Invalid username");
      return;
    }
    setCheckingUsername(true);
    try {
      // Call the server-side /api/v1/username-check endpoint instead of
      // importing `isUsernameAvailable` directly — that function uses
      // PrismaClient, which cannot run in the browser. The endpoint is
      // rate-limited (10/10min per IP) and returns
      // `{ available: boolean, suggestions: string[] }`.
      const res = await api.post<{ available: boolean; suggestions?: string[] }>(
        "/api/v1/username-check",
        { username: parsed.data }
      );
      setUsernameStatus(res.available ? "available" : "taken");
    } catch {
      setUsernameStatus("idle");
    } finally {
      setCheckingUsername(false);
    }
  }

  async function saveProfile() {
    // Phase 18 follow-up — block save when the avatar URL is invalid.
    // The frontend can't bypass the server's validator (defense-in-depth),
    // but we block here too so the user gets instant feedback + no wasted
    // network request. Empty URL is allowed (avatar is optional).
    //
    // We re-derive the trimmed URL + classification here because the
    // component-body consts below are not yet in scope at function-declaration
    // time (hoisting rules). Doing it locally keeps the function self-contained.
    const _trimmed = avatarUrl.trim();
    if (_trimmed) {
      const _kind = classifyImageSourceKind(_trimmed);
      if (_kind === "disallowed" || !_trimmed.match(/^https?:\/\//i)) {
        toast.error("Invalid profile image link. Use a Pinterest link or a direct image URL.");
        return;
      }
      // If the resolver hasn't confirmed an image yet, block. The server
      // will re-validate via validateImageSource (defense-in-depth).
      const _resolved = avatarMedia && avatarMedia.type === "image" && avatarMedia.mediaUrl;
      if (!_resolved) {
        toast.error("Invalid profile image link. Use a Pinterest link or a direct image URL.");
        return;
      }
    }
    setSavingProfile(true);
    try {
      await api.patch("/api/v1/profile", {
        fullName,
        bio,
        // Send gender only if changed from the current value. Empty string
        // is sent as null on the server (normalizeGender returns null for "").
        gender: gender || null,
        // Send country code (ISO 3166-1 alpha-2). Empty string → null.
        countryCode: countryCode || null,
        // Send DOB only if the user picked a date. The server validates
        // against future dates + age limits (defense-in-depth).
        dateOfBirth: dateOfBirth || null,
        // Send the avatar URL — the server validates + sanitizes.
        // Empty string → server stores null (no URL).
        avatarUrl: avatarUrl.trim() || null,
      });
      await fetchUser();
      toast.success(t("profile.profileUpdated"));
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to update profile");
    } finally {
      setSavingProfile(false);
    }
  }

  async function saveUsername() {
    setUsernameError(null);
    const parsed = USERNAME_SCHEMA.safeParse(username);
    if (!parsed.success) {
      const msg = parsed.error.issues[0]?.message ?? "Invalid username";
      setUsernameError(msg);
      toast.error(msg);
      return;
    }
    if (parsed.data.toLowerCase() === user!.username.toLowerCase()) {
      return; // unchanged
    }
    setSavingUsername(true);
    try {
      await api.patch("/api/v1/profile", { username: parsed.data });
      await fetchUser();
      toast.success(t("profile.usernameUpdated"));
      setUsernameStatus("idle");
    } catch (err) {
      const msg = err instanceof ApiClientError ? err.message : "Failed to update username";
      setUsernameError(msg);
      toast.error(msg);
    } finally {
      setSavingUsername(false);
    }
  }

  // Max date for the DOB picker: today. The server ALSO validates.
  const todayIso = new Date().toISOString().split("T")[0];

  // Has the profile form changed? Used to enable/disable the Save button.
  // Includes the avatarUrl — if the user typed a new URL (or cleared it),
  // the Save button becomes enabled.
  //
  // CRITICAL: compare `dateOfBirth` against the NORMALIZED version of
  // `user.dateOfBirth` (not the raw value). The raw value might be a full
  // ISO datetime string from a stale cached session (pre-fix). The state
  // is always YYYY-MM-DD (the date-picker format), so we normalize the
  // server-side value to match before comparing — otherwise the Save
  // button would always appear "dirty" even when the user didn't touch DOB.
  const profileChanged =
    fullName !== (user?.fullName ?? "") ||
    bio !== (user?.bio ?? "") ||
    gender !== (user?.gender ?? "") ||
    dateOfBirth !== normalizeDobForInput(user?.dateOfBirth) ||
    avatarUrl !== (user?.avatarUrl ?? "");

  // The resolved avatar media. When the URL is empty/invalid, this is null.
  // When the resolver returns a `type === "image"` media, we use its
  // `mediaUrl` as the <Avatar src=...> — this handles BOTH direct image
  // URLs AND Pinterest pin URLs where the resolver extracted the pin's image.
  //
  // Phase 18 follow-up — applies the SAME shared image-source rule as the
  // Article cover image: only Pinterest + direct image URLs are accepted.
  // Instagram / Facebook / TikTok / Google / random webpages are rejected
  // instantly via classifyImageSourceKind (no resolver probe needed).
  // The server independently re-validates via validateImageSource
  // (defense-in-depth — the frontend check can't be bypassed).
  const trimmedAvatarUrl = avatarUrl.trim();
  const avatarKind = classifyImageSourceKind(trimmedAvatarUrl);
  const avatarDisallowedReason = getDisallowedReason(trimmedAvatarUrl);
  const avatarUrlIsValid = /^https?:\/\//i.test(trimmedAvatarUrl);
  const avatarResolvedImageUrl =
    avatarMedia && avatarMedia.type === "image" && avatarMedia.mediaUrl
      ? avatarMedia.mediaUrl
      : null;
  // Whether to attempt rendering the resolved image in the <Avatar>.
  // Phase 18 follow-up: only accept when the URL is Pinterest or direct
  // (kind !== "disallowed"). The server independently enforces the same rule.
  const showAvatarPreview =
    !!avatarResolvedImageUrl &&
    avatarLoadStatus !== "error" &&
    (avatarKind === "pinterest" || avatarKind === "direct-image");
  // Preview status — drives the help text below the URL input.
  // Phase 18 follow-up: added "disallowed" + "rejected" states for the
  // new image-source rule.
  const avatarPreviewStatus:
    | "idle"
    | "invalid"
    | "disallowed"
    | "loading"
    | "loaded"
    | "non-image"
    | "rejected"
    | "error" =
    !trimmedAvatarUrl ? "idle"
    : !avatarUrlIsValid ? "invalid"
    : avatarKind === "disallowed" ? "disallowed"
    : avatarResolving ? "loading"
    : avatarResolvedImageUrl ? (avatarLoadStatus === "error" ? "error" : avatarLoadStatus)
    : "rejected";

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile-only slim header — desktop uses MainNav's top bar */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()} title={t("nav.backToApp")}>
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <h1 className="text-lg font-semibold">{t("profile.editProfile")}</h1>
      </header>

      <div className="mx-auto max-w-2xl space-y-6 p-4 md:p-6">
        {/* Profile picture — preview + URL input */}
        <Card>
          <CardHeader>
            <CardTitle>{t("profile.profilePicture")}</CardTitle>
            <CardDescription>
              {t("profile.profilePictureUrlDesc") || "Use a direct image URL or leave blank to use your initials avatar."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Live preview — uses the SAME circular avatar styling used
                throughout the platform (the shared Avatar component).
                When the URL is empty, the initials avatar is shown.
                The Avatar's onLoad/onError handlers drive the load status
                directly (no separate sentinel <img> needed — avoids
                double-fetching the same URL).
                The `key` prop forces React to remount the Avatar whenever
                the validated URL changes — so the <img>'s initial state
                is reset naturally (the new URL starts loading again). */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <Avatar
                  key={avatarResolvedImageUrl ?? "empty"}
                  name={fullName || user.username}
                  color={user.avatarColor}
                  src={showAvatarPreview ? avatarResolvedImageUrl : null}
                  size="2xl"
                  onLoad={() => setAvatarLoadStatus("loaded")}
                  onError={() => setAvatarLoadStatus("error")}
                />
                {/* Loading spinner overlay while the resolver is probing
                    OR the resolved image is loading in the <img>. */}
                {avatarPreviewStatus === "loading" && (
                  <div className="pointer-events-none absolute inset-0 flex items-center justify-center rounded-full bg-black/30">
                    <Loader2 className="h-5 w-5 animate-spin text-white" />
                  </div>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1 font-medium" dir="auto">
                  <span className="truncate">{user.fullName}</span>
                  {user.isVerified && <BadgeCheck className="h-4 w-4 text-blue-500" />}
                </p>
                <p className="text-sm text-muted-foreground truncate">@{user.username}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {t("profile.profilePicturePreviewHint") || "Live preview of your profile picture."}
                </p>
              </div>
            </div>

            {/* URL input field */}
            <div className="space-y-2">
              <Label htmlFor="avatarUrl" className="flex items-center gap-1.5">
                <LinkIcon className="h-3.5 w-3.5" />
                {t("profile.profilePictureUrl") || "Profile Picture URL"}
              </Label>
              <Input
                id="avatarUrl"
                type="url"
                inputMode="url"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                value={avatarUrl}
                onChange={(e) => {
                  setAvatarUrl(e.target.value);
                  // Reset the load status to "loading" so the spinner
                  // shows immediately while the new URL is being resolved.
                  setAvatarLoadStatus("loading");
                }}
                placeholder="Paste a Pinterest link or a direct image URL."
                maxLength={2048}
                aria-invalid={avatarPreviewStatus === "invalid" || avatarPreviewStatus === "error" || avatarPreviewStatus === "disallowed" || avatarPreviewStatus === "rejected"}
                aria-describedby="avatarUrl-help"
              />
              {/* Help / error message — adapt to the current state.
                  Phase 18 follow-up — applies the SAME shared image-source rule
                  as the Article cover image: only Pinterest + direct image URLs
                  are accepted. Instagram / Facebook / TikTok / Google / random
                  webpages are rejected with the spec error message. */}
              <div id="avatarUrl-help" aria-live="polite" className="space-y-1">
                {avatarPreviewStatus === "invalid" && (
                  <p className="flex items-center gap-1.5 text-xs text-destructive">
                    <AlertCircle className="h-3.5 w-3.5" />
                    Invalid profile image link. Use a Pinterest link or a direct image URL.
                  </p>
                )}
                {avatarPreviewStatus === "disallowed" && (
                  <p className="flex items-start gap-1.5 text-xs text-destructive">
                    <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    <span>
                      {avatarDisallowedReason ?? "Invalid profile image link. Use a Pinterest link or a direct image URL."}
                    </span>
                  </p>
                )}
                {avatarPreviewStatus === "rejected" && (
                  <p className="flex items-start gap-1.5 text-xs text-destructive">
                    <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    <span>
                      Invalid profile image link. Use a Pinterest link or a direct image URL.
                    </span>
                  </p>
                )}
                {avatarPreviewStatus === "error" && (
                  <p className="flex items-start gap-1.5 text-xs text-destructive">
                    <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    <span>
                      Invalid profile image link. Use a Pinterest link or a direct image URL.
                    </span>
                  </p>
                )}
                {avatarPreviewStatus === "loaded" && avatarMedia && (
                  <p className="text-xs text-green-600 dark:text-green-400">
                    ✓ {avatarMedia.provider === "direct"
                      ? "Image loaded."
                      : `Image extracted from ${avatarMedia.provider}.`}
                  </p>
                )}
                {avatarPreviewStatus === "loading" && (
                  <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Resolving media…
                  </p>
                )}
                {avatarPreviewStatus === "idle" && (
                  <p className="text-xs text-muted-foreground">
                    Use a direct image URL.
                  </p>
                )}
              </div>

              {/* Profile Image Tutorial — admin-controlled YouTube video.
                  Renders NOTHING when no video is configured OR when the
                  admin has disabled it. Uses ONLY the PROFILE_IMAGE_TUTORIAL
                  location — the Article tutorial is never shown here
                  (spec §2 + §9). */}
              <TutorialVideoCard location="PROFILE_IMAGE_TUTORIAL" />
            </div>
          </CardContent>
        </Card>

        {/* Full name + bio + gender + DOB */}
        <Card>
          <CardHeader>
            <CardTitle>{t("settings.profile")}</CardTitle>
            <CardDescription>{t("profile.editProfileDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">{t("auth.fullName")}</Label>
              <Input
                id="fullName"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                maxLength={50}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bio">{t("profile.bio")}</Label>
              <Textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder={t("profile.bioPlaceholder")}
                maxLength={200}
                rows={3}
              />
              <p className="text-xs text-muted-foreground">{bio.length}/200</p>
            </div>

            {/* Gender (optional) — Select dropdown, mobile-friendly. */}
            <div className="space-y-2">
              <Label htmlFor="gender">
                Gender <span className="text-xs text-muted-foreground">(optional, private)</span>
              </Label>
              <Select value={gender} onValueChange={(v) => setGender(v)}>
                <SelectTrigger id="gender" className="w-full">
                  <SelectValue placeholder="Select gender (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MALE">Male</SelectItem>
                  <SelectItem value="FEMALE">Female</SelectItem>
                  <SelectItem value="PREFER_NOT_TO_SAY">Prefer not to say</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Never shown on your public profile. Used for video chat matchmaking.
              </p>
            </div>

            {/* Country (private) — ISO 3166-1 alpha-2. Used by Video Chat. */}
            <div className="space-y-2">
              <Label htmlFor="country">
                Country <span className="text-xs text-muted-foreground">(private)</span>
              </Label>
              <Select value={countryCode} onValueChange={(v) => setCountryCode(v)}>
                <SelectTrigger id="country" className="w-full">
                  <SelectValue placeholder="Select your country" />
                </SelectTrigger>
                <SelectContent className="max-h-80">
                  {COUNTRIES.map((c) => (
                    <SelectItem key={c.code} value={c.code}>
                      {c.flag} {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Never shown on your public profile. Used for video chat matchmaking.
              </p>
            </div>

            {/* Date of Birth (optional) — native date picker, mobile-friendly.
                `max={todayIso}` prevents future dates client-side; the server
                ALSO validates (defense-in-depth). */}
            <div className="space-y-2">
              <Label htmlFor="dateOfBirth">
                Date of Birth <span className="text-xs text-muted-foreground">(optional, private)</span>
              </Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                max={todayIso}
                inputMode="numeric"
              />
              <p className="text-xs text-muted-foreground">
                Never shown on your public profile. Age is computed on demand — we don&apos;t store a static age.
              </p>
            </div>

            <Button onClick={saveProfile} disabled={savingProfile || !fullName.trim() || !profileChanged || avatarPreviewStatus === "invalid" || avatarPreviewStatus === "error" || avatarPreviewStatus === "disallowed" || avatarPreviewStatus === "rejected"}>
              {savingProfile && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {t("profile.saveProfile")}
            </Button>
          </CardContent>
        </Card>

        {/* Username (separate because of availability check) */}
        <Card>
          <CardHeader>
            <CardTitle>{t("profile.username")}</CardTitle>
            <CardDescription>{t("profile.editProfileDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">@</span>
              <Input
                value={username}
                onChange={(e) => void checkUsername(e.target.value)}
                className="flex-1"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
              />
              <Button
                size="sm"
                variant="outline"
                onClick={saveUsername}
                disabled={
                  savingUsername ||
                  usernameStatus === "invalid" ||
                  usernameStatus === "taken" ||
                  username.toLowerCase() === user.username.toLowerCase()
                }
              >
                {savingUsername ? <Loader2 className="h-4 w-4 animate-spin" /> : t("settings.saveChanges")}
              </Button>
            </div>
            {checkingUsername && (
              <p className="text-xs text-muted-foreground">
                <Loader2 className="mr-1 inline h-3 w-3 animate-spin" />
                {t("common.loading")}
              </p>
            )}
            {!checkingUsername && usernameStatus === "available" && (
              <p className="text-xs text-green-600 dark:text-green-400">
                ✓ {t("profile.usernameAvailable")}
              </p>
            )}
            {!checkingUsername && usernameStatus === "taken" && (
              <p className="text-xs text-destructive">
                ✗ {t("profile.usernameTaken")}
              </p>
            )}
            {!checkingUsername && usernameStatus === "invalid" && usernameError && (
              <p className="text-xs text-destructive">{usernameError}</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
