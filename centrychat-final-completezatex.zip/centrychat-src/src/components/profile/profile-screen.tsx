"use client";

import { useCallback, useEffect, useState, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AvatarWithLightbox } from "@/components/shared/avatar-with-lightbox";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { MainNav } from "@/components/shared/main-nav";
import { FollowButton } from "@/components/shared/follow-button";
import { PostCard, type PostDTO } from "@/components/posts/post-card";
import { ArticleCard, type ArticleCardDTO } from "@/components/articles/article-card";
import { PlaylistCard, type PlaylistCardDTO } from "@/components/playlists/playlist-card";
import { ArrowLeft, MessageSquare, UserPlus, UserCheck, Settings as SettingsIcon, Pencil, Calendar, Loader2, FileText, Plus, ListMusic, PenLine } from "lucide-react";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { useUserPosts } from "@/lib/client/use-user-posts";
import { useIsMobile } from "@/hooks/use-mobile";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

interface ProfileData {
  id: string;
  fullName: string;
  username: string;
  avatarColor: string | null;
  avatarUrl: string | null;
  isVerified: boolean;
  bio: string | null;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  isFollowing: boolean;
  isFollowedBy: boolean;
  createdAt: string;
}

export function ProfileScreen() {
  const router = useRouter();
  const params = useSearchParams();
  const username = params.get("username") ?? "";
  const { user: currentUser } = useAuthStore();
  const { t, language } = useTranslation();

  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [followLoading, setFollowLoading] = useState(false);
  const [messageLoading, setMessageLoading] = useState(false);

  const isOwnProfile = currentUser?.username === username;

  // Posts list (cursor pagination + infinite scroll).
  const {
    posts,
    loading: postsLoading,
    loadingMore,
    hasMore,
    loadMore,
    refresh: refreshPosts,
    removePost,
    prependPost,
    updatePost,
  } = useUserPosts(profile?.id, 10);

  // Published articles for this user — merged into the same "Posts" feed.
  const [articles, setArticles] = useState<ArticleCardDTO[]>([]);
  const [articlesLoading, setArticlesLoading] = useState(false);

  const sentinelRef = useRef<HTMLDivElement | null>(null);

  // IntersectionObserver — fetch the next page when the sentinel scrolls
  // into view. Disconnects when no more pages remain.
  useEffect(() => {
    if (!hasMore || loadingMore) return;
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          void loadMore();
        }
      },
      { rootMargin: "200px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [hasMore, loadingMore, loadMore]);

  // Fetch published articles for this user — merged into the same "Posts" feed.
  // Only published articles are shown (drafts are hidden from visitors).
  // For the profile owner, drafts are also fetched (so they can edit them).
  useEffect(() => {
    if (!profile?.username) return;
    setArticlesLoading(true);
    void api.get<{ articles: ArticleCardDTO[] }>(
      `/api/v1/users/${encodeURIComponent(profile.username)}/articles?limit=50`
    ).then((data) => {
      setArticles(data.articles);
    }).catch(() => {
      /* ignore */
    }).finally(() => setArticlesLoading(false));
  }, [profile?.username]);

  const loadProfile = useCallback(async () => {
    if (!username) {
      setError("No username provided.");
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const data = await api.get<{ profile: ProfileData }>(
        `/api/v1/users/${encodeURIComponent(username)}/profile`
      );
      setProfile(data.profile);
    } catch (err) {
      if (err instanceof ApiClientError) {
        if (err.status === 404) {
          setError("User not found.");
        } else {
          setError(err.message);
        }
      } else {
        setError("Failed to load profile.");
      }
    } finally {
      setLoading(false);
    }
  }, [username]);

  useEffect(() => {
    void loadProfile();
  }, [loadProfile]);

  async function toggleFollow() {
    if (!profile) return;
    setFollowLoading(true);
    const wasFollowing = profile.isFollowing;
    // Optimistic update.
    setProfile((p) => p ? {
      ...p,
      isFollowing: !wasFollowing,
      followersCount: p.followersCount + (wasFollowing ? -1 : 1),
    } : p);
    try {
      if (wasFollowing) {
        await api.delete(`/api/v1/users/${profile.username}/follow`);
      } else {
        await api.post(`/api/v1/users/${profile.username}/follow`);
      }
    } catch (err) {
      // Revert on error.
      setProfile((p) => p ? {
        ...p,
        isFollowing: wasFollowing,
        followersCount: p.followersCount + (wasFollowing ? 1 : -1),
      } : p);
      toast.error(err instanceof ApiClientError ? err.message : "Failed");
    } finally {
      setFollowLoading(false);
    }
  }

  async function startConversation() {
    if (!profile) return;
    setMessageLoading(true);
    try {
      // Create or get the conversation with this user.
      const data = await api.post<{ conversation: { id: string } }>(
        "/api/v1/conversations",
        { userId: profile.id }
      );
      router.push(`/?conversation=${data.conversation.id}`);
    } catch (err) {
      toast.error(err instanceof ApiClientError ? err.message : "Failed to start conversation");
    } finally {
      setMessageLoading(false);
    }
  }

  // Called when a post is deleted from the list.
  function handlePostDeleted(postId: string) {
    removePost(postId);
    // Also decrement the profile's postsCount.
    setProfile((p) => (p ? { ...p, postsCount: Math.max(0, p.postsCount - 1) } : p));
  }

  // Called when a post is updated from this view (PostCard edit mode).
  function handlePostUpdated(updated: PostDTO) {
    updatePost(updated);
  }

  // Listen for cross-view events:
  //   - post:created → prepend + bump count (if it belongs to this profile)
  //   - post:deleted → remove + decrement count (if it belongs to this profile)
  //   - post:updated → replace the post in the list (if it's there)
  //
  // BUG FIX (spec §11): The article editor dispatches `post:created` with
  // an ArticleCardDTO (has `title`, `coverImage`, `videoUrl`, `publishedAt`
  // but NO `content`, `createdAt`, `updatedAt`). The previous code blindly
  // prepended this to the PostDTO[] array. When PostCard tried to render
  // it, `post.content` was `undefined` → `post.content.length` threw
  // TypeError → "Something went wrong" error on the Profile page.
  //
  // FIX: Detect whether the dispatched item is a Post (has `content`)
  // or an Article (has `title` + `excerpt`). If it's an Article,
  // prepend it to the articles array instead of the posts array.
  useEffect(() => {
    function onPostCreated(e: Event) {
      const detail = (e as CustomEvent<any>).detail;
      if (!detail || !profile) return;
      if (detail.author?.id !== profile.id) return;

      // Detect: is this a Post (has `content`) or an Article (has `title` + `excerpt`)?
      const isArticle = typeof detail.title === "string" && typeof detail.excerpt !== "undefined";
      if (isArticle) {
        // It's an Article — prepend to the articles array.
        setArticles((prev) => {
          if (prev.some((a) => a.id === detail.id)) return prev;
          return [detail as ArticleCardDTO, ...prev];
        });
      } else {
        // It's a Post — prepend to the posts array.
        prependPost(detail as PostDTO);
      }
      // Bump the unified postsCount (includes posts + published articles).
      setProfile((p) => (p ? { ...p, postsCount: p.postsCount + 1 } : p));
    }
    function onPostDeleted(e: Event) {
      const detail = (e as CustomEvent<{ id: string; authorId?: string }>).detail;
      if (!detail?.id || !profile) return;
      // Only decrement if the deleted post belongs to this profile.
      if (detail.authorId && detail.authorId !== profile.id) return;
      // Try to remove from posts (useUserPosts handles this).
      removePost(detail.id);
      // Also try to remove from articles (in case it was an article).
      setArticles((prev) => prev.filter((a) => a.id !== detail.id));
      // Decrement the unified count.
      setProfile((p) =>
        p ? { ...p, postsCount: Math.max(0, p.postsCount - 1) } : p
      );
    }
    function onPostUpdated(e: Event) {
      const detail = (e as CustomEvent<any>).detail;
      if (!detail || !profile) return;
      if (detail.author?.id !== profile.id) return;

      // Detect: is this a Post or an Article?
      const isArticle = typeof detail.title === "string" && typeof detail.excerpt !== "undefined";
      if (isArticle) {
        // Update in the articles array.
        setArticles((prev) => prev.map((a) => a.id === detail.id ? detail as ArticleCardDTO : a));
      } else {
        // Update in the posts array.
        updatePost(detail as PostDTO);
      }
    }
    window.addEventListener("post:created", onPostCreated as EventListener);
    window.addEventListener("post:deleted", onPostDeleted as EventListener);
    window.addEventListener("post:updated", onPostUpdated as EventListener);
    return () => {
      window.removeEventListener("post:created", onPostCreated as EventListener);
      window.removeEventListener("post:deleted", onPostDeleted as EventListener);
      window.removeEventListener("post:updated", onPostUpdated as EventListener);
    };
  }, [profile, prependPost, updatePost, removePost]);

  // Loading skeleton.
  if (loading) {
    return (
      <div className="min-h-screen bg-background pb-14 md:pb-0">
        <MainNav />
        <div className="mx-auto max-w-2xl p-4 md:p-6 space-y-4">
          <div className="flex flex-col items-center gap-4">
            <Skeleton className="h-24 w-24 rounded-full" />
            <div className="space-y-2 text-center">
              <Skeleton className="h-6 w-40 mx-auto" />
              <Skeleton className="h-4 w-24 mx-auto" />
            </div>
            <Skeleton className="h-10 w-32" />
            <div className="flex w-full max-w-xs justify-around gap-2">
              <Skeleton className="h-8 w-16" />
              <Skeleton className="h-8 w-16" />
              <Skeleton className="h-8 w-16" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Error state.
  if (error || !profile) {
    return (
      <div className="min-h-screen bg-background pb-14 md:pb-0">
        <MainNav />
        <div className="flex min-h-[calc(100vh-3.5rem)] flex-col items-center justify-center gap-3 p-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
            <UserPlus className="h-8 w-8 text-muted-foreground" />
          </div>
          <p className="text-lg font-medium">{error ?? "User not found."}</p>
          <Button variant="outline" onClick={() => router.push("/")}>
            {t("nav.backToApp")}
          </Button>
        </div>
      </div>
    );
  }

  // ── Fix "Joined Invalid Date" (spec Task 1) ────────────────────
  // ROOT CAUSE: the old code used `toLocaleDateString(undefined, ...)` which
  // passed `undefined` as the locale — falling back to the browser's default
  // locale (NOT the user's selected language). In SSR/edge environments,
  // `undefined` locale can produce "Invalid Date". Also, if `createdAt`
  // was null/missing/invalid, `new Date(null)` → "1/1/1970" or "Invalid Date".
  //
  // FIX:
  //   1. Use the user's selected language to determine the locale (en → en-US,
  //      ar → ar, fr → fr-FR) — matching the i18n SUPPORTED_LANGUAGES config.
  //   2. Add try/catch + isNaN safety — if the date is invalid, return ""
  //      and the "Joined" section is not rendered at all.
  //   3. Format: month long + year numeric (e.g. "August 2026", "أغشت 2026",
  //      "août 2026") — locale-aware via Intl.DateTimeFormat.
  const joinDate = (() => {
    try {
      if (!profile.createdAt) return "";
      const date = new Date(profile.createdAt);
      if (isNaN(date.getTime())) return "";
      const locale = language === "ar" ? "ar" : language === "fr" ? "fr-FR" : "en-US";
      return new Intl.DateTimeFormat(locale, {
        year: "numeric",
        month: "long",
      }).format(date);
    } catch {
      return "";
    }
  })();

  // Pluralize "Post" / "Posts" — uses i18n keys if present, falls back to English.
  const postsLabel = profile.postsCount === 1
    ? (t("posts.postOne") || "Post")
    : (t("posts.postsMany") || "Posts");

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile-only slim header with back button + name context */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.push("/")} title={t("nav.backToApp")}>
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <div className="min-w-0">
          <p className="truncate font-medium" dir="auto">{profile.fullName}</p>
          <p className="truncate text-xs text-muted-foreground">@{profile.username}</p>
        </div>
      </header>

      <div className="mx-auto max-w-2xl">
        {/* Profile Header */}
        <div className="flex flex-col items-center gap-4 p-4 md:p-6">
          <AvatarWithLightbox
            name={profile.fullName}
            color={profile.avatarColor}
            src={profile.avatarUrl}
            size="2xl"
            enableLightbox={!!profile.avatarUrl}
          />

          <div className="text-center">
            <h1 className="flex items-center justify-center gap-1.5 text-xl font-bold" dir="auto">
              {profile.fullName}
              {profile.isVerified && <VerifiedBadge size={18} />}
            </h1>
            <p className="text-sm text-muted-foreground">@{profile.username}</p>
          </div>

          {profile.bio && (
            <p className="max-w-md text-center text-sm text-foreground" dir="auto">
              {profile.bio}
            </p>
          )}

          {/* Only render "Joined" when the date is valid — prevents
              "Joined Invalid Date" if createdAt is missing/corrupt. */}
          {joinDate && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Calendar className="h-3.5 w-3.5" />
              <span>Joined {joinDate}</span>
            </div>
          )}

          <div className="flex flex-wrap justify-center gap-2">
            {isOwnProfile ? (
              <>
                <Button onClick={() => router.push("/?view=edit-profile")} variant="outline">
                  <Pencil className="mr-1.5 h-4 w-4 rtl-flip" />
                  {t("profile.editProfile")}
                </Button>
                <Button onClick={() => router.push("/?view=settings")} variant="ghost">
                  <SettingsIcon className="mr-1.5 h-4 w-4" />
                  {t("nav.settings")}
                </Button>
              </>
            ) : (
              <>
                <FollowButton
                  targetUserId={profile.id}
                  targetUsername={profile.username}
                  isFollowing={profile.isFollowing}
                  isFollowedBy={profile.isFollowedBy}
                  size="md"
                  onStateChange={(state) => {
                    setProfile((p) => p ? {
                      ...p,
                      isFollowing: state.isFollowing,
                      followersCount: p.followersCount + (state.isFollowing ? 1 : -1),
                    } : p);
                  }}
                />
                <Button onClick={startConversation} disabled={messageLoading} variant="outline">
                  {messageLoading ? (
                    <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                  ) : (
                    <MessageSquare className="mr-1.5 h-4 w-4" />
                  )}
                  Message
                </Button>
              </>
            )}
          </div>

          {/* Posts / Followers / Following stats
              - Order: Posts, Followers, Following (per spec)
              - Balanced layout: each stat takes equal width (flex-1) so the
                numbers + labels are evenly spaced regardless of count size.
              - Numbers on top (font-bold), labels below (text-xs muted).
              - Clickable stats (Followers/Following) open the list modal;
                Posts stat is display-only.
              - max-w-xs caps the row width on desktop so the stats don't
                spread too far apart; on mobile it fills the available width.
              - tabular-nums on the numbers prevents layout shift when the
                count changes (e.g. after follow/unfollow). */}
          <div className="flex w-full max-w-xs items-stretch justify-around gap-2">
            {/* Posts stat — not clickable (no dedicated posts list modal). */}
            <div className="flex flex-1 flex-col items-center px-2 py-1 text-center">
              <p className="font-bold tabular-nums">{profile.postsCount.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">{postsLabel}</p>
            </div>
            {/* Followers stat — clickable → navigates to full Followers page. */}
            <button
              onClick={() => router.push(`/?view=followers&username=${encodeURIComponent(profile.username)}`)}
              className="flex flex-1 flex-col items-center rounded-md px-2 py-1 text-center transition-colors hover:bg-accent"
            >
              <p className="font-bold tabular-nums">{profile.followersCount.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">
                {profile.followersCount === 1
                  ? (t("profile.followersOne") || "Follower")
                  : (t("profile.followersMany") || "Followers")}
              </p>
            </button>
            {/* Following stat — clickable → navigates to full Following page. */}
            <button
              onClick={() => router.push(`/?view=following&username=${encodeURIComponent(profile.username)}`)}
              className="flex flex-1 flex-col items-center rounded-md px-2 py-1 text-center transition-colors hover:bg-accent"
            >
              <p className="font-bold tabular-nums">{profile.followingCount.toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">
                {profile.followingCount === 1
                  ? (t("profile.followingOne") || "Following")
                  : (t("profile.followingMany") || "Following")}
              </p>
            </button>
          </div>
        </div>

        {/* ── Tabs: Posts | Playlists ─────────────────────────────────────
            Replaces the previous stacked layout (Posts above, Playlists below).
            Now the user switches between the two sections with a clean tab
            bar — matches the established social-media pattern (Instagram-
            style tabs) while keeping the existing Posts + Playlists systems
            untouched. Default tab = "posts" (matches the prior visible-by-
            default behavior). The (+) button on the right is context-aware:
              - Posts tab active → opens Article editor (same as before).
              - Playlists tab active → opens Create Playlist page (new UX). */}
        <ProfileTabs
          profile={profile}
          isOwnProfile={isOwnProfile}
          currentUser={currentUser}
          // Posts tab state + handlers (passed down so switching tabs
          // preserves scroll position + post list state).
          posts={posts}
          articles={articles}
          postsLoading={postsLoading}
          articlesLoading={articlesLoading}
          hasMore={hasMore}
          loadingMore={loadingMore}
          loadMore={loadMore}
          sentinelRef={sentinelRef}
          onPostDeleted={handlePostDeleted}
          onPostUpdated={handlePostUpdated}
          onArticleDeleted={(articleId) => {
            setArticles((prev) => prev.filter((x) => x.id !== articleId));
            setProfile((p) =>
              p ? { ...p, postsCount: Math.max(0, p.postsCount - 1) } : p
            );
          }}
          postsLabel={postsLabel}
        />
      </div>
    </div>
  );
}

// ── ProfileTabs ─────────────────────────────────────────────────────────
// Replaces the previous stacked Posts/Playlists layout with a clean
// Instagram-style tab switcher. The user toggles between Posts and
// Playlists; the inactive tab's content is unmounted (so there's no
// wasted render), but the underlying state (Posts list, fetched
// Playlists) is preserved in the parent ProfileScreen so switching tabs
// back + forth doesn't trigger refetches.
//
// The (+) button on the right of the tab bar is context-aware:
//   - Posts tab active → opens Article editor (same behavior as the
//     old dedicated + button on the Posts section).
//   - Playlists tab active → opens Create Playlist page (same behavior
//     as the old dedicated + button on the Playlists section).
//
// Visibility (server-side enforced):
//   - Posts tab: shows the profile owner's Posts + Articles (the same
//     data the previous Posts section showed — short Posts first, then
//     Article cards).
//   - Playlists tab: shows the owner's PUBLIC playlists to visitors,
//     and ALL playlists (public + private) to the owner.

interface UserPlaylistDTO {
  id: string;
  ownerId: string;
  name: string;
  slug: string;
  description: string | null;
  coverImage: string | null;
  isPublic: boolean;
  createdAt: string;
  updatedAt: string;
  owner: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  itemCount: number;
}

type ProfileTab = "posts" | "playlists";

function ProfileTabs({
  profile,
  isOwnProfile,
  currentUser,
  posts,
  articles,
  postsLoading,
  articlesLoading,
  hasMore,
  loadingMore,
  loadMore,
  sentinelRef,
  onPostDeleted,
  onPostUpdated,
  onArticleDeleted,
  postsLabel,
}: {
  profile: ProfileData;
  isOwnProfile: boolean;
  currentUser?: { id: string; username: string } | null;
  posts: PostDTO[];
  articles: ArticleCardDTO[];
  postsLoading: boolean;
  articlesLoading: boolean;
  hasMore: boolean;
  loadingMore: boolean;
  loadMore: () => void;
  sentinelRef: React.RefObject<HTMLDivElement | null>;
  onPostDeleted: (postId: string) => void;
  onPostUpdated: (updated: PostDTO) => void;
  onArticleDeleted: (articleId: string) => void;
  postsLabel: string;
}) {
  const router = useRouter();
  const { t } = useTranslation();
  // Default tab = "posts" (matches the previous "Posts visible first" layout).
  // The URL query param `?tab=playlists` survives refresh + is shareable.
  const searchParams = useSearchParams();
  const initialTab =
    (searchParams.get("tab") as ProfileTab | null) ?? "posts";
  const [activeTab, setActiveTab] = useState<ProfileTab>(initialTab);

  // ── Playlists state machine (fixes skeleton flickering) ───────────
  // State machine: "idle" → "loading" → "loaded" (with or without data)
  //
  // ROOT CAUSE of the flicker:
  //   The previous code had `playlistsLoading` AND `playlists.length` in
  //   the useEffect dependency array. When `setPlaylistsLoading(true)` was
  //   called inside the effect, it triggered a re-render, which re-ran
  //   the effect (because `playlistsLoading` changed). The guard
  //   `if (!playlistsLoading && playlists.length > 0) return` didn't help
  //   because `playlistsLoading` was `true` at that point. This caused
  //   a fetch loop: mount → setLoading(true) → re-render → effect runs
  //   again → setLoading(true) → ... until the API response arrived.
  //
  //   During the loop, the skeleton showed + disappeared + showed again
  //   ("flickering").
  //
  // FIX:
  //   1. Use a `useRef` to track whether we've already fetched (so the
  //      effect doesn't re-run when `playlistsLoading` changes).
  //   2. Remove `playlistsLoading` + `playlists.length` from the deps
  //      array — the effect should only depend on `activeTab` and
  //      `profile.username` (the actual triggers for a refetch).
  //   3. Use a single `playlistsState` variable with 3 values:
  //      "idle" | "loading" | "loaded" — no separate boolean.
  type PlaylistsState = "idle" | "loading" | "loaded";
  const [playlistsState, setPlaylistsState] = useState<PlaylistsState>("idle");
  const [playlists, setPlaylists] = useState<UserPlaylistDTO[]>([]);
  // Track whether we've already fetched for this username — prevents
  // double-fetch when React StrictMode runs effects twice in dev, and
  // prevents re-fetching when switching tabs back + forth.
  const playlistsFetchedRef = useRef<string | null>(null); // stores the username we fetched for

  // Sync the active tab to the URL query param (no router navigation —
  // keeps scroll position + state intact).
  useEffect(() => {
    if (typeof window !== "undefined") {
      const newUrl = new URL(window.location.href);
      if (activeTab === "posts") {
        newUrl.searchParams.delete("tab");
      } else {
        newUrl.searchParams.set("tab", activeTab);
      }
      window.history.replaceState(null, "", newUrl.toString());
    }
  }, [activeTab]);

  // Fetch playlists when the Playlists tab becomes active (lazy load —
  // we don't fetch playlists if the user never opens that tab, saving
  // a request on the Posts-only view). The fetch result is cached in
  // state + a ref, so switching back + forth between tabs doesn't refetch.
  //
  // Dependencies: ONLY `activeTab` + `profile.username` — NOT
  // `playlistsState` or `playlists.length` (those were the cause of the
  // flicker loop). The ref `playlistsFetchedRef` prevents double-fetch.
  useEffect(() => {
    if (activeTab !== "playlists") return;
    // If we already fetched for this username, don't refetch.
    if (playlistsFetchedRef.current === profile.username) return;
    playlistsFetchedRef.current = profile.username;

    let cancelled = false;
    setPlaylistsState("loading");
    api
      .get<{ playlists: UserPlaylistDTO[] }>(
        `/api/v1/users/${encodeURIComponent(profile.username)}/playlists?limit=100`
      )
      .then((data) => {
        if (!cancelled) {
          setPlaylists(data.playlists);
          setPlaylistsState("loaded");
        }
      })
      .catch(() => {
        if (!cancelled) {
          setPlaylists([]);
          setPlaylistsState("loaded");
        }
      });
    return () => {
      cancelled = true;
    };
  }, [activeTab, profile.username]);

  return (
    <div className="border-t">
      {/* Tab bar — sticky under the mobile slim header on small screens. */}
      <div className="sticky top-14 z-10 flex items-center justify-between gap-2 border-b bg-background/80 px-4 backdrop-blur md:top-0 md:px-6">
        <div className="flex flex-1">
          {/* Posts tab */}
          <button
            type="button"
            onClick={() => setActiveTab("posts")}
            className={cn(
              "flex flex-1 items-center justify-center gap-1.5 border-b-2 px-3 py-3 text-sm font-medium capitalize transition-colors sm:flex-none sm:px-6",
              activeTab === "posts"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            )}
            aria-pressed={activeTab === "posts"}
          >
            <FileText className="h-4 w-4" />
            <span>Posts</span>
          </button>
          {/* Playlists tab */}
          <button
            type="button"
            onClick={() => setActiveTab("playlists")}
            className={cn(
              "flex flex-1 items-center justify-center gap-1.5 border-b-2 px-3 py-3 text-sm font-medium capitalize transition-colors sm:flex-none sm:px-6",
              activeTab === "playlists"
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground"
            )}
            aria-pressed={activeTab === "playlists"}
          >
            <ListMusic className="h-4 w-4" />
            <span>Playlists</span>
          </button>
        </div>
        {/* (+) button — owner only. Opens a MENU (not direct navigation).
            On desktop: dropdown menu. On mobile: bottom sheet.
            The menu contains BOTH options:
              - Create Post (opens Article editor)
              - Create Playlist (opens Create Playlist page)
            This replaces the previous context-aware direct-navigation
            behavior — now the user always chooses, regardless of which
            tab is active (cleaner UX, no surprise navigation). */}
        {isOwnProfile && (
          <CreateMenuButton
            onPost={() => router.push("/?view=article-editor")}
            onPlaylist={() => router.push("/?view=create-playlist")}
          />
        )}
      </div>

      {/* ── Posts tab content ── */}
      {activeTab === "posts" && (
        <>
          {/* Loading skeleton for the initial fetch. */}
          {postsLoading && (
            <div className="divide-y">
              {[0, 1, 2].map((i) => (
                <div key={i} className="flex gap-3 p-4 md:px-6">
                  <Skeleton className="h-10 w-10 shrink-0 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-full" />
                    <Skeleton className="h-3 w-3/4" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Unified feed: Short Posts first, then Article cards. */}
          {!postsLoading && (posts.length > 0 || articles.length > 0) && (
            <div className="divide-y">
              {posts.map((p) => (
                <PostCard
                  key={p.id}
                  post={p}
                  canDelete={isOwnProfile}
                  onDeleted={onPostDeleted}
                  onUpdated={onPostUpdated}
                  hideFollow
                />
              ))}
              {/* Article cards — published + drafts (for owner). */}
              {articles.map((a) => (
                <ArticleCard
                  key={a.id}
                  article={a}
                  canManage={isOwnProfile}
                  onDeleted={onArticleDeleted}
                />
              ))}
            </div>
          )}

          {/* Empty state — only show when BOTH posts and articles are empty. */}
          {!postsLoading && !articlesLoading && posts.length === 0 && articles.length === 0 && isOwnProfile && (
            <div className="flex flex-col items-center justify-center gap-2 px-4 py-16 text-center md:px-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <FileText className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium">
                {t("posts.emptyTitle") || "No posts yet."}
              </p>
              <p className="max-w-sm text-xs text-muted-foreground">
                {t("posts.emptyDesc") || "Use the + button to create a post or article."}
              </p>
            </div>
          )}

          {/* Visitor empty state */}
          {!postsLoading && !articlesLoading && posts.length === 0 && articles.length === 0 && !isOwnProfile && (
            <div className="flex flex-col items-center justify-center gap-2 px-4 py-16 text-center md:px-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <FileText className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium">
                {t("posts.emptyVisitorTitle") || "No posts yet."}
              </p>
            </div>
          )}

          {/* Infinite-scroll sentinel + "Load more" fallback. */}
          {hasMore && (
            <div ref={sentinelRef} className="flex items-center justify-center py-6">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => loadMore()}
                disabled={loadingMore}
              >
                {loadingMore ? (
                  <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                ) : null}
                {loadingMore
                  ? (t("posts.loadingMore") || "Loading more…")
                  : (t("posts.loadMore") || "Load more")}
              </Button>
            </div>
          )}
        </>
      )}

      {/* ── Playlists tab content ── */}
      {activeTab === "playlists" && (
        <>
          {/* Loading skeleton */}
          {/* Skeleton — ONLY during the "loading" state.
              Once state is "loaded" (whether data is empty or not),
              the skeleton NEVER shows again (fixes flickering). */}
          {playlistsState === "loading" && (
            <div className="divide-y">
              {[0, 1].map((i) => (
                <div key={i} className="flex gap-3 p-4 md:px-6">
                  <Skeleton className="h-12 w-12 shrink-0 rounded-lg" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Playlists grid — shown when state is "loaded" AND there's data. */}
          {playlistsState === "loaded" && playlists.length > 0 && (
            <div className="grid grid-cols-1 gap-2 p-4 md:grid-cols-2 md:px-6">
              {playlists.map((p) => (
                <PlaylistCard
                  key={p.id}
                  playlist={p as PlaylistCardDTO}
                  showOwner={false}
                />
              ))}
            </div>
          )}

          {/* Empty state — owner only. State machine ensures this only
              shows AFTER loading completes (state === "loaded"). */}
          {playlistsState === "loaded" && playlists.length === 0 && isOwnProfile && (
            <div className="flex flex-col items-center justify-center gap-2 px-4 py-10 text-center md:px-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <ListMusic className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium">No playlists yet</p>
              <p className="max-w-sm text-xs text-muted-foreground">
                Create a playlist to bundle your articles into an ordered
                series (e.g. &quot;Avatar Full Story&quot; with Parts 1–5).
              </p>
              <Button
                variant="outline"
                size="sm"
                className="mt-2"
                onClick={() => router.push("/?view=create-playlist")}
              >
                <Plus className="mr-1 h-4 w-4" />
                Create a playlist
              </Button>
            </div>
          )}

          {/* Visitor empty state — when the profile owner has no public
              playlists OR only private ones. State machine ensures this
              only shows AFTER loading completes (state === "loaded"). */}
          {playlistsState === "loaded" && playlists.length === 0 && !isOwnProfile && (
            <div className="flex flex-col items-center justify-center gap-2 px-4 py-10 text-center md:px-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <ListMusic className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium">No public playlists</p>
              <p className="max-w-sm text-xs text-muted-foreground">
                When {profile.fullName} creates a public playlist, it will appear here.
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ── CreateMenuButton ─────────────────────────────────────────────────────
// The (+) button that opens a menu with two options:
//   - Create Post   → opens Article editor (the existing ?view=article-editor)
//   - Create Playlist → opens Create Playlist page (the existing ?view=create-playlist)
//
// Behavior:
//   - On MOBILE (screen width < 768px): opens a bottom Sheet (slides up
//     from the bottom — standard mobile pattern). Closes on backdrop tap,
//     X button, and Escape key. Locks body scroll while open.
//   - On DESKTOP: opens a DropdownMenu (popover anchored to the button).
//     Closes on outside click, Escape key, and item selection.
//
// Accessibility:
//   - The trigger is a real <button> with aria-label="Create".
//   - The menu items are real <button>s with keyboard navigation (up/down
//     arrows to move focus, Enter to select, Escape to close).
//   - The Sheet has role="dialog" + aria-modal=true (built into Radix).
//
// No duplicate logic: the onPost/onPlaylist callbacks are passed by the
// parent ProfileTabs, which uses the same router.push() calls as before.

function CreateMenuButton({
  onPost,
  onPlaylist,
}: {
  onPost: () => void;
  onPlaylist: () => void;
}) {
  const isMobile = useIsMobile();
  const [sheetOpen, setSheetOpen] = useState(false);

  if (isMobile) {
    // Mobile → bottom Sheet.
    return (
      <>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSheetOpen(true)}
          className="gap-1"
          aria-label="Create"
          title="Create"
        >
          <Plus className="h-4 w-4" />
        </Button>
        <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
          <SheetContent side="bottom" className="rounded-t-2xl">
            <SheetHeader className="pb-3">
              <SheetTitle className="text-center">Create</SheetTitle>
            </SheetHeader>
            <div className="flex flex-col gap-1 pb-6">
              <button
                type="button"
                onClick={() => {
                  setSheetOpen(false);
                  onPost();
                }}
                className="flex items-center gap-3 rounded-lg p-3 text-left text-sm font-medium transition-colors hover:bg-accent"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <PenLine className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">Create Post</p>
                  <p className="text-xs text-muted-foreground">Write an article or post</p>
                </div>
              </button>
              <button
                type="button"
                onClick={() => {
                  setSheetOpen(false);
                  onPlaylist();
                }}
                className="flex items-center gap-3 rounded-lg p-3 text-left text-sm font-medium transition-colors hover:bg-accent"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-violet-500/10 text-violet-500">
                  <ListMusic className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">Create Playlist</p>
                  <p className="text-xs text-muted-foreground">Bundle articles into a series</p>
                </div>
              </button>
            </div>
          </SheetContent>
        </Sheet>
      </>
    );
  }

  // Desktop → DropdownMenu.
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="gap-1"
          aria-label="Create"
          title="Create"
        >
          <Plus className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuItem
          onClick={onPost}
          className="cursor-pointer gap-3 p-3"
        >
          <PenLine className="h-5 w-5 text-primary" />
          <div>
            <p className="font-medium">Create Post</p>
            <p className="text-xs text-muted-foreground">Write an article or post</p>
          </div>
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={onPlaylist}
          className="cursor-pointer gap-3 p-3"
        >
          <ListMusic className="h-5 w-5 text-violet-500" />
          <div>
            <p className="font-medium">Create Playlist</p>
            <p className="text-xs text-muted-foreground">Bundle articles into a series</p>
          </div>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
