"use client";

import { useCallback, useEffect, useState, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { FollowButton } from "@/components/shared/follow-button";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Loader2, Users } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";

interface UserListItem {
  id: string;
  fullName: string;
  username: string;
  avatarColor: string | null;
  avatarUrl: string | null;
  isVerified: boolean;
  bio?: string | null;
  isFollowing?: boolean;
  isFollowedBy?: boolean;
}

interface FollowersPageProps {
  /** Username whose followers to display. If omitted, reads from ?username=. */
  username?: string;
}

/**
 * FollowersPage — full-page Followers list.
 *
 * Replaces the small modal that previously opened inside Profile.
 * The page shows:
 *   - Header with Back button + "Followers" title + count
 *   - Paginated list of users (avatar + name + @username + FollowButton)
 *   - Load More button at the bottom
 *   - Empty state when the user has no followers
 *   - Loading skeleton during fetch
 *
 * Uses the existing GET /api/v1/users/:username/followers API (page-based
 * pagination, max 50 per page). The FollowButton reuse means follow/unfollow
 * works inline without leaving the page.
 *
 * Routing: /?view=followers&username=<username>
 */
export function FollowersPage({ username: usernameProp }: FollowersPageProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const username = usernameProp ?? searchParams.get("username") ?? "";
  const { user: currentUser } = useAuthStore();
  const { t } = useTranslation();

  const [users, setUsers] = useState<UserListItem[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const initializedRef = useRef(false);

  const PAGE_SIZE = 20;

  const fetchPage = useCallback(async (pageNum: number) => {
    try {
      const data = await api.get<{ users: UserListItem[]; total: number; page: number; pageSize: number }>(
        `/api/v1/users/${encodeURIComponent(username)}/followers?page=${pageNum}&pageSize=${PAGE_SIZE}`
      );
      setTotal(data.total);
      if (pageNum === 1) {
        setUsers(data.users);
      } else {
        setUsers((prev) => [...prev, ...data.users]);
      }
      // hasMore = we got a full page AND total > loaded count
      setHasMore(data.users.length === PAGE_SIZE && users.length + data.users.length < data.total);
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to load followers";
      toast.error(msg);
    }
  }, [username, users.length]);

  useEffect(() => {
    if (!username || initializedRef.current) return;
    initializedRef.current = true;
    setLoading(true);
    void fetchPage(1).finally(() => setLoading(false));
  }, [username, fetchPage]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    const nextPage = page + 1;
    setPage(nextPage);
    await fetchPage(nextPage);
    setLoadingMore(false);
  }, [loadingMore, hasMore, page, fetchPage]);

  function openProfile(uname: string) {
    router.push(`/?view=profile&username=${encodeURIComponent(uname)}`);
  }

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile sticky header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()} title="Back">
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium">
            {t("profile.followersMany") || "Followers"}
          </p>
          <p className="truncate text-xs text-muted-foreground">
            @{username} · {total.toLocaleString()}
          </p>
        </div>
      </header>

      <div className="mx-auto max-w-2xl">
        {/* Desktop header */}
        <div className="hidden items-center gap-3 border-b px-4 py-3 md:flex md:px-6">
          <Button variant="ghost" size="icon" onClick={() => router.back()} title="Back">
            <ArrowLeft className="h-5 w-5 rtl-flip" />
          </Button>
          <Users className="h-5 w-5 text-muted-foreground" />
          <h1 className="text-lg font-semibold">
            {t("profile.followersMany") || "Followers"}
          </h1>
          <span className="text-sm text-muted-foreground">
            · {total.toLocaleString()}
          </span>
        </div>

        {/* List */}
        <div className="divide-y">
          {loading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 p-4 md:px-6">
                <Skeleton className="h-10 w-10 shrink-0 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-24" />
                </div>
                <Skeleton className="h-8 w-20" />
              </div>
            ))
          ) : users.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 px-4 py-16 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <Users className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium">
                {t("profile.noFollowers") || "No followers yet."}
              </p>
            </div>
          ) : (
            users.map((u) => (
              <div
                key={u.id}
                className="flex items-center gap-3 p-4 transition-colors hover:bg-accent/30 md:px-6"
              >
                <Avatar
                  name={u.fullName}
                  color={u.avatarColor}
                  src={u.avatarUrl}
                  size="sm"
                  className="shrink-0 cursor-pointer"
                  onClick={() => openProfile(u.username)}
                />
                <div className="min-w-0 flex-1">
                  <button
                    onClick={() => openProfile(u.username)}
                    className="flex min-w-0 items-center gap-1 text-sm font-medium hover:underline"
                    dir="auto"
                  >
                    <span className="truncate">{u.fullName}</span>
                    {u.isVerified && <VerifiedBadge size={13} />}
                  </button>
                  <p className="truncate text-xs text-muted-foreground">@{u.username}</p>
                  {u.bio && (
                    <p className="mt-0.5 truncate text-xs text-muted-foreground" dir="auto">
                      {u.bio}
                    </p>
                  )}
                </div>
                {currentUser && u.id !== currentUser.id && (
                  <FollowButton
                    targetUserId={u.id}
                    targetUsername={u.username}
                    isFollowing={u.isFollowing ?? false}
                    isFollowedBy={u.isFollowedBy ?? false}
                    size="sm"
                    onStateChange={(state) => {
                      setUsers((prev) =>
                        prev.map((p) =>
                          p.id === u.id ? { ...p, isFollowing: state.isFollowing } : p
                        )
                      );
                    }}
                  />
                )}
              </div>
            ))
          )}
        </div>

        {/* Load More */}
        {hasMore && !loading && (
          <div className="flex items-center justify-center py-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={loadMore}
              disabled={loadingMore}
            >
              {loadingMore ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
              ) : null}
              {loadingMore
                ? (t("posts.loadingMore") || "Loading…")
                : (t("posts.loadMore") || "Load more")}
            </Button>
          </div>
        )}

        {!loading && users.length > 0 && !hasMore && (
          <div className="flex items-center justify-center py-6 text-center text-xs text-muted-foreground">
            {t("posts.endOfFeed") || "You're all caught up."}
          </div>
        )}
      </div>
    </div>
  );
}
