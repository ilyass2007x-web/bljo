"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  Heart,
  MessageCircle,
  Eye,
  Share2,
  BookmarkPlus,
} from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { useCollectionsEnabled } from "@/lib/client/platform";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { ShareDialog } from "@/components/posts/share-dialog";
import { SaveToCollectionDialog } from "@/components/collections/save-to-collection-dialog";
import {
  useContentEngagement,
  useContentStore,
} from "@/lib/client/content-store";
import type { PostDTO } from "@/components/posts/post-card";

interface PostActionsProps {
  post: PostDTO;
}

function formatCount(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000) {
    const v = n / 1000;
    return (v >= 100 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, "")) + "K";
  }
  const v = n / 1_000_000;
  return v.toFixed(1).replace(/\.0$/, "") + "M";
}

/**
 * PostActions — the action row at the bottom of each PostCard.
 *
 * UNIFIED STATE (spec §1, §12 — Single Source of Truth):
 *   Like / likeCount / commentCount / viewCount are read from the
 *   global content store (`useContentEngagement`). When ANY other
 *   component showing the same post.id updates the state, this
 *   component re-renders INSTANTLY with the new value — no Refresh.
 *
 *   This means: if the user clicks Like on a PostCard in the Home feed
 *   and then opens the same Post on the comments page, the Like button
 *   on the comments page will ALREADY be red — because both components
 *   share the same store slice (keyed by `post:${post.id}`).
 *
 * OPTIMISTIC UI (spec §3, §18, §30):
 *   - On click, we flip `liked` + bump `likeCount` INSTANTLY in the store
 *     (every subscribed component re-renders immediately).
 *   - The API call fires in the background.
 *   - On success: we reconcile with the server's authoritative response.
 *   - On failure: we rollback + toast error.
 *
 * DOUBLE-CLICK PREVENTION (spec §21, §29):
 *   - `likeLoading` flag in the store disables the Like button across
 *     ALL components showing this post (so the user can't click Like
 *     on a different card while the first click is in-flight).
 *
 * SECURITY (spec §32):
 *   - The post.id comes from server-rendered props — the client cannot
 *     spoof it.
 *   - The userId is derived from the session cookie on the server (via
 *     `requireVerifiedUser()` in the API route) — the client never
 *     sends it.
 *   - We never trust a client-supplied `likeCount` — only the server's
 *     response updates the count.
 */
export function PostActions({ post }: PostActionsProps) {
  const router = useRouter();
  const { t } = useTranslation();
  const { user } = useAuthStore();

  // ── Subscribe to the unified engagement state ────────────────────────
  // This is the KEY change. Previously this component had its own local
  // useState for liked + likeCount + commentCount + viewCount. Now it
  // reads from the global store — so every component showing this post
  // shares the SAME state.
  const {
    liked,
    likeCount,
    commentCount,
    viewCount,
    shareCount,
    likeLoading,
  } = useContentEngagement("post", post.id, {
    liked: post.isLiked,
    likeCount: post.likeCount,
    commentCount: post.commentCount,
    viewCount: post.viewCount,
    shareCount: post.shareCount ?? 0,
  });

  // Local state for the share dialog (UI-only — not engagement state).
  const [shareOpen, setShareOpen] = useState(false);
  // Share in-flight flag — disables the Share button while a share request
  // is being recorded (prevents double-submits from rapid clicks). Set
  // true when the ShareDialog opens, cleared when the dialog closes OR
  // when onShareRecorded fires.
  const [shareLoading, setShareLoading] = useState(false);

  // Phase 5 — Collections: Save-to-Collection dialog state. The button is
  // gated by the `collections` feature flag (server-side source of truth
  // mirrored client-side via useCollectionsEnabled). When the flag is OFF,
  // no button is rendered + no API call is made.
  const collectionsEnabled = useCollectionsEnabled();
  const [saveOpen, setSaveOpen] = useState(false);

  // ── Share handler — opens the share dialog. The actual shareCount bump
  //    happens AFTER the user successfully shares (via the ShareDialog's
  //    onShareRecorded callback) — opening the dialog alone does NOT count
  //    as a share (spec: "لا تعتبر مجرد فتح Share modal مشاركة ناجحة").
  //    When the server confirms a SHARE event, we reconcile the store with
  //    the server's authoritative shareCount.
  const handleShareClick = useCallback(async () => {
    if (shareLoading) return; // prevent double-click
    setShareOpen(true);
  }, [shareLoading]);

  // ── Called by ShareDialog after a SHARE event was recorded server-side.
  //    We update the unified store with the server's authoritative count.
  const handleShareRecorded = useCallback((serverShareCount: number) => {
    useContentStore.getState().patch("post", post.id, {
      shareCount: serverShareCount,
    });
    setShareLoading(false);
  }, [post.id]);

  const toggleLike = useCallback(async () => {
    if (likeLoading) return; // prevent double-click

    // ── AUTH GATE (spec §6) ──────────────────────────────────────────────
    // Like / Follow / Comment / Save require an authenticated account.
    // Public viewing (reading the post, seeing counts) is free.
    if (!user) {
      toast.info(t("auth.signInToLike") || "Sign in to like this post");
      router.push("/");
      return;
    }

    // Capture current state for rollback.
    const wasLiked = liked;
    const prevCount = likeCount;

    // ── Optimistic update — INSTANTLY flip the state in the store ───────
    // This re-renders EVERY component showing this post (Home feed,
    // Profile posts, Related posts, Search results, etc.) — they all
    // see the new liked + likeCount values immediately.
    useContentStore.getState().patch("post", post.id, {
      liked: !wasLiked,
      likeCount: prevCount + (wasLiked ? -1 : 1),
      likeLoading: true,
    });

    try {
      const data = await api.post<{ liked: boolean; likeCount: number }>(
        `/api/v1/posts/${post.id}/like`
      );
      // ── Reconcile with the server's authoritative response ────────────
      // The server is the source of truth (spec §18) — if the optimistic
      // state drifted (e.g. another concurrent request won), the server's
      // response wins.
      useContentStore.getState().patch("post", post.id, {
        liked: data.liked,
        likeCount: data.likeCount,
        likeLoading: false,
      });
    } catch (e) {
      // ── Rollback on failure (spec §30) ────────────────────────────────
      // Restore the previous state — every subscribed component re-renders
      // back to the original value.
      useContentStore.getState().patch("post", post.id, {
        liked: wasLiked,
        likeCount: prevCount,
        likeLoading: false,
      });
      const msg = e instanceof ApiClientError ? e.message : "Failed to toggle like";
      toast.error(msg);
    }
  }, [liked, likeCount, post.id, likeLoading, user, router, t]);

  return (
    <>
      <div className="flex items-center justify-between gap-0">
        {/* Like button */}
        <button
          onClick={toggleLike}
          disabled={likeLoading}
          className={cn(
            "group flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-accent/50",
            liked && "text-red-500 hover:bg-red-500/10"
          )}
          aria-pressed={liked}
          aria-label={liked ? (t("posts.unlike") || "Unlike") : (t("posts.like") || "Like")}
        >
          <Heart
            className={cn(
              "h-[18px] w-[18px] transition-all duration-200",
              liked && "fill-current scale-110",
              likeLoading && "opacity-50"
            )}
          />
          {likeCount > 0 && (
            <span className="tabular-nums">{formatCount(likeCount)}</span>
          )}
        </button>

        {/* Comment button */}
        <button
          onClick={() => router.push(`/?view=comments&postId=${post.id}`)}
          className="group flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-sky-500"
          aria-label={t("posts.comment") || "Comment"}
        >
          <MessageCircle className="h-[18px] w-[18px]" />
          {commentCount > 0 && (
            <span className="tabular-nums">{formatCount(commentCount)}</span>
          )}
        </button>

        {/* Views — display only */}
        <div
          className="flex flex-1 items-center justify-center gap-1.5 py-2 text-[13px] font-medium text-muted-foreground"
          aria-label={t("posts.views") || "Views"}
          title={`${viewCount.toLocaleString()} ${t("posts.views") || "views"}`}
        >
          <Eye className="h-[18px] w-[18px]" />
          <span className="tabular-nums">{formatCount(viewCount)}</span>
        </div>

        {/* Share button — records the share server-side via ShareDialog
            (only when the user actually shares, NOT on dialog open).
            shareCount is displayed + reconciled via the unified store. */}
        <button
          onClick={handleShareClick}
          disabled={shareLoading}
          className="group flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-emerald-500 disabled:opacity-50"
          aria-label={t("posts.share") || "Share"}
        >
          <Share2 className="h-[18px] w-[18px]" />
          {shareCount > 0 && (
            <span className="tabular-nums">{formatCount(shareCount)}</span>
          )}
        </button>

        {/* Phase 5 — Collections: Save to Collection button.
            Gated by the `collections` feature flag (server-side source of
            truth mirrored client-side via useCollectionsEnabled). The
            server re-checks the flag on every collection API call, so
            hiding the button on the client is NOT security — it's UX. */}
        {collectionsEnabled && (
          <button
            onClick={() => setSaveOpen(true)}
            className="group flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-amber-500"
            aria-label={t("collections.save") || "Save to collection"}
            title={t("collections.save") || "Save to collection"}
          >
            <BookmarkPlus className="h-[18px] w-[18px]" />
          </button>
        )}
      </div>

      {/* Share modal */}
      <ShareDialog
        postId={post.id}
        authorUsername={post.author.username}
        open={shareOpen}
        onOpenChange={(o) => {
          setShareOpen(o);
          if (!o) setShareLoading(false);
        }}
        onShareRecorded={handleShareRecorded}
      />

      {/* Phase 5 — Collections: Save-to-Collection dialog. */}
      {collectionsEnabled && (
        <SaveToCollectionDialog
          open={saveOpen}
          onOpenChange={setSaveOpen}
          contentType="post"
          contentId={post.id}
        />
      )}
    </>
  );
}
