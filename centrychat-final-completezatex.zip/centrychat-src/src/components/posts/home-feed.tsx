"use client";

import { useEffect, useRef, useState, useCallback, Fragment } from "react";
import { useRouter } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { HomeComposer } from "@/components/posts/home-composer";
import { PostCard, type PostDTO } from "@/components/posts/post-card";
import { ArticleCard } from "@/components/articles/article-card";
import { WhoToFollow } from "@/components/posts/who-to-follow";
import { useUnifiedFeed } from "@/lib/client/use-unified-feed";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { api, type UserSearchResult } from "@/lib/client/api";
import { Loader2, FileText, RefreshCw, Home as HomeIcon, Search } from "lucide-react";
import { AdSlot, useAdsConfig } from "@/components/ads/adsense";

/**
 * HomeFeed — the default authenticated view at `/`.
 *
 * UNIFIED FEED (spec §12-§15): the Home feed now shows BOTH Short Posts
 * AND published Articles, interleaved chronologically. From the user's
 * perspective everything is a "post" — Articles are just a richer
 * content type that renders as a richer card.
 *
 * Layout (spec §8, §22):
 *   - MainNav (desktop top bar + mobile bottom bar)
 *   - Mobile sticky header ("Home" + search icon)
 *   - Centered max-w-xl column containing:
 *     - HomeComposer (inline post composer)
 *     - Unified feed list (PostCard OR ArticleCard based on item.type)
 *     - WhoToFollow (when feed is empty)
 *     - Loading skeleton
 *     - Error state with Retry
 *     - Empty state
 *     - Infinite scroll sentinel
 *     - End-of-feed marker
 *
 * Desktop: centered column with comfortable side margins.
 * Mobile: full-width with px-4 padding.
 */
export function HomeFeed() {
  const router = useRouter();
  const { user } = useAuthStore();
  const { t } = useTranslation();
  const {
    items,
    loading,
    loadingMore,
    hasMore,
    error,
    loadMore,
    refresh,
    removeItem,
    updatePost,
  } = useUnifiedFeed(20);

  // AdSense — read the config to know the min distance between ads. When
  // ads are disabled, the <AdSlot> renders nothing — no perf cost.
  const adsConfig = useAdsConfig();
  const adInterval = adsConfig.config?.minDistanceSlots ?? 3;

  // ── Mobile Home user search state ──────────────────────────────
  // Opens a dialog that searches for PLATFORM USERS (not messages).
  // Uses the existing GET /api/v1/users/search API — same endpoint
  // the Messenger's search uses, but in a DIFFERENT context:
  //   Home Search → find user → open their Profile
  //   Messenger Search → find user → start conversation
  // These are two separate search contexts per spec.
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<UserSearchResult[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Debounced user search — calls the existing API endpoint.
  const doSearch = useCallback((q: string) => {
    setSearchQuery(q);
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    if (q.trim().length < 2) {
      setSearchResults([]);
      setSearchLoading(false);
      return;
    }
    setSearchLoading(true);
    searchDebounceRef.current = setTimeout(async () => {
      try {
        const data = await api.get<{ users: UserSearchResult[] }>(
          `/api/v1/users/search?q=${encodeURIComponent(q)}`
        );
        setSearchResults(data.users);
      } catch {
        setSearchResults([]);
      } finally {
        setSearchLoading(false);
      }
    }, 300); // 300ms debounce
  }, []);

  function openProfile(username: string) {
    setSearchOpen(false);
    router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
  }

  const sentinelRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!hasMore || loadingMore) return;
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          void loadMore();
        }
      },
      { rootMargin: "300px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [hasMore, loadingMore, loadMore]);

  function handleItemDeleted(id: string) {
    removeItem(id);
  }

  function handlePostUpdated(updated: PostDTO) {
    updatePost(updated);
  }

  function handleSuggestionFollowed() {
    refresh();
  }

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile sticky header — the Search icon now opens the EXISTING FULL
          Search experience (/?view=search) which already includes a "People"
          tab for user search, alongside Posts / Articles / Topics tabs.
          Previously this opened a user-only search dialog — that dialog is
          preserved below (dead code, kept for reversibility) but is no longer
          triggered. User Search is NOT lost: it's the "People" tab in the
          full Search page. Also includes a small "About" link so mobile
          users can reach the /about page. */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-2 border-b border-border/60 bg-background/80 px-4 backdrop-blur-md md:hidden">
        <HomeIcon className="h-5 w-5 text-primary" />
        <span className="text-base font-bold">{t("nav.home") || "Home"}</span>
        <div className="ml-auto flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push("/about")}
            className="h-9 px-2 text-xs"
            aria-label={t("nav.about") || "About"}
            title={t("nav.about") || "About"}
          >
            {t("nav.about") || "About"}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => router.push("/?view=search")}
            className="h-9 w-9"
            aria-label={t("nav.search") || "Search"}
            title={t("nav.search") || "Search"}
          >
            <Search className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Centered feed column — max-w-xl on desktop for comfortable reading.
          Uses divide-y with a slightly stronger border color for clear
          post separation (spec §2 — "clear but lightweight"). */}
      <div className="mx-auto max-w-xl border-x border-border/40">
        {/* Inline composer */}
        <HomeComposer />

        {/* Who to follow — only when feed is empty */}
        {!loading && !error && items.length === 0 && (
          <WhoToFollow onFollowed={handleSuggestionFollowed} />
        )}

        {/* Unified feed list — uses divide-y for clear separation.
            Each item is rendered as either PostCard or ArticleCard
            based on its `type` discriminator. */}
        <main className="min-h-[50vh]">
          {/* Loading skeleton — resembles actual PostCard layout */}
          {loading && (
            <div className="divide-y divide-border/60">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="flex gap-3 px-4 py-4 md:px-6">
                  <Skeleton className="h-10 w-10 shrink-0 rounded-full" />
                  <div className="flex-1 space-y-2.5">
                    <div className="flex items-center gap-2">
                      <Skeleton className="h-3.5 w-24" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-5/6" />
                    <Skeleton className="h-4 w-3/4" />
                    <div className="flex justify-between pt-2">
                      <Skeleton className="h-7 w-16 rounded-lg" />
                      <Skeleton className="h-7 w-16 rounded-lg" />
                      <Skeleton className="h-7 w-16 rounded-lg" />
                      <Skeleton className="h-7 w-7 rounded-lg" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Error state */}
          {!loading && error && (
            <div className="flex flex-col items-center justify-center gap-3 px-4 py-20 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-destructive/10">
                <RefreshCw className="h-7 w-7 text-destructive" />
              </div>
              <p className="text-sm font-medium">{error}</p>
              <Button variant="outline" size="sm" onClick={() => refresh()}>
                <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
                {t("posts.retry") || "Retry"}
              </Button>
            </div>
          )}

          {/* Empty state */}
          {!loading && !error && items.length === 0 && (
            <div className="flex flex-col items-center justify-center gap-3 px-4 py-20 text-center md:px-6">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                <FileText className="h-7 w-7 text-muted-foreground" />
              </div>
              <p className="text-base font-semibold">
                {t("posts.feedEmptyTitle") || "Your feed is empty."}
              </p>
              <p className="max-w-sm text-sm text-muted-foreground">
                {t("posts.feedEmptyDesc") ||
                  "Follow people to see their posts here, or write your first post above."}
              </p>
            </div>
          )}

          {/* Unified feed items — render PostCard OR ArticleCard
              based on item.type. Each card uses the same divide-y
              border treatment so the feed reads as a single stream
              (spec §13 — "ONE unified content feed").

              AD INSERTION (spec §21):
              We insert a <AdSlot placement="HOME_FEED" /> every Nth
              item (N = minDistanceSlots from the AdSense config, default 3).
              The <AdSlot> renders nothing when ads are disabled / blocked /
              excluded — so the feed visually collapses to just the cards.
              The HOME_TOP placement is rendered above the feed list. */}
          {!loading && !error && items.length > 0 && (
            <div className="divide-y divide-border/60">
              <AdSlot placement="HOME_TOP" />
              {items.map((item, idx) => (
                <Fragment key={item.type === "post" ? `post-${item.post.id}` : `article-${item.article.id}`}>
                  {item.type === "post" ? (
                    <PostCard
                      post={item.post}
                      canDelete={user?.id === item.post.author.id}
                      onDeleted={handleItemDeleted}
                      onUpdated={handlePostUpdated}
                    />
                  ) : (
                    <ArticleCard article={item.article} />
                  )}
                  {/* Insert an in-feed ad every `adInterval` items. The +1
                      offset avoids placing an ad as the very first item
                      (the HOME_TOP slot already covers that). */}
                  {(idx + 1) % adInterval === 0 && idx < items.length - 1 && (
                    <AdSlot placement="HOME_FEED" />
                  )}
                </Fragment>
              ))}
            </div>
          )}

          {/* Infinite scroll sentinel */}
          {hasMore && !loading && !error && (
            <div ref={sentinelRef} className="flex items-center justify-center py-8">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => loadMore()}
                disabled={loadingMore}
              >
                {loadingMore ? (
                  <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                ) : null}
                {loadingMore
                  ? (t("posts.loadingMore") || "Loading…")
                  : (t("posts.loadMore") || "Load more")}
              </Button>
            </div>
          )}

          {/* End-of-feed */}
          {!loading && !error && items.length > 0 && !hasMore && (
            <div className="flex items-center justify-center py-8 text-center text-xs text-muted-foreground">
              {t("posts.endOfFeed") || "You're all caught up."}
            </div>
          )}
        </main>
      </div>

      {/* ── Mobile Home User Search Dialog ───────────────────────────
          Searches for PLATFORM USERS (not messages/conversations).
          Uses the existing GET /api/v1/users/search API.
          Clicking a result opens the user's Profile.
          This is SEPARATE from the Messenger's search (which searches
          for people to start conversations with) — per spec:
          "Do not connect Home Search to the Messages Search functionality." */}
      <Dialog open={searchOpen} onOpenChange={(o) => {
        setSearchOpen(o);
        if (!o) {
          setSearchQuery("");
          setSearchResults([]);
        }
      }}>
        <DialogContent className="max-w-md p-0">
          <DialogHeader className="px-4 pt-4 pb-2">
            <DialogTitle>Search users</DialogTitle>
          </DialogHeader>
          <div className="px-4 pb-2">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or username…"
                value={searchQuery}
                onChange={(e) => doSearch(e.target.value)}
                className="pl-8"
                autoFocus
              />
            </div>
          </div>
          <ScrollArea className="max-h-80">
            <div className="space-y-1 p-2">
              {searchLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : searchQuery.trim().length < 2 ? (
                <p className="py-8 text-center text-sm text-muted-foreground">
                  Type at least 2 characters to search
                </p>
              ) : searchResults.length === 0 ? (
                <p className="py-8 text-center text-sm text-muted-foreground">
                  No users found
                </p>
              ) : (
                searchResults.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => openProfile(u.username)}
                    className="flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-accent"
                  >
                    <Avatar
                      name={u.fullName}
                      color={u.avatarColor}
                      src={u.avatarUrl}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <p className="flex items-center gap-1 truncate text-sm font-medium" dir="auto">
                        {u.fullName}
                        {u.isVerified && <VerifiedBadge size={12} />}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">
                        @{u.username}
                      </p>
                    </div>
                  </button>
                ))
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}
