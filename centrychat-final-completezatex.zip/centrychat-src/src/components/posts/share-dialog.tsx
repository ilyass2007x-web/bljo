"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Copy, Check, Share2, Link2 } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";

interface ShareDialogProps {
  postId: string;
  authorUsername: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /**
   * Called when a SHARE or LINK_COPY event was successfully recorded on
   * the server. The parent (PostActions) uses this to optimistically
   * bump the shareCount in the unified content store, then reconcile
   * with the server's response. The count passed is the SERVER-AUTHORITATIVE
   * shareCount returned by POST /api/v1/posts/:id/share.
   *
   * NOT called when:
   *   - The user cancels the native share dialog (AbortError).
   *   - The clipboard write fails.
   *   - The server tracking request fails (the user still shared, but we
   *     couldn't record it — silently skip the UI bump).
   */
  onShareRecorded?: (shareCount: number) => void;
}

/**
 * ShareDialog — lets the user share a post via:
 *   1. Native Web Share API (mobile + desktop browsers that support it)
 *   2. Copy-link fallback (manual clipboard write)
 *
 * Tracking:
 *   - Opening the modal does NOT count as a share. Only an explicit:
 *       * successful native share → records a SHARE event
 *       * successful copy-link    → records a LINK_COPY event
 *   - This matches the spec: "لا تعتبر مجرد فتح Share modal مشاركة ناجحة
 *     إذا لم يضغط المستخدم على Share/Copy."
 *
 * The share URL is `${origin}/?post=${postId}` — for now this just routes
 * to the home feed (no standalone post detail page in this phase). When
 * a post detail page is added later, this URL will resolve to that page
 * automatically without code changes here.
 */
export function ShareDialog({
  postId,
  authorUsername,
  open,
  onOpenChange,
  onShareRecorded,
}: ShareDialogProps) {
  const { t } = useTranslation();
  const [copied, setCopied] = useState(false);
  const [recording, setRecording] = useState(false);

  // Build the share URL — uses window.location.origin so it works on any
  // deployment (Netlify preview, production, localhost).
  const [shareUrl, setShareUrl] = useState("");

  useEffect(() => {
    if (typeof window !== "undefined") {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setShareUrl(`${window.location.origin}/?post=${postId}`);
    }
  }, [postId]);

  // Reset copied state when dialog closes.
  useEffect(() => {
    if (!open) {
      const id = setTimeout(() => setCopied(false), 200);
      return () => clearTimeout(id);
    }
  }, [open]);

  async function recordEvent(type: "SHARE" | "LINK_COPY") {
    setRecording(true);
    try {
      const data = await api.post<{ shared: boolean; shareCount: number }>(
        `/api/v1/posts/${postId}/share`,
        { type }
      );
      // Only bump the count for actual SHARE events (LINK_COPY events are
      // tracked separately for analytics but don't count toward the
      // public shareCount). The server's shareCount is authoritative.
      if (type === "SHARE" && typeof data.shareCount === "number") {
        onShareRecorded?.(data.shareCount);
      }
    } catch {
      // Tracking failures are non-fatal — the user successfully shared,
      // we just couldn't record the event. Don't bother them with an error.
    } finally {
      setRecording(false);
    }
  }

  async function nativeShare() {
    if (typeof navigator === "undefined" || !navigator.share) return false;
    try {
      await navigator.share({
        title: `@${authorUsername} on ${shareUrl}`,
        text: t("posts.shareText") || "Check out this post",
        url: shareUrl,
      });
      // Record SHARE event only if the share didn't throw (some browsers
      // throw AbortError if the user cancels — that doesn't count).
      await recordEvent("SHARE");
      toast.success(t("posts.shared") || "Shared");
      onOpenChange(false);
      return true;
    } catch (err) {
      // AbortError = user cancelled — don't show an error, just close.
      if (err instanceof DOMException && err.name === "AbortError") {
        return false;
      }
      // Any other error → fall back to copy-link UX.
      return false;
    }
  }

  async function copyLink() {
    if (typeof navigator === "undefined" || !navigator.clipboard) {
      // Fallback for very old browsers — select the input.
      toast.error(t("posts.copyFailed") || "Clipboard not supported");
      return;
    }
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      await recordEvent("LINK_COPY");
      toast.success(t("posts.linkCopied") || "Link copied to clipboard");
      // Auto-close after a short delay so the user sees the success state.
      setTimeout(() => onOpenChange(false), 800);
    } catch {
      toast.error(t("posts.copyFailed") || "Failed to copy link");
    }
  }

  const hasNativeShare = typeof navigator !== "undefined" && !!navigator.share;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0">
        <DialogHeader className="border-b px-4 py-3">
          <DialogTitle className="text-base flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            {t("posts.sharePost") || "Share Post"}
          </DialogTitle>
          <DialogDescription className="sr-only">
            {t("posts.shareDesc") || "Share this post or copy the link."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 p-4">
          {/* Native share button — only show if Web Share API is available */}
          {hasNativeShare && (
            <Button
              onClick={nativeShare}
              className="w-full"
              disabled={recording}
            >
              {recording ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Share2 className="mr-2 h-4 w-4" />
              )}
              {t("posts.shareVia") || "Share via…"}
            </Button>
          )}

          {/* Copy link section */}
          <div className="space-y-2">
            <label
              htmlFor="share-link-input"
              className="text-xs font-medium text-muted-foreground"
            >
              {t("posts.postLink") || "Post link"}
            </label>
            <div className="flex gap-2">
              <Input
                id="share-link-input"
                value={shareUrl}
                readOnly
                onFocus={(e) => e.target.select()}
                className="text-xs"
                aria-label={t("posts.postLink") || "Post link"}
              />
              <Button
                onClick={copyLink}
                variant={copied ? "default" : "outline"}
                disabled={recording}
                className="shrink-0"
                size="sm"
              >
                {recording ? (
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                ) : copied ? (
                  <Check className="mr-1.5 h-3.5 w-3.5" />
                ) : (
                  <Link2 className="mr-1.5 h-3.5 w-3.5" />
                )}
                {copied
                  ? (t("posts.copied") || "Copied")
                  : (t("posts.copyLink") || "Copy link")}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
