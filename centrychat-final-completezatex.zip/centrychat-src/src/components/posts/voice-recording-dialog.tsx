"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Mic,
  MicOff,
  Square,
  X,
  Loader2,
  AlertTriangle,
  Play,
  Pause,
  Check,
  RefreshCw,
} from "lucide-react";
import {
  useVoiceRecording,
  formatRecordingDuration,
} from "@/hooks/use-voice-recording";
import { useTranslation } from "@/lib/client/i18n-store";
import { cn } from "@/lib/utils";

/**
 * VoiceRecordingDialog — voice recording modal for the post composer.
 *
 * Lifecycle (per spec §3):
 *   1. Initial: "Use Microphone" prompt.
 *   2. Requesting: spinner while getUserMedia resolves.
 *   3. Recording: live timer + pulsing indicator + Stop / Cancel buttons.
 *   4. Review (after stop): audio preview player + duration + Use / Discard.
 *   5. Denied: friendly message + retry option.
 *   6. Unsupported: graceful message (no fallback for audio on most
 *      browsers — no equivalent of <input capture> for audio).
 *
 * The recording is shown as a preview <audio> element after stop, so
 * the user can verify it before confirming. On Confirm, the onRecord
 * callback fires with the Blob + preview URL.
 *
 * Cleanup: the useVoiceRecording hook stops all mic tracks + clears the
 * MediaRecorder + chunk array the moment the dialog closes or the
 * component unmounts. No microphone stays running in the background.
 *
 * Accessibility (spec §8):
 *   - Every button has an aria-label.
 *   - The recording state is announced via aria-live.
 *   - The duration counter is aria-live so screen-readers announce
 *     every-second ticks (but we throttle to avoid spam — only the
 *     first + every 10 seconds + final).
 */

interface VoiceRecordingDialogProps {
  open: boolean;
  onClose: () => void;
  /** Called when the user confirms a recording. */
  onRecord: (result: {
    blob: Blob;
    previewUrl: string;
    mimeType: string;
    durationSeconds: number;
  }) => void;
}

export function VoiceRecordingDialog({ open, onClose, onRecord }: VoiceRecordingDialogProps) {
  const { t } = useTranslation();
  const {
    state,
    message,
    durationSeconds,
    isSupported,
    startRecording,
    stopRecording,
    cancelRecording,
  } = useVoiceRecording();
  // The confirmed recording (shown in the "review" state).
  const [recorded, setRecorded] = useState<{
    blob: Blob;
    previewUrl: string;
    mimeType: string;
    durationSeconds: number;
  } | null>(null);
  // Audio playback state (for the review <audio> element).
  const audioRef = useRef<HTMLAudioElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  /**
   * When the dialog opens, reset to the idle state. When it closes,
   * cancel any in-progress recording + clear the recorded preview.
   *
   * The microphone MUST stop on close (spec §3 + §12) — we don't want
   * the mic staying on after the user dismisses the dialog.
   */
  useEffect(() => {
    if (open) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setRecorded(null);
      setIsPlaying(false);
    } else {
      cancelRecording();
      setRecorded((prev) => {
        if (prev) URL.revokeObjectURL(prev.previewUrl);
        return null;
      });
      setIsPlaying(false);
    }
  }, [open, cancelRecording]);

  /**
   * When the dialog opens AND the browser supports voice recording AND
   * we haven't yet requested permission, automatically start the
   * recording flow. The user explicitly clicked the "Microphone" button
   * to open the dialog — that's the explicit user action the spec
   * requires before requesting microphone access.
   */
  useEffect(() => {
    if (open && isSupported && state === "idle" && !recorded) {
      void startRecording();
    }
  }, [open, isSupported, state, recorded, startRecording]);

  // Cleanup on unmount — revoke the recorded preview URL.
  useEffect(() => {
    return () => {
      if (recorded) URL.revokeObjectURL(recorded.previewUrl);
    };
  }, [recorded]);

  const handleStop = useCallback(async () => {
    const result = await stopRecording();
    if (result) {
      setRecorded((prev) => {
        if (prev) URL.revokeObjectURL(prev.previewUrl);
        return result;
      });
    }
  }, [stopRecording]);

  const handleDiscard = useCallback(() => {
    setRecorded((prev) => {
      if (prev) URL.revokeObjectURL(prev.previewUrl);
      return null;
    });
    setIsPlaying(false);
    // Restart the recording flow if supported.
    if (isSupported) {
      void startRecording();
    }
  }, [isSupported, startRecording]);

  const handleConfirm = useCallback(() => {
    if (recorded) {
      onRecord(recorded);
      // Don't revoke the URL here — the caller owns it now.
      setRecorded(null);
    }
    setIsPlaying(false);
    onClose();
  }, [recorded, onRecord, onClose]);

  const handleCancel = useCallback(() => {
    cancelRecording();
    setRecorded((prev) => {
      if (prev) URL.revokeObjectURL(prev.previewUrl);
      return null;
    });
    setIsPlaying(false);
    onClose();
  }, [cancelRecording, onClose]);

  // Audio playback controls.
  const togglePlayPause = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (audio.paused) {
      void audio.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
    } else {
      audio.pause();
      setIsPlaying(false);
    }
  }, []);

  // Reset isPlaying when the audio ends.
  const handleAudioEnded = useCallback(() => {
    setIsPlaying(false);
  }, []);

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) handleCancel();
      }}
    >
      <DialogContent
        className="sm:max-w-md"
        onPointerDownOutside={(e) => {
          // Prevent closing mid-request / mid-recording.
          if (state === "requesting" || state === "recording") e.preventDefault();
        }}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mic className="h-5 w-5" />
            {t("mic.title") || "Record Audio"}
          </DialogTitle>
          <DialogDescription>
            {recorded
              ? t("mic.reviewDesc") || "Review your recording. Discard or use it."
              : t("mic.desc") || "Record a short voice message."}
          </DialogDescription>
        </DialogHeader>

        {/* ── Recording / Review area ── */}
        <div className="space-y-3">
          {recorded ? (
            // Review state — audio preview player + duration.
            <div className="space-y-3 rounded-lg border bg-muted/30 p-4">
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={togglePlayPause}
                  aria-label={isPlaying ? t("mic.pause") || "Pause" : t("mic.play") || "Play"}
                >
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <div className="flex-1">
                  <audio
                    ref={audioRef}
                    src={recorded.previewUrl}
                    onEnded={handleAudioEnded}
                    controls
                    className="w-full"
                    aria-label={t("mic.audioPreviewAlt") || "Audio preview"}
                  />
                </div>
              </div>
              <p className="text-center text-xs text-muted-foreground">
                {t("mic.duration") || "Duration"}: {formatRecordingDuration(recorded.durationSeconds)}
              </p>
            </div>
          ) : !isSupported ? (
            // Unsupported state.
            <div className="flex flex-col items-center justify-center gap-3 rounded-lg border bg-muted/30 p-8 text-center">
              <MicOff className="h-10 w-10 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">
                  {t("mic.unsupportedTitle") || "Microphone not supported"}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {t("mic.unsupportedDesc") ||
                    "Your browser doesn't support audio recording."}
                </p>
              </div>
            </div>
          ) : state === "denied" ? (
            // Denied state.
            <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-amber-500/30 bg-amber-500/5 p-8 text-center">
              <AlertTriangle className="h-10 w-10 text-amber-500" />
              <div>
                <p className="text-sm font-medium">
                  {t("mic.deniedTitle") || "Microphone access blocked"}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {message ||
                    t("mic.deniedDesc") ||
                    "Microphone access was blocked. Please allow microphone access in your browser settings and try again."}
                </p>
              </div>
            </div>
          ) : state === "requesting" ? (
            // Requesting state — spinner.
            <div className="flex flex-col items-center justify-center gap-3 rounded-lg border bg-muted/30 p-12 text-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                {t("mic.requesting") || "Requesting microphone access..."}
              </p>
            </div>
          ) : state === "error" ? (
            // Error state.
            <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-destructive/30 bg-destructive/5 p-8 text-center">
              <AlertTriangle className="h-10 w-10 text-destructive" />
              <p className="text-sm text-muted-foreground">
                {message || t("mic.error") || "Unable to access the microphone."}
              </p>
            </div>
          ) : (
            // Recording state — pulsing mic + live timer.
            <div className="flex flex-col items-center justify-center gap-4 rounded-lg border bg-muted/30 p-10 text-center">
              <div className="relative">
                <span
                  className={cn(
                    "absolute inset-0 -m-2 rounded-full bg-red-500/30",
                    state === "recording" && "animate-ping"
                  )}
                  aria-hidden="true"
                />
                <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-red-500/10">
                  <Mic className="h-8 w-8 text-red-500" />
                </div>
              </div>
              <p
                className="font-mono text-2xl font-bold tabular-nums"
                aria-live="polite"
                aria-atomic="true"
              >
                {formatRecordingDuration(durationSeconds)}
              </p>
              <p className="text-xs text-muted-foreground">
                {state === "recording"
                  ? t("mic.recording") || "Recording..."
                  : t("mic.starting") || "Starting..."}
              </p>
            </div>
          )}
        </div>

        <DialogFooter className="flex-row items-center justify-between gap-2 sm:justify-between">
          <Button variant="ghost" size="sm" onClick={handleCancel}>
            <X className="mr-1 h-4 w-4" />
            {t("mic.cancel") || "Cancel"}
          </Button>
          {recorded ? (
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleDiscard}>
                <RefreshCw className="mr-1 h-4 w-4" />
                {t("mic.discard") || "Discard"}
              </Button>
              <Button size="sm" onClick={handleConfirm}>
                <Check className="mr-1 h-4 w-4" />
                {t("mic.useRecording") || "Use Recording"}
              </Button>
            </div>
          ) : (
            isSupported &&
            state === "recording" && (
              <Button
                size="sm"
                variant="destructive"
                onClick={handleStop}
                aria-label={t("mic.stop") || "Stop recording"}
              >
                <Square className="mr-1 h-3 w-3 fill-current" />
                {t("mic.stop") || "Stop"}
              </Button>
            )
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
