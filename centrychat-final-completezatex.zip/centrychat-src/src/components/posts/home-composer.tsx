"use client";

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/shared/avatar";
import { Loader2, PenSquare } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { PostDTO } from "@/components/posts/post-card";
import { POST_MAX_LENGTH } from "@/lib/posts/parser";

/**
 * HomeComposer — an INLINE post composer that lives at the top of the
 * Home feed (not a modal).
 *
 * Phase 2: text only. Supports URLs, @mentions, #hashtags.
 *
 * PHASE 1 UI CHANGE (What's Happening composer — text-only scope):
 *   The Camera, Microphone, and photo-attachment UI has been removed from
 *   THIS composer only. The post composer in the home feed is now text-
 *   only, matching the underlying API contract (POST /api/v1/posts is
 *   text-only by design — the camera/microphone captured blobs were
 *   NEVER uploaded, they were a visual aid only).
 *
 *   The CameraCaptureDialog and VoiceRecordingDialog components remain in
 *   the project (`src/components/posts/camera-capture-dialog.tsx` and
 *   `src/components/posts/voice-recording-dialog.tsx`) so they can be
 *   re-imported here or used by other composers in the future. Nothing
 *   backend was deleted.
 *
 * UX:
 *   - Collapsed state: shows just the avatar + "What's happening?" prompt.
 *   - On focus/click: expands into a full composer with textarea + counter
 *     + Post button.
 *   - On submit success: dispatches `post:created` window event (so any
 *     subscribed feed prepends the new post), clears the textarea, blurs
 *     to collapse back to the prompt.
 *   - On submit failure: keeps the text (so the user can retry), shows
 *     a toast error, and does NOT collapse.
 *
 * Security:
 *   - POST_MAX_LENGTH re-validated server-side. Client counter is UX only.
 *   - authorId is NEVER sent in the body — server derives it from the session.
 *   - Textarea content is React-escaped by default — no XSS surface.
 */

export function HomeComposer() {
  const [content, setContent] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const user = useAuthStore((s) => s.user);
  const { t } = useTranslation();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Focus the textarea when expanding.
  useEffect(() => {
    if (expanded) {
      const id = setTimeout(() => textareaRef.current?.focus(), 30);
      return () => clearTimeout(id);
    }
  }, [expanded]);

  // Use Array.from so emoji and astral characters count as 1.
  const charCount = Array.from(content).length;
  const overLimit = charCount > POST_MAX_LENGTH;
  const isEmpty = content.trim().length === 0;
  const canSubmit = !isEmpty && !overLimit && !submitting;

  async function submit() {
    if (!canSubmit) return;
    setSubmitting(true);
    try {
      // The API returns the freshly-created post (with the author hydrated).
      // We dispatch a window event so the Home feed + Profile screen can
      // prepend it without a full re-fetch.
      //
      // The post API is text-only by design ("Phase 1 — text only, no
      // media" per the route comment in src/app/api/v1/posts/route.ts).
      // Only `content` is sent to /api/v1/posts — no media field is added.
      const data = await api.post<{ post: PostDTO }>("/api/v1/posts", { content });
      toast.success(t("posts.created") || "Post created");
      if (data?.post) {
        window.dispatchEvent(new CustomEvent("post:created", { detail: data.post }));
      }
      // Clear + collapse on success.
      setContent("");
      setExpanded(false);
    } catch (e) {
      // IMPORTANT: do NOT clear the text on failure — the user should be
      // able to retry without retyping. The toast tells them what went wrong.
      const msg = e instanceof ApiClientError ? e.message : "Failed to create post";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    // Cmd/Ctrl+Enter to submit — standard shortcut in social apps.
    // This handler runs on ALL devices — it's a no-op on touch devices
    // (no key events fire). The visual hint is hidden via CSS capability
    // detection (see globals.css — `.composer-kbd-hint`).
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      void submit();
    }
    // Escape collapses without losing text (the user might want to come back).
    if (e.key === "Escape" && !submitting) {
      setExpanded(false);
      textareaRef.current?.blur();
    }
  }

  // Collapsed view — a single clickable row.
  if (!expanded) {
    return (
      <div
        className="border-b px-4 py-3 md:px-6"
      >
        <button
          onClick={() => setExpanded(true)}
          className="flex w-full items-center gap-3 text-left"
          aria-label={t("posts.compose") || "New post"}
        >
          <Avatar
            name={user?.fullName ?? "?"}
            color={user?.avatarColor}
            src={user?.avatarUrl}
            size="sm"
            className="shrink-0"
          />
          <span className="flex-1 truncate text-sm text-muted-foreground">
            {t("posts.placeholder") || "What's happening?"}
          </span>
          <span
            className="hidden shrink-0 items-center gap-1 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground sm:flex"
          >
            <PenSquare className="h-3.5 w-3.5" />
            {t("posts.compose") || "New post"}
          </span>
        </button>
      </div>
    );
  }

  // Expanded view — full composer.
  return (
    <div className="border-b px-4 py-3 md:px-6" data-expanded="true">
      <div className="flex items-start gap-3">
        <Avatar
          name={user?.fullName ?? "?"}
          color={user?.avatarColor}
          src={user?.avatarUrl}
          size="sm"
          className="mt-0.5 shrink-0"
        />
        <div className="min-w-0 flex-1">
          <Textarea
            ref={textareaRef}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder={t("posts.placeholder") || "What's happening?"}
            maxLength={POST_MAX_LENGTH * 4}
            rows={3}
            className="min-h-[80px] resize-none border-0 px-0 shadow-none focus-visible:ring-0 text-base"
            aria-label="Post content"
            disabled={submitting}
          />

          <div className="flex items-center justify-between gap-2 border-t pt-2">
            {/* Left side: desktop-only keyboard shortcut hint. The hint uses
                the `composer-kbd-hint` class which is hidden on touch devices
                via CSS capability detection (pointer: coarse + hover: none).
                The existing Tailwind `hidden sm:block` (screen-size based) is
                layered on top for the small-screen case.

                PHASE 1 UI CHANGE: the Camera + Microphone icon buttons that
                used to live here have been removed from this composer. The
                post composer in the home feed is now text-only — matching
                the underlying text-only post API. The CameraCaptureDialog
                and VoiceRecordingDialog components remain in the project so
                they can be re-imported here if needed in the future. */}
            <div className="flex min-w-0 items-center gap-1">
              {/* Desktop-only keyboard shortcut hint. Hidden on:
                  - Small screens (< 640px) via Tailwind `hidden sm:block`.
                  - Touch devices via CSS `.composer-kbd-hint` (pointer: coarse
                    or hover: none — see globals.css). */}
              <p className="composer-kbd-hint hidden text-xs text-muted-foreground sm:ml-2 sm:block">
                {t("posts.hint") || "Press Cmd/Ctrl+Enter to post"}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span
                className={cn(
                  "text-xs tabular-nums",
                  overLimit
                    ? "font-semibold text-destructive"
                    : charCount > POST_MAX_LENGTH - 20
                      ? "text-amber-600 dark:text-amber-400"
                      : "text-muted-foreground"
                )}
                aria-live="polite"
              >
                {charCount}/{POST_MAX_LENGTH}
              </span>
              <Button
                onClick={submit}
                disabled={!canSubmit}
                size="sm"
              >
                {submitting ? (
                  <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                ) : null}
                {t("posts.submit") || "Post"}
              </Button>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}

