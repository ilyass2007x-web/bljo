"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Camera,
  CameraOff,
  RefreshCw,
  Check,
  X,
  Loader2,
  AlertTriangle,
  ImageIcon,
} from "lucide-react";
import { useCameraCapture } from "@/hooks/use-camera-capture";
import { useTranslation } from "@/lib/client/i18n-store";
import { cn } from "@/lib/utils";

/**
 * CameraCaptureDialog — camera capture modal for the post composer.
 *
 * Lifecycle (per spec §2):
 *   1. Initial: "Use Camera" prompt.
 *   2. Requesting: "Requesting camera access..." spinner.
 *   3. Granted: live camera preview + Capture / Cancel buttons.
 *   4. Denied: friendly message explaining the user must enable the
 *      permission in browser settings + a "Use File Instead" fallback.
 *   5. Unsupported: graceful fallback to <input type="file" capture>.
 *
 * After capture: shows a preview of the captured photo with Retake /
 * Confirm buttons. On Confirm, the dialog closes + the onCapture callback
 * fires with the Blob + preview URL.
 *
 * The <video> element uses playsInline + autoPlay + muted — required for
 * iOS Safari to play inline without entering fullscreen. The capture
 * button is large + centered at the bottom of the preview so it's easy
 * to reach with one hand on mobile (spec §7).
 *
 * Cleanup: the useCameraCapture hook stops all camera tracks the moment
 * the dialog closes (we call stopCamera on unmount + on close). The
 * camera light turns off — no stream runs in the background.
 *
 * Accessibility (spec §8):
 *   - Every button has an aria-label.
 *   - The video element has an aria-label describing the live preview.
 *   - The status (requesting/granted/denied) is announced via aria-live.
 *   - All buttons are keyboard-accessible (Dialog from Radix handles
 *     focus trap + Escape to cancel).
 */

interface CameraCaptureDialogProps {
  open: boolean;
  onClose: () => void;
  /** Called when the user confirms a captured photo. */
  onCapture: (result: { blob: Blob; previewUrl: string }) => void;
}

export function CameraCaptureDialog({ open, onClose, onCapture }: CameraCaptureDialogProps) {
  const { t } = useTranslation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const {
    state,
    message,
    requestCamera,
    capturePhoto,
    stopCamera,
    isSupported,
  } = useCameraCapture();
  // The captured photo (preview URL + blob) shown in the "review" state.
  const [captured, setCaptured] = useState<{ blob: Blob; previewUrl: string } | null>(null);
  // Hidden file input for the "Use File Instead" fallback path.
  const fileInputRef = useRef<HTMLInputElement>(null);

  /**
   * When the dialog opens, reset to the idle state. When it closes,
   * stop the camera + clear the captured preview.
   *
   * The camera MUST stop on close (spec §2 + §12) — we don't want the
   * camera light staying on after the user dismisses the dialog.
   */
  useEffect(() => {
    if (open) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setCaptured(null);
    } else {
      stopCamera();
      setCaptured((prev) => {
        if (prev) URL.revokeObjectURL(prev.previewUrl);
        return null;
      });
    }
  }, [open, stopCamera]);

  /**
   * When the dialog opens AND the camera is supported AND we haven't
   * yet requested permission, automatically start the camera. The user
   * explicitly clicked the "Camera" button to open the dialog — that's
   * the explicit user action the spec requires before requesting
   * camera access.
   */
  useEffect(() => {
    if (open && isSupported && state === "idle" && !captured) {
      void requestCamera(videoRef.current);
    }
  }, [open, isSupported, state, captured, requestCamera]);

  // Cleanup on unmount — revoke the captured preview URL.
  useEffect(() => {
    return () => {
      if (captured) URL.revokeObjectURL(captured.previewUrl);
    };
  }, [captured]);

  const handleCapture = useCallback(async () => {
    const result = await capturePhoto(videoRef.current);
    if (result) {
      // Stop the camera as soon as the photo is captured (spec §2).
      stopCamera();
      // Revoke the previous captured preview (if any).
      setCaptured((prev) => {
        if (prev) URL.revokeObjectURL(prev.previewUrl);
        return result;
      });
    }
  }, [capturePhoto, stopCamera]);

  const handleRetake = useCallback(async () => {
    setCaptured((prev) => {
      if (prev) URL.revokeObjectURL(prev.previewUrl);
      return null;
    });
    // Re-request the camera.
    if (isSupported) {
      void requestCamera(videoRef.current);
    }
  }, [isSupported, requestCamera]);

  const handleConfirm = useCallback(() => {
    if (captured) {
      onCapture(captured);
      // Don't revoke the URL here — the caller owns it now.
      setCaptured(null);
    }
    onClose();
  }, [captured, onCapture, onClose]);

  const handleCancel = useCallback(() => {
    stopCamera();
    setCaptured((prev) => {
      if (prev) URL.revokeObjectURL(prev.previewUrl);
      return null;
    });
    onClose();
  }, [stopCamera, onClose]);

  // File-input fallback (used when camera is unsupported or denied).
  const handleFileSelected = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      // Validate it's an image (the input's accept attr also enforces this).
      if (!file.type.startsWith("image/")) return;
      const previewUrl = URL.createObjectURL(file);
      // Revoke any previous preview.
      setCaptured((prev) => {
        if (prev) URL.revokeObjectURL(prev.previewUrl);
        return { blob: file, previewUrl };
      });
      // Reset the input value so the user can pick the same file again.
      e.target.value = "";
    },
    []
  );

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) handleCancel();
      }}
    >
      <DialogContent
        className="sm:max-w-md"
        // Prevent closing mid-request (avoids a confusing half-open state).
        onPointerDownOutside={(e) => {
          if (state === "requesting") e.preventDefault();
        }}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            {t("camera.title") || "Take a Photo"}
          </DialogTitle>
          <DialogDescription>
            {captured
              ? t("camera.reviewDesc") || "Review your photo. Retake or use it."
              : t("camera.desc") || "Capture a photo with your device camera."}
          </DialogDescription>
        </DialogHeader>

        {/* ── Capture area ── */}
        <div className="space-y-3">
          {/* Captured photo review state */}
          {captured ? (
            <div className="overflow-hidden rounded-lg border bg-muted/30">
              <img
                src={captured.previewUrl}
                alt={t("camera.capturedAlt") || "Captured photo preview"}
                className="max-h-[60vh] w-full object-contain"
              />
            </div>
          ) : !isSupported ? (
            // Unsupported state — show fallback file picker
            <div className="flex flex-col items-center justify-center gap-3 rounded-lg border bg-muted/30 p-8 text-center">
              <CameraOff className="h-10 w-10 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">
                  {t("camera.unsupportedTitle") || "Camera not supported"}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {t("camera.unsupportedDesc") ||
                    "Your browser doesn't support camera capture. You can still upload a photo from your device."}
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
              >
                <ImageIcon className="mr-1 h-4 w-4" />
                {t("camera.useFile") || "Choose Photo"}
              </Button>
            </div>
          ) : state === "denied" ? (
            // Denied state — explain how to enable + offer file fallback
            <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-amber-500/30 bg-amber-500/5 p-8 text-center">
              <AlertTriangle className="h-10 w-10 text-amber-500" />
              <div>
                <p className="text-sm font-medium">
                  {t("camera.deniedTitle") || "Camera access blocked"}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {message ||
                    t("camera.deniedDesc") ||
                    "Camera access was blocked. Please allow camera access in your browser settings and try again."}
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
              >
                <ImageIcon className="mr-1 h-4 w-4" />
                {t("camera.useFile") || "Choose Photo"}
              </Button>
            </div>
          ) : state === "requesting" ? (
            // Requesting state — spinner + explanation
            <div className="flex flex-col items-center justify-center gap-3 rounded-lg border bg-muted/30 p-12 text-center">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                {t("camera.requesting") || "Requesting camera access..."}
              </p>
            </div>
          ) : state === "error" ? (
            // Error state — show the message + retry button
            <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-destructive/30 bg-destructive/5 p-8 text-center">
              <AlertTriangle className="h-10 w-10 text-destructive" />
              <p className="text-sm text-muted-foreground">
                {message || t("camera.error") || "Unable to access the camera."}
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
              >
                <ImageIcon className="mr-1 h-4 w-4" />
                {t("camera.useFile") || "Choose Photo"}
              </Button>
            </div>
          ) : (
            // Live camera preview (granted + idle states when supported)
            <div className="relative overflow-hidden rounded-lg border bg-black">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                aria-label={t("camera.livePreviewAlt") || "Live camera preview"}
                className={cn(
                  "h-auto max-h-[60vh] w-full bg-black object-contain",
                  state !== "granted" && "opacity-40"
                )}
              />
              {state === "idle" && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-xs text-muted-foreground">
                    {t("camera.starting") || "Starting camera..."}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Hidden file input for the fallback path. */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleFileSelected}
          className="hidden"
          aria-hidden="true"
          tabIndex={-1}
        />

        <DialogFooter className="flex-row items-center justify-between gap-2 sm:justify-between">
          <Button variant="ghost" size="sm" onClick={handleCancel}>
            <X className="mr-1 h-4 w-4" />
            {t("camera.cancel") || "Cancel"}
          </Button>
          {captured ? (
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleRetake}>
                <RefreshCw className="mr-1 h-4 w-4" />
                {t("camera.retake") || "Retake"}
              </Button>
              <Button size="sm" onClick={handleConfirm}>
                <Check className="mr-1 h-4 w-4" />
                {t("camera.usePhoto") || "Use Photo"}
              </Button>
            </div>
          ) : (
            isSupported &&
            state === "granted" && (
              <Button size="sm" onClick={handleCapture} aria-label={t("camera.capture") || "Capture photo"}>
                <Camera className="mr-1 h-4 w-4" />
                {t("camera.capture") || "Capture"}
              </Button>
            )
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
