"use client";

import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/shared/avatar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Loader2, PenSquare } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { PostDTO } from "@/components/posts/post-card";
// Phase 2.2 — Topics: inline topic selector for post assignment.
import { TopicSelector } from "@/components/topics/topic-selector";

/**
 * Character limit — must match the server-side limit in
 * src/lib/posts/parser.ts. Imported here for client-side counter parity.
 */
const POST_MAX_LENGTH = 280;

/**
 * PostComposer — a modal dialog for creating a short text post.
 *
 * Phase 1: text only. Supports URLs, @mentions, and #hashtags in the text
 * (extracted by the parser, NOT rendered as HTML by this component).
 *
 * UX:
 *   - Trigger button (PenSquare icon) rendered by the parent.
 *   - Modal opens with textarea focused, ready to type.
 *   - Live character counter "0/280" turns red when over the limit.
 *   - Submit disabled when empty or over the limit.
 *   - Submitting sends POST /api/v1/posts, shows a toast, and closes
 *     the modal on success.
 *   - All state is local — the parent just provides the trigger.
 *
 * Security:
 *   - Server-side validation is the source of truth (POST_MAX_LENGTH
 *     re-checked in src/lib/posts/parser.ts). The client counter is UX
 *     only — never trust it.
 *   - The textarea content is sent as JSON to /api/v1/posts via the api
 *     client, which uses credentials: 'include' so the session cookie
 *     authenticates the request. The authorId is NEVER sent — the
 *     server derives it from the session.
 *   - React escapes the textarea value by default — no XSS surface here.
 */
export function PostComposer({ trigger }: { trigger?: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [content, setContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  // Phase 2.2 — Topics: selected topic IDs for this post.
  // Reset to [] when the modal closes (same pattern as content reset below).
  const [topicIds, setTopicIds] = useState<string[]>([]);
  const user = useAuthStore((s) => s.user);
  const { t } = useTranslation();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Focus the textarea when the modal opens.
  useEffect(() => {
    if (open) {
      const id = setTimeout(() => textareaRef.current?.focus(), 50);
      return () => clearTimeout(id);
    }
  }, [open]);

  // Reset content + topicIds when closing (so reopening starts fresh).
  useEffect(() => {
    if (!open) {
      const id = setTimeout(() => {
        setContent("");
        setTopicIds([]);
      }, 200);
      return () => clearTimeout(id);
    }
  }, [open]);

  // Use Array.from so emoji and astral characters count as 1.
  const charCount = Array.from(content).length;
  const overLimit = charCount > POST_MAX_LENGTH;
  const isEmpty = content.trim().length === 0;
  const canSubmit = !isEmpty && !overLimit && !submitting;

  async function submit() {
    if (!canSubmit) return;
    setSubmitting(true);
    try {
      // The API returns the freshly-created post (with the author hydrated).
      // We dispatch a window event so the Profile screen can prepend it
      // to the list + bump the postsCount without a full re-fetch.
      const data = await api.post<{ post: PostDTO }>("/api/v1/posts", { content, topicIds });
      toast.success(t("posts.created") || "Post created");
      if (data?.post) {
        window.dispatchEvent(new CustomEvent("post:created", { detail: data.post }));
      }
      setOpen(false);
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to create post";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    // Cmd/Ctrl+Enter to submit — standard shortcut in social apps.
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      void submit();
    }
  }

  const defaultTrigger = (
    <Button variant="ghost" size="icon" title={t("posts.compose") || "New post"}>
      <PenSquare className="h-5 w-5" />
    </Button>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <div onClick={() => setOpen(true)}>{trigger ?? defaultTrigger}</div>
      <DialogContent
        className="sm:max-w-lg"
        // Prevent the dialog from closing mid-submit (avoids accidental
        // double-submits if the user clicks outside).
        onPointerDownOutside={(e) => {
          if (submitting) e.preventDefault();
        }}
        onEscapeKeyDown={(e) => {
          if (submitting) e.preventDefault();
        }}
      >
        <DialogHeader>
          <DialogTitle>{t("posts.compose") || "New post"}</DialogTitle>
          <DialogDescription>
            {t("posts.composeDesc") ||
              "Share a thought. URLs, @mentions, and #hashtags are supported."}
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-start gap-3 pt-2">
          <Avatar
            name={user?.fullName ?? "?"}
            color={user?.avatarColor}
            src={user?.avatarUrl}
            size="sm"
            className="mt-0.5"
          />
          <div className="flex-1 space-y-3">
            <Textarea
              ref={textareaRef}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onKeyDown={onKeyDown}
              placeholder={t("posts.placeholder") || "What's happening?"}
              maxLength={POST_MAX_LENGTH * 4}
              // Cap the visual height so the modal doesn't grow huge.
              className="min-h-[120px] resize-none border-0 px-0 shadow-none focus-visible:ring-0 text-base"
              aria-label="Post content"
              disabled={submitting}
            />
            {/* Phase 2.2 — Topics: inline topic selector. Compact — fits
                the post composer modal without breaking the layout. */}
            <TopicSelector
              value={topicIds}
              onChange={setTopicIds}
              max={5}
              label=""
              placeholder="Add topics (optional)"
              disabled={submitting}
            />
            <div className="flex items-center justify-between gap-2 border-t pt-3">
              {/* Desktop-only keyboard shortcut hint. Hidden on:
                  - Small screens (< 640px) via Tailwind `hidden sm:block`.
                  - Touch devices via CSS `.composer-kbd-hint` (pointer: coarse
                    or hover: none — see globals.css). The shortcut handler
                    above still runs (no-op on touch devices). */}
              <p className="composer-kbd-hint hidden text-xs text-muted-foreground sm:block">
                {t("posts.hint") || "Press Cmd/Ctrl+Enter to post"}
              </p>
              <div className="flex items-center gap-3">
                <span
                  className={cn(
                    "text-xs tabular-nums",
                    overLimit
                      ? "font-semibold text-destructive"
                      : charCount > POST_MAX_LENGTH - 20
                        ? "text-amber-600 dark:text-amber-400"
                        : "text-muted-foreground"
                  )}
                  aria-live="polite"
                >
                  {charCount}/{POST_MAX_LENGTH}
                </span>
                <Button
                  onClick={submit}
                  disabled={!canSubmit}
                  size="sm"
                >
                  {submitting ? (
                    <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                  ) : null}
                  {t("posts.submit") || "Post"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
