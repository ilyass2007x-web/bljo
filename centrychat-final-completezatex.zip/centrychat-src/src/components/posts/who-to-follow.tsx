"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { FollowButton } from "@/components/shared/follow-button";
import { Loader2 } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";

interface SuggestedUser {
  id: string;
  fullName: string;
  username: string;
  avatarColor: string | null;
  avatarUrl: string | null;
  isVerified: boolean;
  bio: string | null;
  followersCount: number;
  followingCount: number;
  isFollowing: boolean;
  isFollowedBy: boolean;
}

interface WhoToFollowProps {
  /**
   * Called after the user follows one of the suggested users — lets the
   * parent refresh the feed (the newly-followed user's posts should now
   * appear in the feed on the next page load or refresh).
   */
  onFollowed?: () => void;
}

/**
 * WhoToFollow — a small "suggestions" strip shown on the Home Feed.
 *
 * Renders 5 candidate users (returned by GET /api/v1/users/suggested) with:
 *   - Avatar (clickable → opens profile)
 *   - Display name + @username (clickable → opens profile)
 *   - FollowButton (Follow / Follow Back based on isFollowedBy)
 *
 * When the user follows someone from this list, that user is removed from
 * the local list (so the strip doesn't show already-followed users).
 *
 * Hidden when:
 *   - Loading fails (silent — the strip is optional, not critical)
 *   - The list is empty after fetching (no candidates available)
 *
 * Design: kept compact to fit in the feed column without breaking the
 * mobile-first layout. Uses the same Avatar + FollowButton components as
 * the rest of the app for visual consistency.
 */
export function WhoToFollow({ onFollowed }: WhoToFollowProps) {
  const router = useRouter();
  const { t } = useTranslation();
  const [users, setUsers] = useState<SuggestedUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    api
      .get<{ users: SuggestedUser[] }>("/api/v1/users/suggested")
      .then((data) => {
        if (!cancelled) setUsers(data.users);
      })
      .catch((e) => {
        // Silent failure — the suggestions strip is non-critical.
        // Log to console for debugging but don't surface to the user.
        if (e instanceof ApiClientError) {
          console.warn("Failed to load suggestions:", e.message);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  function openProfile(username: string) {
    router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
  }

  function handleFollowed(userId: string) {
    // Remove the followed user from the suggestions list so the strip
    // doesn't show them again. The parent can also refresh the feed.
    setUsers((prev) => prev.filter((u) => u.id !== userId));
    onFollowed?.();
  }

  // Don't render anything while loading or if the list is empty.
  if (loading) {
    return (
      <div className="border-b px-4 py-3 md:px-6">
        <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
          {t("posts.loadingSuggestions") || "Loading suggestions…"}
        </div>
      </div>
    );
  }

  if (users.length === 0) return null;

  return (
    <div className="border-b px-4 py-3 md:px-6">
      <h3 className="mb-2 text-xs font-semibold text-muted-foreground">
        {t("posts.whoToFollow") || "Who to follow"}
      </h3>
      <div className="space-y-1">
        {users.map((u) => (
          <div
            key={u.id}
            className="flex items-center gap-3 rounded-lg p-1.5 hover:bg-accent/50"
          >
            <Avatar
              name={u.fullName}
              color={u.avatarColor}
              src={u.avatarUrl}
              size="sm"
              className="shrink-0 cursor-pointer"
              onClick={() => openProfile(u.username)}
            />
            <div className="min-w-0 flex-1">
              <button
                onClick={() => openProfile(u.username)}
                className="flex min-w-0 items-center gap-1 text-sm font-medium hover:underline"
                dir="auto"
              >
                <span className="truncate">{u.fullName}</span>
                {u.isVerified && <VerifiedBadge size={12} />}
              </button>
              <p className="truncate text-xs text-muted-foreground">
                @{u.username}
              </p>
            </div>
            <FollowButton
              targetUserId={u.id}
              targetUsername={u.username}
              isFollowing={u.isFollowing}
              isFollowedBy={u.isFollowedBy}
              size="sm"
              showLabel={false}
              onStateChange={(state) => {
                if (state.isFollowing) handleFollowed(u.id);
              }}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
