"use client";

import { useCallback, useEffect, useState, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Loader2, MessageSquare } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { COMMENT_MAX_LENGTH } from "@/lib/posts/parser";
import type { PostDTO } from "@/components/posts/post-card";
import {
  CommentThread,
  type CommentDTO as ThreadCommentDTO,
} from "@/components/comments/comment-thread";

interface CommentsPageProps {
  postId?: string;
  postAuthorId?: string;
}

/**
 * CommentsPage — full-page Comments view for a single post.
 *
 * Uses the unified <CommentThread> component (shared with Articles) to
 * render each top-level comment WITH its nested replies, like buttons,
 * and reply composer. The DTO shape matches what the API returns
 * (including `parentCommentId`, `_count.likes`, `isLiked`, `replies`).
 *
 * Routing: /?view=comments&postId=<postId>
 *
 * Phase 1 — Likes/Views/Shares/Comments/Replies:
 *   - Top-level comments rendered via <CommentThread kind="post" />
 *   - Replies rendered INSIDE <CommentThread> (one level deep)
 *   - Like + Reply + Delete available on BOTH comments and replies
 *   - View/Hide replies toggle per comment
 *   - Optimistic UI: likes flip instantly, replies appear instantly
 *     after the API responds, deletes remove locally then sync.
 */
export function CommentsPage({ postId: postIdProp, postAuthorId: postAuthorIdProp }: CommentsPageProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const postId = postIdProp ?? searchParams.get("postId") ?? "";
  const { user } = useAuthStore();
  const { t, fmtRelative } = useTranslation();

  // ── Phase 2 — Deep-link target from URL ──────────────────────────────
  // When the user clicks a COMMENT / COMMENT_REPLY / COMMENT_LIKE /
  // REPLY_LIKE notification, the NotificationsPage navigates to:
  //   /?view=comments&postId=<postId>&commentId=<commentId>[&replyId=<replyId>]
  // We read these query params + use them to:
  //   1. Verify the target comment is loaded (fetch it directly if not).
  //   2. Pass highlight props to the matching CommentThread so it
  //      scrolls into view + pulses.
  const targetCommentId = searchParams.get("commentId");
  const targetReplyId = searchParams.get("replyId");

  const [post, setPost] = useState<PostDTO | null>(null);
  const [postAuthorId, setPostAuthorId] = useState(postAuthorIdProp ?? "");
  const [comments, setComments] = useState<ThreadCommentDTO[]>([]);
  const [commentCount, setCommentCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [draft, setDraft] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const cursorRef = useRef<string | null>(null);
  // Stage 3.2 — comment sorting state.
  const [sort, setSort] = useState<"top" | "newest" | "oldest">("newest");

  // Fetch the post + first page of comments.
  // Clears state from the previous post when `postId` changes — prevents
  // cross-post leakage (spec §12).
  const fetchInitial = useCallback(async () => {
    if (!postId) return;
    setPost(null);
    setPostAuthorId("");
    setComments([]);
    setCommentCount(0);
    setHasMore(false);
    cursorRef.current = null;
    setLoading(true);
    try {
      // Fetch the post (for the preview at the top).
      const postData = await api.get<{ post: PostDTO }>(`/api/v1/posts/${postId}`);
      setPost(postData.post);
      setPostAuthorId(postData.post.author.id);

      // Fetch the first page of comments. The API returns comments WITH
      // their nested replies + likeCount + isLiked — the CommentThread
      // component consumes this shape directly.
      const commentsData = await api.get<{
        comments: ThreadCommentDTO[];
        nextCursor: string | null;
        commentCount: number;
      }>(`/api/v1/posts/${postId}/comments?limit=20&sort=${sort}`);
      setComments(commentsData.comments);
      setCommentCount(commentsData.commentCount);
      cursorRef.current = commentsData.nextCursor;
      setHasMore(!!commentsData.nextCursor);

      // ── Phase 2 — Targeted comment fetch for deep-link ───────────────
      // If the URL has ?commentId=X, check if the target comment is in
      // the first page. If not, fetch it DIRECTLY (single findUnique —
      // avoids paging through 1000 comments just to reach #850, spec §25).
      // Then prepend it to the top of the list so it's visible.
      //
      // Special case: if ?replyId=Y is set (the user clicked a
      // COMMENT_REPLY or REPLY_LIKE notification), the target comment is
      // the REPLY's PARENT — we fetch the parent comment (which includes
      // all its replies, including the target reply) and prepend it.
      //
      // Errors (404 = comment deleted) are silently swallowed — the user
      // still sees the post + the rest of the comments normally (spec §17).
      const fetchTargetId = targetReplyId ?? targetCommentId;
      if (fetchTargetId) {
        // Check if it's already in the loaded set (either as a top-level
        // comment or as a reply inside one).
        const isAlreadyLoaded =
          commentsData.comments.some((c) => c.id === fetchTargetId) ||
          commentsData.comments.some((c) => c.replies.some((r) => r.id === fetchTargetId));
        if (!isAlreadyLoaded) {
          try {
            const targetData = await api.get<{ comment: ThreadCommentDTO }>(
              `/api/v1/post-comments/${fetchTargetId}`
            );
            // If we fetched by replyId, the API actually returns the
            // reply itself (which has parentCommentId set). We need to
            // fetch the PARENT instead so the reply renders inside it.
            let targetComment = targetData.comment;
            if (targetReplyId && targetComment.parentCommentId) {
              const parentData = await api.get<{ comment: ThreadCommentDTO }>(
                `/api/v1/post-comments/${targetComment.parentCommentId}`
              );
              targetComment = parentData.comment;
            }
            // Prepend the target comment to the top of the list (clearly
            // visible). Dedup in case it was loaded between our initial
            // fetch + this targeted fetch (race condition).
            setComments((prev) => {
              if (prev.some((c) => c.id === targetComment.id)) return prev;
              return [targetComment, ...prev];
            });
          } catch {
            // 404 = comment was deleted. Silently ignore — the user sees
            // the post + remaining comments normally (spec §17).
          }
        }
      }
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to load comments";
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  }, [postId, targetCommentId, targetReplyId, sort]);

  useEffect(() => {
    if (!postId) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void fetchInitial();
  }, [postId, fetchInitial]);

  const loadMore = useCallback(async () => {
    if (!hasMore || loadingMore || !cursorRef.current) return;
    setLoadingMore(true);
    try {
      const data = await api.get<{
        comments: ThreadCommentDTO[];
        nextCursor: string | null;
      }>(`/api/v1/posts/${postId}/comments?limit=20&cursor=${encodeURIComponent(cursorRef.current)}&sort=${sort}`);
      setComments((prev) => [...prev, ...data.comments]);
      cursorRef.current = data.nextCursor;
      setHasMore(!!data.nextCursor);
    } catch {
      setHasMore(false);
    } finally {
      setLoadingMore(false);
    }
  }, [hasMore, loadingMore, postId, sort]);

  async function submit() {
    const trimmed = draft.trim();
    if (!trimmed || submitting) return;
    setSubmitting(true);
    try {
      const data = await api.post<{ comment: ThreadCommentDTO }>(
        `/api/v1/posts/${postId}/comments`,
        { content: trimmed }
      );
      // Newest-first → prepend to top.
      setComments((prev) => [data.comment, ...prev]);
      setCommentCount((c) => c + 1);
      setDraft("");
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to post comment";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      void submit();
    }
  }

  // ── Phase 2 — Clear the highlight URL params after the pulse finishes ─
  // Called by CommentThread's onHighlightDone callback. We use
  // router.replace (not push) so the highlight params don't pollute the
  // browser history — pressing Back goes to the previous page, not to
  // a stale "highlighted" URL that would re-trigger the pulse.
  const handleHighlightDone = useCallback(() => {
    if (!targetCommentId && !targetReplyId) return;
    const params = new URLSearchParams(searchParams.toString());
    params.delete("commentId");
    params.delete("replyId");
    const qs = params.toString();
    router.replace(qs ? `/?${qs}` : "/", { scroll: false });
  }, [targetCommentId, targetReplyId, searchParams, router]);

  // When a top-level comment is deleted, remove it from the list + bump count.
  const handleCommentDeleted = useCallback((commentId: string) => {
    setComments((prev) => prev.filter((c) => c.id !== commentId));
    setCommentCount((c) => Math.max(0, c - 1));
  }, []);

  function openProfile(username: string) {
    router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
  }

  const charCount = Array.from(draft).length;
  const overLimit = charCount > COMMENT_MAX_LENGTH;
  const isEmpty = draft.trim().length === 0;
  const canSubmit = !isEmpty && !overLimit && !submitting;

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile sticky header */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur md:hidden">
        <Button variant="ghost" size="icon" onClick={() => router.back()} title="Back">
          <ArrowLeft className="h-5 w-5 rtl-flip" />
        </Button>
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium">
            {t("posts.comments") || "Comments"}
          </p>
          <p className="truncate text-xs text-muted-foreground">
            {commentCount.toLocaleString()} {t("posts.comments") || "comments"}
          </p>
        </div>
      </header>

      <div className="mx-auto max-w-2xl">
        {/* Desktop header */}
        <div className="hidden items-center gap-3 border-b px-4 py-3 md:flex md:px-6">
          <Button variant="ghost" size="icon" onClick={() => router.back()} title="Back">
            <ArrowLeft className="h-5 w-5 rtl-flip" />
          </Button>
          <MessageSquare className="h-5 w-5 text-muted-foreground" />
          <h1 className="text-lg font-semibold">
            {t("posts.comments") || "Comments"}
          </h1>
          <span className="text-sm text-muted-foreground">
            · {commentCount.toLocaleString()}
          </span>
        </div>

        {/* Post preview — lightweight, no actions row */}
        {post && (
          <div className="border-b px-4 py-3 md:px-6">
            <div className="flex gap-3">
              <Avatar
                name={post.author.fullName}
                color={post.author.avatarColor}
                src={post.author.avatarUrl}
                size="sm"
                className="shrink-0 cursor-pointer"
                onClick={() => openProfile(post.author.username)}
              />
              <div className="min-w-0 flex-1">
                <button
                  onClick={() => openProfile(post.author.username)}
                  className="flex min-w-0 items-center gap-1 text-sm font-semibold hover:underline"
                  dir="auto"
                >
                  <span className="truncate">{post.author.fullName}</span>
                  {post.author.isVerified && <VerifiedBadge size={14} />}
                  <span className="truncate font-normal text-muted-foreground">
                    @{post.author.username}
                  </span>
                </button>
                <p
                  className="mt-1 whitespace-pre-wrap break-words text-sm leading-relaxed"
                  dir="auto"
                >
                  {post.content}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Composer */}
        <div className="border-b p-4 md:px-6">
          <div className="flex items-start gap-2">
            <Avatar
              name={user?.fullName ?? "?"}
              color={user?.avatarColor}
              src={user?.avatarUrl}
              size="sm"
              className="mt-0.5 shrink-0"
            />
            <div className="min-w-0 flex-1">
              <Textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={onKeyDown}
                placeholder={t("posts.commentPlaceholder") || "Write a comment…"}
                maxLength={COMMENT_MAX_LENGTH * 4}
                rows={2}
                className="min-h-[60px] resize-none text-sm"
                aria-label="Comment"
                disabled={submitting}
              />
              <div className="mt-1.5 flex items-center justify-between gap-2">
                <span
                  className={cn(
                    "text-xs tabular-nums",
                    overLimit
                      ? "font-semibold text-destructive"
                      : "text-muted-foreground"
                  )}
                  aria-live="polite"
                >
                  {charCount}/{COMMENT_MAX_LENGTH}
                </span>
                <Button onClick={submit} disabled={!canSubmit} size="sm">
                  {submitting && <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />}
                  {t("posts.postComment") || "Comment"}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Stage 3.2 — Comment sorting control */}
        {!loading && comments.length > 0 && (
          <div className="flex items-center gap-1 px-4 md:px-6 pb-2" role="tablist" aria-label="Comment sort">
            {(["top", "newest", "oldest"] as const).map((s) => (
              <button
                key={s}
                role="tab"
                aria-selected={sort === s}
                onClick={() => setSort(s)}
                className={cn(
                  "rounded-md px-2.5 py-1 text-xs font-medium transition-colors",
                  sort === s
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                )}
              >
                {s === "top" ? (t("posts.sortTop") || "Top") :
                 s === "newest" ? (t("posts.sortNewest") || "Newest") :
                 (t("posts.sortOldest") || "Oldest")}
              </button>
            ))}
          </div>
        )}

        {/* Comments list — newest first. Each comment is rendered via the
            unified <CommentThread> component which handles:
              - Like (optimistic, instant)
              - Reply (composer + post + view/hide replies)
              - Reply likes (optimistic, instant)
              - Delete (comment author OR post author OR admin) */}
        <div className="divide-y">
          {loading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex gap-3 p-4 md:px-6">
                <Skeleton className="h-8 w-8 shrink-0 rounded-full" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3 w-24" />
                  <Skeleton className="h-3 w-full" />
                  <Skeleton className="h-3 w-2/3" />
                </div>
              </div>
            ))
          ) : comments.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 px-4 py-16 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <MessageSquare className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium">
                {t("posts.noComments") || "No comments yet. Be the first to comment."}
              </p>
            </div>
          ) : (
            comments.map((c) => {
              // The current user can delete this comment if they are:
              //   - The comment's author, OR
              //   - The post's author (gives post owners moderation over
              //     their own content — spec §10), OR
              //   - An admin/super-admin.
              // The server independently enforces all of this.
              const canDelete =
                user?.id === c.author.id ||
                user?.id === postAuthorId ||
                user?.role === "ADMIN" ||
                user?.role === "SUPER_ADMIN";
              return (
                <CommentThread
                  key={c.id}
                  kind="post"
                  contentId={postId}
                  comment={c}
                  canDelete={canDelete}
                  onDeleted={handleCommentDeleted}
                  // Phase 2 — pass deep-link highlight props. The matching
                  // CommentThread scrolls itself into view + pulses.
                  highlightedCommentId={targetCommentId}
                  highlightedReplyId={targetReplyId}
                  onHighlightDone={handleHighlightDone}
                />
              );
            })
          )}
        </div>

        {/* Load More */}
        {hasMore && !loading && (
          <div className="flex items-center justify-center py-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={loadMore}
              disabled={loadingMore}
            >
              {loadingMore ? (
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
              ) : null}
              {loadingMore
                ? (t("posts.loadingMore") || "Loading…")
                : (t("posts.loadMore") || "Load more")}
            </Button>
          </div>
        )}

        {!loading && comments.length > 0 && !hasMore && (
          <div className="flex items-center justify-center py-6 text-center text-xs text-muted-foreground">
            {t("posts.endOfFeed") || "You're all caught up."}
          </div>
        )}
      </div>
    </div>
  );
}
