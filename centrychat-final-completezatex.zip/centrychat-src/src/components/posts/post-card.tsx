"use client";

import { useMemo, useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { FollowButton } from "@/components/shared/follow-button";
import { parsePostContent, POST_MAX_LENGTH } from "@/lib/posts/parser";
import { useTranslation } from "@/lib/client/i18n-store";
import { usePostView } from "@/lib/client/use-post-view";
import { useAuthStore } from "@/lib/client/auth-store";
import { PostActions } from "@/components/posts/post-actions";
import { Trash2, Pencil, Loader2, X, Check, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { api, ApiClientError } from "@/lib/client/api";
import { cn } from "@/lib/utils";
// Phase 2.2 — Topics: inline topic selector for post edit.
import { TopicSelector } from "@/components/topics/topic-selector";

/**
 * Public DTO shape returned by /api/v1/posts. Mirrors the server-side
 * POST_SELECT projection (no password hash, no email, no totp secret).
 *
 * Phase 3 additions: likeCount, commentCount, viewCount, isLiked. All
 * come from the server — the client never sends these values.
 */
export interface PostDTO {
  id: string;
  content: string;
  createdAt: string;
  updatedAt: string;
  author: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
    isFollowing: boolean;
    isFollowedBy: boolean;
  };
  likeCount: number;
  commentCount: number;
  viewCount: number;
  /** Total SHARE interaction count (type='SHARE' only — LINK_COPY not counted). */
  shareCount: number;
  isLiked: boolean;
  /**
   * Phase 2.2 — Topics: the topic IDs assigned to this post.
   * Empty array when the post has no topics. Always present (never undefined).
   */
  topicIds?: string[];
}

interface PostCardProps {
  post: PostDTO;
  canDelete?: boolean;
  onDeleted?: (postId: string) => void;
  onUpdated?: (post: PostDTO) => void;
  showAuthor?: boolean;
  actions?: React.ReactNode;
  /**
   * When true, the Follow button is NOT rendered next to the post author.
   * Used when PostCards are displayed inside the author's own Profile page —
   * the Profile header already has the main Follow control, so showing a
   * second Follow button on each post would be redundant.
   *
   * The Follow button remains visible in the Home Feed, Search results, and
   * any other context where it was previously intended. Only hidden when
   * viewing posts inside the author's Profile page.
   */
  hideFollow?: boolean;
}

/**
 * PostCard — renders a single text post.
 *
 * Renders the post content as a series of React nodes (text + safe <a>
 * links for URLs + clickable spans for @mentions + #hashtags). NO
 * dangerouslySetInnerHTML is used — the parser is pure and returns
 * offsets, then this component splits the string and renders each piece
 * as a normal React child (which React escapes by default).
 *
 * Phase 4 additions:
 *   - Inline edit mode: clicking the pencil icon replaces the content
 *     area with a textarea. Save dispatches PATCH /api/v1/posts/:id.
 *   - On successful edit, dispatches `post:updated` window event so
 *     any subscribed feed (Home, Profile) can update its local copy
 *     of the post.
 *
 * Security:
 *  - URL scheme allow-list is enforced by the parser (only http/https
 *    and protocol-relative URLs are extracted; javascript:/data: are
 *    ignored).
 *  - Mention/hashtag tags are passed through React as plain text inside
 *    clickable spans, so any HTML-like input (e.g. `<script>`) is treated
 *    as text — never executed.
 *  - The "external" link opens with rel="noopener noreferrer" to prevent
 *    tab-nabbing.
 *  - Edit authorId is NEVER sent in the request body — server derives
 *    it from the session.
 */
export function PostCard({
  post,
  canDelete = false,
  onDeleted,
  onUpdated,
  showAuthor = true,
  actions,
  hideFollow = false,
}: PostCardProps) {
  const router = useRouter();
  const { t, fmtRelative } = useTranslation();
  const currentUser = useAuthStore((s) => s.user);
  const parsed = useMemo(() => parsePostContent(post.content), [post.content]);

  // Edit-mode state. Lives inside the card so multiple cards can be
  // edited independently.
  const [isEditing, setIsEditing] = useState(false);
  const [editDraft, setEditDraft] = useState(post.content);
  const [editSubmitting, setEditSubmitting] = useState(false);
  // Phase 2.2 — Topics: edit-mode topic IDs. Initialized from post.topicIds
  // when entering edit mode, sent in the PATCH body on save.
  const [editTopicIds, setEditTopicIds] = useState<string[]>([]);
  const editTextareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Sync the draft with the post content whenever the post changes
  // (e.g. after a server-driven update via post:updated event).
  useEffect(() => {
    if (!isEditing) setEditDraft(post.content);
  }, [post.content, isEditing]);

  // Phase 2.2 — Topics: sync edit topic IDs when not editing OR when
  // entering edit mode (initialize from the post's current topics).
  useEffect(() => {
    if (!isEditing) {
      setEditTopicIds(post.topicIds ?? []);
    }
  }, [post.topicIds, isEditing]);

  // Focus the textarea when entering edit mode.
  useEffect(() => {
    if (isEditing) {
      const id = setTimeout(() => {
        editTextareaRef.current?.focus();
        // Place cursor at the end.
        const len = editTextareaRef.current?.value.length ?? 0;
        editTextareaRef.current?.setSelectionRange(len, len);
      }, 30);
      return () => clearTimeout(id);
    }
  }, [isEditing]);

  // View tracking — fires POST /api/v1/posts/:id/views when this card is
  // visible in the viewport for at least 1.5 seconds. Deduped per browser
  // session via a module-level Set (see use-post-view.ts).
  // Pass authorId so the hook can skip self-views client-side (the server
  // also checks independently — defense-in-depth).
  const viewRef = usePostView(post.id, true, post.author.id);

  // Merge all entities into a single sorted list of "render segments".
  // Each segment is either plain text or a clickable token (URL / mention
  // / hashtag). Non-overlapping by construction (URL regex stops at
  // whitespace, mentions/hashtags are word-bounded).
  const segments = useMemo(() => {
    type Seg =
      | { kind: "text"; text: string }
      | { kind: "url"; text: string; href: string }
      | { kind: "mention"; text: string; username: string }
      | { kind: "hashtag"; text: string; tag: string };
    const out: Seg[] = [];
    let cursor = 0;
    const all = [
      ...parsed.urls.map((u) => ({ type: "url" as const, start: u.start, end: u.end, raw: u.raw, href: u.url })),
      ...parsed.mentions.map((m) => ({ type: "mention" as const, start: m.start, end: m.end, raw: m.raw, username: m.username })),
      ...parsed.hashtags.map((h) => ({ type: "hashtag" as const, start: h.start, end: h.end, raw: h.raw, tag: h.tag })),
    ].sort((a, b) => a.start - b.start);

    for (const tok of all) {
      if (tok.start > cursor) {
        out.push({ kind: "text", text: post.content.slice(cursor, tok.start) });
      }
      if (tok.type === "url") {
        out.push({ kind: "url", text: tok.raw, href: tok.href });
      } else if (tok.type === "mention") {
        out.push({ kind: "mention", text: tok.raw, username: tok.username });
      } else if (tok.type === "hashtag") {
        out.push({ kind: "hashtag", text: tok.raw, tag: tok.tag });
      }
      cursor = tok.end;
    }
    if (cursor < post.content.length) {
      out.push({ kind: "text", text: post.content.slice(cursor) });
    }
    return out;
  }, [parsed, post.content]);

  async function handleDelete() {
    try {
      await api.delete(`/api/v1/posts/${post.id}`);
      toast.success(t("posts.deleted") || "Post deleted");
      // Notify any subscribed screen (Home feed, Profile list) so they
      // can remove the post + decrement counts WITHOUT a full re-fetch.
      window.dispatchEvent(
        new CustomEvent("post:deleted", {
          detail: { id: post.id, authorId: post.author.id },
        })
      );
      onDeleted?.(post.id);
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to delete post";
      toast.error(msg);
    }
  }

  async function handleSaveEdit() {
    if (!canSubmitEdit) return;
    setEditSubmitting(true);
    try {
      // PATCH sends only { content }. authorId is never sent — server
      // derives it from the session and checks ownership.
      const data = await api.patch<{ post: PostDTO }>(
        `/api/v1/posts/${post.id}`,
        { content: editDraft, topicIds: editTopicIds }
      );
      toast.success(t("posts.updated") || "Post updated");
      // Notify any subscribed screen so they can replace the post in
      // their list with the updated copy.
      window.dispatchEvent(
        new CustomEvent("post:updated", { detail: data.post })
      );
      onUpdated?.(data.post);
      setIsEditing(false);
    } catch (e) {
      // Don't clear the draft on failure — let the user retry.
      const msg = e instanceof ApiClientError ? e.message : "Failed to update post";
      toast.error(msg);
    } finally {
      setEditSubmitting(false);
    }
  }

  function handleCancelEdit() {
    // Reset the draft to the server's current content and exit edit mode.
    setEditDraft(post.content);
    setIsEditing(false);
  }

  function onEditKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      void handleSaveEdit();
    }
    if (e.key === "Escape") {
      e.preventDefault();
      handleCancelEdit();
    }
  }

  // Edit-mode validation (UX only — server re-validates).
  const editCharCount = Array.from(editDraft).length;
  const editOverLimit = editCharCount > POST_MAX_LENGTH;
  const editIsEmpty = editDraft.trim().length === 0;
  const editUnchanged = editDraft === post.content;
  const canSubmitEdit =
    !editIsEmpty && !editOverLimit && !editUnchanged && !editSubmitting;

  function openAuthorProfile() {
    router.push(`/?view=profile&username=${encodeURIComponent(post.author.username)}`);
  }

  return (
    <article
      ref={viewRef as unknown as React.Ref<HTMLElement>}
      className="px-4 py-5 transition-colors hover:bg-accent/5 md:px-6"
      data-post-id={post.id}
    >
      <div className="flex gap-3">
        {showAuthor && (
          <Avatar
            name={post.author.fullName}
            color={post.author.avatarColor}
            src={post.author.avatarUrl}
            size="sm"
            className="mt-0.5 shrink-0"
            onClick={openAuthorProfile}
          />
        )}
        <div className="min-w-0 flex-1">
          {showAuthor && (
            <div className="flex items-start justify-between gap-2">
              {/* Left: name + @username + time
                  Uses flex-wrap so long display names wrap to the next
                  line instead of being truncated/clipped (spec §4 —
                  "Author name must not be cut off"). The @username uses
                  truncate (controlled truncation) since it's less
                  important than the display name. */}
              <div className="flex min-w-0 flex-wrap items-baseline gap-x-1.5 gap-y-0" dir="auto">
                <button
                  onClick={openAuthorProfile}
                  className="max-w-[70%] truncate text-[15px] font-bold hover:underline"
                >
                  {post.author.fullName}
                </button>
                {post.author.isVerified && <VerifiedBadge size={14} />}
                <span className="truncate text-sm font-normal text-muted-foreground">
                  @{post.author.username}
                </span>
                <span className="text-muted-foreground">·</span>
                <time
                  className="shrink-0 text-xs text-muted-foreground"
                  dateTime={post.createdAt}
                  title={new Date(post.createdAt).toLocaleString()}
                >
                  {fmtRelative(post.createdAt)}
                </time>
                {new Date(post.updatedAt).getTime() - new Date(post.createdAt).getTime() > 1000 && (
                  <span
                    className="text-xs text-muted-foreground"
                    title={t("posts.editedTooltip") || `Edited ${new Date(post.updatedAt).toLocaleString()}`}
                  >
                    · {t("posts.edited") || "edited"}
                  </span>
                )}
              </div>

              {/* Right: Follow button OR Edit/Delete */}
              <div className="flex shrink-0 items-center gap-1">
                {/* Follow button — hidden when:
                    - hideFollow is true (Profile page context — the Profile
                      header already has the main Follow control)
                    - canDelete is true (own post — show Edit/Delete instead)
                    - isEditing is true (post is in edit mode)
                    - currentUser is the post author (self-post) */}
                {!hideFollow && !canDelete && !isEditing && currentUser?.id && post.author.id !== currentUser.id && (
                  <FollowButton
                    targetUserId={post.author.id}
                    targetUsername={post.author.username}
                    isFollowing={post.author.isFollowing}
                    isFollowedBy={post.author.isFollowedBy}
                    size="sm"
                    showLabel={true}
                    className="h-8 px-3 text-xs"
                  />
                )}

                {canDelete && !isEditing && (
                  <>
                    {/* Insights button — owner only (canDelete implies ownership).
                        Opens the Post Insights analytics page. */}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0 text-muted-foreground hover:text-primary"
                      onClick={() => router.push(`/?view=post-insights&postId=${post.id}`)}
                      aria-label="Insights"
                      title="Post Insights"
                    >
                      <BarChart3 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0 text-muted-foreground hover:text-foreground"
                      onClick={() => setIsEditing(true)}
                      aria-label={t("posts.edit") || "Edit post"}
                      title={t("posts.edit") || "Edit post"}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
                          aria-label={t("posts.delete") || "Delete post"}
                          title={t("posts.delete") || "Delete post"}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            {t("posts.deleteConfirmTitle") || "Delete this post?"}
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            {t("posts.deleteConfirmDesc") ||
                              "This post will be permanently deleted. This action cannot be undone."}
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>{t("common.cancel") || "Cancel"}</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={handleDelete}
                            className={cn(
                              "bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            )}
                          >
                            {t("posts.delete") || "Delete"}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Content area — switches between view mode (segments) and edit mode (textarea). */}
          {isEditing ? (
            <div className="mt-1 space-y-2">
              <Textarea
                ref={editTextareaRef}
                value={editDraft}
                onChange={(e) => setEditDraft(e.target.value)}
                onKeyDown={onEditKeyDown}
                maxLength={POST_MAX_LENGTH * 4}
                rows={3}
                className="min-h-[80px] resize-none text-sm"
                aria-label={t("posts.editAriaLabel") || "Edit post content"}
                disabled={editSubmitting}
              />
              {/* Phase 2.2 — Topics: inline topic selector in edit mode. */}
              <TopicSelector
                value={editTopicIds}
                onChange={setEditTopicIds}
                max={5}
                label=""
                placeholder="Add topics (optional)"
                disabled={editSubmitting}
              />
              <div className="flex items-center justify-between gap-2">
                <span
                  className={cn(
                    "text-xs tabular-nums",
                    editOverLimit
                      ? "font-semibold text-destructive"
                      : editCharCount > POST_MAX_LENGTH - 20
                        ? "text-amber-600 dark:text-amber-400"
                        : "text-muted-foreground"
                  )}
                  aria-live="polite"
                >
                  {editCharCount}/{POST_MAX_LENGTH}
                </span>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCancelEdit}
                    disabled={editSubmitting}
                  >
                    <X className="mr-1 h-3.5 w-3.5" />
                    {t("common.cancel") || "Cancel"}
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleSaveEdit}
                    disabled={!canSubmitEdit}
                  >
                    {editSubmitting ? (
                      <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Check className="mr-1 h-3.5 w-3.5" />
                    )}
                    {t("posts.save") || "Save"}
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="mt-2 whitespace-pre-wrap break-words text-[15px] leading-[1.6] text-foreground" dir="auto">
              {segments.map((seg, i) => {
                if (seg.kind === "text") return <span key={i}>{seg.text}</span>;
                if (seg.kind === "url") {
                  return (
                    <a
                      key={i}
                      href={seg.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline break-all"
                    >
                      {seg.text}
                    </a>
                  );
                }
                if (seg.kind === "mention") {
                  return (
                    <button
                      key={i}
                      onClick={() =>
                        router.push(`/?view=profile&username=${encodeURIComponent(seg.username)}`)
                      }
                      className="text-primary hover:underline"
                    >
                      {seg.text}
                    </button>
                  );
                }
                // hashtag — clickable in the future (no hashtag page yet),
                // so render as colored text for now.
                return (
                  <span key={i} className="text-primary">
                    {seg.text}
                  </span>
                );
              })}
            </div>
          )}

          {/* Actions slot — separated by light border + spacing.
              Full-bleed via negative margins so the action buttons align
              with the post edges (spec §18: light separators). */}
          {!isEditing && (
            <div className="mt-3 -ml-1 border-t border-border/40 pt-1">
              {actions !== undefined ? actions : <PostActions post={post} />}
            </div>
          )}
        </div>
      </div>
    </article>
  );
}
