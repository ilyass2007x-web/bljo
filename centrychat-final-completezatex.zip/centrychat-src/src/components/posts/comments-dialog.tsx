"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Loader2, Trash2, ArrowDown } from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import { COMMENT_MAX_LENGTH } from "@/lib/posts/parser";

/**
 * Comment DTO — matches the server-side COMMENT_SELECT projection.
 */
export interface CommentDTO {
  id: string;
  postId: string;
  content: string;
  createdAt: string;
  updatedAt: string;
  author: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
}

interface CommentsDialogProps {
  postId: string;
  /** The post author's user id — needed so the dialog can show the delete
   *  button for BOTH the comment author AND the post author (per spec §10). */
  postAuthorId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Called when a comment is created — lets the parent bump the comment count. */
  onCommentAdded?: () => void;
  /** Called when a comment is deleted — lets the parent decrement the comment count. */
  onCommentDeleted?: () => void;
}

/**
 * CommentsDialog — modal showing all comments for a post + a composer.
 *
 * Phase 6 updates:
 *   - Sort order is now NEWEST FIRST (createdAt DESC) per spec §7.
 *     New comments are prepended to the top of the list (not appended).
 *   - "Load more" button is at the BOTTOM of the list — it fetches
 *     OLDER comments and appends them to the bottom.
 *   - Post author can delete any comment on their post (per spec §10).
 *     The delete button is shown if the current user is the comment's
 *     author OR the post's author. The server independently enforces
 *     this authorization.
 *   - No auto-scroll to bottom (irrelevant for newest-first; the user
 *     should stay at the top to see the newest comment immediately).
 *
 * Security:
 *   - Comment content is rendered as plain text via React (escaped by default).
 *     NO dangerouslySetInnerHTML.
 *   - authorId is NEVER sent in the request body — server derives it from
 *     the session.
 *   - Delete authorization is enforced server-side; the client-side check
 *     only controls whether the button is rendered.
 */
export function CommentsDialog({
  postId,
  postAuthorId,
  open,
  onOpenChange,
  onCommentAdded,
  onCommentDeleted,
}: CommentsDialogProps) {
  const router = useRouter();
  const { user } = useAuthStore();
  const { t, fmtRelative } = useTranslation();
  const [comments, setComments] = useState<CommentDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [draft, setDraft] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const cursorRef = useRef<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Reset + fetch the first page when the dialog opens.
  useEffect(() => {
    if (!open) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLoading(true);
    setComments([]);
    cursorRef.current = null;
    api
      .get<{ comments: CommentDTO[]; nextCursor: string | null; commentCount: number }>(
        `/api/v1/posts/${postId}/comments?limit=20`
      )
      .then((data) => {
        setComments(data.comments);
        cursorRef.current = data.nextCursor;
        setHasMore(!!data.nextCursor);
      })
      .catch((e) => {
        const msg = e instanceof ApiClientError ? e.message : "Failed to load comments";
        toast.error(msg);
      })
      .finally(() => setLoading(false));
  }, [open, postId]);

  // Focus the textarea when the dialog opens.
  useEffect(() => {
    if (open) {
      const id = setTimeout(() => textareaRef.current?.focus(), 100);
      return () => clearTimeout(id);
    }
  }, [open]);

  // Load MORE comments — these are OLDER than what we have, so they
  // get APPENDED to the bottom of the list (since we're newest-first).
  const loadMore = useCallback(async () => {
    if (!hasMore || loadingMore || !cursorRef.current) return;
    setLoadingMore(true);
    try {
      const data = await api.get<{ comments: CommentDTO[]; nextCursor: string | null }>(
        `/api/v1/posts/${postId}/comments?limit=20&cursor=${encodeURIComponent(cursorRef.current)}`
      );
      // Append older comments to the bottom (newest-first ordering).
      setComments((prev) => [...prev, ...data.comments]);
      cursorRef.current = data.nextCursor;
      setHasMore(!!data.nextCursor);
    } catch {
      setHasMore(false);
    } finally {
      setLoadingMore(false);
    }
  }, [hasMore, loadingMore, postId]);

  async function submit() {
    const trimmed = draft.trim();
    if (!trimmed || submitting) return;
    setSubmitting(true);
    try {
      const data = await api.post<{ comment: CommentDTO }>(
        `/api/v1/posts/${postId}/comments`,
        { content: trimmed }
      );
      // Newest-first ordering → prepend the new comment to the TOP.
      setComments((prev) => [data.comment, ...prev]);
      setDraft("");
      onCommentAdded?.();
      // Scroll to top so the new comment is visible.
      setTimeout(() => {
        scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
      }, 50);
    } catch (e) {
      // Don't clear the draft on failure — let the user retry.
      const msg = e instanceof ApiClientError ? e.message : "Failed to post comment";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      void submit();
    }
  }

  async function handleDelete(commentId: string) {
    setDeletingId(commentId);
    try {
      await api.delete(`/api/v1/comments/${commentId}`);
      setComments((prev) => prev.filter((c) => c.id !== commentId));
      onCommentDeleted?.();
      toast.success(t("posts.commentDeleted") || "Comment deleted");
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to delete comment";
      toast.error(msg);
    } finally {
      setDeletingId(null);
    }
  }

  function openProfile(username: string) {
    onOpenChange(false);
    router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
  }

  const charCount = Array.from(draft).length;
  const overLimit = charCount > COMMENT_MAX_LENGTH;
  const isEmpty = draft.trim().length === 0;
  const canSubmit = !isEmpty && !overLimit && !submitting;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg p-0">
        <DialogHeader className="border-b px-4 py-3">
          <DialogTitle className="text-base">
            {t("posts.comments") || "Comments"}
          </DialogTitle>
          <DialogDescription className="sr-only">
            {t("posts.commentsDesc") || "View and post comments on this post."}
          </DialogDescription>
        </DialogHeader>

        {/* Comments list — newest first. */}
        <div
          ref={scrollRef}
          className="max-h-[50vh] overflow-y-auto"
        >
          {/* Loading skeleton */}
          {loading ? (
            <div className="space-y-3 p-4">
              {[0, 1, 2].map((i) => (
                <div key={i} className="flex gap-3">
                  <Skeleton className="h-8 w-8 shrink-0 rounded-full" />
                  <div className="flex-1 space-y-1.5">
                    <Skeleton className="h-3 w-24" />
                    <Skeleton className="h-3 w-full" />
                    <Skeleton className="h-3 w-2/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : comments.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 px-4 py-12 text-center">
              <p className="text-sm text-muted-foreground">
                {t("posts.noComments") || "No comments yet. Be the first to comment."}
              </p>
            </div>
          ) : (
            <div className="divide-y">
              {comments.map((c) => {
                // Delete button is shown if the current user is the comment's
                // author OR the post's author (per spec §10). The server
                // independently enforces this authorization.
                const canDelete =
                  user?.id === c.author.id || user?.id === postAuthorId;
                return (
                  <div key={c.id} className="flex gap-3 px-4 py-3">
                    <Avatar
                      name={c.author.fullName}
                      color={c.author.avatarColor}
                      src={c.author.avatarUrl}
                      size="sm"
                      className="mt-0.5 shrink-0"
                      onClick={() => openProfile(c.author.username)}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => openProfile(c.author.username)}
                          className="flex min-w-0 items-center gap-1 text-xs font-semibold hover:underline"
                          dir="auto"
                        >
                          <span className="truncate">{c.author.fullName}</span>
                          {c.author.isVerified && <VerifiedBadge size={12} />}
                          <span className="truncate font-normal text-muted-foreground">
                            @{c.author.username}
                          </span>
                        </button>
                        <span className="text-muted-foreground">·</span>
                        <time
                          className="shrink-0 text-[10px] text-muted-foreground"
                          dateTime={c.createdAt}
                          title={new Date(c.createdAt).toLocaleString()}
                        >
                          {fmtRelative(c.createdAt)}
                        </time>
                        {/* Show "edited" indicator if the comment was edited. */}
                        {new Date(c.updatedAt).getTime() - new Date(c.createdAt).getTime() > 1000 && (
                          <span className="text-[10px] text-muted-foreground">
                            · {t("posts.edited") || "edited"}
                          </span>
                        )}
                      </div>
                      {/* Comment content — plain text via React (escaped by default).
                          whitespace-pre-wrap preserves newlines, break-words
                          prevents horizontal overflow on long URLs. */}
                      <p
                        className="mt-0.5 whitespace-pre-wrap break-words text-sm leading-relaxed"
                        dir="auto"
                      >
                        {c.content}
                      </p>
                    </div>
                    {canDelete && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 shrink-0 text-muted-foreground hover:text-destructive"
                            disabled={deletingId === c.id}
                            aria-label={t("posts.deleteComment") || "Delete comment"}
                            title={t("posts.deleteComment") || "Delete comment"}
                          >
                            {deletingId === c.id ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Trash2 className="h-3.5 w-3.5" />
                            )}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>
                              {t("posts.deleteCommentConfirmTitle") || "Delete this comment?"}
                            </AlertDialogTitle>
                            <AlertDialogDescription>
                              {t("posts.deleteCommentConfirmDesc") ||
                                "This comment will be permanently deleted. This action cannot be undone."}
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>
                              {t("common.cancel") || "Cancel"}
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(c.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              {t("posts.delete") || "Delete"}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* "Load more" button at the BOTTOM — fetches older comments
              (newest-first ordering means older comments go below). */}
          {hasMore && !loading && (
            <div className="flex justify-center border-t py-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={loadMore}
                disabled={loadingMore}
              >
                {loadingMore ? (
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                ) : (
                  <ArrowDown className="mr-1.5 h-3.5 w-3.5" />
                )}
                {loadingMore
                  ? (t("posts.loadingMore") || "Loading…")
                  : (t("posts.loadMore") || "Load more")}
              </Button>
            </div>
          )}
        </div>

        {/* Composer */}
        <div className="border-t p-3">
          <div className="flex items-start gap-2">
            <Avatar
              name={user?.fullName ?? "?"}
              color={user?.avatarColor}
              src={user?.avatarUrl}
              size="sm"
              className="mt-0.5 shrink-0"
            />
            <div className="min-w-0 flex-1">
              <Textarea
                ref={textareaRef}
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={onKeyDown}
                placeholder={t("posts.commentPlaceholder") || "Write a comment…"}
                maxLength={COMMENT_MAX_LENGTH * 4}
                rows={2}
                className="min-h-[60px] resize-none text-sm"
                aria-label="Comment"
                disabled={submitting}
              />
              <div className="mt-1.5 flex items-center justify-between gap-2">
                <span
                  className={cn(
                    "text-xs tabular-nums",
                    overLimit
                      ? "font-semibold text-destructive"
                      : "text-muted-foreground"
                  )}
                  aria-live="polite"
                >
                  {charCount}/{COMMENT_MAX_LENGTH}
                </span>
                <Button onClick={submit} disabled={!canSubmit} size="sm">
                  {submitting && <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />}
                  {t("posts.postComment") || "Comment"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
