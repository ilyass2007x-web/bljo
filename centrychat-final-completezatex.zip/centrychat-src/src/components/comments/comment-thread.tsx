"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Avatar } from "@/components/shared/avatar";
import { VerifiedBadge } from "@/components/shared/verified-badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Heart,
  Loader2,
  Trash2,
  CornerDownRight,
} from "lucide-react";
import { api, ApiClientError } from "@/lib/client/api";
import { useAuthStore } from "@/lib/client/auth-store";
import { useTranslation } from "@/lib/client/i18n-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { COMMENT_MAX_LENGTH } from "@/lib/posts/parser";

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Discriminated union for the parent content type. The CommentThread
 * component is GENERIC — it doesn't know whether it's rendering a post
 * comment or an article comment. The `kind` field tells it which API
 * endpoint to hit.
 *
 *   "post"    → /api/v1/posts/:id/comments + /api/v1/post-comments/:id/like
 *                                                        ^^^^^^^^^^^^^^
 *   "article" → /api/v1/articles/:id/comments + /api/v1/article-comments/:id/like
 *                                                            ^^^^^^^^^^^^^^^
 *
 * The shapes of the responses are IDENTICAL (the API mirrors), so a single
 * TypeScript interface works for both.
 */
export type CommentKind = "post" | "article";

/**
 * Author projection — shared by comments and replies.
 */
export interface CommentAuthor {
  id: string;
  fullName: string;
  username: string;
  avatarColor: string | null;
  avatarUrl: string | null;
  isVerified: boolean;
}

/**
 * A reply (one level deep — parentCommentId !== null). Same shape as a
 * top-level comment, minus the `replies` array (replies can't have replies).
 *
 * Phase 3.1 — Deep Discussions: `replies` is now OPTIONAL + recursive.
 * The API (Phase 3) returns nested `replies` arrays on ALL comments,
 * including replies to replies. This makes `ReplyDTO` recursive.
 */
export interface ReplyDTO {
  id: string;
  content: string;
  parentCommentId: string;
  createdAt: string;
  updatedAt: string;
  author: CommentAuthor;
  likeCount: number;
  isLiked: boolean;
  /** Phase 3.1 — nested replies (recursive). Empty/undefined when this reply has no replies. */
  replies?: ReplyDTO[];
}

/**
 * A top-level comment (parentCommentId === null). Includes nested replies
 * (oldest-first) and the comment's own likeCount + isLiked state.
 */
export interface CommentDTO {
  id: string;
  content: string;
  parentCommentId: string | null;
  createdAt: string;
  updatedAt: string;
  author: CommentAuthor;
  likeCount: number;
  isLiked: boolean;
  replies: ReplyDTO[];
}

// ─────────────────────────────────────────────────────────────────────────────
// Small format helper
// ─────────────────────────────────────────────────────────────────────────────

function formatCount(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000) {
    const v = n / 1000;
    return (v >= 100 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, "")) + "K";
  }
  const v = n / 1_000_000;
  return v.toFixed(1).replace(/\.0$/, "") + "M";
}

// ─────────────────────────────────────────────────────────────────────────────
// Phase 3.1 — Pure tree helper functions (no React, no side effects)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Recursively add a reply to the correct parent in a reply tree.
 * Returns a NEW tree (immutable update — safe for React state).
 */
function addReplyToTree(
  replies: ReplyDTO[],
  parentId: string,
  newReply: ReplyDTO
): ReplyDTO[] {
  return replies.map((r) => {
    if (r.id === parentId) {
      return { ...r, replies: [...(r.replies ?? []), newReply] };
    }
    if (r.replies && r.replies.length > 0) {
      return { ...r, replies: addReplyToTree(r.replies, parentId, newReply) };
    }
    return r;
  });
}

/**
 * Recursively remove a comment (by ID) from a reply tree.
 * Also removes any children of the removed comment (cascade — matches
 * the DB onDelete: Cascade behavior).
 */
function removeCommentFromTree(
  replies: ReplyDTO[],
  commentId: string
): ReplyDTO[] {
  return replies
    .filter((r) => r.id !== commentId)
    .map((r) => {
      if (r.replies && r.replies.length > 0) {
        return { ...r, replies: removeCommentFromTree(r.replies, commentId) };
      }
      return r;
    });
}

/**
 * Recursively update a comment's like state in the tree.
 */
function updateCommentInTree(
  replies: ReplyDTO[],
  commentId: string,
  updates: Partial<ReplyDTO>
): ReplyDTO[] {
  return replies.map((r) => {
    if (r.id === commentId) {
      return { ...r, ...updates };
    }
    if (r.replies && r.replies.length > 0) {
      return { ...r, replies: updateCommentInTree(r.replies, commentId, updates) };
    }
    return r;
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Phase 3.1 — Max visual indent constants
// ─────────────────────────────────────────────────────────────────────────────
// After this depth, the visual indent stops growing (prevents horizontal
// overflow on deep nesting). The data tree can go arbitrarily deep —
// only the VISUAL indent is capped.
const MAX_INDENT_DESKTOP = 5; // depth 0-5 get increasing indent, 6+ stays at 5
const MAX_INDENT_MOBILE = 3;  // depth 0-3 get increasing indent, 4+ stays at 3

/**
 * Compute the left-padding for a given comment depth.
 * Desktop: 24px per level, capped at MAX_INDENT_DESKTOP × 24px = 120px.
 * Mobile: 16px per level, capped at MAX_INDENT_MOBILE × 16px = 48px.
 */
function indentClass(depth: number): string {
  const cappedDesktop = Math.min(depth, MAX_INDENT_DESKTOP);
  const cappedMobile = Math.min(depth, MAX_INDENT_MOBILE);
  // Tailwind doesn't support dynamic class names, so we use inline style
  // for the padding values. The border-l provides the visual thread line.
  return `border-l border-border/60`;
}

function indentStyle(depth: number): React.CSSProperties {
  const cappedDesktop = Math.min(depth, MAX_INDENT_DESKTOP);
  const cappedMobile = Math.min(depth, MAX_INDENT_MOBILE);
  // Use CSS clamp for responsive padding without media query JS.
  // On mobile (< 640px), use the mobile indent. On desktop, use desktop indent.
  return {
    paddingLeft: `clamp(${cappedMobile * 12}px, ${cappedDesktop * 20}px, ${cappedDesktop * 24}px)`,
    marginLeft: `clamp(${cappedMobile * 4}px, ${cappedDesktop * 8}px, ${cappedDesktop * 12}px)`,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Props for the top-level CommentThread component
// ─────────────────────────────────────────────────────────────────────────────

interface CommentThreadProps {
  kind: CommentKind;
  /** The id of the parent content (postId or articleId). */
  contentId: string;
  /** The comment to render (top-level — parentCommentId === null). */
  comment: CommentDTO;
  /**
   * Called when the comment is deleted (parent removes it from the list
   * and decrements the comment count). Only fired for top-level comments
   * — reply deletions are handled internally.
   */
  onDeleted?: (commentId: string) => void;
  /**
   * Called when a reply is added to this comment. Parent may use it to
   * refresh counts, but the reply is also rendered locally so this is
   * purely informational.
   */
  onReplyAdded?: (parentId: string, reply: ReplyDTO) => void;
  /**
   * Whether the current user can delete this comment. Server-side auth
   * is the source of truth — this only controls whether the trash icon
   * is rendered. True when the current user is the comment's author OR
   * the parent content's author OR an admin.
   */
  canDelete: boolean;
  /**
   * Phase 2 — DEEP-LINK HIGHLIGHT:
   * When this comment's id matches `highlightedCommentId`, the comment
   * is scrolled into view + highlighted with a temporary background
   * pulse for ~2.5s. Used by the CommentsPage when the user clicks a
   * COMMENT / COMMENT_LIKE notification — the URL carries ?commentId=X
   * and the matching CommentThread highlights itself.
   */
  highlightedCommentId?: string | null;
  /**
   * Phase 2 — DEEP-LINK HIGHLIGHT for REPLIES:
   * When a reply inside THIS comment matches `highlightedReplyId`, the
   * replies list is FORCED EXPANDED (even if the user hadn't opened it)
   * and the matching reply is scrolled into view + highlighted.
   * Used when the user clicks a COMMENT_REPLY / REPLY_LIKE notification.
   *
   * Note: `highlightedCommentId` is checked separately for the parent
   * comment — both can be set simultaneously (the parent is highlighted
   * + the specific reply inside it is highlighted).
   */
  highlightedReplyId?: string | null;
  /**
   * Optional callback fired after the highlight animation completes.
   * The parent can use this to clear the URL query param so a refresh
   * doesn't re-trigger the highlight.
   */
  onHighlightDone?: () => void;
}

// ─────────────────────────────────────────────────────────────────────────────
// API path helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Build the API paths for a given content kind + id.
 *
 * The post and article comment systems mirror each other exactly — the
 * ONLY difference is the URL prefix. Centralizing the path construction
 * here keeps the component body clean and makes it trivial to add a new
 * content kind (e.g. "reel") later.
 */
function apiPaths(kind: CommentKind, contentId: string) {
  if (kind === "post") {
    return {
      createComment: `/api/v1/posts/${contentId}/comments`,
      deleteComment: (commentId: string) => `/api/v1/comments/${commentId}`,
      likeComment: (commentId: string) => `/api/v1/post-comments/${commentId}/like`,
    };
  }
  return {
    createComment: `/api/v1/articles/${contentId}/comments`,
    deleteComment: (commentId: string) => `/api/v1/article-comments/${commentId}`,
    likeComment: (commentId: string) => `/api/v1/article-comments/${commentId}/like`,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Top-level CommentThread component
// ─────────────────────────────────────────────────────────────────────────────

/**
 * CommentThread — renders a single top-level comment WITH its nested replies.
 *
 * This is the UNIFIED component used by BOTH the Post CommentsPage and the
 * Article CommentsPage. The `kind` prop discriminates which API to hit;
 * everything else (rendering, optimistic UI, like logic, reply logic,
 * view/hide replies toggle) is shared.
 *
 * Layout (spec §9):
 *   ┌─────────────────────────────────────────────────────────────────┐
 *   │ [Avatar] @Author · 5m                                           │
 *   │          Comment content here.                                  │
 *   │          ❤️ 12   Reply                                          │
 *   │          ↳ View 3 replies                                       │
 *   │            ┌───────────────────────────────────────────────┐    │
 *   │            │ [Avatar] @Sara · 2m                            │    │
 *   │            │          Reply content.                        │    │
 *   │            │          ❤️ 4   Reply                          │    │
 *   │            └───────────────────────────────────────────────┘    │
 *   │            ┌───────────────────────────────────────────────┐    │
 *   │            │ [Avatar] @Youssef · 1m                         │    │
 *   │            │          Another reply.                        │    │
 *   │            │          ❤️ 2   Reply                          │    │
 *   │            └───────────────────────────────────────────────┘    │
 *   │                                                                 │
 *   │          [Reply to @Author]                                     │
 *   │          [ Write a reply... ]                    [Send]         │
 *   └─────────────────────────────────────────────────────────────────┘
 *
 * Mobile + desktop responsive:
 *   - The replies list is indented with a left border (sm:pl-4 sm:ml-3
 *     sm:border-l). On mobile (<sm) the indent is reduced (pl-2 ml-2)
 *     so the reply content doesn't get cramped on narrow screens.
 *   - The reply composer textarea is full-width on mobile, comfortable
 *     max-w on desktop.
 *
 * Optimistic UI:
 *   - Like: instantly flips `isLiked` + bumps `likeCount` in local state.
 *     The API call fires in the background. On success, reconcile with
 *     the server's authoritative response. On failure, rollback + toast.
 *   - Reply: the new reply is appended to the replies list AFTER the API
 *     responds (we need the server-generated id + createdAt). The
 *     composer clears. On failure, toast + keep draft.
 *   - Delete: instantly removes the comment from the local state. The
 *     parent's onDeleted is called so it can decrement its count. On
 *     failure, toast + the comment reappears on next refresh.
 */
export function CommentThread({
  kind,
  contentId,
  comment: initialComment,
  onDeleted,
  onReplyAdded,
  canDelete,
  highlightedCommentId,
  highlightedReplyId,
  onHighlightDone,
}: CommentThreadProps) {
  const router = useRouter();
  const { t, fmtRelative } = useTranslation();
  const { user } = useAuthStore();
  const paths = apiPaths(kind, contentId);

  // ── Local state ──────────────────────────────────────────────────────
  // We keep the comment + replies in local state so we can update them
  // optimistically without re-fetching. The parent passes the initial
  // value via props; we own the mutations from there.
  const [comment, setComment] = useState<CommentDTO>(initialComment);

  // Sync from props when the parent re-fetches (e.g. after pagination).
  // We use a ref to track the comment id — if the parent passes a NEW
  // comment with the same id but different content (e.g. after a refresh),
  // we update. If the id changes (different comment entirely), we reset.
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setComment(initialComment);
  }, [initialComment]);

  // Reply composer state.
  const [replyDraft, setReplyDraft] = useState("");
  const [replySubmitting, setReplySubmitting] = useState(false);
  const [showReplyComposer, setShowReplyComposer] = useState(false);
  const replyTextareaRef = useRef<HTMLTextAreaElement | null>(null);

  // ── Phase 2 — Deep-link highlight state ──────────────────────────────
  // The parent passes `highlightedCommentId` + `highlightedReplyId` (from
  // the URL's ?commentId=&replyId= query params, set by the NotificationsPage
  // when the user clicks a COMMENT/COMMENT_REPLY/COMMENT_LIKE/REPLY_LIKE
  // notification).
  //
  // This comment is the highlight target when:
  //   - highlightedCommentId === this comment's id (the user clicked a
  //     COMMENT or COMMENT_LIKE notification pointing at this comment).
  //   - highlightedReplyId is set AND one of this comment's replies
  //     matches it (the user clicked a COMMENT_REPLY or REPLY_LIKE
  //     notification — we need to expand this comment's replies + scroll
  //     to the specific reply).
  const isThisCommentHighlighted = !!highlightedCommentId && highlightedCommentId === comment.id;
  const hasHighlightedReply = !!highlightedReplyId &&
    comment.replies.some((r) => r.id === highlightedReplyId);

  // The root element ref — used to scrollIntoView() when this comment
  // (or a reply inside it) is the highlight target.
  const rootRef = useRef<HTMLDivElement | null>(null);

  // View/hide replies toggle. Default: SHOW replies if there are any
  // (spec §9 — the user clicked "Reply" / "View replies" to see them,
  // so they should be visible by default when the comments page loads).
  //
  // Phase 2: when a reply inside this comment is the highlight target,
  // we FORCE-expand the replies (even if the user had collapsed them)
  // so the highlighted reply is visible.
  const [repliesExpanded, setRepliesExpanded] = useState(
    initialComment.replies.length > 0
  );

  // Force-expand when a highlighted reply is inside this comment.
  useEffect(() => {
    if (hasHighlightedReply && !repliesExpanded) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setRepliesExpanded(true);
    }
  }, [hasHighlightedReply, repliesExpanded]);

  // Scroll into view + fire onHighlightDone after the highlight pulse.
  // Runs ONCE per (commentId, replyId) target — the onHighlightDone
  // callback lets the parent clear the URL query param so a refresh
  // doesn't re-trigger the highlight.
  const highlightTriggeredRef = useRef<string | null>(null);
  useEffect(() => {
    // Build a key that uniquely identifies this highlight request.
    // When the key changes, we re-run the highlight. When it stays the
    // same, we skip (prevents re-triggering on every re-render).
    const targetKey = isThisCommentHighlighted
      ? `comment:${comment.id}`
      : hasHighlightedReply
      ? `reply:${highlightedReplyId}`
      : null;

    if (!targetKey) return;
    if (highlightTriggeredRef.current === targetKey) return;
    highlightTriggeredRef.current = targetKey;

    // Defer the scroll until after the DOM has painted (especially
    // important for replies — the replies list needs to render first).
    const t = setTimeout(() => {
      rootRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }, 100);

    // Clear the highlight after ~3s (the CSS pulse animation lasts ~2.5s).
    // The parent clears its URL query param + state, which causes this
    // component to re-render without the highlight props — the visual
    // highlight disappears.
    const done = setTimeout(() => {
      onHighlightDone?.();
    }, 3000);

    return () => {
      clearTimeout(t);
      clearTimeout(done);
    };
  }, [isThisCommentHighlighted, hasHighlightedReply, highlightedReplyId, comment.id, onHighlightDone]);

  // Like in-flight state (per comment, not per reply — replies have
  // their own state inside ReplyItem).
  const [likeLoading, setLikeLoading] = useState(false);

  // Delete in-flight state.
  const [deleting, setDeleting] = useState(false);

  // ── Like handler — optimistic toggle ─────────────────────────────────
  const toggleLike = useCallback(async () => {
    if (likeLoading) return;
    if (!user) {
      toast.info(t("auth.signInToLike") || "Sign in to like this comment");
      router.push("/");
      return;
    }

    const wasLiked = comment.isLiked;
    const prevCount = comment.likeCount;

    // Optimistic flip.
    setComment((c) => ({
      ...c,
      isLiked: !wasLiked,
      likeCount: prevCount + (wasLiked ? -1 : 1),
    }));
    setLikeLoading(true);

    try {
      const data = await api.post<{ liked: boolean; likeCount: number }>(
        paths.likeComment(comment.id)
      );
      // Reconcile with server's authoritative response.
      setComment((c) => ({
        ...c,
        isLiked: data.liked,
        likeCount: data.likeCount,
      }));
    } catch (e) {
      // Rollback.
      setComment((c) => ({
        ...c,
        isLiked: wasLiked,
        likeCount: prevCount,
      }));
      const msg = e instanceof ApiClientError ? e.message : "Failed to toggle like";
      toast.error(msg);
    } finally {
      setLikeLoading(false);
    }
  }, [comment.id, comment.isLiked, comment.likeCount, likeLoading, user, router, t, paths]);

  // ── Reply submit handler ─────────────────────────────────────────────
  const submitReply = useCallback(async () => {
    const trimmed = replyDraft.trim();
    if (!trimmed || replySubmitting) return;
    if (!user) {
      toast.info(t("auth.signInToComment") || "Sign in to reply");
      router.push("/");
      return;
    }

    setReplySubmitting(true);
    try {
      const data = await api.post<{ comment: CommentDTO }>(
        paths.createComment,
        {
          content: trimmed,
          parentCommentId: comment.id,
        }
      );
      // The server returns the new reply as a CommentDTO (with replies: []).
      // We project it to ReplyDTO shape for our local state.
      const newReply: ReplyDTO = {
        id: data.comment.id,
        content: data.comment.content,
        parentCommentId: comment.id,
        createdAt: data.comment.createdAt,
        updatedAt: data.comment.updatedAt,
        author: data.comment.author,
        likeCount: data.comment.likeCount,
        isLiked: data.comment.isLiked,
      };

      // Replies are oldest-first per spec §9 — the new reply is the
      // newest, so it goes at the BOTTOM (append, not prepend).
      setComment((c) => ({
        ...c,
        replies: [...c.replies, newReply],
      }));

      setReplyDraft("");
      setShowReplyComposer(false);
      setRepliesExpanded(true); // make sure the new reply is visible
      onReplyAdded?.(comment.id, newReply);
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to post reply";
      toast.error(msg);
    } finally {
      setReplySubmitting(false);
    }
  }, [replyDraft, replySubmitting, user, router, t, comment.id, paths, onReplyAdded]);

  // ── Reply deletion handler (called by ReplyItem) ─────────────────────
  // Phase 3.1 — uses recursive removeCommentFromTree so it works at ANY depth.
  const handleReplyDeleted = useCallback((replyId: string) => {
    setComment((c) => ({
      ...c,
      replies: removeCommentFromTree(c.replies, replyId),
    }));
  }, []);

  // ── Reply like update (called by ReplyItem after a successful like) ──
  // Phase 3.1 — uses recursive updateCommentInTree for any depth.
  const handleReplyLikeUpdate = useCallback(
    (replyId: string, liked: boolean, likeCount: number) => {
      setComment((c) => ({
        ...c,
        replies: updateCommentInTree(c.replies, replyId, { isLiked: liked, likeCount }),
      }));
    },
    []
  );

  // ── Top-level delete handler ─────────────────────────────────────────
  const handleDelete = useCallback(async () => {
    setDeleting(true);
    try {
      await api.delete(paths.deleteComment(comment.id));
      onDeleted?.(comment.id);
      toast.success(t("posts.commentDeleted") || "Comment deleted");
    } catch (e) {
      const msg = e instanceof ApiClientError ? e.message : "Failed to delete comment";
      toast.error(msg);
    } finally {
      setDeleting(false);
    }
  }, [comment.id, paths, onDeleted, t]);

  // ── Reply composer keyboard handler ──────────────────────────────────
  function onReplyKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      void submitReply();
    }
    if (e.key === "Escape") {
      e.preventDefault();
      setShowReplyComposer(false);
      setReplyDraft("");
    }
  }

  // Focus the reply textarea when the composer opens.
  useEffect(() => {
    if (showReplyComposer) {
      const id = setTimeout(() => replyTextareaRef.current?.focus(), 50);
      return () => clearTimeout(id);
    }
  }, [showReplyComposer]);

  function openProfile(username: string) {
    router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
  }

  const replyCharCount = Array.from(replyDraft).length;
  const replyOverLimit = replyCharCount > COMMENT_MAX_LENGTH;
  const replyCanSubmit = !replyDraft.trim().length ? false : !replyOverLimit && !replySubmitting;
  const replyCount = comment.replies.length;

  const edited =
    new Date(comment.updatedAt).getTime() - new Date(comment.createdAt).getTime() > 1000;

  return (
    <div
      ref={rootRef}
      className={cn(
        "flex gap-3 px-4 py-3 transition-colors md:px-6",
        // Phase 2 — deep-link highlight: when this comment is the target
        // (or a reply inside it is the target), apply a temporary
        // background pulse so the user's eye is drawn to it. The pulse
        // is removed after ~2.5s by the parent clearing the highlight
        // state (which clears these props → re-render without the class).
        (isThisCommentHighlighted || hasHighlightedReply) &&
          "bg-amber-100/60 dark:bg-amber-900/20 animate-pulse-highlight rounded-lg -mx-2"
      )}
      data-comment-id={comment.id}
    >
      {/* Comment author avatar */}
      <Avatar
        name={comment.author.fullName}
        color={comment.author.avatarColor}
        src={comment.author.avatarUrl}
        size="sm"
        className="mt-0.5 shrink-0 cursor-pointer"
        onClick={() => openProfile(comment.author.username)}
      />

      <div className="min-w-0 flex-1">
        {/* Author name + username + time + edited indicator */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => openProfile(comment.author.username)}
            className="flex min-w-0 items-center gap-1 text-xs font-semibold hover:underline"
            dir="auto"
          >
            <span className="truncate">{comment.author.fullName}</span>
            {comment.author.isVerified && <VerifiedBadge size={12} />}
            <span className="truncate font-normal text-muted-foreground">
              @{comment.author.username}
            </span>
          </button>
          <span className="text-muted-foreground">·</span>
          <time
            className="shrink-0 text-[10px] text-muted-foreground"
            dateTime={comment.createdAt}
            title={new Date(comment.createdAt).toLocaleString()}
          >
            {fmtRelative(comment.createdAt)}
          </time>
          {edited && (
            <span className="text-[10px] text-muted-foreground">
              · {t("posts.edited") || "edited"}
            </span>
          )}
        </div>

        {/* Comment content */}
        <p
          className="mt-0.5 whitespace-pre-wrap break-words text-sm leading-relaxed"
          dir="auto"
        >
          {comment.content}
        </p>

        {/* Action row: Like + Reply + (Delete if authorized) */}
        <div className="mt-1.5 flex items-center gap-1 text-xs">
          {/* Like button — optimistic toggle */}
          <button
            onClick={toggleLike}
            disabled={likeLoading}
            className={cn(
              "flex items-center gap-1 rounded-md px-2 py-1 font-medium transition-colors hover:bg-accent/50 disabled:opacity-50",
              comment.isLiked
                ? "text-red-500 hover:bg-red-500/10"
                : "text-muted-foreground hover:text-red-500"
            )}
            aria-pressed={comment.isLiked}
            aria-label={comment.isLiked ? (t("posts.unlike") || "Unlike") : (t("posts.like") || "Like")}
          >
            <Heart
              className={cn(
                "h-3.5 w-3.5 transition-all duration-200",
                comment.isLiked && "fill-current scale-110"
              )}
            />
            {comment.likeCount > 0 && (
              <span className="tabular-nums">{formatCount(comment.likeCount)}</span>
            )}
          </button>

          {/* Reply button — toggles the reply composer */}
          <button
            onClick={() => {
              setShowReplyComposer((s) => !s);
              // If we just opened the composer and replies are collapsed,
              // expand them so the user can see the new reply when it lands.
              if (!showReplyComposer) setRepliesExpanded(true);
            }}
            className="flex items-center gap-1 rounded-md px-2 py-1 font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-sky-500"
            aria-label={t("posts.reply") || "Reply"}
          >
            <CornerDownRight className="h-3.5 w-3.5 rtl-flip" />
            <span>{t("posts.reply") || "Reply"}</span>
          </button>

          {/* Delete button — only shown when the current user can delete */}
          {canDelete && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 px-2 text-xs font-medium text-muted-foreground hover:text-destructive"
                  disabled={deleting}
                  aria-label={t("posts.deleteComment") || "Delete comment"}
                >
                  {deleting ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <Trash2 className="h-3 w-3" />
                  )}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>
                    {t("posts.deleteCommentConfirmTitle") || "Delete this comment?"}
                  </AlertDialogTitle>
                  <AlertDialogDescription>
                    {t("posts.deleteCommentConfirmDesc") ||
                      "This comment will be permanently deleted. This action cannot be undone."}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>{t("common.cancel") || "Cancel"}</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDelete}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    {t("posts.delete") || "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>

        {/* Reply composer — shown when the user clicks "Reply" */}
        {showReplyComposer && (
          <div className="mt-2 rounded-lg border bg-muted/30 p-2.5">
            <div className="mb-1.5 flex items-center gap-1.5 text-xs text-muted-foreground">
              <CornerDownRight className="h-3 w-3 rtl-flip" />
              <span>
                {t("posts.replyTo") || "Reply to"} @{comment.author.username}
              </span>
            </div>
            <div className="flex items-start gap-2">
              <Avatar
                name={user?.fullName ?? "?"}
                color={user?.avatarColor}
                src={user?.avatarUrl}
                size="sm"
                className="mt-0.5 h-6 w-6 shrink-0 text-[10px]"
              />
              <div className="min-w-0 flex-1">
                <Textarea
                  ref={replyTextareaRef}
                  value={replyDraft}
                  onChange={(e) => setReplyDraft(e.target.value)}
                  onKeyDown={onReplyKeyDown}
                  placeholder={t("posts.replyPlaceholder") || "Write a reply…"}
                  maxLength={COMMENT_MAX_LENGTH * 4}
                  rows={2}
                  className="min-h-[52px] resize-none text-sm"
                  aria-label="Reply"
                  disabled={replySubmitting}
                />
                <div className="mt-1.5 flex items-center justify-between gap-2">
                  <span
                    className={cn(
                      "text-[10px] tabular-nums",
                      replyOverLimit
                        ? "font-semibold text-destructive"
                        : "text-muted-foreground"
                    )}
                    aria-live="polite"
                  >
                    {replyCharCount}/{COMMENT_MAX_LENGTH}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 px-2 text-xs"
                      onClick={() => {
                        setShowReplyComposer(false);
                        setReplyDraft("");
                      }}
                      disabled={replySubmitting}
                    >
                      {t("common.cancel") || "Cancel"}
                    </Button>
                    <Button
                      size="sm"
                      className="h-7 px-3 text-xs"
                      onClick={submitReply}
                      disabled={!replyCanSubmit}
                    >
                      {replySubmitting && <Loader2 className="mr-1 h-3 w-3 animate-spin" />}
                      {t("posts.send") || "Send"}
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* "View replies" / "Hide replies" toggle — only when there are
            replies AND the composer isn't forcing them visible */}
        {replyCount > 0 && !showReplyComposer && (
          <button
            onClick={() => setRepliesExpanded((s) => !s)}
            className="mt-2 flex items-center gap-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            {/* Vertical line — visual cue that this toggles nested content */}
            <span className="inline-block h-3 w-0.5 rounded-full bg-muted-foreground/40" />
            {repliesExpanded ? (
              <>{t("posts.hideReplies") || "Hide replies"}{replyCount > 0 ? ` (${replyCount})` : ""}</>
            ) : (
              <>{t("posts.viewReplies") || "View replies"} ({replyCount})</>
            )}
          </button>
        )}

        {/* Replies list — rendered when expanded. Indented with a left
            border to visually distinguish from the parent comment.
            Phase 3.1 — depth=1 passed to ReplyItem for recursive rendering.
            Mobile: smaller indent (pl-2 ml-2). Desktop: comfortable (sm:pl-4 sm:ml-3). */}
        {repliesExpanded && replyCount > 0 && (
          <div className="mt-2 space-y-1 border-l border-border/60 pl-2 ml-2 sm:pl-4 sm:ml-3">
            {comment.replies.map((reply) => (
              <ReplyItem
                key={reply.id}
                kind={kind}
                contentId={contentId}
                reply={reply}
                depth={1}
                isHighlighted={!!highlightedReplyId && highlightedReplyId === reply.id}
                canDelete={
                  // Reply author OR content author OR admin can delete.
                  user?.id === reply.author.id || canDelete
                }
                onDeleted={handleReplyDeleted}
                onLikeUpdate={handleReplyLikeUpdate}
                onReplyAddedNested={(parentId, newReply) => {
                  // Phase 3.1 — when a nested reply is added (reply to a reply),
                  // use addReplyToTree to insert it at the correct position.
                  setComment((c) => ({
                    ...c,
                    replies: addReplyToTree(c.replies, parentId, newReply),
                  }));
                }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ReplyItem — renders a single reply AND its nested replies (recursive).
// Phase 3.1 — Deep Discussions: now supports arbitrary nesting depth.
// ─────────────────────────────────────────────────────────────────────────────

interface ReplyItemProps {
  kind: CommentKind;
  contentId: string;
  reply: ReplyDTO;
  /** Phase 3.1 — nesting depth (1 = first-level reply, 2 = reply to reply, etc.) */
  depth: number;
  canDelete: boolean;
  onDeleted: (replyId: string) => void;
  onLikeUpdate: (replyId: string, liked: boolean, likeCount: number) => void;
  /** Phase 3.1 — callback when a nested reply is added (reply to this reply). */
  onReplyAddedNested?: (parentId: string, newReply: ReplyDTO) => void;
  /**
   * Phase 2 — when true, this reply is the deep-link target.
   */
  isHighlighted?: boolean;
}

function ReplyItem({
  kind,
  contentId,
  reply: initialReply,
  depth,
  canDelete,
  onDeleted,
  onLikeUpdate,
  onReplyAddedNested,
  isHighlighted,
}: ReplyItemProps) {
  const router = useRouter();
  const { t, fmtRelative } = useTranslation();
  const { user } = useAuthStore();
  const paths = apiPaths(kind, contentId);

  const [reply, setReply] = useState<ReplyDTO>(initialReply);
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setReply(initialReply);
  }, [initialReply]);

  const [likeLoading, setLikeLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // Phase 3.1 — reply composer state (for replying to THIS reply).
  const [replyDraft, setReplyDraft] = useState("");
  const [replySubmitting, setReplySubmitting] = useState(false);
  const [showReplyComposer, setShowReplyComposer] = useState(false);
  const replyTextareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Phase 3.1 — collapse/expand for THIS reply's nested replies.
  const nestedReplies = reply.replies ?? [];
  const [nestedExpanded, setNestedExpanded] = useState(
    nestedReplies.length > 0 && nestedReplies.length <= 3 // auto-expand short threads
  );

  // ── Phase 2 — Deep-link highlight ─────────────────────────────────────
  const replyRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!isHighlighted) return;
    const t = setTimeout(() => {
      replyRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 200);
    return () => clearTimeout(t);
  }, [isHighlighted]);

  // Focus the reply textarea when the composer opens.
  useEffect(() => {
    if (showReplyComposer) {
      const id = setTimeout(() => replyTextareaRef.current?.focus(), 50);
      return () => clearTimeout(id);
    }
  }, [showReplyComposer]);

  // ── Like toggle — optimistic ─────────────────────────────────────────
  const toggleLike = useCallback(async () => {
    if (likeLoading) return;
    if (!user) {
      toast.info(t("auth.signInToLike") || "Sign in to like this reply");
      router.push("/");
      return;
    }
    const wasLiked = reply.isLiked;
    const prevCount = reply.likeCount;
    setReply((r) => ({ ...r, isLiked: !wasLiked, likeCount: prevCount + (wasLiked ? -1 : 1) }));
    setLikeLoading(true);
    try {
      const data = await api.post<{ liked: boolean; likeCount: number }>(paths.likeComment(reply.id));
      setReply((r) => ({ ...r, isLiked: data.liked, likeCount: data.likeCount }));
      onLikeUpdate(reply.id, data.liked, data.likeCount);
    } catch (e) {
      setReply((r) => ({ ...r, isLiked: wasLiked, likeCount: prevCount }));
      toast.error(e instanceof ApiClientError ? e.message : "Failed to toggle like");
    } finally {
      setLikeLoading(false);
    }
  }, [likeLoading, user, router, t, reply.id, reply.isLiked, reply.likeCount, paths, onLikeUpdate]);

  // ── Delete handler ───────────────────────────────────────────────────
  const handleDelete = useCallback(async () => {
    setDeleting(true);
    try {
      await api.delete(paths.deleteComment(reply.id));
      onDeleted(reply.id);
      toast.success(t("posts.commentDeleted") || "Reply deleted");
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to delete reply");
    } finally {
      setDeleting(false);
    }
  }, [reply.id, paths, onDeleted, t]);

  // ── Phase 3.1 — Reply submit (reply to THIS reply) ──────────────────
  const submitReply = useCallback(async () => {
    const trimmed = replyDraft.trim();
    if (!trimmed || replySubmitting) return;
    if (!user) { router.push("/"); return; }
    setReplySubmitting(true);
    try {
      const data = await api.post<{ comment: any }>(paths.createComment, {
        content: trimmed,
        parentCommentId: reply.id, // reply to THIS reply — works at any depth
      });
      const newReply: ReplyDTO = {
        id: data.comment.id,
        content: data.comment.content,
        parentCommentId: reply.id,
        createdAt: data.comment.createdAt,
        updatedAt: data.comment.updatedAt,
        author: data.comment.author,
        likeCount: data.comment.likeCount ?? 0,
        isLiked: data.comment.isLiked ?? false,
        replies: [],
      };
      // Add to THIS reply's nested replies (local state).
      setReply((r) => ({
        ...r,
        replies: [...(r.replies ?? []), newReply],
      }));
      setNestedExpanded(true); // make sure the new reply is visible
      // Also notify parent for tree-level sync.
      onReplyAddedNested?.(reply.id, newReply);
      setReplyDraft("");
      setShowReplyComposer(false);
    } catch (e) {
      toast.error(e instanceof ApiClientError ? e.message : "Failed to post reply");
    } finally {
      setReplySubmitting(false);
    }
  }, [replyDraft, replySubmitting, user, router, reply.id, paths, onReplyAddedNested]);

  // ── Phase 3.1 — nested reply deletion (recursive) ──────────────────
  const handleNestedDeleted = useCallback((nestedReplyId: string) => {
    setReply((r) => ({
      ...r,
      replies: r.replies ? removeCommentFromTree(r.replies, nestedReplyId) : r.replies,
    }));
    onDeleted(nestedReplyId); // propagate to parent for tree-level cleanup
  }, [onDeleted]);

  // ── Phase 3.1 — nested reply like update (recursive) ───────────────
  const handleNestedLikeUpdate = useCallback((nestedReplyId: string, liked: boolean, likeCount: number) => {
    setReply((r) => ({
      ...r,
      replies: r.replies ? updateCommentInTree(r.replies, nestedReplyId, { isLiked: liked, likeCount }) : r.replies,
    }));
    onLikeUpdate(nestedReplyId, liked, likeCount);
  }, [onLikeUpdate]);

  // ── Phase 3.1 — nested reply added (recursive) ─────────────────────
  const handleNestedReplyAdded = useCallback((parentId: string, newReply: ReplyDTO) => {
    setReply((r) => ({
      ...r,
      replies: r.replies ? addReplyToTree(r.replies, parentId, newReply) : [newReply],
    }));
  }, []);

  function onReplyKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") { e.preventDefault(); void submitReply(); }
    if (e.key === "Escape") { e.preventDefault(); setShowReplyComposer(false); setReplyDraft(""); }
  }

  function openProfile(username: string) {
    router.push(`/?view=profile&username=${encodeURIComponent(username)}`);
  }

  const edited = new Date(reply.updatedAt).getTime() - new Date(reply.createdAt).getTime() > 1000;
  const replyCharCount = Array.from(replyDraft).length;
  const replyOverLimit = replyCharCount > COMMENT_MAX_LENGTH;
  const replyCanSubmit = replyDraft.trim().length > 0 && !replyOverLimit && !replySubmitting;
  const nestedCount = nestedReplies.length;

  return (
    <div
      ref={replyRef}
      className={cn(
        "rounded-lg py-1.5 transition-colors",
        isHighlighted && "bg-amber-100/60 dark:bg-amber-900/20 animate-pulse-highlight -mx-1 px-1"
      )}
      data-reply-id={reply.id}
    >
      {/* Reply content — same layout as the existing ReplyItem */}
      <div className="flex gap-2 min-w-0">
        <Avatar
          name={reply.author.fullName}
          color={reply.author.avatarColor}
          src={reply.author.avatarUrl}
          size="sm"
          className="mt-0.5 h-6 w-6 shrink-0 cursor-pointer text-[10px]"
          onClick={() => openProfile(reply.author.username)}
        />
        <div className="min-w-0 flex-1 overflow-hidden">
          {/* Author + time + edited */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => openProfile(reply.author.username)}
              className="flex min-w-0 items-center gap-1 text-xs font-semibold hover:underline"
              dir="auto"
            >
              <span className="truncate">{reply.author.fullName}</span>
              {reply.author.isVerified && <VerifiedBadge size={10} />}
              <span className="truncate font-normal text-muted-foreground">@{reply.author.username}</span>
            </button>
            <span className="text-muted-foreground">·</span>
            <time className="shrink-0 text-[10px] text-muted-foreground" dateTime={reply.createdAt} title={new Date(reply.createdAt).toLocaleString()}>
              {fmtRelative(reply.createdAt)}
            </time>
            {edited && <span className="text-[10px] text-muted-foreground">· {t("posts.edited") || "edited"}</span>}
          </div>

          {/* Reply content */}
          <p className="mt-0.5 whitespace-pre-wrap break-words overflow-wrap-anywhere text-sm leading-relaxed" dir="auto">
            {reply.content}
          </p>

          {/* Like + Reply + Delete actions */}
          <div className="mt-1 flex items-center gap-1 text-xs">
            <button
              onClick={toggleLike}
              disabled={likeLoading}
              className={cn(
                "flex items-center gap-1 rounded-md px-1.5 py-0.5 font-medium transition-colors hover:bg-accent/50 disabled:opacity-50",
                reply.isLiked ? "text-red-500 hover:bg-red-500/10" : "text-muted-foreground hover:text-red-500"
              )}
              aria-pressed={reply.isLiked}
              aria-label={reply.isLiked ? (t("posts.unlike") || "Unlike") : (t("posts.like") || "Like")}
            >
              <Heart className={cn("h-3 w-3 transition-all duration-200", reply.isLiked && "fill-current scale-110")} />
              {reply.likeCount > 0 && <span className="tabular-nums">{formatCount(reply.likeCount)}</span>}
            </button>

            {/* Phase 3.1 — Reply button (works at any depth) */}
            <button
              onClick={() => {
                setShowReplyComposer((s) => !s);
                if (!showReplyComposer) setNestedExpanded(true);
              }}
              className="flex items-center gap-1 rounded-md px-1.5 py-0.5 font-medium text-muted-foreground transition-colors hover:bg-accent/50 hover:text-sky-500"
              aria-label={t("posts.reply") || "Reply"}
            >
              <CornerDownRight className="h-3 w-3 rtl-flip" />
              <span>{t("posts.reply") || "Reply"}</span>
            </button>

            {canDelete && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-6 px-1.5 text-xs font-medium text-muted-foreground hover:text-destructive" disabled={deleting} aria-label={t("posts.deleteComment") || "Delete reply"}>
                    {deleting ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>{t("posts.deleteReplyConfirmTitle") || "Delete this reply?"}</AlertDialogTitle>
                    <AlertDialogDescription>{t("posts.deleteCommentConfirmDesc") || "This reply will be permanently deleted. This action cannot be undone."}</AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>{t("common.cancel") || "Cancel"}</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">{t("posts.delete") || "Delete"}</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
          </div>

          {/* Phase 3.1 — Reply composer (reply to THIS reply) */}
          {showReplyComposer && (
            <div className="mt-2 rounded-lg border bg-muted/30 p-2.5">
              <div className="mb-1.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                <CornerDownRight className="h-3 w-3 rtl-flip" />
                <span>{t("posts.replyTo") || "Reply to"} @{reply.author.username}</span>
              </div>
              <div className="flex items-start gap-2">
                <Avatar name={user?.fullName ?? "?"} color={user?.avatarColor} src={user?.avatarUrl} size="sm" className="mt-0.5 h-6 w-6 shrink-0 text-[10px]" />
                <div className="min-w-0 flex-1">
                  <Textarea
                    ref={replyTextareaRef}
                    value={replyDraft}
                    onChange={(e) => setReplyDraft(e.target.value)}
                    onKeyDown={onReplyKeyDown}
                    placeholder={t("posts.replyPlaceholder") || "Write a reply…"}
                    maxLength={COMMENT_MAX_LENGTH * 4}
                    rows={2}
                    className="min-h-[52px] resize-none text-sm"
                    aria-label="Reply"
                    disabled={replySubmitting}
                  />
                  <div className="mt-1.5 flex items-center justify-between gap-2">
                    <span className={cn("text-[10px] tabular-nums", replyOverLimit ? "font-semibold text-destructive" : "text-muted-foreground")} aria-live="polite">
                      {replyCharCount}/{COMMENT_MAX_LENGTH}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => { setShowReplyComposer(false); setReplyDraft(""); }} disabled={replySubmitting}>
                        {t("common.cancel") || "Cancel"}
                      </Button>
                      <Button size="sm" className="h-7 px-3 text-xs" onClick={submitReply} disabled={!replyCanSubmit}>
                        {replySubmitting && <Loader2 className="mr-1 h-3 w-3 animate-spin" />}
                        {t("posts.send") || "Send"}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Phase 3.1 — Collapse/expand for nested replies */}
          {nestedCount > 0 && !showReplyComposer && (
            <button
              onClick={() => setNestedExpanded((s) => !s)}
              className="mt-1.5 flex items-center gap-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
              aria-expanded={nestedExpanded}
              aria-label={nestedExpanded ? "Hide replies" : "Show replies"}
            >
              <span className="inline-block h-3 w-0.5 rounded-full bg-muted-foreground/40" />
              {nestedExpanded
                ? <>{t("posts.hideReplies") || "Hide replies"} ({nestedCount})</>
                : <>{t("posts.viewReplies") || "View replies"} ({nestedCount})</>
              }
            </button>
          )}

          {/* Phase 3.1 — Recursive nested replies */}
          {nestedExpanded && nestedCount > 0 && (
            <div
              className={cn("mt-1.5 space-y-1", indentClass(depth))}
              style={indentStyle(depth)}
            >
              {nestedReplies.map((nested) => (
                <ReplyItem
                  key={nested.id}
                  kind={kind}
                  contentId={contentId}
                  reply={nested}
                  depth={depth + 1}
                  canDelete={user?.id === nested.author.id || canDelete}
                  onDeleted={handleNestedDeleted}
                  onLikeUpdate={handleNestedLikeUpdate}
                  onReplyAddedNested={handleNestedReplyAdded}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
