"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { MainNav } from "@/components/shared/main-nav";
import { SiteFooter } from "@/components/shared/site-footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Mail, Globe, Info, Send, Loader2 } from "lucide-react";
import { useTranslation } from "@/lib/client/i18n-store";
import { api, ApiClientError } from "@/lib/client/api";
import { trackPageView } from "@/lib/client/analytics";
import { toast } from "sonner";
import type { PublicSitePage } from "@/lib/site-pages";

interface SitePageClientProps {
  page: PublicSitePage;
  /** Dynamic platform name (from platform.name setting). */
  platformName: string;
}

/**
 * SitePageClient — reusable client component for all 4 site pages.
 *
 * Renders the published content for /about, /privacy, /terms, /contact.
 * The server component (src/app/<slug>/page.tsx) fetches the content +
 * passes it as props. This component handles:
 *   - MainNav (desktop top bar + mobile bottom bar)
 *   - Breadcrumb (Home → <Page Title>)
 *   - Page <h1>
 *   - Intro block (intro.title + intro.content)
 *   - Sections (each rendered as a Card)
 *   - Contact block (when present + has at least one channel)
 *   - Contact form (ONLY when slug === "contact")
 *   - SiteFooter
 *
 * Contact form:
 *   - Submits to POST /api/v1/contact (public, rate-limited by IP).
 *   - Fields: name, email, subject (optional), message.
 *   - On success: toast "Message sent successfully" + reset form.
 *   - On error: toast with the server's error message.
 *   - Rate-limited to 5 submissions/hour per IP (server-side).
 *
 * Accessibility:
 *   - Single <h1> (page.title)
 *   - Intro + each section + contact use <h2>
 *   - Form fields have associated <label> elements
 *   - All buttons have aria-labels
 *
 * Responsive:
 *   - Mobile: full width with px-4 padding
 *   - Desktop: centered max-w-3xl column
 */
export function SitePageClient({ page, platformName }: SitePageClientProps) {
  const router = useRouter();
  const { t } = useTranslation();

  const isContactPage = page.slug === "contact";

  // ── Traffic Analytics tracking (fire-and-forget) ──
  // Records a page_view event so the admin dashboard shows traffic to
  // /about, /privacy, /terms, /contact. Non-blocking — uses sendBeacon.
  useEffect(() => {
    trackPageView(`/${page.slug}`);
  }, [page.slug]);

  // Interpolate the platform name into the intro title when the admin
  // left the default "Welcome" — produces "Welcome to <PlatformName>".
  const introTitle =
    page.content.intro.title === "Welcome"
      ? `${page.content.intro.title} to ${platformName}`
      : page.content.intro.title;

  return (
    <div className="min-h-screen bg-background pb-14 md:pb-0">
      <MainNav />

      {/* Mobile sticky header — matches HomeFeed's mobile header pattern */}
      <header className="sticky top-0 z-10 flex h-14 items-center gap-2 border-b border-border/60 bg-background/80 px-4 backdrop-blur-md md:hidden">
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9"
          onClick={() => router.push("/")}
          aria-label={t("nav.backToApp") || "Back to app"}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <span className="truncate text-base font-bold">{page.title}</span>
      </header>

      {/* Desktop back button + breadcrumb */}
      <div className="mx-auto max-w-3xl px-4 pt-6 md:px-6">
        <nav
          aria-label="Breadcrumb"
          className="mb-4 flex items-center gap-1 text-sm text-muted-foreground"
        >
          <button
            onClick={() => router.push("/")}
            className="hover:text-foreground hover:underline"
          >
            {t("nav.home") || "Home"}
          </button>
          <span aria-hidden="true">/</span>
          <span className="text-foreground">{page.title}</span>
        </nav>
      </div>

      {/* Main content column */}
      <main className="mx-auto max-w-3xl px-4 pb-16 md:px-6">
        {/* Page title — single <h1> for accessibility */}
        <h1 className="text-3xl font-bold tracking-tight md:text-4xl">
          {page.title}
        </h1>

        {/* Intro block */}
        <section className="mt-8">
          <h2 className="text-xl font-semibold md:text-2xl">{introTitle}</h2>
          <p className="mt-3 whitespace-pre-line text-base leading-relaxed text-muted-foreground md:text-lg">
            {page.content.intro.content}
          </p>
        </section>

        {/* Sections — each rendered as a Card for visual separation */}
        {page.content.sections.length > 0 && (
          <div className="mt-10 space-y-6">
            {page.content.sections.map((section) => (
              <section
                key={section.id}
                className="rounded-lg border border-border/60 bg-card p-5 text-card-foreground shadow-sm md:p-6"
              >
                <h2 className="text-lg font-semibold md:text-xl">{section.title}</h2>
                <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-muted-foreground md:text-base">
                  {section.content}
                </p>
              </section>
            ))}
          </div>
        )}

        {/* Contact block — only rendered when the page has contact info.
            For /contact, this appears ABOVE the contact form. For other
            pages, this is hidden (they don't have a contact block). */}
        {page.content.contact &&
          (page.content.contact.content ||
            page.content.contact.email ||
            page.content.contact.website) && (
            <section className="mt-10 rounded-lg border border-border/60 bg-card p-5 text-card-foreground shadow-sm md:p-6">
              <h2 className="text-lg font-semibold md:text-xl">
                {page.content.contact.title}
              </h2>
              {page.content.contact.content && (
                <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-muted-foreground md:text-base">
                  {page.content.contact.content}
                </p>
              )}
              <div className="mt-4 flex flex-col gap-2 text-sm">
                {page.content.contact.email && (
                  <a
                    href={`mailto:${page.content.contact.email}`}
                    className="inline-flex items-center gap-2 text-primary hover:underline"
                  >
                    <Mail className="h-4 w-4" />
                    {page.content.contact.email}
                  </a>
                )}
                {page.content.contact.website && (
                  <a
                    href={page.content.contact.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-primary hover:underline"
                  >
                    <Globe className="h-4 w-4" />
                    {page.content.contact.website}
                  </a>
                )}
                {!page.content.contact.email &&
                  !page.content.contact.website && (
                    <p className="inline-flex items-center gap-2 text-muted-foreground">
                      <Info className="h-4 w-4" />
                      Contact channels will be added soon.
                    </p>
                  )}
              </div>
            </section>
          )}

        {/* Contact form — ONLY on /contact */}
        {isContactPage && <ContactForm />}
      </main>

      <SiteFooter platformName={platformName} activeSlug={page.slug as "about" | "privacy" | "terms" | "contact"} />
    </div>
  );
}

// ── Contact form (rendered only on /contact) ───────────────────────────

function ContactForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    if (!name.trim() || !email.trim() || message.trim().length < 10) {
      return;
    }
    setSubmitting(true);
    try {
      await api.post("/api/v1/contact", { name, email, subject, message });
      toast.success("Message sent successfully. We'll get back to you soon.");
      setName("");
      setEmail("");
      setSubject("");
      setMessage("");
    } catch (err) {
      toast.error(
        err instanceof ApiClientError
          ? err.message
          : "Failed to send message. Please try again later."
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section className="mt-10 rounded-lg border border-border/60 bg-card p-5 text-card-foreground shadow-sm md:p-6">
      <h2 className="text-lg font-semibold md:text-xl">Send us a message</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Fill out the form below and we&apos;ll get back to you as soon as possible.
      </p>
      <form onSubmit={handleSubmit} className="mt-4 space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="contact-name">Name</Label>
            <Input
              id="contact-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              maxLength={100}
              placeholder="Your name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="contact-email">Email</Label>
            <Input
              id="contact-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              maxLength={254}
              placeholder="you@example.com"
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="contact-subject">Subject (optional)</Label>
          <Input
            id="contact-subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            maxLength={200}
            placeholder="What's this about?"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="contact-message">Message</Label>
          <Textarea
            id="contact-message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            required
            minLength={10}
            maxLength={5000}
            rows={6}
            placeholder="Your message (at least 10 characters)..."
          />
          <p className="text-xs text-muted-foreground">
            {message.length}/5000 characters
          </p>
        </div>
        <Button type="submit" disabled={submitting} className="w-full md:w-auto">
          {submitting ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Send className="mr-2 h-4 w-4" />
          )}
          {submitting ? "Sending..." : "Send message"}
        </Button>
      </form>
    </section>
  );
}
