/**
 * Username validation & normalization.
 *
 * Rules (per spec §2):
 *  - English letters, numbers, underscore only
 *  - No spaces
 *  - 3-30 characters
 *  - Case-insensitive uniqueness (stored & compared as lowercase)
 *
 * ── MODULE LAYOUT ──────────────────────────────────────────────────────
 *
 * This module is the SERVER-SIDE entry point. It re-exports the
 * client-safe schema + validator from `./username-shared` (so server-side
 * callers can keep importing everything from `@/lib/username`) and adds
 * the DB-backed `isUsernameAvailable` + `suggestUsernames` functions.
 *
 * IMPORTANT: Client Components MUST import `USERNAME_SCHEMA` /
 * `validateUsername` from `@/lib/username-shared` instead of this file.
 * Importing this file in a Client Component pulls `db` (and therefore
 * PrismaClient) into the browser bundle, which throws
 * "PrismaClient is unable to run in this browser environment" and triggers
 * the global-error.tsx boundary ("Something went wrong"). Client
 * components that need to check username availability should call the
 * `/api/v1/username-check` endpoint via fetch — NOT the server function
 * directly.
 */

// Re-export the client-safe schema + validator so server-side callers can
// keep importing everything from `@/lib/username`.
export { USERNAME_SCHEMA, validateUsername } from "./username-shared";

import { db } from "@/lib/database";

/**
 * Check if a username is available (not taken by another user).
 */
export async function isUsernameAvailable(
  username: string,
  excludeUserId?: string
): Promise<boolean> {
  const normalized = username.toLowerCase().trim();
  const existing = await db.user.findUnique({
    where: { username: normalized },
    select: { id: true },
  });
  if (!existing) return true;
  if (excludeUserId && existing.id === excludeUserId) return true;
  return false;
}

/**
 * Suggest alternative usernames when the desired one is taken.
 * Example: "3bdo" → ["3bdo_1", "3bdo2007", "3bdo_official"]
 */
export async function suggestUsernames(base: string): Promise<string[]> {
  const normalized = base.toLowerCase().trim();
  const suggestions: string[] = [];
  const candidates = [
    `${normalized}_1`,
    `${normalized}_2`,
    `${normalized}_official`,
    `${normalized}2007`,
    `${normalized}_real`,
    `the_${normalized}`,
    `${normalized}_2024`,
  ];
  for (const c of candidates) {
    if (suggestions.length >= 3) break;
    const available = await isUsernameAvailable(c);
    if (available) suggestions.push(c);
  }
  return suggestions;
}
