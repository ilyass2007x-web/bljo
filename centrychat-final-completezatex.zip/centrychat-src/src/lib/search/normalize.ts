/**
 * Search Quality — Text Normalization (Phase 2D)
 * ===============================================
 *
 * Pure, deterministic, search-only normalization for Arabic + Latin text.
 *
 * DESIGN PRINCIPLES:
 *   - Pure function: no DB, no Prisma, no I/O. Safe to call from anywhere.
 *   - Deterministic: same input always produces same output.
 *   - Search-only: NOT used for moderation (which has different needs —
 *     see src/lib/moderation/normalize.ts). NOT used to modify user-facing
 *     text. The original text is preserved in the DB; only the normalized
 *     variant is stored alongside in a `*_normalized` column for search.
 *
 * NORMALIZATION RULES (applied in order):
 *   1. NFKC Unicode normalization (canonical composition — collapses
 *      compatibility characters like fullwidth Latin, ligatures, etc.).
 *   2. Strip zero-width characters (ZWJ, ZWNJ, BOM, Word Joiner, soft hyphen).
 *   3. Strip Arabic diacritics (tashkeel: fatha, damma, kasra, shadda, sukun,
 *      dagger alef, etc.).
 *   4. Strip tatweel (U+0640 — Arabic elongation character).
 *   5. Unify alef variants: `أ` `إ` `آ` `ٱ` → `ا` (U+0627).
 *   6. Unify ya / alif maqsura: `ى` → `ي` (U+064A).
 *   7. Lowercase (handles Latin characters; no-op for Arabic).
 *   8. Collapse repeated whitespace to single space + trim.
 *
 * WHAT THIS MODULE DOES NOT DO (deliberately, per Phase 2D scope):
 *   - Does NOT convert ta marbuta `ة` to `ه` (or vice versa). This is a
 *     linguistic transformation that risks false positives. Search users
 *     typing `مغربة` should match `مغربة` (with ta marbuta) but should
 *     not necessarily match `مغربه` (with ha) — these are different words
 *     in Arabic. If equivalence is desired in the future, it should be
 *     a separate, tested decision.
 *   - Does NOT transliterate Darija numerals (3→ع, 7→ح, 9→ق). This is
 *     transliteration, not normalization — out of Phase 2D scope.
 *   - Does NOT apply leetspeak substitution (that's moderation's job).
 *   - Does NOT collapse repeated characters (that's moderation's job).
 *   - Does NOT strip inter-word punctuation (preserve search semantics).
 *
 * PERFORMANCE: O(n) on input length. No regex backtracking. A 10,000-char
 * article body normalizes in microseconds.
 */

/**
 * Zero-width characters stripped in step 2.
 *
 *   U+200B  Zero Width Space
 *   U+200C  Zero Width Non-Joiner (ZWNJ)
 *   U+200D  Zero Width Joiner (ZWJ)
 *   U+2060  Word Joiner (invisible)
 *   U+FEFF  Zero Width No-Break Space (BOM)
 *   U+00AD  Soft Hyphen
 *   U+180E  Mongolian Vowel Separator
 */
const ZERO_WIDTH_REGEX = /[\u200b\u200c\u200d\u2060\ufeff\u00ad\u180e]/g;

/**
 * Arabic diacritics (tashkeel) stripped in step 3.
 *
 * Covers:
 *   U+0610–U+061A  Arabic signs (small waw, etc.)
 *   U+064B–U+065F  Arabic diacritics (fatha, damma, kasra, shadda, sukun, etc.)
 *   U+0670         Arabic letter superscript alef (dagger alef)
 *   U+06D6–U+06DC  Arabic vowel signs (extended)
 *   U+06DF–U+06E4  Arabic vowel signs (extended)
 *   U+06E7–U+06E8  Arabic vowel signs (extended)
 *   U+06EA–U+06ED  Arabic vowel signs (extended)
 */
const ARABIC_DIACRITICS_REGEX = /[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06dc\u06df-\u06e4\u06e7-\u06e8\u06ea-\u06ed]/g;

/**
 * Tatweel (Arabic elongation character) stripped in step 4.
 *
 *   U+0640  Arabic Tatweel
 */
const TATWEEL_REGEX = /\u0640/g;

/**
 * Alef variants unified to canonical alef (U+0627) in step 5.
 *
 *   U+0623  أ  (alef with hamza above)
 *   U+0625  إ  (alef with hamza below)
 *   U+0622  آ  (alef with madde above)
 *   U+0671  ٱ  (alef wasla)
 */
const ALEF_VARIANTS_REGEX = /[\u0623\u0625\u0622\u0671]/g;

/**
 * Alif maqsura (U+0649 ى) unified to ya (U+064A ي) in step 6.
 */
const ALIF_MAQSURA_REGEX = /\u0649/g;

/**
 * Main entry point. Returns the normalized string used for search.
 *
 * @param text The original text (untouched after this call).
 * @returns The normalized variant — NFKC + zero-width stripped + Arabic
 *          diacritics stripped + tatweel stripped + alef variants unified +
 *          alif maqsura unified + lowercased + whitespace collapsed.
 */
export function normalizeForSearch(text: string | null | undefined): string {
  if (!text) return "";

  // Step 1: NFKC Unicode normalization.
  // NFKC = canonical decomposition + compatibility composition. Collapses
  // fullwidth Latin (Ａ → A), ligatures (ﬁ → fi), etc.
  let out = text.normalize("NFKC");

  // Step 2: strip zero-width characters.
  out = out.replace(ZERO_WIDTH_REGEX, "");

  // Step 3: strip Arabic diacritics (tashkeel).
  out = out.replace(ARABIC_DIACRITICS_REGEX, "");

  // Step 4: strip tatweel (Arabic elongation).
  out = out.replace(TATWEEL_REGEX, "");

  // Step 5: unify alef variants to canonical alef.
  out = out.replace(ALEF_VARIANTS_REGEX, "\u0627");

  // Step 6: unify alif maqsura to ya.
  out = out.replace(ALIF_MAQSURA_REGEX, "\u064A");

  // Step 7: lowercase (handles Latin characters; no-op for Arabic).
  out = out.toLowerCase();

  // Step 8: collapse repeated whitespace to single space + trim.
  out = out.replace(/\s+/g, " ").trim();

  return out;
}

/**
 * Split a normalized query into search tokens (whitespace-separated).
 *
 * Used for multi-word token AND fallback. The query is normalized FIRST
 * (so tokenization happens on the normalized form — diacritics stripped,
 * alef variants unified, etc.), then split on whitespace.
 *
 * @param q The already-normalized query string.
 * @returns Array of non-empty tokens. For `"football player"` returns
 *          `["football", "player"]`. For single-word queries returns
 *          a 1-element array. For empty/whitespace-only returns `[]`.
 */
export function tokenizeSearchQuery(q: string | null | undefined): string[] {
  if (!q) return [];
  return q.split(/\s+/).filter((t) => t.length > 0);
}

/**
 * Detect if a string contains Arabic characters. Used for diagnostics
 * + tests (NOT used by the search route directly — the route normalizes
 * all queries regardless of script).
 *
 * Returns true if ANY character is in the Arabic Unicode block
 * (U+0600–U+06FF) or Arabic Supplement (U+0750–U+077F) or Arabic
 * Presentation Forms (U+FB50–U+FDFF, U+FE70–U+FEFF).
 */
export function containsArabic(text: string): boolean {
  return /[\u0600-\u06ff\u0750-\u077f\ufb50-\ufdff\ufe70-\ufeff]/.test(text);
}
