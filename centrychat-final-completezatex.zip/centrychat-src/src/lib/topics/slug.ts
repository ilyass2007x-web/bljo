/**
 * Topic slug normalization utilities.
 *
 * A topic slug is the URL-safe, lowercase, normalized identity of a topic.
 * Slugs are STABLE + IMMUTABLE after creation — they are the primary key
 * for topic URLs + the deduplication mechanism.
 *
 * Normalization rules:
 *   - lowercase
 *   - trim leading/trailing whitespace
 *   - collapse internal whitespace to single hyphens
 *   - strip diacritics (Arabic, French accents) → ASCII when possible
 *   - remove all non-[a-z0-9-] characters
 *   - collapse multiple hyphens
 *   - strip leading/trailing hyphens
 *
 * Examples:
 *   "Artificial Intelligence"    → "artificial-intelligence"
 *   "  Football  "               → "football"
 *   "Web Development"           → "web-development"
 *   "AI / Machine Learning"     → "ai-machine-learning"
 *   "Café & Restaurant"         → "cafe-restaurant"
 *   "   "                       → "" (empty — caller must validate non-empty)
 */

/**
 * Generate a canonical slug from a topic name.
 *
 * @param name - the topic name (any case, any whitespace, may have diacritics).
 * @returns the normalized slug. Empty string when the input is empty or
 *          normalizes to empty (caller must validate non-empty before
 *          creating a topic).
 */
export function generateTopicSlug(name: string): string {
  if (!name || typeof name !== "string") return "";
  return normalizeTopicSlug(name);
}

/**
 * Normalize a slug (or any string) into canonical form.
 *
 * Used both for generating slugs from names AND for normalizing slugs that
 * come from the client (defensive — clients shouldn't send pre-made slugs,
 * but if they do, we normalize them consistently).
 */
export function normalizeTopicSlug(input: string): string {
  if (!input || typeof input !== "string") return "";
  // Step 1: lowercase + trim.
  let s = input.toLowerCase().trim();
  if (!s) return "";
  // Step 2: strip diacritics — NFD normalize + drop combining marks.
  // This converts "café" → "cafe", "naïve" → "naive", "المغرب" stays (Arabic
  // has no combining marks in the NFD sense). For Arabic text, the slug
  // will contain the Arabic characters themselves (URL-safe when encoded).
  // Note: not all runtimes have full ICU. We use a try/catch fallback.
  try {
    s = s.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  } catch {
    // normalize may not be available in some environments — proceed without.
  }
  // Step 3: replace any sequence of non-alphanumeric (incl. Unicode letters
  // + digits) characters with a single hyphen. \p{L} = any letter, \p{N} = any
  // number. The 'u' flag enables Unicode mode.
  // Keep Arabic + Latin + digit characters, replace everything else with '-'.
  s = s.replace(/[^\p{L}\p{N}]+/gu, "-");
  // Step 4: collapse multiple hyphens (defensive — the replace above
  // already produces single hyphens, but be safe).
  s = s.replace(/-{2,}/g, "-");
  // Step 5: strip leading/trailing hyphens.
  s = s.replace(/^-+|-+$/g, "");
  return s;
}

/**
 * Validate that a slug is well-formed + safe for use in URLs.
 *
 * Returns true when:
 *   - non-empty
 *   - length 2-80 characters
 *   - matches the canonical form (re-normalizing produces the same string)
 *   - doesn't start/end with a hyphen
 *   - doesn't contain consecutive hyphens
 *
 * Used by the topic service to reject malformed client-supplied slugs before
 * they hit the DB.
 */
export function isValidTopicSlug(slug: string): boolean {
  if (!slug || typeof slug !== "string") return false;
  if (slug.length < 2 || slug.length > 80) return false;
  // Must be canonical — re-normalizing produces the same string.
  if (normalizeTopicSlug(slug) !== slug) return false;
  // Must not start/end with hyphen (normalizeTopicSlug already strips these,
  // but be defensive in case the caller bypassed normalization).
  if (slug.startsWith("-") || slug.endsWith("-")) return false;
  // Must not contain consecutive hyphens.
  if (slug.includes("--")) return false;
  // Must contain only [a-z0-9-] + Unicode letters/digits (Arabic allowed).
  // The regex below matches the same character class as normalizeTopicSlug.
  return /^[a-z0-9-]+$/i.test(slug) || /^[\p{L}\p{N}-]+$/u.test(slug);
}

/**
 * Validate a topic name.
 *
 * Returns true when:
 *   - non-empty after trim
 *   - length 2-100 characters
 *   - doesn't contain control characters
 *
 * @param name - the topic display name.
 */
export function isValidTopicName(name: string): boolean {
  if (!name || typeof name !== "string") return false;
  const trimmed = name.trim();
  if (trimmed.length < 2 || trimmed.length > 100) return false;
  // Reject control characters (potential XSS / injection vector).
  if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/.test(trimmed)) return false;
  return true;
}
