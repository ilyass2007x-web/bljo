/**
 * Topic service — all topic business logic in one place.
 *
 * Reuses the EXISTING ContentTopic model (extended in Phase 2 with isActive +
 * updatedAt + new relations ArticleTopic/PostTopic/UserTopicFollow).
 *
 * SECURITY:
 *   - All public functions that mutate state require an authenticated userId
 *     (passed by the API route after `requireVerifiedUser()`).
 *   - userId is NEVER taken from the client — always from the session.
 *   - Topic IDs + slugs are validated before use.
 *   - Admin mutations require `requireAdmin()` in the API route (server-side).
 *
 * PERFORMANCE:
 *   - All list queries are bounded (take: N, default 20-50).
 *   - Indexes used: ContentTopic.slug, ContentTopic.isActive,
 *     UserTopicFollow.userId, ArticleTopic.articleId, PostTopic.postId.
 *   - Public topic data is cached 60s via getSetting-style cache (TODO).
 *   - Personalized recommendations are NEVER cached globally — they're
 *     per-user (see getUserInterestProfile's per-user cache).
 *
 * NO DUPLICATE FUNCTIONALITY:
 *   - Topic recommendation reuses `getUserInterestProfile` to get the user's
 *     existing interest topics + author affinities.
 *   - Topic following is separate from UserInterest (binary signal vs graded).
 *   - Not-interested topics continue to live in RecommendationProfile.
 */
import { db } from "@/lib/database";
import { getUserInterestProfile } from "@/lib/feed/interest-profile";
import {
  generateTopicSlug,
  isValidTopicName,
  isValidTopicSlug,
  normalizeTopicSlug,
} from "./slug";
import { logger } from "@/lib/logging";

// ── Types ───────────────────────────────────────────────────────────────────

export interface TopicDTO {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  isActive: boolean;
  followerCount: number;
  /** Whether the CURRENT user follows this topic. Null when no user context. */
  isFollowed: boolean | null;
  createdAt: string;
  updatedAt: string;
}

export interface TopicListResult {
  topics: TopicDTO[];
  nextCursor: string | null;
}

// ── Internal helpers ───────────────────────────────────────────────────────

/**
 * Convert a raw ContentTopic Prisma row to a TopicDTO.
 *
 * @param row - the Prisma row (must include _count.followers via _count
 *             aggregation when followerCount is desired).
 * @param currentUserId - the current user's ID (for isFollowed). Null when
 *                        no user context (e.g. SSR for public topic page).
 * @param followedTopicIdsSet - a Set of topic IDs the current user follows.
 *                              Null when no user context.
 */
function toTopicDTO(
  row: {
    id: string;
    name: string;
    slug: string;
    description: string | null;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
    _count?: { followers?: number };
  },
  currentUserId: string | null,
  followedTopicIdsSet: Set<string> | null
): TopicDTO {
  return {
    id: row.id,
    name: row.name,
    slug: row.slug,
    description: row.description,
    isActive: row.isActive,
    followerCount: row._count?.followers ?? 0,
    isFollowed: followedTopicIdsSet
      ? followedTopicIdsSet.has(row.id)
      : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

// ── Public read operations ──────────────────────────────────────────────────

/**
 * List active topics with cursor pagination.
 *
 * @param opts.limit - page size (default 20, max 50).
 * @param opts.cursor - opaque cursor from the previous response.
 * @param opts.search - optional search query (case-insensitive contains on name).
 * @param opts.sortBy - "popular" (default) | "recent" | "name".
 * @param currentUserId - the current user's ID (for isFollowed). Null for anon.
 */
export async function listTopics(
  opts: {
    limit?: number;
    cursor?: string | null;
    search?: string;
    sortBy?: "popular" | "recent" | "name";
  } = {},
  currentUserId: string | null = null
): Promise<TopicListResult> {
  const limit = Math.min(Math.max(opts.limit ?? 20, 1), 50);
  const search = opts.search?.trim() ?? "";
  const sortBy = opts.sortBy ?? "popular";

  // Decode the cursor — opaque base64-encoded slug of the last item.
  // For "name" sort: cursor is the slug. For "popular"/"recent": cursor is
  // also the slug (we paginate by slug offset — simpler than a composite
  // (count, slug) cursor, and good enough for ≤50 per page).
  let cursorSlug: string | null = null;
  if (opts.cursor) {
    try {
      cursorSlug = Buffer.from(opts.cursor, "base64").toString("utf-8");
    } catch {
      // invalid cursor — ignore, start from beginning
    }
  }

  // Build the WHERE clause. Active topics only (admin-deactivated excluded).
  // Search is case-insensitive contains on name.
  // PostgreSQL ILIKE — Prisma's `mode: "insensitive"`.
  const where: {
    isActive: boolean;
    name?: { contains: string; mode: "insensitive" };
    slug?: { gt: string };
  } = { isActive: true };
  if (search) {
    where.name = { contains: search, mode: "insensitive" };
  }
  if (cursorSlug) {
    where.slug = { gt: cursorSlug };
  }

  // Build the ORDER BY. For "popular" sort, we'd ideally use _count.followers
  // DESC, but Prisma's cursor pagination doesn't compose well with _count
  // ordering. So we use slug ASC for all sorts + re-sort in JS when needed.
  // For "popular" we fetch a larger pool (5×limit, max 250) + sort in JS by
  // follower count. For "recent" + "name" we use slug ASC (already indexed).
  // This keeps queries bounded + uses the index.
  let rows: any[];
  if (sortBy === "popular") {
    // Fetch 5×limit (capped at 250) to get a candidate pool, then sort in JS.
    const poolSize = Math.min(limit * 5, 250);
    rows = await db.contentTopic.findMany({
      where,
      orderBy: { slug: "asc" },
      take: poolSize,
      select: {
        id: true,
        name: true,
        slug: true,
        description: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
        _count: { select: { followers: true } },
      },
    });
    // Sort by follower count desc, then by name asc as tiebreaker.
    rows.sort((a, b) => {
      const fc = (b._count?.followers ?? 0) - (a._count?.followers ?? 0);
      if (fc !== 0) return fc;
      return a.name.localeCompare(b.name);
    });
    rows = rows.slice(0, limit);
  } else {
    // "recent" or "name" — use slug ASC (deterministic, indexed).
    rows = await db.contentTopic.findMany({
      where,
      orderBy: { slug: "asc" },
      take: limit + 1,
      select: {
        id: true,
        name: true,
        slug: true,
        description: true,
        isActive: true,
        createdAt: true,
        updatedAt: true,
        _count: { select: { followers: true } },
      },
    });
  }

  // Determine if there's a next page.
  const hasMore = sortBy !== "popular" && rows.length > limit;
  const items = hasMore ? rows.slice(0, limit) : rows;
  const lastSlug = items.length > 0 ? items[items.length - 1].slug : null;
  const nextCursor = hasMore && lastSlug
    ? Buffer.from(lastSlug, "utf-8").toString("base64")
    : null;

  // Fetch the current user's followed topic IDs (batched, 1 query) for isFollowed.
  let followedSet: Set<string> | null = null;
  if (currentUserId) {
    const follows = await db.userTopicFollow.findMany({
      where: { userId: currentUserId },
      select: { topicId: true },
    }).catch(() => []);
    followedSet = new Set(follows.map((f) => f.topicId));
  }

  return {
    topics: items.map((row: any) => toTopicDTO(row, currentUserId, followedSet)),
    nextCursor,
  };
}

/**
 * Get a single topic by slug. Returns null when not found or inactive
 * (unless includeInactive=true — admin-only).
 */
export async function getTopicBySlug(
  slug: string,
  opts: { includeInactive?: boolean } = {},
  currentUserId: string | null = null
): Promise<TopicDTO | null> {
  const normalized = normalizeTopicSlug(slug);
  if (!normalized || !isValidTopicSlug(normalized)) return null;

  const row = await db.contentTopic.findUnique({
    where: { slug: normalized },
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      isActive: true,
      createdAt: true,
      updatedAt: true,
      _count: { select: { followers: true } },
    },
  });
  if (!row) return null;
  if (!row.isActive && !opts.includeInactive) return null;

  // Fetch isFollowed for the current user (1 query).
  let followedSet: Set<string> | null = null;
  if (currentUserId) {
    const follow = await db.userTopicFollow.findUnique({
      where: { userId_topicId: { userId: currentUserId, topicId: row.id } },
      select: { topicId: true },
    }).catch(() => null);
    followedSet = new Set(follow ? [row.id] : []);
  }

  return toTopicDTO(row, currentUserId, followedSet);
}

/**
 * Get trending topics — topics with the most new follows in the last 7 days.
 *
 * @param limit - max topics to return (default 10, max 20).
 * @param currentUserId - for isFollowed.
 */
export async function getTrendingTopics(
  limit = 10,
  currentUserId: string | null = null
): Promise<TopicDTO[]> {
  const maxLimit = Math.min(Math.max(limit, 1), 20);
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  // Group by topicId where createdAt >= 7d ago, count follows, take top N.
  const trending = await db.userTopicFollow.groupBy({
    by: ["topicId"],
    where: { createdAt: { gte: sevenDaysAgo } },
    _count: { _all: true },
    orderBy: { _count: { topicId: "desc" } as any },
    take: maxLimit,
  }).catch(() => []);

  if (trending.length === 0) {
    // No recent follows — fall back to the most-followed topics overall.
    return listTopics({ limit: maxLimit, sortBy: "popular" }, currentUserId)
      .then((r) => r.topics);
  }

  const topicIds = trending.map((t) => t.topicId);
  const rows = await db.contentTopic.findMany({
    where: { id: { in: topicIds }, isActive: true },
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      isActive: true,
      createdAt: true,
      updatedAt: true,
      _count: { select: { followers: true } },
    },
  });

  // Reorder to match the trending sort (most new follows first).
  const orderMap = new Map<string, number>(
    trending.map((t, i) => [t.topicId, i] as [string, number])
  );
  rows.sort((a, b) => (orderMap.get(a.id) ?? 0) - (orderMap.get(b.id) ?? 0));

  // Fetch isFollowed for the current user.
  let followedSet: Set<string> | null = null;
  if (currentUserId) {
    const follows = await db.userTopicFollow.findMany({
      where: { userId: currentUserId, topicId: { in: topicIds } },
      select: { topicId: true },
    }).catch(() => []);
    followedSet = new Set(follows.map((f) => f.topicId));
  }

  return rows.map((row) => toTopicDTO(row, currentUserId, followedSet));
}

/**
 * Get recommended topics for a user — based on their existing interests,
 * followed topics, and creator affinities. EXCLUDES topics the user already
 * follows AND topics in their notInterestedTopics list.
 *
 * @param userId - the current user's ID.
 * @param limit - max topics to return (default 10, max 20).
 */
export async function getRecommendedTopics(
  userId: string,
  limit = 10
): Promise<TopicDTO[]> {
  const maxLimit = Math.min(Math.max(limit, 1), 20);

  // Load the user's interest profile (cached 60s — cheap).
  const profile = await getUserInterestProfile(userId).catch(() => null);

  // Topics the user already follows — EXCLUDE from recommendations.
  const followedTopics = await db.userTopicFollow.findMany({
    where: { userId },
    select: { topicId: true },
  }).catch(() => []);
  const followedTopicIdsSet = new Set(followedTopics.map((f) => f.topicId));

  // Topics the user marked "not interested" — EXCLUDE.
  const notInterestedSlugs = new Set(profile?.notInterestedTopics ?? []);

  // Build the candidate pool from the user's TOP interest topics.
  // These are topics they have high affinity for but haven't followed yet.
  const candidateTopicSlugs = new Set<string>();
  for (const t of profile?.topics ?? []) {
    if (t.effectiveScore > 0.2 && !notInterestedSlugs.has(t.topicSlug)) {
      candidateTopicSlugs.add(t.topicSlug);
    }
  }

  // Also add the topics from the user's top authors' top topics.
  // (Reuses the existing personalization data — no new queries.)
  for (const a of profile?.authors ?? []) {
    // We don't have the author's topics here directly — they're in the
    // authorTopics map in the feed route, not in the profile. Skip for now.
    // A future improvement would be to include author-topics in the profile.
    void a;
  }

  // Fetch the candidate topics (excluding followed + not-interested).
  const candidateSlugsArr = [...candidateTopicSlugs];
  let candidates: any[] = [];
  if (candidateSlugsArr.length > 0) {
    candidates = await db.contentTopic.findMany({
      where: {
        slug: { in: candidateSlugsArr },
        isActive: true,
        id: { notIn: [...followedTopicIdsSet] },
      },
      select: {
        id: true, name: true, slug: true, description: true, isActive: true,
        createdAt: true, updatedAt: true,
        _count: { select: { followers: true } },
      },
      take: maxLimit * 3, // 3× to allow for shuffle + trimming.
    }).catch(() => []);
  }

  // If we don't have enough candidates from the user's interests, fall back
  // to popular topics (still excluding followed + not-interested).
  if (candidates.length < maxLimit) {
    const existingIds = new Set(candidates.map((c) => c.id));
    const fallback = await db.contentTopic.findMany({
      where: {
        isActive: true,
        id: { notIn: [...existingIds, ...followedTopicIdsSet] },
        // Exclude by slug for not-interested (different ID space).
        // (slug is unique, so this is safe.)
        ...(notInterestedSlugs.size > 0 ? {
          NOT: [...notInterestedSlugs].map((slug) => ({ slug })),
        } : {}),
      },
      orderBy: { slug: "asc" },
      take: (maxLimit - candidates.length) * 3,
      select: {
        id: true, name: true, slug: true, description: true, isActive: true,
        createdAt: true, updatedAt: true,
        _count: { select: { followers: true } },
      },
    }).catch(() => []);
    candidates = [...candidates, ...fallback];
  }

  // Sort candidates by the user's interest score (highest first), then by
  // follower count as a tiebreaker.
  const interestOrder = new Map((profile?.topics ?? []).map((t) => [t.topicSlug, t.effectiveScore]));
  candidates.sort((a, b) => {
    const sa = interestOrder.get(a.slug) ?? 0;
    const sb = interestOrder.get(b.slug) ?? 0;
    if (sb !== sa) return sb - sa;
    return (b._count?.followers ?? 0) - (a._count?.followers ?? 0);
  });

  const top = candidates.slice(0, maxLimit);
  return top.map((row) => toTopicDTO(row, userId, followedTopicIdsSet));
}

// ── Topic Following ─────────────────────────────────────────────────────────

/**
 * User follows a topic. Idempotent — if already followed, returns success
 * without creating a duplicate (the @@unique constraint enforces this).
 *
 * @returns the topic that was followed (or already followed).
 */
export async function followTopic(
  userId: string,
  topicSlugOrId: string
): Promise<{ topicId: string; topicSlug: string; alreadyFollowing: boolean }> {
  // Resolve the topic by slug OR ID (returns minimal shape: id, slug, isActive).
  const topic = await resolveTopic(userId, topicSlugOrId);
  if (!topic) {
    throw new Error("Topic not found");
  }
  if (!topic.isActive) {
    throw new Error("Topic is not active");
  }

  // Check if already following (avoids the unique-constraint error path).
  const existing = await db.userTopicFollow.findUnique({
    where: { userId_topicId: { userId, topicId: topic.id } },
    select: { id: true },
  }).catch(() => null);

  if (existing) {
    return { topicId: topic.id, topicSlug: topic.slug, alreadyFollowing: true };
  }

  // Create the follow. The @@unique constraint is the source of truth —
  // if a concurrent request just created it, we swallow the P2002 + return.
  try {
    await db.userTopicFollow.create({
      data: { userId, topicId: topic.id },
    });
  } catch (err: unknown) {
    // P2002 = unique constraint violation. Treat as already-following.
    const code = (err as { code?: string })?.code;
    if (code !== "P2002") {
      logger.error("application", "followTopic failed", {
        error: err instanceof Error ? err.message : String(err),
      });
      throw err;
    }
    return { topicId: topic.id, topicSlug: topic.slug, alreadyFollowing: true };
  }

  // Bump the user's UserInterest.score for this topic (capped at 0.8).
  // This reuses the EXISTING personalization pipeline — the followed topic
  // gets a strong positive signal in the ranker via `interestMatch`.
  try {
    await db.userInterest.upsert({
      where: { userId_topicId: { userId, topicId: topic.id } },
      create: { userId, topicId: topic.id, score: 0.8 },
      update: {
        score: Math.max(0.8, (await db.userInterest.findUnique({
          where: { userId_topicId: { userId, topicId: topic.id } },
          select: { score: true },
        }))?.score ?? 0),
      },
    });
  } catch {
    // Non-fatal — the follow itself succeeded. The interest score is a
    // secondary signal; if upsert fails (e.g. DB hiccup), the follow still
    // affects the ranker via the followedTopicBoost component (Phase 2 new).
  }

  // Invalidate the interest profile cache so the next feed request picks
  // up the new follow.
  try {
    const { invalidateProfileCache } = await import("@/lib/feed/interest-profile");
    invalidateProfileCache(userId);
  } catch {
    // best-effort
  }

  return { topicId: topic.id, topicSlug: topic.slug, alreadyFollowing: false };
}

/**
 * User unfollows a topic. Idempotent — if not following, returns success.
 *
 * Does NOT zero out the UserInterest score — preserves the user's organic
 * interaction history. The user can re-follow later without losing their
 * affinity.
 */
export async function unfollowTopic(
  userId: string,
  topicSlugOrId: string
): Promise<{ topicId: string; wasFollowing: boolean }> {
  // Resolve the topic by slug OR ID.
  const topic = await resolveTopic(userId, topicSlugOrId, { includeInactive: true });
  if (!topic) {
    throw new Error("Topic not found");
  }

  // Delete the follow. If it doesn't exist, deleteMany returns count=0.
  const result = await db.userTopicFollow.deleteMany({
    where: { userId, topicId: topic.id },
  }).catch((err) => {
    logger.error("application", "unfollowTopic failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    throw err;
  });

  // Invalidate the interest profile cache.
  try {
    const { invalidateProfileCache } = await import("@/lib/feed/interest-profile");
    invalidateProfileCache(userId);
  } catch {
    // best-effort
  }

  return { topicId: topic.id, wasFollowing: result.count > 0 };
}

/**
 * Get the set of topic IDs the current user follows. Used by the feed ranker
 * to compute followedTopicBoost.
 *
 * Returns a Set<string> of topic IDs. Empty when the user follows no topics
 * or on error (best-effort).
 */
export async function getFollowedTopicIds(userId: string): Promise<Set<string>> {
  const follows = await db.userTopicFollow.findMany({
    where: { userId },
    select: { topicId: true },
  }).catch(() => []);
  return new Set(follows.map((f) => f.topicId));
}

// ── Topic Content ───────────────────────────────────────────────────────────

/**
 * Get posts + articles for a topic, paginated. Used by the /topics/[slug]/content
 * API + the extended /topics/[tag] SSR route.
 *
 * Returns the IDs + minimal fields for posts + articles. The caller is
 * responsible for hydrating with author info + counts (the unified feed
 * pattern).
 *
 * PERFORMANCE: 2 queries (posts + articles), each bounded by `take: limit+1`.
 */
export async function getContentForTopic(
  topicId: string,
  opts: { limit?: number; cursor?: string | null } = {}
): Promise<{
  posts: { id: string; createdAt: Date }[];
  articles: { id: string; publishedAt: Date | null }[];
  nextCursor: string | null;
}> {
  const limit = Math.min(Math.max(opts.limit ?? 20, 1), 50);

  // Fetch posts with this topic, newest first.
  const posts = await db.postTopic.findMany({
    where: { topicId },
    orderBy: { post: { createdAt: "desc" } },
    take: limit + 1,
    select: { post: { select: { id: true, createdAt: true } } },
  }).catch(() => []);

  // Fetch published articles with this topic, newest first.
  const articles = await db.articleTopic.findMany({
    where: { topicId, article: { status: "PUBLISHED", publishedAt: { not: null } } },
    orderBy: { article: { publishedAt: "desc" } },
    take: limit + 1,
    select: { article: { select: { id: true, publishedAt: true } } },
  }).catch(() => []);

  const hasMorePosts = posts.length > limit;
  const hasMoreArticles = articles.length > limit;
  const trimmedPosts = hasMorePosts ? posts.slice(0, limit) : posts;
  const trimmedArticles = hasMoreArticles ? articles.slice(0, limit) : articles;

  return {
    posts: trimmedPosts.map((p) => ({ id: p.post.id, createdAt: p.post.createdAt })),
    articles: trimmedArticles.map((a) => ({
      id: a.article.id,
      publishedAt: a.article.publishedAt,
    })),
    nextCursor: (hasMorePosts || hasMoreArticles) ? "more" : null,
  };
}

// ── Admin Operations ───────────────────────────────────────────────────────

/**
 * Create a new topic. The slug is auto-generated from the name (or the
 * admin-supplied slug is normalized). The unique constraint on slug is the
 * deduplication mechanism — if a topic with the same slug already exists,
 * we return the existing one instead of erroring.
 *
 * SECURITY: caller MUST verify `requireAdmin()` before invoking this.
 */
export async function adminCreateTopic(opts: {
  name: string;
  description?: string | null;
  slug?: string | null;
  isActive?: boolean;
}): Promise<TopicDTO> {
  if (!isValidTopicName(opts.name)) {
    throw new Error("Invalid topic name (must be 2-100 chars, no control chars).");
  }

  // Generate the slug from the name if not provided, else normalize.
  const slug = normalizeTopicSlug(opts.slug ?? opts.name);
  if (!isValidTopicSlug(slug)) {
    throw new Error("Invalid topic slug (must be 2-80 chars, URL-safe).");
  }

  // Check if a topic with this slug already exists — if so, return it
  // (deduplication: the admin can't accidentally create two "Football"
  // topics with different IDs but the same slug).
  const existing = await db.contentTopic.findUnique({
    where: { slug },
    select: {
      id: true, name: true, slug: true, description: true, isActive: true,
      createdAt: true, updatedAt: true,
      _count: { select: { followers: true } },
    },
  }).catch(() => null);

  if (existing) {
    // Update name + description if provided (admin can fix typos).
    const updated = await db.contentTopic.update({
      where: { id: existing.id },
      data: {
        name: opts.name.trim(),
        description: opts.description ?? existing.description,
        ...(typeof opts.isActive === "boolean" ? { isActive: opts.isActive } : {}),
      },
      select: {
        id: true, name: true, slug: true, description: true, isActive: true,
        createdAt: true, updatedAt: true,
        _count: { select: { followers: true } },
      },
    });
    return toTopicDTO(updated, null, null);
  }

  // Create the new topic. The @@unique constraint on slug is the final
  // defense — if a concurrent request just created it, we swallow P2002 +
  // re-fetch.
  try {
    const created = await db.contentTopic.create({
      data: {
        name: opts.name.trim(),
        slug,
        description: opts.description ?? null,
        isActive: opts.isActive ?? true,
      },
      select: {
        id: true, name: true, slug: true, description: true, isActive: true,
        createdAt: true, updatedAt: true,
        _count: { select: { followers: true } },
      },
    });
    return toTopicDTO(created, null, null);
  } catch (err: unknown) {
    const code = (err as { code?: string })?.code;
    if (code === "P2002") {
      // Race condition — re-fetch + return.
      const race = await db.contentTopic.findUnique({
        where: { slug },
        select: {
          id: true, name: true, slug: true, description: true, isActive: true,
          createdAt: true, updatedAt: true,
          _count: { select: { followers: true } },
        },
      });
      if (race) return toTopicDTO(race, null, null);
    }
    throw err;
  }
}

/**
 * Update an existing topic. Admin-only — caller MUST verify `requireAdmin()`.
 *
 * The slug CANNOT be changed once the topic has follower relationships
 * (would break indexed URLs). The slug CAN be changed when the topic has
 * no followers (new topic, admin typo fix).
 */
export async function adminUpdateTopic(
  topicId: string,
  opts: {
    name?: string;
    description?: string | null;
    isActive?: boolean;
    slug?: string;
  }
): Promise<TopicDTO> {
  const existing = await db.contentTopic.findUnique({
    where: { id: topicId },
    select: { id: true, slug: true, _count: { select: { followers: true } } },
  });
  if (!existing) throw new Error("Topic not found");

  const data: {
    name?: string;
    description?: string | null;
    isActive?: boolean;
    slug?: string;
  } = {};

  if (opts.name !== undefined) {
    if (!isValidTopicName(opts.name)) {
      throw new Error("Invalid topic name.");
    }
    data.name = opts.name.trim();
  }
  if (opts.description !== undefined) {
    data.description = opts.description;
  }
  if (typeof opts.isActive === "boolean") {
    data.isActive = opts.isActive;
  }
  if (opts.slug !== undefined) {
    const newSlug = normalizeTopicSlug(opts.slug);
    if (!isValidTopicSlug(newSlug)) {
      throw new Error("Invalid topic slug.");
    }
    if (newSlug !== existing.slug) {
      // Only allow slug changes when the topic has no followers (avoid
      // breaking indexed URLs / follows).
      if (existing._count.followers > 0) {
        throw new Error("Cannot change slug of a topic with followers (would break indexed URLs).");
      }
      data.slug = newSlug;
    }
  }

  const updated = await db.contentTopic.update({
    where: { id: topicId },
    data,
    select: {
      id: true, name: true, slug: true, description: true, isActive: true,
      createdAt: true, updatedAt: true,
      _count: { select: { followers: true } },
    },
  });
  return toTopicDTO(updated, null, null);
}

/**
 * Deactivate a topic (soft-delete). Admin-only.
 * Sets isActive=false. Existing relationships preserved (can be reactivated).
 */
export async function adminDeactivateTopic(topicId: string): Promise<void> {
  await db.contentTopic.update({
    where: { id: topicId },
    data: { isActive: false },
  });
}

// ── Internal: resolve topic by slug OR ID ───────────────────────────────────

async function resolveTopic(
  _userId: string,
  slugOrId: string,
  opts: { includeInactive?: boolean } = {}
): Promise<{ id: string; slug: string; isActive: boolean } | null> {
  // Try slug first (most common case).
  const normalized = normalizeTopicSlug(slugOrId);
  if (normalized && isValidTopicSlug(normalized)) {
    const bySlug = await db.contentTopic.findUnique({
      where: { slug: normalized },
      select: { id: true, slug: true, isActive: true },
    });
    if (bySlug && (bySlug.isActive || opts.includeInactive)) {
      return bySlug;
    }
  }
  // Fall back to ID lookup (cuid).
  const byId = await db.contentTopic.findUnique({
    where: { id: slugOrId },
    select: { id: true, slug: true, isActive: true },
  });
  if (byId && (byId.isActive || opts.includeInactive)) {
    return byId;
  }
  return null;
}

// ── Phase 2.1 — Content Topic Assignment & Sync ────────────────────────────

/**
 * Maximum number of Topics that can be assigned to a single content item
 * (Article or Post). Server-side enforced — never trust the client.
 *
 * Conservative default: 5. Enough for meaningful categorization without
 * enabling topic-spam (assigning 50 topics to game the ranking).
 */
export const MAX_TOPICS_PER_CONTENT = 5;

/**
 * Validate a list of topic IDs supplied by the client for content assignment.
 *
 * Returns `{ ok: true, topicIds: validated[] }` when all IDs are valid:
 *   - non-empty array (or empty array — explicitly clearing topics is allowed)
 *   - each ID is a non-empty string
 *   - deduplicated (client may send duplicates; we silently dedupe)
 *   - count ≤ MAX_TOPICS_PER_CONTENT
 *   - each ID corresponds to an EXISTING + ACTIVE ContentTopic
 *
 * Returns `{ ok: false, error: string }` when validation fails. The error
 * message is safe to return to the client (no internal details leaked).
 *
 * SECURITY:
 *   - Server-side only — never trust client validation.
 *   - Each topic ID is checked against the DB (existence + active state).
 *   - The caller MUST pass the authenticated user's ID for audit logging
 *     (not used for validation, but required for the function signature to
 *     discourage misuse).
 *
 * @param rawTopicIds - the topic IDs from the client request body.
 * @returns the validated topic IDs (deduplicated, ≤ MAX_TOPICS_PER_CONTENT),
 *          or an error message.
 */
export async function validateTopicIds(
  rawTopicIds: unknown
): Promise<{ ok: true; topicIds: string[] } | { ok: false; error: string }> {
  // Accept undefined / null / missing field → empty array (no topics).
  // This is the common case for content without topics.
  if (rawTopicIds === undefined || rawTopicIds === null) {
    return { ok: true, topicIds: [] };
  }
  if (!Array.isArray(rawTopicIds)) {
    return { ok: false, error: "topicIds must be an array of strings." };
  }
  // Deduplicate + filter invalid entries (non-string, empty, whitespace-only).
  const seen = new Set<string>();
  const deduped: string[] = [];
  for (const id of rawTopicIds) {
    if (typeof id !== "string") {
      return { ok: false, error: "Each topicId must be a string." };
    }
    const trimmed = id.trim();
    if (!trimmed) continue; // skip empty strings silently
    if (seen.has(trimmed)) continue; // dedupe
    seen.add(trimmed);
    deduped.push(trimmed);
  }
  // Enforce the per-content limit (after dedup, so duplicates don't count).
  if (deduped.length > MAX_TOPICS_PER_CONTENT) {
    return {
      ok: false,
      error: `Cannot assign more than ${MAX_TOPICS_PER_CONTENT} topics to a single content item.`,
    };
  }
  // Empty array is valid (explicitly clearing topics).
  if (deduped.length === 0) {
    return { ok: true, topicIds: [] };
  }
  // Verify each ID exists + is active in the DB. ONE batched query.
  const topics = await db.contentTopic.findMany({
    where: { id: { in: deduped }, isActive: true },
    select: { id: true },
  }).catch(() => []);
  const validIds = new Set(topics.map((t) => t.id));
  // If any supplied ID doesn't match an active topic, reject the WHOLE
  // request. We don't silently drop invalid IDs because that would let
  // clients probe which IDs are valid (info leak). Better to fail fast
  // with a clear error.
  for (const id of deduped) {
    if (!validIds.has(id)) {
      return {
        ok: false,
        error: "One or more topicIds are invalid or refer to inactive topics.",
      };
    }
  }
  return { ok: true, topicIds: deduped };
}

/**
 * Synchronize a content item's topic relationships to match the supplied
 * `desiredTopicIds`. Used by both Article + Post create/update routes.
 *
 * Behavior:
 *   - Fetches the CURRENT relationships for the content item.
 *   - Computes the diff: topics to ADD (in desired, not in current),
 *     topics to REMOVE (in current, not in desired).
 *   - If no changes needed, returns early (no DB writes).
 *   - Otherwise, performs the deletes + creates in a SINGLE transaction.
 *     If either fails, the transaction rolls back (no orphan relations).
 *
 * The `@@unique([contentType, topicId])` constraint prevents duplicates
 * at the DB level. We also dedupe on the client side (validateTopicIds)
 * so the constraint should never fire — but it's the safety net.
 *
 * SECURITY: the caller MUST have already verified ownership of the content
 * item. This function does NOT re-check ownership (it's the caller's
 * responsibility).
 *
 * @param contentType - "article" | "post".
 * @param contentId - the content item's ID.
 * @param desiredTopicIds - the validated topic IDs to assign (replaces ALL existing).
 */
export async function syncContentTopics(
  contentType: "article" | "post",
  contentId: string,
  desiredTopicIds: string[]
): Promise<void> {
  if (contentType === "article") {
    // Fetch current ArticleTopic relationships for this article.
    const current = await db.articleTopic.findMany({
      where: { articleId: contentId },
      select: { topicId: true },
    }).catch(() => []);
    const currentIds = new Set(current.map((r) => r.topicId));
    const desiredIds = new Set(desiredTopicIds);

    // Compute diff.
    const toAdd = desiredTopicIds.filter((id) => !currentIds.has(id));
    const toRemove = [...currentIds].filter((id) => !desiredIds.has(id));

    if (toAdd.length === 0 && toRemove.length === 0) {
      return; // no changes — skip DB writes
    }

    // Perform the sync in a single transaction.
    await db.$transaction(async (tx) => {
      if (toRemove.length > 0) {
        await tx.articleTopic.deleteMany({
          where: { articleId: contentId, topicId: { in: toRemove } },
        });
      }
      if (toAdd.length > 0) {
        // createMany with skipDuplicates = false because we already deduped
        // + validated. If the @@unique constraint fires (P2002), it means a
        // concurrent request just created the same relation — we want the
        // transaction to fail so the caller can retry.
        await tx.articleTopic.createMany({
          data: toAdd.map((topicId) => ({ articleId: contentId, topicId })),
        });
      }
    }).catch((err) => {
      // P2002 (unique constraint) — concurrent request created the same
      // relation. This is fine — the relation exists, which is the desired
      // state. Log + continue.
      const code = (err as { code?: string })?.code;
      if (code !== "P2002") throw err;
      logger.warn("application", "syncContentTopics: P2002 on ArticleTopic create (concurrent)", {
        articleId: contentId,
        topicIds: toAdd,
      });
    });
    return;
  }

  // contentType === "post" — same logic, different table.
  const current = await db.postTopic.findMany({
    where: { postId: contentId },
    select: { topicId: true },
  }).catch(() => []);
  const currentIds = new Set(current.map((r) => r.topicId));
  const desiredIds = new Set(desiredTopicIds);

  const toAdd = desiredTopicIds.filter((id) => !currentIds.has(id));
  const toRemove = [...currentIds].filter((id) => !desiredIds.has(id));

  if (toAdd.length === 0 && toRemove.length === 0) {
    return;
  }

  await db.$transaction(async (tx) => {
    if (toRemove.length > 0) {
      await tx.postTopic.deleteMany({
        where: { postId: contentId, topicId: { in: toRemove } },
      });
    }
    if (toAdd.length > 0) {
      await tx.postTopic.createMany({
        data: toAdd.map((topicId) => ({ postId: contentId, topicId })),
      });
    }
  }).catch((err) => {
    const code = (err as { code?: string })?.code;
    if (code !== "P2002") throw err;
    logger.warn("application", "syncContentTopics: P2002 on PostTopic create (concurrent)", {
      postId: contentId,
      topicIds: toAdd,
    });
  });
}

/**
 * Fetch the topic IDs for a batch of content items (Articles or Posts).
 * Used by the unified feed route to populate the `authorTopicIds` map
 * (which despite the name is keyed by CONTENT ID, not author ID — see
 * the ranker's scoreAndRankContent).
 *
 * PERFORMANCE: 1 batched query per content type (so 2 queries total for a
 * mixed feed). Uses the `@@index([articleId])` / `@@index([postId])`
 * indexes. Returns a Map<contentId, topicIds[]>.
 *
 * @param contentType - "article" | "post".
 * @param contentIds - the content IDs to fetch topics for.
 * @returns Map<contentId, topicId[]> — empty array for content with no topics.
 */
export async function batchGetContentTopicIds(
  contentType: "article" | "post",
  contentIds: string[]
): Promise<Map<string, string[]>> {
  const out = new Map<string, string[]>();
  if (contentIds.length === 0) return out;

  if (contentType === "article") {
    const rows = await db.articleTopic.findMany({
      where: { articleId: { in: contentIds } },
      select: { articleId: true, topicId: true },
    }).catch(() => []);
    for (const r of rows) {
      const arr = out.get(r.articleId) ?? [];
      arr.push(r.topicId);
      out.set(r.articleId, arr);
    }
  } else {
    const rows = await db.postTopic.findMany({
      where: { postId: { in: contentIds } },
      select: { postId: true, topicId: true },
    }).catch(() => []);
    for (const r of rows) {
      const arr = out.get(r.postId) ?? [];
      arr.push(r.topicId);
      out.set(r.postId, arr);
    }
  }
  return out;
}

/**
 * Fetch the topic IDs for a single content item. Used by the GET /articles/[id]
 * + GET /posts/[id] routes to include `topicIds` in the response DTO.
 *
 * @param contentType - "article" | "post".
 * @param contentId - the content item's ID.
 * @returns array of topic IDs (empty when content has no topics or on error).
 */
export async function getContentTopicIds(
  contentType: "article" | "post",
  contentId: string
): Promise<string[]> {
  const map = await batchGetContentTopicIds(contentType, [contentId]);
  return map.get(contentId) ?? [];
}

