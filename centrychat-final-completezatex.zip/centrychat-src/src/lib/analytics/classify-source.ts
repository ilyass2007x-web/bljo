/**
 * Traffic source classification.
 *
 * Converts a raw referrer URL into a structured { source, medium } pair.
 *
 * Classification rules (spec §23):
 *   - google.com / google.co.uk / google.fr / www.google.com / images.google.com
 *       → source="google",     medium="search"
 *   - bing.com                → source="bing",       medium="search"
 *   - yahoo.com               → source="yahoo",      medium="search"
 *   - duckduckgo.com          → source="duckduckgo", medium="search"
 *   - facebook.com / l.facebook.com / m.facebook.com / fb.me
 *       → source="facebook",  medium="social"
 *   - instagram.com           → source="instagram",  medium="social"
 *   - tiktok.com              → source="tiktok",     medium="social"
 *   - youtube.com / youtu.be  → source="youtube",    medium="social"
 *   - reddit.com              → source="reddit",     medium="social"
 *   - x.com / twitter.com / t.co
 *       → source="x",         medium="social"
 *   - linkedin.com            → source="linkedin",   medium="social"
 *   - Any other http(s) referrer → source=<hostname>, medium="referral"
 *   - Empty / null referrer   → source="direct",     medium="direct"
 *
 * SECURITY:
 *   - Uses URL parsing (NOT substring matching) to avoid false positives.
 *   - Validates the referrer is http(s) — rejects javascript:, data:, etc.
 *   - Length-caps at 2048 chars (defensive — browsers usually cap at ~2000).
 *
 * UTM SUPPORT (spec §24):
 *   - When UTM parameters are present in the page URL (NOT the referrer),
 *     they take PRECEDENCE over the referrer-based classification.
 *     This is handled by the caller (track.ts), not here.
 */

export type TrafficMedium =
  | "direct"
  | "search"
  | "social"
  | "referral"
  | "email"
  | "unknown";

export interface ClassifiedTraffic {
  /** Short identifier: "google", "facebook", "direct", "referral", etc. */
  source: string;
  /** Coarse category: "direct" | "search" | "social" | "referral" | "email" | "unknown" */
  medium: TrafficMedium;
}

// ── Known host → source/medium mapping ──────────────────────────────────
//
// Each entry is { hosts: string[], source: string, medium: TrafficMedium }.
// A referrer hostname matches when it ENDS WITH any of the listed suffixes
// (so "google.com" matches "www.google.com", "images.google.com", etc.).
//
// We use endswith() (not includes()) so "evilgoogle.com" does NOT match
// "google.com". This is the safe pattern.

interface SourceRule {
  hosts: string[];
  source: string;
  medium: TrafficMedium;
}

const SOURCE_RULES: SourceRule[] = [
  // ── Search engines ──
  {
    hosts: ["google.com", "google.co.uk", "google.fr", "google.de", "google.es",
            "google.ca", "google.com.au", "google.it", "google.com.br",
            "google.co.jp", "google.co.in", "google.com.mx", "google.nl",
            "google.com.tr", "google.com.sa", "google.com.eg", "google.ae",
            "google.com.pk", "google.co.id", "google.com.sg"],
    source: "google",
    medium: "search",
  },
  { hosts: ["bing.com"], source: "bing", medium: "search" },
  { hosts: ["yahoo.com", "search.yahoo.com"], source: "yahoo", medium: "search" },
  { hosts: ["duckduckgo.com"], source: "duckduckgo", medium: "search" },
  { hosts: ["baidu.com"], source: "baidu", medium: "search" },
  { hosts: ["yandex.com", "yandex.ru"], source: "yandex", medium: "search" },
  { hosts: ["ecosia.org"], source: "ecosia", medium: "search" },
  // ── Social ──
  {
    hosts: ["facebook.com", "l.facebook.com", "m.facebook.com",
            "fb.com", "fb.me"],
    source: "facebook",
    medium: "social",
  },
  { hosts: ["instagram.com", "l.instagram.com"], source: "instagram", medium: "social" },
  { hosts: ["tiktok.com", "m.tiktok.com"], source: "tiktok", medium: "social" },
  { hosts: ["youtube.com", "youtu.be", "m.youtube.com"], source: "youtube", medium: "social" },
  { hosts: ["reddit.com", "old.reddit.com", "m.reddit.com"], source: "reddit", medium: "social" },
  { hosts: ["x.com", "twitter.com", "t.co"], source: "x", medium: "social" },
  { hosts: ["linkedin.com"], source: "linkedin", medium: "social" },
  { hosts: ["pinterest.com", "pin.it", "pinterest.co.uk"], source: "pinterest", medium: "social" },
  { hosts: ["telegram.org", "t.me"], source: "telegram", medium: "social" },
  { hosts: ["whatsapp.com", "wa.me"], source: "whatsapp", medium: "social" },
  { hosts: ["discord.com", "discord.gg"], source: "discord", medium: "social" },
  { hosts: ["threads.net"], source: "threads", medium: "social" },
  // ── Email providers (rare as referrers, but classified for completeness) ──
  { hosts: ["mail.google.com", "outlook.live.com", "mail.yahoo.com"], source: "email", medium: "email" },
];

// ── Public API ──────────────────────────────────────────────────────────

/**
 * Classify a referrer URL into { source, medium }.
 *
 * @param referrer - The raw document.referrer value (or empty string / null).
 * @returns { source, medium } — always returns a value, never throws.
 *
 * Examples:
 *   classifyTrafficSource("https://www.google.com/search?q=hello")
 *     → { source: "google", medium: "search" }
 *   classifyTrafficSource("https://m.facebook.com/story.php?story_fbid=123")
 *     → { source: "facebook", medium: "social" }
 *   classifyTrafficSource("https://example.com/some-page")
 *     → { source: "example.com", medium: "referral" }
 *   classifyTrafficSource("")
 *     → { source: "direct", medium: "direct" }
 *   classifyTrafficSource(null)
 *     → { source: "direct", medium: "direct" }
 */
export function classifyTrafficSource(referrer: string | null | undefined): ClassifiedTraffic {
  // Empty / null → direct.
  if (!referrer || typeof referrer !== "string") {
    return { source: "direct", medium: "direct" };
  }
  const trimmed = referrer.trim();
  if (!trimmed) {
    return { source: "direct", medium: "direct" };
  }
  // Length cap — defensive (browsers usually cap referrers at ~2000 chars).
  if (trimmed.length > 2048) {
    return { source: "direct", medium: "direct" };
  }

  // Parse the URL safely. Invalid URLs → direct.
  let url: URL;
  try {
    url = new URL(trimmed);
  } catch {
    return { source: "direct", medium: "direct" };
  }

  // Only http(s) referrers are classified. javascript:, data:, file:, etc.
  // are treated as direct (they're not real referrers).
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    return { source: "direct", medium: "direct" };
  }

  const hostname = url.hostname.toLowerCase();

  // Match against the known source rules. endswith() prevents false positives
  // (e.g. "evilgoogle.com" does NOT match "google.com").
  for (const rule of SOURCE_RULES) {
    for (const host of rule.hosts) {
      if (hostname === host || hostname.endsWith("." + host)) {
        return { source: rule.source, medium: rule.medium };
      }
    }
  }

  // Unknown host → referral. The source is the hostname (without "www."
  // prefix, for cleaner display in the admin dashboard).
  const cleanHost = hostname.startsWith("www.") ? hostname.slice(4) : hostname;
  return { source: cleanHost, medium: "referral" };
}

/**
 * Extract the display hostname from a referrer URL (for the "Top Referrers"
 * section). Strips "www.", "l.", "m." prefixes. Returns null for invalid
 * or non-http(s) referrers.
 *
 * Examples:
 *   extractReferrerDomain("https://www.google.com/search?q=hello") → "google.com"
 *   extractReferrerDomain("https://l.facebook.com/story.php")       → "facebook.com"
 *   extractReferrerDomain("")                                        → null
 */
export function extractReferrerDomain(referrer: string | null | undefined): string | null {
  if (!referrer || typeof referrer !== "string") return null;
  const trimmed = referrer.trim();
  if (!trimmed || trimmed.length > 2048) return null;
  try {
    const url = new URL(trimmed);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    let hostname = url.hostname.toLowerCase();
    // Strip common subdomain prefixes used by social platforms for their
    // link redirectors (l.facebook.com, m.facebook.com, t.co, etc.).
    for (const prefix of ["www.", "l.", "m.", "old.", "mobile."]) {
      if (hostname.startsWith(prefix)) {
        const stripped = hostname.slice(prefix.length);
        // Only strip if the result still has a dot (avoid stripping "m." from
        // a hostname like "m.com" — unlikely but defensive).
        if (stripped.includes(".")) {
          hostname = stripped;
          break;
        }
      }
    }
    return hostname;
  } catch {
    return null;
  }
}

// ── Source → color mapping (centralized, spec §22) ─────────────────────

/**
 * Get a consistent color for a traffic source. Used by both the admin UI
 * (charts + legends) and the export (CSV/JSON doesn't use colors, but the
 * admin preview does).
 *
 * Color system (spec §22):
 *   - Search engines → blue/green
 *   - Social         → purple/blue
 *   - Direct         → neutral gray
 *   - Referral       → orange
 *   - Email          → amber
 *   - Unknown        → gray
 *
 * Returns a hex color string. The mapping is centralized so changing a
 * color here updates every chart.
 */
export function getSourceColor(source: string, medium: TrafficMedium): string {
  // Specific source colors (brand-recognizable where possible).
  const SOURCE_COLORS: Record<string, string> = {
    google: "#4285F4",      // Google blue
    bing: "#00897B",        // teal
    yahoo: "#6001D2",       // Yahoo purple
    duckduckgo: "#DE5833",  // DDG red-orange
    baidu: "#2932E1",       // Baidu blue
    yandex: "#FF0000",      // Yandex red
    facebook: "#1877F2",    // Facebook blue
    instagram: "#E4405F",   // Instagram pink
    tiktok: "#000000",      // TikTok black (rendered with a lighter variant in dark mode)
    youtube: "#FF0000",     // YouTube red
    reddit: "#FF4500",      // Reddit orange
    x: "#000000",           // X black
    twitter: "#1DA1F2",     // Twitter blue (legacy)
    linkedin: "#0A66C2",    // LinkedIn blue
    pinterest: "#BD081C",   // Pinterest red
    telegram: "#0088CC",    // Telegram blue
    whatsapp: "#25D366",    // WhatsApp green
    discord: "#5865F2",     // Discord blurple
    threads: "#000000",     // Threads black
  };
  if (SOURCE_COLORS[source]) {
    return SOURCE_COLORS[source]!;
  }
  // Fallback by medium.
  switch (medium) {
    case "search":   return "#4285F4";  // blue
    case "social":   return "#8B5CF6";  // purple
    case "referral": return "#F59E0B";  // orange/amber
    case "email":    return "#F59E0B";  // amber
    case "direct":   return "#64748B";  // slate gray
    case "unknown":  return "#94A3B8";  // light gray
    default:         return "#94A3B8";
  }
}

/**
 * Get a human-friendly display label for a source.
 *   "google" → "Google"
 *   "facebook" → "Facebook"
 *   "x" → "X / Twitter"
 *   "direct" → "Direct"
 *   custom hostname → the hostname as-is
 */
export function getSourceLabel(source: string): string {
  const LABELS: Record<string, string> = {
    direct: "Direct",
    google: "Google",
    bing: "Bing",
    yahoo: "Yahoo",
    duckduckgo: "DuckDuckGo",
    baidu: "Baidu",
    yandex: "Yandex",
    ecosia: "Ecosia",
    facebook: "Facebook",
    instagram: "Instagram",
    tiktok: "TikTok",
    youtube: "YouTube",
    reddit: "Reddit",
    x: "X / Twitter",
    twitter: "Twitter",
    linkedin: "LinkedIn",
    pinterest: "Pinterest",
    telegram: "Telegram",
    whatsapp: "WhatsApp",
    discord: "Discord",
    threads: "Threads",
    email: "Email",
  };
  return LABELS[source] ?? source;
}

// ── Internal-source detection (spec §7) ─────────────────────────────────

/**
 * Detect whether a referrer URL belongs to the same site (internal traffic).
 *
 * Per spec §7: when the referrer's hostname matches the current site's
 * hostname, the visit should be classified as "internal" (not "referral").
 * Examples:
 *   - homepage → article (referrer = https://yoursite.com/)
 *   - topic page → article (referrer = https://yoursite.com/topics/foo)
 *   - profile → article (referrer = https://yoursite.com/?view=profile)
 *
 * The check uses the request's `Host` header (the server-side equivalent
 * of `window.location.host`). On Netlify, the Host header is set
 * correctly to the deployment domain (e.g. "yoursite.netlify.app" or
 * the custom domain).
 *
 * @param referrer - The raw document.referrer / Referer header value.
 * @param currentHost - The current site's hostname (from request headers).
 * @returns true if the referrer is on the same host (internal).
 */
export function isInternalReferrer(
  referrer: string | null | undefined,
  currentHost: string | null | undefined
): boolean {
  if (!referrer || !currentHost) return false;
  const trimmed = referrer.trim();
  if (!trimmed || trimmed.length > 2048) return false;
  try {
    const url = new URL(trimmed);
    if (url.protocol !== "http:" && url.protocol !== "https:") return false;
    const refHost = url.hostname.toLowerCase();
    const myHost = currentHost.toLowerCase().split(":")[0]!;
    // Match exact hostname + common "www." prefix variants.
    return (
      refHost === myHost ||
      refHost === `www.${myHost}` ||
      myHost.startsWith("www.") && refHost === myHost.slice(4)
    );
  } catch {
    return false;
  }
}

/**
 * Classify a referrer URL into { source, medium, referralDomain }, taking
 * the current site's hostname into account so same-site referrers are
 * classified as "internal" rather than "referral".
 *
 * This is the same as classifyTrafficSource() but with the additional
 * internal-source detection (spec §7). Used by the article view-tracking
 * endpoint so the ArticleView.source column carries the correct
 * "internal" / "direct" / "google" / etc. label.
 *
 * @param referrer - The raw referrer string (document.referrer / Referer header).
 * @param currentHost - The current site's hostname (for internal-source detection).
 * @returns { source, medium, referralDomain }
 *   - source: "internal" when same-site, otherwise same as classifyTrafficSource.
 *   - medium: "direct" | "internal" | "search" | "social" | "referral" | "email" | "unknown"
 *   - referralDomain: the normalized domain of the external referrer (null for
 *     direct / internal).
 */
export function classifyWithInternal(
  referrer: string | null | undefined,
  currentHost: string | null | undefined
): {
  source: string;
  medium: TrafficMedium;
  referralDomain: string | null;
} {
  // Check internal first (spec §7).
  if (isInternalReferrer(referrer, currentHost)) {
    return { source: "internal", medium: "direct", referralDomain: null };
  }
  const classified = classifyTrafficSource(referrer);
  // For external referrers, extract the normalized domain.
  const referralDomain =
    classified.medium === "direct"
      ? null
      : extractReferrerDomain(referrer);
  return {
    source: classified.source,
    medium: classified.medium,
    referralDomain,
  };
}

/**
 * Get a human-friendly display label for a source — extended with the
 * "Internal" + "Unknown" labels (used by the ArticleView source column).
 */
export function getSourceLabelExtended(source: string): string {
  if (source === "internal") return "Internal";
  if (source === "unknown") return "Unknown";
  return getSourceLabel(source);
}
