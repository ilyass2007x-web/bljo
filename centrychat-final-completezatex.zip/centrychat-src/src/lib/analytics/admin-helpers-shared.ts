/**
 * Admin Analytics — SHARED (client-safe) pure helpers.
 * =====================================================
 *
 * This module contains ONLY pure functions + types (no DB imports, no
 * server-only imports). It is safe to import from BOTH server and client
 * components.
 *
 * Why this file exists:
 *   The full `@/lib/analytics/admin-helpers.ts` imports `db` from
 *   `@/lib/database`, which imports `PrismaClient` from `@prisma/client`.
 *   When a Client Component (e.g. admin analytics charts) imports
 *   `formatBucketLabel` from `@/lib/analytics/admin-helpers`, webpack
 *   bundles the whole module — including `db` — into the browser chunk.
 *   PrismaClient then throws "PrismaClient is unable to run in this
 *   browser environment" at runtime, which propagates up to the
 *   global-error.tsx boundary and shows the "Something went wrong" page
 *   to every visitor.
 *
 *   Splitting the pure parts into this shared file lets client
 *   components import the helpers they need WITHOUT pulling Prisma into
 *   the browser bundle.
 */

// ── Types ───────────────────────────────────────────────────────────────

export type AnalyticsRange =
  | "today"
  | "yesterday"
  | "7d"
  | "30d"
  | "90d"
  | "1y"
  | "custom";

export interface DateRange {
  start: Date;
  end: Date;
  /** The range before this one (for growth % comparison). */
  prevStart: Date;
  prevEnd: Date;
  /** The bucket size for time-series charts (hour/day/month). */
  bucket: "hour" | "day" | "month";
  /** Label for display ("Last 7 days", "Today", etc.). */
  label: string;
}

// ── Range parsing (pure) ───────────────────────────────────────────────

/**
 * Parse a range string into a DateRange.
 *
 * Supported ranges:
 *   - "today"     → [start of today, now]               (hourly buckets)
 *   - "yesterday" → [start of yesterday, end of yesterday] (hourly buckets)
 *   - "7d"        → [now - 7 days, now]                  (daily buckets)
 *   - "30d"       → [now - 30 days, now]                 (daily buckets)
 *   - "90d"       → [now - 90 days, now]                 (daily buckets)
 *   - "1y"        → [now - 365 days, now]                (monthly buckets)
 *   - "custom"    → requires ?start=ISO&end=ISO          (daily buckets)
 *
 * The "previous period" is the same-length range IMMEDIATELY BEFORE the
 * current range. For 30d: current = [now-30d, now], prev = [now-60d, now-30d].
 *
 * NEVER throws — on invalid input, falls back to "30d".
 */
export function parseRange(
  range: string | null | undefined,
  customStart?: string | null,
  customEnd?: string | null
): DateRange {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const tomorrow = new Date(today.getTime() + 24 * 60 * 60 * 1000);

  // Custom range.
  if (range === "custom" && customStart && customEnd) {
    try {
      const start = new Date(customStart);
      const end = new Date(customEnd);
      if (!isNaN(start.getTime()) && !isNaN(end.getTime()) && start < end) {
        const rangeMs = end.getTime() - start.getTime();
        return {
          start,
          end,
          prevStart: new Date(start.getTime() - rangeMs),
          prevEnd: start,
          bucket: rangeMs > 90 * 24 * 60 * 60 * 1000 ? "month" : "day",
          label: `${start.toLocaleDateString()} – ${end.toLocaleDateString()}`,
        };
      }
    } catch {
      // Fall through to 30d default.
    }
  }

  switch (range) {
    case "today":
      return {
        start: today,
        end: now,
        prevStart: new Date(today.getTime() - 24 * 60 * 60 * 1000),
        prevEnd: today,
        bucket: "hour",
        label: "Today",
      };
    case "yesterday":
      return {
        start: new Date(today.getTime() - 24 * 60 * 60 * 1000),
        end: today,
        prevStart: new Date(today.getTime() - 48 * 60 * 60 * 1000),
        prevEnd: new Date(today.getTime() - 24 * 60 * 60 * 1000),
        bucket: "hour",
        label: "Yesterday",
      };
    case "7d":
      return makeRelativeRange(7, now, "day", "Last 7 Days");
    case "90d":
      return makeRelativeRange(90, now, "day", "Last 90 Days");
    case "1y":
      return makeRelativeRange(365, now, "month", "This Year");
    case "30d":
    default:
      return makeRelativeRange(30, now, "day", "Last 30 Days");
  }
}

function makeRelativeRange(
  days: number,
  now: Date,
  bucket: "hour" | "day" | "month",
  label: string
): DateRange {
  const ms = days * 24 * 60 * 60 * 1000;
  return {
    start: new Date(now.getTime() - ms),
    end: now,
    prevStart: new Date(now.getTime() - 2 * ms),
    prevEnd: new Date(now.getTime() - ms),
    bucket,
    label,
  };
}

// ── Growth percentage (pure) ───────────────────────────────────────────

/**
 * Calculate the growth percentage between two counts.
 * Returns null when the previous count is 0 (can't divide by zero).
 *
 *   growthPercentage(120, 100) → 20     (20% increase)
 *   growthPercentage(80, 100)  → -20    (20% decrease)
 *   growthPercentage(100, 0)   → null   (no previous data)
 */
export function growthPercentage(current: number, previous: number): number | null {
  if (previous === 0) return null;
  return ((current - previous) / previous) * 100;
}

// ── Time-series bucketing (pure) ───────────────────────────────────────

/**
 * Bucket key for a timestamp, based on the bucket size.
 *   - "hour"  → "2026-08-21T14:00"  (hour precision)
 *   - "day"   → "2026-08-21"        (day precision)
 *   - "month" → "2026-08"           (month precision)
 */
export function bucketKey(date: Date, bucket: "hour" | "day" | "month"): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  const hour = String(date.getHours()).padStart(2, "0");
  switch (bucket) {
    case "hour":  return `${year}-${month}-${day}T${hour}:00`;
    case "day":   return `${year}-${month}-${day}`;
    case "month": return `${year}-${month}`;
  }
}

/**
 * Format a bucket key for display on the chart x-axis.
 *   - "hour"  → "14:00" or "Aug 21, 14:00"
 *   - "day"   → "Aug 21"
 *   - "month" → "Aug 2026"
 */
export function formatBucketLabel(key: string, bucket: "hour" | "day" | "month"): string {
  try {
    if (bucket === "hour") {
      // Key format: "2026-08-21T14:00"
      const [date, time] = key.split("T");
      const [, , day] = (date ?? "").split("-");
      const d = new Date(key);
      const monthName = d.toLocaleString(undefined, { month: "short" });
      return `${monthName} ${day}, ${time}`;
    }
    if (bucket === "month") {
      // Key format: "2026-08"
      const [year, month] = key.split("-");
      const d = new Date(Number(year), Number(month) - 1, 1);
      return d.toLocaleString(undefined, { month: "short", year: "numeric" });
    }
    // day
    const d = new Date(key + "T00:00:00");
    return d.toLocaleString(undefined, { month: "short", day: "numeric" });
  } catch {
    return key;
  }
}
