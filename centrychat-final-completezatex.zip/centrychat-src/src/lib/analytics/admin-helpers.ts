/**
 * Shared helpers for the admin analytics API endpoints.
 *
 * Provides:
 *   - Time range parsing (today, yesterday, 7d, 30d, 90d, 1y, custom)
 *   - Previous-period calculation (for growth % comparisons)
 *   - Date bucketing (hour/day/month) for time-series charts
 *   - cacheGetOrSet wrapper (30s cache for admin analytics responses)
 *
 * All admin analytics endpoints use these helpers for consistent behavior.
 *
 * ── MODULE LAYOUT ──────────────────────────────────────────────────────
 *
 * This module is the SERVER-SIDE entry point. It re-exports the client-safe
 * pure functions + types from `./admin-helpers-shared` (so server-side
 * callers can keep importing everything from `@/lib/analytics/admin-helpers`)
 * and adds the DB-backed helpers (`cachedAggregate`, `hasAnyAnalyticsData`).
 *
 * IMPORTANT: Client Components MUST import pure helpers (e.g.
 * `formatBucketLabel`, `parseRange`, `bucketKey`, `growthPercentage`) from
 * `@/lib/analytics/admin-helpers-shared` instead of this file. Importing
 * this file in a Client Component pulls `db` (and therefore PrismaClient)
 * into the browser bundle, which throws "PrismaClient is unable to run in
 * this browser environment" and triggers the global-error.tsx boundary.
 */

// Re-export the client-safe pure functions + types so server-side callers
// can keep importing everything from `@/lib/analytics/admin-helpers`.
export {
  parseRange,
  bucketKey,
  formatBucketLabel,
  growthPercentage,
} from "./admin-helpers-shared";
export type { AnalyticsRange, DateRange } from "./admin-helpers-shared";

import { cacheGetOrSet } from "@/lib/cache";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";

// ── Cached aggregation helper ───────────────────────────────────────────

/**
 * Run an aggregation function with a 30-second cache.
 *
 * The cache key includes the range + endpoint name, so different ranges +
 * endpoints don't collide. The cache is in-memory (per-instance) — on
 * Netlify serverless, this means each instance has its own cache. The
 * 30-second TTL keeps data fresh while preventing DB hammering.
 *
 * The factory function receives the parsed DateRange. On any error, the
 * factory should return a sensible empty result (the cache wrapper doesn't
 * catch errors — they propagate to the caller's apiHandler).
 */
export async function cachedAggregate<T>(
  cacheKey: string,
  factory: () => Promise<T>
): Promise<T> {
  return cacheGetOrSet(cacheKey, 30, factory);
}

// ── Empty-state helpers ─────────────────────────────────────────────────

/**
 * Check if the AnalyticsEvent table has ANY rows. Used to render the "No
 * traffic data yet" empty state (spec §29) instead of misleading zeros.
 */
export async function hasAnyAnalyticsData(): Promise<boolean> {
  try {
    const count = await db.analyticsEvent.count({ take: 1 });
    return count > 0;
  } catch (err) {
    logger.warn("application", "hasAnyAnalyticsData check failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return false;
  }
}
