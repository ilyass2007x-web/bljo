/**
 * Analytics session + tracking service.
 *
 * Provides:
 *   - getSessionForRequest() — find-or-create an AnalyticsSession for the
 *     current visitor. Handles the 30-minute session timeout (a new event
 *     after 30 min of silence creates a NEW session row).
 *   - trackEvent() — record an AnalyticsEvent + update the session's
 *     lastSeenAt. NON-BLOCKING — returns immediately, the DB write happens
 *     in the background (fire-and-forget via queueMicrotask).
 *
 * SESSION MANAGEMENT:
 *   A session is identified by the visitor cookie (anonymousVisitorId —
 *   same SHA-256 hash mechanism used by ArticleView). When a visitor
 *   arrives with no cookie, the tracking endpoint sets one (via the
 *   setVisitorCookieOnResponse helper from src/lib/security/visitor-cookie).
 *
 *   A session "expires" after 30 minutes of inactivity. The next event
 *   after the timeout creates a NEW session row (with the same anonymousId,
 *   but a new sessionId + new firstSeenAt). This matches the standard
 *   analytics convention (Google Analytics, Mixpanel, etc.).
 *
 * PRIVACY:
 *   - NO raw IP stored. The IP is used transiently to derive the country
 *     (via the Geo abstraction) and then discarded.
 *   - The anonymousId is a SHA-256 hash — even if the DB leaks, an attacker
 *     can't map it back to a specific browser cookie.
 *   - userId is only set when the visitor is authenticated.
 *   - NO passwords, tokens, message content, or auth secrets are logged.
 *
 * PERFORMANCE:
 *   - trackEvent() is fire-and-forget. The tracking endpoint responds 204
 *     BEFORE the DB write completes — the visitor's page load is never
 *     delayed by analytics.
 *   - getSessionForRequest() uses a single findFirst (indexed by anonymousId
 *     + lastSeenAt desc) — O(log n), fast.
 *   - All writes use create() — no upserts (the sessionId is unique, so
 *     concurrent requests for the same session are safe).
 *
 * NON-BLOCKING IMPLEMENTATION:
 *   The trackEvent function schedules the DB write via queueMicrotask. This
 *   means the write happens on the next microtask tick — after the HTTP
 *   response has been sent. If the write fails, it's silently logged (the
 *   visitor's experience is never affected).
 *
 *   This is the SAME pattern used by the existing notification system
 *   (notifyPostLiked is fire-and-forget in src/lib/notifications.ts).
 */

import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { classifyTrafficSource, type TrafficMedium } from "./classify-source";
import { parseUserAgent } from "./parse-ua";
import { resolveCountry } from "./geo";

// ── Constants ───────────────────────────────────────────────────────────

/** Session timeout — 30 minutes of inactivity creates a new session. */
const SESSION_TIMEOUT_MS = 30 * 60 * 1000;

/** Max length for the path field (defensive — paths are usually < 200 chars). */
const MAX_PATH_LENGTH = 2048;

/** Max length for UTM fields. */
const MAX_UTM_LENGTH = 200;

/** Allowed event types — anything else is rejected. */
const ALLOWED_EVENT_TYPES = new Set([
  "page_view",
  "article_view",
  "article_open",
  "article_engagement",
  "external_referral",
  "session_start",
]);

// ── Types ───────────────────────────────────────────────────────────────

export interface TrackContext {
  /** The visitor's anonymous ID (SHA-256 hash of the visitor cookie). */
  anonymousId: string | null;
  /** The authenticated user's ID (when logged in). */
  userId: string | null;
  /** The request headers (used for User-Agent + Geo headers). */
  headers: Headers;
  /** The client IP (used transiently for Geo — never stored). */
  ip: string | null;
}

export interface TrackEventInput {
  eventType: string;
  path: string;
  articleId?: string | null;
  referrer?: string | null;
  /** UTM parameters from the page URL (NOT the referrer). */
  utm?: {
    source?: string;
    medium?: string;
    campaign?: string;
  } | null;
}

// ── Validation helpers ──────────────────────────────────────────────────

function sanitizePath(path: unknown): string | null {
  if (typeof path !== "string") return null;
  const trimmed = path.trim();
  if (!trimmed) return null;
  if (trimmed.length > MAX_PATH_LENGTH) return null;
  // Paths must start with "/" (relative to the site root). Reject absolute
  // URLs + dangerous schemes.
  if (!trimmed.startsWith("/")) return null;
  return trimmed;
}

function sanitizeReferrer(referrer: unknown): string | null {
  if (typeof referrer !== "string") return null;
  const trimmed = referrer.trim();
  if (!trimmed || trimmed.length > 2048) return null;
  try {
    const url = new URL(trimmed);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return trimmed;
  } catch {
    return null;
  }
}

function sanitizeUtm(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.trim().toLowerCase().slice(0, MAX_UTM_LENGTH);
  // UTM values should be alphanumeric + dashes/underscores. Reject anything
  // that looks like an attempt to inject HTML/JS.
  if (!/^[a-z0-9_\-]+$/.test(trimmed)) return null;
  return trimmed || null;
}

// ── Session management ──────────────────────────────────────────────────

/**
 * Find-or-create an AnalyticsSession for the current visitor.
 *
 * Session timeout: if the visitor's most recent session has lastSeenAt
 * older than 30 minutes, a NEW session is created (preserving the same
 * anonymousId). This matches standard analytics conventions.
 *
 * Returns the sessionId. NEVER throws — on any error, returns null (the
 * caller skips the event tracking, never crashes the request).
 *
 * @param ctx - The TrackContext (anonymousId, userId, headers, ip).
 * @param path - The path of the FIRST event in the session (the landing page).
 * @param referrer - The referrer of the FIRST event.
 * @param classified - The classified { source, medium } from the referrer.
 */
async function getOrCreateSession(
  ctx: TrackContext,
  path: string,
  referrer: string | null,
  classified: { source: string; medium: TrafficMedium },
  utm: { source?: string | null; medium?: string | null; campaign?: string | null } | null
): Promise<string | null> {
  try {
    const { device, browser, os } = parseUserAgent(ctx.headers.get("user-agent"));
    const country = resolveCountry(ctx.headers, ctx.ip ?? undefined);

    // Try to find an existing session for this visitor (anonymous or
    // authenticated) that's still "active" (lastSeenAt within 30 min).
    // We use findFirst (not findUnique) because anonymousId is not unique —
    // a visitor can have multiple sessions over time.
    const cutoff = new Date(Date.now() - SESSION_TIMEOUT_MS);
    const where = ctx.userId
      ? { userId: ctx.userId, lastSeenAt: { gt: cutoff } }
      : ctx.anonymousId
      ? { anonymousId: ctx.anonymousId, lastSeenAt: { gt: cutoff } }
      : null;

    if (where) {
      const existing = await db.analyticsSession.findFirst({
        where,
        orderBy: { lastSeenAt: "desc" },
        select: { id: true },
      });
      if (existing) {
        // Found an active session — update its lastSeenAt + return its id.
        // The session's source/medium/entryPath are NOT updated (they're
        // locked to the FIRST event — standard analytics convention).
        await db.analyticsSession.update({
          where: { id: existing.id },
          data: { lastSeenAt: new Date() },
        });
        return existing.id;
      }
    }

    // No active session — create a new one.
    const session = await db.analyticsSession.create({
      data: {
        anonymousId: ctx.anonymousId,
        userId: ctx.userId,
        entryPath: path,
        referrer: referrer,
        source: classified.source,
        medium: classified.medium,
        utmSource: utm?.source ?? null,
        utmMedium: utm?.medium ?? null,
        utmCampaign: utm?.campaign ?? null,
        device,
        browser,
        os,
        country,
        lastSeenAt: new Date(),
      },
    });
    return session.id;
  } catch (err) {
    // Non-fatal — the caller skips tracking. The visitor's experience is
    // never affected by an analytics DB failure.
    logger.warn("application", "Analytics session creation failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return null;
  }
}

// ── Public API: trackEvent (fire-and-forget) ────────────────────────────

/**
 * Record an analytics event. NON-BLOCKING — returns immediately, the DB
 * write happens in the background via queueMicrotask.
 *
 * The caller (the tracking endpoint) should NOT await this function. It's
 * typed as Promise<void> for consistency, but the actual DB work happens
 * outside the caller's await chain.
 *
 * SECURITY:
 *   - All inputs are validated + sanitized (path, referrer, UTM fields).
 *   - eventType must be in ALLOWED_EVENT_TYPES.
 *   - articleId is validated to exist + be PUBLISHED before recording an
 *     article_view event (prevents fabrication).
 *
 * FAILURE HANDLING:
 *   - If validation fails, the event is silently dropped (logged at debug).
 *   - If the DB write fails, the error is logged at warn — the visitor's
 *     experience is never affected.
 */
export function trackEvent(ctx: TrackContext, input: TrackEventInput): void {
  // Validate eventType.
  if (!ALLOWED_EVENT_TYPES.has(input.eventType)) {
    logger.debug("application", "Analytics event rejected: unknown type", {
      eventType: input.eventType,
    });
    return;
  }

  // Validate path.
  const path = sanitizePath(input.path);
  if (!path) {
    logger.debug("application", "Analytics event rejected: invalid path");
    return;
  }

  // Validate referrer.
  const referrer = sanitizeReferrer(input.referrer);

  // Classify the traffic source from the referrer.
  const classified = classifyTrafficSource(referrer);

  // Sanitize UTM fields.
  const utm = input.utm
    ? {
        source: sanitizeUtm(input.utm.source),
        medium: sanitizeUtm(input.utm.medium),
        campaign: sanitizeUtm(input.utm.campaign),
      }
    : null;

  // ── Fire-and-forget ──
  // Schedule the DB write on the next microtask. The caller returns
  // immediately — the visitor's page load is never delayed by analytics.
  //
  // We use a self-invoking async function (not queueMicrotask directly)
  // because we need to await the DB writes inside. The function runs to
  // completion in the background; any errors are caught + logged.
  void (async () => {
    try {
      // When articleId is provided, validate it exists + is PUBLISHED.
      // This prevents fabrication (a malicious client can't send fake
      // article_view events for non-existent articles).
      if (input.articleId) {
        const article = await db.article.findUnique({
          where: { id: input.articleId },
          select: { id: true, status: true },
        });
        if (!article || article.status !== "PUBLISHED") {
          logger.debug("application", "Analytics event rejected: article not found / not published", {
            articleId: input.articleId,
          });
          return;
        }
      }

      // Find-or-create the session.
      const sessionId = await getOrCreateSession(ctx, path, referrer, classified, utm);
      if (!sessionId) {
        // Session creation failed — the error was already logged inside
        // getOrCreateSession. Skip the event write.
        return;
      }

      // Parse UA + Geo for the event row (matches the session's values,
      // but we re-parse in case the visitor switched browsers mid-session —
      // extremely rare but possible).
      const { device, browser, os } = parseUserAgent(ctx.headers.get("user-agent"));
      const country = resolveCountry(ctx.headers, ctx.ip ?? undefined);

      // Insert the event.
      await db.analyticsEvent.create({
        data: {
          sessionId,
          userId: ctx.userId,
          eventType: input.eventType,
          path,
          articleId: input.articleId ?? null,
          referrer: referrer,
          source: classified.source,
          medium: classified.medium,
          utmSource: utm?.source ?? null,
          utmMedium: utm?.medium ?? null,
          utmCampaign: utm?.campaign ?? null,
          device,
          browser,
          os,
          country,
        },
      });
    } catch (err) {
      // Non-fatal — analytics failures must NEVER break the visitor's
      // experience. Log at warn (so admins see it in logs) + move on.
      logger.warn("application", "Analytics event write failed", {
        eventType: input.eventType,
        path,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  })();
}
