/**
 * Lightweight User-Agent parser.
 *
 * Extracts device type (desktop/mobile/tablet), browser name, and OS name
 * from the User-Agent header. NO external dependency — pure regex parsing.
 *
 * This is intentionally SIMPLISTIC. It covers ~95% of real-world UAs without
 * the 50KB+ cost of a full UA database (like ua-parser-js). The tradeoff:
 * occasional misclassification of obscure browsers/OSes, but they fall into
 * the "other" bucket which is correct behavior.
 *
 * All return values are LOWERCASE short strings (no versions) so they group
 * cleanly in Prisma groupBy queries:
 *   - device: "desktop" | "mobile" | "tablet"
 *   - browser: "chrome" | "safari" | "firefox" | "edge" | "opera" | "samsung" | "other"
 *   - os: "windows" | "android" | "ios" | "macos" | "linux" | "chromeos" | "other"
 */

export interface ParsedUA {
  device: "desktop" | "mobile" | "tablet";
  browser: string;
  os: string;
}

/**
 * Parse a User-Agent string. NEVER throws — returns "other" for unknown fields.
 */
export function parseUserAgent(ua: string | null | undefined): ParsedUA {
  const s = (ua ?? "").toLowerCase();
  if (!s) {
    return { device: "desktop", browser: "other", os: "other" };
  }

  // ── Device ──
  // iPad + Android tablets report "tablet" or have no "mobile" in their UA.
  // iPhones + Android phones include "mobile" (but not "tablet").
  let device: ParsedUA["device"] = "desktop";
  if (/ipad|tablet|playbook|silk/.test(s) || (/android/.test(s) && !/mobile/.test(s))) {
    device = "tablet";
  } else if (/iphone|android.*mobile|ipod|blackberry|opera mini|mobile/.test(s)) {
    device = "mobile";
  }

  // ── OS ──
  let os: string = "other";
  if (/windows nt/.test(s)) {
    os = "windows";
  } else if (/iphone|ipad|ipod/.test(s)) {
    os = "ios";
  } else if (/mac os x|macintosh/.test(s)) {
    os = "macos";
  } else if (/android/.test(s)) {
    os = "android";
  } else if (/linux/.test(s)) {
    os = "linux";
  } else if (/cros/.test(s)) {
    os = "chromeos";
  }

  // ── Browser ──
  // Order matters — some browsers spoof others. We check the most specific first.
  let browser: string = "other";
  if (/edg\//.test(s)) {
    browser = "edge";
  } else if (/opr\/|opera/.test(s)) {
    browser = "opera";
  } else if (/samsungbrowser/.test(s)) {
    browser = "samsung";
  } else if (/chrome|crios|chromium/.test(s) && !/edg\//.test(s)) {
    // Chrome on iOS is "crios"; desktop Chrome is "chrome"
    browser = "chrome";
  } else if (/firefox|fxios/.test(s)) {
    browser = "firefox";
  } else if (/safari/.test(s) && !/chrome|crios|chromium/.test(s)) {
    // Safari (not Chrome-as-Safari)
    browser = "safari";
  }

  return { device, browser, os };
}
