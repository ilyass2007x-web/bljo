/**
 * Helpers to build a TrackContext from an incoming API request.
 *
 * Used by the tracking endpoint (POST /api/v1/analytics/track) to extract:
 *   - anonymousId (from the visitor cookie, hashed via deriveAnonymousVisitorId)
 *   - userId (from the session, when authenticated — nullable for anonymous)
 *   - headers (passed through for UA + Geo parsing)
 *   - ip (from x-forwarded-for / x-real-ip — used transiently for Geo)
 *
 * PRIVACY:
 *   - The visitor cookie is hashed (SHA-256) before storage — the raw cookie
 *     value never enters the DB.
 *   - The IP is used transiently (passed to resolveCountry) and then discarded.
 *     It is NEVER stored in the analytics tables.
 */

import { NextRequest } from "next/server";
import {
  VISITOR_COOKIE_NAME,
  deriveAnonymousVisitorId,
} from "@/lib/security/visitor-cookie";
import { getCurrentUser } from "@/lib/auth";
import type { TrackContext } from "./track";

/**
 * Extract the client IP from a request.
 * Checks x-forwarded-for (standard proxy header) + x-real-ip (nginx).
 * Returns the FIRST IP in the list (the visitor's real IP, not the proxy's).
 */
export function getClientIpFromRequest(req: Request | NextRequest): string | null {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) {
    const first = xff.split(",")[0]?.trim();
    if (first) return first;
  }
  const xRealIp = req.headers.get("x-real-ip");
  if (xRealIp) return xRealIp.trim();
  return null;
}

/**
 * Read the visitor cookie from a request + derive the anonymousId.
 * Returns null when no cookie is present (the caller sets a fresh cookie
 * on the response so subsequent requests carry it).
 */
async function getAnonymousIdFromRequest(
  req: Request | NextRequest
): Promise<string | null> {
  // We can't use next/headers cookies() here because this function is called
  // from a Route Handler (not a Server Component). Route Handlers receive
  // the request directly — we read the Cookie header manually.
  const cookieHeader = req.headers.get("cookie") ?? "";
  const cookies = Object.fromEntries(
    cookieHeader.split(";").map((c) => {
      const [k, ...v] = c.trim().split("=");
      return [k, v.join("=")];
    })
  );
  const raw = cookies[VISITOR_COOKIE_NAME];
  if (!raw || typeof raw !== "string") return null;
  // Validate the token looks like a UUID (same check as getVisitorToken).
  if (!/^[a-f0-9-]{10,}$/i.test(raw)) return null;
  return deriveAnonymousVisitorId(raw);
}

/**
 * Build a TrackContext from a request.
 *
 * This calls getCurrentUser() (which reads the session) to get the userId
 * when the visitor is authenticated. For anonymous visitors, userId is null
 * and we rely on the anonymousId for session identification.
 *
 * NEVER throws — on any error, returns a context with null fields (the
 * tracker will still work, just without user attribution).
 */
export async function buildTrackContext(
  req: Request | NextRequest
): Promise<TrackContext> {
  let userId: string | null = null;
  let anonymousId: string | null = null;

  try {
    // Try to resolve the authenticated user (non-blocking on failure).
    // We use getCurrentUser() (not requireUser) so anonymous visitors are
    // tracked too. getCurrentUser returns null when not authenticated.
    const user = await getCurrentUser().catch(() => null);
    if (user) {
      userId = user.id;
    }
  } catch {
    // Auth resolution failed — track as anonymous.
  }

  try {
    anonymousId = await getAnonymousIdFromRequest(req);
  } catch {
    // Cookie read failed — track without anonymousId (less accurate but
    // still functional).
  }

  return {
    anonymousId,
    userId,
    headers: req.headers,
    ip: getClientIpFromRequest(req),
  };
}
