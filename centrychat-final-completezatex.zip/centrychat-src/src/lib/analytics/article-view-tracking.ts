/**
 * Unified article view tracking — server-side integration between the
 * canonical ArticleView counter and the AnalyticsEvent stream.
 *
 * THE SINGLE CANONICAL VIEW FLOW (spec Phase 3.5):
 *
 *   1. Client POSTs /api/v1/articles/[id]/views  (the ONLY view-tracking call)
 *   2. /views route validates: bot exclusion, rate limit, article published,
 *      author self-view exclusion, dedup by (article, user) or (article, anon)
 *   3. ArticleView row is created OR its viewedAt is bumped.
 *      ↑ THIS IS THE PUBLIC VIEW COUNTER — single source of truth.
 *   4. If + only if a NEW view was recorded (recorded === true), the SAME
 *      endpoint fires `recordArticleViewAnalytics()` to write an
 *      AnalyticsEvent row in the background.
 *
 * INVARIANTS:
 *   - The public view count (`COUNT(ArticleView WHERE articleId=X)`) and
 *     the admin "article views" metric
 *     (`COUNT(AnalyticsEvent WHERE eventType='article_view' AND articleId=X)`)
 *     MUST stay in sync: every +1 to the public counter corresponds to
 *     exactly ONE AnalyticsEvent row, and a re-view (viewedAt bump, no
 *     new row) does NOT create an AnalyticsEvent.
 *   - The /api/v1/analytics/track endpoint can still receive article_view
 *     events from other callers (e.g. SPA navigation `article_open`),
 *     but the article-reading-page.tsx MUST NOT call it for the initial
 *     article_view event — that's now exclusively the /views route's job.
 *
 * NON-BLOCKING:
 *   This helper schedules the DB write via queueMicrotask (same pattern as
 *   `trackEvent` in ./track.ts). The /views route returns to the client
 *   immediately; the analytics write happens on the next microtask tick.
 *   Failures are silently logged (analytics must never break the view
 *   tracking path).
 */

import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { classifyTrafficSource } from "./classify-source";
import { parseUserAgent } from "./parse-ua";
import { resolveCountry } from "./geo";
import type { TrackContext } from "./track";

/**
 * Inputs for recording an article-view analytics event.
 *
 * Most fields come from the request context (parsed by the /views route):
 *   - articleId
 *   - ctx: the analytics context (anonymousId, userId, headers, ip)
 *   - referrer: the verbatim referrer URL (already validated by /views)
 *   - path: the article URL path
 *   - source + medium: ALREADY classified by the /views route (we reuse
 *     the same classification, ensuring the AnalyticsEvent.source matches
 *     the ArticleView.source — no divergence).
 */
export interface ArticleViewAnalyticsInput {
  articleId: string;
  ctx: TrackContext;
  path: string;
  referrer: string | null;
  /** The classified source string (e.g. "google", "internal", "direct"). */
  source: string;
  /** The classified medium (e.g. "search", "social", "referral"). */
  medium: string;
  /** UTM parameters from the page URL (passed through from the request body, if any). */
  utm?: {
    source?: string | null;
    medium?: string | null;
    campaign?: string | null;
  } | null;
}

/**
 * Record an `article_view` AnalyticsEvent for a CANONICALLY VALID article view.
 *
 * This MUST only be called from POST /api/v1/articles/[id]/views, AFTER the
 * ArticleView upsert succeeded with `recorded === true` (i.e., a NEW unique
 * view was just inserted — NOT a viewedAt bump on an existing row).
 *
 * Fire-and-forget: schedules the DB write via queueMicrotask. NEVER throws.
 * Failures are logged at warn level (so admins see them) but never propagate
 * to the caller.
 *
 * The event is attributed to:
 *   - The authenticated user (ctx.userId) when present, OR
 *   - The anonymous visitor (ctx.anonymousId) when no user is logged in.
 *
 * Session lookup uses the SAME 30-minute timeout as the public /analytics/track
 * endpoint (delegates to the same getOrCreateSession helper).
 */
export function recordArticleViewAnalytics(input: ArticleViewAnalyticsInput): void {
  // Schedule the DB write on the next microtask. Same pattern as trackEvent
  // in ./track.ts — non-blocking, fire-and-forget.
  void (async () => {
    try {
      const { articleId, ctx, path, referrer, source, medium, utm } = input;

      // ── Find-or-create the session ──────────────────────────────────
      // Delegates to the same session helper used by /analytics/track.
      // This guarantees a single analytics session per visitor per 30min
      // window, regardless of whether the event came from /views or
      // /analytics/track.
      const sessionId = await getOrCreateSessionForView(
        ctx,
        path,
        referrer,
        source,
        medium,
        utm ?? null // normalize undefined → null (the input field is optional)
      );
      if (!sessionId) {
        // Session creation failed — error already logged inside. Skip.
        return;
      }

      // ── Parse UA + Geo for the event row ───────────────────────────
      const { device, browser, os } = parseUserAgent(ctx.headers.get("user-agent"));
      const country = resolveCountry(ctx.headers, ctx.ip ?? undefined);

      // ── Insert the AnalyticsEvent ─────────────────────────────────
      await db.analyticsEvent.create({
        data: {
          sessionId,
          userId: ctx.userId,
          eventType: "article_view",
          path,
          articleId,
          referrer,
          // Reuse the SAME source classification the /views route already
          // computed. This guarantees ArticleView.source and AnalyticsEvent.source
          // agree — no divergence between the public counter and the admin
          // analytics breakdown.
          source,
          medium,
          utmSource: utm?.source ?? null,
          utmMedium: utm?.medium ?? null,
          utmCampaign: utm?.campaign ?? null,
          device,
          browser,
          os,
          country,
        },
      });
    } catch (err) {
      // Non-fatal — analytics failures must NEVER break the view-tracking
      // path. The ArticleView row was already written (that's the source of
      // truth for the public counter). Log at warn so admins see it.
      logger.warn("application", "Article view analytics event write failed", {
        articleId: input.articleId,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  })();
}

// ── Session timeout (must match ./track.ts) ───────────────────────────
const SESSION_TIMEOUT_MS = 30 * 60 * 1000;

/**
 * Find-or-create an AnalyticsSession for the current visitor.
 *
 * This is a duplicate of the `getOrCreateSession` function in ./track.ts.
 * It's intentionally duplicated (NOT exported from track.ts) to keep the
 * analytics module's internals private — only `recordArticleViewAnalytics`
 * is the public entry point from outside this module.
 *
 * Same 30-minute session timeout as the public /analytics/track endpoint.
 */
async function getOrCreateSessionForView(
  ctx: TrackContext,
  path: string,
  referrer: string | null,
  source: string,
  medium: string,
  utm: { source?: string | null; medium?: string | null; campaign?: string | null } | null
): Promise<string | null> {
  try {
    const { device, browser, os } = parseUserAgent(ctx.headers.get("user-agent"));
    const country = resolveCountry(ctx.headers, ctx.ip ?? undefined);

    const cutoff = new Date(Date.now() - SESSION_TIMEOUT_MS);
    const where = ctx.userId
      ? { userId: ctx.userId, lastSeenAt: { gt: cutoff } }
      : ctx.anonymousId
        ? { anonymousId: ctx.anonymousId, lastSeenAt: { gt: cutoff } }
        : null;

    if (where) {
      const existing = await db.analyticsSession.findFirst({
        where,
        orderBy: { lastSeenAt: "desc" },
        select: { id: true },
      });
      if (existing) {
        await db.analyticsSession.update({
          where: { id: existing.id },
          data: { lastSeenAt: new Date() },
        });
        return existing.id;
      }
    }

    const session = await db.analyticsSession.create({
      data: {
        anonymousId: ctx.anonymousId,
        userId: ctx.userId,
        entryPath: path,
        referrer,
        source,
        medium,
        utmSource: utm?.source ?? null,
        utmMedium: utm?.medium ?? null,
        utmCampaign: utm?.campaign ?? null,
        device,
        browser,
        os,
        country,
        lastSeenAt: new Date(),
      },
    });
    return session.id;
  } catch (err) {
    logger.warn("application", "Analytics session creation failed (article view)", {
      error: err instanceof Error ? err.message : String(err),
    });
    return null;
  }
}

/**
 * Build a TrackContext from the /views route's already-resolved data.
 *
 * This avoids a second `getCurrentUser()` call (we already have the user)
 * + a second visitor cookie read (we already have the anonymousVisitorId).
 * The headers + IP are extracted from the request.
 *
 * @param req - The incoming HTTP request (for headers + IP).
 * @param userId - The resolved user ID (null for anonymous visitors).
 * @param anonymousVisitorId - The hashed visitor ID (null for logged-in users).
 */
export function buildViewTrackContext(
  req: Request,
  userId: string | null,
  anonymousVisitorId: string | null
): TrackContext {
  // Extract IP (same logic as ./context.ts getClientIpFromRequest).
  const xff = req.headers.get("x-forwarded-for");
  let ip: string | null = null;
  if (xff) {
    const first = xff.split(",")[0]?.trim();
    if (first) ip = first;
  }
  if (!ip) {
    const xRealIp = req.headers.get("x-real-ip");
    if (xRealIp) ip = xRealIp.trim();
  }

  return {
    anonymousId: anonymousVisitorId,
    userId,
    headers: req.headers,
    ip,
  };
}

/**
 * Re-export classifyTrafficSource so the /views route can classify referrers
 * into { source, medium } using the same helper the /analytics/track endpoint
 * uses. This guarantees consistent classification between the two paths.
 */
export { classifyTrafficSource };
