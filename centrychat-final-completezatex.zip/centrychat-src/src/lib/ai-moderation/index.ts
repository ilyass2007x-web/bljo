/**
 * AI Moderation Provider System — Public API
 * ==========================================
 *
 * SERVER-ONLY. Aggregates the public surface of the AI moderation system.
 *
 * The application talks to `moderateContent()` (from service.ts) — that's
 * the single entry point. Never import from adapters/ or registry/ directly
 * (those are implementation details).
 *
 * SECURITY: this module imports `db` (Prisma) — NEVER import from a client
 * component. API routes + server actions only.
 */

export { moderateContent, applyContentAction, applyUserAction } from "./service";
export type { ModerateContentInput, ModerateContentOutput } from "./service";

export { encryptApiKey, decryptApiKey, maskApiKey, isEncryptionKeyConfigured } from "./encryption";

export { getAdapter, listProviderTypes } from "./registry";

export { evaluatePolicy, DEFAULT_POLICY, DEFAULT_CATEGORY_POLICY } from "./policy-engine";

export { loadPolicy, savePolicy, getPolicyVersion, loadActiveProviders, loadAllProviders } from "./settings";

export { testProvider } from "./test-provider";
export type { TestProviderInput, TestProviderOutput } from "./test-provider";

export { getAiModerationStats, getReviewQueue, applyReviewAction } from "./stats";
export type { AiModerationStats, ReviewQueueFilter, ReviewQueueItem, ReviewActionInput } from "./stats";

export { validateEndpointUrl } from "./ssrf";

// Types (pure — safe to re-export).
export type {
  ModerationProvider,
  NormalizedModerationResult,
  ProviderRuntimeConfig,
  ProviderType,
  ProviderTypeMeta,
  HealthCheckResult,
  TextModerationInput,
  ImageModerationInput,
  VideoModerationInput,
  ModerationCategory,
  CategoryScores,
  ContentAction,
  UserAction,
  ModerationDecision,
  ModerationCallSummary,
  ModerationProviderError,
  ModerationProviderTimeoutError,
  ModerationProviderRateLimitError,
  ModerationProviderServerError,
  ModerationProviderResponseError,
  ModerationProviderConfigError,
} from "./types";
export { PROVIDER_TYPES, CATEGORY_ORDER, CATEGORY_LABELS } from "./types";

// Schemas (Zod — pure).
export {
  CreateProviderSchema,
  UpdateProviderSchema,
  TestProviderSchema,
  SetActiveProviderSchema,
  SetFallbackProviderSchema,
  ModerationPolicySchema,
  CategoryPolicySchema,
  ContentActionSchema,
  UserActionSchema,
  ReviewActionSchema,
  ReviewStatusSchema,
  PaginationSchema,
  ReviewFilterSchema,
  ContentTypeSchema,
} from "./schemas";
export type {
  CreateProviderInput,
  UpdateProviderInput,
  TestProviderInput as TestProviderInputSchema,
  ModerationPolicy,
  CategoryPolicy,
  ReviewAction,
} from "./schemas";
