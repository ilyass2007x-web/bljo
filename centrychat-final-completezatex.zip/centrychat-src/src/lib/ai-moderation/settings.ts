/**
 * AI Moderation — Settings + Policy persistence
 * ============================================
 *
 * SERVER-ONLY. Loads + saves the moderation policy via the existing
 * PlatformSetting table (no new settings table). The policy is stored
 * as a JSON string in the `ai_moderation.policy` key.
 *
 * CACHING: 30-second TTL via cacheGetOrSet (same pattern as the rest of
 * the settings system). The savePolicy function invalidates the cache
 * immediately so admin changes take effect on the next request.
 *
 * POLICY VERSIONING (spec §45): every save bumps the policy version.
 * The version is stored in `ai_moderation.policy_version` + snapshotted
 * into every AiModerationResult row so admins can see which policy
 * produced each decision (no retroactive changes).
 */

import { db } from "@/lib/database";
import { cacheGetOrSet, getCache } from "@/lib/cache";
import { getSetting, getSettingNumber, setSetting } from "@/lib/settings";
import type { ModerationPolicy } from "./schemas";
import { DEFAULT_POLICY } from "./policy-engine";

const POLICY_CACHE_KEY = "ai_moderation:policy";
const POLICY_CACHE_TTL = 30; // seconds

const POLICY_SETTING_KEY = "ai_moderation.policy";
const POLICY_VERSION_SETTING_KEY = "ai_moderation.policy_version";

/**
 * Load the active moderation policy. Returns the default policy when
 * no policy has been configured (or when the DB is unreachable).
 */
export async function loadPolicy(): Promise<{ policy: ModerationPolicy; version: number }> {
  try {
    const cached = await cacheGetOrSet(POLICY_CACHE_KEY, POLICY_CACHE_TTL, async () => {
      const [policyJson, version] = await Promise.all([
        getSetting(POLICY_SETTING_KEY),
        getSettingNumber(POLICY_VERSION_SETTING_KEY),
      ]);
      if (!policyJson) {
        return { policy: DEFAULT_POLICY, version: version ?? 0 };
      }
      try {
        const parsed = JSON.parse(policyJson) as ModerationPolicy;
        // Merge with defaults — so new fields added in upgrades don't break.
        const merged: ModerationPolicy = {
          ...DEFAULT_POLICY,
          ...parsed,
          categories: {
            ...DEFAULT_POLICY.categories,
            ...parsed.categories,
          },
        };
        return { policy: merged, version: version ?? 0 };
      } catch {
        return { policy: DEFAULT_POLICY, version: version ?? 0 };
      }
    });
    return cached;
  } catch {
    // DB unreachable — return defaults.
    return { policy: DEFAULT_POLICY, version: 0 };
  }
}

/**
 * Save the moderation policy + bump the policy version.
 * Invalidates the cache so the next request sees the new policy.
 *
 * SECURITY: caller MUST verify requireAdmin() before calling this.
 */
export async function savePolicy(
  policy: ModerationPolicy,
  adminId: string
): Promise<number> {
  // Load the current version + bump it.
  const currentVersion = (await getSettingNumber(POLICY_VERSION_SETTING_KEY)) ?? 0;
  const newVersion = currentVersion + 1;

  await Promise.all([
    setSetting(POLICY_SETTING_KEY, JSON.stringify(policy), adminId),
    setSetting(POLICY_VERSION_SETTING_KEY, String(newVersion), adminId),
  ]);

  // Invalidate the cache.
  try {
    await getCache().delete(POLICY_CACHE_KEY);
  } catch {
    // best-effort — TTL still applies
  }

  return newVersion;
}

/**
 * Get the current policy version (without loading the full policy).
 * Used by the Service to snapshot the version into AiModerationResult rows.
 */
export async function getPolicyVersion(): Promise<number> {
  return (await getSettingNumber(POLICY_VERSION_SETTING_KEY)) ?? 0;
}

// ── Provider list helpers ─────────────────────────────────────────────

/**
 * Load the active provider list from the DB, ordered by priority.
 * Returns only providers with priority > 0 (active).
 */
export async function loadActiveProviders() {
  return db.aiModerationProvider.findMany({
    where: { priority: { gt: 0 } },
    orderBy: [{ priority: "asc" }, { createdAt: "asc" }],
  });
}

/**
 * Load ALL providers (active + inactive) — used by the admin UI.
 */
export async function loadAllProviders() {
  return db.aiModerationProvider.findMany({
    orderBy: [{ priority: "asc" }, { createdAt: "asc" }],
  });
}
