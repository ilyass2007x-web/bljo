/**
 * AI Moderation — Zod Validation Schemas
 * ======================================
 *
 * Pure Zod schemas for validating ALL client input to the AI Moderation
 * admin API. Never trust client input — every endpoint validates with
 * one of these schemas before touching the DB.
 *
 * SERVER + CLIENT. Pure types — no Node-only modules.
 */

import { z } from "zod";

// ── Provider Type ─────────────────────────────────────────────────────

export const PROVIDER_TYPE_VALUES = ["openai", "gemini", "huggingface", "custom", "local"] as const;

export const ProviderTypeSchema = z.enum(PROVIDER_TYPE_VALUES);

// ── Create / Update Provider ──────────────────────────────────────────

export const CreateProviderSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Provider name must be at least 2 characters")
    .max(80, "Provider name is too long (max 80)"),
  type: ProviderTypeSchema,
  model: z
    .string()
    .trim()
    .min(1, "Model identifier is required")
    .max(120, "Model identifier is too long (max 120)"),
  apiKey: z
    .string()
    .min(8, "API key must be at least 8 characters")
    .max(400, "API key is too long (max 400)")
    .optional()
    .or(z.literal("").transform(() => undefined)),
  endpoint: z
    .string()
    .trim()
    .max(400, "Endpoint URL is too long (max 400)")
    .optional()
    .or(z.literal("").transform(() => undefined)),
  priority: z
    .number()
    .int("Priority must be an integer")
    .min(0, "Priority must be >= 0 (0 = inactive)")
    .max(99, "Priority must be <= 99"),
  supportsText: z.boolean().optional().default(true),
  supportsImage: z.boolean().optional().default(false),
  supportsVideo: z.boolean().optional().default(false),
  /** When true, the adapter's healthCheck() is called BEFORE the provider is persisted. */
  testBeforeSave: z.boolean().optional().default(true),
}).refine(
  // Custom + Local providers MUST have an endpoint.
  (v) => v.type !== "custom" && v.type !== "local" ? true : !!v.endpoint,
  { message: "Endpoint is required for custom and local providers", path: ["endpoint"] }
).refine(
  // OpenAI / Gemini / Hugging Face REQUIRE an API key.
  (v) => v.type === "custom" || v.type === "local" ? true : !!v.apiKey,
  { message: "API key is required for this provider type", path: ["apiKey"] }
);

export type CreateProviderInput = z.infer<typeof CreateProviderSchema>;

export const UpdateProviderSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2)
    .max(80)
    .optional(),
  model: z
    .string()
    .trim()
    .min(1)
    .max(120)
    .optional(),
  /** Optional new API key. When omitted, the existing key is preserved. */
  apiKey: z
    .string()
    .min(8)
    .max(400)
    .optional()
    .or(z.literal("").transform(() => undefined)),
  endpoint: z
    .string()
    .trim()
    .max(400)
    .optional()
    .or(z.literal("").transform(() => undefined)),
  priority: z
    .number()
    .int()
    .min(0)
    .max(99)
    .optional(),
  supportsText: z.boolean().optional(),
  supportsImage: z.boolean().optional(),
  supportsVideo: z.boolean().optional(),
  /** When true, run healthCheck() before persisting the update. */
  testBeforeSave: z.boolean().optional(),
}).refine(
  (v) => Object.keys(v).length > 0,
  { message: "At least one field must be provided for update" }
);

export type UpdateProviderInput = z.infer<typeof UpdateProviderSchema>;

// ── Test Provider ─────────────────────────────────────────────────────

export const TestProviderSchema = z.object({
  /** When provided, test an EXISTING provider by ID (uses the stored encrypted API key). */
  providerId: z.string().trim().min(1).optional(),
  /** When providerId is omitted, test a DRAFT config (not yet persisted). */
  draftConfig: z.object({
    type: ProviderTypeSchema,
    model: z.string().trim().min(1).max(120),
    apiKey: z.string().min(8).max(400).optional().or(z.literal("").transform(() => undefined)),
    endpoint: z.string().trim().max(400).optional().or(z.literal("").transform(() => undefined)),
  }).optional(),
}).refine(
  (v) => v.providerId || v.draftConfig,
  { message: "Either providerId or draftConfig is required" }
);

export type TestProviderInput = z.infer<typeof TestProviderSchema>;

// ── Activate / Set Priority ───────────────────────────────────────────

export const SetActiveProviderSchema = z.object({
  providerId: z.string().trim().min(1, "Provider ID is required"),
  /** New priority. 1 = primary. 0 = inactive. */
  priority: z.number().int().min(0).max(99),
});

export const SetFallbackProviderSchema = z.object({
  providerId: z.string().trim().min(1, "Provider ID is required"),
});

// ── Policy ────────────────────────────────────────────────────────────

export const CONTENT_TYPE_VALUES = [
  "post", "article", "post_comment", "article_comment",
  "profile_bio", "profile_full_name", "image", "video",
] as const;

export const ContentTypeSchema = z.enum(CONTENT_TYPE_VALUES);

export const CONTENT_ACTION_VALUES = [
  "ALLOW", "FLAG_FOR_REVIEW", "HIDE_CONTENT", "BLOCK_CONTENT", "DELETE_CONTENT",
] as const;

export const ContentActionSchema = z.enum(CONTENT_ACTION_VALUES);

export const USER_ACTION_VALUES = [
  "NONE", "WARN_USER", "RESTRICT_USER", "SUSPEND_USER", "BAN_USER",
] as const;

export const UserActionSchema = z.enum(USER_ACTION_VALUES);

export const CategoryPolicySchema = z.object({
  /** Threshold 0..1 — content with score >= threshold triggers this policy. */
  threshold: z.number().min(0).max(1),
  contentAction: ContentActionSchema,
  userAction: UserActionSchema,
  /** Optional restriction duration in seconds. Applies to RESTRICT_USER / SUSPEND_USER. */
  restrictionDurationSec: z.number().int().min(0).max(60 * 60 * 24 * 365).optional(),
});

export type CategoryPolicy = z.infer<typeof CategoryPolicySchema>;

export const ModerationPolicySchema = z.object({
  /** Global on/off for AI moderation (overrides the feature flag — both must be ON). */
  enabled: z.boolean(),
  /** Which content types are subject to AI moderation. */
  contentTypes: z.array(ContentTypeSchema),
  /** Per-category policy. Missing categories use the default threshold (0.85) + ALLOW + NONE. */
  categories: z.record(z.string(), CategoryPolicySchema),
  /** Per-call timeout in milliseconds (default 10000). */
  timeoutMs: z.number().int().min(1000).max(60000).optional().default(10000),
  /** Max retries on retryable errors (default 2). */
  maxRetries: z.number().int().min(0).max(5).optional().default(2),
  /** Fail-open (ALLOW) or fail-closed (FLAG_FOR_REVIEW) when ALL providers fail. */
  failureMode: z.enum(["FAIL_OPEN", "FAIL_CLOSED"]).optional().default("FAIL_CLOSED"),
  /** Retention in days for AiModerationResult rows. 0 = never delete. */
  retentionDays: z.number().int().min(0).max(3650).optional().default(90),
  /** Escalation rules: violation #N → { userAction, restrictionDurationSec }. */
  escalationRules: z.array(z.object({
    violationCount: z.number().int().min(1).max(20),
    userAction: UserActionSchema,
    restrictionDurationSec: z.number().int().min(0).max(60 * 60 * 24 * 365).optional(),
  })).optional(),
});

export type ModerationPolicy = z.infer<typeof ModerationPolicySchema>;

// ── Review Queue Actions ──────────────────────────────────────────────

export const REVIEW_STATUS_VALUES = ["PENDING", "APPROVED", "REJECTED", "OVERRIDDEN"] as const;

export const ReviewStatusSchema = z.enum(REVIEW_STATUS_VALUES);

export const ReviewActionSchema = z.object({
  /** New status for the review item (PENDING is not a valid action — admins can only advance the queue). */
  status: z.enum(["APPROVED", "REJECTED", "OVERRIDDEN"]),
  /** Optional admin notes (audit trail). */
  notes: z.string().trim().max(1000).optional().or(z.literal("").transform(() => undefined)),
  /** Optional explicit content action override (when admin wants to escalate). */
  overrideContentAction: ContentActionSchema.optional(),
  /** Optional explicit user action override. */
  overrideUserAction: UserActionSchema.optional(),
});

export type ReviewAction = z.infer<typeof ReviewActionSchema>;

// ── Pagination / Filters ──────────────────────────────────────────────

export const PaginationSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
});

export const ReviewFilterSchema = PaginationSchema.extend({
  status: ReviewStatusSchema.optional(),
  providerId: z.string().trim().optional(),
  contentType: ContentTypeSchema.optional(),
  category: z.string().trim().optional(),
  userId: z.string().trim().optional(),
});
