/**
 * AI Moderation — Policy Engine
 * ============================
 *
 * SERVER-ONLY. Takes a NormalizedModerationResult + the admin-configured
 * policy + the user's violation history → produces a final ModerationDecision.
 *
 * Pure functions where possible (no DB inside the policy evaluation). The
 * caller fetches the policy + the violation count + passes them in.
 *
 * DECISION LOGIC (spec §10, §11, §13, §57):
 *
 *   1. For each category the provider scored (non-null):
 *      - If score >= threshold AND threshold > 0:
 *        → this category is a "triggered violation".
 *   2. Pick the triggered category with the HIGHEST score.
 *   3. Look up that category's policy:
 *      - contentAction → what to do with the content
 *      - userAction → what to do with the user
 *      - restrictionDurationSec → applies to RESTRICT_USER / SUSPEND_USER
 *   4. Apply escalation:
 *      - If the user has prior violations of the SAME category, escalate
 *        the userAction per the escalation rules (1st, 2nd, 3rd, ...).
 *      - NEVER escalate to BAN_USER unless the policy explicitly says so.
 *   5. Build the ModerationDecision.
 *
 * CRITICAL (spec §57): the AI gives categories + scores. The POLICY ENGINE
 * decides the action — never the AI. This is the critical separation
 * required by spec §57: "Admin decides the penalty, not the AI."
 *
 * CRITICAL (spec §44): NEVER auto-ban a user for a single uncertain result.
 * The escalation rules must be explicitly configured by the admin — there's
 * no implicit "1 violation → ban" default.
 */

import type {
  NormalizedModerationResult,
  ModerationDecision,
  ModerationCategory,
  ContentAction,
  UserAction,
} from "./types";
import type { ModerationPolicy, CategoryPolicy } from "./schemas";
import { CATEGORY_ORDER } from "./types";

// ── Default policy ────────────────────────────────────────────────────

/**
 * The DEFAULT policy used when no policy has been configured by the admin.
 * Conservative — errs on the side of "review" rather than "delete" or "ban".
 *
 * Per spec §44: "Do NOT automatically ban users for one uncertain
 * moderation result." The default userAction is NONE for most categories;
 * only sexual_explicit + scam get a WARN_USER by default.
 */
export const DEFAULT_CATEGORY_POLICY: Record<ModerationCategory, CategoryPolicy> = {
  sexual: {
    threshold: 0.85,
    contentAction: "HIDE_CONTENT",
    userAction: "WARN_USER",
  },
  explicit: {
    threshold: 0.90,
    contentAction: "DELETE_CONTENT",
    userAction: "WARN_USER",
  },
  nudity: {
    threshold: 0.90,
    contentAction: "HIDE_CONTENT",
    userAction: "WARN_USER",
  },
  suggestive: {
    threshold: 0.75,
    contentAction: "FLAG_FOR_REVIEW",
    userAction: "NONE",
  },
  violence: {
    threshold: 0.85,
    contentAction: "FLAG_FOR_REVIEW",
    userAction: "NONE",
  },
  graphicViolence: {
    threshold: 0.85,
    contentAction: "DELETE_CONTENT",
    userAction: "WARN_USER",
  },
  hate: {
    threshold: 0.80,
    contentAction: "HIDE_CONTENT",
    userAction: "RESTRICT_USER",
    restrictionDurationSec: 24 * 60 * 60, // 24h
  },
  harassment: {
    threshold: 0.80,
    contentAction: "FLAG_FOR_REVIEW",
    userAction: "WARN_USER",
  },
  bullying: {
    threshold: 0.80,
    contentAction: "HIDE_CONTENT",
    userAction: "WARN_USER",
  },
  selfHarm: {
    threshold: 0.70,
    contentAction: "FLAG_FOR_REVIEW",
    userAction: "NONE", // self-harm is treated as a safety concern, not a violation — see spec §11
  },
  spam: {
    threshold: 0.75,
    contentAction: "HIDE_CONTENT",
    userAction: "WARN_USER",
  },
  scam: {
    threshold: 0.85,
    contentAction: "DELETE_CONTENT",
    userAction: "SUSPEND_USER",
    restrictionDurationSec: 24 * 60 * 60, // 24h
  },
  illegal: {
    threshold: 0.85,
    contentAction: "DELETE_CONTENT",
    userAction: "SUSPEND_USER",
    restrictionDurationSec: 3 * 24 * 60 * 60, // 3 days
  },
};

export const DEFAULT_POLICY: ModerationPolicy = {
  enabled: false,
  contentTypes: ["post", "article", "post_comment", "article_comment", "profile_bio", "profile_full_name"],
  categories: DEFAULT_CATEGORY_POLICY as unknown as Record<string, CategoryPolicy>,
  timeoutMs: 10000,
  maxRetries: 2,
  failureMode: "FAIL_CLOSED",
  retentionDays: 90,
  escalationRules: [
    { violationCount: 1, userAction: "WARN_USER" },
    { violationCount: 2, userAction: "RESTRICT_USER", restrictionDurationSec: 24 * 60 * 60 }, // 24h
    { violationCount: 3, userAction: "SUSPEND_USER", restrictionDurationSec: 3 * 24 * 60 * 60 }, // 3 days
    { violationCount: 5, userAction: "BAN_USER" }, // permanent
  ],
};

// ── Policy versioning ────────────────────────────────────────────────

/**
 * The current policy version. Bumped when the admin saves a new policy.
 * Stored in PlatformSetting `ai_moderation.policy_version` so it survives
 * restarts. Used to snapshot which policy produced each result (spec §45).
 *
 * Read by loadPolicy() — written by savePolicy().
 */

// ── Policy evaluation ────────────────────────────────────────────────

/**
 * Determine the moderation decision from a normalized result + the policy.
 *
 * Pure function — no DB access. The caller fetches:
 *   - The policy (via loadPolicy())
 *   - The user's violation count for the triggered category (via countUserViolations())
 *
 * @param result The normalized provider response.
 * @param policy The admin-configured policy.
 * @param priorViolationCount The user's prior violations of the SAME category.
 * @returns The final ModerationDecision.
 */
export function evaluatePolicy(
  result: NormalizedModerationResult,
  policy: ModerationPolicy,
  priorViolationCount: number
): ModerationDecision {
  // Step 1: find all triggered violations.
  const triggered: Array<{ category: ModerationCategory; score: number; policy: CategoryPolicy }> = [];
  for (const cat of CATEGORY_ORDER) {
    const score = result.categories[cat];
    if (score === null) continue; // provider didn't score this
    const catPolicy = (policy.categories[cat] as CategoryPolicy | undefined) ?? DEFAULT_CATEGORY_POLICY[cat];
    if (catPolicy.threshold > 0 && score >= catPolicy.threshold) {
      triggered.push({ category: cat, score, policy: catPolicy });
    }
  }

  // Step 2: no triggered violations → ALLOW.
  if (triggered.length === 0) {
    return {
      contentAction: "ALLOW",
      userAction: "NONE",
      restrictionDurationSec: null,
      triggeredCategory: null,
      threshold: 0,
      triggeredScore: result.score,
      severity: deriveSeverity(result.score),
      requiresReview: false,
      policyVersion: 0, // set by caller — see evaluatePolicyWithVersion
      userMessage: "", // empty = no message shown to user (content allowed)
    };
  }

  // Step 3: pick the highest-scoring triggered category.
  triggered.sort((a, b) => b.score - a.score);
  const top = triggered[0];

  // Step 4: look up the per-category policy.
  let contentAction: ContentAction = top.policy.contentAction;
  let userAction: UserAction = top.policy.userAction;
  let restrictionDurationSec: number | null = top.policy.restrictionDurationSec ?? null;

  // Step 5: apply escalation (only if user has prior violations of the same category).
  if (priorViolationCount > 0 && policy.escalationRules && policy.escalationRules.length > 0) {
    // The total violation count INCLUDING this one (prior + 1).
    const totalViolations = priorViolationCount + 1;
    // Find the highest escalation rule whose violationCount <= totalViolations.
    const sortedRules = [...policy.escalationRules].sort((a, b) => b.violationCount - a.violationCount);
    const matchedRule = sortedRules.find((r) => r.violationCount <= totalViolations);
    if (matchedRule) {
      // Only escalate the userAction — keep the contentAction from the policy.
      // (e.g. 1st violation = DELETE + WARN, 3rd violation = DELETE + SUSPEND.)
      userAction = matchedRule.userAction;
      if (matchedRule.restrictionDurationSec !== undefined) {
        restrictionDurationSec = matchedRule.restrictionDurationSec;
      }
    }
  }

  // Step 6: determine if review is needed.
  // FLAG_FOR_REVIEW + HIDE_CONTENT always create a review item.
  // BLOCK_CONTENT + DELETE_CONTENT do NOT create a review item (the action
  // is destructive — but the admin can still see the result in the stats
  // + can override via the review queue if they manually re-moderate).
  // Actually, per spec §17, ALL non-ALLOW actions should be reviewable.
  // We create a review item for FLAG_FOR_REVIEW + HIDE_CONTENT + BLOCK_CONTENT
  // + DELETE_CONTENT so the admin can override (spec §18).
  const requiresReview = contentAction !== "ALLOW";

  // Step 7: build the user-facing message (never reveals detection details).
  const userMessage = buildUserMessage(contentAction);

  return {
    contentAction,
    userAction,
    restrictionDurationSec,
    triggeredCategory: top.category,
    threshold: top.policy.threshold,
    triggeredScore: top.score,
    severity: deriveSeverity(top.score),
    requiresReview,
    policyVersion: 0, // set by caller
    userMessage,
  };
}

/** Derive the severity bucket from a 0..1 score. */
function deriveSeverity(score: number): "LOW" | "MEDIUM" | "HIGH" | "CRITICAL" {
  if (score >= 0.95) return "CRITICAL";
  if (score >= 0.85) return "HIGH";
  if (score >= 0.70) return "MEDIUM";
  return "LOW";
}

/** Build a safe end-user message that never reveals detection details (spec §50). */
function buildUserMessage(action: ContentAction): string {
  switch (action) {
    case "ALLOW":
      return "";
    case "FLAG_FOR_REVIEW":
      return "Your content has been submitted for review. It will be visible to others once it has been approved by our moderation team.";
    case "HIDE_CONTENT":
      return "Your content has been hidden pending review by our moderation team.";
    case "BLOCK_CONTENT":
      return "This content cannot be published because it may violate our community guidelines. Please review our guidelines and try again.";
    case "DELETE_CONTENT":
      return "This content was removed because it violates our community guidelines.";
    default:
      return "";
  }
}

// ── User action enforcement ──────────────────────────────────────────

/**
 * Determine whether a userAction requires writing to the User table
 * (e.g. status="SUSPENDED") + the AiModerationUserViolation table.
 *
 * NONE + WARN_USER do NOT change the user's status — WARN_USER only
 * creates a UserWarning row (which the existing admin warning flow uses).
 * The caller (Service) handles the DB writes.
 */
export function userActionRequiresDbWrite(action: UserAction): boolean {
  return action === "RESTRICT_USER" || action === "SUSPEND_USER" || action === "BAN_USER";
}

/**
 * Map a UserAction to the User.status value.
 * - RESTRICT_USER → "ACTIVE" (still active, but restrictions tracked separately)
 * - SUSPEND_USER → "SUSPENDED"
 * - BAN_USER → "BANNED"
 * - NONE / WARN_USER → no status change (caller should skip the User update)
 */
export function userActionToStatus(action: UserAction): "SUSPENDED" | "BANNED" | null {
  switch (action) {
    case "SUSPEND_USER":
      return "SUSPENDED";
    case "BAN_USER":
      return "BANNED";
    default:
      return null;
  }
}
