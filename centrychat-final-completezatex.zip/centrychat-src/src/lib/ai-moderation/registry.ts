/**
 * AI Moderation — Provider Registry
 * =================================
 *
 * SERVER-ONLY. Maintains the singleton adapter instances + provides a
 * factory function that returns the right adapter for a given
 * `ProviderType`. This is the ONLY place that knows about concrete
 * adapter classes — everything else talks to `ModerationProvider`.
 *
 * Adding a new provider type requires:
 *   1. Implement the adapter (extends nothing, just implements `ModerationProvider`).
 *   2. Add a case to `getAdapter(type)`.
 *   3. Add the type to `PROVIDER_TYPES` in types.ts.
 *
 * That's it — no changes to the Service, Policy Engine, API routes, etc.
 */

import type { ModerationProvider, ProviderType } from "./types";
import { OpenAIModerationProvider } from "./adapters/openai";
import { GeminiModerationProvider } from "./adapters/gemini";
import { HuggingFaceModerationProvider } from "./adapters/huggingface";
import { CustomModerationProvider, LocalModerationProvider } from "./adapters/custom";

// ── Singleton adapter instances ───────────────────────────────────────
// Adapters are stateless — they don't hold config between calls (config is
// passed per-call). So a single instance per type is safe + avoids GC churn.

const _openai = new OpenAIModerationProvider();
const _gemini = new GeminiModerationProvider();
const _huggingface = new HuggingFaceModerationProvider();
const _custom = new CustomModerationProvider();
const _local = new LocalModerationProvider();

const REGISTRY: Record<ProviderType, ModerationProvider> = {
  openai: _openai,
  gemini: _gemini,
  huggingface: _huggingface,
  custom: _custom,
  local: _local,
};

/**
 * Get the adapter for a provider type.
 * Throws when the type is unknown — fail-fast (should never happen since
 * the DB column is typed).
 */
export function getAdapter(type: ProviderType): ModerationProvider {
  const adapter = REGISTRY[type];
  if (!adapter) {
    throw new Error(`Unknown moderation provider type: ${type}`);
  }
  return adapter;
}

/**
 * Get all registered provider types + their adapters. Used by the admin
 * "Add Provider" form to populate the type dropdown.
 */
export function listProviderTypes(): Array<{ type: ProviderType; adapter: ModerationProvider }> {
  return Object.entries(REGISTRY).map(([type, adapter]) => ({
    type: type as ProviderType,
    adapter,
  }));
}
