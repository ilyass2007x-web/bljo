/**
 * AI Moderation — SSRF Protection for Provider Endpoints
 * =====================================================
 *
 * SERVER-ONLY. Validates + sanitizes provider endpoint URLs to prevent
 * Server-Side Request Forgery (SSRF) attacks.
 *
 * What is SSRF?
 *   When the moderation service calls a provider's API endpoint, it's
 *   making an HTTP request from the server. If an attacker can configure
 *   a malicious endpoint URL, they can make the server fetch arbitrary
 *   internal URLs — e.g.:
 *     - http://169.254.169.254/latest/meta-data/ (cloud metadata)
 *     - http://localhost:3000/admin/internal-api (internal services)
 *     - http://10.0.0.1:6379 (Redis on the internal network)
 *
 *   This module blocks those by:
 *     1. Validating the URL scheme (http/https only)
 *     2. Validating the hostname is not localhost / private IP / cloud metadata
 *     3. For non-local providers: rejecting any private IP range
 *     4. For "local" provider type: allowing localhost but NOT cloud metadata
 *
 * WHITELIST vs BLACKLIST approach:
 *   We use a denylist of dangerous hostnames/IP ranges. A whitelist would
 *   be safer but too restrictive for a moderation system that legitimately
 *   needs to call external APIs (OpenAI, Google, etc.).
 *
 *   The denylist covers:
 *     - Cloud metadata endpoints (169.254.169.254 — AWS/Azure/GCP metadata)
 *     - Link-local range (169.254.0.0/16)
 *     - Loopback range (127.0.0.0/8) — UNLESS the provider type is "local"
 *     - Private ranges (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)
 *     - IPv6 loopback (::1) + ULA (fc00::/7)
 */

// ── Types ─────────────────────────────────────────────────────────────

export type SsrfValidationResult =
  | { ok: true; url: string }
  | { ok: false; reason: string };

// ── Validation ────────────────────────────────────────────────────────

const BLOCKED_HOSTNAMES = new Set([
  "169.254.169.254", // AWS / Azure / GCP cloud metadata
  "metadata.google.internal", // GCP metadata DNS
  "metadata.internal",
  "0.0.0.0",
]);

/**
 * Check if an IPv4 address is in a given CIDR range.
 * Returns false for invalid inputs (defensive).
 */
function isIpInCidr(ip: string, cidr: string): boolean {
  const [rangeIp, rangeBitsStr] = cidr.split("/");
  if (!rangeIp || !rangeBitsStr) return false;
  const rangeBits = parseInt(rangeBitsStr, 10);
  if (isNaN(rangeBits) || rangeBits < 0 || rangeBits > 32) return false;

  const ipParts = ip.split(".").map((p) => parseInt(p, 10));
  const rangeParts = rangeIp.split(".").map((p) => parseInt(p, 10));
  if (ipParts.length !== 4 || rangeParts.length !== 4) return false;
  if (ipParts.some((p) => isNaN(p) || p < 0 || p > 255)) return false;
  if (rangeParts.some((p) => isNaN(p) || p < 0 || p > 255)) return false;

  // Convert to 32-bit integers
  const ipInt = (ipParts[0] << 24) | (ipParts[1] << 16) | (ipParts[2] << 8) | ipParts[3];
  const rangeInt = (rangeParts[0] << 24) | (rangeParts[1] << 16) | (rangeParts[2] << 8) | rangeParts[3];
  // JS bitwise ops are signed 32-bit — convert to unsigned via >>> 0
  const ipUint = ipInt >>> 0;
  const rangeUint = rangeInt >>> 0;

  // Compute the mask
  const mask = rangeBits === 0 ? 0 : (0xFFFFFFFF << (32 - rangeBits)) >>> 0;

  return (ipUint & mask) >>> 0 === (rangeUint & mask) >>> 0;
}

/** Returns true if the IP looks like a private/loopback/link-local IPv4 address. */
function isPrivateIpv4(ip: string): boolean {
  return (
    isIpInCidr(ip, "10.0.0.0/8") ||     // Private Class A
    isIpInCidr(ip, "172.16.0.0/12") || // Private Class B
    isIpInCidr(ip, "192.168.0.0/16") || // Private Class C
    isIpInCidr(ip, "127.0.0.0/8") ||   // Loopback
    isIpInCidr(ip, "169.254.0.0/16")   // Link-local
  );
}

/** Returns true if the hostname is the IPv6 loopback (::1). */
function isIpv6Loopback(hostname: string): boolean {
  return hostname === "::1" || hostname === "[::1]" || hostname === "0:0:0:0:0:0:0:1";
}

/**
 * Validate an endpoint URL for SSRF safety.
 *
 * @param url The endpoint URL the admin entered.
 * @param isLocalProvider When true, localhost / 127.0.0.1 / [::1] are ALLOWED
 *                        (used by the "local" provider type — the admin is
 *                        explicitly configuring a self-hosted model on the
 *                        same machine). All other SSRF rules still apply.
 */
export async function validateEndpointUrl(
  url: string,
  opts: { isLocalProvider?: boolean } = {}
): Promise<SsrfValidationResult> {
  if (!url || typeof url !== "string") {
    return { ok: false, reason: "Endpoint URL is required" };
  }
  const trimmed = url.trim();
  if (trimmed.length > 400) {
    return { ok: false, reason: "Endpoint URL is too long (max 400 chars)" };
  }
  // Scheme check — only http + https allowed.
  const lower = trimmed.toLowerCase();
  if (!lower.startsWith("https://") && !lower.startsWith("http://")) {
    return { ok: false, reason: "Endpoint must use http:// or https:// scheme" };
  }
  // Parse the URL via the standard URL constructor. Catches malformed URLs.
  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return { ok: false, reason: "Endpoint URL is not a valid URL" };
  }
  // Reject any URL with credentials embedded (http://user:pass@host).
  if (parsed.username || parsed.password) {
    return { ok: false, reason: "Endpoint URL must not contain credentials" };
  }
  const hostname = parsed.hostname.toLowerCase();
  if (!hostname) {
    return { ok: false, reason: "Endpoint URL must have a hostname" };
  }
  // Strip the brackets from IPv6 hostnames for the metadata check.
  const bareHost = hostname.replace(/^\[/, "").replace(/\]$/, "");

  // 1. Blocklisted hostnames (cloud metadata).
  if (BLOCKED_HOSTNAMES.has(bareHost)) {
    return { ok: false, reason: "Endpoint points to a blocked hostname (cloud metadata or unsafe address)" };
  }

  // 2. IPv6 loopback.
  if (isIpv6Loopback(bareHost) && !opts.isLocalProvider) {
    return { ok: false, reason: "Endpoint points to IPv6 loopback — not allowed for this provider type" };
  }

  // 3. IPv4 private / loopback / link-local.
  if (/^\d+\.\d+\.\d+\.\d+$/.test(bareHost)) {
    if (isPrivateIpv4(bareHost)) {
      // Allow loopback (127.0.0.0/8) ONLY for the local provider type.
      // Allow other private ranges (10.x, 172.16-31.x, 192.168.x) ONLY for
      // the local provider type (admin is configuring a self-hosted model
      // on the same network — e.g. a Kubernetes pod IP).
      if (!opts.isLocalProvider) {
        return {
          ok: false,
          reason: "Endpoint points to a private or loopback IP — not allowed for this provider type (use the 'local' provider type for self-hosted models)",
        };
      }
      // Even for the local provider type, block link-local (169.254.x.x).
      if (isIpInCidr(bareHost, "169.254.0.0/16")) {
        return { ok: false, reason: "Endpoint points to a link-local address (169.254.x.x) — not allowed" };
      }
    }
  }

  // 4. localhost / *.localhost — allowed only for local provider.
  if ((bareHost === "localhost" || bareHost.endsWith(".localhost")) && !opts.isLocalProvider) {
    return { ok: false, reason: "Endpoint points to localhost — not allowed for this provider type (use the 'local' provider type)" };
  }

  // 5. Reject ports below 1024 except 80/443 (prevent hitting internal services
  // like Postgres on 5432, Redis on 6379, etc.). PLUS reject well-known
  // database / cache / internal-service ports even though they're above
  // 1024 — defense-in-depth against accidental misconfiguration that
  // would let the moderation pipeline talk to a database instead of an
  // HTTP API. The well-known denylist:
  //   - 5432  PostgreSQL
  //   - 6379  Redis
  //   - 27017 MongoDB
  //   - 3306  MySQL
  //   - 1433  Microsoft SQL Server
  //   - 9200  Elasticsearch
  //   - 9042  Cassandra
  //   - 11211 Memcached
  // These ports would NEVER serve an HTTP moderation API — rejecting
  // them is safe and prevents accidental SSRF-to-DB attacks.
  const BLOCKED_DB_PORTS = new Set([5432, 6379, 27017, 3306, 1433, 9200, 9042, 11211]);
  const port = parsed.port ? parseInt(parsed.port, 10) : (parsed.protocol === "https:" ? 443 : 80);
  if (port < 1024 && port !== 80 && port !== 443) {
    return { ok: false, reason: `Endpoint port ${port} is in the privileged range (<1024) — only 80, 443, and ports >=1024 are allowed` };
  }
  if (BLOCKED_DB_PORTS.has(port)) {
    return { ok: false, reason: `Endpoint port ${port} is a well-known database or cache port — moderation endpoints must be HTTP APIs, not databases` };
  }

  // 6. SECURITY FIX — DNS resolution check (defense-in-depth against DNS rebinding).
  //
  // The above checks (1–5) only inspect the LITERAL hostname/IP. An
  // attacker who controls an authoritative DNS server for
  // `evil.example.com` could configure it to return:
  //   - First lookup: a PUBLIC IP (passes our check).
  //   - Later (when the moderation adapter actually fetches the URL):
  //     127.0.0.1 or 169.254.169.254 (cloud metadata).
  //
  // This is the classic DNS-rebinding SSRF bypass. To close it:
  //   - Resolve the hostname via `dns.lookup` at validation time.
  //   - Check EVERY returned IP against the private ranges (10/8, 172.16/12,
  //     192.168/16, 127/8, 169.254/16, IPv6 ::1, IPv6 ULA fc00::/7, IPv6
  //     link-local fe80::/10).
  //   - Reject if ANY returned IP is private.
  //
  // Note: this is the SAME defense as the media resolver's `isPrivateHostname`.
  // For LOCAL provider type, we skip this DNS check (the admin has explicitly
  // opted into self-hosted models on the local network — DNS resolution
  // would reject their legitimate 10.x pod IP).
  if (!opts.isLocalProvider) {
    const dnsOk = await isHostnameSafeViaDns(bareHost);
    if (!dnsOk) {
      return {
        ok: false,
        reason: "Endpoint hostname resolves to a private, loopback, link-local, or cloud-metadata IP — blocked by DNS pinning defense",
      };
    }
  }

  return { ok: true, url: trimmed };
}

/**
 * Resolve a hostname via DNS + verify ALL returned IPs are public.
 *
 * Used by `validateEndpointUrl` (step 6) to close the DNS-rebinding
 * TOCTOU gap for admin-configured AI-moderation provider endpoints.
 *
 * Returns true when the hostname is SAFE (all resolved IPs are public),
 * false when ANY resolved IP is private/loopback/link-local/reserved.
 *
 * If DNS resolution fails (NXDOMAIN, no records), we return true
 * (fail-open) — the actual fetch will surface the failure. This matches
 * the media resolver's `isPrivateHostname` behavior.
 */
async function isHostnameSafeViaDns(hostname: string): Promise<boolean> {
  // IPv6 loopback (no DNS resolution needed).
  if (isIpv6Loopback(hostname)) return false;

  // If the hostname is already a literal IP, skip DNS (already checked
  // in step 3 above).
  if (/^\d+\.\d+\.\d+\.\d+$/.test(hostname)) return true;

  // Blocklist (already checked above, but defensive — short-circuits DNS).
  if (BLOCKED_HOSTNAMES.has(hostname)) return false;
  if (hostname === "localhost" || hostname.endsWith(".localhost")) return false;

  // Lazy import — keeps this module loadable without `node:dns` at module
  // evaluation time (Next.js may try to bundle it for client-side if it's
  // imported in a client component, which it shouldn't be).
  const dns = await import("node:dns/promises");
  const net = await import("node:net");

  try {
    const [v4, v6] = await Promise.allSettled([
      dns.resolve4(hostname),
      dns.resolve6(hostname),
    ]);
    const resolved: string[] = [
      ...(v4.status === "fulfilled" ? v4.value : []),
      ...(v6.status === "fulfilled" ? v6.value : []),
    ];

    if (resolved.length === 0) {
      // No DNS records — fail-open (the fetch will surface the error).
      return true;
    }

    for (const ip of resolved) {
      const kind = net.isIP(ip);
      if (!kind) continue;
      if (isPrivateByKind(ip, kind)) return false;
    }
    return true;
  } catch {
    // DNS resolution failed — fail-open (the fetch will surface the error).
    return true;
  }
}

/** Check whether an IP literal (of the given kind) is private/reserved. */
function isPrivateByKind(ip: string, kind: number): boolean {
  if (kind === 4) {
    return isPrivateIpv4(ip);
  }
  if (kind === 6) {
    const lower = ip.toLowerCase();
      // ::1 — loopback
      if (lower === "::1") return true;
      // fc00::/7 — ULA (private)
      if (/^f[cd][0-9a-f]{2}:/.test(lower)) return true;
      // fe80::/10 — link-local
      if (/^fe[89ab][0-9a-f]:/.test(lower)) return true;
      // ::ffff:v4 — IPv4-mapped IPv6 (recurse into IPv4 check)
      const v4Mapped = lower.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
      if (v4Mapped) {
        return isPrivateIpv4(v4Mapped[1]!);
      }
      // 2001:db8::/32 — documentation
      if (/^2001:db8:/.test(lower)) return true;
      return false;
  }
  return true; // unknown kind — block by default
}
