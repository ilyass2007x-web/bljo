/**
 * AI Moderation — Encryption (AES-GCM)
 * ====================================
 *
 * SERVER-ONLY. Provides AES-256-GCM encryption for provider API keys.
 *
 * Design:
 *   - The encryption key (MODERATION_ENCRYPTION_KEY) lives ONLY in the
 *     server-side environment. NEVER in the database. NEVER in NEXT_PUBLIC_*.
 *   - Ciphertext format: "<base64(ciphertext)>:<base64(iv)>:<base64(authTag)>"
 *     — this format is stored in the ai_moderation_provider.api_key_encrypted
 *     column. The IV + authTag are needed for decryption.
 *   - AES-GCM provides BOTH confidentiality AND authenticity. An attacker
 *     who tampers with the ciphertext or IV cannot decrypt it (authTag
 *     check fails) — so we don't need a separate HMAC.
 *   - The IV (Initialization Vector) is cryptographically random per
 *     encryption call. Even if the same key is encrypted twice, the
 *     ciphertexts are different.
 *
 * SECURITY:
 *   - NEVER log the plaintext key. NEVER return it in API responses.
 *   - The masking helper (maskApiKey) shows only the last 4 chars — e.g.
 *     "••••••••••••1234". This is safe to expose to the admin UI.
 *   - If MODERATION_ENCRYPTION_KEY is unset or too short, we fail-closed
 *     in production (throw). In dev/test, we use a deterministic dev key
 *     so the build succeeds without real secrets.
 */

// ── Key Resolution ────────────────────────────────────────────────────

const DEV_FALLBACK_KEY =
  "dev-only-insecure-moderation-key-please-set-MODERATION_ENCRYPTION_KEY-xxxxx";

let _resolvedKey: Buffer | null = null;

/**
 * Resolve + cache the encryption key. Lazily evaluated so `next build`
 * succeeds without the env var present at build time (secrets are runtime
 * concerns, not build-time concerns).
 *
 * SECURITY: fail-closed in production. In dev/test, a deterministic dev
 * key is used (so the build succeeds) — but never in production.
 *
 * Uses Node's classic `createHash` (sync) — avoids the async webcrypto
 * subtle.digest dance that would force encrypt/decrypt to be async.
 */
function resolveKeySync(): Buffer {
  if (_resolvedKey !== null) return _resolvedKey;
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { createHash } = require("node:crypto") as typeof import("node:crypto");

  const envKey = process.env.MODERATION_ENCRYPTION_KEY;
  const env = process.env.NODE_ENV;

  if (!envKey || envKey.length < 32) {
    if (env !== "development" && env !== "test") {
      throw new Error(
        "MODERATION_ENCRYPTION_KEY must be set to a random string of at least 32 characters. " +
          "Generate one with: openssl rand -hex 32"
      );
    }
    if (!envKey) {
      console.warn(
        "[ai-moderation] MODERATION_ENCRYPTION_KEY is not set — using insecure dev fallback. " +
          "DO NOT use in production."
      );
    }
    // Pad the env key (or the fallback) to at least 32 chars before hashing.
    const source = (envKey || DEV_FALLBACK_KEY).padEnd(32, "0");
    _resolvedKey = createHash("sha256").update(source).digest();
    return _resolvedKey;
  }

  // Production: SHA-256 the env var to normalize to exactly 32 bytes for AES-256.
  _resolvedKey = createHash("sha256").update(envKey).digest();
  return _resolvedKey;
}

// ── Public API ────────────────────────────────────────────────────────

/**
 * Encrypt an API key (plaintext → "ciphertext:iv:authTag" base64).
 *
 * SERVER-ONLY. NEVER expose the plaintext key to the client, in logs,
 * in API responses, in error messages, or in audit metadata.
 *
 * @param plaintext The API key to encrypt (must be non-empty).
 * @returns The encrypted string suitable for storing in the DB.
 */
export function encryptApiKey(plaintext: string): string {
  if (!plaintext || typeof plaintext !== "string") {
    throw new Error("encryptApiKey: plaintext must be a non-empty string");
  }
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { createCipheriv, randomBytes } = require("node:crypto") as typeof import("node:crypto");
  const key = resolveKeySync();
  // AES-256-GCM. IV must be 12 bytes (96 bits) for GCM — that's the
  // recommended length and what Node's createCipheriv expects.
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  // Format: "<base64(ciphertext)>:<base64(iv)>:<base64(authTag)>"
  return `${ciphertext.toString("base64")}:${iv.toString("base64")}:${authTag.toString("base64")}`;
}

/**
 * Decrypt an API key ("ciphertext:iv:authTag" base64 → plaintext).
 *
 * SERVER-ONLY. The plaintext is passed to the provider adapter and is
 * NEVER logged, NEVER returned in API responses, NEVER persisted anywhere
 * outside the encrypted DB column.
 *
 * @returns The plaintext API key. Throws on tampering (authTag mismatch)
 *          or on malformed input.
 */
export function decryptApiKey(encrypted: string): string {
  if (!encrypted || typeof encrypted !== "string") {
    throw new Error("decryptApiKey: encrypted value must be a non-empty string");
  }
  const parts = encrypted.split(":");
  if (parts.length !== 3) {
    throw new Error("decryptApiKey: malformed encrypted value (expected 3 parts)");
  }
  const [ciphertextB64, ivB64, authTagB64] = parts;
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { createDecipheriv } = require("node:crypto") as typeof import("node:crypto");
  const key = resolveKeySync();
  const ciphertext = Buffer.from(ciphertextB64, "base64");
  const iv = Buffer.from(ivB64, "base64");
  const authTag = Buffer.from(authTagB64, "base64");
  if (iv.length !== 12) {
    throw new Error(`decryptApiKey: IV must be 12 bytes (got ${iv.length})`);
  }
  if (authTag.length !== 16) {
    throw new Error(`decryptApiKey: authTag must be 16 bytes (got ${authTag.length})`);
  }
  const decipher = createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(authTag);
  try {
    const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
    return plaintext.toString("utf8");
  } catch {
    // AuthTag mismatch — ciphertext was tampered with or wrong key.
    // NEVER include the ciphertext in the error message (it might leak).
    throw new Error("decryptApiKey: decryption failed (tampered ciphertext or wrong key)");
  }
}

/**
 * Mask an API key for safe display in the admin UI.
 *
 * Returns "••••••••••••XXXX" where XXXX is the last 4 chars of the plaintext.
 * When the plaintext is shorter than 8 chars, masks everything (returns "••••").
 *
 * Accepts either the encrypted form (we decrypt first) or the plaintext
 * directly. When given the encrypted form, decryption failure returns a
 * placeholder ("[encrypted — key unavailable]") — NEVER throws to the
 * admin UI (the admin can't fix a missing encryption key from the UI).
 *
 * @param input The API key (plaintext or encrypted) OR null/empty.
 * @returns The masked string. Empty string when input is null/empty.
 */
export function maskApiKey(input: string | null | undefined): string {
  if (!input) return "";
  let plaintext: string;
  // Detect the encrypted form (contains 2 colons + valid base64 parts).
  // If it doesn't look encrypted, treat it as plaintext (defensive).
  const parts = input.split(":");
  const looksEncrypted =
    parts.length === 3 &&
    /^[A-Za-z0-9+/=]+$/.test(parts[0]) &&
    /^[A-Za-z0-9+/=]+$/.test(parts[1]) &&
    /^[A-Za-z0-9+/=]+$/.test(parts[2]);
  if (looksEncrypted) {
    try {
      plaintext = decryptApiKey(input);
    } catch {
      return "[encrypted — key unavailable]";
    }
  } else {
    plaintext = input;
  }
  if (plaintext.length <= 4) return "••••";
  if (plaintext.length < 12) {
    return "•".repeat(plaintext.length - 4) + plaintext.slice(-4);
  }
  return "•".repeat(12) + plaintext.slice(-4);
}

/**
 * Has the MODERATION_ENCRYPTION_KEY been configured?
 *
 * Used by the admin UI to show a warning when the env var is missing
 * (the admin can't fix this from the UI — they need to set the env var
 * in Netlify). NEVER throws.
 */
export function isEncryptionKeyConfigured(): boolean {
  try {
    resolveKeySync();
    return true;
  } catch {
    return false;
  }
}

/**
 * Test-only helper. Resets the cached key so tests can swap env vars.
 * NEVER call in production.
 */
export function _resetEncryptionKeyCacheForTests(): void {
  _resolvedKey = null;
}
