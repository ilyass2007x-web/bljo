/**
 * AI Moderation — Admin Stats + Review Queue Helpers
 * ==================================================
 *
 * SERVER-ONLY. Used by the admin API routes to fetch dashboard stats +
 * paginated review queue items. All queries use the existing Prisma
 * client — no raw SQL, no new patterns.
 */

import { db } from "@/lib/database";
import { Prisma } from "@prisma/client";
import type { ModerationCategory } from "./types";

// ── Stats ─────────────────────────────────────────────────────────────

export interface AiModerationStats {
  totalResults: number;
  allowed: number;
  flagged: number;
  hidden: number;
  blocked: number;
  deleted: number;
  pendingReviews: number;
  reviewedApprove: number;
  reviewedReject: number;
  reviewedOverride: number;
  warnings: number;
  restrictions: number;
  suspensions: number;
  bans: number;
  providerErrors: number;
  fallbackUsage: number;
  avgProcessingTimeMs: number;
  topCategories: Array<{ category: string; count: number }>;
  last7Days: Array<{ date: string; count: number }>;
  providers: Array<{
    id: string;
    name: string;
    type: string;
    model: string;
    priority: number;
    healthStatus: string;
    totalRequests: number;
    failedRequests: number;
    failureRate: number;
    lastHealthCheck: string | null;
  }>;
}

export async function getAiModerationStats(): Promise<AiModerationStats> {
  const [
    totalResults,
    allowed,
    flagged,
    hidden,
    blocked,
    deleted,
    pendingReviews,
    reviewedApprove,
    reviewedReject,
    reviewedOverride,
    warnings,
    restrictions,
    suspensions,
    bans,
    fallbackUsage,
    avgProcessingAgg,
    topCategoriesRaw,
    last7DaysRaw,
    providers,
  ] = await Promise.all([
    db.aiModerationResult.count(),
    db.aiModerationResult.count({ where: { action: "ALLOW" } }),
    db.aiModerationResult.count({ where: { action: "FLAG_FOR_REVIEW" } }),
    db.aiModerationResult.count({ where: { action: "HIDE_CONTENT" } }),
    db.aiModerationResult.count({ where: { action: "BLOCK_CONTENT" } }),
    db.aiModerationResult.count({ where: { action: "DELETE_CONTENT" } }),
    db.aiModerationReviewItem.count({ where: { status: "PENDING" } }),
    db.aiModerationReviewItem.count({ where: { status: "APPROVED" } }),
    db.aiModerationReviewItem.count({ where: { status: "REJECTED" } }),
    db.aiModerationReviewItem.count({ where: { status: "OVERRIDDEN" } }),
    db.aiModerationUserViolation.count({ where: { appliedAction: "WARN_USER" } }),
    db.aiModerationUserViolation.count({ where: { appliedAction: "RESTRICT_USER" } }),
    db.aiModerationUserViolation.count({ where: { appliedAction: "SUSPEND_USER" } }),
    db.aiModerationUserViolation.count({ where: { appliedAction: "BAN_USER" } }),
    db.aiModerationResult.count({ where: { NOT: { fallbackFrom: null } } }),
    // Average processing time (null when no results yet).
    db.aiModerationResult.aggregate({ _avg: { processingTimeMs: true } }),
    // Top categories — fetch raw + aggregate in code (same pattern as the
    // existing moderation stats).
    db.aiModerationUserViolation.findMany({
      select: { category: true },
    }),
    // Last 7 days.
    db.aiModerationResult.findMany({
      where: { createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } },
      select: { createdAt: true },
      orderBy: { createdAt: "asc" },
    }),
    // Providers.
    db.aiModerationProvider.findMany({
      orderBy: [{ priority: "asc" }, { createdAt: "asc" }],
      select: {
        id: true, name: true, type: true, model: true, priority: true,
        healthStatus: true, totalRequests: true, failedRequests: true,
        lastHealthCheck: true,
      },
    }),
  ]);

  // Aggregate top categories.
  const categoryCounts = new Map<string, number>();
  for (const v of topCategoriesRaw) {
    categoryCounts.set(v.category, (categoryCounts.get(v.category) ?? 0) + 1);
  }
  const topCategories = [...categoryCounts.entries()]
    .map(([category, count]) => ({ category, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  // Bucket last-7-days by day.
  const dayBuckets = new Map<string, number>();
  for (const r of last7DaysRaw) {
    const d = r.createdAt;
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    dayBuckets.set(key, (dayBuckets.get(key) ?? 0) + 1);
  }
  const last7Days: Array<{ date: string; count: number }> = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    last7Days.push({ date: key, count: dayBuckets.get(key) ?? 0 });
  }

  return {
    totalResults,
    allowed,
    flagged,
    hidden,
    blocked,
    deleted,
    pendingReviews,
    reviewedApprove,
    reviewedReject,
    reviewedOverride,
    warnings,
    restrictions,
    suspensions,
    bans,
    providerErrors: providers.reduce((sum, p) => sum + p.failedRequests, 0),
    fallbackUsage,
    avgProcessingTimeMs: avgProcessingAgg._avg.processingTimeMs ?? 0,
    topCategories,
    last7Days,
    providers: providers.map((p) => ({
      ...p,
      failureRate: p.totalRequests > 0 ? p.failedRequests / p.totalRequests : 0,
      lastHealthCheck: p.lastHealthCheck?.toISOString() ?? null,
    })),
  };
}

// ── Review Queue ─────────────────────────────────────────────────────

export interface ReviewQueueFilter {
  status?: "PENDING" | "APPROVED" | "REJECTED" | "OVERRIDDEN";
  providerId?: string;
  contentType?: string;
  category?: string;
  userId?: string;
  page: number;
  pageSize: number;
}

export interface ReviewQueueItem {
  id: string;
  status: string;
  resultId: string;
  providerName: string;
  modelName: string;
  contentType: string;
  contentId: string | null;
  categoryScores: Record<string, number | null>;
  score: number;
  confidence: number | null;
  reason: string;
  action: string;
  policyVersion: number;
  fallbackFrom: string | null;
  processingTimeMs: number;
  createdAt: string;
  reviewedAt: string | null;
  reviewerId: string | null;
  reviewerName: string | null;
  adminNotes: string | null;
  appliedActions: string[];
  // Joined user (when available).
  userId: string | null;
  userFullName: string | null;
  userUsername: string | null;
}

export async function getReviewQueue(filter: ReviewQueueFilter): Promise<{
  items: ReviewQueueItem[];
  total: number;
}> {
  const page = Math.max(1, filter.page);
  const pageSize = Math.min(100, Math.max(1, filter.pageSize));

  const where: {
    status?: string;
    result?: {
      providerId?: string;
      contentType?: string;
      userId?: string;
    };
  } = {};
  if (filter.status) where.status = filter.status;
  if (filter.providerId || filter.contentType || filter.userId) {
    where.result = {};
    if (filter.providerId) where.result.providerId = filter.providerId;
    if (filter.contentType) where.result.contentType = filter.contentType;
    if (filter.userId) where.result.userId = filter.userId;
  }
  // Category filter requires a JSON-path query — we'll filter client-side
  // for simplicity (the per-category counts are usually small enough that
  // the admin can scroll to find specific categories). This is a known
  // limitation documented in the admin UI.

  const [rows, total] = await Promise.all([
    db.aiModerationReviewItem.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        result: {
          select: {
            id: true, providerName: true, modelName: true, contentType: true,
            contentId: true, categoryScores: true, score: true, confidence: true,
            reason: true, action: true, policyVersion: true, fallbackFrom: true,
            processingTimeMs: true, createdAt: true, userId: true,
            user: { select: { id: true, fullName: true, username: true } },
          },
        },
        reviewer: { select: { id: true, fullName: true } },
      },
    }),
    db.aiModerationReviewItem.count({ where }),
  ]);

  const items: ReviewQueueItem[] = rows.map((r) => ({
    id: r.id,
    status: r.status,
    resultId: r.resultId,
    providerName: r.result?.providerName ?? "(deleted)",
    modelName: r.result?.modelName ?? "",
    contentType: r.result?.contentType ?? "",
    contentId: r.result?.contentId ?? null,
    categoryScores: (r.result?.categoryScores as Record<string, number | null>) ?? {},
    score: r.result?.score ?? 0,
    confidence: r.result?.confidence ?? null,
    reason: r.result?.reason ?? "",
    action: r.result?.action ?? "",
    policyVersion: r.result?.policyVersion ?? 0,
    fallbackFrom: r.result?.fallbackFrom ?? null,
    processingTimeMs: r.result?.processingTimeMs ?? 0,
    createdAt: r.result?.createdAt.toISOString() ?? r.createdAt.toISOString(),
    reviewedAt: r.reviewedAt?.toISOString() ?? null,
    reviewerId: r.reviewer?.id ?? null,
    reviewerName: r.reviewer?.fullName ?? null,
    adminNotes: r.adminNotes,
    appliedActions: Array.isArray(r.appliedActions) ? (r.appliedActions as string[]) : [],
    userId: r.result?.user?.id ?? null,
    userFullName: r.result?.user?.fullName ?? null,
    userUsername: r.result?.user?.username ?? null,
  }));

  return { items, total };
}

// ── Admin override action ────────────────────────────────────────────

export interface ReviewActionInput {
  reviewId: string;
  newStatus: "APPROVED" | "REJECTED" | "OVERRIDDEN";
  notes?: string;
  overrideContentAction?: "ALLOW" | "FLAG_FOR_REVIEW" | "HIDE_CONTENT" | "BLOCK_CONTENT" | "DELETE_CONTENT";
  overrideUserAction?: "NONE" | "WARN_USER" | "RESTRICT_USER" | "SUSPEND_USER" | "BAN_USER";
}

/**
 * Apply an admin override to a review item.
 *
 * Per spec §18: the admin override has PRIORITY over the AI decision.
 *   - APPROVE → keep the content as-is (override of AI's BLOCK/HIDE/DELETE)
 *   - REJECT → confirm the AI's decision (or escalate an ALLOW)
 *   - OVERRIDDEN → admin changed the AI's decision in any way
 *
 * Returns the applied actions (for the audit trail).
 */
export async function applyReviewAction(
  input: ReviewActionInput,
  adminId: string
): Promise<{ ok: boolean; notFound?: boolean; appliedActions: string[] }> {
  const item = await db.aiModerationReviewItem.findUnique({
    where: { id: input.reviewId },
    include: { result: { select: { contentId: true, contentType: true, userId: true, action: true } } },
  });
  if (!item) return { ok: false, notFound: true, appliedActions: [] };

  const appliedActions: string[] = [];

  // 1. Update the review item.
  await db.aiModerationReviewItem.update({
    where: { id: input.reviewId },
    data: {
      status: input.newStatus,
      adminNotes: input.notes ?? null,
      reviewerId: adminId,
      reviewedAt: new Date(),
      // Persist the applied actions for audit (start with empty — populated below).
      appliedActions: [] as unknown as Prisma.InputJsonValue,
    },
  });

  // 2. Apply the content action override (if provided).
  if (input.overrideContentAction && item.result?.contentId) {
    const { applyContentAction } = await import("./service");
    const ok = await applyContentAction(
      item.result.contentType,
      item.result.contentId,
      input.overrideContentAction
    );
    if (ok) appliedActions.push(input.overrideContentAction);
  } else if (input.newStatus === "APPROVED" && item.result?.contentId) {
    // APPROVE = make the content public (override any HIDE/BLOCK).
    const { approveContent } = await import("@/lib/moderation/pipeline");
    const ok = await approveContent(item.result.contentType as never, item.result.contentId);
    if (ok) appliedActions.push("APPROVE_CONTENT");
  } else if (input.newStatus === "REJECTED" && item.result?.contentId) {
    // REJECT = hide/delete the content (confirm AI's decision).
    const { rejectContent } = await import("@/lib/moderation/pipeline");
    const ok = await rejectContent(item.result.contentType as never, item.result.contentId, false);
    if (ok) appliedActions.push("REJECT_CONTENT");
  }

  // 3. Apply the user action override (if provided).
  if (input.overrideUserAction && input.overrideUserAction !== "NONE" && item.result?.userId) {
    const { applyUserAction } = await import("./service");
    const ok = await applyUserAction(item.result.userId, input.overrideUserAction);
    if (ok) appliedActions.push(input.overrideUserAction);
  }

  // 4. Update the review item with the final applied actions list.
  await db.aiModerationReviewItem.update({
    where: { id: input.reviewId },
    data: { appliedActions: appliedActions as unknown as Prisma.InputJsonValue },
  });

  return { ok: true, appliedActions };
}
