/**
 * AI Moderation — Provider Test Helper
 * ====================================
 *
 * SERVER-ONLY. Called by the "Test Provider" button in the admin UI.
 * Tests a provider configuration WITHOUT persisting it — the admin
 * can verify the API key + endpoint + model work BEFORE saving.
 *
 * The helper:
 *   1. Decrypts the API key (when an existing provider ID is given).
 *   2. OR uses the draft API key from the request body (when testing a NEW config).
 *   3. Builds a ProviderRuntimeConfig.
 *   4. Calls the adapter's `healthCheck()`.
 *   5. Updates the provider's health columns (when testing an existing provider).
 *   6. Returns a SAFE result — NEVER includes the API key, endpoint query params,
 *      or the full HTTP response body.
 */

import { db } from "@/lib/database";
import { decryptApiKey } from "./encryption";
import { getAdapter } from "./registry";
import { validateEndpointUrl } from "./ssrf";
import type { ProviderType, HealthCheckResult, ProviderRuntimeConfig } from "./types";
import { ModerationProviderConfigError } from "./types";

export interface TestProviderInput {
  /** When provided, test an EXISTING provider by ID (uses the stored encrypted API key). */
  providerId?: string;
  /** When providerId is omitted, test a DRAFT config (not yet persisted). */
  draftConfig?: {
    type: ProviderType;
    model: string;
    apiKey?: string;       // plaintext (admin entered it in the form — we test then discard)
    endpoint?: string | null;
  };
}

export interface TestProviderOutput {
  healthy: boolean;
  reason: string;
  latencyMs: number;
  /** NEVER returned: the API key. Always empty in the response. */
}

export async function testProvider(input: TestProviderInput): Promise<TestProviderOutput> {
  let config: ProviderRuntimeConfig;
  let providerId: string | null = null;

  if (input.providerId) {
    // Test existing provider — load from DB.
    const provider = await db.aiModerationProvider.findUnique({
      where: { id: input.providerId },
    });
    if (!provider) {
      return { healthy: false, reason: "Provider not found.", latencyMs: 0 };
    }
    let apiKey: string | null = null;
    if (provider.apiKeyEncrypted) {
      try {
        apiKey = decryptApiKey(provider.apiKeyEncrypted);
      } catch {
        return { healthy: false, reason: "Failed to decrypt API key (MODERATION_ENCRYPTION_KEY changed?).", latencyMs: 0 };
      }
    }
    config = {
      name: provider.name,
      model: provider.model,
      apiKey,
      endpoint: provider.endpoint,
      timeoutMs: 10000,
    };
    providerId = provider.id;
  } else if (input.draftConfig) {
    // Test draft config — admin entered it in the "Add Provider" form.
    const draft = input.draftConfig;
    // SSRF-check the endpoint before we make a request.
    if (draft.endpoint) {
      const ssrfCheck = await validateEndpointUrl(draft.endpoint, { isLocalProvider: draft.type === "local" });
      if (!ssrfCheck.ok) {
        return { healthy: false, reason: `Endpoint rejected: ${ssrfCheck.reason}`, latencyMs: 0 };
      }
    }
    config = {
      name: "(draft)",
      model: draft.model,
      apiKey: draft.apiKey ?? null,
      endpoint: draft.endpoint ?? null,
      timeoutMs: 10000,
    };
  } else {
    return { healthy: false, reason: "Either providerId or draftConfig is required.", latencyMs: 0 };
  }

  // Call the adapter.
  let providerType: ProviderType;
  if (input.providerId) {
    providerType = await getProviderType(providerId);
  } else if (input.draftConfig) {
    providerType = input.draftConfig.type;
  } else {
    return { healthy: false, reason: "Either providerId or draftConfig is required.", latencyMs: 0 };
  }
  const adapter = getAdapter(providerType);
  try {
    const result: HealthCheckResult = await adapter.healthCheck(config);

    // Update the provider's health columns (only for existing providers).
    if (providerId) {
      try {
        await db.aiModerationProvider.update({
          where: { id: providerId },
          data: {
            healthStatus: result.healthy ? "healthy" : "degraded",
            lastHealthCheck: new Date(),
            lastHealthError: result.healthy ? null : result.reason.slice(0, 500),
          },
        });
      } catch {
        // Non-fatal — the test result is what matters to the admin.
      }
    }

    return {
      healthy: result.healthy,
      reason: result.reason,
      latencyMs: result.latencyMs,
    };
  } catch (err) {
    const reason = err instanceof Error ? err.message : "Connection failed";
    if (providerId) {
      try {
        await db.aiModerationProvider.update({
          where: { id: providerId },
          data: {
            healthStatus: "offline",
            lastHealthCheck: new Date(),
            lastHealthError: reason.slice(0, 500),
          },
        });
      } catch {
        // ignore
      }
    }
    return { healthy: false, reason, latencyMs: 0 };
  }
}

/** Helper: fetch the provider type from the DB (only when providerId is given). */
async function getProviderType(providerId: string | null): Promise<ProviderType> {
  if (!providerId) {
    throw new ModerationProviderConfigError("Cannot determine provider type without providerId or draftConfig");
  }
  const provider = await db.aiModerationProvider.findUnique({
    where: { id: providerId },
    select: { type: true },
  });
  if (!provider) {
    throw new ModerationProviderConfigError("Provider not found");
  }
  return provider.type as ProviderType;
}
