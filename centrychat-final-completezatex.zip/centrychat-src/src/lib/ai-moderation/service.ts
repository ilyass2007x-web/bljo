/**
 * AI Moderation — Service
 * ======================
 *
 * SERVER-ONLY. The single entry point the application uses to moderate
 * content. Orchestrates:
 *
 *   1. Check the feature flag (`ai_moderation`) + policy.enabled.
 *   2. Load the active provider list (ordered by priority).
 *   3. Try the primary provider.
 *   4. On technical failure (timeout, 429, 5xx, network) → try fallback.
 *   5. On definitive answer (provider returned a result) → DON'T fallback
 *      just because the result was "blocked" (spec §8).
 *   6. If ALL providers fail → apply failureMode (FAIL_OPEN / FAIL_CLOSED).
 *   7. Apply the Policy Engine → final decision.
 *   8. Persist the result + review item + user violation.
 *
 * CRITICAL (spec §8): fallback is for TECHNICAL failures only. If the
 * primary provider said "blocked", that's a definitive answer — we don't
 * ask the fallback provider for a second opinion.
 *
 * CRITICAL (spec §21): AI failure must NOT cause content loss. When
 * failureMode=FAIL_OPEN, the content is published (allowed=true). When
 * failureMode=FAIL_CLOSED, the content is sent to review (allowed=true,
 * status=PENDING_MODERATION) — NOT deleted.
 *
 * The Service NEVER calls getUserMedia / RTCPeerConnection / camera / mic.
 * It only does server-side text/image/video-URL moderation.
 */

import { db } from "@/lib/database";
import { Prisma } from "@prisma/client";
import { logger } from "@/lib/logging";
import { isFeatureEnabled } from "@/lib/features";
import { decryptApiKey } from "./encryption";
import { getAdapter } from "./registry";
import { evaluatePolicy } from "./policy-engine";
import { loadPolicy, loadActiveProviders, getPolicyVersion } from "./settings";
import type {
  NormalizedModerationResult,
  ProviderRuntimeConfig,
  ModerationCategory,
  ModerationDecision,
  ContentAction,
  UserAction,
} from "./types";
import {
  ModerationProviderError,
  ModerationProviderConfigError,
} from "./types";
import type { ModerationPolicy } from "./schemas";
import type { ProviderType } from "./types";

// ── Public input/output ──────────────────────────────────────────────

export interface ModerateContentInput {
  /** Text to moderate (required for text moderation). */
  text?: string;
  /** Image URL to moderate (required for image moderation). */
  imageUrl?: string;
  /** Video URL to moderate (required for video moderation). */
  videoUrl?: string;
  /** Content type label (e.g. "post", "article", "image", "video"). */
  contentType: string;
  /** Content ID (null when the content hasn't been persisted yet — e.g. during pre-publish moderation). */
  contentId?: string | null;
  /** Author's user ID. */
  userId?: string | null;
}

export interface ModerateContentOutput {
  /** The normalized provider result. */
  result: NormalizedModerationResult | null;
  /** The policy-engine decision. */
  decision: ModerationDecision;
  /** The DB row ID of the persisted AiModerationResult (null when AI moderation was skipped or failed). */
  resultId: string | null;
  /** Whether AI moderation was actually run (false when feature disabled or no providers configured). */
  ran: boolean;
  /** Error message when ALL providers failed (null on success). */
  error: string | null;
}

// ── Constants ────────────────────────────────────────────────────────

/** Max chars of text to send to a provider. Larger inputs are truncated. */
const MAX_TEXT_LENGTH = 8000;

/** SHA-256 hash helper (for content deduplication). */
async function hashContent(text: string): Promise<string> {
  const { createHash } = await import("node:crypto");
  return createHash("sha256").update(text).digest("hex");
}

// ── Main entry point ─────────────────────────────────────────────────

/**
 * Moderate a piece of content. The single entry point for the application.
 *
 * Behavior:
 *   - When `ai_moderation` feature flag is OFF → returns { ran: false, decision: ALLOW }.
 *   - When the policy is disabled → returns { ran: false, decision: ALLOW }.
 *   - When no providers are configured → returns { ran: false, decision: ALLOW } (fail-open).
 *   - When the content type is not in the policy's contentTypes → returns { ran: false, decision: ALLOW }.
 *   - Otherwise → runs the pipeline, persists the result, returns the decision.
 */
export async function moderateContent(input: ModerateContentInput): Promise<ModerateContentOutput> {
  // 1. Feature flag check.
  const featureEnabled = await isFeatureEnabled("ai_moderation");
  if (!featureEnabled) {
    return skipResult("AI moderation feature is disabled.");
  }

  // 2. Policy check.
  const { policy, version: policyVersion } = await loadPolicy();
  if (!policy.enabled) {
    return skipResult("AI moderation policy is disabled.");
  }

  // 3. Content type check.
  if (!policy.contentTypes.includes(input.contentType as never)) {
    return skipResult(`Content type '${input.contentType}' is not subject to AI moderation.`);
  }

  // 4. Load providers.
  const providers = await loadActiveProviders();
  if (providers.length === 0) {
    return skipResult("No active AI moderation providers configured.");
  }

  // 5. Pick the right capability based on input.
  const capability = input.imageUrl ? "image" : input.videoUrl ? "video" : "text";

  // 6. Filter providers by capability + health.
  const eligible = providers.filter((p) => {
    if (capability === "text" && !p.supportsText) return false;
    if (capability === "image" && !p.supportsImage) return false;
    if (capability === "video" && !p.supportsVideo) return false;
    if (p.healthStatus === "offline") return false;
    return true;
  });

  if (eligible.length === 0) {
    // No provider can handle this content type — apply failureMode.
    return applyFailureMode(policy, policyVersion, input, "No eligible provider for this content type.");
  }

  // 7. Try providers in priority order. First definitive result wins.
  let lastError: unknown = null;
  let primaryName: string | null = null;
  for (let i = 0; i < eligible.length; i++) {
    const provider = eligible[i];
    primaryName = primaryName ?? provider.name;
    const isPrimary = i === 0;
    const config = await buildRuntimeConfig(provider, policy);

    try {
      const start = Date.now();
      const result = await callProvider(provider.type, capability, input, config);
      const processingTimeMs = Date.now() - start;

      // 8. Apply policy engine.
      const priorViolations = input.userId
        ? await countUserViolations(input.userId, extractTopCategory(result))
        : 0;
      const decision = evaluatePolicy(result, policy, priorViolations);
      decision.policyVersion = policyVersion;

      // 9. Update provider health (success → healthy, unless it was a response error).
      await updateProviderHealth(provider.id, true, null);

      // 10. Persist the result.
      const fallbackFrom = isPrimary ? null : primaryName;
      const resultId = await persistResult({
        result,
        decision,
        provider,
        input,
        policyVersion,
        fallbackFrom,
        processingTimeMs,
      });

      return { result, decision, resultId, ran: true, error: null };
    } catch (err) {
      lastError = err;
      // Technical failure → update provider health + try next provider.
      const errorMsg = err instanceof Error ? err.message : String(err);
      const retryable = err instanceof ModerationProviderError ? err.retryable : false;
      logger.warn("application", "AI moderation provider failed", {
        provider: provider.name,
        retryable,
        error: errorMsg,
      });
      await updateProviderHealth(provider.id, false, errorMsg);
      // Continue to next provider (fallback) — but ONLY on technical failures.
      // Response errors (invalid response) are NOT retryable — but we still
      // try the next provider because that's a different provider that might
      // return a valid response.
      continue;
    }
  }

  // 11. All providers failed → apply failureMode.
  return applyFailureMode(
    policy,
    policyVersion,
    input,
    lastError instanceof Error ? lastError.message : "All providers failed."
  );
}

// ── Helpers ──────────────────────────────────────────────────────────

function skipResult(reason: string): ModerateContentOutput {
  return {
    result: null,
    decision: {
      contentAction: "ALLOW",
      userAction: "NONE",
      restrictionDurationSec: null,
      triggeredCategory: null,
      threshold: 0,
      triggeredScore: 0,
      severity: "LOW",
      requiresReview: false,
      policyVersion: 0,
      userMessage: "",
    },
    resultId: null,
    ran: false,
    error: reason,
  };
}

function applyFailureMode(
  policy: ModerationPolicy,
  policyVersion: number,
  input: ModerateContentInput,
  error: string
): ModerateContentOutput {
  // FAIL_OPEN → ALLOW the content (but record that AI moderation failed).
  // FAIL_CLOSED → ALLOW the content + flag for review (NEVER delete on AI failure — spec §21).
  if (policy.failureMode === "FAIL_OPEN") {
    return {
      result: null,
      decision: {
        contentAction: "ALLOW",
        userAction: "NONE",
        restrictionDurationSec: null,
        triggeredCategory: null,
        threshold: 0,
        triggeredScore: 0,
        severity: "LOW",
        requiresReview: false,
        policyVersion,
        userMessage: "",
      },
      resultId: null,
      ran: false,
      error,
    };
  }
  // FAIL_CLOSED — flag for review without modifying the content.
  return {
    result: null,
    decision: {
      contentAction: "FLAG_FOR_REVIEW",
      userAction: "NONE",
      restrictionDurationSec: null,
      triggeredCategory: null,
      threshold: 0,
      triggeredScore: 0,
      severity: "LOW",
      requiresReview: true,
      policyVersion,
      userMessage: "Your content has been submitted for review. It will be visible to others once it has been approved by our moderation team.",
    },
    resultId: null,
    ran: false,
    error,
  };
}

async function buildRuntimeConfig(
  provider: { id: string; name: string; type: string; model: string; apiKeyEncrypted: string | null; endpoint: string | null },
  policy: ModerationPolicy
): Promise<ProviderRuntimeConfig> {
  let apiKey: string | null = null;
  if (provider.apiKeyEncrypted) {
    try {
      apiKey = decryptApiKey(provider.apiKeyEncrypted);
    } catch (err) {
      logger.error("application", "Failed to decrypt provider API key", {
        providerId: provider.id,
        providerName: provider.name,
        error: err instanceof Error ? err.message : String(err),
      });
      // The key is unusable — the adapter will throw a ConfigError on call.
    }
  }
  return {
    name: provider.name,
    model: provider.model,
    apiKey,
    endpoint: provider.endpoint,
    timeoutMs: policy.timeoutMs ?? 10000,
  };
}

async function callProvider(
  type: string,
  capability: "text" | "image" | "video",
  input: ModerateContentInput,
  config: ProviderRuntimeConfig
): Promise<NormalizedModerationResult> {
  const adapter = getAdapter(type as ProviderType);
  if (capability === "text") {
    if (!input.text) throw new ModerationProviderConfigError("Text moderation requires `text`");
    const truncated = input.text.slice(0, MAX_TEXT_LENGTH);
    return adapter.moderateText({ text: truncated, contentType: input.contentType }, config);
  }
  if (capability === "image") {
    if (!input.imageUrl) throw new ModerationProviderConfigError("Image moderation requires `imageUrl`");
    return adapter.moderateImage({ imageUrl: input.imageUrl }, config);
  }
  if (capability === "video") {
    if (!input.videoUrl) throw new ModerationProviderConfigError("Video moderation requires `videoUrl`");
    return adapter.moderateVideo({ videoUrl: input.videoUrl }, config);
  }
  throw new ModerationProviderConfigError(`Unknown capability: ${capability}`);
}

function extractTopCategory(result: NormalizedModerationResult): ModerationCategory | null {
  let top: { cat: ModerationCategory; score: number } | null = null;
  for (const cat of Object.keys(result.categories) as ModerationCategory[]) {
    const score = result.categories[cat];
    if (score === null) continue;
    if (!top || score > top.score) {
      top = { cat, score };
    }
  }
  return top?.cat ?? null;
}

async function countUserViolations(userId: string, category: ModerationCategory | null): Promise<number> {
  if (!category) return 0;
  try {
    return await db.aiModerationUserViolation.count({
      where: { userId, category },
    });
  } catch {
    return 0;
  }
}

async function updateProviderHealth(providerId: string, success: boolean, errorMsg: string | null): Promise<void> {
  try {
    const update: {
      totalRequests?: { increment: number };
      failedRequests?: { increment: number };
      healthStatus?: string;
      lastHealthCheck?: Date;
      lastHealthError?: string | null;
    } = {
      totalRequests: { increment: 1 },
      lastHealthCheck: new Date(),
    };
    if (!success) {
      update.failedRequests = { increment: 1 };
      update.lastHealthError = errorMsg?.slice(0, 500) ?? null;
      // Only flip to "degraded" if we have a meaningful failure count.
      // (A single failure shouldn't take the provider offline — could be a blip.)
      const provider = await db.aiModerationProvider.findUnique({
        where: { id: providerId },
        select: { failedRequests: true, totalRequests: true },
      });
      if (provider && provider.totalRequests > 0) {
        const failureRate = provider.failedRequests / provider.totalRequests;
        if (failureRate > 0.5) {
          update.healthStatus = "degraded";
        }
      }
    } else {
      update.lastHealthError = null;
      // Flip back to "healthy" if it was degraded.
      const provider = await db.aiModerationProvider.findUnique({
        where: { id: providerId },
        select: { healthStatus: true },
      });
      if (provider?.healthStatus === "degraded") {
        update.healthStatus = "healthy";
      }
    }
    await db.aiModerationProvider.update({ where: { id: providerId }, data: update });
  } catch (err) {
    // Non-fatal — the moderation decision was already made.
    logger.warn("application", "Failed to update provider health", {
      providerId,
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

async function persistResult(opts: {
  result: NormalizedModerationResult;
  decision: ModerationDecision;
  provider: { id: string; name: string; model: string };
  input: ModerateContentInput;
  policyVersion: number;
  fallbackFrom: string | null;
  processingTimeMs: number;
}): Promise<string | null> {
  try {
    const contentHash = opts.input.text
      ? await hashContent(opts.input.text.slice(0, 2000))
      : opts.input.imageUrl
        ? await hashContent(opts.input.imageUrl)
        : null;

    const created = await db.aiModerationResult.create({
      data: {
        providerId: opts.provider.id,
        providerName: opts.provider.name,
        modelName: opts.provider.model,
        contentType: opts.input.contentType,
        contentId: opts.input.contentId ?? null,
        contentHash,
        userId: opts.input.userId ?? null,
        // Prisma's Json type expects a JSON-serializable value. Cast via `unknown`
        // to satisfy TypeScript — the value IS a plain object (the type is
        // `Record<ModerationCategory, number | null>`).
        categoryScores: opts.result.categories as unknown as Prisma.InputJsonValue,
        score: opts.result.score,
        confidence: opts.result.confidence,
        reason: opts.result.reason,
        action: opts.decision.contentAction,
        policyVersion: opts.policyVersion,
        fallbackFrom: opts.fallbackFrom,
        processingTimeMs: opts.processingTimeMs,
      },
      select: { id: true },
    });

    // Create a review item when the decision requires review.
    if (opts.decision.requiresReview) {
      await db.aiModerationReviewItem.create({
        data: {
          resultId: created.id,
          status: "PENDING",
        },
      });
    }

    // Persist the user violation (for escalation tracking).
    if (opts.input.userId && opts.decision.triggeredCategory) {
      const appliedAction = opts.decision.userAction !== "NONE" ? opts.decision.userAction : null;
      const appliedContentAction = opts.decision.contentAction !== "ALLOW" ? opts.decision.contentAction : null;
      const restrictionEndsAt = opts.decision.restrictionDurationSec
        ? new Date(Date.now() + opts.decision.restrictionDurationSec * 1000)
        : null;

      await db.aiModerationUserViolation.create({
        data: {
          userId: opts.input.userId,
          resultId: created.id,
          contentType: opts.input.contentType,
          contentId: opts.input.contentId ?? null,
          category: opts.decision.triggeredCategory,
          severity: opts.decision.severity,
          score: opts.decision.triggeredScore,
          policyVersion: opts.policyVersion,
          appliedAction,
          appliedContentAction,
          restrictionEndsAt,
        },
      });
    }

    return created.id;
  } catch (err) {
    logger.error("application", "Failed to persist AI moderation result", {
      error: err instanceof Error ? err.message : String(err),
      provider: opts.provider.name,
    });
    return null;
  }
}

// ── Content + user action enforcement ────────────────────────────────

/**
 * Apply the content action to the underlying content row.
 * Called by the API route AFTER the content has been persisted (so contentId is known).
 *
 * Maps content actions → content row updates:
 *   ALLOW              → no-op
 *   FLAG_FOR_REVIEW    → moderationStatus = "PENDING_MODERATION" (existing column)
 *   HIDE_CONTENT       → moderationStatus = "PENDING_MODERATION" (hidden from public)
 *   BLOCK_CONTENT      → delete the content row (never published)
 *   DELETE_CONTENT     → delete the content row
 *
 * NOTE: BLOCK_CONTENT is treated identically to DELETE_CONTENT here — both
 * delete the row. The distinction matters for the policy engine (BLOCK is
 * more severe) but for content rows, the action is the same: delete.
 */
export async function applyContentAction(
  contentType: string,
  contentId: string,
  action: ContentAction
): Promise<boolean> {
  if (action === "ALLOW") return true;
  if (action === "FLAG_FOR_REVIEW" || action === "HIDE_CONTENT") {
    // Set moderationStatus = PENDING_MODERATION on the content row.
    try {
      switch (contentType) {
        case "post":
          await db.post.update({ where: { id: contentId }, data: { moderationStatus: "PENDING_MODERATION" } });
          return true;
        case "article":
          await db.article.update({ where: { id: contentId }, data: { moderationStatus: "PENDING_MODERATION" } });
          return true;
        case "post_comment":
          await db.postComment.update({ where: { id: contentId }, data: { moderationStatus: "PENDING_MODERATION" } });
          return true;
        case "article_comment":
          await db.articleComment.update({ where: { id: contentId }, data: { moderationStatus: "PENDING_MODERATION" } });
          return true;
        default:
          return false;
      }
    } catch (err) {
      logger.error("application", "applyContentAction: failed to set PENDING_MODERATION", {
        contentType, contentId, action,
        error: err instanceof Error ? err.message : String(err),
      });
      return false;
    }
  }
  // BLOCK_CONTENT + DELETE_CONTENT → delete the row.
  if (action === "BLOCK_CONTENT" || action === "DELETE_CONTENT") {
    try {
      switch (contentType) {
        case "post":
          await db.post.delete({ where: { id: contentId } }).catch(() => {});
          return true;
        case "article":
          await db.article.delete({ where: { id: contentId } }).catch(() => {});
          return true;
        case "post_comment":
          await db.postComment.delete({ where: { id: contentId } }).catch(() => {});
          return true;
        case "article_comment":
          await db.articleComment.delete({ where: { id: contentId } }).catch(() => {});
          return true;
        default:
          return false;
      }
    } catch (err) {
      logger.error("application", "applyContentAction: failed to delete content", {
        contentType, contentId, action,
        error: err instanceof Error ? err.message : String(err),
      });
      return false;
    }
  }
  return false;
}

/**
 * Apply the user action to the user row.
 * Maps user actions → User.status changes:
 *   NONE          → no-op
 *   WARN_USER     → no status change (caller creates a UserWarning via the existing flow)
 *   RESTRICT_USER → no status change (restriction tracked in AiModerationUserViolation)
 *   SUSPEND_USER  → status = "SUSPENDED"
 *   BAN_USER      → status = "BANNED"
 *
 * The caller should also destroy all user sessions when SUSPEND/BAN is applied
 * (via the existing destroyAllUserSessions helper in src/lib/auth/session.ts).
 */
export async function applyUserAction(
  userId: string,
  action: UserAction
): Promise<boolean> {
  if (action === "NONE" || action === "WARN_USER" || action === "RESTRICT_USER") {
    return true; // no User.status change
  }
  try {
    if (action === "SUSPEND_USER") {
      await db.user.update({ where: { id: userId }, data: { status: "SUSPENDED" } });
      return true;
    }
    if (action === "BAN_USER") {
      await db.user.update({ where: { id: userId }, data: { status: "BANNED" } });
      return true;
    }
  } catch (err) {
    logger.error("application", "applyUserAction failed", {
      userId, action,
      error: err instanceof Error ? err.message : String(err),
    });
    return false;
  }
  return false;
}
