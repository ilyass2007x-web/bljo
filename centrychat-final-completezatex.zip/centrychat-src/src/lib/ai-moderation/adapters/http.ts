/**
 * AI Moderation — HTTP fetch helper with timeout + retry
 * ======================================================
 *
 * SERVER-ONLY. Provides a single `fetchWithTimeout` + `fetchWithRetry`
 * helper used by all provider adapters. Centralized so we don't duplicate
 * timeout/backoff logic across adapters.
 *
 * SECURITY:
 *   - Never logs Authorization headers or request bodies (those contain
 *     the API key + the content being moderated).
 *   - Logs only: provider name, HTTP status, duration, error category.
 *   - N3 fix: routes EVERY fetch through the shared SSRF-safe agent
 *     (ssrfFetch from src/lib/security/ssrf-agent.ts). This closes the
 *     DNS-rebinding TOCTOU gap between validateEndpointUrl (write-time
 *     DNS check) and the actual fetch — undici now connects to the
 *     exact IP we validated at write time.
 */

import { logger } from "@/lib/logging";
import { ssrfFetch } from "@/lib/security/ssrf-agent";
import {
  ModerationProviderError,
  ModerationProviderRateLimitError,
  ModerationProviderServerError,
  ModerationProviderTimeoutError,
} from "../types";

/** Fetch with an AbortController-based timeout. Throws ModerationProviderTimeoutError on timeout. */
export async function fetchWithTimeout(
  url: string,
  init: RequestInit & { timeoutMs?: number } = {}
): Promise<Response> {
  const { timeoutMs = 10000, ...rest } = init;
  // N3 fix: use ssrfFetch instead of the global fetch. ssrfFetch:
  //   - Uses undici's own fetch (NOT the global fetch that silently ignores
  //     `dispatcher` on Bun + throws on Node 24).
  //   - Routes through ssrfSafeAgent (custom DNS lookup that rejects private
  //     IPs AT CONNECT TIME — closes the DNS-rebinding TOCTOU gap).
  //   - Applies the AbortController-based timeout.
  // The provider endpoint URL was already validated at WRITE TIME via
  // `validateEndpointUrl` (which checks DNS resolution + private IPs). This
  // fetch now ALSO validates at CONNECT TIME — defense-in-depth.
  try {
    const start = Date.now();
    const res = (await ssrfFetch(url, { ...rest, timeoutMs })) as unknown as Response;
    // Log the call (no body, no headers — just metadata).
    logger.debug("performance", "AI moderation HTTP call", {
      url: safeUrlForLog(url),
      status: res.status,
      durationMs: Date.now() - start,
    });
    return res;
  } catch (err) {
    if (err instanceof Error && err.name === "AbortError") {
      throw new ModerationProviderTimeoutError(
        `Request to ${safeUrlForLog(url)} timed out after ${timeoutMs}ms`
      );
    }
    // Network error — retryable.
    throw new ModerationProviderError(
      `Network error calling ${safeUrlForLog(url)}: ${err instanceof Error ? err.message : String(err)}`,
      { retryable: true, cause: err instanceof Error ? err : undefined }
    );
  }
}

/**
 * Retry wrapper. Retries ONLY on:
 *   - ModerationProviderTimeoutError
 *   - ModerationProviderRateLimitError (429)
 *   - ModerationProviderServerError (5xx)
 *   - Network errors (retryable=true)
 *
 * Uses exponential backoff: 500ms, 1000ms, 2000ms, ... (capped at 5000ms).
 *
 * Does NOT retry on:
 *   - 4xx (except 429) — the request is malformed, retrying won't help.
 *   - Response parsing errors — the response is invalid, retrying won't help.
 *   - Config errors — the provider config is wrong, retrying won't help.
 */
export async function fetchWithRetry<T>(
  fn: () => Promise<T>,
  opts: { maxRetries?: number; baseDelayMs?: number; maxDelayMs?: number } = {}
): Promise<T> {
  const maxRetries = opts.maxRetries ?? 2;
  const baseDelayMs = opts.baseDelayMs ?? 500;
  const maxDelayMs = opts.maxDelayMs ?? 5000;
  let lastError: unknown;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      // Determine retryability.
      const retryable =
        err instanceof ModerationProviderError ? err.retryable : false;
      if (!retryable || attempt === maxRetries) {
        throw err;
      }
      // Exponential backoff with jitter (jitter prevents thundering herd).
      const baseDelay = Math.min(maxDelayMs, baseDelayMs * Math.pow(2, attempt));
      const jitter = Math.random() * baseDelay * 0.3;
      const delay = baseDelay + jitter;
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  throw lastError;
}

/**
 * Convert a provider HTTP error response into the right error class.
 *
 * - 429 → ModerationProviderRateLimitError (retryable)
 * - 5xx → ModerationProviderServerError (retryable)
 * - other 4xx → ModerationProviderError (NOT retryable — request is wrong)
 */
export async function throwForStatus(
  res: Response,
  providerName: string
): Promise<void> {
  if (res.ok) return;
  let bodyText = "";
  try {
    bodyText = await res.text();
    // Truncate — never log a multi-KB error page.
    if (bodyText.length > 500) bodyText = bodyText.slice(0, 500) + "…";
  } catch {
    // ignore — body may have been consumed
  }
  const msg = `${providerName} returned HTTP ${res.status}: ${bodyText || "(no body)"}`;
  if (res.status === 429) {
    throw new ModerationProviderRateLimitError(msg);
  }
  if (res.status >= 500) {
    throw new ModerationProviderServerError(msg, res.status);
  }
  // 4xx (except 429) — NOT retryable. The request is malformed or unauthorized.
  throw new ModerationProviderError(msg, { retryable: false, statusCode: res.status });
}

/**
 * Strip the query string from a URL before logging. Some providers (Custom)
 * might encode the API key in the query (we discourage this, but defensive).
 * NEVER log the query string verbatim — only the origin + path.
 */
function safeUrlForLog(url: string): string {
  try {
    const parsed = new URL(url);
    return `${parsed.protocol}//${parsed.hostname}${parsed.pathname}`;
  } catch {
    return "(invalid url)";
  }
}
