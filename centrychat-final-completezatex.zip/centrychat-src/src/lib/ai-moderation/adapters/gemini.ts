/**
 * AI Moderation — Google Gemini Adapter
 * =====================================
 *
 * Implements the `ModerationProvider` interface for Google Gemini's
 * Generative Language API. Uses the safety_settings + harm_categories
 * fields in the response to derive normalized scores.
 *
 * API: POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={apiKey}
 *
 * SECURITY:
 *   - The API key is decrypted by the Registry, passed in `config.apiKey`.
 *   - Gemini accepts the key as a query string param OR as an
 *     x-goog-api-key header. We use the HEADER form (more secure — query
 *     params can leak through proxies/access logs).
 *   - We never log the URL with the key in it (the fetch helper strips query).
 */
import type {
  ModerationProvider,
  NormalizedModerationResult,
  ProviderRuntimeConfig,
  TextModerationInput,
  ImageModerationInput,
  VideoModerationInput,
  HealthCheckResult,
} from "../types";
import {
  ModerationProviderConfigError,
  ModerationProviderResponseError,
} from "../types";
import { fetchWithRetry, fetchWithTimeout, throwForStatus } from "./http";

// Gemini harm category → our normalized name.
const GEMINI_CATEGORY_MAP: Record<string, keyof NormalizedModerationResult["categories"] | null> = {
  "HARM_CATEGORY_HARASSMENT": "harassment",
  "HARM_CATEGORY_HATE_SPEECH": "hate",
  "HARM_CATEGORY_SEXUALLY_EXPLICIT": "sexual",
  "HARM_CATEGORY_DANGEROUS_CONTENT": "violence",
  "HARM_CATEGORY_CIVIC_INTEGRITY": "illegal",
};

/**
 * Gemini probability → numeric score. Gemini returns probability as one
 * of: NEGLIGIBLE | LOW | MEDIUM | HIGH. We map these to 0.05 / 0.30 /
 * 0.60 / 0.90. This is a conservative mapping — better to under-score
 * than over-score (false positives are worse than false negatives for
 * user-facing content moderation).
 */
const GEMINI_PROBABILITY_SCORE: Record<string, number> = {
  "NEGLIGIBLE": 0.05,
  "LOW": 0.30,
  "MEDIUM": 0.60,
  "HIGH": 0.90,
};

function emptyCategoryScores(): NormalizedModerationResult["categories"] {
  return {
    sexual: null, explicit: null, nudity: null, suggestive: null,
    violence: null, graphicViolence: null, hate: null, harassment: null,
    bullying: null, selfHarm: null, spam: null, scam: null, illegal: null,
  };
}

export class GeminiModerationProvider implements ModerationProvider {
  readonly type = "gemini" as const;
  readonly name = "Google Gemini";
  readonly capabilities = { text: true, image: true, video: false };

  async moderateText(input: TextModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    if (!config.apiKey) {
      throw new ModerationProviderConfigError("Gemini provider requires an API key");
    }
    const baseEndpoint = (config.endpoint || "https://generativelanguage.googleapis.com/v1beta").replace(/\/$/, "");
    const model = config.model || "gemini-1.5-flash";
    const endpoint = `${baseEndpoint}/models/${encodeURIComponent(model)}:generateContent`;

    const res = await fetchWithRetry(async () => {
      const r = await fetchWithTimeout(endpoint, {
        method: "POST",
        timeoutMs: config.timeoutMs,
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": config.apiKey!, // Never logged by the fetch helper
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: input.text }] }],
          // Request ALL harm categories — Gemini returns scores for each.
          safetySettings: [
            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
          ],
        }),
      });
      await throwForStatus(r, "Gemini");
      return r;
    });

    const json = await res.json().catch(() => null) as {
      candidates?: Array<{
        safetyRatings?: Array<{
          category?: string;
          probability?: string;
          probabilityScore?: number;
          blocked?: boolean;
        }>;
        finishReason?: string;
      }>;
      promptFeedback?: { blockReason?: string };
    } | null;

    if (!json) {
      throw new ModerationProviderResponseError("Gemini returned an invalid response");
    }

    // If Gemini blocked the prompt entirely, treat as a high-confidence violation.
    if (json.promptFeedback?.blockReason) {
      const cats = emptyCategoryScores();
      cats.sexual = 0.95; // Conservative — we don't know which category triggered the block.
      return {
        allowed: false,
        categories: cats,
        score: 0.95,
        confidence: 0.95,
        reason: `Gemini blocked prompt: ${json.promptFeedback.blockReason}`,
        provider: config.name,
        model: config.model,
        flags: ["gemini_prompt_blocked"],
      };
    }

    const ratings = json.candidates?.[0]?.safetyRatings ?? [];
    const categories = emptyCategoryScores();
    let maxScore = 0;
    let blocked = false;
    const triggered: string[] = [];

    for (const rating of ratings) {
      const mapped = rating.category ? GEMINI_CATEGORY_MAP[rating.category] : null;
      if (!mapped) continue;
      // Prefer the numeric probabilityScore when available; otherwise
      // fall back to the discrete probability bucket.
      let score: number;
      if (typeof rating.probabilityScore === "number") {
        score = Math.max(0, Math.min(1, rating.probabilityScore));
      } else if (rating.probability && rating.probability in GEMINI_PROBABILITY_SCORE) {
        score = GEMINI_PROBABILITY_SCORE[rating.probability];
      } else {
        continue;
      }
      if (categories[mapped] === null || score > (categories[mapped] ?? 0)) {
        categories[mapped] = score;
      }
      if (score > maxScore) maxScore = score;
      if (rating.blocked) {
        blocked = true;
        triggered.push(rating.category ?? "unknown");
      }
    }

    return {
      allowed: !blocked && maxScore < 0.5,
      categories,
      score: maxScore,
      confidence: null,
      reason: blocked
        ? `Gemini blocked: ${triggered.join(", ")}`
        : `Gemini: max probability ${maxScore.toFixed(2)}`,
      provider: config.name,
      model: config.model,
      flags: [],
    };
  }

  async moderateImage(input: ImageModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    if (!config.apiKey) {
      throw new ModerationProviderConfigError("Gemini provider requires an API key");
    }
    const baseEndpoint = (config.endpoint || "https://generativelanguage.googleapis.com/v1beta").replace(/\/$/, "");
    const model = config.model || "gemini-1.5-flash";
    const endpoint = `${baseEndpoint}/models/${encodeURIComponent(model)}:generateContent`;

    // Gemini can take inline_data (base64) or a file_url. For URLs, we use file_url.
    // NOTE: Gemini only fetches Google Cloud Storage (gs://) URLs by default — for
    // public https URLs, the caller should base64-encode the image. To keep this
    // adapter simple + server-side, we send the URL as file_data and let Gemini
    // fetch it. If Gemini doesn't support the URL, the response will indicate that.
    const res = await fetchWithRetry(async () => {
      const r = await fetchWithTimeout(endpoint, {
        method: "POST",
        timeoutMs: config.timeoutMs,
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": config.apiKey!,
        },
        body: JSON.stringify({
          contents: [{
            parts: [
              { text: "Analyze this image for policy violations." },
              { fileData: { mimeType: "image/jpeg", fileUri: input.imageUrl } },
            ],
          }],
          safetySettings: [
            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
          ],
        }),
      });
      await throwForStatus(r, "Gemini");
      return r;
    });

    const json = await res.json().catch(() => null) as {
      candidates?: Array<{ safetyRatings?: Array<{ category?: string; probability?: string; probabilityScore?: number }> }>;
      promptFeedback?: { blockReason?: string };
    } | null;

    if (!json) {
      throw new ModerationProviderResponseError("Gemini returned an invalid response for image");
    }

    const cats = emptyCategoryScores();
    let maxScore = 0;
    for (const r of json.candidates?.[0]?.safetyRatings ?? []) {
      const mapped = r.category ? GEMINI_CATEGORY_MAP[r.category] : null;
      if (!mapped) continue;
      const score = typeof r.probabilityScore === "number"
        ? Math.max(0, Math.min(1, r.probabilityScore))
        : r.probability ? (GEMINI_PROBABILITY_SCORE[r.probability] ?? 0) : 0;
      if (cats[mapped] === null || score > (cats[mapped] ?? 0)) cats[mapped] = score;
      if (score > maxScore) maxScore = score;
    }
    return {
      allowed: !json.promptFeedback?.blockReason && maxScore < 0.5,
      categories: cats,
      score: maxScore,
      confidence: null,
      reason: json.promptFeedback?.blockReason
        ? `Gemini blocked image: ${json.promptFeedback.blockReason}`
        : `Gemini image: max ${maxScore.toFixed(2)}`,
      provider: config.name,
      model: config.model,
      flags: [],
    };
  }

  async moderateVideo(_input: VideoModerationInput, _config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    throw new ModerationProviderConfigError("Gemini provider does not support direct video moderation — use frame extraction");
  }

  async healthCheck(config: ProviderRuntimeConfig): Promise<HealthCheckResult> {
    if (!config.apiKey) {
      return { healthy: false, reason: "Missing API key", latencyMs: 0 };
    }
    const start = Date.now();
    try {
      const baseEndpoint = (config.endpoint || "https://generativelanguage.googleapis.com/v1beta").replace(/\/$/, "");
      const model = config.model || "gemini-1.5-flash";
      // List models — cheap + verifies the API key.
      const r = await fetchWithTimeout(
        `${baseEndpoint}/models/${encodeURIComponent(model)}?key=`,
        {
          method: "GET",
          timeoutMs: 5000,
          headers: { "x-goog-api-key": config.apiKey },
        }
      );
      if (r.status === 401 || r.status === 403) {
        return { healthy: false, reason: "Invalid API key (HTTP 401/403)", latencyMs: Date.now() - start };
      }
      if (!r.ok) {
        return { healthy: false, reason: `HTTP ${r.status}`, latencyMs: Date.now() - start };
      }
      return { healthy: true, reason: "Connection successful", latencyMs: Date.now() - start };
    } catch (err) {
      return {
        healthy: false,
        reason: err instanceof Error ? err.message : "Connection failed",
        latencyMs: Date.now() - start,
      };
    }
  }
}
