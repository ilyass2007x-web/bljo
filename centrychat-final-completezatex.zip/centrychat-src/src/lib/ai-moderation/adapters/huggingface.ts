/**
 * AI Moderation — Hugging Face Adapter
 * =====================================
 *
 * Implements the `ModerationProvider` interface for Hugging Face's
 * Inference API. HF serves community models — typically each model
 * is dedicated to ONE category (e.g. facebook/roberta-hate-speech-dynabench
 * detects hate speech). The admin configures which model + which
 * category the output maps to.
 *
 * Since HF models are single-purpose, this adapter ONLY populates the
 * category the admin declares via the model name. We embed the category
 * hint in the model identifier using a special syntax:
 *   "facebook/roberta-hate-speech-dynabench-r4-target|hate"
 *
 * The part after the `|` is the target category. When omitted, we
 * default to "hate" for any model name containing "hate", "harass" →
 * "harassment", etc. — best-effort.
 *
 * SECURITY:
 *   - API key is decrypted by the Registry, passed in `config.apiKey`.
 *   - Sent as `Authorization: Bearer <token>` — never logged.
 */
import type {
  ModerationProvider,
  NormalizedModerationResult,
  ProviderRuntimeConfig,
  TextModerationInput,
  ImageModerationInput,
  VideoModerationInput,
  HealthCheckResult,
  ModerationCategory,
} from "../types";
import {
  ModerationProviderConfigError,
  ModerationProviderResponseError,
} from "../types";
import { fetchWithRetry, fetchWithTimeout, throwForStatus } from "./http";

function emptyCategoryScores(): NormalizedModerationResult["categories"] {
  return {
    sexual: null, explicit: null, nudity: null, suggestive: null,
    violence: null, graphicViolence: null, hate: null, harassment: null,
    bullying: null, selfHarm: null, spam: null, scam: null, illegal: null,
  };
}

/** Extract the target category from the model identifier (e.g. "model|hate"). */
function extractTargetCategory(model: string): ModerationCategory | null {
  const parts = model.split("|");
  if (parts.length >= 2) {
    const candidate = parts[1].trim();
    const valid: ModerationCategory[] = [
      "sexual", "explicit", "nudity", "suggestive",
      "violence", "graphicViolence", "hate", "harassment",
      "bullying", "selfHarm", "spam", "scam", "illegal",
    ];
    if (valid.includes(candidate as ModerationCategory)) {
      return candidate as ModerationCategory;
    }
  }
  // Best-effort inference from the model name.
  const lower = model.toLowerCase();
  if (lower.includes("hate")) return "hate";
  if (lower.includes("harass") || lower.includes("toxic")) return "harassment";
  if (lower.includes("spam")) return "spam";
  if (lower.includes("viol")) return "violence";
  if (lower.includes("sex")) return "sexual";
  return null;
}

export class HuggingFaceModerationProvider implements ModerationProvider {
  readonly type = "huggingface" as const;
  readonly name = "Hugging Face";
  readonly capabilities = { text: true, image: false, video: false };

  async moderateText(input: TextModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    if (!config.apiKey) {
      throw new ModerationProviderConfigError("Hugging Face provider requires an API key");
    }
    const baseEndpoint = (config.endpoint || "https://api-inference.huggingface.co/models").replace(/\/$/, "");
    // Strip the `|category` suffix — HF doesn't know about it.
    const modelId = config.model.split("|")[0].trim();
    if (!modelId) {
      throw new ModerationProviderConfigError("Hugging Face provider requires a model identifier");
    }
    const endpoint = `${baseEndpoint}/${modelId}`;

    const res = await fetchWithRetry(async () => {
      const r = await fetchWithTimeout(endpoint, {
        method: "POST",
        timeoutMs: config.timeoutMs,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify({ inputs: input.text }),
      });
      await throwForStatus(r, "Hugging Face");
      return r;
    });

    const json = await res.json().catch(() => null) as unknown;
    if (!json) {
      throw new ModerationProviderResponseError("Hugging Face returned an invalid response");
    }

    // HF returns either [[{label:"hate",score:0.99},...]] (classification
    // with return_all_scores) OR [{label, score}] (single result) OR
    // {error: "..."}. Normalize all of these.
    let scores: Array<{ label: string; score: number }> = [];
    if (Array.isArray(json)) {
      const first = json[0];
      if (Array.isArray(first)) {
        scores = first as Array<{ label: string; score: number }>;
      } else if (first && typeof first === "object" && "label" in first) {
        scores = json as Array<{ label: string; score: number }>;
      }
    }

    const targetCategory = extractTargetCategory(config.model);
    const categories = emptyCategoryScores();
    let maxScore = 0;
    let allowed = true;
    const flags: string[] = [];
    let reason = "Hugging Face: no scores returned";

    if (targetCategory && scores.length > 0) {
      // Find the score for the target label (e.g. "hate" or "toxic").
      // Take the highest "positive" label score.
      const positiveScores = scores
        .filter((s) => /hate|toxic|spam|viol|sex|harass|nsfw|inappropriate/i.test(s.label))
        .map((s) => Math.max(0, Math.min(1, s.score ?? 0)));
      if (positiveScores.length > 0) {
        const score = Math.max(...positiveScores);
        categories[targetCategory] = score;
        maxScore = score;
        allowed = score < 0.5;
        reason = `Hugging Face: ${targetCategory}=${score.toFixed(2)} (label: ${scores[0]?.label})`;
      }
    }

    // Prompt-injection heuristic.
    if (/ignore (all )?previous instructions/i.test(input.text)) {
      flags.push("prompt_injection_suspected");
    }

    return {
      allowed,
      categories,
      score: maxScore,
      confidence: null,
      reason,
      provider: config.name,
      model: config.model,
      flags,
    };
  }

  async moderateImage(_input: ImageModerationInput, _config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    throw new ModerationProviderConfigError("Hugging Face adapter does not support image moderation in this build");
  }

  async moderateVideo(_input: VideoModerationInput, _config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    throw new ModerationProviderConfigError("Hugging Face adapter does not support video moderation");
  }

  async healthCheck(config: ProviderRuntimeConfig): Promise<HealthCheckResult> {
    if (!config.apiKey) {
      return { healthy: false, reason: "Missing API key", latencyMs: 0 };
    }
    const start = Date.now();
    try {
      const baseEndpoint = (config.endpoint || "https://api-inference.huggingface.co/models").replace(/\/$/, "");
      // Hit the /whoami-v2 endpoint — cheap + verifies the token.
      const r = await fetchWithTimeout(`${baseEndpoint.replace(/\/models$/, "")}/whoami-v2`, {
        method: "GET",
        timeoutMs: 5000,
        headers: { Authorization: `Bearer ${config.apiKey}` },
      });
      if (r.status === 401) {
        return { healthy: false, reason: "Invalid API key (HTTP 401)", latencyMs: Date.now() - start };
      }
      if (!r.ok) {
        return { healthy: false, reason: `HTTP ${r.status}`, latencyMs: Date.now() - start };
      }
      return { healthy: true, reason: "Connection successful", latencyMs: Date.now() - start };
    } catch (err) {
      return {
        healthy: false,
        reason: err instanceof Error ? err.message : "Connection failed",
        latencyMs: Date.now() - start,
      };
    }
  }
}
