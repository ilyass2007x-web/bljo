/**
 * AI Moderation — Custom HTTP Adapter
 * ===================================
 *
 * Implements the `ModerationProvider` interface for ANY HTTP endpoint
 * that follows our request/response schema. Useful for:
 *   - Self-hosted OpenAI-compatible moderation gateways
 *   - Internal moderation microservices
 *   - Custom AI providers with a thin wrapper
 *
 * REQUEST (POST to the configured endpoint):
 *   {
 *     "text"?: string,
 *     "imageUrl"?: string,
 *     "videoUrl"?: string,
 *     "contentType": string,
 *     "model": string
 *   }
 *
 * RESPONSE (any 2xx):
 *   {
 *     "allowed": boolean,
 *     "categories": {
 *       "sexual"?: 0..1 | null,
 *       "explicit"?: 0..1 | null,
 *       ...
 *     },
 *     "score"?: 0..1,
 *     "confidence"?: 0..1,
 *     "reason"?: string,
 *     "flags"?: string[]
 *   }
 *
 * SECURITY:
 *   - SSRF protection: the endpoint is validated by the API route BEFORE
 *     this adapter sees it (see src/lib/ai-moderation/ssrf.ts). We don't
 *     re-validate here (the admin saved it once + it can't be tampered with
 *     from outside the admin panel).
 *   - API key (optional) is sent as `Authorization: Bearer <key>` — never
 *     in the URL or body. The fetch helper strips query params from logs.
 *   - The response is treated as untrusted — every field is validated +
 *     clamped to its expected range before being normalized.
 */
import type {
  ModerationProvider,
  NormalizedModerationResult,
  ProviderRuntimeConfig,
  TextModerationInput,
  ImageModerationInput,
  VideoModerationInput,
  HealthCheckResult,
  ModerationCategory,
} from "../types";
import {
  ModerationProviderConfigError,
  ModerationProviderResponseError,
} from "../types";
import { fetchWithRetry, fetchWithTimeout, throwForStatus } from "./http";

const VALID_CATEGORIES: ModerationCategory[] = [
  "sexual", "explicit", "nudity", "suggestive",
  "violence", "graphicViolence", "hate", "harassment",
  "bullying", "selfHarm", "spam", "scam", "illegal",
];

function emptyCategoryScores(): NormalizedModerationResult["categories"] {
  return {
    sexual: null, explicit: null, nudity: null, suggestive: null,
    violence: null, graphicViolence: null, hate: null, harassment: null,
    bullying: null, selfHarm: null, spam: null, scam: null, illegal: null,
  };
}

function normalizeResponse(
  json: unknown,
  config: ProviderRuntimeConfig
): NormalizedModerationResult {
  if (!json || typeof json !== "object") {
    throw new ModerationProviderResponseError("Custom provider returned a non-object response");
  }
  const obj = json as Record<string, unknown>;
  const categories = emptyCategoryScores();
  let maxScore = 0;

  // Parse the `categories` object — accept any subset of valid category names.
  if (obj.categories && typeof obj.categories === "object") {
    const cats = obj.categories as Record<string, unknown>;
    for (const cat of VALID_CATEGORIES) {
      const v = cats[cat];
      if (typeof v === "number" && !isNaN(v)) {
        categories[cat] = Math.max(0, Math.min(1, v));
        if (categories[cat]! > maxScore) maxScore = categories[cat]!;
      } else if (v === null) {
        // null is valid — means "provider didn't score this".
        categories[cat] = null;
      }
      // ignore non-number, non-null values (defensive).
    }
  }

  // Parse the composite score — optional.
  let score = maxScore;
  if (typeof obj.score === "number" && !isNaN(obj.score)) {
    score = Math.max(0, Math.min(1, obj.score));
  }

  // Parse confidence — optional.
  let confidence: number | null = null;
  if (typeof obj.confidence === "number" && !isNaN(obj.confidence)) {
    confidence = Math.max(0, Math.min(1, obj.confidence));
  }

  // Parse flags — optional array of strings.
  const flags: string[] = [];
  if (Array.isArray(obj.flags)) {
    for (const f of obj.flags) {
      if (typeof f === "string" && f.length <= 80) flags.push(f);
    }
  }

  // Parse reason — optional string.
  const reason = typeof obj.reason === "string" ? obj.reason.slice(0, 500) : "Custom: no reason";

  // Parse allowed — fall back to "score < 0.5" when missing.
  const allowed = typeof obj.allowed === "boolean" ? obj.allowed : (score < 0.5);

  return {
    allowed,
    categories,
    score,
    confidence,
    reason,
    provider: config.name,
    model: config.model,
    flags,
  };
}

export class CustomModerationProvider implements ModerationProvider {
  readonly type = "custom" as const;
  readonly name = "Custom API";
  readonly capabilities = { text: true, image: true, video: true };

  private async callEndpoint(
    body: Record<string, unknown>,
    config: ProviderRuntimeConfig
  ): Promise<NormalizedModerationResult> {
    if (!config.endpoint) {
      throw new ModerationProviderConfigError("Custom provider requires an endpoint");
    }
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    if (config.apiKey) {
      headers.Authorization = `Bearer ${config.apiKey}`;
    }

    const res = await fetchWithRetry(async () => {
      const r = await fetchWithTimeout(config.endpoint!, {
        method: "POST",
        timeoutMs: config.timeoutMs,
        headers,
        body: JSON.stringify({ ...body, model: config.model }),
      });
      await throwForStatus(r, "Custom provider");
      return r;
    });

    const json = await res.json().catch(() => null);
    if (json === null) {
      throw new ModerationProviderResponseError("Custom provider returned a non-JSON response");
    }
    return normalizeResponse(json, config);
  }

  async moderateText(input: TextModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    return this.callEndpoint({
      text: input.text,
      contentType: input.contentType,
    }, config);
  }

  async moderateImage(input: ImageModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    return this.callEndpoint({
      imageUrl: input.imageUrl,
      contentType: "image",
    }, config);
  }

  async moderateVideo(input: VideoModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    return this.callEndpoint({
      videoUrl: input.videoUrl,
      contentType: "video",
    }, config);
  }

  async healthCheck(config: ProviderRuntimeConfig): Promise<HealthCheckResult> {
    if (!config.endpoint) {
      return { healthy: false, reason: "Missing endpoint", latencyMs: 0 };
    }
    const start = Date.now();
    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (config.apiKey) headers.Authorization = `Bearer ${config.apiKey}`;
      // Send a trivial text — a healthy provider returns a valid response
      // (allowed=true + empty categories is fine).
      const r = await fetchWithTimeout(config.endpoint, {
        method: "POST",
        timeoutMs: 5000,
        headers,
        body: JSON.stringify({ text: "healthcheck", contentType: "healthcheck", model: config.model }),
      });
      if (!r.ok) {
        return { healthy: false, reason: `HTTP ${r.status}`, latencyMs: Date.now() - start };
      }
      // Validate the response is parseable.
      const json = await r.json().catch(() => null);
      if (!json || typeof json !== "object") {
        return { healthy: false, reason: "Response is not valid JSON", latencyMs: Date.now() - start };
      }
      return { healthy: true, reason: "Connection successful", latencyMs: Date.now() - start };
    } catch (err) {
      return {
        healthy: false,
        reason: err instanceof Error ? err.message : "Connection failed",
        latencyMs: Date.now() - start,
      };
    }
  }
}

/**
 * Local adapter — for self-hosted models (e.g. Llama Guard via Ollama).
 *
 * Functionally identical to the Custom adapter but:
 *   - Allows localhost / 127.0.0.1 / [::1] endpoints (SSRF protection
 *     is relaxed for the "local" provider type — see ssrf.ts).
 *   - API key is optional (most local models don't require auth).
 *   - Video is NOT supported (most local models are text-only).
 *
 * NOTE: We don't subclass Custom because the `readonly type` + `readonly name`
 * fields can't be overridden in TypeScript. We delegate to a private Custom
 * instance instead — keeps the call/normalize logic DRY without inheritance.
 */
export class LocalModerationProvider implements ModerationProvider {
  readonly type = "local" as const;
  readonly name = "Local / Self-hosted";
  readonly capabilities = { text: true, image: false, video: false };

  // Delegate to a private Custom instance for the actual call/normalize logic.
  private delegate = new CustomModerationProvider();

  async moderateText(input: TextModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    return this.delegate.moderateText(input, config);
  }

  async moderateImage(input: ImageModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    return this.delegate.moderateImage(input, config);
  }

  async moderateVideo(input: VideoModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    return this.delegate.moderateVideo(input, config);
  }

  async healthCheck(config: ProviderRuntimeConfig): Promise<HealthCheckResult> {
    return this.delegate.healthCheck(config);
  }
}
