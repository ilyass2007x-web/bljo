/**
 * AI Moderation — OpenAI Adapter
 * ==============================
 *
 * Implements the `ModerationProvider` interface for OpenAI's Moderation API.
 *
 * API: POST https://api.openai.com/v1/moderations
 *   Body: { model: "omni-moderation-latest", input: "..." | [{type:"image_url",image_url:{url:"..."}}] }
 *   Headers: Authorization: Bearer <api_key>
 *
 * Response:
 *   { results: [{ flagged: boolean, categories: {...}, category_scores: {...} }] }
 *
 * Normalization (spec §5):
 *   OpenAI's category names map to our normalized names. Some OpenAI categories
 *   (like "violence" + "violence/graphic") map cleanly; others (like "illicit"
 *   + "illicit/violent") get grouped into our "illegal" bucket.
 *
 * SECURITY:
 *   - The API key is decrypted by the Registry, passed in `config.apiKey`.
 *   - NEVER logged. The fetch helper logs only the URL origin + path.
 *   - We only send the text to be moderated — no metadata, no user IDs.
 */
import type {
  ModerationProvider,
  NormalizedModerationResult,
  ProviderRuntimeConfig,
  TextModerationInput,
  ImageModerationInput,
  VideoModerationInput,
  HealthCheckResult,
} from "../types";
import {
  ModerationProviderConfigError,
  ModerationProviderResponseError,
} from "../types";
import { fetchWithRetry, fetchWithTimeout, throwForStatus } from "./http";

// OpenAI category name → our normalized name. NULL means "we don't map this".
const OPENAI_CATEGORY_MAP: Record<string, keyof NormalizedModerationResult["categories"] | null> = {
  // Sexual
  "sexual": "sexual",
  "sexual/minors": "explicit",
  "harassment": "harassment",
  "harassment/threatening": "bullying",
  "hate": "hate",
  "hate/threatening": "hate",
  "illicit": "illegal",
  "illicit/violent": "illegal",
  "self-harm": "selfHarm",
  "self-harm/intent": "selfHarm",
  "self-harm/instructions": "selfHarm",
  "violence": "violence",
  "violence/graphic": "graphicViolence",
};

function emptyCategoryScores(): NormalizedModerationResult["categories"] {
  return {
    sexual: null, explicit: null, nudity: null, suggestive: null,
    violence: null, graphicViolence: null, hate: null, harassment: null,
    bullying: null, selfHarm: null, spam: null, scam: null, illegal: null,
  };
}

export class OpenAIModerationProvider implements ModerationProvider {
  readonly type = "openai" as const;
  readonly name = "OpenAI";
  readonly capabilities = { text: true, image: true, video: false };

  async moderateText(input: TextModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    if (!config.apiKey) {
      throw new ModerationProviderConfigError("OpenAI provider requires an API key");
    }
    const endpoint = config.endpoint || "https://api.openai.com/v1/moderations";

    const res = await fetchWithRetry(async () => {
      const r = await fetchWithTimeout(endpoint, {
        method: "POST",
        timeoutMs: config.timeoutMs,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify({
          model: config.model || "omni-moderation-latest",
          input: input.text,
        }),
      });
      await throwForStatus(r, "OpenAI");
      return r;
    });

    const json = await res.json().catch(() => null) as {
      results?: Array<{
        flagged?: boolean;
        categories?: Record<string, boolean>;
        category_scores?: Record<string, number>;
        category_applied_input_types?: Record<string, string[]>;
      }>;
    } | null;

    if (!json || !Array.isArray(json.results) || !json.results[0]) {
      throw new ModerationProviderResponseError("OpenAI returned an invalid response (missing results)");
    }

    const r0 = json.results[0];
    const categories = emptyCategoryScores();
    let maxScore = 0;
    const flags: string[] = [];

    if (r0.category_scores) {
      for (const [openaiName, score] of Object.entries(r0.category_scores)) {
        const mapped = OPENAI_CATEGORY_MAP[openaiName];
        if (!mapped || typeof score !== "number") continue;
        // OpenAI scores are 0..1 (probability).
        const clamped = Math.max(0, Math.min(1, score));
        // Only overwrite when the slot is empty OR the new score is higher.
        // (Multiple OpenAI categories map to the same normalized category —
        // e.g. "hate" + "hate/threatening" both map to "hate".)
        if (categories[mapped] === null || clamped > (categories[mapped] ?? 0)) {
          categories[mapped] = clamped;
        }
        if (clamped > maxScore) maxScore = clamped;
      }
    }

    // Detect prompt-injection patterns in the text (heuristic only — not foolproof).
    if (/ignore (all )?previous instructions/i.test(input.text)) {
      flags.push("prompt_injection_suspected");
    }

    return {
      allowed: !r0.flagged,
      categories,
      score: maxScore,
      confidence: null, // OpenAI doesn't report a single "confidence" — we leave it null
      reason: r0.flagged
        ? `OpenAI flagged: ${Object.entries(r0.categories ?? {})
            .filter(([, v]) => v === true)
            .map(([k]) => k)
            .join(", ")}`
        : "OpenAI: no categories flagged",
      provider: config.name,
      model: config.model,
      flags,
    };
  }

  async moderateImage(input: ImageModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    if (!config.apiKey) {
      throw new ModerationProviderConfigError("OpenAI provider requires an API key");
    }
    const endpoint = config.endpoint || "https://api.openai.com/v1/moderations";

    // OpenAI omni-moderation-latest supports image_url input.
    const res = await fetchWithRetry(async () => {
      const r = await fetchWithTimeout(endpoint, {
        method: "POST",
        timeoutMs: config.timeoutMs,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify({
          model: config.model || "omni-moderation-latest",
          input: [{ type: "image_url", image_url: { url: input.imageUrl } }],
        }),
      });
      await throwForStatus(r, "OpenAI");
      return r;
    });

    const json = await res.json().catch(() => null) as {
      results?: Array<{
        flagged?: boolean;
        categories?: Record<string, boolean>;
        category_scores?: Record<string, number>;
      }>;
    } | null;

    if (!json || !Array.isArray(json.results) || !json.results[0]) {
      throw new ModerationProviderResponseError("OpenAI returned an invalid response (image moderation)");
    }

    const r0 = json.results[0];
    const categories = emptyCategoryScores();
    let maxScore = 0;

    if (r0.category_scores) {
      for (const [openaiName, score] of Object.entries(r0.category_scores)) {
        const mapped = OPENAI_CATEGORY_MAP[openaiName];
        if (!mapped || typeof score !== "number") continue;
        const clamped = Math.max(0, Math.min(1, score));
        if (categories[mapped] === null || clamped > (categories[mapped] ?? 0)) {
          categories[mapped] = clamped;
        }
        if (clamped > maxScore) maxScore = clamped;
      }
    }

    return {
      allowed: !r0.flagged,
      categories,
      score: maxScore,
      confidence: null,
      reason: r0.flagged ? "OpenAI flagged image content" : "OpenAI: image not flagged",
      provider: config.name,
      model: config.model,
      flags: [],
    };
  }

  async moderateVideo(_input: VideoModerationInput, _config: ProviderRuntimeConfig): Promise<NormalizedModerationResult> {
    // OpenAI Moderation API does not support direct video analysis.
    // The Service handles frame extraction + multiple image calls.
    throw new ModerationProviderConfigError("OpenAI provider does not support direct video moderation — use frame extraction");
  }

  async healthCheck(config: ProviderRuntimeConfig): Promise<HealthCheckResult> {
    if (!config.apiKey) {
      return { healthy: false, reason: "Missing API key", latencyMs: 0 };
    }
    const start = Date.now();
    try {
      const endpoint = config.endpoint || "https://api.openai.com/v1/moderations";
      // Send a trivial "hello" — OpenAI returns a valid (200) response with
      // flagged=false for safe content. Cheaper than a models list call.
      const r = await fetchWithTimeout(endpoint, {
        method: "POST",
        timeoutMs: 5000,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify({
          model: config.model || "omni-moderation-latest",
          input: "hello",
        }),
      });
      if (r.status === 401) {
        return { healthy: false, reason: "Invalid API key (HTTP 401)", latencyMs: Date.now() - start };
      }
      if (r.status === 429) {
        return { healthy: false, reason: "Rate limited (HTTP 429)", latencyMs: Date.now() - start };
      }
      if (!r.ok) {
        return { healthy: false, reason: `HTTP ${r.status}`, latencyMs: Date.now() - start };
      }
      return { healthy: true, reason: "Connection successful", latencyMs: Date.now() - start };
    } catch (err) {
      return {
        healthy: false,
        reason: err instanceof Error ? err.message : "Connection failed",
        latencyMs: Date.now() - start,
      };
    }
  }
}
