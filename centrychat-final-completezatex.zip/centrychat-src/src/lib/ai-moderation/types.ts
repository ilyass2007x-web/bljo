/**
 * AI Moderation Provider System — Type Definitions
 * =================================================
 *
 * Pure types — no DB, no Node-only modules. Safe to import from anywhere.
 * The actual provider adapters + service live in sibling files and are
 * SERVER-ONLY (they import the database + encryption module).
 *
 * DESIGN (spec §2, §5, §57):
 *   - The application talks to `ModerationService`, NEVER to a concrete
 *     provider (OpenAI, Gemini, etc.). Adding a new provider requires
 *     only: implement the `ModerationProvider` interface + register it
 *     in the Registry. No change to the rest of the system.
 *   - All provider responses are normalized to `NormalizedModerationResult`
 *     so the policy engine doesn't care which provider produced the result.
 *   - Per-category scores are `number | null`. NULL means "the provider
 *     did not score this category" — we NEVER convert null to 0 (that
 *     would be a false negative for high-severity categories).
 *   - The AI gives categories + scores + confidence. The POLICY ENGINE
 *     (not the AI) decides the action. This is the critical separation
 *     required by spec §57: "Admin decides the penalty, not the AI."
 */

// ── Provider Type ──────────────────────────────────────────────────────

/**
 * Provider type identifier. Stored in `AiModerationProvider.type`. Drives
 * which adapter is instantiated by the Registry. Adding a new provider
 * type requires: implement the adapter + add a case to the Registry's
 * factory function. No DB migration, no admin UI change.
 */
export type ProviderType =
  | "openai"
  | "gemini"
  | "huggingface"
  | "custom"
  | "local";

/**
 * Admin-facing metadata for each provider type. Used by the admin UI to
 * show what each type supports + how to configure it. Static data — pure.
 */
export interface ProviderTypeMeta {
  id: ProviderType;
  label: string;
  description: string;
  supportsText: boolean;
  supportsImage: boolean;
  supportsVideo: boolean;
  /** Whether an API key is required (local self-hosted models don't need one). */
  requiresApiKey: boolean;
  /** Default endpoint when the admin doesn't specify a custom one. */
  defaultEndpoint: string | null;
  /** Help text shown in the admin "Add Provider" form. */
  helpText: string;
}

export const PROVIDER_TYPES: Record<ProviderType, ProviderTypeMeta> = {
  openai: {
    id: "openai",
    label: "OpenAI",
    description: "OpenAI Moderation API (text + image moderation).",
    supportsText: true,
    supportsImage: true,
    supportsVideo: false,
    requiresApiKey: true,
    defaultEndpoint: "https://api.openai.com/v1/moderations",
    helpText: "Use the omni-moderation-latest model for both text and image. API key from platform.openai.com.",
  },
  gemini: {
    id: "gemini",
    label: "Google Gemini",
    description: "Google Gemini Pro Vision / Safety settings.",
    supportsText: true,
    supportsImage: true,
    supportsVideo: false,
    requiresApiKey: true,
    defaultEndpoint: "https://generativelanguage.googleapis.com/v1beta",
    helpText: "Use gemini-1.5-pro or gemini-1.5-flash. API key from ai.google.dev.",
  },
  huggingface: {
    id: "huggingface",
    label: "Hugging Face",
    description: "Hugging Face Inference API (community models).",
    supportsText: true,
    supportsImage: false,
    supportsVideo: false,
    requiresApiKey: true,
    defaultEndpoint: "https://api-inference.huggingface.co/models",
    helpText: "Use a model like facebook/roberta-hate-speech-dynabench-r4-target. API key from huggingface.co/settings/tokens.",
  },
  custom: {
    id: "custom",
    label: "Custom API",
    description: "Any HTTP endpoint that accepts our request schema. Useful for self-hosted OpenAI-compatible gateways, internal moderation services, etc.",
    supportsText: true,
    supportsImage: true,
    supportsVideo: true,
    requiresApiKey: false,
    defaultEndpoint: null,
    helpText: "Endpoint is required. Must accept POST with JSON body { text?, imageUrl?, videoUrl? } and return { categories: {...}, confidence?: number, reason?: string }. SSRF-protected — private IPs are blocked.",
  },
  local: {
    id: "local",
    label: "Local / Self-hosted",
    description: "A locally-running model (e.g. Llama Guard via Ollama). No API key required.",
    supportsText: true,
    supportsImage: false,
    supportsVideo: false,
    requiresApiKey: false,
    defaultEndpoint: "http://localhost:11434/api/moderation",
    helpText: "Endpoint is required. Use a local URL (localhost or 127.0.0.1) — SSRF-protected but local addresses are allowed for this provider type only.",
  },
};

// ── Categories ────────────────────────────────────────────────────────

/**
 * Normalized moderation categories (spec §4). These are the 13 categories
 * the system supports. Each provider adapter maps its raw response to these.
 *
 * A score for a category can be NULL — meaning "the provider didn't score
 * this category." This is NOT the same as 0 (which would mean "definitely
 * not present"). NULL is preserved through the pipeline so the policy
 * engine only fires on categories the provider actually analyzed.
 */
export type ModerationCategory =
  | "sexual"
  | "explicit"
  | "nudity"
  | "suggestive"
  | "violence"
  | "graphicViolence"
  | "hate"
  | "harassment"
  | "bullying"
  | "selfHarm"
  | "spam"
  | "scam"
  | "illegal";

/** Ordered list of categories — used by the admin UI to render consistently. */
export const CATEGORY_ORDER: ModerationCategory[] = [
  "sexual",
  "explicit",
  "nudity",
  "suggestive",
  "violence",
  "graphicViolence",
  "hate",
  "harassment",
  "bullying",
  "selfHarm",
  "spam",
  "scam",
  "illegal",
];

/** Human-readable labels for the admin UI. Pure data. */
export const CATEGORY_LABELS: Record<ModerationCategory, string> = {
  sexual: "Sexual Content",
  explicit: "Explicit Sexual",
  nudity: "Nudity",
  suggestive: "Suggestive",
  violence: "Violence",
  graphicViolence: "Graphic Violence",
  hate: "Hate Speech",
  harassment: "Harassment",
  bullying: "Bullying",
  selfHarm: "Self Harm",
  spam: "Spam",
  scam: "Scam",
  illegal: "Illegal Content",
};

/**
 * Per-category scores (0..1, or null when the provider didn't score that category).
 * NEVER convert null to 0 — null means "unknown", 0 means "definitely not".
 */
export type CategoryScores = Record<ModerationCategory, number | null>;

// ── Normalized Result ─────────────────────────────────────────────────

/**
 * The normalized result every provider adapter must produce (spec §5).
 * The policy engine + action engine consume this shape — they never see
 * the raw provider response.
 */
export interface NormalizedModerationResult {
  /** Whether the provider considers the content overall safe (true) or not (false). */
  allowed: boolean;
  /** Per-category scores (0..1 or null). NULL is preserved — never converted to 0. */
  categories: CategoryScores;
  /** Composite score 0..1 (max across non-null categories, or 0 when no categories were scored). */
  score: number;
  /** Provider-reported confidence 0..1 (null when the provider doesn't report it). */
  confidence: number | null;
  /** Free-text reason from the provider (admin-only — never shown to end users). */
  reason: string;
  /** Provider name (snapshot — survives provider deletion). */
  provider: string;
  /** Model name (snapshot — survives model change). */
  model: string;
  /** Free-form flags the adapter wants to surface (e.g. ["prompt_injection_suspected"]). */
  flags: string[];
}

// ── Provider Interface ───────────────────────────────────────────────

/**
 * The interface every provider adapter must implement (spec §2).
 *
 * The application talks to this interface via the Registry + Service.
 * Adding a new provider requires only implementing this interface + adding
 * one case to the Registry's factory function. No change to the rest of
 * the system.
 *
 * NOTE: each method takes BOTH `input` AND `config`. The `config` carries
 * the decrypted API key + endpoint + timeout. We could have injected the
 * config into the constructor — but doing so would force the Registry to
 * hold per-call state (it currently uses singletons). Per-call config is
 * cleaner + avoids concurrency issues.
 */
export interface ModerationProvider {
  /** Stable identifier matching `ProviderType`. */
  readonly type: ProviderType;
  /** Human-readable name (for logs + admin UI). */
  readonly name: string;
  /** Declared capabilities — drives which requests this provider handles. */
  readonly capabilities: {
    text: boolean;
    image: boolean;
    video: boolean;
  };

  /** Moderate a piece of text. Returns the normalized result. */
  moderateText(input: TextModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult>;
  /** Moderate an image (URL — provider fetches it server-side). */
  moderateImage(input: ImageModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult>;
  /** Moderate a video (URL — provider fetches frames server-side if supported). */
  moderateVideo(input: VideoModerationInput, config: ProviderRuntimeConfig): Promise<NormalizedModerationResult>;
  /** Lightweight connectivity + auth check. Used by the admin "Test Provider" button. */
  healthCheck(config: ProviderRuntimeConfig): Promise<HealthCheckResult>;
}

/** Input for text moderation. */
export interface TextModerationInput {
  text: string;
  /** Content type hint — some providers adjust behavior based on this. */
  contentType: string;
}

/** Input for image moderation. The provider fetches the image server-side. */
export interface ImageModerationInput {
  imageUrl: string;
  /** Optional alt text — used by providers that can't see the image directly. */
  altText?: string;
}

/** Input for video moderation. Provider-dependent — most can't handle video directly. */
export interface VideoModerationInput {
  videoUrl: string;
}

/**
 * Runtime config for a provider call. Built by the Registry from the DB
 * row — the adapter never sees the encrypted form, only the decrypted key.
 */
export interface ProviderRuntimeConfig {
  /** Provider display name (for snapshots). */
  name: string;
  /** Model identifier (e.g. "omni-moderation-latest"). */
  model: string;
  /** Decrypted API key (plaintext — adapter-only, NEVER logged). */
  apiKey: string | null;
  /** Custom endpoint URL (null = use provider's defaultEndpoint). */
  endpoint: string | null;
  /** Per-call timeout in milliseconds (default 10000). */
  timeoutMs: number;
}

/** Health check result. */
export interface HealthCheckResult {
  healthy: boolean;
  /** Free-text reason (shown to the admin). */
  reason: string;
  /** Response latency in milliseconds (for stats). */
  latencyMs: number;
}

// ── Errors ────────────────────────────────────────────────────────────

/**
 * Base class for provider errors. The Service uses these to distinguish
 * retryable failures (timeouts, 429, 5xx) from definitive results (provider
 * said "blocked" — that's a definitive answer, not an error to retry).
 */
export class ModerationProviderError extends Error {
  /** true = retryable (timeout, 429, 5xx, network). false = definitive (don't retry). */
  readonly retryable: boolean;
  /** HTTP status code from the provider (null when no HTTP response). */
  readonly statusCode: number | null;

  constructor(message: string, opts: { retryable?: boolean; statusCode?: number | null; cause?: unknown }) {
    super(message);
    this.name = "ModerationProviderError";
    this.retryable = opts.retryable ?? false;
    this.statusCode = opts.statusCode ?? null;
    if (opts.cause instanceof Error) {
      // Preserve the cause chain for debugging.
      (this as { cause?: unknown }).cause = opts.cause;
    }
  }
}

/** Provider timed out (retryable). */
export class ModerationProviderTimeoutError extends ModerationProviderError {
  constructor(message: string, cause?: unknown) {
    super(message, { retryable: true, statusCode: null, cause });
    this.name = "ModerationProviderTimeoutError";
  }
}

/** Provider returned 429 Too Many Requests (retryable). */
export class ModerationProviderRateLimitError extends ModerationProviderError {
  constructor(message: string, cause?: unknown) {
    super(message, { retryable: true, statusCode: 429, cause });
    this.name = "ModerationProviderRateLimitError";
  }
}

/** Provider returned 5xx (retryable). */
export class ModerationProviderServerError extends ModerationProviderError {
  constructor(message: string, statusCode: number, cause?: unknown) {
    super(message, { retryable: true, statusCode, cause });
    this.name = "ModerationProviderServerError";
  }
}

/** Provider returned an invalid/unparseable response (NOT retryable — caller should fail to fallback or fail-open per policy). */
export class ModerationProviderResponseError extends ModerationProviderError {
  constructor(message: string, cause?: unknown) {
    super(message, { retryable: false, statusCode: null, cause });
    this.name = "ModerationProviderResponseError";
  }
}

/** Provider is not configured correctly (e.g. missing API key, invalid endpoint). NOT retryable. */
export class ModerationProviderConfigError extends ModerationProviderError {
  constructor(message: string) {
    super(message, { retryable: false, statusCode: null });
    this.name = "ModerationProviderConfigError";
  }
}

// ── Pipeline Types (Policy / Action / Escalation) ─────────────────────

/** Content action — what to do with the content itself. */
export type ContentAction =
  | "ALLOW"
  | "FLAG_FOR_REVIEW"
  | "HIDE_CONTENT"
  | "BLOCK_CONTENT"
  | "DELETE_CONTENT";

/** User action — what to do with the user who posted the content. */
export type UserAction =
  | "NONE"
  | "WARN_USER"
  | "RESTRICT_USER"
  | "SUSPEND_USER"
  | "BAN_USER";

/**
 * The final pipeline decision. Built by the Policy Engine from a
 * NormalizedModerationResult + the admin-configured policy.
 */
export interface ModerationDecision {
  /** The action to apply to the content. */
  contentAction: ContentAction;
  /** The action to apply to the user (NONE when no user action). */
  userAction: UserAction;
  /** Restriction duration in seconds (null = no time-based restriction). */
  restrictionDurationSec: number | null;
  /** The category that triggered the decision (highest-scoring above threshold). */
  triggeredCategory: ModerationCategory | null;
  /** The threshold value that was used (admin-configured). */
  threshold: number;
  /** The score that triggered the decision. */
  triggeredScore: number;
  /** Severity bucket (derived from score). */
  severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  /** Whether a review queue item should be created. */
  requiresReview: boolean;
  /** The policy version that produced this decision (snapshot). */
  policyVersion: number;
  /** Safe end-user message (never reveals detection details). */
  userMessage: string;
}

/** Admin-friendly summary of one provider call. */
export interface ModerationCallSummary {
  resultId: string;
  providerName: string;
  modelName: string;
  contentType: string;
  contentId: string | null;
  contentHash: string | null;
  userId: string | null;
  categoryScores: CategoryScores;
  score: number;
  confidence: number | null;
  reason: string;
  decision: ModerationDecision;
  /** Null when primary succeeded, otherwise the failed primary's name (for fallback tracking). */
  fallbackFrom: string | null;
  processingTimeMs: number;
  createdAt: string;
}
