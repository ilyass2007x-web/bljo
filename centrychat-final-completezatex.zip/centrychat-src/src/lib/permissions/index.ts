/**
 * Permission / RBAC helpers.
 *
 * Roles (ascending): USER < MODERATOR < ADMIN < SUPER_ADMIN
 * Server-side enforcement is MANDATORY. The frontend never authorizes.
 */

export type Role = "USER" | "MODERATOR" | "ADMIN" | "SUPER_ADMIN";
export type UserStatus =
  | "ACTIVE"
  | "SUSPENDED"
  | "BANNED"
  | "PENDING_VERIFICATION";

export const ROLE_RANK: Record<Role, number> = {
  USER: 0,
  MODERATOR: 1,
  ADMIN: 2,
  SUPER_ADMIN: 3,
};

export function hasRole(userRole: string, required: Role): boolean {
  const u = ROLE_RANK[userRole as Role];
  const r = ROLE_RANK[required];
  if (u === undefined || r === undefined) return false;
  return u >= r;
}

export function canModerate(userRole: string): boolean {
  return hasRole(userRole, "MODERATOR");
}

export function canAccessAdmin(userRole: string): boolean {
  return hasRole(userRole, "ADMIN");
}

export function isSuperAdmin(userRole: string): boolean {
  return hasRole(userRole, "SUPER_ADMIN");
}

export function isActive(status: string): boolean {
  return status === "ACTIVE";
}

export function canLogin(status: string): boolean {
  // Pending verification users can log in but are blocked from messaging until verified.
  return status === "ACTIVE" || status === "PENDING_VERIFICATION";
}
