/**
 * Background job abstraction.
 *
 * The MVP runs jobs in-process (fine for single-instance dev / small VPS).
 * Future: Redis-backed BullMQ, a separate worker process, or serverless queues.
 *
 * IMPORTANT: long-running work must NEVER block an HTTP request. Push it onto
 * the job queue and return immediately.
 */

export interface JobPayload {
  type: string;
  data: Record<string, unknown>;
}

export interface JobHandler {
  type: string;
  handle(data: Record<string, unknown>): Promise<void>;
}

export interface JobProvider {
  readonly name: string;
  register(handler: JobHandler): void;
  enqueue(payload: JobPayload): Promise<void>;
}

class InProcessJobProvider implements JobProvider {
  readonly name = "in-process";
  private handlers = new Map<string, JobHandler>();
  private queue: JobPayload[] = [];
  private processing = false;

  register(handler: JobHandler): void {
    this.handlers.set(handler.type, handler);
  }

  async enqueue(payload: JobPayload): Promise<void> {
    this.queue.push(payload);
    void this.drain();
  }

  private async drain(): Promise<void> {
    if (this.processing) return;
    this.processing = true;
    try {
      while (this.queue.length > 0) {
        const job = this.queue.shift()!;
        const handler = this.handlers.get(job.type);
        if (!handler) {
          console.warn(`[jobs] No handler for job type: ${job.type}`);
          continue;
        }
        try {
          await handler.handle(job.data);
        } catch (err) {
          console.error(`[jobs] Handler ${job.type} failed:`, err);
        }
      }
    } finally {
      this.processing = false;
    }
  }
}

let cached: JobProvider | null = null;

export function getJobs(): JobProvider {
  if (cached) return cached;
  const provider = (process.env.JOB_PROVIDER ?? "in-process").toLowerCase();
  switch (provider) {
    case "in-process":
    case "":
      cached = new InProcessJobProvider();
      break;
    default:
      throw new Error(`Unknown job provider: ${provider}`);
  }
  return cached;
}
