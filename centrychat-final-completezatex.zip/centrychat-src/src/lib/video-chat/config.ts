/**
 * Video Chat — WebRTC Configuration Service
 * ==========================================
 *
 * SERVER-ONLY. The single source of truth for WebRTC ICE server configuration.
 *
 * This is the ONLY function that builds the `iceServers` array. The frontend
 * fetches it via `GET /api/v1/video-chat/config` (authenticated) and passes
 * it to `new RTCPeerConnection(config)`.
 *
 * TURN credentials are NEVER exposed via NEXT_PUBLIC_* env vars. They live
 * in the PlatformSetting table (admin-editable) and are only served to
 * authenticated users via this function.
 *
 * ── P2P-First Architecture ───────────────────────────────────────────
 * When TURN is disabled (default), only STUN servers are provided. This
 * means WebRTC will attempt direct P2P (host candidates + STUN-reflexive
 * candidates). If P2P fails, the call fails — we do NOT silently route
 * through the Centry backend.
 *
 * When TURN is enabled (admin opted in), TURN servers are appended as
 * fallback candidates. WebRTC still prefers P2P; TURN is only used when
 * P2P is impossible (symmetric NAT, restrictive firewalls).
 */

import { getSetting, getSettingBool, getSettingNumber } from "@/lib/settings";

export interface IceServerConfig {
  urls: string[];
  username?: string;
  credential?: string;
}

export interface WebRtcConfig {
  iceServers: IceServerConfig[];
  /** Whether TURN is enabled (for client-side UI display). */
  turnEnabled: boolean;
  /** The STUN URL used (for client-side UI display). */
  stunUrl: string;
  /**
   * Admin-controlled debug-logging flag. When true, the client hook emits
   * `[VIDEO]` diagnostic logs (state transitions, ICE events, signaling
   * milestones — NEVER SDP / ICE payloads / TURN credentials). When false
   * (the default), the hook is silent. The admin toggles this from the
   * Video Chat admin panel (`videochat.debug_logging` PlatformSetting)
   * to debug a specific issue without redeploying.
   */
  debugLogging: boolean;
}

/**
 * Build the WebRTC ICE server configuration.
 *
 * This is the SINGLE source of truth — all video chat components fetch
 * this config via the /api/v1/video-chat/config endpoint. No component
 * hardcodes TURN credentials or STUN URLs.
 */
export async function getWebRtcConfig(): Promise<WebRtcConfig> {
  const stunUrl = (await getSetting("videochat.stun.url")) || "stun:stun.l.google.com:19302";
  const turnEnabled = await getSettingBool("videochat.turn.enabled");
  const debugLogging = await getSettingBool("videochat.debug_logging");

  const iceServers: IceServerConfig[] = [
    { urls: [stunUrl] },
  ];

  if (turnEnabled) {
    const turnUrl = await getSetting("videochat.turn.url");
    const turnUsername = await getSetting("videochat.turn.username");
    const turnCredential = await getSetting("videochat.turn.credential");
    const turnProtocol = (await getSetting("videochat.turn.protocol")) || "udp";
    const turnPort = (await getSettingNumber("videochat.turn.port")) ?? 3478;
    const turnTls = await getSettingBool("videochat.turn.tls");

    if (turnUrl) {
      const scheme = turnTls ? "turns" : "turn";
      const fullTurnUrl = `${scheme}:${turnUrl.replace(/^turns?:/, "")}:${turnPort}?transport=${turnTls ? "tls" : turnProtocol}`;
      iceServers.push({
        urls: [fullTurnUrl],
        username: turnUsername || undefined,
        credential: turnCredential || undefined,
      });
    }
  }

  return { iceServers, turnEnabled, stunUrl, debugLogging };
}

/**
 * Load all video chat settings (for the admin UI).
 * Returns the raw values — the admin UI displays + edits them.
 */
export async function loadVideoChatSettings(): Promise<{
  turnEnabled: boolean;
  turnUrl: string;
  turnUsername: string;
  turnCredential: string;
  turnProtocol: string;
  turnPort: number;
  turnTls: boolean;
  stunUrl: string;
  maxDurationSec: number;
  queueTimeoutSec: number;
  minAccountAgeHours: number;
  debugLogging: boolean;
}> {
  const [
    turnEnabled, turnUrl, turnUsername, turnCredential, turnProtocol,
    turnPort, turnTls, stunUrl, maxDurationSec, queueTimeoutSec, minAccountAgeHours,
    debugLogging,
  ] = await Promise.all([
    getSettingBool("videochat.turn.enabled"),
    getSetting("videochat.turn.url"),
    getSetting("videochat.turn.username"),
    getSetting("videochat.turn.credential"),
    getSetting("videochat.turn.protocol"),
    getSettingNumber("videochat.turn.port"),
    getSettingBool("videochat.turn.tls"),
    getSetting("videochat.stun.url"),
    getSettingNumber("videochat.max_duration_sec"),
    getSettingNumber("videochat.queue_timeout_sec"),
    getSettingNumber("videochat.min_account_age_hours"),
    getSettingBool("videochat.debug_logging"),
  ]);

  return {
    turnEnabled,
    turnUrl: turnUrl ?? "",
    turnUsername: turnUsername ?? "",
    turnCredential: turnCredential ?? "",
    turnProtocol: turnProtocol ?? "udp",
    turnPort: turnPort ?? 3478,
    turnTls,
    stunUrl: stunUrl ?? "stun:stun.l.google.com:19302",
    maxDurationSec: maxDurationSec ?? 3600,
    queueTimeoutSec: queueTimeoutSec ?? 60,
    minAccountAgeHours: minAccountAgeHours ?? 0,
    debugLogging,
  };
}
