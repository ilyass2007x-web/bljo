/**
 * Video Chat — Matchmaking Service
 * =================================
 *
 * SERVER-ONLY. Handles the matchmaking queue + session lifecycle.
 *
 * ── Architecture ─────────────────────────────────────────────────────
 * Matchmaking uses the project's existing Redis/Upstash cache abstraction
 * (src/lib/cache/index.ts) as the shared queue store. This is REQUIRED
 * on Netlify serverless — each Function instance has its own in-memory
 * state, so an in-memory queue would only ever match users that happen
 * to land on the SAME instance (essentially never in production).
 *
 * Redis keys (all server-side only, all TTL-bounded):
 *   videochat:queue:entry:{userId}  — JSON QueueEntry (1 entry per user)
 *                                     TTL = queue_timeout_sec (default 60s).
 *   videochat:queue:users           — Redis LIST of userIds currently in
 *                                     the queue (TTL refreshed on every
 *                                     join). Used to enumerate candidates
 *                                     without scanning the keyspace.
 *   videochat:match:{userId}        — JSON { sessionId, peerId, peerSummary }
 *                                     SET by the matcher when this user is
 *                                     matched, so the matched user's next
 *                                     poll can detect the match. TTL = 30s.
 *   videochat:claim:{userId}        — Atomic counter (INCR) used as a
 *                                     brief "match lock" during the
 *                                     match-creation critical section.
 *                                     Prevents double-matching when two
 *                                     concurrent joiners target the same
 *                                     waiting user. TTL = 10s.
 *
 * Flow:
 *   1. User POSTs /api/v1/video-chat/queue (join queue)
 *   2. The service looks for another waiting user (excluding blocked pairs)
 *   3. If found → atomically claims both users via INCR-based locks,
 *      creates a VideoChatSession row in the DB, sets match-notification
 *      keys for both users, returns "matched" to the joiner.
 *   4. If not found → adds the user's entry to Redis + LPUSHes userId
 *      to the users list, returns "searching".
 *   5. The client polls GET /api/v1/video-chat/queue every 2s
 *   6. When matched, the matcher's match-notification key is read by the
 *      waiting user's next poll, which returns "matched" + session info.
 *   7. WebRTC signaling happens via POST /api/v1/video-chat/signal
 *      (Redis-backed — see src/lib/video-chat/signal-store.ts).
 *   8. On call end, PATCH /api/v1/video-chat/sessions/{id} with
 *      action=ended.
 *
 * ── Concurrency / Double-Match Prevention ────────────────────────────
 *   When two users join at almost the same time AND both see the same
 *   waiting peer in the queue, they could both try to match that peer.
 *   The `videochat:claim:{userId}` counter (INCR is atomic on Redis)
 *   ensures that only ONE joiner can claim a given peer:
 *     - claim returns 1 → this joiner is the first claimant → proceed.
 *     - claim returns >1 → another joiner already claimed this peer →
 *       release our own claim and try the next peer.
 *   The claim TTL is short (10s) so a crashed matcher's claim auto-
 *   releases. There is still a tiny race window between INCR (claim)
 *   and the actual session creation — but the worst case is that one
 *   of the two joiners gets "no match" this round and tries again on
 *   the next poll, which is acceptable.
 *
 * ── Stale Entry Cleanup ──────────────────────────────────────────────
 * Every key has a TTL, so stale entries auto-expire even if the process
 * crashes mid-operation. The users LIST may accumulate stale userIds
 * whose entries have expired — when matching, we just skip entries that
 * return null from `cache.get`. The LIST itself has a TTL of
 * queue_timeout_sec, so it eventually resets.
 *
 * ── Block System Integration ─────────────────────────────────────────
 * Before matching two users, the service checks BOTH directions of the
 * Block table. If A blocks B OR B blocks A, they are never matched.
 */

import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { getSettingNumber } from "@/lib/settings";
import { getCache } from "@/lib/cache";

// ── Types ──────────────────────────────────────────────────────────────

export type MatchmakingStatus = "searching" | "matched" | "timeout" | "error";

export interface MatchmakingResult {
  status: MatchmakingStatus;
  sessionId?: string;
  peer?: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  /** Whether THIS user is the offerer (initiator) of the WebRTC connection. */
  isOfferer?: boolean;
}

// ── In-memory queue (fast matchmaking without DB writes on every poll) ─

/**
 * The user's gender + desired gender preference.
 * "ANY" means no gender filter (the user accepts any gender).
 */
export type GenderFilter = "ANY" | "MALE" | "FEMALE";

/**
 * The user's country preference.
 * "WORLDWIDE" means no country filter (accepts any country).
 * A specific ISO 3166-1 alpha-2 code means only that country.
 */
export type CountryFilter = "WORLDWIDE" | string; // e.g. "MA", "US", "FR"

interface QueueEntry {
  userId: string;
  joinedAt: number;
  // User's profile attributes (fetched once when joining).
  gender: string | null;        // MALE | FEMALE | PREFER_NOT_TO_SAY | null
  countryCode: string | null;   // ISO 3166-1 alpha-2
  // User's matchmaking preferences.
  desiredGender: GenderFilter;
  desiredCountry: CountryFilter;
  language?: string;
}

// ── Redis-backed shared queue store ───────────────────────────────────
//
// All keys are namespaced + TTL-bounded so stale state auto-expires
// even if a function instance crashes mid-operation. The cache
// abstraction (src/lib/cache/index.ts) is shared across ALL Netlify
// function instances via Upstash Redis REST in production, and falls
// back to an in-memory Map in dev (when CACHE_PROVIDER=memory or unset).
//
// Key layout:
//   videochat:queue:entry:{userId}  → JSON QueueEntry, TTL = queue_timeout_sec.
//   videochat:queue:users           → Redis LIST of userIds (TTL = queue_timeout_sec).
//                                      May contain stale userIds whose entries
//                                      have expired — callers skip null entries.
//   videochat:match:{userId}        → JSON MatchNotification, TTL = 30s.
//                                      Written by the matcher when this user
//                                      gets matched, so the matched user's
//                                      next poll detects it.
//   videochat:claim:{userId}        → INCR counter, TTL = 10s.
//                                      Used as an atomic "match lock" to
//                                      prevent double-matching under
//                                      concurrent joins.
const QUEUE_ENTRY_KEY_PREFIX = "videochat:queue:entry";
const QUEUE_USERS_KEY = "videochat:queue:users";
const MATCH_KEY_PREFIX = "videochat:match";
const CLAIM_KEY_PREFIX = "videochat:claim";

/** TTL for match-notification keys. Short — they're read on the next poll. */
const MATCH_TTL_SECONDS = 30;
/** TTL for claim locks. Short — they only need to survive the DB write. */
const CLAIM_TTL_SECONDS = 10;

function entryKey(userId: string): string {
  return `${QUEUE_ENTRY_KEY_PREFIX}:${userId}`;
}
function matchKey(userId: string): string {
  return `${MATCH_KEY_PREFIX}:${userId}`;
}
function claimKey(userId: string): string {
  return `${CLAIM_KEY_PREFIX}:${userId}`;
}

interface MatchNotification {
  sessionId: string;
  peerId: string;
  peerSummary: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
  };
  /** True if THIS user is the offerer (User A — was waiting in the queue). */
  isOfferer: boolean;
}

// Track active sessions in-memory for the "Next" stats endpoint. This is
// per-instance and may undercount on multi-instance deploys — the DB is
// the source of truth (used by getVideoChatStats via db.videoChatSession
// queries). Kept only as a fast-path for the admin dashboard's "active
// sessions" counter. The in-memory queue (Map<string, QueueEntry>) was
// REMOVED — it was per-process and made matchmaking impossible on
// Netlify serverless. All queue state now lives in Redis.
const activeSessions: Map<string, { userAId: string; userBId: string; startedAt: number }> = new Map();

// ── Helpers ────────────────────────────────────────────────────────────

/**
 * Check if two users have a block relationship (either direction).
 * Used by the matchmaking engine to exclude blocked pairs.
 */
async function areBlocked(userAId: string, userBId: string): Promise<boolean> {
  const block = await db.block.findFirst({
    where: {
      OR: [
        { blockerId: userAId, blockedId: userBId },
        { blockerId: userBId, blockedId: userAId },
      ],
    },
    select: { id: true },
  });
  return !!block;
}

/**
 * Check if a user's gender is acceptable to another user's preference.
 *
 * - "ANY" → accepts any gender (including null/PREFER_NOT_TO_SAY)
 * - "MALE" → only accepts MALE
 * - "FEMALE" → only accepts FEMALE
 *
 * NOTE: PREFER_NOT_TO_SAY + null are treated as "unknown gender". They
 * only match when the preference is "ANY" (we never guess the user's
 * actual gender). This is a deliberate safety choice.
 */
function genderMatches(candidateGender: string | null, desired: GenderFilter): boolean {
  if (desired === "ANY") return true;
  return candidateGender === desired;
}

/**
 * Check if a user's country is acceptable to another user's preference.
 *
 * - "WORLDWIDE" → accepts any country (including null)
 * - Specific code (e.g. "MA") → only accepts that exact code (case-sensitive,
 *   but we normalize to uppercase on input so this is safe)
 *
 * NOTE: null country only matches "WORLDWIDE" (we never guess the user's
 * country). This is deliberate.
 */
function countryMatches(candidateCountry: string | null, desired: CountryFilter): boolean {
  if (desired === "WORLDWIDE") return true;
  return candidateCountry === desired;
}

/**
 * Check MUTUAL compatibility between two users.
 *
 * Both users must accept each other:
 *   - A's desiredGender must accept B's gender AND B's desiredGender must accept A's gender
 *   - A's desiredCountry must accept B's country AND B's desiredCountry must accept A's country
 *
 * This is the core of the mutual matching logic. We NEVER silently broaden
 * a user's filters — if they asked for "Female + Morocco", they only match
 * with users who are Female AND in Morocco (and who also accept them back).
 */
function isMutuallyCompatible(a: QueueEntry, b: QueueEntry): boolean {
  // A accepts B?
  const aAcceptsBGender = genderMatches(b.gender, a.desiredGender);
  const aAcceptsBCountry = countryMatches(b.countryCode, a.desiredCountry);

  // B accepts A?
  const bAcceptsAGender = genderMatches(a.gender, b.desiredGender);
  const bAcceptsACountry = countryMatches(a.countryCode, b.desiredCountry);

  return aAcceptsBGender && aAcceptsBCountry && bAcceptsAGender && bAcceptsACountry;
}

/**
 * Stale-entry cleanup is now handled by Redis TTLs on every key — no
 * in-process scan needed. Kept as an exported no-op for backward
 * compatibility with any callers that used to import it.
 */
async function cleanStaleQueue(_timeoutSec: number): Promise<void> {
  // No-op — TTLs handle expiration. See module-level comment.
  void _timeoutSec;
}

// ── Public API ─────────────────────────────────────────────────────────

/**
 * Join the matchmaking queue. If a compatible partner is already waiting,
 * match immediately. Otherwise, add the user to the queue.
 *
 * The matchmaking uses MUTUAL compatibility: both users must accept each
 * other's gender + country. We NEVER silently broaden a user's filters.
 *
 * @param userId The user joining the queue.
 * @param preferences The user's matchmaking preferences (desiredGender + desiredCountry).
 */
export async function joinQueue(
  userId: string,
  preferences?: {
    desiredGender?: GenderFilter;
    desiredCountry?: CountryFilter;
  }
): Promise<MatchmakingResult> {
  const cache = getCache();
  const timeoutSec = (await getSettingNumber("videochat.queue_timeout_sec")) ?? 60;

  // 1. Check if we were already matched by someone else's join (race during
  //    the user's own poll cycle). The match key is set atomically by the
  //    matcher — if present, return matched immediately.
  const existingMatch = await cache.get<MatchNotification>(matchKey(userId));
  if (existingMatch) {
    return {
      status: "matched",
      sessionId: existingMatch.sessionId,
      peer: existingMatch.peerSummary,
      isOfferer: existingMatch.isOfferer,
    };
  }

  // 2. Idempotency: if the user is already in the queue, return "searching".
  //    This prevents duplicate entries when the client retries the POST.
  const existingEntry = await cache.get<QueueEntry>(entryKey(userId));
  if (existingEntry) {
    return { status: "searching" };
  }

  // 3. Fetch the user's profile attributes (gender + country) ONCE.
  //    These are the user's actual attributes — used by OTHER users' filters
  //    to decide if they accept this user.
  const userProfile = await db.user.findUnique({
    where: { id: userId },
    select: { gender: true, countryCode: true },
  });

  // If the user has no gender or country set, they can still join the queue
  // — but they'll only match with users whose preferences are "ANY" /
  // "WORLDWIDE" (since we never guess unknown attributes).
  const myEntry: QueueEntry = {
    userId,
    joinedAt: Date.now(),
    gender: userProfile?.gender ?? null,
    countryCode: userProfile?.countryCode ?? null,
    desiredGender: preferences?.desiredGender ?? "ANY",
    desiredCountry: preferences?.desiredCountry ?? "WORLDWIDE",
  };

  // 4. Enumerate all userIds currently in the queue (across ALL Netlify
  //    instances — this is the cross-instance visibility that the
  //    in-memory Map could not provide).
  let candidateIds: string[] = [];
  try {
    candidateIds = await cache.listRange<string>(QUEUE_USERS_KEY);
  } catch (err) {
    // Redis failure — log + treat as "no candidates available" (return
    // "searching" so the client retries on the next poll). If Redis is
    // down for an extended period, the client's queue-timeout will
    // eventually fire "timeout".
    logger.error("application", "matchmaking: listRange(users) failed", {
      error: err instanceof Error ? err.message : String(err),
    });
  }

  // 5. Try to match each candidate (in insertion order — oldest first,
  //    so a waiting user gets matched before a newer one).
  for (const peerId of candidateIds) {
    if (peerId === userId) continue; // never match self

    // Fetch the peer's entry. May be null if the entry expired between
    // the LIST read and this GET (rare but possible — TTLs are best-effort).
    let peerEntry: QueueEntry | null = null;
    try {
      peerEntry = await cache.get<QueueEntry>(entryKey(peerId));
    } catch {
      continue; // skip on Redis error — try next peer
    }
    if (!peerEntry) continue;

    // Check block relationship (both directions).
    if (await areBlocked(userId, peerId)) continue;

    // Check MUTUAL compatibility (both users must accept each other).
    if (!isMutuallyCompatible(myEntry, peerEntry)) continue;

    // ── Atomic claim via INCR (Redis single-threaded) ───────────────
    //   claimSelf — prevents another joiner from matching US while we
    //     are mid-match-creation with this peer.
    //   claimPeer — prevents another joiner from matching THIS PEER
    //     while we are mid-match-creation.
    //   If either claim returns >1, the user was already claimed by
    //   someone else — release our claims and try the next peer.
    let claimSelf: number;
    let claimPeer: number;
    try {
      [claimSelf, claimPeer] = await Promise.all([
        cache.increment(claimKey(userId), CLAIM_TTL_SECONDS),
        cache.increment(claimKey(peerId), CLAIM_TTL_SECONDS),
      ]);
    } catch (err) {
      // Redis failure during claim — skip this peer, try next.
      logger.error("application", "matchmaking: claim INCR failed", {
        error: err instanceof Error ? err.message : String(err),
      });
      continue;
    }

    if (claimSelf > 1) {
      // We were already claimed by another joiner (race). They will set
      // our match key — release the peer claim (if we got it) and bail
      // out so the next poll picks up the match.
      if (claimPeer === 1) {
        try { await cache.delete(claimKey(peerId)); } catch { /* best-effort */ }
      }
      // Don't add ourselves to the queue — we're being matched.
      return { status: "searching" };
    }

    if (claimPeer > 1) {
      // Peer was already claimed by another joiner. Release our own
      // claim and try the next peer.
      try { await cache.delete(claimKey(userId)); } catch { /* best-effort */ }
      continue;
    }

    // ── We won both claims — create the session ───────────────────────
    // The waiting user (peer) is the offerer (A), the joining user is
    // the answerer (B). This mirrors the original in-memory semantics.
    let session: { id: string; userAId: string; userBId: string; userA: { id: string; fullName: string; username: string; avatarColor: string | null; avatarUrl: string | null; isVerified: boolean } } | null = null;
    try {
      session = await db.videoChatSession.create({
        data: {
          userAId: peerId, // waiting user = offerer (A)
          userBId: userId, // joining user = answerer (B)
        },
        include: {
          userA: {
            select: {
              id: true, fullName: true, username: true,
              avatarColor: true, avatarUrl: true, isVerified: true,
            },
          },
        },
      });
    } catch (err) {
      // DB failure — release both claims so the next joiner can retry,
      // then return "searching" so the client retries on the next poll.
      logger.error("application", "matchmaking: db.videoChatSession.create failed", {
        error: err instanceof Error ? err.message : String(err),
      });
      try {
        await Promise.all([
          cache.delete(claimKey(userId)),
          cache.delete(claimKey(peerId)),
        ]);
      } catch { /* best-effort */ }
      // Don't add to queue — let the client retry. Returning "searching"
      // would re-add us to the queue, which is fine, but the DB might
      // still be down on the next call. Better to bail and let the
      // client's queue-timeout fire.
      return { status: "searching" };
    }

    activeSessions.set(session.id, {
      userAId: session.userAId,
      userBId: session.userBId,
      startedAt: Date.now(),
    });

    logger.info("application", "Video chat match created", {
      sessionId: session.id,
      userAId: session.userAId,
      userBId: session.userBId,
    });

    // ── Write match-notification keys for both users ─────────────────
    //   - For the PEER (waiting user A): isOfferer=true, peer = joiner.
    //     Their next poll detects this + returns matched.
    //   - For OURSELVES (joiner B): isOfferer=false, peer = waiting user.
    //     We return matched immediately below — the match key is just a
    //     safety net in case our response is lost + the client retries.
    //
    // We need the joiner's full profile to populate matchForPeer. Fetch
    // it here (one DB read — acceptable, happens only on match).
    let joinerSummary: { id: string; fullName: string; username: string; avatarColor: string | null; avatarUrl: string | null; isVerified: boolean } = {
      id: userId, fullName: "", username: "", avatarColor: null, avatarUrl: null, isVerified: false,
    };
    try {
      const joinerProfile = await db.user.findUnique({
        where: { id: userId },
        select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true },
      });
      if (joinerProfile) {
        joinerSummary = joinerProfile;
      }
    } catch {
      // Non-fatal — the matched user's poll will fetch the peer from DB
      // via the session.userB relation as a fallback (see checkQueueStatus).
    }
    const matchForPeer: MatchNotification = {
      sessionId: session.id,
      peerId: userId,
      peerSummary: joinerSummary,
      isOfferer: true,
    };
    const matchForSelf: MatchNotification = {
      sessionId: session.id,
      peerId,
      peerSummary: {
        id: session.userA.id,
        fullName: session.userA.fullName,
        username: session.userA.username,
        avatarColor: session.userA.avatarColor,
        avatarUrl: session.userA.avatarUrl,
        isVerified: session.userA.isVerified,
      },
      isOfferer: false,
    };

    try {
      await Promise.all([
        cache.set(matchKey(peerId), matchForPeer, MATCH_TTL_SECONDS),
        cache.set(matchKey(userId), matchForSelf, MATCH_TTL_SECONDS),
      ]);
    } catch (err) {
      // If the match-key write fails, the matched user's poll won't
      // detect the match. They'll time out + retry. We still return
      // "matched" to the joiner (we have the session). The peer will
      // recover on their next queue join.
      logger.error("application", "matchmaking: match-key write failed", {
        error: err instanceof Error ? err.message : String(err),
      });
    }

    // ── Clean up queue entries + claims ─────────────────────────────
    // Best-effort — if these fail, the TTLs will eventually clean up.
    try {
      await Promise.all([
        cache.delete(entryKey(userId)),
        cache.delete(entryKey(peerId)),
        cache.delete(claimKey(userId)),
        cache.delete(claimKey(peerId)),
      ]);
    } catch {
      // Non-fatal — TTLs will clean up.
    }

    // The joining user (B) is the answerer — return matched now.
    return {
      status: "matched",
      sessionId: session.id,
      peer: {
        id: session.userA.id,
        fullName: session.userA.fullName,
        username: session.userA.username,
        avatarColor: session.userA.avatarColor,
        avatarUrl: session.userA.avatarUrl,
        isVerified: session.userA.isVerified,
      },
      isOfferer: false,
    };
  }

  // 6. No compatible match found — add the user to the queue + return
  //    "searching". The next poll (from this user OR another user's join)
  //    will re-scan the queue.
  try {
    await Promise.all([
      cache.set(entryKey(userId), myEntry, timeoutSec),
      // LPUSH (atomic append) to the users list + refresh TTL.
      cache.listPush(QUEUE_USERS_KEY, userId, timeoutSec),
    ]);
  } catch (err) {
    // Redis failure — return "searching" so the client retries. If Redis
    // is down for an extended period, the client's queue-timeout will
    // eventually fire "timeout".
    logger.error("application", "matchmaking: failed to add to queue", {
      userId,
      error: err instanceof Error ? err.message : String(err),
    });
  }

  return { status: "searching" };
}

/**
 * Check the queue status. Called by the client every 2s while searching.
 * If another user matched with this user, returns the session + peer info.
 *
 * Order of checks:
 *   1. match-notification key → return matched (cross-instance visibility).
 *   2. queue entry key        → return "searching".
 *   3. neither                → return "timeout" (entry expired or never set).
 */
export async function checkQueueStatus(userId: string): Promise<MatchmakingResult> {
  const cache = getCache();
  const timeoutSec = (await getSettingNumber("videochat.queue_timeout_sec")) ?? 60;
  await cleanStaleQueue(timeoutSec);

  // 1. Cross-instance match detection — the matcher wrote a match-notification
  //    key for us. Read it (and delete it so we don't return matched twice).
  let match: MatchNotification | null = null;
  try {
    match = await cache.get<MatchNotification>(matchKey(userId));
  } catch (err) {
    logger.error("application", "matchmaking: checkQueueStatus match-get failed", {
      userId,
      error: err instanceof Error ? err.message : String(err),
    });
    // Treat as "still searching" — the next poll may succeed.
    return { status: "searching" };
  }
  if (match) {
    // Best-effort delete — the TTL will clean up if this fails.
    try { await cache.delete(matchKey(userId)); } catch { /* best-effort */ }

    // If the match notification didn't include the peer's full profile
    // (rare — only on DB read failure during join), fall back to fetching
    // the peer from the DB via the session. We always include BOTH userA
    // and userB in this fallback path so the TypeScript type is consistent
    // (the conditional-include variant confuses Prisma's type inference).
    if (!match.peerSummary.fullName && !match.peerSummary.username) {
      try {
        const session = await db.videoChatSession.findUnique({
          where: { id: match.sessionId },
          include: {
            userA: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
            userB: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
          },
        });
        if (session) {
          const peerRow = match.isOfferer ? session.userB : session.userA;
          if (peerRow) {
            match.peerSummary = {
              id: peerRow.id, fullName: peerRow.fullName, username: peerRow.username,
              avatarColor: peerRow.avatarColor, avatarUrl: peerRow.avatarUrl,
              isVerified: peerRow.isVerified,
            };
          }
        }
      } catch (err) {
        logger.error("application", "matchmaking: peer-profile fallback failed", {
          sessionId: match.sessionId,
          error: err instanceof Error ? err.message : String(err),
        });
      }
    }

    return {
      status: "matched",
      sessionId: match.sessionId,
      peer: match.peerSummary,
      isOfferer: match.isOfferer,
    };
  }

  // 2. Still in queue? (entry exists)
  let entry: QueueEntry | null = null;
  try {
    entry = await cache.get<QueueEntry>(entryKey(userId));
  } catch (err) {
    logger.error("application", "matchmaking: checkQueueStatus entry-get failed", {
      userId,
      error: err instanceof Error ? err.message : String(err),
    });
    return { status: "searching" };
  }
  if (entry) {
    return { status: "searching" };
  }

  // 3. Neither match nor entry — timed out (or never joined).
  return { status: "timeout" };
}

/**
 * Leave the queue (cancel search).
 *
 * Removes the user's queue entry + match-notification key from Redis.
 * The users LIST may still contain the userId (LPUSH is append-only),
 * but the entry is gone — future matchers will skip the null entry. The
 * LIST itself expires via TTL.
 */
export async function leaveQueue(userId: string): Promise<void> {
  const cache = getCache();
  try {
    await Promise.all([
      cache.delete(entryKey(userId)),
      cache.delete(matchKey(userId)),
      cache.delete(claimKey(userId)),
    ]);
  } catch (err) {
    // Non-fatal — TTLs will eventually clean up. Log for diagnostics.
    logger.error("application", "matchmaking: leaveQueue failed", {
      userId,
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

/**
 * End a video chat session. Records the end time + duration + reason.
 * Cleans up the in-memory active session.
 */
export async function endSession(
  sessionId: string,
  endReason: string,
  connectionType?: "P2P" | "TURN" | "FAILED"
): Promise<void> {
  try {
    const session = await db.videoChatSession.findUnique({
      where: { id: sessionId },
      select: { startedAt: true, connectedAt: true, endedAt: true },
    });

    if (!session || session.endedAt) {
      // Already ended or doesn't exist — just clean up memory.
      activeSessions.delete(sessionId);
      return;
    }

    const now = new Date();
    const durationSec = session.connectedAt
      ? Math.floor((now.getTime() - session.connectedAt.getTime()) / 1000)
      : null;

    await db.videoChatSession.update({
      where: { id: sessionId },
      data: {
        endedAt: now,
        durationSec,
        endReason,
        ...(connectionType ? { connectionType } : {}),
      },
    });

    activeSessions.delete(sessionId);
  } catch (err) {
    logger.error("application", "Failed to end video chat session", {
      sessionId,
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

/**
 * Mark a session as connected (WebRTC connection established).
 * Records the connection type (P2P vs TURN) for admin analytics.
 */
export async function markSessionConnected(
  sessionId: string,
  connectionType: "P2P" | "TURN"
): Promise<void> {
  try {
    await db.videoChatSession.update({
      where: { id: sessionId },
      data: {
        connectedAt: new Date(),
        connectionType,
      },
    });
  } catch (err) {
    logger.error("application", "Failed to mark session connected", {
      sessionId,
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

/**
 * Get admin dashboard statistics for video chat.
 */
export async function getVideoChatStats(): Promise<{
  activeSessions: number;
  usersSearching: number;
  connectedToday: number;
  p2pSuccessRate: number;
  turnUsageRate: number;
  failedRate: number;
  avgCallDurationSec: number;
  totalReports: number;
}> {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const [
    connectedToday,
    p2pCount,
    turnCount,
    failedCount,
    avgDurationAgg,
    totalReports,
  ] = await Promise.all([
    db.videoChatSession.count({
      where: {
        connectedAt: { gte: todayStart },
        endedAt: null,
      },
    }),
    db.videoChatSession.count({ where: { connectionType: "P2P" } }),
    db.videoChatSession.count({ where: { connectionType: "TURN" } }),
    db.videoChatSession.count({ where: { connectionType: "FAILED" } }),
    db.videoChatSession.aggregate({
      _avg: { durationSec: true },
      where: { durationSec: { not: null } },
    }),
    db.videoChatReport.count(),
  ]);

  const totalCompleted = p2pCount + turnCount + failedCount;
  const p2pSuccessRate = totalCompleted > 0 ? p2pCount / totalCompleted : 0;
  const turnUsageRate = totalCompleted > 0 ? turnCount / totalCompleted : 0;
  const failedRate = totalCompleted > 0 ? failedCount / totalCompleted : 0;

  // Cross-instance "users searching" count — read from the Redis users
  // LIST (may contain stale userIds whose entries have expired — that's
  // acceptable for an approximate count on the admin dashboard).
  let usersSearching = 0;
  try {
    const userIds = await getCache().listRange<string>(QUEUE_USERS_KEY);
    usersSearching = userIds.length;
  } catch {
    // Redis failure — report 0 (admin dashboard will show the failure
    // via the system-health endpoint, not here).
  }

  return {
    activeSessions: activeSessions.size,
    usersSearching,
    connectedToday,
    p2pSuccessRate,
    turnUsageRate,
    failedRate,
    avgCallDurationSec: avgDurationAgg._avg.durationSec ?? 0,
    totalReports,
  };
}
