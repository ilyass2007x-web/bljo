/**
 * Video Chat — centralized feature-flag helper.
 * ===============================================
 *
 * This module is the SINGLE source of truth for whether Video Chat
 * (random matchmaking + 1:1 chat video calls) is currently enabled.
 *
 * TWO LAYERS OF DEFENSE:
 *
 *   1. HARD KILL SWITCH (env var) — `VIDEO_CHAT_ENABLED`
 *      Server-side only. When this is NOT the literal string `"true"`,
 *      Video Chat is HARD-DISABLED at the server level: every video
 *      chat API route returns 403 immediately, before touching the
 *      database or feature-flag cache. This is the GUARANTEE that
 *      Video Chat can be turned off via a single environment variable
 *      change in Netlify — no DB round-trip, no cache TTL delay.
 *
 *      Default behavior (env var unset): DISABLED. This is fail-safe:
 *      a fresh deployment with no env var configured does NOT expose
 *      Video Chat. To re-enable, set `VIDEO_CHAT_ENABLED=true` in
 *      Netlify Environment Variables and redeploy.
 *
 *   2. ADMIN FEATURE FLAG (DB) — `video_chat` FeatureFlag row
 *      Server-side + client-side. The existing FeatureFlag system
 *      (src/lib/features/index.ts) that the admin can toggle from
 *      the Admin → Video Chat section. The API routes ALSO check
 *      this flag (defense-in-depth) — so even if the env var says
 *      "enabled", the admin can still disable per-environment via
 *      the database.
 *
 * FINAL RULE: Video Chat is enabled ONLY when BOTH conditions are true:
 *   - `VIDEO_CHAT_ENABLED === "true"` (env var)
 *   - `video_chat` FeatureFlag is `true` (DB)
 *
 * ── CLIENT-SIDE ──
 *
 * Client components CANNOT read `process.env.VIDEO_CHAT_ENABLED`
 * (server-only). They read `NEXT_PUBLIC_VIDEO_CHAT_ENABLED` instead.
 * The same fail-safe default applies: anything other than the literal
 * string `"true"` → disabled. TURN credentials, ICE config, etc. are
 * NEVER exposed via NEXT_PUBLIC_* — only the boolean.
 *
 * The client helper `isVideoChatClientEnabled()` is a SYNC function
 * (no DB call) — it can be called during render without breaking SSR.
 *
 * ── PRESERVATION ──
 *
 * Nothing in this module deletes or modifies the Video Chat codebase.
 * It only GATES access to it. When the env vars are flipped back to
 * `"true"`, every Video Chat feature works again — WebRTC
 * initialization, signaling, matchmaking, the admin panel, etc.
 * No migration, no code changes required.
 */

// ── SERVER-SIDE ─────────────────────────────────────────────────────────────

/**
 * Read the server-side env var. Returns true ONLY when the literal
 * string "true" is set. Anything else (unset, "false", "0", typos)
 * returns false — fail-safe.
 *
 * DO NOT inline this — keep it as a function so callers can mock it
 * in tests by setting process.env directly.
 */
function serverEnvEnabled(): boolean {
  return process.env.VIDEO_CHAT_ENABLED === "true";
}

/**
 * Check whether Video Chat is enabled at the ENV level (hard kill switch).
 *
 * SERVER-SIDE ONLY. Calling this from a Client Component will throw at
 * build time (process.env.VIDEO_CHAT_ENABLED is replaced at build time
 * with its literal value if present, or `undefined` — never the runtime
 * value, so it would silently always return false in the browser).
 *
 * Use `isVideoChatClientEnabled()` from Client Components instead.
 */
export function isVideoChatEnvEnabled(): boolean {
  return serverEnvEnabled();
}

/**
 * Combined check: env var must be "true" AND (if checking the DB flag)
 * the admin FeatureFlag must also be true.
 *
 * This is the AUTHORITATIVE check for server-side API routes. Use it
 * BEFORE doing any Video Chat work — it short-circuits the request
 * with 403 when disabled, without touching the matchmaking queue,
 * signaling store, or WebRTC config.
 *
 * @param checkFeatureFlag — when false, ONLY the env var is checked.
 *   Use this in lightweight routes (health, config) where the FeatureFlag
 *   DB query is unnecessary. Default true (check both).
 */
export async function isVideoChatEnabled(
  checkFeatureFlag = true
): Promise<boolean> {
  // Hard kill switch — fail fast without a DB call when env says no.
  if (!serverEnvEnabled()) return false;
  if (!checkFeatureFlag) return true;

  // Soft feature flag — admin can disable per-environment via the DB.
  try {
    const { isFeatureEnabled } = await import("@/lib/features");
    return await isFeatureEnabled("video_chat");
  } catch {
    // If the FeatureFlag system is unreachable, fail SAFE (disabled).
    // The env var said "enabled" but we can't confirm the admin flag —
    // safer to refuse than to start a Video Chat session the admin
    // may have intended to disable.
    return false;
  }
}

// ── CLIENT-SIDE ─────────────────────────────────────────────────────────────

/**
 * Sync client-side check based on NEXT_PUBLIC_VIDEO_CHAT_ENABLED.
 *
 * This is the ONLY safe way for Client Components to know whether to
 * render Video Chat UI (icons, buttons, dialogs, the screen itself).
 *
 * The env var is inlined by Next.js at build time, so the value is
 * deterministic per build — set it in `.env` (or Netlify env vars)
 * BEFORE building, then redeploy to flip.
 *
 * This does NOT check the DB FeatureFlag — that requires a server
 * round-trip. Client components that need the FULL server-side check
 * (env + flag) should call the `/api/v1/video-chat/config` endpoint
 * and react to the 403. The current usage (hide icons / block route)
 * only needs the env var — that's the hard kill switch the user can
 * toggle in Netlify.
 */
export function isVideoChatClientEnabled(): boolean {
  return process.env.NEXT_PUBLIC_VIDEO_CHAT_ENABLED === "true";
}
