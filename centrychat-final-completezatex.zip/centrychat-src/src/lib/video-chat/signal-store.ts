/**
 * Video Chat — Shared signaling store (Netlify serverless-safe).
 * ==============================================================
 *
 * SERVER-ONLY. Replaces the old per-process `Map<string, StoredSignal[]>`
 * that was in `src/app/api/v1/video-chat/signal/route.ts`. Without this
 * shared store, POST signal would land on Netlify Instance #X and GET
 * signal would land on Instance #Y → the offer/answer/ICE candidates
 * would never be delivered to the other peer → both clients stuck in
 * "Connecting..." forever.
 *
 * ARCHITECTURE:
 *   The store is per-(sessionId, recipientUserId). The producer (the
 *   sender of the signal) writes to the recipient's queue. The consumer
 *   (the recipient) reads + drains their OWN queue. This eliminates the
 *   read-modify-write race that a single shared per-sessionId queue
 *   would have (multiple producers + multiple consumers on the same key).
 *
 *   Each user has exactly one queue per session. The only producer for
 *   "user B's queue" is user A (and vice versa), so there's no cross-user
 *   write contention. The only consumer is the user themselves, polled
 *   by the client every 500ms.
 *
 * STORAGE:
 *   - Redis (Upstash REST) in production — shared across ALL Netlify
 *     function instances via the existing `CacheProvider.listPush` /
 *     `listRange` / `listDelete` primitives. Atomic LPUSH + EXPIRE
 *     pipeline. Sliding-window TTL of 5 minutes (refreshed on every
 *     push).
 *   - In-memory in dev/test — single-process, fine for local `bun run dev`
 *     where two browser tabs share the same Next.js process.
 *
 * TTL:
 *   SIGNAL_TTL_SECONDS = 300 (5 minutes) — matches the previous
 *   in-memory TTL of 5 * 60 * 1000 ms. The TTL is REFRESHED on every
 *   push (sliding window) — so as long as signals are being produced
 *   (which they are, every 500ms during ICE gathering), the queue
 *   stays alive. After the call ends, the queue expires automatically.
 *
 * SECURITY:
 *   - The store does NOT trust the `fromUserId` from the client — it's
 *     derived server-side from `requireVerifiedUser()` + the
 *     `VideoChatSession` participants. The caller passes `toUserId`
 *     which they computed by reversing the session's userAId/userBId.
 *   - Signal payloads are NEVER inspected by the store (they're opaque
 *     JSON blobs — SDP offers, SDP answers, ICE candidates). They are
 *     NOT logged.
 *   - TTL prevents stale data from accumulating indefinitely.
 *
 * FAILURE BEHAVIOR:
 *   - When the cache provider throws (Redis unreachable in production,
 *     or any other IO error), these functions throw. The route handler
 *     catches via `apiHandler` and returns 500 to the client. The
 *     client's signal-poll catch branch swallows the error and keeps
 *     polling (non-fatal for individual polls). If Redis is down for an
 *     extended period, the client's WebRTC connection eventually times
 *     out → `connectionState === "failed"` → UI shows "Connection lost".
 *   - In production, there is NO silent fallback to in-memory — that
 *     would recreate the original multi-instance bug.
 */

import { getCache } from "@/lib/cache";
import { logger } from "@/lib/logging";

// ── Types ─────────────────────────────────────────────────────────────

export type SignalType = "offer" | "answer" | "ice" | "end";

export interface StoredSignal {
  id: string;
  sessionId: string;
  fromUserId: string;
  toUserId: string;
  type: SignalType;
  payload: unknown;
  createdAt: number;
}

// ── Constants ────────────────────────────────────────────────────────

/** Sliding-window TTL for signal queues. Refreshed on every push. */
export const SIGNAL_TTL_SECONDS = 5 * 60; // 5 minutes

/** Redis key namespace prefix. */
const KEY_PREFIX = "video-chat:signal";

/**
 * Build the per-recipient queue key.
 *
 * Each (sessionId, recipientUserId) pair gets its own Redis LIST. This
 * eliminates the cross-user read-modify-write race that a single shared
 * per-sessionId queue would have.
 */
function buildKey(sessionId: string, recipientUserId: string): string {
  return `${KEY_PREFIX}:${sessionId}:${recipientUserId}`;
}

// ── Public API ────────────────────────────────────────────────────────

/**
 * Push a signal into the recipient's queue. Atomic LPUSH + EXPIRE on
 * Redis (sliding-window TTL). Safe to call concurrently from multiple
 * producers — each producer writes to the recipient's queue, and Redis
 * LPUSH is single-threaded.
 *
 * @param params.sessionId   The video chat session ID.
 * @param params.fromUserId  The SENDER's user ID (server-derived).
 * @param params.toUserId    The RECIPIENT's user ID (server-derived via session lookup).
 * @param params.type        "offer" | "answer" | "ice" | "end".
 * @param params.payload     Opaque JSON-serializable signal payload (SDP / ICE candidate / end marker).
 */
export async function pushSignal(params: {
  sessionId: string;
  fromUserId: string;
  toUserId: string;
  type: SignalType;
  payload: unknown;
}): Promise<void> {
  const { sessionId, fromUserId, toUserId, type, payload } = params;
  const signal: StoredSignal = {
    // The id is only used for client-side deduplication. It does NOT
    // need to be globally unique — only unique within the queue. The
    // combination of fromUserId + type + createdAt (ms) is sufficient
    // to dedupe within a 5-minute window.
    id: `${sessionId}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    sessionId,
    fromUserId,
    toUserId,
    type,
    payload,
    createdAt: Date.now(),
  };

  const key = buildKey(sessionId, toUserId);
  const serialized = JSON.stringify(signal);

  try {
    await getCache().listPush(key, serialized, SIGNAL_TTL_SECONDS);
  } catch (err) {
    // Log metadata only — never the payload (it may contain SDP which
    // could leak session description details).
    logger.error("application", "video-chat signal push failed", {
      sessionId,
      signalType: type,
      fromUserId,
      toUserId,
      keyNamespace: KEY_PREFIX,
      error: err instanceof Error ? err.message : String(err),
    });
    throw err;
  }
}

/**
 * Pop (consume) ALL signals addressed to the given user for the given
 * session. The signals are returned in oldest-first order (insertion
 * order — important for ICE candidates which can depend on order) and
 * then deleted from the queue (no double-delivery).
 *
 * Safe to call concurrently from multiple consumers of DIFFERENT users
 * (each user has their own queue). Concurrent calls from the SAME user
 * (rare — e.g. two browser tabs) would each get a slice of the queue;
 * the existing client-side dedup by signal id handles this.
 *
 * @param sessionId  The video chat session ID.
 * @param userId     The CALLING user's ID (the one polling). Returns signals addressed to them.
 * @returns Array of StoredSignal (possibly empty). Oldest-first.
 */
export async function popSignals(
  sessionId: string,
  userId: string
): Promise<StoredSignal[]> {
  const key = buildKey(sessionId, userId);

  let signals: StoredSignal[];
  try {
    // LRANGE is non-destructive. We DEL after reading to drain the queue.
    // This is a tiny read-then-delete race — if a producer LPUSHes
    // between LRANGE and DEL, that signal is lost. For the signaling
    // use-case, this is acceptable: ICE candidates are redundant (the
    // connection establishes via the surviving ones), and offer/answer
    // are sent ONCE (so the only way a new one arrives between LRANGE
    // and DEL is the rare case where the sender retries due to a network
    // error — and even then, the WebRTC layer tolerates a duplicate
    // setRemoteDescription on an idempotent offer/answer).
    signals = await getCache().listRange<StoredSignal>(key);
    if (signals.length > 0) {
      await getCache().listDelete(key);
    }
  } catch (err) {
    logger.error("application", "video-chat signal pop failed", {
      sessionId,
      userId,
      keyNamespace: KEY_PREFIX,
      error: err instanceof Error ? err.message : String(err),
    });
    throw err;
  }

  return signals;
}
