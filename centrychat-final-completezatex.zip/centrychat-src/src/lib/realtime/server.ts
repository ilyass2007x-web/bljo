/**
 * Server-side realtime broadcast.
 *
 * The Next.js app (port 3000) cannot hold WebSocket connections to fan out
 * messages in serverless mode. Instead it POSTs to the realtime mini-service
 * (port 3003 in dev, or a WebSocket gateway in prod) which holds the client
 * connections and pushes events down.
 *
 * Abstraction: if REALTIME_INTERNAL_URL is unset, broadcast is a no-op (the
 * frontend will poll as a fallback). This keeps the app functional even without
 * the realtime service running.
 */
import { logger } from "@/lib/logging";
import type { RealtimeMessage } from "@/lib/realtime";

const REALTIME_INTERNAL_URL =
  process.env.REALTIME_INTERNAL_URL ?? "http://localhost:3003";

export async function broadcastRealtime(msg: RealtimeMessage): Promise<void> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    await fetch(`${REALTIME_INTERNAL_URL}/internal/broadcast`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(msg),
      signal: controller.signal,
    });
    clearTimeout(timeout);
  } catch (err) {
    // Non-fatal: frontend falls back to polling.
    logger.debug("performance", "Realtime broadcast skipped", {
      error: err instanceof Error ? err.message : "unknown",
    });
  }
}
