/**
 * Realtime abstraction.
 *
 * The frontend messaging UI talks to a RealtimeProvider interface, NOT to a
 * specific socket.io client. This lets us swap implementations:
 *  - WebSocket / socket.io (self-hosted — current MVP via mini-service on :3003)
 *  - SSE (serverless compatible)
 *  - Redis Pub/Sub fan-out (multi-instance)
 *  - Managed realtime provider
 */

export type RealtimeEvent =
  | "message:new"
  | "message:update"
  | "message:delete"
  | "message:read"
  | "conversation:read"
  | "notification:new"
  | "presence:update"
  | "typing.start"
  | "typing.stop"
  // ── Chat Video Call (additive — does NOT affect existing events) ──
  // Sent by the caller when they POST /api/v1/conversations/[id]/call/start.
  // The recipient's messenger listens for this event to open the incoming
  // call UI. Payload: { conversationId, callId, caller: SafeUserSummary }.
  | "conversation:call:incoming"
  // Sent when the recipient accepts/rejects/ends a call. The caller's
  // messenger listens to transition out of the "calling" state.
  // Payload: { conversationId, callId, action: "accept"|"reject"|"end"|"busy" }
  | "conversation:call:event";

export interface RealtimeMessage {
  event: RealtimeEvent;
  payload: unknown;
  /** Recipient user IDs (server-enforced). */
  recipientIds?: string[];
}

export interface RealtimeClient {
  connect(token: string): Promise<void>;
  disconnect(): void;
  on(event: RealtimeEvent, handler: (payload: unknown) => void): () => void;
  /** Notify the server that the user is now viewing a conversation. */
  markActive(conversationId: string | null): void;
  readonly isConnected: boolean;
}
