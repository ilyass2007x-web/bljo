/**
 * Database abstraction layer.
 *
 * The application talks to Prisma through this module. The active Prisma client
 * is the only database dependency the rest of the codebase is allowed to import.
 *
 * PORTABILITY:
 * - On SQLite (dev): `DATABASE_URL=file:./db/custom.db`
 * - On PostgreSQL (prod): `DATABASE_URL=postgresql://user:pass@host:5432/db`
 *   — switch `provider` in prisma/schema.prisma to "postgresql" and run migrations.
 * No application code changes are required when switching providers, because all
 * data access goes through `lib/database`.
 *
 * PHASE 2D — WRITE-TIME NORMALIZATION:
 *   The Prisma Client is extended via `$extends({ query: {...} })` to
 *   intercept `create` + `update` on the 5 searchable entities (User,
 *   Post, Article, Collection, Playlist). When the intercepted operation
 *   includes a searchable field in `args.data`, the corresponding
 *   `*_normalized` field is automatically computed via
 *   `normalizeForSearch()` (from src/lib/search/normalize.ts) and
 *   injected into `args.data` before the write is delegated to Prisma.
 *
 *   This catches 100% of searchable-field writes through the Prisma
 *   Client. Other write paths (admin actions, moderation pipeline,
 *   item reorders) touch only non-searchable fields (status, role,
 *   isVerified, moderationStatus, updatedAt) and are not affected.
 *
 *   No `beforeCreate`/`beforeUpdate` Prisma hooks are used — those are
 *   not Prisma Client APIs. The `$extends({ query: {...} })` extension
 *   is the standard Prisma 5+ pattern for write interception.
 */
import { PrismaClient } from "@prisma/client";
import { normalizeForSearch } from "@/lib/search/normalize";

/**
 * Helper: inject normalized fields into args.data based on which raw
 * searchable fields are present.
 *
 * Mutates `args.data` in place — Prisma's extension API passes the args
 * object by reference, so mutating it before calling `query(args)` is
 * the documented way to inject computed fields.
 *
 * For each entity, the mapping is:
 *   User:        username → usernameNormalized, fullName → fullNameNormalized
 *   Post:        content → contentNormalized
 *   Article:     title → titleNormalized, content → contentNormalized,
 *                excerpt → excerptNormalized
 *   Collection:  name → nameNormalized, description → descriptionNormalized
 *   Playlist:    name → nameNormalized, description → descriptionNormalized
 */
function injectNormalizedFields(
  model: "user" | "post" | "article" | "collection" | "playlist",
  data: unknown
): void {
  if (!data || typeof data !== "object") return;
  const d = data as Record<string, unknown>;

  // Prisma allows nested writes (e.g. `{ posts: { create: [...] } }`).
  // We only inject at the top level — nested writes that touch searchable
  // fields go through their own create/update interceptors.
  switch (model) {
    case "user":
      if (typeof d.username === "string") d.usernameNormalized = normalizeForSearch(d.username);
      if (typeof d.fullName === "string") d.fullNameNormalized = normalizeForSearch(d.fullName);
      break;
    case "post":
      if (typeof d.content === "string") d.contentNormalized = normalizeForSearch(d.content);
      break;
    case "article":
      if (typeof d.title === "string") d.titleNormalized = normalizeForSearch(d.title);
      if (typeof d.content === "string") d.contentNormalized = normalizeForSearch(d.content);
      if (typeof d.excerpt === "string") d.excerptNormalized = normalizeForSearch(d.excerpt);
      break;
    case "collection":
      if (typeof d.name === "string") d.nameNormalized = normalizeForSearch(d.name);
      if (typeof d.description === "string") d.descriptionNormalized = normalizeForSearch(d.description);
      break;
    case "playlist":
      if (typeof d.name === "string") d.nameNormalized = normalizeForSearch(d.name);
      if (typeof d.description === "string") d.descriptionNormalized = normalizeForSearch(d.description);
      break;
  }
}

/**
 * Create the extended Prisma Client with write-interception for
 * searchable-field normalization.
 *
 * The extension's `query.{model}.{create,update}` callbacks receive
 * `{ args, query }` where:
 *   - `args` is the Prisma operation args (e.g. `{ data: {...}, where: {...} }`)
 *   - `query` is the original Prisma operation (call it to delegate)
 *
 * We mutate `args.data` to inject `*_normalized` fields, then call
 * `query(args)` to perform the actual write.
 */
function createExtendedClient(): PrismaClient {
  const base = new PrismaClient({
    log:
      process.env.NODE_ENV === "development"
        ? ["error", "warn"]
        : ["error"],
  });

  return base.$extends({
    name: "phase2d-search-normalization",
    query: {
      user: {
        async create({ args, query }) {
          injectNormalizedFields("user", (args as { data?: unknown }).data);
          return query(args);
        },
        async update({ args, query }) {
          injectNormalizedFields("user", (args as { data?: unknown }).data);
          return query(args);
        },
      },
      post: {
        async create({ args, query }) {
          injectNormalizedFields("post", (args as { data?: unknown }).data);
          return query(args);
        },
        async update({ args, query }) {
          injectNormalizedFields("post", (args as { data?: unknown }).data);
          return query(args);
        },
      },
      article: {
        async create({ args, query }) {
          injectNormalizedFields("article", (args as { data?: unknown }).data);
          return query(args);
        },
        async update({ args, query }) {
          injectNormalizedFields("article", (args as { data?: unknown }).data);
          return query(args);
        },
      },
      collection: {
        async create({ args, query }) {
          injectNormalizedFields("collection", (args as { data?: unknown }).data);
          return query(args);
        },
        async update({ args, query }) {
          injectNormalizedFields("collection", (args as { data?: unknown }).data);
          return query(args);
        },
      },
      playlist: {
        async create({ args, query }) {
          injectNormalizedFields("playlist", (args as { data?: unknown }).data);
          return query(args);
        },
        async update({ args, query }) {
          injectNormalizedFields("playlist", (args as { data?: unknown }).data);
          return query(args);
        },
      },
    },
  }) as unknown as PrismaClient;
  // Cast back to PrismaClient: the $extends return type is structurally
  // compatible with PrismaClient for all read/write operations, but
  // TypeScript doesn't know that. The cast is safe — every existing
  // `db.X.findUnique(...)` / `db.X.create(...)` call continues to work.
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db = globalForPrisma.prisma ?? createExtendedClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = db;

export type { PrismaClient } from "@prisma/client";

/**
 * Returns the configured database provider name (e.g. "sqlite" or "postgresql").
 * Used by the Admin → Database panel for display only.
 */
export function getDatabaseProvider(): string {
  // Read from the schema-derived env at build time is not available at runtime,
  // so we infer from DATABASE_URL scheme.
  const url = process.env.DATABASE_URL ?? "";
  if (url.startsWith("file:")) return "sqlite";
  if (url.startsWith("postgres")) return "postgresql";
  return "unknown";
}

/**
 * Lightweight connectivity probe used by /api/ready.
 */
export async function pingDatabase(): Promise<{
  ok: boolean;
  latencyMs: number;
  error?: string;
}> {
  const start = Date.now();
  try {
    // A cheap scalar query that works on both SQLite and PostgreSQL.
    await db.$queryRaw`SELECT 1`;
    return { ok: true, latencyMs: Date.now() - start };
  } catch (err) {
    return {
      ok: false,
      latencyMs: Date.now() - start,
      error: err instanceof Error ? err.message : "Unknown database error",
    };
  }
}
