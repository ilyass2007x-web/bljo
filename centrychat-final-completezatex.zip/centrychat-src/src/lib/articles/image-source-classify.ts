/**
 * Image-source classification — PURE CLIENT-SAFE HELPERS.
 *
 * This module is intentionally separated from `image-source-validation.ts`
 * so that client components (ArticleEditor, EditProfileScreen) can import
 * only the synchronous platform classification helpers WITHOUT pulling
 * `src/lib/media/resolver.ts` (which imports `node:dns` + `node:net` for
 * SSRF protection) into the browser bundle.
 *
 * WHAT LIVES HERE (pure sync, no Node primitives, no network):
 *   - ImageSourceKind type
 *   - isPinterestUrl(url)
 *   - classifyImageSourceKind(url)
 *   - getDisallowedReason(url)
 *   - providerToKind(provider)
 *
 * WHAT DOES NOT LIVE HERE (server-only — stays in image-source-validation.ts):
 *   - validateImageSource(url)   → calls resolveMedia (SSRF HTTP probe)
 *   - isValidImageSource(url)    → wraps validateImageSource
 *
 * The SSRF defense in `src/lib/media/resolver.ts` is UNCHANGED — we are
 * only re-locating the pure helpers so the bundler doesn't follow the
 * `resolveMedia` import path when building client chunks.
 */

import type { MediaProvider } from "@/lib/media/types";

// ── Types ────────────────────────────────────────────────────────────────

export type ImageSourceKind = "pinterest" | "direct-image" | "disallowed";

// ── Platform classification ─────────────────────────────────────────────

/**
 * Check if a URL belongs to Pinterest. Accepts:
 *   - https://www.pinterest.com/pin/...
 *   - https://pinterest.com/pin/...
 *   - https://pin.it/...
 *   - https://*.pinterest.com/... (country subdomains like uk.pinterest.com)
 *
 * Pinterest short links (pin.it) redirect to pinterest.com — the
 * resolver follows redirects + re-resolves the destination, so we
 * accept the pin.it form here too.
 */
export function isPinterestUrl(url: string): boolean {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    if (host === "pin.it") return true;
    if (host === "pinterest.com" || host === "www.pinterest.com") return true;
    // Country subdomains: uk.pinterest.com, ca.pinterest.com, etc.
    if (host.endsWith(".pinterest.com")) return true;
    return false;
  } catch {
    return false;
  }
}

/**
 * Disallowed platforms — these are NEVER accepted as image sources,
 * even if the resolver manages to extract an og:image from them.
 *
 * The user's intent (per spec) is that ONLY Pinterest + direct image
 * URLs are allowed. A Facebook/Instagram/TikTok/Google page that
 * happens to have an og:image is NOT a valid image source.
 *
 * Note: Pinterest is intentionally NOT in this list — it's the only
 * social platform we accept (per spec).
 */
const DISALLOWED_HOST_PATTERNS: ReadonlyArray<{ host: string; reason: string }> = [
  { host: "instagram.com", reason: "Instagram pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "www.instagram.com", reason: "Instagram pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "facebook.com", reason: "Facebook pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "www.facebook.com", reason: "Facebook pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "fb.watch", reason: "Facebook pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "tiktok.com", reason: "TikTok pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "www.tiktok.com", reason: "TikTok pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "google.com", reason: "Google pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "www.google.com", reason: "Google pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "images.google.com", reason: "Google Images pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "lens.google.com", reason: "Google Lens pages are not allowed. Use a Pinterest link or a direct image URL." },
  { host: "share.google", reason: "Google share links are not allowed. Use a Pinterest link or a direct image URL." },
];

/**
 * Synchronous (no-network) client-side pre-check.
 *
 * Returns the detected "kind" of the URL so the UI can show
 * instant feedback without waiting for the resolver to probe.
 *
 *   - "pinterest"     → URL is a Pinterest link (accepted by the kind rule)
 *   - "direct-image"  → URL doesn't match any disallowed platform — MIGHT be
 *                        a direct image. The resolver must verify Content-Type.
 *   - "disallowed"    → URL matches a disallowed platform (Instagram, FB, etc.).
 *                        Reject immediately, no resolver call needed.
 */
export function classifyImageSourceKind(url: string): ImageSourceKind {
  const trimmed = (url ?? "").trim();
  if (!trimmed) return "disallowed";

  try {
    const u = new URL(trimmed);
    const host = u.hostname.toLowerCase();
    if (isPinterestUrl(trimmed)) return "pinterest";
    for (const pattern of DISALLOWED_HOST_PATTERNS) {
      if (host === pattern.host || host.endsWith("." + pattern.host)) {
        return "disallowed";
      }
    }
    return "direct-image";
  } catch {
    return "disallowed";
  }
}

/**
 * Returns the user-facing reason for a disallowed URL, or null if the
 * URL is not on the disallowed list. Used by the frontend to show
 * instant feedback before the resolver probe completes.
 */
export function getDisallowedReason(url: string): string | null {
  const trimmed = (url ?? "").trim();
  if (!trimmed) return null;
  try {
    const u = new URL(trimmed);
    const host = u.hostname.toLowerCase();
    for (const pattern of DISALLOWED_HOST_PATTERNS) {
      if (host === pattern.host || host.endsWith("." + pattern.host)) {
        return pattern.reason;
      }
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * Map a resolver-returned `provider` to the image-source kind.
 * Used by frontend hooks (useImageSourceValidation) to interpret the
 * resolver's output in terms of the allowlist.
 *
 *   - "pinterest" → "pinterest"
 *   - "direct"    → "direct-image" (the resolver confirmed type=image
 *                   via Content-Type — the caller should still check
 *                   `resolved.type === "image"`)
 *   - anything else → "disallowed"
 */
export function providerToKind(provider: MediaProvider): ImageSourceKind {
  if (provider === "pinterest") return "pinterest";
  if (provider === "direct") return "direct-image";
  return "disallowed";
}
