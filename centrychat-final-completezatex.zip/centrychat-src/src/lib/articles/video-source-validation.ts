/**
 * Shared video-source validation (Phase 18 follow-up + SSRF hardening).
 *
 * ONE shared validation function used by:
 *   - Article video URLs (POST/PATCH /api/v1/articles)
 *
 * Accepts:
 *   - Direct video URLs (Content-Type: video/* — verified via HTTP probe).
 *   - Embed URLs from recognized providers (YouTube, Vimeo, TikTok,
 *     Instagram, Facebook, X, Reddit) — these are pattern-matched by
 *     `detectPlatform` WITHOUT an HTTP probe (no SSRF surface).
 *   - Pinterest URLs (which may host video pins).
 *
 * Rejects:
 *   - Google search/image pages
 *   - Instagram pages (the page, not the embed)
 *   - Facebook pages (the page, not the embed)
 *   - TikTok pages (the page, not the embed)
 *   - Random webpages (no Content-Type video/* + no recognized embed)
 *   - Broken URLs
 *   - Dangerous schemes (javascript:, data:, vbscript:, file:, blob:, about:)
 *   - Private/loopback IPs (via the SSRF-safe resolver, now with DNS pinning)
 *
 * SECURITY:
 *   - Calls `resolveMedia` which uses undici's Agent with a pinned DNS
 *     lookup — closes the DNS-rebinding TOCTOU gap.
 *   - All schemes are validated (only http/https).
 *   - All hostnames are validated (no private IPs).
 *   - All redirect chains are re-validated per hop.
 *
 * Reused infrastructure:
 *   - `detectPlatform` from `embeds.ts` (pure regex, no network).
 *   - `resolveMedia` from `resolver.ts` (SSRF-safe HTTP probe with DNS pinning).
 */

import { resolveMedia } from "@/lib/media/resolver";
import { detectPlatform } from "@/lib/media/embeds";
import type { MediaProvider } from "@/lib/media/types";

export interface VideoSourceValidationResult {
  ok: boolean;
  /** The validated URL (trimmed) when ok=true. */
  url?: string;
  /** User-facing error message when ok=false. */
  error?: string;
  /** What kind of source was detected (for UX/debugging). */
  kind?: "embed" | "direct-video" | "pinterest" | "disallowed";
}

/**
 * Validate a video URL for persistence.
 *
 * @param url - the user-supplied video URL (string | null | undefined).
 * @returns `{ ok: true, url, kind }` on success, `{ ok: false, error, kind }` on failure.
 */
export async function validateVideoSource(
  url: string | null | undefined
): Promise<VideoSourceValidationResult> {
  if (!url || typeof url !== "string") {
    return { ok: false, error: "Video URL is required.", kind: "disallowed" };
  }
  const trimmed = url.trim();
  if (!trimmed) {
    return { ok: false, error: "Video URL cannot be empty.", kind: "disallowed" };
  }
  if (trimmed.length > 2048) {
    return { ok: false, error: "Video URL is too long.", kind: "disallowed" };
  }

  // Step 1: scheme + basic URL structure.
  // Reject javascript:, data:, vbscript:, file:, blob:, about: schemes.
  // The resolver also rejects these, but we check synchronously first
  // for a clear error message + zero network cost.
  if (!/^https?:\/\//i.test(trimmed)) {
    return {
      ok: false,
      error: "Invalid video link. Use a YouTube/Vimeo/TikTok link or a direct video URL.",
      kind: "disallowed",
    };
  }
  // Defensive: never accept these schemes even with https:// regex (e.g.
  // crafted "javascript://" wouldn't match https:// but check anyway).
  if (/javascript:|data:|vbscript:|file:|blob:|about:/i.test(trimmed)) {
    return {
      ok: false,
      error: "Blocked scheme.",
      kind: "disallowed",
    };
  }

  // Step 2: synchronous platform detection (NO network call).
  // YouTube/Vimeo/TikTok/Instagram/Facebook/X/Reddit embed URLs are
  // pattern-matched here — they're trusted + don't need an HTTP probe.
  // The `detectPlatform` function returns an EmbedInfo with a `provider`
  // string for recognized hosts (e.g. "youtube", "vimeo", "pinterest").
  const embed = detectPlatform(trimmed);
  if (embed && embed.provider !== "webpage") {
    // Recognized embed provider — accept the URL as-is.
    // Pinterest is also handled here (provider === "pinterest").
    return {
      ok: true,
      url: trimmed,
      kind: embed.provider === "pinterest" ? "pinterest" : "embed",
    };
  }

  // Step 3: SSRF-safe HTTP probe via the EXISTING resolver.
  // The resolver uses undici with DNS pinning (closes the DNS-rebinding
  // TOCTOU gap) — the IP we validate is the same IP we'd connect to.
  let resolved;
  try {
    resolved = await resolveMedia(trimmed);
  } catch {
    // Network error / SSRF block / timeout → reject.
    return {
      ok: false,
      error: "Invalid video link. Use a YouTube/Vimeo/TikTok link or a direct video URL.",
      kind: "disallowed",
    };
  }

  // Direct video URL: the resolver MUST have confirmed `type === "video"`
  // via Content-Type sniffing. No extension guessing — only the actual
  // HTTP response Content-Type decides.
  if (resolved.type === "video" && resolved.mediaUrl) {
    return { ok: true, url: trimmed, kind: "direct-video" };
  }

  // Some webpages serve a video via og:video / twitter:player — the
  // resolver returns `type: "embed"` in that case. Accept these.
  if (resolved.type === "embed" && resolved.mediaUrl) {
    return { ok: true, url: trimmed, kind: "embed" };
  }

  // The URL resolved to something that's NOT a video (webpage, image,
  // preview card, or the probe failed and the resolver returned
  // `type: "unknown"`). Reject.
  return {
    ok: false,
    error: "Invalid video link. Use a YouTube/Vimeo/TikTok link or a direct video URL.",
    kind: "disallowed",
  };
}

/**
 * Convenience wrapper: returns true when the URL passes the shared
 * validation.
 */
export async function isValidVideoSource(url: string | null | undefined): Promise<boolean> {
  const result = await validateVideoSource(url);
  return result.ok;
}

// Re-export for callers that need to detect the platform without
// validating (e.g. for UI hints).
export type { MediaProvider };
