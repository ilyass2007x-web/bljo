/**
 * Shared image-source validation (Phase 18 follow-up).
 *
 * ONE shared validation function used by BOTH:
 *   - Article cover image URLs (POST/PATCH /api/v1/articles)
 *   - Profile avatar URLs (PATCH /api/v1/profile)
 *
 * Accepts ONLY two kinds of image sources:
 *   A. Pinterest URLs (pinterest.com / pin.it / *.pinterest.com)
 *   B. Direct image URLs — verified by actual HTTP response Content-Type
 *      (image/*), NOT by .jpg/.png extensions.
 *
 * Rejects:
 *   - Google search/image pages
 *   - Instagram pages
 *   - Facebook pages
 *   - TikTok pages
 *   - Random webpages (no Content-Type image/*)
 *   - Broken URLs
 *   - Dangerous schemes (javascript:, data:, vbscript:, file:, blob:, about:)
 *
 * Server-side: this module calls the EXISTING `resolveMedia` from
 * `src/lib/media/resolver.ts` (NOT modified) — it does the SSRF-safe
 * HTTP probe + Content-Type sniffing. We reuse its result + apply the
 * platform allowlist on top.
 *
 * Client-side: a synchronous pre-check `isAllowedImageSourceKind`
 * gives instant feedback for clearly-disallowed platforms (Instagram,
 * Facebook, TikTok, Google search, etc.) before the resolver even
 * runs. The server is the source of truth — the client check is just
 * UX (defense-in-depth).
 *
 * IMPORTANT: this module MUST NOT modify the resolver. It only
 * consumes its output. The resolver stays the single source of truth
 * for "what kind of media is this URL".
 *
 * ── BUNDLE HYGIENE ───────────────────────────────────────────────────────
 * The pure sync helpers (isPinterestUrl, classifyImageSourceKind,
 * getDisallowedReason, providerToKind, ImageSourceKind) live in
 * `./image-source-classify` and are RE-EXPORTED here for backward
 * compatibility with existing server-side imports. Client components
 * MUST import those helpers directly from `./image-source-classify`
 * (NOT from this file) so the bundler does not follow the
 * `resolveMedia` import below into the browser chunk (which would
 * pull `node:dns` + `node:net` from `src/lib/media/resolver.ts`).
 * The SSRF defense in resolver.ts is unchanged.
 */

// Re-export the pure client-safe helpers so existing server-side
// imports of these symbols from `image-source-validation` keep working.
// New client code should import them from `./image-source-classify`.
export {
  isPinterestUrl,
  classifyImageSourceKind,
  getDisallowedReason,
  providerToKind,
  type ImageSourceKind,
} from "./image-source-classify";

import { validateImageUrl } from "@/lib/security/sanitize";
import { resolveMedia } from "@/lib/media/resolver";

// ── Types ────────────────────────────────────────────────────────────────

export interface ImageSourceValidationResult {
  ok: boolean;
  /** The validated URL (trimmed) when ok=true. */
  url?: string;
  /** User-facing error message when ok=false. */
  error?: string;
  /** What kind of source was detected (for UX/debugging). */
  kind?: import("./image-source-classify").ImageSourceKind;
}

// ── Shared async validator (server-side source of truth) ────────────────

/**
 * Validate an image URL for persistence. This is the SHARED function
 * used by both Article cover image and Profile avatar routes.
 *
 * Algorithm:
 *   1. `validateImageUrl` — scheme + length + character sanity (existing).
 *   2. `classifyImageSourceKind` — reject disallowed platforms immediately.
 *   3. `resolveMedia` — SSRF-safe HTTP probe + Content-Type sniffing (existing).
 *      The URL is accepted ONLY when the resolver returns `type === "image"`
 *      (the probe verified the actual response Content-Type starts with
 *      `image/`). This catches direct image URLs without extensions (e.g.
 *      `https://example.com/photo?id=42` that returns `image/jpeg`).
 *
 * Pinterest URLs are accepted if EITHER:
 *   - the resolver returns `type === "image"` (the pin's image was extracted), OR
 *   - the resolver returns a non-image type (preview/embed) — we still accept
 *     the Pinterest URL itself because Pinterest pins reliably have images,
 *     and the resolver's classification of Pinterest pages can vary. The
 *     user's intent is clear: they pasted a Pinterest link. We trust it.
 *     (This matches the spec's "Pinterest image → ACCEPT" rule.)
 *
 * Returns `{ ok: true, url }` when valid, or `{ ok: false, error }` with
 * a user-facing message.
 */
export async function validateImageSource(
  url: string | null | undefined
): Promise<ImageSourceValidationResult> {
  // Local import of the pure classifier — keeps the SSRF chain explicit
  // (the resolver import is what makes this module server-only).
  const { classifyImageSourceKind } = await import("./image-source-classify");

  // Step 1: scheme + length + character sanity.
  const safe = validateImageUrl(url);
  if (!safe) {
    return {
      ok: false,
      error: "Invalid image link. Use a Pinterest link or a direct image URL.",
      kind: "disallowed",
    };
  }

  // Step 2: synchronous platform classification.
  const kind = classifyImageSourceKind(safe);
  if (kind === "disallowed") {
    return {
      ok: false,
      error: "Invalid image link. Use a Pinterest link or a direct image URL.",
      kind: "disallowed",
    };
  }

  // Step 3: SSRF-safe HTTP probe via the EXISTING resolver.
  // We do NOT modify the resolver — we only consume its output.
  let resolved;
  try {
    resolved = await resolveMedia(safe);
  } catch {
    // Network error / resolver crash → reject. The user can try again.
    return {
      ok: false,
      error: "Invalid image link. Use a Pinterest link or a direct image URL.",
      kind: "disallowed",
    };
  }

  // Pinterest URLs: accept if the resolver returned a usable image URL
  // (the pin's image was extracted) OR if the URL was classified as
  // Pinterest but the resolver couldn't probe (rare — pin.it redirects).
  // We trust the user's intent: they pasted a Pinterest link.
  if (kind === "pinterest") {
    if (resolved.type === "image" && resolved.mediaUrl) {
      return { ok: true, url: safe, kind: "pinterest" };
    }
    // Pinterest URL but the resolver couldn't extract an image. This is
    // rare (Pinterest pages reliably have og:image). We accept the
    // original URL — the published image may still load in the browser
    // via the renderer's fallback path. This matches the spec's "Pinterest
    // image → ACCEPT" rule.
    return { ok: true, url: safe, kind: "pinterest" };
  }

  // Direct image URL: the resolver MUST have confirmed `type === "image"`
  // via Content-Type sniffing. No extension guessing — only the actual
  // HTTP response Content-Type decides.
  if (resolved.type === "image" && resolved.mediaUrl) {
    return { ok: true, url: safe, kind: "direct-image" };
  }

  // The URL resolved to something that's NOT an image (webpage, embed,
  // video, preview card, or the probe failed and the resolver returned
  // `type: "unknown"`). Reject.
  return {
    ok: false,
    error: "Invalid image link. Use a Pinterest link or a direct image URL.",
    kind: "disallowed",
  };
}

/**
 * Convenience wrapper: returns true when the URL passes the shared
 * validation. Used in places where the caller only needs a boolean.
 */
export async function isValidImageSource(url: string | null | undefined): Promise<boolean> {
  const result = await validateImageSource(url);
  return result.ok;
}
