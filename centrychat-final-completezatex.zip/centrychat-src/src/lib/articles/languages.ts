/**
 * Supported Translation Languages
 * ================================
 *
 * The full list of languages the article translation feature supports.
 *
 * Each entry maps a 2-letter ISO 639-1 code to:
 *   - nativeName: the language's name IN ITSELF (shown in the language
 *     selector — e.g. "العربية" for Arabic, "日本語" for Japanese).
 *   - englishName: the language's name in English (used for the search
 *     filter — e.g. searching "Arabic" finds "العربية").
 *   - dir: text direction — "rtl" for Arabic/Hebrew/Persian/Urdu,
 *     "ltr" for everything else.
 *
 * WHY HARDCODED (not fetched from the LLM API at runtime):
 *   - The LLM (z-ai-web-dev-sdk) supports ALL these languages but does NOT
 *     expose a "list supported languages" API endpoint. We maintain this
 *     list manually — it matches the languages GLM-4.6 is known to handle
 *     well (high-quality translation).
 *   - The list is CONSERVATIVE — only languages with strong LLM support
 *     are included. Adding a language requires a code change (deliberate —
 *     we want to verify translation quality before exposing it).
 *
 * SEARCH (spec §2):
 *   The client LanguageSelector filters this list by BOTH nativeName AND
 *   englishName. So a user typing "arabic" OR "العربية" finds the Arabic
 *     entry.
 *
 * RTL DETECTION (spec §7):
 *   The `dir` field drives the article content's `dir` attribute when a
 *   translation is selected. The UI chrome (header, action bar) stays in
 *   the user's UI language — only the article body flips to RTL/LTR.
 */

export interface TranslationLanguage {
  /** 2-letter ISO 639-1 code (e.g. "ar", "fr", "es", "zh"). */
  code: string;
  /** Native name — shown in the language selector (e.g. "العربية", "日本語"). */
  nativeName: string;
  /** English name — used by the search filter (e.g. "Arabic", "Japanese"). */
  englishName: string;
  /** Text direction — "rtl" for Arabic/Hebrew/Persian/Urdu, "ltr" otherwise. */
  dir: "ltr" | "rtl";
}

/**
 * The registry of supported translation languages.
 *
 * Adding a new language = add ONE entry here. No other code changes required.
 * The LanguageSelector component, the API endpoint, and the cache all use
 * this list as the source of truth.
 *
 * Order: roughly by expected usage frequency (English first, then major
 * world languages, then regional ones).
 */
export const SUPPORTED_TRANSLATION_LANGUAGES: TranslationLanguage[] = [
  { code: "en", nativeName: "English", englishName: "English", dir: "ltr" },
  { code: "ar", nativeName: "العربية", englishName: "Arabic", dir: "rtl" },
  { code: "fr", nativeName: "Français", englishName: "French", dir: "ltr" },
  { code: "es", nativeName: "Español", englishName: "Spanish", dir: "ltr" },
  { code: "de", nativeName: "Deutsch", englishName: "German", dir: "ltr" },
  { code: "pt", nativeName: "Português", englishName: "Portuguese", dir: "ltr" },
  { code: "it", nativeName: "Italiano", englishName: "Italian", dir: "ltr" },
  { code: "ru", nativeName: "Русский", englishName: "Russian", dir: "ltr" },
  { code: "zh", nativeName: "中文", englishName: "Chinese", dir: "ltr" },
  { code: "ja", nativeName: "日本語", englishName: "Japanese", dir: "ltr" },
  { code: "ko", nativeName: "한국어", englishName: "Korean", dir: "ltr" },
  { code: "tr", nativeName: "Türkçe", englishName: "Turkish", dir: "ltr" },
  { code: "hi", nativeName: "हिन्दी", englishName: "Hindi", dir: "ltr" },
  { code: "fa", nativeName: "فارسی", englishName: "Persian", dir: "rtl" },
  { code: "ur", nativeName: "اردو", englishName: "Urdu", dir: "rtl" },
  { code: "he", nativeName: "עברית", englishName: "Hebrew", dir: "rtl" },
  { code: "nl", nativeName: "Nederlands", englishName: "Dutch", dir: "ltr" },
  { code: "pl", nativeName: "Polski", englishName: "Polish", dir: "ltr" },
  { code: "sv", nativeName: "Svenska", englishName: "Swedish", dir: "ltr" },
  { code: "id", nativeName: "Bahasa Indonesia", englishName: "Indonesian", dir: "ltr" },
  { code: "ms", nativeName: "Bahasa Melayu", englishName: "Malay", dir: "ltr" },
  { code: "th", nativeName: "ไทย", englishName: "Thai", dir: "ltr" },
  { code: "vi", nativeName: "Tiếng Việt", englishName: "Vietnamese", dir: "ltr" },
  { code: "uk", nativeName: "Українська", englishName: "Ukrainian", dir: "ltr" },
  { code: "el", nativeName: "Ελληνικά", englishName: "Greek", dir: "ltr" },
  { code: "cs", nativeName: "Čeština", englishName: "Czech", dir: "ltr" },
  { code: "ro", nativeName: "Română", englishName: "Romanian", dir: "ltr" },
  { code: "hu", nativeName: "Magyar", englishName: "Hungarian", dir: "ltr" },
  { code: "da", nativeName: "Dansk", englishName: "Danish", dir: "ltr" },
  { code: "fi", nativeName: "Suomi", englishName: "Finnish", dir: "ltr" },
  { code: "no", nativeName: "Norsk", englishName: "Norwegian", dir: "ltr" },
  { code: "bn", nativeName: "বাংলা", englishName: "Bengali", dir: "ltr" },
  { code: "ta", nativeName: "தமிழ்", englishName: "Tamil", dir: "ltr" },
  { code: "te", nativeName: "తెలుగు", englishName: "Telugu", dir: "ltr" },
  { code: "ml", nativeName: "മലയാളം", englishName: "Malayalam", dir: "ltr" },
  { code: "sw", nativeName: "Kiswahili", englishName: "Swahili", dir: "ltr" },
];

/**
 * Lookup map for O(1) validation + dir lookup.
 * Keyed by the 2-letter code.
 */
const LANGUAGE_BY_CODE: Map<string, TranslationLanguage> = new Map(
  SUPPORTED_TRANSLATION_LANGUAGES.map((l) => [l.code, l])
);

/**
 * Validate that a language code is in the supported list.
 * Used by the API endpoint to reject invalid language requests.
 */
export function isValidTranslationLanguage(code: string): boolean {
  return LANGUAGE_BY_CODE.has(code);
}

/**
 * Get a language's configuration (nativeName, dir, etc.) by code.
 * Returns undefined for unsupported codes.
 */
export function getTranslationLanguage(code: string): TranslationLanguage | undefined {
  return LANGUAGE_BY_CODE.get(code);
}

/**
 * Get the text direction for a language code.
 * Returns "ltr" for unknown codes (defensive — never throws).
 *
 * Used by the article reading page to set the `dir` attribute on the
 * translated content container (spec §7 — RTL/LTR system).
 */
export function getTranslationDir(code: string): "ltr" | "rtl" {
  return LANGUAGE_BY_CODE.get(code)?.dir ?? "ltr";
}
