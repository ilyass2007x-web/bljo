/**
 * Article Translation Service
 * ============================
 *
 * Server-side translation of article title + description + content.
 *
 * ARCHITECTURE:
 *   1. Try the SDK first (z.ai sandbox — reads /etc/.z-ai-config automatically).
 *   2. If SDK fails (no config file — Netlify production), try direct fetch()
 *      using ZAI_API_KEY + ZAI_BASE_URL + ZAI_TOKEN env vars.
 *   3. If both fail, throw TranslationError with a clean message.
 *
 * RESILIENCE:
 *   - DB cache operations (lookup/store) are wrapped in try/catch.
 *   - If the DB is unavailable (table missing, connection error), the
 *     translation STILL WORKS — it just doesn't get cached. The user
 *     gets a real translation, not an error.
 *   - The `hasArticleContentChanged` defensive check is also resilient —
 *     if it fails, we skip it and proceed with the translation.
 *
 * SECURITY:
 *   - All env vars are SERVER-ONLY (no NEXT_PUBLIC_ prefix).
 *   - The SDK is dynamically imported (not bundled into client).
 *   - Translated content is sanitized via stripControlChars.
 *   - LLM API keys/tokens NEVER exposed to the client.
 *
 * CHUNKING:
 *   For articles >4000 chars, content is split at paragraph boundaries.
 *   Each chunk is translated separately, then joined.
 */

import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { stripControlChars } from "@/lib/seo/article";
import {
  isValidTranslationLanguage,
  getTranslationLanguage,
} from "./languages";
import { createHash } from "node:crypto";

// ── Types ────────────────────────────────────────────────────────────────

export interface ArticleToTranslate {
  id: string;
  title: string;
  content: string;
  excerpt: string | null;
}

export interface TranslationResult {
  articleId: string;
  languageCode: string;
  translatedTitle: string;
  translatedDescription: string | null;
  translatedContent: string;
  languageNativeName: string;
  dir: "ltr" | "rtl";
  fromCache: boolean;
}

export class TranslationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "TranslationError";
  }
}

// ── Hashing ──────────────────────────────────────────────────────────────

export function computeSourceContentHash(article: ArticleToTranslate): string {
  const input = `${article.title}\n\n${article.excerpt ?? ""}\n\n${article.content}`;
  return createHash("sha256").update(input, "utf-8").digest("hex");
}

// ── System Prompt ─────────────────────────────────────────────────────────

const TRANSLATION_SYSTEM_PROMPT = `You are a professional translator. Translate the user's text into the target language.

CRITICAL RULES (follow exactly):
1. Translate ONLY natural-language text (sentences, paragraphs, headings).
2. PRESERVE all Markdown and HTML structure EXACTLY as-is:
   - Headings (#, ##, ###)
   - Lists (-, *, 1.)
   - Bold (**text**), Italic (*text*)
   - Blockquotes (>)
   - Horizontal rules (---)
   - Code blocks (\`\`\`)
   - Inline code (\`code\`)
3. NEVER translate or modify URLs:
   - Image URLs: ![alt](https://example.com/image.jpg)
   - Link URLs: [text](https://example.com)
   - Video URLs, embed URLs
4. NEVER translate:
   - Code blocks (between \`\`\`)
   - HTML tags
   - Usernames (e.g. @username)
   - Hashtags (e.g. #topic)
   - Email addresses
   - Article IDs
5. Keep the SAME paragraph breaks and line breaks.
6. Keep the SAME punctuation structure (don't add/remove periods).
7. If a word is a proper noun (brand name, person name, place), keep it in the original language if it's commonly untranslated.
8. Do NOT add any commentary, explanation, or notes — output ONLY the translated text.
9. Do NOT wrap the output in quotes or code blocks — output raw translated text.

Output: ONLY the translated text, nothing else.`;

// ── LLM Call ─────────────────────────────────────────────────────────────

/**
 * Call the LLM to translate a single text chunk.
 *
 * Strategy:
 *   1. Try the SDK first (z.ai sandbox — /etc/.z-ai-config exists).
 *      The SDK handles ALL auth headers automatically (Authorization,
 *      X-Token, X-Chat-Id, X-User-Id, X-Z-AI-From).
 *   2. If SDK fails (no config file — Netlify), try direct fetch()
 *      with env vars: ZAI_API_KEY + ZAI_BASE_URL + ZAI_TOKEN.
 *      The direct fetch includes ALL the same headers the SDK sends.
 *   3. If both fail, throw TranslationError.
 */
async function callLLMTranslate(
  text: string,
  targetLanguageName: string
): Promise<string> {
  const userPrompt = `Translate the following text into ${targetLanguageName}. Output ONLY the translation, nothing else.

TEXT TO TRANSLATE:
${text}`;

  const messages = [
    { role: "assistant" as const, content: TRANSLATION_SYSTEM_PROMPT },
    { role: "user" as const, content: userPrompt },
  ];
  const requestBody = { messages, thinking: { type: "disabled" as const } };

  // ── Strategy 1: Try the SDK (z.ai sandbox) ──────────────────────────
  // The SDK reads /etc/.z-ai-config automatically and sends ALL required
  // headers (Authorization, X-Token, X-Chat-Id, X-User-Id, X-Z-AI-From).
  // In the z.ai sandbox, this is the PRIMARY path.
  try {
    const ZAIModule = await import("z-ai-web-dev-sdk");
    const ZAI = (ZAIModule as { default: { create: () => Promise<unknown> } }).default;
    const zai = (await ZAI.create()) as {
      chat: { completions: { create: (opts: unknown) => Promise<unknown> } };
    };

    const completion = (await zai.chat.completions.create(requestBody)) as {
      choices?: Array<{ message?: { content?: string } }>;
    };

    const content = completion.choices?.[0]?.message?.content;
    if (content && typeof content === "string" && content.trim().length > 0) {
      return content.trim();
    }
    // SDK returned empty → fall through to direct fetch.
    logger.warn("application", "SDK returned empty response, trying direct fetch");
  } catch (sdkErr) {
    // SDK failed (likely no .z-ai-config on Netlify). Log + fall through
    // to the direct fetch path.
    logger.info("application", "SDK unavailable, trying direct fetch", {
      error: sdkErr instanceof Error ? sdkErr.message : String(sdkErr),
    });
  }

  // ── Strategy 2: Direct fetch with env vars (Netlify production) ─────
  // The SDK sends these headers:
  //   - Content-Type: application/json
  //   - Authorization: Bearer ${apiKey}
  //   - X-Z-AI-From: Z
  //   - X-Chat-Id: ${chatId}     (optional)
  //   - X-User-Id: ${userId}     (optional)
  //   - X-Token: ${token}         (required for auth!)
  //
  // We replicate ALL of them. The X-Token header is CRITICAL — without it,
  // the API returns 401 "missing X-Token header".
  const envApiKey = process.env.ZAI_API_KEY;
  const envBaseUrl = process.env.ZAI_BASE_URL;
  const envToken = process.env.ZAI_TOKEN;

  if (!envApiKey || !envBaseUrl) {
    throw new TranslationError(
      "Translation service is not configured. Set ZAI_API_KEY, ZAI_BASE_URL, and ZAI_TOKEN environment variables."
    );
  }

  try {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${envApiKey}`,
      "X-Z-AI-From": "Z",
    };
    // X-Token is REQUIRED — the API returns 401 without it.
    if (envToken) {
      headers["X-Token"] = envToken;
    }

    const response = await fetch(`${envBaseUrl}/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      const errorBody = await response.text().catch(() => "unknown");
      logger.error("application", "Translation API HTTP error", {
        status: response.status,
        body: errorBody.slice(0, 500),
      });
      throw new TranslationError(
        `Translation API returned HTTP ${response.status}`
      );
    }

    const completion = (await response.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };

    const content = completion.choices?.[0]?.message?.content;
    if (!content || typeof content !== "string" || content.trim().length === 0) {
      throw new TranslationError("Translation API returned an empty response.");
    }

    return content.trim();
  } catch (err) {
    if (err instanceof TranslationError) throw err;
    throw new TranslationError(
      `Translation API call failed: ${err instanceof Error ? err.message : "unknown error"}`
    );
  }
}

// ── Chunking ─────────────────────────────────────────────────────────────

const MAX_CHUNK_CHARS = 4000;

function chunkArticleContent(content: string): string[] {
  if (content.length <= MAX_CHUNK_CHARS) {
    return [content];
  }

  const paragraphs = content.split(/\n\n+/);
  const chunks: string[] = [];
  let current = "";

  for (const para of paragraphs) {
    if ((current + "\n\n" + para).length > MAX_CHUNK_CHARS) {
      if (current) {
        chunks.push(current);
        current = "";
      }
      if (para.length > MAX_CHUNK_CHARS) {
        for (let i = 0; i < para.length; i += MAX_CHUNK_CHARS) {
          chunks.push(para.slice(i, i + MAX_CHUNK_CHARS));
        }
      } else {
        current = para;
      }
    } else {
      current = current ? `${current}\n\n${para}` : para;
    }
  }
  if (current) chunks.push(current);

  return chunks;
}

// ── Main translation function ────────────────────────────────────────────

export async function translateArticle(
  article: ArticleToTranslate,
  languageCode: string
): Promise<TranslationResult> {
  // ── 1. Validate language code ────────────────────────────────────────
  if (!isValidTranslationLanguage(languageCode)) {
    throw new TranslationError(`Unsupported language code: ${languageCode}`);
  }
  const langConfig = getTranslationLanguage(languageCode)!;

  // ── 2. Compute source hash ────────────────────────────────────────────
  const sourceHash = computeSourceContentHash(article);

  // ── 3. Look up existing translation (RESILIENT — skip on DB failure) ─
  // If the DB is unavailable (table missing, connection error), we skip
  // the cache lookup and proceed directly to the LLM call. The translation
  // still works — it just doesn't get cached.
  let existing: { id: string; sourceContentHash: string; translatedTitle: string; translatedDescription: string | null; translatedContent: string } | null = null;
  try {
    existing = await db.articleTranslation.findUnique({
      where: {
        articleId_languageCode: {
          articleId: article.id,
          languageCode,
        },
      },
      select: {
        id: true,
        sourceContentHash: true,
        translatedTitle: true,
        translatedDescription: true,
        translatedContent: true,
      },
    });
  } catch (dbErr) {
    // DB lookup failed — log + continue without cache.
    logger.warn("application", "Translation cache lookup failed (non-blocking)", {
      articleId: article.id,
      languageCode,
      error: dbErr instanceof Error ? dbErr.message : String(dbErr),
    });
  }

  // ── 4. Cache hit + hash matches → return cached ──────────────────────
  if (existing && existing.sourceContentHash === sourceHash) {
    return {
      articleId: article.id,
      languageCode,
      translatedTitle: existing.translatedTitle,
      translatedDescription: existing.translatedDescription,
      translatedContent: existing.translatedContent,
      languageNativeName: langConfig.nativeName,
      dir: langConfig.dir,
      fromCache: true,
    };
  }

  // ── 5. Stale cache (hash differs) → delete + regenerate ──────────────
  if (existing && existing.sourceContentHash !== sourceHash) {
    try {
      await db.articleTranslation.delete({ where: { id: existing.id } });
    } catch {
      // Non-blocking — the upsert below will handle it.
    }
  }

  // ── 6. Call the LLM ──────────────────────────────────────────────────
  let translatedTitle: string;
  let translatedDescription: string | null = null;
  let translatedContent: string;

  // Title — single call (always short).
  translatedTitle = await callLLMTranslate(article.title, langConfig.englishName);

  // Description — single call if present.
  if (article.excerpt && article.excerpt.trim().length > 0) {
    translatedDescription = await callLLMTranslate(
      article.excerpt,
      langConfig.englishName
    );
  }

  // Content — chunked for long articles.
  const chunks = chunkArticleContent(article.content);
  const translatedChunks: string[] = [];
  for (const chunk of chunks) {
    const translated = await callLLMTranslate(chunk, langConfig.englishName);
    translatedChunks.push(translated);
  }
  translatedContent = translatedChunks.join("\n\n");

  // ── Sanitize the output ─────────────────────────────────────────────
  translatedTitle = stripControlChars(translatedTitle);
  if (translatedDescription) {
    translatedDescription = stripControlChars(translatedDescription);
  }
  translatedContent = stripControlChars(translatedContent);

  // ── 7. Store the translation (RESILIENT — skip on DB failure) ───────
  // If the DB is unavailable, we still return the translation — we just
  // don't cache it. The next request will re-translate (no cache hit).
  try {
    await db.articleTranslation.upsert({
      where: {
        articleId_languageCode: {
          articleId: article.id,
          languageCode,
        },
      },
      create: {
        articleId: article.id,
        languageCode,
        translatedTitle,
        translatedDescription,
        translatedContent,
        sourceContentHash: sourceHash,
        model: "z-ai-glm-4.6",
      },
      update: {
        translatedTitle,
        translatedDescription,
        translatedContent,
        sourceContentHash: sourceHash,
        model: "z-ai-glm-4.6",
      },
    });
  } catch (dbErr) {
    // DB storage failed — log + continue. The translation is still valid,
    // it just won't be cached for next time.
    logger.warn("application", "Translation cache store failed (non-blocking)", {
      articleId: article.id,
      languageCode,
      error: dbErr instanceof Error ? dbErr.message : String(dbErr),
    });
  }

  return {
    articleId: article.id,
    languageCode,
    translatedTitle,
    translatedDescription,
    translatedContent,
    languageNativeName: langConfig.nativeName,
    dir: langConfig.dir,
    fromCache: false,
  };
}

// ── Invalidation helpers (RESILIENT) ─────────────────────────────────────

export async function invalidateTranslationsForArticle(
  articleId: string
): Promise<void> {
  try {
    await db.articleTranslation.deleteMany({
      where: { articleId },
    });
  } catch (err) {
    // Non-fatal — translation cleanup must NOT break the article edit/delete.
    logger.error("application", "Failed to invalidate translations", {
      articleId,
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

export async function hasArticleContentChanged(
  articleId: string,
  currentArticle: ArticleToTranslate
): Promise<boolean> {
  try {
    const currentHash = computeSourceContentHash(currentArticle);
    const translations = await db.articleTranslation.findMany({
      where: { articleId },
      select: { sourceContentHash: true },
      take: 1,
    });
    if (translations.length === 0) return false;
    return translations[0].sourceContentHash !== currentHash;
  } catch {
    // DB check failed — assume no change (proceed with translation).
    return false;
  }
}
