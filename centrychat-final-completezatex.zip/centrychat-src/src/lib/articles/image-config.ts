/**
 * Article image presentation configuration (Phase 18).
 *
 * The article cover image has THREE visual knobs the author can adjust
 * during article creation:
 *
 *   - imageZoom       (1.0 = 100%, 3.0 = 300%)
 *   - imagePositionX   (-1.0 = full left, 0 = center, 1.0 = full right)
 *   - imagePositionY   (-1.0 = full up, 0 = center, 1.0 = full down)
 *
 * `imagePositionX/Y` are stored as FRACTIONS of the container's
 * width/height (not pixels) so the same configuration renders
 * consistently across mobile, tablet, and desktop viewports — the
 * editor UI measures the container's pixel dimensions at drag time
 * and converts to fractions before persisting.
 *
 * The renderer (ArticleImageFrame) applies these via CSS transform:
 *   transform: translate(Xpx, Ypx) scale(zoom)
 *   transform-origin: center center
 *
 * Backward compatibility: NULL fields are treated as the natural
 * default (zoom=1, center). Old articles continue to render exactly
 * as before — no migration script is required.
 */

export interface ArticleImageConfig {
  zoom: number;
  positionX: number;
  positionY: number;
}

/** Natural defaults — used when an article has NULL image config. */
export const DEFAULT_IMAGE_CONFIG: ArticleImageConfig = {
  zoom: 1,
  positionX: 0,
  positionY: 0,
};

// ── Validation bounds (enforced server-side in /api/v1/articles/*) ────────

export const IMAGE_ZOOM_MIN = 1.0;
export const IMAGE_ZOOM_MAX = 3.0;
export const IMAGE_ZOOM_STEP = 0.05;

export const IMAGE_POSITION_MIN = -1.0;
export const IMAGE_POSITION_MAX = 1.0;

/**
 * Normalize a raw (possibly null / out-of-range) config into a safe
 * ArticleImageConfig. Used by both the renderer (client-side) and the
 * API serializer (server-side) so the two never drift.
 *
 * - null/undefined on all three fields → DEFAULT_IMAGE_CONFIG
 * - out-of-range values are clamped to the valid range
 * - NaN / non-finite values fall back to the default for that field
 */
export function normalizeImageConfig(opts: {
  zoom?: number | null;
  positionX?: number | null;
  positionY?: number | null;
}): ArticleImageConfig {
  const safe = (
    v: number | null | undefined,
    min: number,
    max: number,
    fallback: number
  ): number => {
    if (v === null || v === undefined) return fallback;
    const n = typeof v === "number" ? v : Number(v);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, n));
  };

  return {
    zoom: safe(opts.zoom, IMAGE_ZOOM_MIN, IMAGE_ZOOM_MAX, DEFAULT_IMAGE_CONFIG.zoom),
    positionX: safe(
      opts.positionX,
      IMAGE_POSITION_MIN,
      IMAGE_POSITION_MAX,
      DEFAULT_IMAGE_CONFIG.positionX
    ),
    positionY: safe(
      opts.positionY,
      IMAGE_POSITION_MIN,
      IMAGE_POSITION_MAX,
      DEFAULT_IMAGE_CONFIG.positionY
    ),
  };
}

/**
 * Returns true when the config is effectively the default (no transform
 * needed). Lets the renderer skip the transform entirely — keeping the
 * HTML output minimal for the common case.
 */
export function isDefaultConfig(c: ArticleImageConfig): boolean {
  return c.zoom === 1 && c.positionX === 0 && c.positionY === 0;
}

/**
 * Build the CSS `transform` string for the image element.
 *
 * The position fractions are converted to pixel offsets via the
 * container's pixel dimensions (passed in). The transform is then:
 *
 *   translate(Xpx, Ypx) scale(zoom)
 *
 * with transform-origin: center center so the zoom anchors on the
 * center of the image (matching the editor's drag behavior).
 *
 * NOTE: callers MUST apply `overflow: hidden` + a controlled aspect
 * ratio on the container — the transform itself never creates
 * scrolling, but the container must clip the overflow so zoomed-in
 * portions of the image are hidden instead of producing scrollbars.
 */
export function buildImageTransform(
  c: ArticleImageConfig,
  containerPx: { width: number; height: number }
): string {
  const x = c.positionX * containerPx.width;
  const y = c.positionY * containerPx.height;
  return `translate(${x}px, ${y}px) scale(${c.zoom})`;
}

/**
 * Validate a candidate config (server-side). Returns the sanitized
 * config or throws a descriptive error if any value is wildly out of
 * range (e.g. zoom = 100 — clearly a bug, not user intent).
 *
 * Used by POST /api/v1/articles + PATCH /api/v1/articles/:id.
 */
export function validateImageConfigField(
  field: "imageZoom" | "imagePositionX" | "imagePositionY",
  value: unknown
): number | null {
  if (value === null || value === undefined) return null;

  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) {
    throw new Error(`Invalid ${field}: not a finite number`);
  }

  switch (field) {
    case "imageZoom":
      if (n < IMAGE_ZOOM_MIN || n > IMAGE_ZOOM_MAX) {
        throw new Error(`imageZoom must be between ${IMAGE_ZOOM_MIN} and ${IMAGE_ZOOM_MAX}`);
      }
      return Math.round(n / IMAGE_ZOOM_STEP) * IMAGE_ZOOM_STEP; // snap to step
    case "imagePositionX":
    case "imagePositionY":
      if (n < IMAGE_POSITION_MIN || n > IMAGE_POSITION_MAX) {
        throw new Error(`${field} must be between ${IMAGE_POSITION_MIN} and ${IMAGE_POSITION_MAX}`);
      }
      return Math.round(n * 100) / 100; // 2 decimal places
    default:
      return null;
  }
}
