/**
 * Tutorial Videos — SHARED (client-safe) constants, types, and helpers.
 * =====================================================================
 *
 * This module contains ONLY pure code (no DB imports, no server-only
 * imports). It is safe to import from BOTH server and client components.
 *
 * Why this file exists:
 *   The full `@/lib/tutorial-videos/index.ts` imports `db` from
 *   `@/lib/database`, which imports `PrismaClient` from `@prisma/client`.
 *   When a Client Component imports runtime values (constants,
 *   functions) from `@/lib/tutorial-videos`, webpack bundles the
 *   whole module — including `db` — into the browser chunk. The
 *   Prisma client then throws "PrismaClient is unable to run in this
 *   browser environment" at runtime, which propagates up to the
 *   global-error.tsx boundary and shows the "Something went wrong"
 *   page to every visitor.
 *
 *   Splitting the pure parts into this shared file lets client
 *   components import the constants + helpers they need WITHOUT
 *   pulling Prisma into the browser bundle.
 *
 *   Server-side code (API routes) continues to import from
 *   `@/lib/tutorial-videos` which re-exports everything below +
 *   adds the DB-backed functions.
 */

import { parseYouTube } from "@/lib/media/embeds";

// ── Types ────────────────────────────────────────────────────────────────

/** A tutorial location — each is independent (spec §9). */
export type TutorialLocation =
  | "PROFILE_IMAGE_TUTORIAL"
  | "ARTICLE_IMAGE_TUTORIAL"
  | "ARTICLE_VIDEO_TUTORIAL";

/**
 * The full list of supported tutorial locations. To add a new one,
 * append it here — the API + admin UI + public fetch all pick it up
 * automatically (spec §10 — future-ready, no architecture rebuild).
 */
export const TUTORIAL_LOCATIONS: readonly TutorialLocation[] = [
  "PROFILE_IMAGE_TUTORIAL",
  "ARTICLE_IMAGE_TUTORIAL",
  "ARTICLE_VIDEO_TUTORIAL",
] as const;

/** Human-readable labels + per-location UX hints. */
export const TUTORIAL_LOCATION_META: Record<
  TutorialLocation,
  { label: string; description: string; cardTitle: string }
> = {
  PROFILE_IMAGE_TUTORIAL: {
    label: "Profile Image Tutorial",
    description: "YouTube tutorial shown near the profile image URL input.",
    cardTitle: "How to add a profile image?",
  },
  ARTICLE_IMAGE_TUTORIAL: {
    label: "Article Image Tutorial",
    description: "YouTube tutorial shown near the article cover image URL input.",
    cardTitle: "How to add an article image?",
  },
  ARTICLE_VIDEO_TUTORIAL: {
    label: "Article Video Tutorial",
    description:
      "YouTube tutorial shown near the article Video URL input. Explains how to copy a YouTube link and paste it into the editor.",
    cardTitle: "How to add a YouTube video?",
  },
};

/** Stored shape (JSON-encoded in PlatformSetting.value). */
export interface TutorialVideoRecord {
  youtubeUrl: string;
  enabled: boolean;
  /** The 11-char YouTube video ID (derived from youtubeUrl). */
  videoId: string;
  /** ISO timestamp of the last admin update. */
  updatedAt?: string;
}

/** Public-facing shape (returned by the public GET endpoint). */
export interface TutorialVideo {
  location: TutorialLocation;
  youtubeUrl: string;
  embedUrl: string;
  thumbnailUrl: string;
  enabled: boolean;
}

// ── Helpers (pure — no DB) ───────────────────────────────────────────────

/** Validate a YouTube URL. Returns the parsed info or null. */
export function validateYouTubeUrl(url: string): {
  videoId: string;
  embedUrl: string;
  thumbnailUrl: string;
} | null {
  const trimmed = (url ?? "").trim();
  if (!trimmed) return null;
  // Reuse the existing platform parser — NOT modified. It accepts
  // youtu.be/ID, youtube.com/watch?v=ID, /embed/ID, /shorts/ID.
  return parseYouTube(trimmed);
}

/**
 * Parse a YouTube URL on the client (for live preview in the admin UI).
 * Re-exports `validateYouTubeUrl` for convenience.
 */
export { validateYouTubeUrl as parseYouTubeUrl };
