/**
 * Tutorial Videos — Admin-controlled YouTube tutorials per location.
 *
 * Each "location" (e.g. PROFILE_IMAGE_TUTORIAL, ARTICLE_IMAGE_TUTORIAL)
 * has its OWN independent YouTube URL + enabled flag. Admins configure
 * them via /api/v1/admin/tutorial-videos; users fetch them via
 * /api/v1/settings/public/tutorial-videos?location=...
 *
 * STORAGE: reuses the existing `PlatformSetting` table. Each tutorial
 * is stored as ONE row keyed `tutorial.<LOCATION>`. The row's `value`
 * field is a JSON string: `{ "youtubeUrl": string, "enabled": boolean }`.
 * The `type` is "json" + the `description` is human-readable. No new
 * database migration needed — `PlatformSetting` is already in the
 * schema (model has been there since Phase 1).
 *
 * REUSABLE LOCATION/KEY SYSTEM (spec §10): adding a new tutorial
 * location is a 1-line change — add the location key to the
 * `TUTORIAL_LOCATIONS` array below. The API + UI automatically
 * support it. No architecture changes required.
 *
 * SECURITY:
 *   - Admin routes use `requireAdmin()` (server-enforced).
 *   - YouTube URLs are validated via the existing `parseYouTube`
 *     helper (from src/lib/media/embeds.ts — NOT modified). Only
 *     valid YouTube URLs are accepted. No URL is ever executed as JS.
 *   - The thumbnail URL is derived from the video ID — admins don't
 *     enter a thumbnail URL (spec §4: "Do NOT add Thumbnail URL input").
 *   - Users can ONLY view; only admins can add/edit/enable/disable.
 *
 * ── MODULE LAYOUT ──────────────────────────────────────────────────────
 *
 * This module is the SERVER-SIDE entry point. It re-exports the
 * client-safe constants, types, and helpers from `./shared` (so
 * server-side callers can keep importing everything from
 * `@/lib/tutorial-videos`) and adds the DB-backed read/write functions.
 *
 * IMPORTANT: Client Components MUST import from `@/lib/tutorial-videos/shared`
 * instead of this file. Importing this file in a Client Component pulls
 * `db` (and therefore PrismaClient) into the browser bundle, which throws
 * "PrismaClient is unable to run in this browser environment" and triggers
 * the global-error.tsx boundary ("Something went wrong").
 */

// Re-export the client-safe constants, types, and helpers so server-side
// callers can keep importing everything from `@/lib/tutorial-videos`.
export {
  validateYouTubeUrl,
  parseYouTubeUrl,
  TUTORIAL_LOCATIONS,
  TUTORIAL_LOCATION_META,
} from "./shared";
export type {
  TutorialLocation,
  TutorialVideoRecord,
  TutorialVideo,
} from "./shared";

// Import what we need from the shared module + the DB / cache for the
// server-only functions defined below.
import { db } from "@/lib/database";
import { cacheGetOrSet } from "@/lib/cache";
import {
  TUTORIAL_LOCATIONS,
  validateYouTubeUrl,
  TUTORIAL_LOCATION_META,
  type TutorialLocation,
  type TutorialVideoRecord,
  type TutorialVideo,
} from "./shared";

// ── Internal helpers (server-only) ───────────────────────────────────────

function settingKey(location: TutorialLocation): string {
  return `tutorial.${location}`;
}

function isTutorialLocation(x: string): x is TutorialLocation {
  return (TUTORIAL_LOCATIONS as readonly string[]).includes(x);
}

function normalizeRecord(raw: unknown): TutorialVideoRecord | null {
  if (!raw || typeof raw !== "string") return null;
  try {
    const parsed = JSON.parse(raw) as Partial<TutorialVideoRecord>;
    if (typeof parsed.youtubeUrl !== "string") return null;
    if (typeof parsed.enabled !== "boolean") return null;
    if (typeof parsed.videoId !== "string") return null;
    return {
      youtubeUrl: parsed.youtubeUrl,
      enabled: parsed.enabled,
      videoId: parsed.videoId,
      updatedAt: typeof parsed.updatedAt === "string" ? parsed.updatedAt : undefined,
    };
  } catch {
    return null;
  }
}

const CACHE_TTL = 30; // seconds — matches the existing settings cache TTL.

// ── Read API (server-side) ─────────────────────────────────────────────

/**
 * Get a single tutorial video by location. Returns null when no record
 * exists OR when the record exists but is disabled. Uses the existing
 * 30-second cache via `cacheGetOrSet` (same pattern as `getSetting`).
 *
 * Public route uses this; admin route uses `getTutorialVideoRecord`
 * (which returns the disabled state too so admins can see what they
 * configured).
 */
export async function getEnabledTutorialVideo(
  location: TutorialLocation
): Promise<TutorialVideo | null> {
  const rec = await cacheGetOrSet<TutorialVideoRecord | null>(
    `tutorial:${location}`,
    CACHE_TTL,
    async () => {
      const row = await db.platformSetting.findUnique({
        where: { key: settingKey(location) },
      });
      return normalizeRecord(row?.value);
    }
  );

  if (!rec || !rec.enabled) return null;

  // Re-derive embed/thumbnail URLs from the stored videoId. This keeps
  // the stored record small + lets us benefit from any future URL
  // format changes without re-saving rows.
  const parsed = validateYouTubeUrl(rec.youtubeUrl);
  if (!parsed) return null;

  return {
    location,
    youtubeUrl: rec.youtubeUrl,
    embedUrl: parsed.embedUrl,
    thumbnailUrl: parsed.thumbnailUrl,
    enabled: rec.enabled,
  };
}

/**
 * Get the raw record (including disabled state) — used by the admin
 * UI so the admin can see + edit what they configured even when the
 * video is disabled.
 */
export async function getTutorialVideoRecord(
  location: TutorialLocation
): Promise<TutorialVideoRecord | null> {
  const row = await db.platformSetting.findUnique({
    where: { key: settingKey(location) },
  });
  return normalizeRecord(row?.value);
}

/**
 * Get ALL tutorial records (admin view). Always returns every location
 * in TUTORIAL_LOCATIONS — missing ones come back as null.
 */
export async function listTutorialVideoRecords(): Promise<
  Array<{ location: TutorialLocation; record: TutorialVideoRecord | null }>
> {
  const rows = await db.platformSetting.findMany({
    where: {
      key: { in: TUTORIAL_LOCATIONS.map((l) => settingKey(l)) },
    },
  });
  const byLocation = new Map<string, TutorialVideoRecord>();
  for (const row of rows) {
    const rec = normalizeRecord(row.value);
    // Extract location from the key (e.g. "tutorial.PROFILE_IMAGE_TUTORIAL").
    const loc = row.key.replace(/^tutorial\./, "");
    if (rec && isTutorialLocation(loc)) {
      byLocation.set(loc, rec);
    }
  }
  return TUTORIAL_LOCATIONS.map((location) => ({
    location,
    record: byLocation.get(location) ?? null,
  }));
}

// ── Write API (server-side, admin-only) ────────────────────────────────

/**
 * Save a tutorial video for a location. Validates the YouTube URL via
 * the existing `parseYouTube` helper. Throws on invalid input.
 *
 * Returns the saved record (including derived embed/thumbnail URLs).
 */
export async function saveTutorialVideo(
  location: TutorialLocation,
  input: { youtubeUrl: string; enabled: boolean },
  updatedByAdminId: string
): Promise<TutorialVideoRecord> {
  if (!isTutorialLocation(location)) {
    throw new Error(`Unknown tutorial location: ${location}`);
  }
  const parsed = validateYouTubeUrl(input.youtubeUrl);
  if (!parsed) {
    throw new Error(
      "Invalid YouTube URL. Use https://youtube.com/watch?v=… or https://youtu.be/…"
    );
  }

  const record: TutorialVideoRecord = {
    youtubeUrl: input.youtubeUrl.trim(),
    enabled: !!input.enabled,
    videoId: parsed.videoId,
    updatedAt: new Date().toISOString(),
  };

  await db.platformSetting.upsert({
    where: { key: settingKey(location) },
    create: {
      key: settingKey(location),
      value: JSON.stringify(record),
      type: "json",
      description: TUTORIAL_LOCATION_META[location].label,
      updatedById: updatedByAdminId,
    },
    update: {
      value: JSON.stringify(record),
      type: "json",
      description: TUTORIAL_LOCATION_META[location].label,
      updatedById: updatedByAdminId,
    },
  });

  return record;
}

// NOTE: `validateYouTubeUrl` + `parseYouTubeUrl` are re-exported from
// `./shared` at the top of this file. Client components that need these
// (or the constants) should import from `@/lib/tutorial-videos/shared`
// directly to avoid pulling `db` into the browser bundle.
