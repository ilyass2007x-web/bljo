/**
 * Internationalization engine.
 *
 * Architecture:
 *  - Translations live in locales/<lang>/common.json (NOT hardcoded in components).
 *  - Supported languages are registered in SUPPORTED_LANGUAGES — adding a new
 *    language only requires creating a locales/<lang>/common.json file and
 *    registering it here. No component changes.
 *  - Missing keys fall back to English (never display undefined/missing_key).
 *  - RTL languages are detected via isRTL().
 *  - Date/time formatting uses the Intl API (locale-aware, no manual formats).
 */

import en from "./locales/en/common.json";
import ar from "./locales/ar/common.json";
import fr from "./locales/fr/common.json";

export type Language = "en" | "ar" | "fr";

export interface LanguageConfig {
  code: Language;
  /** Native name shown in the language selector. */
  nativeName: string;
  /** English name for reference. */
  englishName: string;
  /** Direction. */
  dir: "ltr" | "rtl";
  /** BCP-47 locale tag for Intl APIs. */
  locale: string;
}

/**
 * Registry of supported languages. To add a new language (e.g. Spanish):
 *   1. Create locales/es/common.json
 *   2. Import it below
 *   3. Add { code: "es", ... } to this array
 * No component changes required.
 */
export const SUPPORTED_LANGUAGES: LanguageConfig[] = [
  { code: "en", nativeName: "English", englishName: "English", dir: "ltr", locale: "en-US" },
  { code: "ar", nativeName: "العربية", englishName: "Arabic", dir: "rtl", locale: "ar" },
  { code: "fr", nativeName: "Français", englishName: "French", dir: "ltr", locale: "fr-FR" },
];

export const DEFAULT_LANGUAGE: Language = "en";

const TRANSLATIONS: Record<Language, Record<string, unknown>> = {
  en,
  ar,
  fr,
};

export function isRTL(lang: string): boolean {
  const config = SUPPORTED_LANGUAGES.find((l) => l.code === lang);
  return config?.dir === "rtl";
}

export function getLanguageConfig(lang: string): LanguageConfig {
  return (
    SUPPORTED_LANGUAGES.find((l) => l.code === lang) ??
    SUPPORTED_LANGUAGES.find((l) => l.code === DEFAULT_LANGUAGE)!
  );
}

export function isValidLanguage(lang: string): lang is Language {
  return SUPPORTED_LANGUAGES.some((l) => l.code === lang);
}

/**
 * Resolve a nested key like "auth.signIn" from a translations object.
 */
function resolveKey(obj: Record<string, unknown>, key: string): unknown {
  const parts = key.split(".");
  let current: unknown = obj;
  for (const part of parts) {
    if (current && typeof current === "object" && part in (current as Record<string, unknown>)) {
      current = (current as Record<string, unknown>)[part];
    } else {
      return undefined;
    }
  }
  return current;
}

/**
 * Interpolate {placeholders} in a string.
 */
function interpolate(
  template: string,
  params?: Record<string, string | number>
): string {
  if (!params) return template;
  return template.replace(/\{(\w+)\}/g, (_, key) =>
    key in params ? String(params[key]) : `{${key}}`
  );
}

/**
 * Translate a key in the given language. Falls back to English if the key is
 * missing in the requested language. Never returns undefined.
 */
export function translate(
  lang: string,
  key: string,
  params?: Record<string, string | number>
): string {
  const language = isValidLanguage(lang) ? lang : DEFAULT_LANGUAGE;

  // Try the requested language first.
  let value = resolveKey(TRANSLATIONS[language], key);
  // Fall back to English if missing.
  if (value === undefined && language !== DEFAULT_LANGUAGE) {
    value = resolveKey(TRANSLATIONS[DEFAULT_LANGUAGE], key);
  }
  // If still missing, return the key itself (better than undefined).
  if (value === undefined || typeof value !== "string") {
    return key;
  }
  return interpolate(value, params);
}

/**
 * Format a relative time (e.g. "2 minutes ago") using the Intl API.
 * Locale-aware — produces "منذ دقيقتين" in Arabic, "il y a 2 minutes" in French.
 */
export function formatRelativeTime(iso: string, lang: string): string {
  const config = getLanguageConfig(lang);
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSec = Math.round(diffMs / 1000);
  const diffMin = Math.round(diffSec / 60);
  const diffHr = Math.round(diffMin / 60);
  const diffDay = Math.round(diffHr / 24);

  const rtf = new Intl.RelativeTimeFormat(config.locale, { numeric: "auto" });

  if (diffSec < 60) {
    return translate(lang, "time.now");
  }
  if (diffMin < 60) {
    return rtf.format(-diffMin, "minute");
  }
  if (diffHr < 24) {
    return rtf.format(-diffHr, "hour");
  }
  if (diffDay < 7) {
    return rtf.format(-diffDay, "day");
  }
  return new Intl.DateTimeFormat(config.locale, {
    month: "short",
    day: "numeric",
  }).format(date);
}

/**
 * Format a full date/time using the user's locale.
 */
export function formatDateTime(iso: string, lang: string): string {
  const config = getLanguageConfig(lang);
  return new Intl.DateTimeFormat(config.locale, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(iso));
}
