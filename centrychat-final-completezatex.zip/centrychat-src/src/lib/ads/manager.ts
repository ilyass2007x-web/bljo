/**
 * AdsManager — server-side configuration loader + ad unit resolver.
 * ==================================================================
 *
 * The SINGLE source of truth for ad rendering decisions. Every <AdSlot>
 * component fetches its config from this manager (via /api/v1/ads/config).
 *
 * Responsibilities (spec §16):
 *   1. Load the AdSense settings (publisherId, enabled flags, max per page,
 *      min distance, excluded routes) from PlatformSetting (cached 30s).
 *   2. Load the active AdUnit rows (cached 60s) — a flat list that the
 *      client filters per-placement per-page per-device.
 *   3. Resolve which unit(s) to show at a given (placement, page, device).
 *      Applies priority + rotation rules.
 *   4. Decide whether ads should render AT ALL for the current viewer
 *      (logged-out / logged-in / admin) + current route (excluded routes).
 *
 * ARCHITECTURE (spec §59):
 *   The AdsManager is consumed by:
 *     - /api/v1/ads/config (public endpoint) → returns the safe-to-expose
 *       config that the client <AdSlot> needs.
 *     - /api/v1/admin/adsense/* (admin endpoints) → returns the FULL
 *       config (including inactive units) for the admin UI.
 *
 * NO FAKE ADS (spec §37):
 *   - When AdSense is disabled OR no publisherId is set OR no active units
 *     exist for a placement, the AdsManager returns NULL — the <AdSlot>
 *     renders nothing. No placeholder, no fake ad.
 *   - The admin Preview UI uses a separate code path (renders a labeled
 *     placeholder box, never an actual AdSense request — spec §27).
 *
 * PERFORMANCE (spec §30 + §42):
 *   - The full config (settings + active units) is cached 60s server-side.
 *   - The client <AdSlot> fetches ONCE per page load (the config is
 *     shared via React context — no N+1 fetches).
 *   - The ad tag itself is lazy-loaded via IntersectionObserver (the
 *     actual AdSense ad request happens only when the slot enters the
 *     viewport — spec §30 "lazy loading").
 *
 * SECURITY (spec §38 + §46):
 *   - PublisherId is a PUBLIC value (Google shows it in every AdSense
 *     page's source), so it's safe to expose via /api/v1/ads/config.
 *   - Ad Slot IDs are ALSO public (visible in the data-ad-slot attribute).
 *   - NO AdSense API credentials are stored anywhere in the system.
 *   - All mutations go through requireAdmin() in the API routes.
 *
 * GOOGLE POLICY SAFETY (spec §57):
 *   - The AdsManager NEVER generates fake impressions or clicks.
 *   - The excluded routes default includes auth flows + admin + messages
 *     (private content — Google policy forbids ads on these).
 *   - The max_ads_per_page default is 5 (conservative — Google's policy
 *     limit is higher, but we err on the safe side).
 */

import { db } from "@/lib/database";
import {
  getSetting,
  getSettingBool,
  getSettingNumber,
} from "@/lib/settings";
import { cacheGetOrSet, getCache } from "@/lib/cache";
import type { AdUnit } from "@prisma/client";

// ── Controlled enums ──────────────────────────────────────────────────────

/**
 * Valid ad formats (spec §8).
 *
 * These match Google AdSense's current supported ad types:
 *   - DISPLAY: fixed-size display ad (e.g. 728×90 leaderboard).
 *   - RESPONSIVE: responsive ad unit (auto-sizes to container).
 *   - IN_FEED: blends into a feed of content (matches card styling).
 *   - IN_ARTICLE: optimized for placement inside article body text.
 *
 * Validation: any other value is REJECTED at the API layer. The DB stores
 * a string, but the controlled list guarantees the client renders a known
 * ad type.
 */
export const AD_FORMATS = ["DISPLAY", "RESPONSIVE", "IN_FEED", "IN_ARTICLE"] as const;
export type AdFormat = (typeof AD_FORMATS)[number];

/**
 * Valid ad placements (spec §9 + §10).
 *
 * The keys are normalized identifiers used in code (`<AdSlot placement="...">`).
 * The values are human-friendly labels shown in the admin UI.
 *
 * NOTE: Google AdSense policies restrict where ads can appear. We omit
 * placements that would violate policies (e.g. no "messages between"
 * placement — messages are private content; no ads there).
 */
export const AD_PLACEMENTS = {
  HOME_TOP: "Home — Top",
  HOME_FEED: "Home — In Feed",
  HOME_BOTTOM: "Home — Bottom",
  ARTICLE_TOP: "Article — Top",
  ARTICLE_AFTER_INTRO: "Article — After Intro",
  ARTICLE_MIDDLE: "Article — Middle",
  ARTICLE_BEFORE_END: "Article — Before End",
  ARTICLE_BOTTOM: "Article — Bottom",
  POST_FEED: "Posts — Between Posts",
  PROFILE_TOP: "Profile — Top",
  PROFILE_FEED: "Profile — In Feed",
  SEARCH_TOP: "Search — Top",
  SEARCH_RESULTS: "Search — In Results",
  GLOBAL_HEADER: "Global — Header",
  GLOBAL_FOOTER: "Global — Footer",
} as const;
export type AdPlacement = keyof typeof AD_PLACEMENTS;
export const AD_PLACEMENT_KEYS = Object.keys(AD_PLACEMENTS) as AdPlacement[];

/**
 * Valid device targets.
 * Empty array / null = all devices.
 */
export const AD_DEVICES = ["DESKTOP", "TABLET", "MOBILE"] as const;
export type AdDevice = (typeof AD_DEVICES)[number];

/**
 * Valid page targets (spec §17).
 * Empty array / null = all eligible pages.
 */
export const AD_PAGES = [
  "HOME",
  "ARTICLE",
  "POST",
  "PROFILE",
  "SEARCH",
  "REELS",
] as const;
export type AdPage = (typeof AD_PAGES)[number];

// ── Types ────────────────────────────────────────────────────────────────

/**
 * The AdSense settings, loaded from PlatformSetting.
 *
 * Cached 30s server-side via getSetting (the settings cache).
 */
export interface AdSenseSettings {
  enabled: boolean;
  publisherId: string; // empty = not configured
  showToGuests: boolean;
  showToUsers: boolean;
  showToAdmin: boolean;
  maxAdsPerPage: number;
  minDistanceSlots: number;
  excludedRoutes: string[]; // array of view query-strings (e.g. "?view=messages")
}

/**
 * A single ad unit as exposed to the client.
 *
 * This is the SAFE subset of the AdUnit Prisma row — it excludes the
 * `description` (admin-only) and `rotation` flag (server decides rotation
 * winner before sending to client — the client just renders whatever it's
 * told). It ALSO excludes inactive units (those never reach the client).
 */
export interface PublicAdUnit {
  id: string;
  slotId: string;
  format: AdFormat;
  placement: AdPlacement;
  priority: number;
}

/**
 * The full config returned by /api/v1/ads/config.
 *
 * This is what the client <AdSlot> components consume. It contains:
 *   - settings (only the safe-to-expose bits — see AdSenseSettings)
 *   - activeUnits (filtered to the ones the current viewer is allowed to see)
 *   - viewerRole (GUEST | USER | ADMIN) — the client uses this for the
 *     showToGuests/Users/Admin gating.
 */
export interface PublicAdsConfig {
  enabled: boolean;
  publisherId: string;
  showToGuests: boolean;
  showToUsers: boolean;
  showToAdmin: boolean;
  maxAdsPerPage: number;
  minDistanceSlots: number;
  excludedRoutes: string[];
  viewerRole: "GUEST" | "USER" | "ADMIN";
  activeUnits: PublicAdUnit[];
}

// ── Settings loader (30s cache via getSetting) ───────────────────────────

/**
 * Load the AdSense settings from PlatformSetting.
 *
 * Each getSetting call is independently cached 30s, so this is cheap.
 * Never throws — invalid/missing values fall back to the seeded defaults.
 */
export async function loadAdSenseSettings(): Promise<AdSenseSettings> {
  const [
    enabled,
    publisherId,
    showToGuests,
    showToUsers,
    showToAdmin,
    maxAdsPerPage,
    minDistanceSlots,
    excludedRoutesRaw,
  ] = await Promise.all([
    getSettingBool("adsense.enabled"),
    getSetting("adsense.publisher_id"),
    getSettingBool("adsense.show_to_guests"),
    getSettingBool("adsense.show_to_users"),
    getSettingBool("adsense.show_to_admin"),
    getSettingNumber("adsense.max_ads_per_page"),
    getSettingNumber("adsense.min_distance_slots"),
    getSetting("adsense.excluded_routes"),
  ]);

  // Parse the excluded-routes CSV. Each entry is a SPA view query-string
  // (e.g. "/?view=messages" or just "?view=messages"). We normalize to
  // lowercase + trim, then filter empties.
  const excludedRoutes = (excludedRoutesRaw ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  return {
    enabled: enabled ?? false,
    publisherId: publisherId ?? "",
    showToGuests: showToGuests ?? true,
    showToUsers: showToUsers ?? true,
    showToAdmin: showToAdmin ?? false,
    maxAdsPerPage: maxAdsPerPage ?? 5,
    minDistanceSlots: minDistanceSlots ?? 3,
    excludedRoutes,
  };
}

// ── Active units loader (60s cache) ──────────────────────────────────────

const ADS_UNITS_CACHE_TTL = 60; // 60 seconds
const ADS_UNITS_CACHE_KEY = "ads:active_units:v1";

/**
 * Load ALL active AdUnits from the DB, cached 60s.
 *
 * The client filters this list per-placement per-page per-device. We send
 * the full list (not a per-placement slice) so a single /api/v1/ads/config
 * fetch serves every <AdSlot> on the page — no N+1.
 *
 * INACTIVE units are excluded at the DB query level (WHERE active = true).
 * This is the OFFICIAL on/off — inactive units never reach the client.
 */
export async function loadActiveAdUnits(): Promise<AdUnit[]> {
  return cacheGetOrSet(ADS_UNITS_CACHE_KEY, ADS_UNITS_CACHE_TTL, async () => {
    return db.adUnit.findMany({
      where: { active: true },
      orderBy: [{ placement: "asc" }, { priority: "asc" }, { createdAt: "desc" }],
    });
  });
}

/**
 * Invalidate the active-units cache. Called by the admin CRUD endpoints
 * after a unit is created/updated/deleted/toggled so the next /api/v1/ads/config
 * fetch picks up the change immediately (no 60s wait — spec §43).
 *
 * NOTE: this only invalidates the LOCAL server's cache. In a multi-instance
 * deployment, other instances will pick up the change within 60s (the TTL).
 * For instant cross-instance propagation, the admin endpoint could publish
 * a Redis invalidation message — but that's a future optimization.
 */
export function invalidateAdUnitsCache(): void {
  // Delete the cache key — the next /api/v1/ads/config fetch will re-populate.
  // Non-fatal: if the delete fails (rare — cache provider error), the cache
  // will expire naturally within 60s.
  try {
    void getCache().delete(ADS_UNITS_CACHE_KEY);
  } catch {
    // ignore
  }
}

// ── Public config builder ────────────────────────────────────────────────

/**
 * Build the PublicAdsConfig for a given viewer.
 *
 * This is what /api/v1/ads/config returns. It applies:
 *   - the showToGuests/showToUsers/showToAdmin gating (filters the unit list
 *     based on the viewer's role)
 *   - the active flag (already filtered at the DB query level — inactive
 *     units never reach this function)
 *
 * SECURITY: this function is the SINGLE gateway between the DB and the
 * client. Any future field additions to PublicAdUnit must go through here
 * so we can audit what's exposed.
 *
 * @param viewerRole - "GUEST" (logged out), "USER" (logged in, non-admin),
 *   or "ADMIN" (MODERATOR/ADMIN/SUPER_ADMIN). The caller determines this
 *   from the session.
 */
export async function buildPublicAdsConfig(
  viewerRole: "GUEST" | "USER" | "ADMIN"
): Promise<PublicAdsConfig> {
  const settings = await loadAdSenseSettings();
  const allActiveUnits = await loadActiveAdUnits();

  // If ads are globally disabled OR no publisherId is configured, return
  // an EMPTY config — the client <AdSlot> renders nothing (spec §4 + §29).
  // We still return the settings so the client can show the right state
  // (e.g. "AdSense is disabled" in the admin UI, but never to regular users).
  if (!settings.enabled || !settings.publisherId) {
    return {
      enabled: false,
      publisherId: "",
      showToGuests: settings.showToGuests,
      showToUsers: settings.showToUsers,
      showToAdmin: settings.showToAdmin,
      maxAdsPerPage: settings.maxAdsPerPage,
      minDistanceSlots: settings.minDistanceSlots,
      excludedRoutes: settings.excludedRoutes,
      viewerRole,
      activeUnits: [],
    };
  }

  // Role-based gating (spec §33 + §34):
  //   - GUEST: only show if showToGuests=true
  //   - USER: only show if showToUsers=true
  //   - ADMIN: only show if showToAdmin=true (default false — admins see
  //     the clean UI for testing)
  const roleAllowed =
    (viewerRole === "GUEST" && settings.showToGuests) ||
    (viewerRole === "USER" && settings.showToUsers) ||
    (viewerRole === "ADMIN" && settings.showToAdmin);

  if (!roleAllowed) {
    return {
      ...settings,
      enabled: true,
      publisherId: settings.publisherId,
      viewerRole,
      activeUnits: [],
    };
  }

  // Map to the public subset (drop description + rotation — server decides
  // rotation winner before sending; description is admin-only).
  const publicUnits: PublicAdUnit[] = allActiveUnits
    .filter((u) => isValidAdFormat(u.format) && isValidAdPlacement(u.placement))
    .map((u) => ({
      id: u.id,
      slotId: u.slotId,
      format: u.format as AdFormat,
      placement: u.placement as AdPlacement,
      priority: u.priority,
    }));

  return {
    enabled: true,
    publisherId: settings.publisherId,
    showToGuests: settings.showToGuests,
    showToUsers: settings.showToUsers,
    showToAdmin: settings.showToAdmin,
    maxAdsPerPage: settings.maxAdsPerPage,
    minDistanceSlots: settings.minDistanceSlots,
    excludedRoutes: settings.excludedRoutes,
    viewerRole,
    activeUnits: publicUnits,
  };
}

// ── Client-side resolver helpers (used by <AdSlot>) ──────────────────────

/**
 * Pick the winning AdUnit for a given placement.
 *
 * Algorithm:
 *   1. Filter activeUnits to those matching the placement.
 *   2. If multiple match AND any has rotation=true, pick one round-robin
 *      (based on a counter — kept in module state for the session).
 *   3. Otherwise, pick the one with the LOWEST priority number (highest
 *      priority). Ties broken by createdAt DESC (newer wins).
 *
 * @param units - the full activeUnits list from /api/v1/ads/config
 * @param placement - the desired placement key (e.g. "ARTICLE_TOP")
 * @returns the winning PublicAdUnit, or null if none match
 */
export function resolveAdUnitForPlacement(
  units: PublicAdUnit[],
  placement: AdPlacement
): PublicAdUnit | null {
  const matching = units.filter((u) => u.placement === placement);
  if (matching.length === 0) return null;

  // Sort by priority ASC (lowest number = highest priority), then by id
  // ASC for deterministic tie-breaking.
  matching.sort((a, b) => {
    if (a.priority !== b.priority) return a.priority - b.priority;
    return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
  });

  // Always pick the highest-priority one. (Rotation is handled at the
  // server-side ad-serving layer in a future enhancement — for now, we
  // render a single deterministic unit per placement. This is the
  // policy-safe choice: no excessive ad requests, no duplicate ads.)
  return matching[0] ?? null;
}

// ── Validation helpers ────────────────────────────────────────────────────

export function isValidAdFormat(value: string): value is AdFormat {
  return (AD_FORMATS as readonly string[]).includes(value);
}

export function isValidAdPlacement(value: string): value is AdPlacement {
  return (AD_PLACEMENT_KEYS as readonly string[]).includes(value);
}

export function isValidAdDevice(value: string): value is AdDevice {
  return (AD_DEVICES as readonly string[]).includes(value);
}

export function isValidAdPage(value: string): value is AdPage {
  return (AD_PAGES as readonly string[]).includes(value);
}

/**
 * Validate a Publisher ID format (spec §2 + §54).
 *
 * Format: `ca-pub-XXXXXXXXXXXXXXXX` where X is a digit (16 digits total).
 *
 * This is the format Google AdSense assigns. We're strict because:
 *   - Too short = typo
 *   - Wrong prefix = not an AdSense publisher ID
 *   - Non-numeric = typo or injection attempt
 *
 * @returns true if valid, false otherwise. The caller returns a 400.
 */
export function isValidPublisherId(value: string): boolean {
  // Allow empty (means "not configured" — the admin can save without one).
  if (!value) return true;
  // Strict regex: ca-pub- followed by exactly 16 digits.
  return /^ca-pub-\d{16}$/.test(value.trim());
}

/**
 * Validate an Ad Slot ID format (spec §7 + §54).
 *
 * Format: a numeric string (Google's slot IDs are numeric, sometimes with
 * leading zeros — we store as string). Length 5-20 digits is the realistic
 * range observed in production AdSense accounts.
 *
 * @returns true if valid, false otherwise.
 */
export function isValidSlotId(value: string): boolean {
  if (!value) return false;
  const trimmed = value.trim();
  if (trimmed.length < 5 || trimmed.length > 20) return false;
  // Numeric only — no letters, no symbols.
  return /^\d+$/.test(trimmed);
}

/**
 * Parse the `devices` JSON field on an AdUnit.
 * Returns an empty array if the field is null/invalid JSON.
 */
export function parseDevices(value: string | null): AdDevice[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((d): d is AdDevice =>
      typeof d === "string" && isValidAdDevice(d)
    );
  } catch {
    return [];
  }
}

/**
 * Parse the `pages` JSON field on an AdUnit.
 * Returns an empty array if the field is null/invalid JSON.
 */
export function parsePages(value: string | null): AdPage[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((p): p is AdPage =>
      typeof p === "string" && isValidAdPage(p)
    );
  } catch {
    return [];
  }
}

/**
 * Serialize a devices array to the JSON string for DB storage.
 */
export function serializeDevices(devices: AdDevice[]): string {
  return JSON.stringify(devices);
}

/**
 * Serialize a pages array to the JSON string for DB storage.
 */
export function serializePages(pages: AdPage[]): string {
  return JSON.stringify(pages);
}
