/**
 * RuleBasedRecommendationEngine
 *
 * Initial implementation using weighted scoring. Designed to be replaced by
 * ML/embeddings later without changing the interface.
 *
 * Scoring factors (all configurable via admin settings):
 *  - Personalization: match content topics to user interests
 *  - Freshness: newer content scores higher
 *  - Engagement: content with more likes/comments scores higher
 *  - Following: content from followed users gets a boost
 *  - Trending: globally popular content gets a boost
 *  - Diversity: limits consecutive same-topic/same-creator content
 *
 * INTEREST LEARNING (CentryChat spec §6 + §7 + §17):
 *   Each interaction calls trackInteraction, which:
 *     1. Records the raw ContentInteraction row (existing behavior — for
 *        analytics + later re-computation).
 *     2. Updates the user's UserInterest.score for the affected topic by
 *        a CONFIGURABLE DELTA (positive for like/comment/share/follow,
 *        negative for skip/not_interested/unfollow).
 *     3. Clamps the new score to [decayFloor, 1.0] where decayFloor is the
 *        admin-configured `interest.decay_floor` (default 0.05). This
 *        preserves a small residual for re-exploration (spec §17 — "don't
 *        delete entirely").
 *
 * PRIVACY: Never uses private messages, passwords, or auth secrets.
 * Only uses public interactions (views, likes, follows, etc.).
 */

import { db } from "@/lib/database";
import { getSettingNumber, getSettingBool } from "@/lib/settings";
import { isFeatureEnabled } from "@/lib/features";
import {
  getInterestDeltaForAction,
  clampInterestScore,
} from "@/lib/feed/personalization";
import type {
  RecommendationEngine,
  FeedItem,
  FeedResult,
  FeedOptions,
} from "./engine";

/**
 * @deprecated — kept for backward compat with any code that imports it
 * directly. The actual delta values now come from admin settings
 * `interest.weight.*` via getInterestDeltaForAction (cached 30s).
 *
 * This map is only used as a FALLBACK when the admin settings return null
 * (which never happens in practice — the defaults are seeded).
 */
const ACTION_WEIGHTS: Record<string, number> = {
  view: 0.05,
  like: 0.15,
  comment: 0.20,
  share: 0.25,
  save: 0.20,
  follow: 0.30,
  profile_visit: 0.10,
  skip: -0.05,
  not_interested: -0.30,
  unfollow: -0.15,
  read_long: 0.08,
};

export class RuleBasedRecommendationEngine implements RecommendationEngine {
  readonly name = "rule-based";

  async getFeed(opts: FeedOptions): Promise<FeedResult> {
    const { userId, limit = 20, feedType = "for_you" } = opts;

    // If the algorithm is disabled, return a basic chronological feed.
    const enabled = await isFeatureEnabled("recommendation_algorithm");
    if (!enabled) {
      return this.getBasicFeed(userId, limit, feedType);
    }

    // Get configurable weights from admin settings (with defaults).
    const personalizationWeight = await getSettingNumber("rec.weight.personalization") ?? 1.0;
    const freshnessWeight = await getSettingNumber("rec.weight.freshness") ?? 0.5;
    const engagementWeight = await getSettingNumber("rec.weight.engagement") ?? 0.3;
    const followingWeight = await getSettingNumber("rec.weight.following") ?? 0.4;
    const trendingWeight = await getSettingNumber("rec.weight.trending") ?? 0.2;
    const diversityWeight = await getSettingNumber("rec.weight.diversity") ?? 0.5;
    const maxConsecutiveSameCreator = await getSettingNumber("rec.max_consecutive_creator") ?? 2;

    // For now, since Posts/Reels are not yet enabled, we recommend PROFILES
    // based on the user's interests and follow graph. When posts are enabled,
    // this will naturally extend to include them.
    const candidates = await this.getCandidateProfiles(userId, feedType, limit * 3);

    // Get user's interest profile.
    const interests = await this.getUserInterests(userId);
    const notInterestedTopics = await this.getNotInterestedTopics(userId);

    // Get users that the current user follows.
    const followingIds = await this.getFollowingIds(userId);

    // Score each candidate.
    const scored: FeedItem[] = candidates.map((c) => {
      let score = 0;
      const reasons: string[] = [];

      // Personalization: match candidate's topics to user interests.
      if (c.topics && c.topics.length > 0) {
        const interestMatch = c.topics.reduce((sum, slug) => {
          const interest = interests.find((i) => i.topic === slug);
          return sum + (interest?.score ?? 0);
        }, 0);
        score += interestMatch * personalizationWeight;
        if (interestMatch > 0.5) reasons.push("matches your interests");
      }

      // Following: boost content from followed users.
      if (followingIds.has(c.id)) {
        score += followingWeight;
        reasons.push("from someone you follow");
      }

      // Freshness: newer = higher score (using createdAt).
      const ageHours = (Date.now() - c.createdAt.getTime()) / (1000 * 60 * 60);
      const freshnessScore = Math.max(0, 1 - ageHours / (24 * 7)); // decay over 7 days
      score += freshnessScore * freshnessWeight;

      // Engagement: more followers = slightly higher score (proxy for popularity).
      const engagementScore = Math.min(1, (c._count?.followers ?? 0) / 100);
      score += engagementScore * engagementWeight;

      // Trending: globally popular (verified users get a small boost).
      if (c.isVerified) {
        score += trendingWeight * 0.1;
      }

      // Diversity: penalize if we've already shown this creator or topic recently.
      // (Simplified — in production this would track recent impressions.)

      // Not interested: penalize if the candidate's topics are in the user's blocklist.
      if (c.topics?.some((t) => notInterestedTopics.has(t))) {
        score -= 0.5;
      }

      return {
        contentType: "profile" as const,
        contentId: c.id,
        score: Math.max(0, score),
        reason: reasons.length > 0 ? reasons[0] : undefined,
      };
    });

    // Sort by score descending.
    scored.sort((a, b) => b.score - a.score);

    // Apply creator diversity: limit consecutive items from the same creator.
    const diverse = this.applyCreatorDiversity(scored, maxConsecutiveSameCreator);

    // Take the top `limit` items.
    const items = diverse.slice(0, limit);

    return { items };
  }

  async trackInteraction(opts: {
    userId: string;
    contentType: string;
    contentId: string;
    action: string;
    topicSlug?: string;
    duration?: number;
  }): Promise<void> {
    // Resolve the topic for this interaction. The caller may pass a
    // topicSlug explicitly (when known). When NOT passed, Phase 2.4
    // now auto-resolves the topicId from the content's ArticleTopic/
    // PostTopic relationships — so interactions with topic-assigned
    // content automatically update the user's interest scores.
    //
    // This reuses the same pattern as the Phase 2 not-interested fix
    // (resolveTopicSlugFromContent), but returns a topicId directly
    // (avoiding the slug → ID lookup detour — 1 query instead of 2).
    let topicId: string | null = null;
    if (opts.topicSlug) {
      const topic = await db.contentTopic.findUnique({
        where: { slug: opts.topicSlug },
        select: { id: true },
      });
      topicId = topic?.id ?? null;
    } else {
      // Phase 2.4 — auto-resolve topicId from the content's canonical
      // topic relationships. 1 indexed query (findFirst on ArticleTopic
      // or PostTopic, filtered by isActive=true). Returns null when the
      // content has no topics OR the first topic is inactive.
      topicId = await this.resolveTopicIdFromContent(
        opts.contentType,
        opts.contentId
      );
    }

    // ── 1. Record the raw interaction row (existing behavior) ────────
    // Always created — used for analytics + later re-computation.
    await db.contentInteraction.create({
      data: {
        userId: opts.userId,
        contentType: opts.contentType,
        contentId: opts.contentId,
        topicId,
        action: opts.action,
        duration: opts.duration ?? null,
      },
    });

    // ── 2. Get the configurable delta for this action ────────────────
    // Loaded from admin settings `interest.weight.*` (cached 30s).
    // Returns { appliesToInterests: false } for analytics-only events
    // (impression, click) — they don't move the interest score.
    const { delta, appliesToInterests } = await getInterestDeltaForAction(
      opts.action
    );

    // ── 3. Update the user's interest score for this topic ──────────
    // Only when:
    //   - The action has an interest delta (appliesToInterests=true)
    //   - We resolved a topicId from the topicSlug
    //   - The delta is non-zero
    // When any of these is false, we still recorded the raw interaction
    // above — analytics are intact, we just don't move the score.
    if (appliesToInterests && topicId && delta !== 0) {
      // Load the decay floor (admin-configured, default 0.05) — preserves
      // a small residual for re-exploration (spec §17).
      const decayFloor = (await getSettingNumber("interest.decay_floor")) ?? 0.05;
      await this.updateInterestScore(opts.userId, topicId, delta, decayFloor);
    }

    // Update the recommendation profile metadata.
    await db.recommendationProfile.upsert({
      where: { userId: opts.userId },
      create: {
        userId: opts.userId,
        interactionCount: 1,
        lastComputedAt: new Date(),
      },
      update: {
        interactionCount: { increment: 1 },
        lastComputedAt: new Date(),
      },
    });

    // Record a recommendation event for analytics (only for content events).
    if (["impression", "click", "skip", "not_interested"].includes(opts.action)) {
      await db.recommendationEvent.create({
        data: {
          userId: opts.userId,
          contentType: opts.contentType,
          contentId: opts.contentId,
          event: opts.action,
        },
      });
    }

    // Phase 1 Personalized Feed — invalidate the interest profile cache
    // for this user so the next profile read reflects the new interaction.
    // This is a fire-and-forget import (lazy) to avoid a circular dependency
    // at module-load time (interest-profile imports from the DB, not from
    // the engine — but we keep it lazy for safety).
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const { invalidateProfileCache } = require("@/lib/feed/interest-profile") as typeof import("@/lib/feed/interest-profile");
      invalidateProfileCache(opts.userId);
    } catch {
      // Best-effort — if the import fails (SSR build), silently skip.
    }
  }

  async markNotInterested(opts: {
    userId: string;
    contentType: string;
    contentId: string;
    topicSlug?: string;
  }): Promise<void> {
    // Phase 2 — Topics fix: when topicSlug is missing, try to resolve it
    // from the content's explicit topic relationships (ArticleTopic /
    // PostTopic — added in Phase 2). This fixes the Phase 1.5-identified
    // bug where "Not interested" without topicSlug had ZERO effect on
    // future ranking (the notInterestedTopics JSON array wasn't updated).
    //
    // Resolution order:
    //   1. Use opts.topicSlug when provided (existing behavior).
    //   2. Else, look up the content's first topic via ArticleTopic/PostTopic.
    //   3. Else, leave topicSlug undefined — the interaction is still
    //      recorded (for analytics), but no notInterestedTopics entry is
    //      added (existing behavior, now an explicit fallback rather than
    //      a silent failure).
    let resolvedTopicSlug = opts.topicSlug;
    if (!resolvedTopicSlug) {
      try {
        resolvedTopicSlug = await this.resolveTopicSlugFromContent(
          opts.contentType,
          opts.contentId
        );
      } catch {
        // best-effort — fall through to the original trackInteraction path
        resolvedTopicSlug = undefined;
      }
    }

    // Track the not-interested interaction. If we resolved a topicSlug,
    // pass it so the existing trackInteraction path updates UserInterest
    // score (reduces it by the configured delta, clamped to decayFloor).
    await this.trackInteraction({
      userId: opts.userId,
      contentType: opts.contentType,
      contentId: opts.contentId,
      action: "not_interested",
      topicSlug: resolvedTopicSlug,
    });

    // Add the resolved topic to the user's not-interested list (Phase 2 fix).
    // The list is consumed by getUserInterestProfile() → notInterestedTopicsSet
    // → calculateNotInterestedPenalty() in the ranker.
    if (resolvedTopicSlug) {
      // Use upsert (not findUnique + update) so the profile row is created
      // when missing (new user with no prior interactions). The trackInteraction
      // path above also calls upsert on RecommendationProfile, so the row
      // now exists.
      const profile = await db.recommendationProfile.findUnique({
        where: { userId: opts.userId },
      });
      if (profile) {
        // Parse the existing list (defensive — JSON.parse may fail on
        // corrupted data, in which case we start fresh).
        let current: string[] = [];
        try {
          current = profile.notInterestedTopics
            ? JSON.parse(profile.notInterestedTopics)
            : [];
          if (!Array.isArray(current)) current = [];
        } catch {
          current = []; // corrupted JSON — reset
        }
        // Deduplicate — don't add the same topic twice.
        if (!current.includes(resolvedTopicSlug)) {
          // Cap at 200 entries to prevent unbounded growth (the user can
          // only meaningfully reject so many topics).
          if (current.length >= 200) {
            current = current.slice(current.length - 199); // drop oldest
          }
          current.push(resolvedTopicSlug);
          await db.recommendationProfile.update({
            where: { userId: opts.userId },
            data: { notInterestedTopics: JSON.stringify(current) },
          });
        }
      }
    }
  }

  /**
   * Resolve the first topic slug for a piece of content (post or article)
   * by looking up its explicit topic relationships (ArticleTopic/PostTopic).
   *
   * Used by markNotInterested when the client doesn't provide a topicSlug.
   * Returns null when the content has no topics OR the content doesn't exist.
   *
   * PERFORMANCE: 2 queries max (one for the topic relationship, one to
   * resolve the slug). Bounded + indexed by (articleId|postId).
   */
  private async resolveTopicSlugFromContent(
    contentType: string,
    contentId: string
  ): Promise<string | undefined> {
    if (contentType === "article") {
      // Fetch the article's first topic (by createdAt asc — the first one
      // assigned to the article).
      const articleTopic = await db.articleTopic.findFirst({
        where: { articleId: contentId },
        orderBy: { createdAt: "asc" },
        select: { topic: { select: { slug: true, isActive: true } } },
      }).catch(() => null);
      if (articleTopic?.topic?.isActive) {
        return articleTopic.topic.slug;
      }
      return undefined;
    }
    if (contentType === "post") {
      const postTopic = await db.postTopic.findFirst({
        where: { postId: contentId },
        orderBy: { createdAt: "asc" },
        select: { topic: { select: { slug: true, isActive: true } } },
      }).catch(() => null);
      if (postTopic?.topic?.isActive) {
        return postTopic.topic.slug;
      }
      return undefined;
    }
    // Unknown content type — no resolution possible.
    return undefined;
  }

  /**
   * Phase 2.4 — Resolve the first topic ID from a piece of content's
   * canonical topic relationships (ArticleTopic/PostTopic).
   *
   * Used by trackInteraction when the client doesn't provide a topicSlug.
   * Returns the topicId directly (avoiding the slug → ID lookup detour).
   * Returns null when the content has no topics OR the first topic's
   * ContentTopic is inactive.
   *
   * PERFORMANCE: 1 indexed query (findFirst on ArticleTopic or PostTopic,
   * filtered by isActive=true via the relation). Returns null on error.
   */
  private async resolveTopicIdFromContent(
    contentType: string,
    contentId: string
  ): Promise<string | null> {
    if (contentType === "article") {
      const articleTopic = await db.articleTopic.findFirst({
        where: { articleId: contentId, topic: { isActive: true } },
        orderBy: { createdAt: "asc" },
        select: { topicId: true },
      }).catch(() => null);
      return articleTopic?.topicId ?? null;
    }
    if (contentType === "post") {
      const postTopic = await db.postTopic.findFirst({
        where: { postId: contentId, topic: { isActive: true } },
        orderBy: { createdAt: "asc" },
        select: { topicId: true },
      }).catch(() => null);
      return postTopic?.topicId ?? null;
    }
    return null;
  }

  async setOnboardingInterests(userId: string, topicSlugs: string[]): Promise<void> {
    // Set initial interest scores for the selected topics.
    for (const slug of topicSlugs) {
      const topic = await db.contentTopic.findUnique({
        where: { slug },
        select: { id: true },
      });
      if (topic) {
        await db.userInterest.upsert({
          where: { userId_topicId: { userId, topicId: topic.id } },
          create: { userId, topicId: topic.id, score: 0.5 },
          update: { score: 0.5 },
        });
      }
    }

    // Mark onboarding as completed.
    await db.recommendationProfile.upsert({
      where: { userId },
      create: {
        userId,
        onboardingCompleted: true,
      },
      update: {
        onboardingCompleted: true,
      },
    });
  }

  async getInterestProfile(userId: string): Promise<{ topic: string; score: number }[]> {
    const interests = await db.userInterest.findMany({
      where: { userId },
      include: { topic: { select: { slug: true } } },
      orderBy: { score: "desc" },
    });
    return interests.map((i) => ({
      topic: i.topic.slug,
      score: i.score,
    }));
  }

  async resetUserProfile(userId: string): Promise<void> {
    await db.userInterest.deleteMany({ where: { userId } });
    await db.contentInteraction.deleteMany({ where: { userId } });
    await db.recommendationEvent.deleteMany({ where: { userId } });
    await db.recommendationProfile.deleteMany({ where: { userId } });
  }

  async resetAllProfiles(): Promise<void> {
    await db.userInterest.deleteMany({});
    await db.contentInteraction.deleteMany({});
    await db.recommendationEvent.deleteMany({});
    await db.recommendationProfile.deleteMany({});
  }

  // ---- Private helpers ----

  private async getBasicFeed(
    userId: string,
    limit: number,
    feedType: string
  ): Promise<FeedResult> {
    // Basic chronological feed — no personalization.
    if (feedType === "following") {
      const following = await db.follow.findMany({
        where: { followerId: userId },
        include: {
          following: {
            select: {
              id: true,
              fullName: true,
              username: true,
              avatarColor: true,
              isVerified: true,
              createdAt: true,
              _count: { select: { followers: true } },
            },
          },
        },
        orderBy: { createdAt: "desc" },
        take: limit,
      });
      return {
        items: following.map((f) => ({
          contentType: "profile" as const,
          contentId: f.following.id,
          score: 0,
        })),
      };
    }

    // Default: recent active users.
    const users = await db.user.findMany({
      where: {
        status: "ACTIVE",
        id: { not: userId },
      },
      orderBy: { lastSeenAt: "desc" },
      take: limit,
      select: { id: true },
    });
    return {
      items: users.map((u) => ({
        contentType: "profile" as const,
        contentId: u.id,
        score: 0,
      })),
    };
  }

  private async getCandidateProfiles(
    userId: string,
    feedType: string,
    limit: number
  ) {
    // For the "following" feed, only show followed users.
    if (feedType === "following") {
      const following = await db.follow.findMany({
        where: { followerId: userId },
        include: { following: { select: { id: true, fullName: true, username: true, avatarColor: true, isVerified: true, createdAt: true } } },
        take: limit,
      });
      return following.map((f) => ({
        ...f.following,
        topics: [],
      }));
    }

    // For "for_you" and "trending", get a pool of active users.
    // In the future, this will include posts and reels.
    const users = await db.user.findMany({
      where: {
        status: "ACTIVE",
        id: { not: userId },
      },
      orderBy: { lastSeenAt: "desc" },
      take: limit,
      select: {
        id: true,
        fullName: true,
        username: true,
        avatarColor: true,
        isVerified: true,
        createdAt: true,
        _count: { select: { followers: true } },
      },
    });
    // For now, profiles don't have topics — return empty arrays.
    // When posts are enabled, we'll infer profile topics from their posts.
    return users.map((u) => ({ ...u, topics: [] as string[] }));
  }

  private async getUserInterests(userId: string): Promise<{ topic: string; score: number }[]> {
    const interests = await db.userInterest.findMany({
      where: { userId, score: { gt: 0 } },
      include: { topic: { select: { slug: true } } },
      orderBy: { score: "desc" },
    });
    return interests.map((i) => ({
      topic: i.topic.slug,
      score: i.score,
    }));
  }

  private async getNotInterestedTopics(userId: string): Promise<Set<string>> {
    const profile = await db.recommendationProfile.findUnique({
      where: { userId },
      select: { notInterestedTopics: true },
    });
    if (!profile?.notInterestedTopics) return new Set();
    try {
      return new Set(JSON.parse(profile.notInterestedTopics) as string[]);
    } catch {
      return new Set();
    }
  }

  private async getFollowingIds(userId: string): Promise<Set<string>> {
    const follows = await db.follow.findMany({
      where: { followerId: userId },
      select: { followingId: true },
    });
    return new Set(follows.map((f) => f.followingId));
  }

  private async updateInterestScore(
    userId: string,
    topicId: string,
    delta: number,
    decayFloor: number
  ): Promise<void> {
    const existing = await db.userInterest.findUnique({
      where: { userId_topicId: { userId, topicId } },
    });

    if (existing) {
      // Update with clamping to [decayFloor, 1.0] via the shared helper.
      // The decay floor preserves a residual for re-exploration (spec §17).
      const newScore = clampInterestScore(existing.score + delta, decayFloor);
      await db.userInterest.update({
        where: { id: existing.id },
        data: { score: newScore },
      });
    } else {
      // Create new interest. For POSITIVE deltas, start at the delta value
      // (clamped to [decayFloor, 1.0]). For NEGATIVE deltas (rare — usually
      // only happens when a user clicks "not interested" on a topic they've
      // never interacted with), start at the decay floor (so we still keep
      // a residual for re-exploration).
      const rawInitial = delta > 0 ? delta : decayFloor;
      const newScore = clampInterestScore(rawInitial, decayFloor);
      await db.userInterest.create({
        data: { userId, topicId, score: newScore },
      });
    }
  }

  private applyCreatorDiversity(
    items: FeedItem[],
    maxConsecutive: number
  ): FeedItem[] {
    if (maxConsecutive <= 0) return items;
    // Simple diversity: if the same contentId appears more than maxConsecutive
    // times in a row, push it later. For profiles this is unlikely, but for
    // posts/reels this will matter.
    const result: FeedItem[] = [];
    const consecutiveCount = new Map<string, number>();

    for (const item of items) {
      const count = consecutiveCount.get(item.contentId) ?? 0;
      if (count < maxConsecutive) {
        result.push(item);
        consecutiveCount.set(item.contentId, count + 1);
      }
      // If exceeded, skip (it's already sorted by score, so lower-scored items fill in).
    }
    return result;
  }
}

// Singleton instance.
let _engine: RecommendationEngine | null = null;

export function getRecommendationEngine(): RecommendationEngine {
  if (_engine) return _engine;
  _engine = new RuleBasedRecommendationEngine();
  return _engine;
}

/**
 * Shared singleton instance of the rule-based recommendation engine.
 * Convenience export for routes that import `ruleBasedEngine` directly.
 */
export const ruleBasedEngine = getRecommendationEngine();
