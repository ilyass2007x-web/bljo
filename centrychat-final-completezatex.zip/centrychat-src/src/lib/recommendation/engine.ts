/**
 * RecommendationEngine — abstraction layer for content recommendations.
 *
 * The application talks to this interface. The active implementation is selected
 * via the `recommendation_algorithm` feature flag + admin settings.
 *
 * Current implementation: RuleBasedRecommendationEngine (weighted scoring).
 * Future implementations can use ML, embeddings, or vector search — no
 * application code changes required because all access goes through this interface.
 */

export interface FeedItem {
  contentType: "post" | "reel" | "profile";
  contentId: string;
  score: number;
  reason?: string; // optional transparency: "Recommended because you follow X"
}

export interface FeedOptions {
  userId: string;
  limit?: number;
  cursor?: string; // for pagination
  feedType?: "for_you" | "following" | "trending";
}

export interface FeedResult {
  items: FeedItem[];
  nextCursor?: string;
}

export interface RecommendationEngine {
  readonly name: string;

  /**
   * Get a personalized feed for the user.
   * Combines interests, following, trending, recency, and diversity.
   */
  getFeed(opts: FeedOptions): Promise<FeedResult>;

  /**
   * Track a user interaction with content. Updates the user's interest profile.
   */
  trackInteraction(opts: {
    userId: string;
    contentType: string;
    contentId: string;
    action: string;
    topicSlug?: string;
    duration?: number;
  }): Promise<void>;

  /**
   * Mark content as "not interested" — reduces similar recommendations.
   */
  markNotInterested(opts: {
    userId: string;
    contentType: string;
    contentId: string;
    topicSlug?: string;
  }): Promise<void>;

  /**
   * Set the user's initial interests during onboarding.
   */
  setOnboardingInterests(userId: string, topicSlugs: string[]): Promise<void>;

  /**
   * Get the user's interest profile (admin/debug only — never exposed to normal users).
   */
  getInterestProfile(userId: string): Promise<{ topic: string; score: number }[]>;

  /**
   * Reset a user's recommendation profile (SUPER_ADMIN only).
   */
  resetUserProfile(userId: string): Promise<void>;

  /**
   * Reset all recommendation profiles (SUPER_ADMIN only).
   */
  resetAllProfiles(): Promise<void>;
}
