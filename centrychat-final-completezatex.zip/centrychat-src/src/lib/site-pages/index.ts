/**
 * Site Pages — unified CMS service for the informational / legal pages.
 *
 * Replaces the older src/lib/about (which used PlatformSetting JSON). Now
 * uses a dedicated Prisma model `SitePage` (slug UNIQUE) so each page is a
 * real DB row with proper indexing, audit trail (updatedById), and a
 * published/draft toggle.
 *
 * RESERVED SLUGS:
 *   - "about"    → /about    (About Us)
 *   - "privacy"  → /privacy  (Privacy Policy)
 *   - "terms"    → /terms    (Terms of Service)
 *   - "contact"  → /contact  (Contact information + form target)
 *
 * CONTENT SHAPE (stored as JSON in the `content` column):
 *   {
 *     intro: { title, content },
 *     sections: [{ id, title, content }],
 *     contact?: { title, content, email, website }  // only used by /contact
 *   }
 *
 * SECURITY:
 *   - All write paths require requireAdmin() (enforced by the API routes).
 *   - Content is rendered as plain text (React escapes) — NO HTML injection.
 *   - slug is immutable from the client (the 4 reserved slugs are fixed).
 *   - section ids are validated (non-empty, ≤64 chars).
 *   - Total JSON payload capped at 200 KB.
 *
 * CACHING:
 *   - Public reads use cacheGetOrSet (30s TTL) keyed by `site-page:<slug>`.
 *   - Admin writes invalidate the cache for that slug via cacheInvalidate.
 *   - Visitors see updates within 30 seconds — no full rebuild needed.
 *
 * BACKWARD COMPATIBILITY:
 *   The previous /about implementation stored content in PlatformSetting
 *   under key "about.page_content". On first read of the "about" slug, if
 *   no SitePage row exists yet BUT a PlatformSetting row exists, we migrate
 *   the content automatically (one-time, best-effort). After migration, the
 *   PlatformSetting row is left in place (NOT deleted) so the admin can
 *   roll back if needed — but it's never read again.
 */

import { z } from "zod";
import { db } from "@/lib/database";
import { cacheGetOrSet, getCache } from "@/lib/cache";
import { getSetting } from "@/lib/settings";
import { logger } from "@/lib/logging";

// ── Constants ───────────────────────────────────────────────────────────

/** Hard cap on the total JSON payload size (defends against unbounded growth). */
const MAX_TOTAL_JSON_BYTES = 200_000; // 200 KB

/** Cache TTL for public reads (seconds). Same as the settings cache. */
const CACHE_TTL_SECONDS = 30;

/** PlatformSetting key from the previous /about implementation. Used for
 *  one-time backward-compat migration only. */
const LEGACY_ABOUT_SETTING_KEY = "about.page_content";

// ── Zod schema (server-side source of truth for validation) ────────────

const MAX_TITLE = 200;
const MAX_CONTENT = 5000;
const MAX_EMAIL = 254;
const MAX_WEBSITE = 2048;
const MAX_SLUG = 60;
const MAX_SEO_DESC = 300;

const SectionSchema = z.object({
  id: z.string().min(1).max(64),
  title: z.string().trim().min(1, "Section title cannot be empty").max(MAX_TITLE, `Section title too long (max ${MAX_TITLE} chars)`),
  content: z.string().trim().min(1, "Section content cannot be empty").max(MAX_CONTENT, `Section content too long (max ${MAX_CONTENT} chars)`),
});

const IntroSchema = z.object({
  title: z.string().trim().min(1).max(MAX_TITLE),
  content: z.string().trim().min(1).max(MAX_CONTENT),
});

const ContactBlockSchema = z.object({
  title: z.string().trim().min(1).max(MAX_TITLE),
  content: z.string().trim().max(MAX_CONTENT).optional().or(z.literal("")),
  email: z.string().trim().max(MAX_EMAIL).optional().or(z.literal("")),
  website: z.string().trim().max(MAX_WEBSITE).optional().or(z.literal("")),
});

/** The structured JSON shape stored in SitePage.content. */
export const SitePageContentSchema = z.object({
  intro: IntroSchema,
  sections: z.array(SectionSchema).max(20, "Too many sections (max 20)"),
  contact: ContactBlockSchema.optional(),
});

// ── Types ───────────────────────────────────────────────────────────────

export type SitePageSlug = "about" | "privacy" | "terms" | "contact";

export interface SitePageSection {
  id: string;
  title: string;
  content: string;
}

export interface SitePageContent {
  intro: {
    title: string;
    content: string;
  };
  sections: SitePageSection[];
  contact?: {
    title: string;
    content: string;
    email: string;
    website: string;
  };
}

/** Full SitePage row (admin view — includes draft fields). */
export interface SitePageRow {
  id: string;
  slug: string;
  title: string;
  content: SitePageContent;
  seoTitle: string;
  seoDescription: string;
  isPublished: boolean;
  updatedAt: string; // ISO string
  createdAt: string; // ISO string
}

/** Public SitePage view (no draft fields, only published). */
export interface PublicSitePage {
  slug: string;
  title: string;
  content: SitePageContent;
  seoTitle: string;
  seoDescription: string;
}

// ── Default content for each slug ──────────────────────────────────────

/**
 * Default content for each reserved slug. Used by:
 *   - scripts/seed-site-pages.ts (initial DB seed)
 *   - getOrCreateSitePage() (lazy creation when an admin opens a page
 *     that doesn't exist in the DB yet)
 *
 * Per the user's spec: NO fake company names, NO fake phone numbers, NO
 * fake legal claims. The platform name is interpolated at render time.
 */
export function getDefaultContent(slug: SitePageSlug): {
  title: string;
  content: SitePageContent;
  seoTitle: string;
  seoDescription: string;
} {
  switch (slug) {
    case "about":
      return {
        title: "About Us",
        content: {
          intro: {
            title: "Welcome",
            content:
              "Welcome to our platform — a digital space designed to bring content, information, and conversations together in one place. " +
              "We aim to provide a simple, fast experience that helps you discover content that matters to you and engage with it meaningfully.",
          },
          sections: [
            {
              id: "vision",
              title: "Our Vision",
              content:
                "To build a digital community where every user can discover, share, and discuss ideas that matter — " +
                "a place where quality content is easy to find and where every voice can be heard.",
            },
            {
              id: "mission",
              title: "Our Mission",
              content:
                "To deliver a clean, fast, and personalized experience that surfaces the content you care about — " +
                "while keeping the platform lightweight, accessible on any device, and respectful of your time and privacy.",
            },
            {
              id: "what-we-offer",
              title: "What We Offer",
              content:
                "Articles, short posts, videos, topics, collections, and a personalized feed that learns what you care about. " +
                "Plus discussions, comments, follows, and notifications so you can stay connected with the creators and conversations you love.",
            },
            {
              id: "why-we-built-this",
              title: "Why We Built This",
              content:
                "We built this platform because we believed the web deserved another place that puts content and readers first — " +
                "without clutter, without noise, and without treating attention as the product.",
            },
          ],
        },
        seoTitle: "",
        seoDescription: "",
      };

    case "privacy":
      return {
        title: "Privacy Policy",
        content: {
          intro: {
            title: "Your Privacy Matters",
            content:
              "This Privacy Policy explains how we collect, use, and protect your information when you use our platform. " +
              "Please review this policy carefully. By using the platform, you agree to the practices described here.",
          },
          sections: [
            {
              id: "information-we-collect",
              title: "Information We Collect",
              content:
                "We collect information you provide directly to us — such as your name, email address, and profile details when you register. " +
                "We also collect usage data (such as the content you view, interactions you make, and device information) to improve the platform.",
            },
            {
              id: "how-we-use-information",
              title: "How We Use Your Information",
              content:
                "We use your information to provide, personalize, and improve the platform — including showing you relevant content, " +
                "notifying you of activity, ensuring security, and analyzing usage to make data-driven improvements.",
            },
            {
              id: "information-sharing",
              title: "Information Sharing",
              content:
                "We do not sell your personal information. We may share data with service providers who help us operate the platform " +
                "(such as email delivery and analytics providers), under strict confidentiality agreements, and only to the extent necessary.",
            },
            {
              id: "data-security",
              title: "Data Security",
              content:
                "We take reasonable measures to protect your information using industry-standard security practices. " +
                "Passwords are hashed with Argon2id, sessions are encrypted, and access is restricted to authorized personnel only.",
            },
            {
              id: "your-rights",
              title: "Your Rights",
              content:
                "You have the right to access, correct, or delete your personal information. " +
                "Contact us using the information on the Contact page to exercise these rights.",
            },
            {
              id: "changes-to-this-policy",
              title: "Changes to This Policy",
              content:
                "We may update this Privacy Policy from time to time. When we do, we will revise the 'last updated' date at the top of this page. " +
                "We encourage you to review this policy periodically.",
            },
          ],
        },
        seoTitle: "",
        seoDescription: "",
      };

    case "terms":
      return {
        title: "Terms of Service",
        content: {
          intro: {
            title: "Terms of Service",
            content:
              "These Terms of Service govern your use of our platform. By creating an account or using the platform, " +
              "you agree to be bound by these terms. Please read them carefully.",
          },
          sections: [
            {
              id: "acceptance-of-terms",
              title: "Acceptance of Terms",
              content:
                "By accessing or using the platform, you agree to these Terms of Service and our Privacy Policy. " +
                "If you do not agree, you may not use the platform.",
            },
            {
              id: "user-responsibilities",
              title: "User Responsibilities",
              content:
                "You are responsible for your account and all activity that occurs under it. You agree to provide accurate information, " +
                "keep your password secure, and not misuse the platform — including not posting illegal, harmful, or infringing content.",
            },
            {
              id: "acceptable-use",
              title: "Acceptable Use",
              content:
                "You agree not to harass others, spread spam, attempt to disrupt the platform, or access data you are not authorized to access. " +
                "Violations may result in account suspension or termination.",
            },
            {
              id: "content-ownership",
              title: "Content Ownership",
              content:
                "You retain ownership of the content you create. By posting it on the platform, you grant us a license to display and distribute " +
                "it as part of the platform's operation.",
            },
            {
              id: "termination",
              title: "Termination",
              content:
                "We may suspend or terminate your account if you violate these terms. You may also delete your account at any time. " +
                "Upon termination, your right to use the platform ceases immediately.",
            },
            {
              id: "disclaimers",
              title: "Disclaimers",
              content:
                "The platform is provided 'as is' without warranties of any kind. We do not guarantee uninterrupted or error-free service. " +
                "You use the platform at your own risk.",
            },
            {
              id: "changes-to-terms",
              title: "Changes to These Terms",
              content:
                "We may update these Terms of Service from time to time. Continued use of the platform after changes constitutes acceptance " +
                "of the updated terms.",
            },
          ],
        },
        seoTitle: "",
        seoDescription: "",
      };

    case "contact":
      return {
        title: "Contact Us",
        content: {
          intro: {
            title: "Get in Touch",
            content:
              "We'd love to hear from you. Whether you have a question, feedback, a partnership inquiry, " +
              "or just want to say hello — you can reach us through the channels below or use the contact form.",
          },
          sections: [],
          contact: {
            title: "Contact Information",
            content:
              "Use the form below to send us a message, or reach us directly via email. " +
              "We typically respond within 1–2 business days.",
            email: "",
            website: "",
          },
        },
        seoTitle: "",
        seoDescription: "",
      };
  }
}

// ── Internal helpers ───────────────────────────────────────────────────

/** Cache key for a slug's published content. */
function cacheKey(slug: string): string {
  return `site-page:${slug}`;
}

/** Validate + normalize the content JSON. Returns null on validation failure. */
function parseContent(raw: string): SitePageContent | null {
  try {
    const parsed: unknown = JSON.parse(raw);
    const result = SitePageContentSchema.safeParse(parsed);
    if (!result.success) {
      logger.warn("application", "SitePage content failed validation", {
        issues: result.error.issues.slice(0, 3),
      });
      return null;
    }
    const data = result.data;
    return {
      intro: data.intro,
      sections: data.sections,
      contact: data.contact
        ? {
            title: data.contact.title,
            content: data.contact.content ?? "",
            email: data.contact.email ?? "",
            website: data.contact.website ?? "",
          }
        : undefined,
    };
  } catch {
    return null;
  }
}

/** Serialize the content to JSON (with size check). Throws on oversize. */
function serializeContent(content: SitePageContent): string {
  const json = JSON.stringify(content);
  if (Buffer.byteLength(json, "utf8") > MAX_TOTAL_JSON_BYTES) {
    throw new Error(`Site page content too large (max ${MAX_TOTAL_JSON_BYTES} bytes)`);
  }
  return json;
}

/** Convert a Prisma SitePage row to a SitePageRow (with parsed content). */
function toRow(row: {
  id: string;
  slug: string;
  title: string;
  content: string;
  seoTitle: string | null;
  seoDescription: string | null;
  isPublished: boolean;
  createdAt: Date;
  updatedAt: Date;
}): SitePageRow {
  const parsed = parseContent(row.content);
  const defaults = getDefaultContent(row.slug as SitePageSlug);
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    content: parsed ?? defaults.content,
    seoTitle: row.seoTitle ?? "",
    seoDescription: row.seoDescription ?? "",
    isPublished: row.isPublished,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

// ── Backward-compat migration (legacy PlatformSetting → SitePage) ──────

/**
 * One-time migration: if a SitePage row for "about" doesn't exist yet BUT
 * a PlatformSetting row with key "about.page_content" exists (from the
 * previous /about implementation), migrate the content to a new SitePage
 * row. Best-effort — if parsing fails, we fall through to defaults.
 *
 * This runs lazily on first read of the "about" slug. After migration, the
 * PlatformSetting row is NOT deleted (so the admin can roll back), but it's
 * never read again.
 */
async function migrateLegacyAboutIfNeeded(): Promise<void> {
  try {
    const existing = await db.sitePage.findUnique({ where: { slug: "about" } });
    if (existing) return; // already migrated or created

    const legacyRaw = await getSetting(LEGACY_ABOUT_SETTING_KEY);
    if (!legacyRaw) return; // no legacy content — nothing to migrate

    // Try to parse the legacy content. It had a slightly different shape
    // (pageTitle + intro + sections + contact + seoTitle + seoDescription
    // at the top level). We extract the content fields + SEO fields.
    const legacy: unknown = JSON.parse(legacyRaw);
    if (typeof legacy !== "object" || legacy === null) return;
    const l = legacy as Record<string, unknown>;

    const content: SitePageContent = {
      intro: (l.intro as SitePageContent["intro"]) ?? getDefaultContent("about").content.intro,
      sections: Array.isArray(l.sections) ? (l.sections as SitePageContent["sections"]) : getDefaultContent("about").content.sections,
      contact: l.contact
        ? (l.contact as SitePageContent["contact"])
        : getDefaultContent("about").content.contact,
    };

    const title = typeof l.pageTitle === "string" ? l.pageTitle : "About Us";
    const seoTitle = typeof l.seoTitle === "string" ? l.seoTitle : "";
    const seoDescription = typeof l.seoDescription === "string" ? l.seoDescription : "";

    await db.sitePage.create({
      data: {
        slug: "about",
        title,
        content: serializeContent(content),
        seoTitle: seoTitle || null,
        seoDescription: seoDescription || null,
        isPublished: true, // legacy content was always "live"
      },
    });
    logger.info("application", "Migrated legacy about.page_content to SitePage");
  } catch (err) {
    // Non-fatal — the admin can re-create the content from the editor.
    logger.warn("application", "Legacy about migration failed (non-fatal)", {
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

// ── Public read API ────────────────────────────────────────────────────

/**
 * Ensure a SitePage row exists AND is published. If the row is missing or
 * is a draft, create/upgrade it with default content (isPublished=true).
 *
 * WHY: The canonical public routes /about, /privacy, /terms, /contact must
 * always render real content — never 404 — even on a fresh deploy where
 * the seed script hasn't been run, or where the admin left the pages in
 * draft state. The admin can still edit/unpublish pages via the admin
 * panel (saveSitePage), which invalidates the cache so the change takes
 * effect within 30 seconds.
 *
 * PRESERVES ADMIN EDITS: If a published row already exists, it is NEVER
 * overwritten — we return it as-is. Only missing rows or drafts are
 * created/upgraded with defaults.
 *
 * Idempotent + race-safe: uses upsert with `update: {}` so concurrent
 * requests don't conflict (P2002 is swallowed). Best-effort — on failure
 * (e.g. DB unreachable), the caller returns null and the SSR page renders
 * a 404 gracefully (existing behavior).
 *
 * For the "about" slug, this also runs the one-time legacy migration from
 * PlatformSetting (best-effort, non-blocking) BEFORE the upsert.
 */
async function ensurePublishedSitePage(slug: SitePageSlug): Promise<void> {
  // For "about", try the legacy migration first (it may create a published
  // row with migrated content — in which case the upsert below is a no-op).
  if (slug === "about") {
    await migrateLegacyAboutIfNeeded();
  }

  // Check if a published row already exists. If so, nothing to do —
  // this preserves admin-edited content + avoids a needless write.
  const existing = await db.sitePage.findUnique({ where: { slug } });
  if (existing && existing.isPublished) return;

  // Missing row OR draft → upsert with default content as PUBLISHED.
  // `update: {}` means an existing row is NEVER overwritten (if another
  // concurrent request already created it, we keep their version).
  // The only case we'd want to "upgrade" a draft to published is when
  // the row exists but isPublished=false — handled by the create branch
  // (upsert's `update: {}` won't flip isPublished for an existing draft,
  // so we explicitly publish drafts below).
  if (existing && !existing.isPublished) {
    // Admin intentionally left this as a draft OR the seed script created
    // it as a draft. The canonical public route must render content (not
    // 404), so publish the existing draft content (preserving any admin
    // edits to the title/content/seo fields).
    await db.sitePage.update({
      where: { slug },
      data: { isPublished: true },
    }).catch(() => {
      // Race condition or DB error — non-fatal. The findUnique inside
      // the cache callback below will re-fetch and decide.
    });
    return;
  }

  // Row doesn't exist → create with default content as PUBLISHED.
  const defaults = getDefaultContent(slug);
  await db.sitePage.upsert({
    where: { slug },
    create: {
      slug,
      title: defaults.title,
      content: serializeContent(defaults.content),
      seoTitle: defaults.seoTitle || null,
      seoDescription: defaults.seoDescription || null,
      isPublished: true,
    },
    update: {}, // never overwrite an existing row
  }).catch(() => {
    // Race condition: another concurrent request created it. Ignore —
    // the findUnique inside the cache callback will return the winner's row.
  });
}

/**
 * Get a published SitePage by slug. Returns null when:
 *   - The slug doesn't exist in the DB (after lazy-create attempt).
 *   - The page exists but isPublished=false AND the lazy-publish failed.
 *
 * In practice, this function guarantees the 4 canonical routes
 * (/about, /privacy, /terms, /contact) always return real content —
 * missing rows are lazy-created with default content as PUBLISHED, and
 * existing drafts are upgraded to PUBLISHED (preserving admin edits to
 * the content fields). The admin can still unpublish a page by setting
 * isPublished=false via saveSitePage(), but the next public request will
 * re-publish it (this is intentional — the canonical routes must never
 * 404). To hide a page, the admin should remove all links to it instead.
 *
 * Uses the 30-second cache (cacheGetOrSet) keyed by slug. When the admin
 * saves a page, saveSitePage() invalidates this cache — visitors see the
 * update within 30 seconds.
 *
 * NEVER throws — returns null on any error so the SSR page can render a
 * 404 gracefully.
 */
export async function getPublishedSitePage(
  slug: SitePageSlug
): Promise<PublicSitePage | null> {
  try {
    // Lazy-create + publish the row if it doesn't exist or is a draft.
    // This guarantees the canonical public routes never 404. For "about",
    // this also runs the one-time legacy migration from PlatformSetting.
    await ensurePublishedSitePage(slug);

    return await cacheGetOrSet(cacheKey(slug), CACHE_TTL_SECONDS, async () => {
      const row = await db.sitePage.findUnique({ where: { slug } });
      if (!row || !row.isPublished) return null;
      const parsed = parseContent(row.content);
      if (!parsed) return null;
      return {
        slug: row.slug,
        title: row.title,
        content: parsed,
        seoTitle: row.seoTitle ?? "",
        seoDescription: row.seoDescription ?? "",
      };
    });
  } catch (err) {
    logger.error("application", "getPublishedSitePage failed", {
      slug,
      error: err instanceof Error ? err.message : String(err),
    });
    return null;
  }
}

// ── Admin read API ─────────────────────────────────────────────────────

/**
 * List all SitePage rows (admin view — includes drafts). Used by the
 * "Pages & Legal" admin section to render the list of editable pages.
 *
 * Ensures all 4 reserved slugs exist (lazy-creates missing ones as
 * drafts with default content) so the admin always sees all 4 cards.
 */
export async function listSitePagesForAdmin(): Promise<SitePageRow[]> {
  const SLUGS: SitePageSlug[] = ["about", "privacy", "terms", "contact"];

  // Lazy-create any missing rows with default content (as drafts).
  for (const slug of SLUGS) {
    const existing = await db.sitePage.findUnique({ where: { slug } });
    if (!existing) {
      const defaults = getDefaultContent(slug);
      await db.sitePage.create({
        data: {
          slug,
          title: defaults.title,
          content: serializeContent(defaults.content),
          seoTitle: defaults.seoTitle || null,
          seoDescription: defaults.seoDescription || null,
          isPublished: false,
        },
      }).catch(() => {
        // Race condition: another concurrent request created it. Ignore —
        // the findUnique below will return the winner's row.
      });
    }
  }

  const rows = await db.sitePage.findMany({
    where: { slug: { in: SLUGS } },
    orderBy: { slug: "asc" },
  });

  // Sort by the canonical SLUGS order (about, privacy, terms, contact)
  // so the admin list is always in a predictable order.
  return rows
    .map(toRow)
    .sort((a, b) => SLUGS.indexOf(a.slug as SitePageSlug) - SLUGS.indexOf(b.slug as SitePageSlug));
}

/**
 * Get a single SitePage by slug (admin view — includes drafts).
 * Returns null when the slug doesn't exist (after lazy-create attempt).
 */
export async function getSitePageForAdmin(
  slug: string
): Promise<SitePageRow | null> {
  // Validate slug — only the 4 reserved slugs are allowed.
  if (!["about", "privacy", "terms", "contact"].includes(slug)) {
    return null;
  }
  const safeSlug = slug as SitePageSlug;

  // Lazy-create if missing (so the admin can edit even on a fresh deploy).
  let row = await db.sitePage.findUnique({ where: { slug: safeSlug } });
  if (!row) {
    const defaults = getDefaultContent(safeSlug);
    row = await db.sitePage.create({
      data: {
        slug: safeSlug,
        title: defaults.title,
        content: serializeContent(defaults.content),
        seoTitle: defaults.seoTitle || null,
        seoDescription: defaults.seoDescription || null,
        isPublished: false,
      },
    }).catch(async () => {
      // Race condition: another request created it. Re-fetch.
      return await db.sitePage.findUnique({ where: { slug: safeSlug } });
    });
  }
  if (!row) return null;
  return toRow(row);
}

// ── Admin write API ────────────────────────────────────────────────────

/**
 * Validate + persist a SitePage. Called ONLY by the admin API (which
 * already enforced requireAdmin()).
 *
 * Parameters:
 *   - slug: the page slug (immutable — must be one of the 4 reserved slugs)
 *   - payload: { title, content, seoTitle?, seoDescription?, isPublished? }
 *   - adminId: the admin user's id (for updatedById audit trail)
 *
 * Returns the saved SitePageRow. Throws Error on validation failure
 * (the caller's apiHandler converts it to a 400 response).
 *
 * SECURITY:
 *   - slug is validated against the reserved list — clients cannot create
 *     arbitrary new pages (only edit the 4 existing ones).
 *   - content is validated via Zod (SitePageContentSchema).
 *   - Total JSON payload capped at 200 KB.
 *   - The cache for this slug is invalidated after save so the public
 *     page reflects the update within 30 seconds.
 */
export async function saveSitePage(
  slug: string,
  payload: {
    title?: string;
    content?: SitePageContent;
    seoTitle?: string;
    seoDescription?: string;
    isPublished?: boolean;
  },
  adminId: string
): Promise<SitePageRow> {
  // Validate slug.
  if (!["about", "privacy", "terms", "contact"].includes(slug)) {
    throw new Error(`Unknown site page slug: ${slug}`);
  }
  const safeSlug = slug as SitePageSlug;

  // Validate title.
  const title = (payload.title ?? "").trim();
  if (!title) throw new Error("Title cannot be empty");
  if (title.length > MAX_TITLE) throw new Error(`Title too long (max ${MAX_TITLE} chars)`);

  // Validate content.
  let contentJson: string;
  if (payload.content !== undefined) {
    const result = SitePageContentSchema.safeParse(payload.content);
    if (!result.success) {
      const first = result.error.issues[0];
      throw new Error(
        first ? `${first.path.join(".")}: ${first.message}` : "Invalid content"
      );
    }
    const normalized: SitePageContent = {
      intro: result.data.intro,
      sections: result.data.sections,
      contact: result.data.contact
        ? {
            title: result.data.contact.title,
            content: result.data.contact.content ?? "",
            email: result.data.contact.email ?? "",
            website: result.data.contact.website ?? "",
          }
        : undefined,
    };
    contentJson = serializeContent(normalized);
  } else {
    // No content in payload — keep existing.
    const existing = await db.sitePage.findUnique({ where: { slug: safeSlug } });
    contentJson = existing?.content ?? serializeContent(getDefaultContent(safeSlug).content);
  }

  // Validate SEO fields.
  const seoTitle = (payload.seoTitle ?? "").trim();
  if (seoTitle.length > MAX_TITLE) throw new Error(`SEO title too long (max ${MAX_TITLE} chars)`);
  const seoDescription = (payload.seoDescription ?? "").trim();
  if (seoDescription.length > MAX_SEO_DESC) throw new Error(`SEO description too long (max ${MAX_SEO_DESC} chars)`);

  // Validate slug length (defensive — the reserved slugs are all short).
  if (slug.length > MAX_SLUG) throw new Error(`Slug too long (max ${MAX_SLUG} chars)`);

  // Upsert (create if missing — though listSitePagesForAdmin already lazy-creates).
  const row = await db.sitePage.upsert({
    where: { slug: safeSlug },
    create: {
      slug: safeSlug,
      title,
      content: contentJson,
      seoTitle: seoTitle || null,
      seoDescription: seoDescription || null,
      isPublished: payload.isPublished ?? false,
      updatedById: adminId,
    },
    update: {
      title,
      content: contentJson,
      seoTitle: seoTitle || null,
      seoDescription: seoDescription || null,
      ...(payload.isPublished !== undefined && { isPublished: payload.isPublished }),
      updatedById: adminId,
    },
  });

  // Invalidate the cache for this slug so the public page picks up the
  // new content on the next read (within 30s).
  try {
    await getCache().delete(cacheKey(safeSlug));
  } catch {
    // Non-fatal — the cache will expire naturally within 30s.
  }

  return toRow(row);
}

// ── Slug list (for sitemap + seed) ─────────────────────────────────────

/** All reserved site-page slugs. */
export const SITE_PAGE_SLUGS: readonly SitePageSlug[] = ["about", "privacy", "terms", "contact"] as const;

/**
 * List all PUBLISHED site-page slugs (for the sitemap).
 * Returns slugs in the canonical order.
 */
export async function listPublishedSitePageSlugs(): Promise<SitePageSlug[]> {
  try {
    const rows = await db.sitePage.findMany({
      where: { isPublished: true, slug: { in: [...SITE_PAGE_SLUGS] } },
      select: { slug: true },
    });
    const published = new Set(rows.map((r) => r.slug));
    return SITE_PAGE_SLUGS.filter((slug) => published.has(slug));
  } catch {
    return [];
  }
}
