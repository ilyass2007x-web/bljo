/**
 * Server-side SSR helpers for the site pages.
 *
 * Shared by src/app/{about,privacy,terms,contact}/page.tsx — each route
 * file is a thin wrapper that calls these helpers with its slug.
 *
 * Why a shared helper (not a single dynamic route)?
 *   Next.js App Router prefers explicit route files over [...slug] dynamic
 *   routes for static-content pages. Explicit files give:
 *     - Better build-time analysis (each route shows up in the build output)
 *     - Clearer intent (a reader sees /about/page.tsx and knows what it is)
 *     - No risk of a wildcard route shadowing other top-level routes
 *   The duplication across the 4 page.tsx files is minimal (3 lines each)
 *   because all the real logic lives here.
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPublishedSitePage, type SitePageSlug, type PublicSitePage } from "./index";
import { getSetting } from "@/lib/settings";
import { loadBaseUrl, serializeJsonLd } from "@/lib/seo/article";

/**
 * Fetch the published page + platform name + base URL in parallel.
 * Returns null when the page is not found / not published — the caller
 * calls notFound() to produce a 404.
 *
 * NEVER throws — wraps everything in try/catch so a DB outage renders a
 * 404 instead of crashing the page.
 */
export async function fetchSitePageForSSR(
  slug: SitePageSlug
): Promise<{
  page: PublicSitePage;
  platformName: string;
  baseUrl: string;
} | null> {
  try {
    const [page, platformName, baseUrl] = await Promise.all([
      getPublishedSitePage(slug),
      getSetting("platform.name").then((n) => n ?? "Platform"),
      loadBaseUrl().catch(() => ""),
    ]);
    if (!page) return null;
    return { page, platformName, baseUrl };
  } catch {
    return null;
  }
}

/**
 * Build the Next.js Metadata object for a site page.
 *
 * - title: seoTitle (if set) || "<pageTitle> | <platformName>"
 * - description: seoDescription (if set) || intro.content (truncated to 160)
 * - canonical: <baseUrl>/<slug>
 * - OG + Twitter Card with the platform's default OG image
 * - robots: index, follow (explicit — these are real public pages)
 */
export function buildSitePageMetadata(
  slug: SitePageSlug,
  page: PublicSitePage,
  platformName: string,
  baseUrl: string
): Metadata {
  const title = page.seoTitle || `${page.title} | ${platformName}`;
  const description =
    page.seoDescription ||
    (page.content.intro.content.length > 160
      ? page.content.intro.content.slice(0, 157).trimEnd() + "..."
      : page.content.intro.content);
  const canonical = `${baseUrl}/${slug}`;
  const ogImage = `${baseUrl}/og-default.png`;

  return {
    title,
    description,
    alternates: {
      canonical,
    },
    // EXPLICITLY indexable — these are real public pages.
    robots: {
      index: true,
      follow: true,
    },
    openGraph: {
      title,
      description,
      url: canonical,
      siteName: platformName,
      type: "website",
      images: [{ url: ogImage }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [ogImage],
    },
  };
}

/**
 * Build the JSON-LD structured data for a site page.
 * Returns two scripts: WebPage + BreadcrumbList.
 *
 * Uses serializeJsonLd (escapes </script> sequences) to prevent JSON-LD XSS.
 */
export function buildSitePageJsonLd(
  slug: SitePageSlug,
  page: PublicSitePage,
  platformName: string,
  baseUrl: string
): { webPageHtml: string; breadcrumbHtml: string } {
  const pageUrl = `${baseUrl}/${slug}`;

  const breadcrumb = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: platformName,
        item: baseUrl || "/",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: page.title,
        item: pageUrl,
      },
    ],
  };

  const webPage = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    name: page.title,
    description:
      page.seoDescription || page.content.intro.content.slice(0, 200),
    url: pageUrl,
    isPartOf: {
      "@type": "WebSite",
      name: platformName,
      url: baseUrl || "/",
    },
    breadcrumb: {
      "@type": "BreadcrumbList",
      itemListElement: breadcrumb.itemListElement,
    },
  };

  return {
    webPageHtml: serializeJsonLd(webPage),
    breadcrumbHtml: serializeJsonLd(breadcrumb),
  };
}

/**
 * Render helper: fetch + 404 if not found. Returns the data + JSON-LD HTML
 * strings. Used by each page.tsx to avoid duplicating the fetch + notFound
 * logic across 4 files.
 */
export async function prepareSitePage(slug: SitePageSlug) {
  const data = await fetchSitePageForSSR(slug);
  if (!data) {
    notFound();
  }
  const jsonLd = buildSitePageJsonLd(slug, data.page, data.platformName, data.baseUrl);
  return { ...data, jsonLd };
}
