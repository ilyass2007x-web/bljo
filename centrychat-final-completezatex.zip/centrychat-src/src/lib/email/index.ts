/**
 * Email abstraction.
 *
 * Default provider: console (logs to stdout — fine for dev / self-hosted MVP).
 * Switching: set EMAIL_PROVIDER env var. Implement the provider in
 * lib/email/providers/<name>.ts. Application code never imports a concrete provider.
 *
 * Available providers:
 *  - console (default) — logs to stdout, never sends real email
 *  - resend           — uses Resend API (requires RESEND_API_KEY)
 *
 * Resend configuration (set in Netlify Environment Variables — never in netlify.toml):
 *   - RESEND_API_KEY     (required when EMAIL_PROVIDER=resend)
 *   - RESEND_FROM_EMAIL  (optional — defaults to Resend's onboarding@resend.dev
 *                         test sender; set to your own domain once verified)
 */

export interface EmailMessage {
  to: string;
  subject: string;
  html: string;
  text: string;
}

export interface EmailProvider {
  readonly name: string;
  send(message: EmailMessage): Promise<void>;
}

class ConsoleEmailProvider implements EmailProvider {
  readonly name = "console";

  async send(message: EmailMessage): Promise<void> {
    console.log(
      `\n[EMAIL:${this.name}] → ${message.to}\n  subject: ${message.subject}\n  text: ${message.text}\n`
    );
  }
}

let cached: EmailProvider | null = null;

export function getEmailProvider(): EmailProvider {
  if (cached) return cached;
  const provider = (process.env.EMAIL_PROVIDER ?? "console").toLowerCase();
  switch (provider) {
    case "console":
    case "":
      cached = new ConsoleEmailProvider();
      break;
    case "resend": {
      // Lazy-import so the `resend` package is never loaded in the browser
      // bundle even if this file were transitively imported client-side.
      // (It isn't, but defense in depth is cheap.)
      const { ResendEmailProvider } = require("./providers/resend") as {
        ResendEmailProvider: new () => EmailProvider;
      };
      cached = new ResendEmailProvider();
      break;
    }
    default:
      throw new Error(`Unknown email provider: ${provider}`);
  }
  return cached;
}

/**
 * Reset the cached provider. Useful for tests that change env vars between
 * cases. Not used in production.
 */
export function _resetEmailProviderCacheForTests(): void {
  cached = null;
}

export interface AppUrlConfig {
  baseUrl: string;
}

/**
 * Resolve the public base URL of the deployed app, used for building
 * links inside transactional emails (verification, password reset, etc.).
 *
 * Resolution order (first non-empty wins):
 *   1. `NEXT_PUBLIC_APP_BASE_URL` env var (admin-configured canonical URL).
 *   2. `APP_BASE_URL` env var (alternate name — useful for server-only).
 *   3. `request` origin (when called from an API route that has the
 *      Request object available — derived from `Host` + `X-Forwarded-Proto`).
 *   4. `http://localhost:3000` (last-resort dev fallback).
 *
 * EMAIL-LINK CORRECTNESS:
 *   In production on Netlify, the env var MUST be set to the canonical
 *   URL (e.g. `https://centrychat.netlify.app`). If it is NOT set,
 *   email links would point to `http://localhost:3000` — clicking them
 *   would fail for the user. The `request` fallback (step 3) prevents
 *   this by deriving the actual deployment origin from the incoming
 *   request's Host header.
 *
 * SECURITY:
 *   The Host header is set by the deployment's edge (Netlify's load
 *   balancer) — an attacker CANNOT spoof it in a browser context
 *   (browsers refuse to send arbitrary Host headers, and TLS SNI/cert
 *   validation would fail). The X-Forwarded-Proto header is also set
 *   by the trusted edge. We do NOT trust user-supplied query params
 *   or body fields for the URL.
 *
 * @param request optional Request object — pass it when calling from
 *   an API route so we can fall back to the request-derived origin.
 */
export function getAppBaseUrl(request?: Request): string {
  const env = process.env.NEXT_PUBLIC_APP_BASE_URL ?? process.env.APP_BASE_URL;
  if (env && env.trim().length > 0) {
    return env.trim();
  }
  if (request) {
    try {
      const host = request.headers.get("host") ?? request.headers.get("x-forwarded-host");
      const proto =
        request.headers.get("x-forwarded-proto") ??
        (request.url.startsWith("https://") ? "https" : "http");
      if (host && host.length > 0) {
        // Strip any port from proto — proto is just the scheme.
        const cleanProto = proto.split(",")[0]!.trim().toLowerCase();
        return `${cleanProto}://${host}`;
      }
    } catch {
      // Ignore — fall through to dev fallback.
    }
  }
  return "http://localhost:3000";
}

// ---------------------------------------------------------------------------
// Reusable email templates — called from auth flows, notifications, admin.
// Each function renders a clean HTML + text version of the email and routes
// through getEmailProvider() so the choice of provider (console/resend/...)
// stays centralized.
// ---------------------------------------------------------------------------

/**
 * Get the configured "from" display name. Override with RESEND_FROM_NAME.
 */
function getFromName(): string {
  return process.env.RESEND_FROM_NAME ?? "SentryChat";
}

/**
 * Standard email wrapper — gives every email the same look (header, footer,
 * brand color). Used by all templates below.
 */
function wrapEmail(opts: {
  title: string;
  preheader?: string;
  bodyHtml: string;
  bodyText: string;
  baseUrl?: string;
}): { html: string; text: string } {
  const { title, preheader, bodyHtml, bodyText } = opts;
  const brand = getFromName();
  const baseUrl = opts.baseUrl ?? getAppBaseUrl();
  const year = new Date().getFullYear();
  const preheaderHtml = preheader
    ? `<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent">${preheader}</div>`
    : "";
  return {
    html: `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)}</title></head><body style="margin:0;padding:0;background:#f4f4f5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif">
${preheaderHtml}
<table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="background:#f4f4f5;padding:24px 8px">
  <tr><td align="center">
    <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="max-width:560px;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.08)">
      <tr><td style="background:#0f172a;color:#ffffff;padding:18px 24px;text-align:center">
        <span style="font-size:16px;font-weight:600;letter-spacing:0.3px">${escapeHtml(brand)}</span>
      </td></tr>
      <tr><td style="padding:28px 24px;color:#0f172a">
        <h1 style="margin:0 0 12px;font-size:20px;font-weight:600">${escapeHtml(title)}</h1>
        ${bodyHtml}
      </td></tr>
      <tr><td style="padding:0 24px 24px;color:#94a3b8;font-size:12px;text-align:center;border-top:1px solid #e2e8f0;padding-top:16px">
        <p style="margin:0 0 4px">© ${year} ${escapeHtml(brand)}. All rights reserved.</p>
        <p style="margin:0"><a href="${escapeHtml(baseUrl)}" style="color:#64748b;text-decoration:none">${escapeHtml(baseUrl)}</a></p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>`,
    text: `${title}\n\n${bodyText}\n\n— ${brand}\n${baseUrl}\n`,
  };
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// ---------------------------------------------------------------------------
// Templates
// ---------------------------------------------------------------------------

/** 1. Email verification (registration) */
export async function sendVerificationEmail(
  to: string,
  token: string,
  opts?: { request?: Request }
): Promise<void> {
  const baseUrl = getAppBaseUrl(opts?.request);
  const link = `${baseUrl}/?view=verify-email&token=${token}`;
  const wrapped = wrapEmail({
    title: "Verify your email address",
    preheader: "Confirm your email to activate your account",
    baseUrl,
    bodyHtml: `
      <p style="margin:0 0 12px;line-height:1.5;color:#475569">Welcome! Click the button below to verify your email address. This link expires in 24 hours and can only be used once.</p>
      <p style="margin:18px 0;text-align:center">
        <a href="${escapeHtml(link)}" style="display:inline-block;padding:12px 22px;background:#0f172a;color:#ffffff;border-radius:8px;text-decoration:none;font-weight:600">Verify email</a>
      </p>
      <p style="margin:18px 0 0;font-size:13px;color:#94a3b8">Or paste this link into your browser: <a href="${escapeHtml(link)}" style="color:#0ea5e9;word-break:break-all">${escapeHtml(link)}</a></p>
      <p style="margin:14px 0 0;font-size:12px;color:#94a3b8">If you did not create an account, you can safely ignore this email.</p>
    `,
    bodyText: `Welcome! Verify your email by visiting the link below (expires in 24 hours):\n${link}\n\nIf you did not create an account, you can ignore this email.`,
  });
  await getEmailProvider().send({
    to,
    subject: "Verify your email address",
    html: wrapped.html,
    text: wrapped.text,
  });
}

/** 2. Verification code / OTP (for 2FA, email-only login, etc.) */
export async function sendOtpEmail(
  to: string,
  code: string,
  opts?: { purpose?: string }
): Promise<void> {
  const purpose = opts?.purpose ?? "verify your identity";
  const wrapped = wrapEmail({
    title: "Your verification code",
    preheader: `Use this code to ${purpose}`,
    bodyHtml: `
      <p style="margin:0 0 12px;line-height:1.5;color:#475569">Use the code below to ${escapeHtml(purpose)}. This code expires in 10 minutes.</p>
      <p style="margin:18px 0;text-align:center">
        <span style="display:inline-block;padding:14px 28px;background:#f1f5f9;color:#0f172a;border-radius:8px;font-size:28px;font-weight:700;letter-spacing:4px;font-family:'SF Mono','Menlo',monospace">${escapeHtml(code)}</span>
      </p>
      <p style="margin:18px 0 0;font-size:12px;color:#94a3b8">If you did not request this code, you can safely ignore this email.</p>
    `,
    bodyText: `Use the code below to ${purpose} (expires in 10 minutes):\n\n${code}\n\nIf you did not request this code, you can ignore this email.`,
  });
  await getEmailProvider().send({
    to,
    subject: `Your verification code: ${code}`,
    html: wrapped.html,
    text: wrapped.text,
  });
}

/** 3. Password reset — localized (ar / en / fr) */
export async function sendPasswordResetEmail(
  to: string,
  token: string,
  opts?: { lang?: string; fullName?: string; request?: Request }
): Promise<void> {
  const lang = opts?.lang ?? "en";
  const name = opts?.fullName;
  const baseUrl = getAppBaseUrl(opts?.request);
  // The existing SPA architecture uses /?view=reset-password&token=...
  // — keeping it (per spec: "استعمل architecture الموجودة").
  const link = `${baseUrl}/?view=reset-password&token=${token}`;

  // Localized strings — defaults to English for unknown languages.
  let title: string;
  let preheader: string;
  let greeting: string;
  let bodyIntro: string;
  let buttonLabel: string;
  let validityNote: string;
  let orPasteLink: string;
  let ignoreNote: string;
  let subject: string;
  let textBody: string;

  if (lang === "ar") {
    title = "إعادة تعيين كلمة المرور";
    preheader = "تم استلام طلب لإعادة تعيين كلمة المرور لحسابك";
    greeting = name ? `مرحباً ${name}،` : "مرحباً،";
    bodyIntro =
      "تلقينا طلباً لإعادة تعيين كلمة المرور الخاصة بحسابك. اضغط على الزر أدناه لاختيار كلمة مرور جديدة. هذا الرابط صالح لمدة 30 دقيقة ويمكن استخدامه مرة واحدة فقط.";
    buttonLabel = "إعادة تعيين كلمة المرور";
    validityNote = "هذا الرابط صالح لمدة 30 دقيقة فقط وللاستخدام مرة واحدة.";
    orPasteLink = "أو انسخ هذا الرابط والصقه في متصفحك:";
    ignoreNote =
      "إذا لم تطلب إعادة تعيين كلمة المرور، يمكنك تجاهل هذه الرسالة بأمان — سيبقى حسابك محمياً.";
    subject = "إعادة تعيين كلمة المرور";
    textBody = `${title}\n\n${greeting}\n\n${bodyIntro}\n\n${buttonLabel}: ${link}\n\n${validityNote}\n\n${ignoreNote}`;
  } else if (lang === "fr") {
    title = "Réinitialiser votre mot de passe";
    preheader = "Une demande de réinitialisation a été reçue pour votre compte";
    greeting = name ? `Bonjour ${name},` : "Bonjour,";
    bodyIntro =
      "Nous avons reçu une demande de réinitialisation du mot de passe de votre compte. Cliquez sur le bouton ci-dessous pour en choisir un nouveau. Ce lien est valable 30 minutes et ne peut être utilisé qu'une seule fois.";
    buttonLabel = "Réinitialiser le mot de passe";
    validityNote = "Ce lien est valable 30 minutes et à usage unique.";
    orPasteLink = "Ou collez ce lien dans votre navigateur :";
    ignoreNote =
      "Si vous n'avez pas demandé cette réinitialisation, vous pouvez ignorer cet e-mail en toute sécurité — votre compte reste protégé.";
    subject = "Réinitialiser votre mot de passe";
    textBody = `${title}\n\n${greeting}\n\n${bodyIntro}\n\n${buttonLabel}: ${link}\n\n${validityNote}\n\n${ignoreNote}`;
  } else {
    title = "Reset your password";
    preheader = "A password reset request was received for your account";
    greeting = name ? `Hi ${name},` : "Hello,";
    bodyIntro =
      "We received a request to reset the password for your account. Click the button below to choose a new one. This link expires in 30 minutes and can only be used once.";
    buttonLabel = "Reset password";
    validityNote = "This link expires in 30 minutes and can only be used once.";
    orPasteLink = "Or paste this link into your browser:";
    ignoreNote =
      "If you did not request a password reset, you can safely ignore this email — your account is still secure.";
    subject = "Reset your password";
    textBody = `${title}\n\n${greeting}\n\n${bodyIntro}\n\n${buttonLabel}: ${link}\n\n${validityNote}\n\n${ignoreNote}`;
  }

  const wrapped = wrapEmail({
    title,
    preheader,
    baseUrl,
    bodyHtml: `
      <p style="margin:0 0 12px;line-height:1.5;color:#475569">${escapeHtml(greeting)}</p>
      <p style="margin:0 0 12px;line-height:1.5;color:#475569">${escapeHtml(bodyIntro)}</p>
      <p style="margin:18px 0;text-align:center">
        <a href="${escapeHtml(link)}" style="display:inline-block;padding:12px 22px;background:#0f172a;color:#ffffff;border-radius:8px;text-decoration:none;font-weight:600">${escapeHtml(buttonLabel)}</a>
      </p>
      <p style="margin:18px 0 0;font-size:13px;color:#94a3b8">${escapeHtml(orPasteLink)} <a href="${escapeHtml(link)}" style="color:#0ea5e9;word-break:break-all">${escapeHtml(link)}</a></p>
      <p style="margin:14px 0 0;font-size:12px;color:#94a3b8">${escapeHtml(validityNote)}</p>
      <p style="margin:8px 0 0;font-size:12px;color:#94a3b8">${escapeHtml(ignoreNote)}</p>
    `,
    bodyText: textBody,
  });
  await getEmailProvider().send({
    to,
    subject,
    html: wrapped.html,
    text: wrapped.text,
  });
}

/** 4. Welcome email (sent on first verified login or post-registration) */
export async function sendWelcomeEmail(
  to: string,
  name: string
): Promise<void> {
  const wrapped = wrapEmail({
    title: `Welcome to ${getFromName()}, ${name}!`,
    preheader: "Your account is ready — let's get started",
    bodyHtml: `
      <p style="margin:0 0 12px;line-height:1.5;color:#475569">Hi ${escapeHtml(name)},</p>
      <p style="margin:0 0 12px;line-height:1.5;color:#475569">Your email is verified and your account is ready. You can now start messaging, follow people, and customize your profile.</p>
      <p style="margin:18px 0;text-align:center">
        <a href="${escapeHtml(getAppBaseUrl())}/" style="display:inline-block;padding:12px 22px;background:#0f172a;color:#ffffff;border-radius:8px;text-decoration:none;font-weight:600">Open ${escapeHtml(getFromName())}</a>
      </p>
      <p style="margin:18px 0 0;font-size:12px;color:#94a3b8">If you have any questions, just reply to this email.</p>
    `,
    bodyText: `Hi ${name},\n\nYour email is verified and your account is ready. You can now start messaging, follow people, and customize your profile.\n\nOpen ${getFromName()}: ${getAppBaseUrl()}/`,
  });
  await getEmailProvider().send({
    to,
    subject: `Welcome to ${getFromName()}!`,
    html: wrapped.html,
    text: wrapped.text,
  });
}

/** 5. Security / login notification (e.g. new device login) */
export async function sendSecurityEmail(
  to: string,
  opts: { subject: string; event: string; details?: string; ip?: string; userAgent?: string }
): Promise<void> {
  const detailsRows: string[] = [];
  if (opts.ip) detailsRows.push(`<tr><td style="color:#94a3b8;padding:4px 0">IP address</td><td style="color:#0f172a;padding:4px 0;text-align:right">${escapeHtml(opts.ip)}</td></tr>`);
  if (opts.userAgent) detailsRows.push(`<tr><td style="color:#94a3b8;padding:4px 0">Device</td><td style="color:#0f172a;padding:4px 0;text-align:right">${escapeHtml(opts.userAgent)}</td></tr>`);
  if (opts.details) detailsRows.push(`<tr><td style="color:#94a3b8;padding:4px 0">Details</td><td style="color:#0f172a;padding:4px 0;text-align:right">${escapeHtml(opts.details)}</td></tr>`);

  const wrapped = wrapEmail({
    title: opts.subject,
    preheader: opts.event,
    bodyHtml: `
      <p style="margin:0 0 12px;line-height:1.5;color:#475569">${escapeHtml(opts.event)}</p>
      ${detailsRows.length > 0 ? `<table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="margin:14px 0;font-size:13px">${detailsRows.join("")}</table>` : ""}
      <p style="margin:18px 0 0;font-size:12px;color:#94a3b8">If this was you, no action is needed. If you don't recognize this activity, change your password immediately and contact support.</p>
    `,
    bodyText: `${opts.subject}\n\n${opts.event}${opts.ip ? `\nIP: ${opts.ip}` : ""}${opts.userAgent ? `\nDevice: ${opts.userAgent}` : ""}${opts.details ? `\nDetails: ${opts.details}` : ""}\n\nIf this was you, no action is needed. Otherwise, change your password immediately.`,
  });
  await getEmailProvider().send({
    to,
    subject: opts.subject,
    html: wrapped.html,
    text: wrapped.text,
  });
}

/** 6. General system / notification email */
export async function sendNotificationEmail(
  to: string,
  subject: string,
  text: string
): Promise<void> {
  const wrapped = wrapEmail({
    title: subject,
    preheader: text.slice(0, 100),
    bodyHtml: `<p style="margin:0;line-height:1.6;color:#475569">${escapeHtml(text)}</p>`,
    bodyText: text,
  });
  await getEmailProvider().send({
    to,
    subject,
    html: wrapped.html,
    text: wrapped.text,
  });
}

/** 7. Raw / custom email (used by the test endpoint and admin broadcasts) */
export async function sendRawEmail(message: EmailMessage): Promise<void> {
  await getEmailProvider().send(message);
}

// ---------------------------------------------------------------------------
// Email logging — optional diagnostics, never stores the API key.
// Wrapped around sendRawEmail so every outbound email gets a row in EmailLog
// regardless of the caller. Failures are caught and logged as `failed`.
// ---------------------------------------------------------------------------

/**
 * Send an email and record the result in EmailLog.
 * Safe to call from any server-side context (API route, scheduled job, etc.).
 */
export async function sendAndLog(
  message: EmailMessage,
  opts: { template: string; userId?: string | null }
): Promise<{ ok: boolean; error?: string }> {
  const provider = getEmailProvider();
  try {
    await provider.send(message);
    await safeLogEmail({
      userId: opts.userId ?? null,
      toEmail: message.to,
      template: opts.template,
      provider: provider.name,
      status: "sent",
      error: null,
    });
    return { ok: true };
  } catch (e) {
    const errorMessage =
      e instanceof Error ? e.message.slice(0, 500) : String(e).slice(0, 500);
    await safeLogEmail({
      userId: opts.userId ?? null,
      toEmail: message.to,
      template: opts.template,
      provider: provider.name,
      status: "failed",
      error: errorMessage,
    });
    return { ok: false, error: errorMessage };
  }
}

/**
 * Best-effort DB log. If the DB write fails (e.g. during cold start), we
 * still let the email send succeed — the catch is intentional.
 */
async function safeLogEmail(entry: {
  userId: string | null;
  toEmail: string;
  template: string;
  provider: string;
  status: string;
  error: string | null;
}): Promise<void> {
  try {
    const { db } = await import("@/lib/database");
    await db.emailLog.create({
      data: {
        userId: entry.userId,
        toEmail: entry.toEmail,
        template: entry.template,
        provider: entry.provider,
        status: entry.status,
        error: entry.error,
      },
    });
  } catch {
    // Best-effort — don't crash the email flow because of a DB hiccup.
  }
}
