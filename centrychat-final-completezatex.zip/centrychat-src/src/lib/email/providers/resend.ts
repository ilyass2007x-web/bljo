/**
 * Resend email provider — server-side only.
 *
 * SECURITY:
 *  - Reads RESEND_API_KEY from process.env at runtime. NEVER hard-coded.
 *  - NEVER exposed to the browser. This file is only imported from
 *    `src/lib/email/index.ts`, which itself is only imported by server code
 *    (API routes / server actions). The bundler keeps it out of client bundles.
 *  - Sender (`from`) is taken from RESEND_FROM_EMAIL (server-controlled).
 *    The browser can NEVER supply or override the sender address.
 *  - On error, only safe diagnostic info is logged — the API key is never
 *    printed, returned, or serialized.
 *
 * Configuration (set in Netlify Environment Variables — never in netlify.toml):
 *   - RESEND_API_KEY       (required)  Your Resend API key
 *   - RESEND_FROM_EMAIL    (optional)  Sender address, e.g.
 *                                     "SentryChat <noreply@mydomain.com>"
 *                                     If unset, defaults to Resend's test
 *                                     sender "onboarding@resend.dev".
 *
 * When you later verify your own domain, you only need to change
 * RESEND_FROM_EMAIL — no code changes required.
 */
import { Resend } from "resend";
import type { EmailMessage, EmailProvider } from "../index";

/** Resend's official test sender (works without a verified domain). */
const RESEND_TEST_FROM = "onboarding@resend.dev";

/**
 * Resolve the sender address from the server environment.
 * Browser requests cannot influence this value.
 */
function getFromEmail(): string {
  const configured = process.env.RESEND_FROM_EMAIL?.trim();
  if (configured && configured.length > 0) {
    return configured;
  }
  return RESEND_TEST_FROM;
}

/**
 * Validate that a string looks like a reasonable sender. This is a sanity
 * check, not a security boundary — the value comes from server env, not user
 * input. Catches accidental misconfiguration early with a clear log line.
 */
function isValidEmail(s: string): boolean {
  // Simple RFC-5322-ish check — good enough for diagnostics.
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
}

export class ResendEmailProvider implements EmailProvider {
  readonly name = "resend";
  private client: Resend | null = null;

  /**
   * Lazily construct the Resend SDK client on first send. We avoid creating
   * it eagerly in the constructor because the SDK throws when given an empty
   * key, and we want the provider to instantiate cleanly so that the rest of
   * the app can boot and report a friendly "not configured" error to the
   * admin UI (rather than crashing the whole serverless function).
   */
  private getClient(): Resend {
    if (this.client) return this.client;
    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey || apiKey.trim().length === 0) {
      // Safe error — never echoes the key (because there is none).
      const err = new Error(
        "Email service is not configured. Set RESEND_API_KEY in Netlify Environment Variables and redeploy."
      );
      err.name = "EmailConfigError";
      throw err;
    }
    this.client = new Resend(apiKey);
    return this.client;
  }

  async send(message: EmailMessage): Promise<void> {
    // This call throws EmailConfigError if RESEND_API_KEY is missing —
    // which the test endpoint / auth flow catches and surfaces as a 500
    // CONFIG_ERROR so the deployer knows what to fix.
    const client = this.getClient();

    const from = getFromEmail();
    if (!isValidEmail(from)) {
      console.error(
        `[email:resend] RESEND_FROM_EMAIL is misconfigured (${JSON.stringify(
          process.env.RESEND_FROM_EMAIL
        )}). Falling back to ${RESEND_TEST_FROM}.`
      );
    }

    // SAFE diagnostic: log that we're about to call Resend. NEVER logs
    // the API key, NEVER logs message body, NEVER logs the reset token.
    console.log("[email:resend] sending", {
      from,
      to: message.to,
      subject: message.subject,
    });

    try {
      // SDK returns { data: { id } | null, error: ErrorResponse | null, headers }.
      // We capture BOTH so we can log the email ID on success (lets the admin
      // find the message in the Resend dashboard) and the full safe error
      // fields on failure.
      const { data, error } = await client.emails.send({
        from,
        to: message.to,
        subject: message.subject,
        html: message.html,
        text: message.text,
      });

      if (error) {
        // Resend returned an application-level error (HTTP 4xx/5xx).
        // Safe fields only: error.name is the Resend error code
        // (e.g. 'missing_api_key', 'invalid_api_key', 'restricted_api_key',
        // 'invalid_from_address', 'rate_limit_exceeded', 'monthly_quota_exceeded').
        console.error("[email:resend] FAILED:", {
          to: message.to,
          subject: message.subject,
          errorName: error.name,
          errorMessage: error.message,
          statusCode: error.statusCode,
        });
        const err = new Error(
          `Email delivery failed: ${error.name ?? "UnknownError"}${error.message ? ` — ${error.message}` : ""}`
        );
        err.name = "EmailSendError";
        throw err;
      }

      // SUCCESS — Resend accepted the email. Log the email ID so the admin
      // can find this exact message in the Resend dashboard.
      console.log("[email:resend] sent OK:", {
        to: message.to,
        subject: message.subject,
        emailId: data?.id ?? null,
      });
    } catch (e) {
      // Re-throw our own typed errors as-is.
      if (e instanceof Error && (e.name === "EmailConfigError" || e.name === "EmailSendError")) {
        throw e;
      }
      // Network / SDK error (e.g. fetch failed, DNS, TLS). Log safe info only.
      console.error("[email:resend] unexpected error:", {
        to: message.to,
        subject: message.subject,
        errorName: e instanceof Error ? e.name : typeof e,
        errorMessage: e instanceof Error ? e.message : String(e).slice(0, 200),
      });
      const err = new Error("Email delivery failed due to a transient error.");
      err.name = "EmailSendError";
      throw err;
    }
  }
}
