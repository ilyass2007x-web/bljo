/**
 * Storage abstraction.
 *
 * The MVP messaging platform stores NO media (text-only messages, see spec §19).
 * However, the architecture must allow future image/video/file support without
 * rewriting the messaging core. Therefore all storage access goes through a
 * StorageProvider interface.
 *
 * Current provider: NoopStorageProvider (rejects all uploads).
 * Future providers: S3, Cloudflare R2, MinIO, self-hosted object storage, etc.
 *
 * Switching providers: set STORAGE_PROVIDER env var and implement the provider
 * in lib/storage/providers/<name>.ts. No messaging code changes required.
 */

export interface StorageUploadInput {
  key: string;
  body: Buffer | Uint8Array;
  contentType: string;
  metadata?: Record<string, string>;
}

export interface StorageObject {
  key: string;
  url: string;
  size: number;
  contentType: string;
  uploadedAt: Date;
}

export interface StorageProvider {
  readonly name: string;
  upload(input: StorageUploadInput): Promise<StorageObject>;
  delete(key: string): Promise<void>;
  getUrl(key: string): Promise<string>;
  exists(key: string): Promise<boolean>;
}

class NoopStorageProvider implements StorageProvider {
  readonly name = "noop";

  async upload(): Promise<StorageObject> {
    throw new Error(
      "Storage is disabled. The MVP messaging platform is text-only. " +
        "Configure a StorageProvider (S3, R2, MinIO) to enable media uploads."
    );
  }

  async delete(): Promise<void> {
    /* no-op */
  }

  async getUrl(key: string): Promise<string> {
    return key;
  }

  async exists(): Promise<boolean> {
    return false;
  }
}

let cached: StorageProvider | null = null;

export function getStorageProvider(): StorageProvider {
  if (cached) return cached;
  const provider = (process.env.STORAGE_PROVIDER ?? "noop").toLowerCase();
  switch (provider) {
    case "noop":
    case "":
      cached = new NoopStorageProvider();
      break;
    // Future: case "s3": cached = new S3StorageProvider(); break;
    default:
      throw new Error(`Unknown storage provider: ${provider}`);
  }
  return cached;
}
