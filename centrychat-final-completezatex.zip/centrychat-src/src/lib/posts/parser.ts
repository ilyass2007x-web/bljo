/**
 * Post content parser — pure functions, NO HTML transformation.
 *
 * The stored `Post.content` is the user's verbatim text (after server-side
 * trimming). This module extracts structured entities (URLs, @mentions,
 * #hashtags) on demand, WITHOUT modifying or transforming the original
 * text. The client can use these extracted tokens to render links safely.
 *
 * Security model:
 *  - Content from the DB is ALWAYS treated as untrusted (XSS-safe).
 *  - URL extraction rejects `javascript:`, `data:`, and other dangerous
 *    schemes — only `http:`, `https:`, and protocol-relative `//` URLs
 *    are recognized as links.
 *  - Mention/hashtag tokens are returned as raw substrings; the CLIENT
 *    is responsible for escaping them when rendering (React escapes by
 *    default — never use dangerouslySetInnerHTML with post content).
 */

export interface ParsedUrl {
  /** The matched URL substring, exactly as it appears in the text. */
  raw: string;
  /** Normalized URL with a protocol (added `https://` if missing). */
  url: string;
  /** Display text — same as `raw` for now, but exposed for future shortening. */
  display: string;
  /** Start offset in the original content (inclusive). */
  start: number;
  /** End offset in the original content (exclusive). */
  end: number;
}

export interface ParsedMention {
  /** Matched substring including the leading `@`, e.g. `@alice`. */
  raw: string;
  /** Username without the `@`, lowercased for lookup, e.g. `alice`. */
  username: string;
  start: number;
  end: number;
}

export interface ParsedHashtag {
  /** Matched substring including the leading `#`, e.g. `#football`. */
  raw: string;
  /** Tag without the `#`, lowercased, e.g. `football`. */
  tag: string;
  start: number;
  end: number;
}

export interface ParsedPost {
  urls: ParsedUrl[];
  mentions: ParsedMention[];
  hashtags: ParsedHashtag[];
}

/**
 * Regex for HTTP(S) URLs and protocol-relative URLs.
 * Rejects `javascript:`, `data:`, `vbscript:` etc. — those schemes are
 * not in the allow-list and so won't be picked up as URLs at all.
 *
 * Pattern breakdown:
 *   - `https?://` or `//`     → scheme prefix
 *   - followed by a greedy run of non-whitespace, non-quote, non-<> chars
 *   - then we trim trailing punctuation (. , ! ? ; : ) ] } ' ") from the match
 *     post-hoc, because users commonly write "check https://x.com." with
 *     a trailing period that's part of the sentence, not the URL.
 *
 * Trailing-punctuation trimming is done in the parser body (not the regex)
 * because JS regex has no good way to express "match a run, then trim
 * trailing punctuation" in a single pattern that works on all browsers.
 */
const URL_REGEX = /(?:https?:\/\/|\/\/)[^\s<>"']+/gi;

/**
 * Regex for @mentions. Allows letters, digits, underscore, hyphen.
 * Maximum length 32 (matches the username validation rule).
 *
 * NOTE: this regex is intentionally permissive — it does NOT verify the
 * mention actually exists in the database. That lookup happens server-side
 * at render time if needed (e.g. to render an avatar next to the mention).
 */
const MENTION_REGEX = /@(?:[a-z0-9_]{1,32})/gi;

/**
 * Regex for #hashtags. Allows letters, digits, underscore. Must be
 * preceded by start-of-string or a non-word character (so `code#42`
 * does not become a hashtag).
 */
const HASHTAG_REGEX = /(?:^|[^&\w#])#[\p{L}\p{N}_]{1,64}/giu;

/**
 * Parse a post's content into structured entities. Returns an object
 * with three arrays: URLs, mentions, and hashtags. Each item includes
 * the original substring and its start/end offsets.
 *
 * This function is PURE — it does not modify the input. It is safe to
 * call on the server (for API responses) and on the client (for rendering).
 *
 * @param content Raw post content from the database.
 * @returns ParsedPost with extracted entities (empty arrays if none).
 */
export function parsePostContent(content: string): ParsedPost {
  if (!content) return { urls: [], mentions: [], hashtags: [] };

  const urls: ParsedUrl[] = [];
  const mentions: ParsedMention[] = [];
  const hashtags: ParsedHashtag[] = [];

  // URLs
  for (const match of content.matchAll(URL_REGEX)) {
    let raw = match[0];
    if (raw.length < 4) continue; // skip obviously-too-short matches
    const start = match.index ?? 0;
    // Strip trailing punctuation that's part of the sentence, not the URL.
    // Common case: "check https://example.com." → trailing "." is removed.
    // Special case: closing parens are only stripped when there's no
    // matching "(" in the URL itself — handles "(see https://x.com)".
    while (raw.length > 4 && /[.!?,;:)\]}'"]$/.test(raw)) {
      const last = raw[raw.length - 1];
      if (last === ")") {
        // Only strip if the URL doesn't contain an unbalanced "(".
        if (raw.includes("(")) break;
      }
      raw = raw.slice(0, -1);
    }
    const end = start + raw.length;
    // Normalize: add https: prefix if it was a protocol-relative URL.
    const url = raw.startsWith("//") ? `https:${raw}` : raw;
    urls.push({ raw, url, display: raw, start, end });
  }

  // Mentions
  for (const match of content.matchAll(MENTION_REGEX)) {
    const raw = match[0];
    const start = match.index ?? 0;
    const end = start + raw.length;
    const username = raw.slice(1).toLowerCase(); // strip '@'
    mentions.push({ raw, username, start, end });
  }

  // Hashtags — strip the optional leading non-word char.
  for (const match of content.matchAll(HASHTAG_REGEX)) {
    const raw = match[0];
    const start = match.index ?? 0;
    // If the match has a leading non-word char, the actual hashtag starts
    // at the position of '#'.
    const hashIdx = raw.indexOf("#");
    if (hashIdx < 0) continue;
    const tagStart = start + hashIdx;
    const tagRaw = raw.slice(hashIdx);
    const tag = tagRaw.slice(1).toLowerCase(); // strip '#'
    if (!tag) continue;
    hashtags.push({
      raw: tagRaw,
      tag,
      start: tagStart,
      end: tagStart + tagRaw.length,
    });
  }

  return { urls, mentions, hashtags };
}

/**
 * Constants used by both the server-side validation and the client-side
 * composer UI counter. Keeping them in one place ensures they stay in sync.
 */
export const POST_MAX_LENGTH = 280;
export const POST_MIN_LENGTH = 1;

/**
 * Server-side content validation.
 *
 *  - Trim leading/trailing whitespace.
 *  - Collapse internal runs of whitespace (spaces, tabs, newlines) into
 *    single spaces — this prevents both accidental double-spacing AND
 *    zero-width-character abuse (e.g. a "filled" 280-char post that's
 *    actually all whitespace).
 *  - Enforce POST_MIN_LENGTH (>= 1 char after trimming).
 *  - Enforce POST_MAX_LENGTH (280 chars).
 *
 * @returns `{ ok: true; value: string }` on success, or
 *          `{ ok: false; error: string }` on failure. The error string
 *          is safe to surface to the client (no internal details).
 */
export function validatePostContent(
  raw: unknown
): { ok: true; value: string } | { ok: false; error: string } {
  if (typeof raw !== "string") {
    return { ok: false, error: "Post content must be a string." };
  }

  // Normalize all whitespace runs (including unicode whitespace and
  // zero-width chars) to single ASCII spaces, then trim.
  const normalized = raw
    .replace(/[\s\u00A0\u200B-\u200D\uFEFF]+/g, " ")
    .trim();

  // Use Array.from to count code points (not UTF-16 code units) so that
  // emoji and other astral characters count as 1, not 2. This matches
  // what the user perceives as "character count" in the composer counter.
  // The client-side counter in PostComposer uses the same Array.from approach.
  const charCount = Array.from(normalized).length;
  if (charCount < POST_MIN_LENGTH) {
    return { ok: false, error: "Post cannot be empty." };
  }
  if (charCount > POST_MAX_LENGTH) {
    return {
      ok: false,
      error: `Post must be at most ${POST_MAX_LENGTH} characters (you used ${charCount}).`,
    };
  }

  return { ok: true, value: normalized };
}

/**
 * Comment length limits — distinct from posts because comments can be longer
 * (max 500 chars per spec §3). Both server + client import these constants
 * to stay in sync.
 */
export const COMMENT_MAX_LENGTH = 500;
export const COMMENT_MIN_LENGTH = 1;

/**
 * Server-side comment content validation.
 *
 * Same logic as validatePostContent, just with COMMENT_MAX_LENGTH.
 * - Trim + normalize whitespace (no zero-width-char abuse).
 * - Enforce 1..500 chars (code-point counting so emoji = 1).
 *
 * Comments are user-generated content — they are rendered as plain text
 * via React (which escapes by default). NO dangerouslySetInnerHTML is
 * ever used on comment content.
 */
export function validateCommentContent(
  raw: unknown
): { ok: true; value: string } | { ok: false; error: string } {
  if (typeof raw !== "string") {
    return { ok: false, error: "Comment content must be a string." };
  }

  // Same whitespace normalization as posts — collapse runs, trim ends.
  // Comments may contain newlines (we keep them as \n, not collapsed to spaces,
  // because line breaks are meaningful in comments). To do this we only
  // collapse runs of spaces/tabs, not newlines, then trim.
  const normalized = raw
    .replace(/[ \t\u00A0\u200B-\u200D\uFEFF]+/g, " ")
    .replace(/\n{3,}/g, "\n\n") // limit consecutive newlines to 2
    .trim();

  const charCount = Array.from(normalized).length;
  if (charCount < COMMENT_MIN_LENGTH) {
    return { ok: false, error: "Comment cannot be empty." };
  }
  if (charCount > COMMENT_MAX_LENGTH) {
    return {
      ok: false,
      error: `Comment must be at most ${COMMENT_MAX_LENGTH} characters (you used ${charCount}).`,
    };
  }

  return { ok: true, value: normalized };
}
