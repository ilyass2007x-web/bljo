/**
 * Feed Ranking Engine
 * ===================
 *
 * Scores posts based on multiple signals to produce a personalized,
 * diverse, and engaging feed — NOT just chronological order.
 *
 * Scoring components (all configurable via FEED_WEIGHTS):
 *   1. Recency — newer posts get a bonus that decays over time.
 *   2. Engagement — likes (weight 3) + comments (weight 5) + views (weight 0.5).
 *      Active interactions (likes/comments) are much stronger than passive views.
 *   3. Following boost — posts from followed users get a flat bonus.
 *   4. Exploration bonus — a small fraction of non-followed posts get a
 *      boost to introduce the user to new creators (prevents echo chamber).
 *   5. Diversity penalty — if the same author appears multiple times in
 *      the candidate pool, their subsequent posts get progressively lower
 *      scores (prevents one creator from dominating the feed).
 *   6. Velocity bonus — posts that are getting engagement FAST (relative
 *      to their age) get a boost. This surfaces trending content.
 *
 * Architecture:
 *   - The engine operates on a CANDIDATE POOL fetched from the DB (not
 *     on the entire posts table). The pool is typically 3-5x the page
 *     size, fetched via a single Prisma query with _count aggregation.
 *   - Scoring is done in-memory (JavaScript) after the DB fetch —
 *     no per-post DB queries (no N+1).
 *   - The engine is designed to be replaceable by an ML model later —
 *     just swap the `scorePosts` function. The API contract (input:
 *     candidate posts + user context, output: scored + sorted posts)
 *     stays the same.
 *   - Weights are centralized in FEED_WEIGHTS for easy tuning + future
 *     admin dashboard integration.
 *
 * Performance:
 *   - 1 DB query for the candidate pool (with _count for likes/comments/views).
 *   - 1 DB query for the user's followed IDs (batch, reused for isFollowing).
 *   - Scoring is O(n) where n = candidate pool size (typically 60-100 posts).
 *   - Total queries: 2 (same as before) + 1 for likes (existing) = 3.
 */

// ── Configurable Weights ────────────────────────────────────────────────────
// Centralized so they can be tuned in one place. Future: expose via admin
// settings (PlatformSetting) so admins can adjust without code changes.

export const FEED_WEIGHTS = {
  // Recency: how fast the recency bonus decays. Higher = newer posts
  // dominate more. 1.0 = moderate decay (half-life ~3 hours).
  recencyDecay: 1.0,

  // Engagement: relative weights of each interaction type.
  // Likes and comments are "active" engagement — much stronger signals
  // than passive views.
  likeWeight: 3.0,
  commentWeight: 5.0,
  viewWeight: 0.5,

  // Following: flat bonus added to posts from followed users.
  followingBoost: 15.0,

  // Exploration: fraction of the candidate pool reserved for non-followed
  // users (discovery). 0.15 = 15% of the feed comes from creators the
  // user doesn't follow yet.
  explorationRatio: 0.15,
  explorationBoost: 10.0,

  // Diversity: penalty applied to the Nth post from the same author.
  // The first post from an author gets no penalty. The second gets -5,
  // the third gets -10, etc. This prevents one creator from filling
  // the entire feed.
  diversityPenalty: 5.0,

  // Velocity: bonus for posts getting engagement quickly relative to
  // their age. A post with 10 likes in 5 minutes is more "trending"
  // than a post with 10 likes in 5 hours.
  velocityBonus: 8.0,

  // Self-post penalty: the user's own posts get a slight penalty so
  // they don't dominate their own feed (they already see them when
  // they post).
  selfPostPenalty: 5.0,
} as const;

// ── Types ───────────────────────────────────────────────────────────────────

/** A post with its aggregated counts (from Prisma _count). */
export interface RankablePost {
  id: string;
  authorId: string;
  content: string;
  createdAt: Date;
  _count: {
    likes: number;
    comments: number;
    views: number;
  };
}

/** Context about the current user needed for scoring. */
export interface UserContext {
  userId: string;
  followedAuthorIds: Set<string>;
}

/** A scored post ready for sorting. */
export interface ScoredPost {
  post: RankablePost;
  score: number;
  components: ScoreComponents;
}

/** Breakdown of the score for explainability (spec §19). */
export interface ScoreComponents {
  recency: number;
  engagement: number;
  following: number;
  exploration: number;
  diversity: number;
  velocity: number;
  self: number;
}

// ── Scoring Functions ───────────────────────────────────────────────────────

/**
 * Calculate the recency score for a post.
 *
 * Uses an exponential decay function: score = e^(-decay * hoursSincePost)
 * - A post from 1 hour ago gets ~0.37 of the max recency score (with decay=1.0)
 * - A post from 3 hours ago gets ~0.05
 * - A post from 24 hours ago gets ~0.000003 (effectively 0)
 *
 * This means very old posts almost never outrank fresh ones on recency
 * alone — but strong engagement can still push them up.
 */
function calculateRecencyScore(createdAt: Date, now: Date): number {
  const hoursSincePost = (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60);
  return Math.exp(-FEED_WEIGHTS.recencyDecay * hoursSincePost) * 100;
}

/**
 * Calculate the engagement score for a post.
 *
 * Weighted sum: likes * likeWeight + comments * commentWeight + views * viewWeight.
 * Views are heavily discounted (0.5) because a view is a passive signal —
 * the user might have scrolled past without reading. Likes and comments
 * are active signals that prove the user engaged with the content.
 */
function calculateEngagementScore(post: RankablePost): number {
  const { likes, comments, views } = post._count;
  return (
    likes * FEED_WEIGHTS.likeWeight +
    comments * FEED_WEIGHTS.commentWeight +
    views * FEED_WEIGHTS.viewWeight
  );
}

/**
 * Calculate the velocity score — how fast is this post accumulating
 * engagement relative to its age?
 *
 * A post with 10 likes in 5 minutes has higher velocity than a post
 * with 10 likes in 5 hours. This surfaces trending content.
 *
 * Formula: engagementPerHour = totalEngagement / max(hoursSincePost, 0.1)
 * We cap at 0.1 hours (6 min) to prevent division by zero and to
 * avoid over-rewarding brand-new posts that haven't had time to
 * accumulate real engagement.
 *
 * The velocity bonus is then scaled and capped to prevent runaway scores.
 */
function calculateVelocityScore(post: RankablePost, now: Date): number {
  const totalEngagement = post._count.likes + post._count.comments;
  if (totalEngagement === 0) return 0;

  const hoursSincePost = Math.max(
    (now.getTime() - post.createdAt.getTime()) / (1000 * 60 * 60),
    0.1 // minimum 6 minutes
  );

  const engagementPerHour = totalEngagement / hoursSincePost;
  // Cap at 20 engagement/hour to prevent runaway scores for viral posts.
  const cappedVelocity = Math.min(engagementPerHour, 20);

  return (cappedVelocity / 20) * FEED_WEIGHTS.velocityBonus;
}

// ── Main Scoring Function ───────────────────────────────────────────────────

/**
 * Score a list of candidate posts and return them sorted by score (descending).
 *
 * This is the MAIN entry point for the ranking engine. It:
 *   1. Calculates individual score components for each post.
 *   2. Applies diversity penalties (same author appearing multiple times).
 *   3. Sorts by total score.
 *   4. Returns the top N posts.
 *
 * @param candidates - The candidate pool (typically 3-5x the page size).
 * @param userCtx - The current user's context (id + followed author IDs).
 * @param limit - How many posts to return (page size).
 * @returns ScoredPost[] sorted by score descending, length = min(limit, candidates.length).
 */
export function scoreAndRankPosts(
  candidates: RankablePost[],
  userCtx: UserContext,
  limit: number
): ScoredPost[] {
  const now = new Date();

  // Phase 1: Calculate base scores (no diversity yet).
  const scored: ScoredPost[] = candidates.map((post) => {
    const isFollowing = userCtx.followedAuthorIds.has(post.authorId);
    const isOwnPost = post.authorId === userCtx.userId;

    const recency = calculateRecencyScore(post.createdAt, now);
    const engagement = calculateEngagementScore(post);
    const following = isFollowing ? FEED_WEIGHTS.followingBoost : 0;
    const exploration = !isFollowing && !isOwnPost ? FEED_WEIGHTS.explorationBoost : 0;
    const velocity = calculateVelocityScore(post, now);
    const self = isOwnPost ? -FEED_WEIGHTS.selfPostPenalty : 0;

    return {
      post,
      score: recency + engagement + following + exploration + velocity + self,
      components: {
        recency,
        engagement,
        following,
        exploration,
        diversity: 0, // applied in phase 2
        velocity,
        self,
      },
    };
  });

  // Phase 2: Apply diversity penalties.
  // We sort by current score first (so the BEST post from each author
  // is at the top), then penalize subsequent posts from the same author.
  scored.sort((a, b) => b.score - a.score);

  const authorPostCount = new Map<string, number>();
  for (const s of scored) {
    const count = authorPostCount.get(s.post.authorId) ?? 0;
    if (count > 0) {
      // This is the (count+1)th post from this author — apply penalty.
      const penalty = FEED_WEIGHTS.diversityPenalty * count;
      s.score -= penalty;
      s.components.diversity = -penalty;
    }
    authorPostCount.set(s.post.authorId, count + 1);
  }

  // Phase 3: Re-sort by final score and return the top N.
  scored.sort((a, b) => b.score - a.score);

  return scored.slice(0, limit);
}

/**
 * Build the candidate pool for the feed.
 *
 * This fetches a larger-than-needed pool of recent posts so the ranking
 * engine has enough material to score and diversify. The pool includes:
 *   - Posts from followed users (the core of the feed).
 *   - A smaller set of posts from non-followed users (exploration).
 *
 * The pool size is typically 3-5x the requested page size, capped at 100
 * to keep the query fast.
 *
 * @returns { followedPosts, explorationPosts } — two separate arrays
 * so the caller can control the exploration ratio.
 */
export function getCandidatePoolSize(requestedLimit: number): number {
  // 3x the requested limit, capped between 30 and 100.
  return Math.min(Math.max(requestedLimit * 3, 30), 100);
}
