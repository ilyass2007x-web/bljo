/**
 * Collections service — central business-logic helpers for Phase 5.
 *
 * Keeps the API routes thin: the routes handle auth + rate limiting + HTTP
 * concerns; this module handles:
 *   - content-type validation (allowlist + existence checks)
 *   - collection ownership + visibility queries (IDOR-safe)
 *   - item reordering (transactional, deterministic positions)
 *   - batched content hydration for the collection detail page
 *
 * SECURITY:
 *   - ownerId / actorId is ALWAYS the authenticated user, passed in by the
 *     route handler after `requireVerifiedUser()`. This module NEVER trusts
 *     a userId from a request body.
 *   - All findUnique queries that need ownership filtering use the
 *     authorization-aware pattern: filter by `id AND ownerId` in the
 *     WHERE clause, so a non-owner gets a null result (404 at the route
 *     layer) — same pattern used by the post-comment DELETE handler.
 *   - Public collection reads use a separate path: filter by `id AND
 *     (ownerId = viewerId OR isPublic = true)`.
 *
 * PERFORMANCE:
 *   - No N+1: content hydration is batched by contentType (1 query per
 *     type — 4 types max — for any number of items in a collection).
 *   - Reorder uses a single transaction that reads + writes once.
 *   - The item-list query uses `@@index([collectionId, position])` for
 *     fast ordering.
 *
 * NO DB SCHEMA CHANGES here — this module works with the Collection +
 * CollectionItem models added by migration 20260822000000_add_collections.
 */

import { db } from "@/lib/database";
import { BadRequestError, NotFoundError } from "@/lib/auth";
import { Prisma } from "@prisma/client";

// ── Content types ────────────────────────────────────────────────────────────

/**
 * Allowed content types for a CollectionItem. Validated server-side in
 * every API route that accepts a contentType from the client.
 *
 * `video` is treated as an Article with a non-empty videoUrl (the project
 * stores videos as Articles with an embedded URL — the media resolver handles
 * YouTube/Vimeo/etc.). `discussion` is a PostComment OR ArticleComment (top-
 * level OR reply — saved as a "discussion item" by ID).
 */
export const ALLOWED_CONTENT_TYPES = [
  "post",
  "article",
  "video",
  "discussion",
] as const;
export type CollectionContentType = (typeof ALLOWED_CONTENT_TYPES)[number];

/**
 * Validate + normalize a contentType string from the client.
 *
 * Returns the validated type or throws BadRequestError. The throw matches
 * the project's existing pattern (parser.ts validateCommentContent, etc.)
 * — the apiHandler wrapper converts it to an HTTP 400 response.
 */
export function validateContentType(raw: unknown): CollectionContentType {
  if (typeof raw !== "string") {
    throw new BadRequestError("contentType is required");
  }
  const t = raw.trim().toLowerCase();
  if (!ALLOWED_CONTENT_TYPES.includes(t as CollectionContentType)) {
    throw new BadRequestError(
      `Invalid contentType. Allowed: ${ALLOWED_CONTENT_TYPES.join(", ")}`
    );
  }
  return t as CollectionContentType;
}

/**
 * Validate a contentId string. Must be a non-empty trimmed string.
 * Throws BadRequestError on invalid input.
 */
export function validateContentId(raw: unknown): string {
  if (typeof raw !== "string" || raw.trim().length === 0) {
    throw new BadRequestError("contentId is required");
  }
  return raw.trim();
}

// ── Content existence validation ────────────────────────────────────────────

/**
 * Verify the underlying content exists + is accessible to the user BEFORE
 * inserting a CollectionItem. This is the polymorphic-content FK surrogate:
 * instead of a DB foreign key, we explicitly check the target table.
 *
 * Behavior by contentType:
 *   - "post":       Post must exist.
 *   - "article":    Article must exist + be PUBLISHED (drafts are private —
 *                   saving a draft URL is disallowed because non-owners
 *                   can't resolve the content later).
 *   - "video":      Article must exist + be PUBLISHED + have a non-empty videoUrl.
 *   - "discussion": PostComment OR ArticleComment must exist. We check both
 *                   tables (single findUnique each) since the client only
 *                   passes the comment ID, not which kind.
 *
 * Returns true if the content exists + is accessible. Returns false if the
 * content does not exist (caller treats as 404/BadRequest). Throws only on
 * DB connection errors (let the apiHandler wrapper convert to 500).
 *
 * SECURITY: this function NEVER trusts a contentId passed by the client
 * beyond looking it up — it performs a server-side existence check on the
 * real DB row. If the contentId is fake / belongs to a private draft, the
 * function returns false, and the caller rejects the save.
 */
export async function validateContentExists(
  contentType: CollectionContentType,
  contentId: string
): Promise<boolean> {
  switch (contentType) {
    case "post": {
      const row = await db.post.findUnique({
        where: { id: contentId },
        select: { id: true },
      });
      return row !== null;
    }
    case "article": {
      const row = await db.article.findUnique({
        where: { id: contentId },
        select: { id: true, status: true },
      });
      return row !== null && row.status === "PUBLISHED";
    }
    case "video": {
      const row = await db.article.findUnique({
        where: { id: contentId },
        select: { id: true, status: true, videoUrl: true },
      });
      // Article must be PUBLISHED + have a non-empty videoUrl.
      return (
        row !== null &&
        row.status === "PUBLISHED" &&
        typeof row.videoUrl === "string" &&
        row.videoUrl.trim().length > 0
      );
    }
    case "discussion": {
      // A "discussion" is a comment — could be a PostComment OR ArticleComment.
      // Check both (1 query each — both indexed by id primary key).
      const [postComment, articleComment] = await Promise.all([
        db.postComment.findUnique({
          where: { id: contentId },
          select: { id: true },
        }),
        db.articleComment.findUnique({
          where: { id: contentId },
          select: { id: true },
        }),
      ]);
      return postComment !== null || articleComment !== null;
    }
    default:
      return false;
  }
}

// ── Collection queries (IDOR-safe) ──────────────────────────────────────────

/**
 * The standard projection for a Collection — used by every read endpoint.
 * Includes the owner's public profile (no email, no passwordHash).
 */
const COLLECTION_SELECT = {
  id: true,
  ownerId: true,
  name: true,
  description: true,
  isPublic: true,
  createdAt: true,
  updatedAt: true,
  owner: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: { select: { items: true } },
} as const satisfies Prisma.CollectionSelect;

export type CollectionDTO = Prisma.CollectionGetPayload<{
  select: typeof COLLECTION_SELECT;
}>;

/**
 * Serialize a Collection row to the API response shape (ISO string dates,
 * flat itemCount, no internal fields).
 */
export function serializeCollection(c: CollectionDTO) {
  return {
    id: c.id,
    ownerId: c.ownerId,
    name: c.name,
    description: c.description,
    isPublic: c.isPublic,
    createdAt: c.createdAt.toISOString(),
    updatedAt: c.updatedAt.toISOString(),
    owner: c.owner,
    itemCount: c._count.items,
  };
}

/**
 * Fetch a collection by ID for the OWNER context.
 *
 * IDOR-safe: filters by `id AND ownerId`. Non-owner gets null → caller
 * returns 404. This is the project's established authorization pattern
 * (same as /api/v1/comments/[id] DELETE handler).
 */
export async function getCollectionForOwner(
  collectionId: string,
  ownerId: string
): Promise<CollectionDTO | null> {
  return db.collection.findFirst({
    where: { id: collectionId, ownerId },
    select: COLLECTION_SELECT,
  });
}

/**
 * Fetch a collection by ID for VIEWING (owner OR public).
 *
 * IDOR-safe:
 *   - If the viewer is the owner → returns the collection (any visibility).
 *   - If the viewer is NOT the owner → returns the collection ONLY if
 *     isPublic=true. Otherwise returns null → caller returns 404.
 *
 * This is the project's established "private resource" pattern — non-owner
 * access to a private resource returns 404 (not 403) to avoid leaking
 * the resource's existence.
 */
export async function getCollectionForViewer(
  collectionId: string,
  viewerId: string | null
): Promise<CollectionDTO | null> {
  // Owner sees everything they own (regardless of isPublic).
  if (viewerId) {
    const asOwner = await db.collection.findFirst({
      where: { id: collectionId, ownerId: viewerId },
      select: COLLECTION_SELECT,
    });
    if (asOwner) return asOwner;
  }
  // Non-owner (or unauth viewer) sees only public collections.
  return db.collection.findFirst({
    where: { id: collectionId, isPublic: true },
    select: COLLECTION_SELECT,
  });
}

// ── Limits ──────────────────────────────────────────────────────────────────

/**
 * Count collections owned by a user. Used to enforce the
 * `collection.max_per_user` limit on creation.
 */
export async function countUserCollections(userId: string): Promise<number> {
  return db.collection.count({ where: { ownerId: userId } });
}

/**
 * Count items in a collection. Used to enforce the `collection.max_items`
 * limit on item insertion.
 */
export async function countCollectionItems(collectionId: string): Promise<number> {
  return db.collectionItem.count({ where: { collectionId } });
}

// ── Item ordering helpers ───────────────────────────────────────────────────

/**
 * The standard projection for a CollectionItem — used by the list + add
 * endpoints. Does NOT include the underlying content (post/article/etc.)
 * — that's hydrated separately + batched by the route handler via
 * `hydrateCollectionItems`.
 */
const ITEM_SELECT = {
  id: true,
  collectionId: true,
  contentType: true,
  contentId: true,
  position: true,
  addedAt: true,
} as const satisfies Prisma.CollectionItemSelect;

export type CollectionItemDTO = Prisma.CollectionItemGetPayload<{
  select: typeof ITEM_SELECT;
}>;

/**
 * Serialize a CollectionItem row to the API response shape (ISO date).
 */
export function serializeItem(i: CollectionItemDTO) {
  return {
    id: i.id,
    collectionId: i.collectionId,
    contentType: i.contentType,
    contentId: i.contentId,
    position: i.position,
    addedAt: i.addedAt.toISOString(),
  };
}

/**
 * Compute the next position for a new item in a collection.
 *
 * Returns `max(position) + 1` (or 0 if the collection is empty). Used by
 * the POST add-item endpoint so new items append to the end (per spec §13:
 * "Default: append new item to the end.").
 */
export async function getNextPosition(collectionId: string): Promise<number> {
  const last = await db.collectionItem.findFirst({
    where: { collectionId },
    orderBy: { position: "desc" },
    select: { position: true },
  });
  return (last?.position ?? -1) + 1;
}

/**
 * Reorder an item within a collection to a new position, then rewrite
 * ALL sibling positions to a clean 0,1,2,... sequence (transactional).
 *
 * Algorithm (spec §14):
 *   1. Read all item IDs in this collection, ordered by current position.
 *   2. Remove the target item from the list.
 *   3. Insert it at the requested `newPosition` (clamped to [0, list.length-1]).
 *   4. Rewrite each item's `position` to its index in the new list (0,1,2,...).
 *
 * The whole operation runs inside a Prisma transaction (`$transaction`) so:
 *   - Concurrent reorders can't corrupt positions (DB row-level locks
 *     during the UPDATE).
 *   - If any update fails, the entire reorder rolls back (no partial state).
 *
 * SECURITY: the caller MUST verify ownership BEFORE calling this helper.
 * We re-check ownership inside the transaction (defensive) — if the
 * collection's ownerId doesn't match the actorId, throw NotFoundError
 * (404 at the route layer — no information leakage).
 *
 * @returns the new ordered list of item IDs (after the rewrite).
 */
export async function reorderItem(
  collectionId: string,
  itemId: string,
  newPosition: number,
  actorId: string
): Promise<string[]> {
  // Defensive ownership re-check inside the function (the route already
  // checked, but we re-verify inside the transaction to be safe).
  const collection = await db.collection.findUnique({
    where: { id: collectionId },
    select: { ownerId: true },
  });
  if (!collection || collection.ownerId !== actorId) {
    throw new NotFoundError("Collection not found");
  }

  return db.$transaction(async (tx) => {
    // 1. Read all item IDs in this collection, ordered by current position.
    const items = await tx.collectionItem.findMany({
      where: { collectionId },
      orderBy: [{ position: "asc" }, { addedAt: "asc" }, { id: "asc" }],
      select: { id: true },
    });
    const ids = items.map((i) => i.id);

    // 2. Remove the target item.
    const currentIndex = ids.indexOf(itemId);
    if (currentIndex === -1) {
      throw new NotFoundError("Item not found in this collection");
    }
    ids.splice(currentIndex, 1);

    // 3. Insert at the new position (clamped to valid bounds).
    const clamped = Math.max(0, Math.min(newPosition, ids.length));
    ids.splice(clamped, 0, itemId);

    // 4. Rewrite positions: 0,1,2,...
    // Use a Promise.all of update calls — each is a single SQL UPDATE.
    // For very large collections this is O(n) updates inside a transaction;
    // that's the price of deterministic positions. The `collection.max_items`
    // limit (default 1000) bounds the worst case.
    await Promise.all(
      ids.map((id, index) =>
        tx.collectionItem.update({
          where: { id },
          data: { position: index },
          select: { id: true },
        })
      )
    );

    return ids;
  });
}

/**
 * Normalize positions to a clean 0,1,2,... sequence after an item is
 * deleted (or after any operation that might leave gaps). Used by the
 * DELETE item endpoint (spec §15: "optionally normalize remaining positions").
 *
 * Transactional — reads + rewrites all positions in one go.
 */
export async function normalizePositions(collectionId: string): Promise<void> {
  await db.$transaction(async (tx) => {
    const items = await tx.collectionItem.findMany({
      where: { collectionId },
      orderBy: [{ position: "asc" }, { addedAt: "asc" }, { id: "asc" }],
      select: { id: true },
    });
    await Promise.all(
      items.map((item, index) =>
        tx.collectionItem.update({
          where: { id: item.id },
          data: { position: index },
          select: { id: true },
        })
      )
    );
  });
}

// ── Batched content hydration ───────────────────────────────────────────────

/**
 * Hydrate the underlying content for a list of CollectionItems, batched
 * by contentType. Returns a Map keyed by `${contentType}:${contentId}`
 * with the minimal fields needed by the Collection Detail UI to render
 * a card per item.
 *
 * NO N+1 — runs ONE query per contentType (max 4 queries for any number
 * of items in a collection).
 *
 * Returns only PUBLIC-facing fields. For articles/videos, only PUBLISHED
 * status rows are returned (drafts are skipped — they appear as `null` in
 * the result map, and the caller's UI renders a "Content no longer
 * available" placeholder).
 *
 * For "discussion" items, the underlying PostComment/ArticleComment rows
 * are looked up (with the parent post/article ID) so the UI can deep-link.
 */
export interface HydratedContent {
  contentType: CollectionContentType;
  contentId: string;
  // Common minimal projection (varies by type, but always includes these
  // for the card preview):
  title: string | null;
  excerpt: string | null;
  coverImage: string | null;
  videoUrl: string | null;
  authorId: string | null;
  authorFullName: string | null;
  authorUsername: string | null;
  authorAvatarColor: string | null;
  authorAvatarUrl: string | null;
  authorIsVerified: boolean;
  createdAt: string | null;
  // For "discussion" items: the parent post/article ID so the UI can
  // deep-link to the comment inside its parent's context.
  parentPostId: string | null;
  parentArticleId: string | null;
}

/**
 * Batch-resolve the underlying content for a list of items.
 *
 * @param items - the CollectionItem rows to hydrate.
 * @returns a Map keyed by `${contentType}:${contentId}` → HydratedContent.
 */
export async function hydrateCollectionItems(
  items: Array<{ contentType: string; contentId: string }>
): Promise<Map<string, HydratedContent>> {
  const out = new Map<string, HydratedContent>();
  if (items.length === 0) return out;

  // Group IDs by contentType.
  const postIds: string[] = [];
  const articleIds: string[] = [];
  const videoIds: string[] = []; // videos are Articles with videoUrl.
  const discussionIds: string[] = [];

  for (const i of items) {
    if (i.contentType === "post") postIds.push(i.contentId);
    else if (i.contentType === "article") articleIds.push(i.contentId);
    else if (i.contentType === "video") videoIds.push(i.contentId);
    else if (i.contentType === "discussion") discussionIds.push(i.contentId);
  }

  // Fetch posts (1 query, no N+1).
  if (postIds.length > 0) {
    const rows = await db.post.findMany({
      where: { id: { in: postIds } },
      select: {
        id: true,
        content: true,
        createdAt: true,
        author: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatarColor: true,
            avatarUrl: true,
            isVerified: true,
          },
        },
      },
    });
    for (const p of rows) {
      out.set(`post:${p.id}`, {
        contentType: "post",
        contentId: p.id,
        title: null,
        excerpt: p.content.slice(0, 160),
        coverImage: null,
        videoUrl: null,
        authorId: p.author.id,
        authorFullName: p.author.fullName,
        authorUsername: p.author.username,
        authorAvatarColor: p.author.avatarColor,
        authorAvatarUrl: p.author.avatarUrl,
        authorIsVerified: p.author.isVerified,
        createdAt: p.createdAt.toISOString(),
        parentPostId: null,
        parentArticleId: null,
      });
    }
  }

  // Fetch articles + videos in ONE query (videos are a subset of articles).
  // We fetch all article IDs (article + video) in one shot, then split by
  // whether videoUrl is non-empty.
  const allArticleIds = [...new Set([...articleIds, ...videoIds])];
  if (allArticleIds.length > 0) {
    const rows = await db.article.findMany({
      where: { id: { in: allArticleIds }, status: "PUBLISHED" },
      select: {
        id: true,
        title: true,
        excerpt: true,
        coverImage: true,
        videoUrl: true,
        publishedAt: true,
        author: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatarColor: true,
            avatarUrl: true,
            isVerified: true,
          },
        },
      },
    });
    for (const a of rows) {
      const hasVideo =
        typeof a.videoUrl === "string" && a.videoUrl.trim().length > 0;
      // Add to "article" key (always, when requested as article).
      if (articleIds.includes(a.id)) {
        out.set(`article:${a.id}`, {
          contentType: "article",
          contentId: a.id,
          title: a.title,
          excerpt: a.excerpt,
          coverImage: a.coverImage,
          videoUrl: a.videoUrl,
          authorId: a.author.id,
          authorFullName: a.author.fullName,
          authorUsername: a.author.username,
          authorAvatarColor: a.author.avatarColor,
          authorAvatarUrl: a.author.avatarUrl,
          authorIsVerified: a.author.isVerified,
          createdAt: a.publishedAt?.toISOString() ?? null,
          parentPostId: null,
          parentArticleId: null,
        });
      }
      // Add to "video" key (when requested as video AND has videoUrl).
      if (hasVideo && videoIds.includes(a.id)) {
        out.set(`video:${a.id}`, {
          contentType: "video",
          contentId: a.id,
          title: a.title,
          excerpt: a.excerpt,
          coverImage: a.coverImage,
          videoUrl: a.videoUrl,
          authorId: a.author.id,
          authorFullName: a.author.fullName,
          authorUsername: a.author.username,
          authorAvatarColor: a.author.avatarColor,
          authorAvatarUrl: a.author.avatarUrl,
          authorIsVerified: a.author.isVerified,
          createdAt: a.publishedAt?.toISOString() ?? null,
          parentPostId: null,
          parentArticleId: null,
        });
      }
    }
  }

  // Fetch discussions (PostComment OR ArticleComment).
  // Check both tables — a discussion item's contentId could be either.
  if (discussionIds.length > 0) {
    const [postComments, articleComments] = await Promise.all([
      db.postComment.findMany({
        where: { id: { in: discussionIds } },
        select: {
          id: true,
          content: true,
          createdAt: true,
          postId: true,
          author: {
            select: {
              id: true,
              fullName: true,
              username: true,
              avatarColor: true,
              avatarUrl: true,
              isVerified: true,
            },
          },
        },
      }),
      db.articleComment.findMany({
        where: { id: { in: discussionIds } },
        select: {
          id: true,
          content: true,
          createdAt: true,
          articleId: true,
          author: {
            select: {
              id: true,
              fullName: true,
              username: true,
              avatarColor: true,
              avatarUrl: true,
              isVerified: true,
            },
          },
        },
      }),
    ]);
    for (const c of postComments) {
      out.set(`discussion:${c.id}`, {
        contentType: "discussion",
        contentId: c.id,
        title: null,
        excerpt: c.content.slice(0, 160),
        coverImage: null,
        videoUrl: null,
        authorId: c.author.id,
        authorFullName: c.author.fullName,
        authorUsername: c.author.username,
        authorAvatarColor: c.author.avatarColor,
        authorAvatarUrl: c.author.avatarUrl,
        authorIsVerified: c.author.isVerified,
        createdAt: c.createdAt.toISOString(),
        parentPostId: c.postId,
        parentArticleId: null,
      });
    }
    for (const c of articleComments) {
      out.set(`discussion:${c.id}`, {
        contentType: "discussion",
        contentId: c.id,
        title: null,
        excerpt: c.content.slice(0, 160),
        coverImage: null,
        videoUrl: null,
        authorId: c.author.id,
        authorFullName: c.author.fullName,
        authorUsername: c.author.username,
        authorAvatarColor: c.author.avatarColor,
        authorAvatarUrl: c.author.avatarUrl,
        authorIsVerified: c.author.isVerified,
        createdAt: c.createdAt.toISOString(),
        parentPostId: null,
        parentArticleId: c.articleId,
      });
    }
  }

  return out;
}

// ── Already-saved state (for the Save dialog) ───────────────────────────────

/**
 * For the Save-to-Collection dialog: given a (contentType, contentId) pair
 * + the current user, return the list of the user's collections that
 * ALREADY contain this content. Used to show the already-saved state in
 * the dialog.
 *
 * Returns minimal collection projections (id + name only) — the dialog
 * only needs to highlight which collections already contain this item.
 *
 * SECURITY: viewerId is the authenticated user from the session. The query
 * filters by `ownerId = viewerId` so users can NEVER see which OTHER users'
 * collections contain a given content (privacy: collection membership is
 * private to the owner).
 */
export async function getCollectionsContainingContent(
  viewerId: string,
  contentType: CollectionContentType,
  contentId: string
): Promise<Array<{ id: string; name: string; isPublic: boolean }>> {
  const rows = await db.collection.findMany({
    where: {
      ownerId: viewerId,
      items: { some: { contentType, contentId } },
    },
    select: { id: true, name: true, isPublic: true },
    orderBy: { updatedAt: "desc" },
  });
  return rows;
}
