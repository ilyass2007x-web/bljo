/**
 * Moderation Engine — Categories
 * ==============================
 *
 * Static metadata about each ModerationCategory: human-readable labels
 * (for the admin dashboard) and color classes (for badges).
 *
 * Pure data — no DB, no Node-only modules. Safe to import from anywhere.
 */

import type { ModerationCategory, ModerationSeverity } from "./types";

export interface CategoryMeta {
  /** Stable identifier (matches the union type). */
  id: ModerationCategory;
  /** Short human label for the admin UI. */
  label: string;
  /** Longer description for the admin tooltip. */
  description: string;
  /** Tailwind badge color classes (used by the admin dashboard). */
  badgeClass: string;
  /** Default severity when this category is matched. The actual severity
   *  can be raised by individual rules in rules.ts (e.g. a single
   *  profanity = LOW, but 5 profanities in 1 sentence = HIGH). */
  defaultSeverity: ModerationSeverity;
}

export const CATEGORY_META: Record<ModerationCategory, CategoryMeta> = {
  sexual_explicit: {
    id: "sexual_explicit",
    label: "Sexual / Explicit",
    description: "Sexual or pornographic content, explicit descriptions.",
    badgeClass: "bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300",
    defaultSeverity: "HIGH",
  },
  sexual_solicitation: {
    id: "sexual_solicitation",
    label: "Sexual Solicitation",
    description: "Requests for sexual services, propositions, escort ads.",
    badgeClass: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
    defaultSeverity: "HIGH",
  },
  sexual_exploitation: {
    id: "sexual_exploitation",
    label: "Sexual Exploitation",
    description: "Content related to CSA, trafficking, or exploitation of minors.",
    badgeClass: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
    defaultSeverity: "CRITICAL",
  },
  profanity: {
    id: "profanity",
    label: "Profanity",
    description: "Strong abusive language, swearing, extreme vulgarity.",
    badgeClass: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
    defaultSeverity: "LOW",
  },
  harassment: {
    id: "harassment",
    label: "Harassment",
    description: "Targeted insults, bullying, sustained personal attacks.",
    badgeClass: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300",
    defaultSeverity: "MEDIUM",
  },
  hate_speech: {
    id: "hate_speech",
    label: "Hate Speech",
    description: "Slurs and attacks based on race, religion, ethnicity, orientation.",
    badgeClass: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
    defaultSeverity: "HIGH",
  },
  threats: {
    id: "threats",
    label: "Threats / Violence",
    description: "Credible threats of violence, harm, or illegal acts.",
    badgeClass: "bg-red-200 text-red-800 dark:bg-red-900/60 dark:text-red-200",
    defaultSeverity: "HIGH",
  },
  spam: {
    id: "spam",
    label: "Spam",
    description: "Repetitive, promotional, or low-effort flooding content.",
    badgeClass: "bg-slate-100 text-slate-700 dark:bg-slate-800/60 dark:text-slate-300",
    defaultSeverity: "LOW",
  },
  illegal: {
    id: "illegal",
    label: "Illegal / Dangerous",
    description: "Content promoting illegal drugs, weapons, or dangerous acts.",
    badgeClass: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
    defaultSeverity: "HIGH",
  },
};

/** Ordered list — used by the admin UI to render the categories in a
 *  consistent order (most severe first). */
export const CATEGORY_ORDER: ModerationCategory[] = [
  "sexual_exploitation",
  "sexual_solicitation",
  "sexual_explicit",
  "hate_speech",
  "threats",
  "illegal",
  "harassment",
  "profanity",
  "spam",
];

/** Severity → Tailwind badge color. */
export const SEVERITY_BADGE: Record<ModerationSeverity, string> = {
  LOW: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  MEDIUM: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  HIGH: "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300",
  CRITICAL: "bg-red-200 text-red-800 dark:bg-red-900/60 dark:text-red-200",
};
