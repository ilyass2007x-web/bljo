/**
 * Moderation Engine — Type Definitions
 * =====================================
 *
 * Shared types for the centralized content moderation system. These types
 * are PURE — no DB access, no Prisma, no Node-only modules. They can be
 * imported from BOTH server and client modules, but the moderation ENGINE
 * itself (rules.ts, content-moderation.ts) MUST only be invoked from
 * server-side API routes (it reads admin settings via PlatformSetting,
 * which requires DB access).
 *
 * SECURITY: never expose `matchedRules` or internal `reasons` to end users.
 *           Only `userMessage` (a generic community-guidelines string)
 *           is safe to surface in API responses.
 */

/** Content types the moderation engine knows how to handle. */
export type ModerationContentType =
  | "post"
  | "article"
  | "article_title"
  | "article_excerpt"
  | "post_comment"
  | "article_comment"
  | "profile_bio"
  | "profile_full_name";

/** Moderation action the engine decided to take. */
export type ModerationAction = "ALLOW" | "WARN" | "BLOCK" | "REVIEW";

/** Severity buckets. Higher = more serious. */
export type ModerationSeverity = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

/** Violation categories — what KIND of policy was matched. */
export type ModerationCategory =
  | "sexual_explicit"
  | "sexual_solicitation"
  | "sexual_exploitation"
  | "profanity"
  | "harassment"
  | "hate_speech"
  | "threats"
  | "spam"
  | "illegal";

/** Context hints derived from surrounding text (educational, medical, news). */
export type ModerationContext =
  | "educational"
  | "medical"
  | "news"
  | "discussion"
  | "explicit"
  | "neutral";

/**
 * A single rule that matched the input text.
 *
 * `ruleId` is an opaque identifier used internally + in admin logs.
 * It is NEVER returned to end users — only `userMessage` is.
 */
export interface MatchedRule {
  ruleId: string;
  category: ModerationCategory;
  severity: ModerationSeverity;
  /** Confidence 0..1 — how sure the engine is this match is real. */
  confidence: number;
  /** The matched substring (or normalized form). NEVER sent to end users. */
  match: string;
}

/**
 * Full structured result of `moderateContent()`.
 *
 * SECURITY: only `allowed`, `action`, `userMessage`, and (optionally)
 * `score` should ever be exposed to end users. The `categories`,
 * `reasons`, `matchedRules`, `normalizedText`, `severity`, and `context`
 * fields are admin-only.
 */
export interface ModerationResult {
  /** Whether the content should be persisted to the DB. */
  allowed: boolean;
  /** The action the engine recommends. */
  action: ModerationAction;
  /** Composite score 0..100 (higher = more likely to be a violation). */
  score: number;
  /** Highest severity among all matched rules. */
  severity: ModerationSeverity;
  /** All categories that matched. */
  categories: ModerationCategory[];
  /** Internal reasons (admin-only — never expose to end users). */
  reasons: string[];
  /** Internal rule matches (admin-only — never expose to end users). */
  matchedRules: MatchedRule[];
  /** Derived context (educational/medical/news/...). */
  context: ModerationContext;
  /** The normalized text the engine analyzed. NEVER persisted to the DB
   *  as the user's content — the user's ORIGINAL text is what we store.
   *  This is included for admin review and audit purposes only. */
  normalizedText: string;
  /** Safe, generic message shown to the end user when allowed=false. */
  userMessage: string;
}

/** Input shape for `moderateContent()`. */
export interface ModerationInput {
  /** Raw user text. Will be normalized by the engine — original is never mutated. */
  text: string;
  /** Which content type this is (post, comment, profile bio, etc.). */
  contentType: ModerationContentType;
  /** Optional user ID — used for repeat-violation tracking (future use). */
  userId?: string;
  /** Optional hint — currently informational, may affect scoring later. */
  language?: string;
}

/** Admin-facing safe subset of fields for the moderation queue UI. */
export interface ModerationQueueItem {
  id: string;
  contentType: ModerationContentType;
  contentId: string | null;
  userId: string;
  userFullName: string;
  userUsername: string;
  status: ModerationStatus;
  action: ModerationAction;
  severity: ModerationSeverity;
  score: number;
  categories: ModerationCategory[];
  reasons: string[];
  /** A short, sanitized preview of the flagged content (first 200 chars). */
  contentPreview: string;
  createdAt: string;
  reviewedAt: string | null;
  reviewedBy: string | null;
  reviewedByName: string | null;
}

/** Moderation queue lifecycle. */
export type ModerationStatus = "PENDING" | "APPROVED" | "REJECTED" | "DISMISSED";

/**
 * Map severity → numeric weight for scoring.
 * Used internally by `scoring.ts`.
 */
export const SEVERITY_WEIGHT: Record<ModerationSeverity, number> = {
  LOW: 10,
  MEDIUM: 30,
  HIGH: 60,
  CRITICAL: 100,
};

/** Convenience: severity rank for comparison (LOW < MEDIUM < HIGH < CRITICAL). */
export const SEVERITY_RANK: Record<ModerationSeverity, number> = {
  LOW: 1,
  MEDIUM: 2,
  HIGH: 3,
  CRITICAL: 4,
};

/**
 * Generic, safe end-user message strings. NEVER reveal which keyword
 * matched — only that the content violates community guidelines.
 */
export const USER_MESSAGES = {
  blocked:
    "Your content couldn't be published because it violates our community guidelines.",
  warned:
    "This content may violate our community guidelines. Please review it before posting.",
  review:
    "Your content was submitted for review. It will be visible once approved by a moderator.",
} as const;
