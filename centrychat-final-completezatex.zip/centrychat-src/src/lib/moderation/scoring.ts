/**
 * Moderation Engine — Scoring
 * ===========================
 *
 * Pure functions that take the matched rules + context and produce the
 * final `score` (0..100) + `severity` + `action` + `allowed` decision.
 *
 * NO DB, NO Prisma, NO Node-only modules. Pure.
 *
 * Scoring formula (additive, capped at 100):
 *   score = sum over matches of:
 *             SEVERITY_WEIGHT[severity] * confidence
 *         + spam bonus (caps-lock, repeat tokens)
 *
 * The score is then mapped to action + severity via thresholds. These
 * thresholds are tuned for a low false-positive rate:
 *
 *   score < 10  → ALLOW  (severity = LOW)
 *   10 ≤ score < 30 → WARN  (severity = LOW/MEDIUM)
 *   30 ≤ score < 60 → REVIEW (severity = MEDIUM/HIGH)
 *   score ≥ 60    → BLOCK  (severity = HIGH/CRITICAL)
 *
 * CRITICAL-severity matches (sexual_exploitation) ALWAYS trigger BLOCK
 * regardless of score — they have a high base weight and contextSensitive=false
 * so they can't be downgraded.
 */

import type {
  MatchedRule,
  ModerationAction,
  ModerationCategory,
  ModerationContext,
  ModerationResult,
  ModerationSeverity,
  USER_MESSAGES as _UM,
} from "./types";
import { SEVERITY_WEIGHT, SEVERITY_RANK, USER_MESSAGES } from "./types";

/** Result of the scoring pass — passed back to the engine for assembly. */
export interface ScoreResult {
  score: number;
  severity: ModerationSeverity;
  action: ModerationAction;
  allowed: boolean;
  userMessage: string;
}

/**
 * Aggregate matches → final score + severity + action.
 *
 * @param matches All rule matches (already context-adjusted for confidence).
 * @param context Detected context (educational/medical/news/explicit/neutral).
 * @param capsLockSpam Whether the caps-lock spam check fired.
 * @param strictness Admin-configured strictness 1..3 (1=permissive, 3=strict).
 * @param autoBlockHigh When true, REVIEW-threshold content is auto-BLOCKED
 *                      instead of being sent to the review queue. Used by the
 *                      `auto_block_high_confidence` admin setting.
 */
export function computeScore(
  matches: MatchedRule[],
  context: ModerationContext,
  capsLockSpam: boolean,
  strictness: number,
  autoBlockHigh: boolean
): ScoreResult {
  // Step 1: sum the per-match severity weights * confidence.
  let rawScore = 0;
  for (const m of matches) {
    rawScore += SEVERITY_WEIGHT[m.severity] * m.confidence;
  }

  // Step 2: spam bonuses.
  if (capsLockSpam) rawScore += 10;

  // Step 3: multiple-match escalation. If 3+ distinct rules matched, the
  // content is likely a deliberate violation — boost the score by 25%.
  if (matches.length >= 3) rawScore *= 1.25;

  // Step 4: explicit-context boost. If the surrounding text shows NO benign
  // context markers (educational/medical/news/discussion) AND we have at
  // least one explicit-category match, boost by 20%. This rewards benign
  // contexts (we already downgraded their confidence in rules.ts) and
  // penalizes bare explicit content.
  const hasExplicit = matches.some(
    (m) =>
      m.category === "sexual_explicit" ||
      m.category === "sexual_solicitation" ||
      m.category === "sexual_exploitation"
  );
  if (hasExplicit && context !== "educational" && context !== "medical" && context !== "news" && context !== "discussion") {
    rawScore *= 1.2;
  }

  // Step 5: apply strictness multiplier.
  // 1=0.8 (permissive), 2=1.0 (default), 3=1.3 (strict).
  const strictnessMult = strictness === 3 ? 1.3 : strictness === 1 ? 0.8 : 1.0;
  rawScore *= strictnessMult;

  // Step 6: cap at 100.
  const score = Math.min(100, Math.round(rawScore));

  // Step 7: find the highest-severity match (used for the final severity).
  let severity: ModerationSeverity = "LOW";
  for (const m of matches) {
    if (SEVERITY_RANK[m.severity] > SEVERITY_RANK[severity]) {
      severity = m.severity;
    }
  }

  // Step 8: CRITICAL escalation — any CRITICAL match forces BLOCK regardless
  // of the computed score (defense-in-depth: CSA / exploitation content
  // is never allowed through even if the score somehow came out low).
  const hasCritical = matches.some((m) => m.severity === "CRITICAL");
  if (hasCritical) {
    return {
      score: Math.max(score, 90),
      severity: "CRITICAL",
      action: "BLOCK",
      allowed: false,
      userMessage: USER_MESSAGES.blocked,
    };
  }

  // Step 9: map score → action.
  // Thresholds adjusted for strictness: at strictness=3, REVIEW→BLOCK.
  let action: ModerationAction;
  let allowed: boolean;
  let userMessage: string;

  if (score < 10) {
    action = "ALLOW";
    allowed = true;
    userMessage = "";
    severity = "LOW";
  } else if (score < 30) {
    action = "WARN";
    allowed = true; // WARN = allow but log for admin review
    userMessage = USER_MESSAGES.warned;
    if (severity === "LOW") severity = "MEDIUM";
  } else if (score < 60) {
    // REVIEW threshold. When autoBlockHigh=true, escalate to BLOCK.
    if (autoBlockHigh) {
      action = "BLOCK";
      allowed = false;
      userMessage = USER_MESSAGES.blocked;
    } else {
      action = "REVIEW";
      allowed = true; // REVIEW = allow but queue for moderator (publish + flag)
      userMessage = USER_MESSAGES.review;
    }
    if (severity === "LOW" || severity === "MEDIUM") severity = "HIGH";
  } else {
    action = "BLOCK";
    allowed = false;
    userMessage = USER_MESSAGES.blocked;
    if (severity === "LOW" || severity === "MEDIUM" || severity === "HIGH") {
      severity = "HIGH";
    }
  }

  return { score, severity, action, allowed, userMessage };
}

/**
 * Pick the headline category for the result. Used by the admin dashboard
 * to show the "top violation category". We pick the category with the
 * highest severity (ties broken by highest confidence).
 */
export function pickHeadlineCategory(
  matches: MatchedRule[]
): ModerationCategory | null {
  if (matches.length === 0) return null;
  const sorted = [...matches].sort((a, b) => {
    if (SEVERITY_RANK[b.severity] !== SEVERITY_RANK[a.severity]) {
      return SEVERITY_RANK[b.severity] - SEVERITY_RANK[a.severity];
    }
    return b.confidence - a.confidence;
  });
  return sorted[0]!.category;
}

/**
 * Build the final ModerationResult from the engine's internal pieces.
 */
export function assembleResult(opts: {
  normalizedText: string;
  matches: MatchedRule[];
  context: ModerationContext;
  score: ScoreResult;
}): Pick<
  ModerationResult,
  | "score"
  | "severity"
  | "categories"
  | "reasons"
  | "matchedRules"
  | "context"
  | "normalizedText"
  | "allowed"
  | "action"
  | "userMessage"
> {
  const { normalizedText, matches, context, score } = opts;

  // Dedupe categories (preserve insertion order).
  const categories: ModerationCategory[] = [];
  for (const m of matches) {
    if (!categories.includes(m.category)) categories.push(m.category);
  }

  // Build admin-only reasons (never sent to end users).
  const reasons: string[] = matches.map(
    (m) => `${m.ruleId} (${m.category}, ${m.severity}, conf=${m.confidence.toFixed(2)})`
  );

  return {
    allowed: score.allowed,
    action: score.action,
    score: score.score,
    severity: score.severity,
    categories,
    reasons,
    matchedRules: matches,
    context,
    normalizedText,
    userMessage: score.userMessage,
  };
}
