/**
 * Moderation Engine — Orchestrator
 * =================================
 *
 * SERVER-ONLY. Reads admin-configurable settings (PlatformSetting) so the
 * engine behavior can be tuned without code changes. NEVER imported from
 * client components.
 *
 * This is the single public entry point: `moderateContent()`.
 *
 * All other modules in src/lib/moderation/ are pure functions / pure data
 * — they don't touch the DB and could in principle be reused by a client
 * utility, BUT we deliberately keep the engine's invocation gated behind
 * this server-only file so the word lists never ship to the browser.
 */

import { getSetting, getSettingBool, getSettingNumber } from "@/lib/settings";
import { normalizeForModeration, stripSpaces } from "./normalize";
import { matchRules, isCapsLockSpam } from "./rules";
import { computeScore, assembleResult } from "./scoring";
import type { ModerationInput, ModerationResult } from "./types";

/**
 * Default strictness — used when the admin hasn't configured
 * `platform.moderation.strictness` yet. 2 = balanced.
 *
 * 1 = permissive (low false-positive rate, may miss subtle violations)
 * 2 = balanced (default)
 * 3 = strict (aggressive, may produce more false positives)
 */
const DEFAULT_STRICTNESS = 2;

/**
 * The main moderation entry point.
 *
 * Flow:
 *   1. Check the master `platform.moderation.enabled` flag. If false,
 *      return ALLOW immediately (still records nothing — see note below).
 *   2. Normalize the input text (lowercase, strip zero-width chars +
 *      diacritics, apply leetspeak substitutions, collapse runs).
 *   3. Run ALL rules against both the normalized + space-stripped forms.
 *      Collect every match.
 *   4. Detect context (educational/medical/news/discussion/explicit/neutral).
 *      Downgrade confidence of contextSensitive rules in benign contexts.
 *   5. Compute the composite score + severity + action via scoring.ts.
 *   6. Return the structured result.
 *
 * @param input.text - The raw user-submitted text (NEVER mutated by this fn).
 * @param input.contentType - One of: post, article, article_title,
 *                            article_excerpt, post_comment, article_comment,
 *                            profile_bio, profile_full_name.
 * @param input.userId - Optional — reserved for repeat-violation tracking.
 * @param input.language - Optional — informational only (the engine is
 *                        already multilingual and auto-detects Arabic).
 */
export async function moderateContent(
  input: ModerationInput
): Promise<ModerationResult> {
  const text = input.text ?? "";

  // ── Master switch ──────────────────────────────────────────────────
  // When the admin has globally disabled moderation, we ALLOW everything.
  // This is the SINGLE place that check happens — there is no per-endpoint
  // override (the admin is responsible for understanding the trade-off).
  //
  // SECURITY: even when moderation is "disabled", the existing server-side
  // validation (length limits, type checks, no-HTML) still runs in the
  // route handlers. So "disabled moderation" does NOT mean "no validation".
  const moderationEnabled = await getSettingBool("platform.moderation.enabled");
  if (!moderationEnabled) {
    return {
      allowed: true,
      action: "ALLOW",
      score: 0,
      severity: "LOW",
      categories: [],
      reasons: [],
      matchedRules: [],
      context: "neutral",
      normalizedText: "",
      userMessage: "",
    };
  }

  // ── Per-category enable/disable ────────────────────────────────────
  // Read the admin's per-category toggles. When a category is disabled,
  // we still RUN its rules (so we can detect + log) but we DON'T escalate
  // to BLOCK. This keeps a paper trail while respecting the admin's choice.
  const [
    sexualEnabled,
    harassmentEnabled,
    hateEnabled,
    threatsEnabled,
    profanityEnabled,
  ] = await Promise.all([
    getSettingBool("platform.moderation.sexual_enabled"),
    getSettingBool("platform.moderation.harassment_enabled"),
    getSettingBool("platform.moderation.hate_enabled"),
    getSettingBool("platform.moderation.threats_enabled"),
    getSettingBool("platform.moderation.profanity_enabled"),
  ]);

  // ── Strictness + auto-block setting ────────────────────────────────
  const strictness = (await getSettingNumber("platform.moderation.strictness")) ?? DEFAULT_STRICTNESS;
  const autoBlockHigh = await getSettingBool("platform.moderation.auto_block_high");

  // ── Normalize + analyze ───────────────────────────────────────────
  const normalizedText = normalizeForModeration(text, input.contentType);
  const spaceStripped = stripSpaces(normalizedText);
  const capsLockSpam = isCapsLockSpam(text);

  // Run rules.
  const { matches: allMatches, context } = matchRules(normalizedText, spaceStripped);

  // Filter out matches from disabled categories. We DO NOT filter CRITICAL
  // matches (sexual_exploitation) — those are ALWAYS enforced regardless
  // of admin settings, because they're illegal content (CSA, trafficking).
  const matches = allMatches.filter((m) => {
    if (m.severity === "CRITICAL") return true; // always enforced
    switch (m.category) {
      case "sexual_explicit":
      case "sexual_solicitation":
        return sexualEnabled;
      case "harassment":
        return harassmentEnabled;
      case "hate_speech":
        return hateEnabled;
      case "threats":
        return threatsEnabled;
      case "profanity":
        return profanityEnabled;
      case "sexual_exploitation":
      case "illegal":
      case "spam":
        return true; // always enforced
      default:
        return true;
    }
  });

  // ── Score + decide ─────────────────────────────────────────────────
  const score = computeScore(
    matches,
    context,
    capsLockSpam,
    strictness,
    autoBlockHigh
  );

  const assembled = assembleResult({
    normalizedText,
    matches,
    context,
    score,
  });

  return assembled;
}

/**
 * Convenience: returns just the boolean "should we persist this content?"
 * Used by API routes that don't care about the full result (they just
 * need a yes/no + the user message).
 *
 * The full result is recorded separately (see recordModerationEvent) when
 * the action is WARN/REVIEW/BLOCK.
 */
export async function isContentAllowed(
  input: ModerationInput
): Promise<{ allowed: boolean; action: ModerationResult["action"]; userMessage: string }> {
  const result = await moderateContent(input);
  return {
    allowed: result.allowed,
    action: result.action,
    userMessage: result.userMessage,
  };
}
