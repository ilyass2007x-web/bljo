/**
 * User Warning Service
 * ====================
 *
 * SERVER-ONLY. Provides the admin user-warning functionality:
 *   - issueWarning() — creates a UserWarning + Notification + AuditLog
 *   - getUserWarnings() — list warnings for a user (admin view)
 *   - getUserModerationHistory() — unified history (warnings + events + reports)
 *
 * SECURITY: all functions require the caller to have already verified admin
 * permissions (requireAdmin). The service does NOT re-check permissions —
 * it trusts the API route layer. This keeps the service focused on data
 * operations + prevents double-checking overhead.
 */

import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { recordAudit } from "@/lib/audit";
import { createNotification } from "@/lib/notifications";

// ── Types ──────────────────────────────────────────────────────────────

export type WarningReason =
  | "SEXUAL_CONTENT"
  | "NUDITY"
  | "VIOLENCE"
  | "HATE"
  | "HARASSMENT"
  | "SPAM"
  | "MALICIOUS_LINK"
  | "OTHER";

export const WARNING_REASONS: WarningReason[] = [
  "SEXUAL_CONTENT",
  "NUDITY",
  "VIOLENCE",
  "HATE",
  "HARASSMENT",
  "SPAM",
  "MALICIOUS_LINK",
  "OTHER",
];

export interface IssueWarningInput {
  userId: string;
  adminId: string;
  reason: WarningReason;
  message: string;
  moderationEventId?: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface UserWarningRow {
  id: string;
  userId: string;
  issuedById: string | null;
  issuedByName: string | null;
  reason: WarningReason;
  message: string;
  moderationEventId: string | null;
  createdAt: string;
}

export interface ModerationHistoryItem {
  type: "warning" | "moderation_event" | "report";
  id: string;
  createdAt: string;
  reason: string;
  details: string;
  adminName: string | null;
  status: string;
}

// ── Validation ─────────────────────────────────────────────────────────

const MAX_MESSAGE_LENGTH = 1000;

/**
 * Validate the warning input. Returns an error string or null if valid.
 */
export function validateWarningInput(input: {
  reason: string;
  message: string;
}): string | null {
  if (!WARNING_REASONS.includes(input.reason as WarningReason)) {
    return `Invalid warning reason: ${input.reason}`;
  }
  const msg = input.message.trim();
  if (!msg) return "Warning message cannot be empty";
  if (msg.length > MAX_MESSAGE_LENGTH) {
    return `Warning message too long (max ${MAX_MESSAGE_LENGTH} chars)`;
  }
  return null;
}

// ── Issue Warning ──────────────────────────────────────────────────────

/**
 * Issue a formal warning to a user.
 *
 * Creates:
 *   1. A UserWarning row (permanent record in the user's moderation history)
 *   2. A Notification (so the user sees it in their notification bell)
 *   3. An AdminAuditLog entry (for admin accountability)
 *
 * The notification uses type="MODERATION" which is always shown to the user
 * (security notifications bypass the user's notification preferences).
 *
 * Returns the created UserWarning ID, or null on failure.
 */
export async function issueWarning(
  input: IssueWarningInput
): Promise<string | null> {
  try {
    // Create the UserWarning row.
    const warning = await db.userWarning.create({
      data: {
        userId: input.userId,
        issuedById: input.adminId,
        reason: input.reason,
        message: input.message.trim(),
        moderationEventId: input.moderationEventId ?? null,
      },
      select: { id: true },
    });

    // Create a notification for the user (MODERATION type — always shown).
    // Use the createNotification helper which respects notification prefs
    // EXCEPT for SECURITY type (which is always sent). We use MODERATION
    // here because it's a moderation action, not a security alert.
    try {
      await createNotification({
        userId: input.userId,
        type: "MODERATION",
        title: "Community Guidelines Warning",
        message: input.message.trim(),
        metadata: {
          warningId: warning.id,
          reason: input.reason,
          moderationEventId: input.moderationEventId ?? null,
        },
      });
    } catch (notifErr) {
      // Notification failure is non-fatal — the warning is still recorded.
      logger.warn("application", "Warning notification failed (non-fatal)", {
        warningId: warning.id,
        error: notifErr instanceof Error ? notifErr.message : String(notifErr),
      });
    }

    // Record the audit log entry.
    try {
      await recordAudit({
        adminId: input.adminId,
        action: "admin.user.warn",
        targetType: "user",
        targetId: input.userId,
        metadata: {
          warningId: warning.id,
          reason: input.reason,
          messageLength: input.message.trim().length,
          moderationEventId: input.moderationEventId ?? null,
        },
        ipAddress: input.ipAddress,
        userAgent: input.userAgent,
      });
    } catch (auditErr) {
      // Audit failure is non-fatal.
      logger.warn("application", "Warning audit log failed (non-fatal)", {
        warningId: warning.id,
        error: auditErr instanceof Error ? auditErr.message : String(auditErr),
      });
    }

    return warning.id;
  } catch (err) {
    logger.error("application", "issueWarning failed", {
      userId: input.userId,
      reason: input.reason,
      error: err instanceof Error ? err.message : String(err),
    });
    return null;
  }
}

// ── Get User Warnings ──────────────────────────────────────────────────

/**
 * List all warnings for a user (admin view). Returns newest-first.
 */
export async function getUserWarnings(userId: string): Promise<UserWarningRow[]> {
  const warnings = await db.userWarning.findMany({
    where: { userId },
    include: {
      issuedBy: { select: { fullName: true, username: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return warnings.map((w) => ({
    id: w.id,
    userId: w.userId,
    issuedById: w.issuedById,
    issuedByName: w.issuedBy?.fullName ?? null,
    reason: w.reason as WarningReason,
    message: w.message,
    moderationEventId: w.moderationEventId,
    createdAt: w.createdAt.toISOString(),
  }));
}

// ── Get User Moderation History ────────────────────────────────────────

/**
 * Unified moderation history for a user. Merges:
 *   - Warnings (from UserWarning table)
 *   - Moderation events (from ModerationEvent table — automated flags)
 *   - Reports (from Report table where targetUserId = userId)
 *
 * Used by the admin user detail panel to show a complete moderation timeline.
 *
 * Returns newest-first, capped at 100 items.
 */
export async function getUserModerationHistory(
  userId: string
): Promise<ModerationHistoryItem[]> {
  const [warnings, moderationEvents, reports] = await Promise.all([
    db.userWarning.findMany({
      where: { userId },
      include: { issuedBy: { select: { fullName: true } } },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
    db.moderationEvent.findMany({
      where: { userId },
      include: { reviewer: { select: { fullName: true } } },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
    db.report.findMany({
      where: { targetUserId: userId },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
  ]);

  const items: ModerationHistoryItem[] = [];

  // Warnings
  for (const w of warnings) {
    items.push({
      type: "warning",
      id: w.id,
      createdAt: w.createdAt.toISOString(),
      reason: w.reason,
      details: w.message,
      adminName: w.issuedBy?.fullName ?? null,
      status: "ISSUED",
    });
  }

  // Moderation events (automated flags)
  for (const e of moderationEvents) {
    items.push({
      type: "moderation_event",
      id: e.id,
      createdAt: e.createdAt.toISOString(),
      reason: `Auto-moderation: ${e.action} (${e.severity}, score=${e.score})`,
      details: e.contentPreview,
      adminName: e.reviewer?.fullName ?? null,
      status: e.status,
    });
  }

  // Reports (user-submitted)
  for (const r of reports) {
    items.push({
      type: "report",
      id: r.id,
      createdAt: r.createdAt.toISOString(),
      reason: r.reason,
      details: r.description,
      adminName: null, // resolvedBy relation not available without explicit include
      status: r.status,
    });
  }

  // Sort newest-first + cap at 100.
  items.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return items.slice(0, 100);
}

// ── Bulk Issue Warnings ────────────────────────────────────────────────

/**
 * Issue the same warning to multiple users. Used by the bulk moderation
 * action in the admin dashboard.
 *
 * Returns per-user results so the admin sees which warnings succeeded.
 */
export async function bulkIssueWarnings(opts: {
  userIds: string[];
  adminId: string;
  reason: WarningReason;
  message: string;
  ipAddress?: string;
  userAgent?: string;
}): Promise<{
  requested: number;
  issued: number;
  failed: number;
  results: Array<{ userId: string; success: boolean; warningId: string | null }>;
}> {
  const results: Array<{ userId: string; success: boolean; warningId: string | null }> = [];

  for (const userId of opts.userIds) {
    const warningId = await issueWarning({
      userId,
      adminId: opts.adminId,
      reason: opts.reason,
      message: opts.message,
      ipAddress: opts.ipAddress,
      userAgent: opts.userAgent,
    });
    results.push({ userId, success: warningId !== null, warningId });
  }

  return {
    requested: opts.userIds.length,
    issued: results.filter((r) => r.success).length,
    failed: results.filter((r) => !r.success).length,
    results,
  };
}
