/**
 * Moderation Engine — Text Normalization
 * ======================================
 *
 * Pure functions. NO DB access, NO Prisma, NO Node-only modules. Safe to
 * import from anywhere, but ONLY ever invoked from server-side moderation
 * code (we don't want client bundles to ship the word lists).
 *
 * DESIGN PRINCIPLE: the user's ORIGINAL text is NEVER modified. We produce
 * a SEPARATE normalized string used ONLY for analysis. The original text is
 * what gets persisted to the DB.
 *
 * What we normalize for the ANALYSIS pass (without touching the original):
 *
 *   1. Lowercase (case-insensitive matching).
 *   2. Strip zero-width chars (U+200B, U+200C, U+200D, U+FEFF) — these are
 *      used to break "porn" into "p\u200Born" to evade naive `includes`.
 *   3. Strip Arabic diacritics (tashkeel: fatha, kasra, damma, etc.) so
 *      "سَلام" matches "سلام".
 *   4. Collapse repeated whitespace (so "p o r n" doesn't evade word-list
 *      matching when we apply space-stripped comparison).
 *   5. Apply common leetspeak substitutions:
 *        0 → o      1 → i      3 → e      4 → a      5 → s
 *        7 → t      8 → b      $ → s      @ → a      € → e
 *      (Only used for ANALYSIS — never stored.)
 *   6. Collapse repeated characters (so "poooorn" matches "porn"). Done with
 *      a length-aware cap (we don't collapse past 3 chars, otherwise "ssss"
 *      becomes "s" and matches a different word).
 *   7. Strip common inter-word punctuation (".", "-", "_", "*") so "p.o.r.n"
 *      and "p_o_r_n" normalize to "porn".
 *   8. NFC normalization (canonical decomposition → recomposition) so
 *      Unicode lookalikes don't slip through.
 *
 * The output of `normalizeForModeration()` is what rules.ts runs regex
 * matching against. The original `text` argument is left untouched.
 *
 * PERFORMANCE: all transforms are O(n) on the input length. No regex
 * backtracking. A 500-character comment normalizes in microseconds.
 */

import type { ModerationContentType } from "./types";

/**
 * Leetspeak → natural-language substitution map.
 *
 * Applied in this order — we don't apply both numeric + symbol substitutions
 * simultaneously because some symbols can themselves be letters (e.g. `@`
 * can be "at" or "a" depending on context; we use the "a" reading because
 * it's the more common abusive-typo case).
 */
const LEET_MAP: Record<string, string> = {
  "0": "o",
  "1": "i",
  "3": "e",
  "4": "a",
  "5": "s",
  "7": "t",
  "8": "b",
  $: "s",
  "@": "a",
  "€": "e",
  "!": "i",
  "+": "t",
};

/**
 * Strip diacritics from a string.
 *
 * For Latin text: NFD-normalize then strip the combining-mark range U+0300–U+036F.
 * For Arabic text: also strip the tashkeel range U+0610–U+061A + U+064B–U+065F
 * + U+0670 + U+06D6–U+06DC + U+06DF–U+06E4 + U+06E7–U+06E8 + U+06EA–U+06ED
 * (covers fatha, damma, kasra, shadda, sukun, dagger alef, etc.).
 */
function stripDiacritics(input: string): string {
  // NFD = canonical decomposition. Combined characters like "é" become "e" + "´".
  const nfd = input.normalize("NFD");
  // Remove combining diacritical marks (Latin + extensions).
  let out = nfd.replace(/[\u0300-\u036f]/g, "");
  // Remove Arabic diacritics (tashkeel).
  out = out.replace(/[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06dc\u06df-\u06e4\u06e7-\u06e8\u06ea-\u06ed]/g, "");
  // Re-compose to NFC so lookalike codepoints collapse back to canonical form.
  return out.normalize("NFC");
}

/**
 * Strip zero-width characters used to obfuscate words.
 *
 *   U+200B  Zero Width Space
 *   U+200C  Zero Width Non-Joiner (ZWNJ)
 *   U+200D  Zero Width Joiner (ZWJ)  — used in emoji sequences; safe to strip
 *                                     for moderation because we match text.
 *   U+2060  Word Joiner (invisible)
 *   U+FEFF  Zero Width No-Break Space (BOM)
 *   U+00AD  Soft Hyphen
 *   U+180E  Mongolian Vowel Separator
 */
const ZERO_WIDTH_REGEX = /[\u200b\u200c\u200d\u2060\ufeff\u00ad\u180e]/g;

/**
 * Apply leetspeak substitution to a single character.
 * Returns the original char if no substitution exists.
 */
function applyLeet(ch: string): string {
  return LEET_MAP[ch] ?? ch;
}

/**
 * Collapse runs of the same character.
 *
 * "poooorn"     → "porn"     (4 o's → 1)
 * "yessss"      → "yess"     (4 s's → 2; capped at 3 chars max)
 * "aaaaaaaaa"   → "aaa"
 *
 * Cap at 3 chars: a single repeated char might legitimately appear 2-3
 * times in a word ("succeed", "book"). Capping at 3 prevents over-collapse
 * while still defeating "poooooooorn" style obfuscation.
 */
function collapseRepeats(input: string): string {
  return input.replace(/(.)\1{3,}/g, "$1$1$1");
}

/**
 * Strip inter-word punctuation commonly used to break up banned words.
 *
 *   "p.o.r.n"   → "porn"
 *   "p_o_r_n"   → "porn"
 *   "p-o-r-n"   → "porn"
 *   "p*o*r*n"   → "porn"
 *   "p|o|r|n"   → "porn"
 *
 * We do NOT strip ALL punctuation — just the chars abusers use as
 * word-separator substitutes: . - _ * | ~ = and the middle dot ·.
 * We keep commas, question marks, exclamation marks etc. so the
 * sentence-level analysis (educational context detection) still has
 * structure to work with.
 */
const SEPARATOR_PUNCT_REGEX = /[.\-_*|~=\u00b7]/g;

/**
 * Main entry point.
 *
 * Returns the normalized string used for moderation analysis. The input
 * is never modified.
 *
 * @param text The original user-submitted text (untouched after this call).
 * @param _contentType Currently unused — accepted for future per-type
 *                     normalization (e.g. shorter profiles may have
 *                     different collapse rules).
 */
export function normalizeForModeration(
  text: string,
  _contentType?: ModerationContentType
): string {
  if (!text) return "";

  // Step 1: lowercase (case-insensitive matching).
  let out = text.toLowerCase();

  // Step 2: strip zero-width chars (used to break "porn" into "p\u200Bor").
  out = out.replace(ZERO_WIDTH_REGEX, "");

  // Step 3: strip diacritics (Arabic tashkeel + Latin combining marks).
  out = stripDiacritics(out);

  // Step 4: strip inter-word punctuation used as separator substitutes.
  // Done BEFORE leetspeak so "$" and "@" substitutions still apply for
  // standalone leetspeak tokens like "$ex" or "@ss".
  out = out.replace(SEPARATOR_PUNCT_REGEX, "");

  // Step 5: apply leetspeak substitutions.
  let leetApplied = "";
  for (let i = 0; i < out.length; i++) {
    leetApplied += applyLeet(out[i]!);
  }
  out = leetApplied;

  // Step 6: collapse runs of the same char (defeats "poooorn").
  out = collapseRepeats(out);

  // Step 7: collapse runs of whitespace to single spaces + trim.
  out = out.replace(/\s+/g, " ").trim();

  return out;
}

/**
 * ALSO produce a "no-spaces" variant for matching abusers who insert
 * spaces between every letter: "p o r n" → "porn".
 *
 * This is computed SEPARATELY (not by `normalizeForModeration`) because
 * the rules engine wants BOTH variants — the spaced-normalized version
 * (so we still detect "p o r n") AND the spaced version (so we still
 * detect legitimate phrases like "sexual health" without false positives).
 */
export function stripSpaces(input: string): string {
  return input.replace(/\s+/g, "");
}

/**
 * Detect if the text contains Arabic / Darija characters.
 * Used to route the rules engine to Arabic-aware patterns.
 *
 * Returns true if ANY character in the input is in the Arabic Unicode
 * block (U+0600–U+06FF) or Arabic Supplement (U+0750–U+077F) or Arabic
 * Presentation Forms (U+FB50–U+FDFF, U+FE70–U+FEFF).
 */
export function containsArabic(text: string): boolean {
  return /[\u0600-\u06ff\u0750-\u077f\ufb50-\ufdff\ufe70-\ufeff]/.test(text);
}

/**
 * Detect Latin-only text. Used to skip Arabic-specific rules when the
 * text is purely Latin (and vice versa).
 */
export function isLatinOnly(text: string): boolean {
  // Strip whitespace + common punctuation, then check if everything is Latin.
  const stripped = text.replace(/[\s\p{P}\p{S}]/gu, "");
  if (stripped.length === 0) return true;
  return !/[\u0600-\u06ff\u0750-\u077f\ufb50-\ufdff\ufe70-\ufeff]/.test(stripped);
}
