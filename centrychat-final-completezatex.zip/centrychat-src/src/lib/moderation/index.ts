/**
 * Moderation Engine — Public API
 * ===============================
 *
 * SERVER-ONLY. Aggregates the moderation engine's public surface:
 *
 *   - `moderateContent(input)` — analyze text, return a structured result.
 *   - `isContentAllowed(input)` — convenience boolean wrapper.
 *   - `recordModerationEvent(...)` — persist a ModerationEvent row in the DB
 *      (admin-only via the moderation queue UI). Called by API routes after
 *      moderation runs, regardless of ALLOW/WARN/BLOCK — but the row's
 *      `status` field differs:
 *        - ALLOW  → no row written (nothing to review)
 *        - WARN   → row written, status="PENDING" (admin can review later)
 *        - REVIEW → row written, status="PENDING", content IS published
 *        - BLOCK  → row written, status="PENDING", content is NOT published
 *
 *   - `getModerationStats()` — admin dashboard aggregates (counts, top
 *      categories, recent events).
 *   - `getModerationQueue()` — paginated queue list.
 *   - `updateModerationEventStatus(...)` — admin action (APPROVE/REJECT/DISMISS).
 *
 * SECURITY: this module imports `db` (Prisma). NEVER import from a client
 * component. API routes + server actions only.
 *
 * CLIENT/SERVER BOUNDARY: the moderation ENGINE itself (rules.ts, normalize.ts,
 * scoring.ts, categories.ts, types.ts) is pure TypeScript with NO Node-only
 * imports. They COULD theoretically be bundled for the browser. We avoid
 * that by only re-exporting them via THIS file, which imports `db` — making
 * the entire module tree server-only by virtue of the Prisma import.
 */

import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { moderateContent as runModeration, isContentAllowed as checkAllowed } from "./content-moderation";
import { CATEGORY_META, CATEGORY_ORDER } from "./categories";
import { SEVERITY_BADGE } from "./categories";

// Re-export public types + helpers for callers (API routes, server actions).
export type {
  ModerationInput,
  ModerationResult,
  ModerationAction,
  ModerationCategory,
  ModerationContentType,
  ModerationSeverity,
  ModerationStatus,
  ModerationQueueItem,
  ModerationContext,
  MatchedRule,
} from "./types";
export { USER_MESSAGES, SEVERITY_WEIGHT, SEVERITY_RANK } from "./types";
export { CATEGORY_META, CATEGORY_ORDER, SEVERITY_BADGE } from "./categories";
export { moderateContent, isContentAllowed } from "./content-moderation";

import type {
  ModerationResult,
  ModerationContentType,
  ModerationStatus,
  ModerationQueueItem,
} from "./types";

/**
 * Persist a moderation event row.
 *
 * Called by API routes AFTER moderation runs, when action !== ALLOW.
 * For ALLOW, we don't write a row (nothing to review).
 *
 * PRIVACY: we DO NOT store the user's full original text. We store only:
 *   - contentType + contentId (reference back to the content row)
 *   - userId (author)
 *   - action, severity, score, categories, reasons (engine output)
 *   - a short sanitized preview (first 200 chars, used by the admin queue UI)
 *
 * If contentId is null (the content was BLOCKED so nothing was persisted),
 * we still write the moderation event so admins can see what was blocked —
 * but the preview is the only copy of the user's text we keep, and we cap
 * it at 200 chars to minimize stored sensitive content.
 *
 * @param result The engine result.
 * @param contentType Which content type this was.
 * @param contentId The content row ID (null when content was BLOCKED).
 * @param userId The author's user ID.
 * @param originalText The user's submitted text (used ONLY for the preview).
 * @returns The created ModerationEvent ID (null on failure — never throws).
 */
export async function recordModerationEvent(opts: {
  result: ModerationResult;
  contentType: ModerationContentType;
  contentId: string | null;
  userId: string;
  originalText: string;
}): Promise<string | null> {
  // ALLOW → nothing to record.
  if (opts.result.action === "ALLOW") return null;

  // Sanitize the preview: collapse whitespace, trim, cap at 200 chars.
  // We use the user's ORIGINAL text here (not the normalized form)
  // because the admin needs to see what the user actually typed.
  const preview = (opts.originalText ?? "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 200);

  try {
    const event = await db.moderationEvent.create({
      data: {
        contentType: opts.contentType,
        contentId: opts.contentId,
        userId: opts.userId,
        // For BLOCK, the content was never persisted → status starts as
        // PENDING (admin can review what was blocked). For REVIEW, the
        // content IS published but flagged for review. For WARN, same.
        status: "PENDING" as ModerationStatus,
        action: opts.result.action,
        severity: opts.result.severity,
        score: opts.result.score,
        categories: opts.result.categories,
        reasons: opts.result.reasons,
        contentPreview: preview,
      },
      select: { id: true },
    });
    return event.id;
  } catch (err) {
    // Recording failure must NOT crash the request. The moderation decision
    // itself was already made — we just couldn't log it for admin review.
    logger.error("application", "Failed to record moderation event", {
      error: err instanceof Error ? err.message : String(err),
      contentType: opts.contentType,
    });
    return null;
  }
}

// ─── Admin-facing helpers (used by the moderation API routes) ────────────

/**
 * Aggregate stats for the admin dashboard.
 *
 * Returns:
 *   - totalBlocked: count of events with action="BLOCK"
 *   - totalFlagged: count of events with action in (WARN, REVIEW)
 *   - totalReviewed: count of events with status in (APPROVED, REJECTED, DISMISSED)
 *   - pendingReview: count of events with status="PENDING"
 *   - approvalRate: approved / total reviewed (0..1)
 *   - topCategories: [{ category, count }] (top 5)
 *   - byContentType: [{ contentType, count }] (all 8 types)
 *   - bySeverity: [{ severity, count }]
 *   - last7Days: [{ date, count }] (events per day, last 7 days)
 *   - recent: last 10 events with user info
 */
export interface ModerationStats {
  totalBlocked: number;
  totalFlagged: number;
  totalReviewed: number;
  pendingReview: number;
  approvalRate: number;
  topCategories: { category: string; count: number }[];
  byContentType: { contentType: string; count: number }[];
  bySeverity: { severity: string; count: number }[];
  last7Days: { date: string; count: number }[];
}

export async function getModerationStats(): Promise<ModerationStats> {
  const [
    totalBlocked,
    totalFlagged,
    totalReviewed,
    pendingReview,
    approvedCount,
    topCategoriesAgg,
    byContentTypeAgg,
    bySeverityAgg,
    recentEventsRaw,
  ] = await Promise.all([
    db.moderationEvent.count({ where: { action: "BLOCK" } }),
    db.moderationEvent.count({ where: { action: { in: ["WARN", "REVIEW"] } } }),
    db.moderationEvent.count({ where: { status: { in: ["APPROVED", "REJECTED", "DISMISSED"] } } }),
    db.moderationEvent.count({ where: { status: "PENDING" } }),
    db.moderationEvent.count({ where: { status: "APPROVED" } }),
    // Top categories — Prisma can't groupBy JSON array elements directly,
    // so we fetch all events + aggregate in code. For platforms with many
    // thousands of events, this should be cached at the API layer (the
    // admin dashboard only fetches once per page load).
    db.moderationEvent.findMany({
      where: { action: { not: "ALLOW" } },
      select: { categories: true },
    }),
    db.moderationEvent.groupBy({
      by: ["contentType"],
      _count: true,
      orderBy: { _count: { contentType: "desc" } },
    }),
    db.moderationEvent.groupBy({
      by: ["severity"],
      _count: true,
      orderBy: { _count: { severity: "desc" } },
    }),
    // For last 7 days we fetch raw createdAts + bucket in code (Prisma
    // doesn't have a date_trunc groupBy out of the box).
    db.moderationEvent.findMany({
      where: { createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } },
      select: { createdAt: true },
      orderBy: { createdAt: "asc" },
    }),
  ]);

  // Aggregate top categories (count each category across all events).
  const categoryCounts = new Map<string, number>();
  for (const ev of topCategoriesAgg) {
    // `categories` is stored as JSON (Prisma `Json` type). It's typed as
    // `Prisma.JsonValue` — we narrow safely.
    const cats = Array.isArray(ev.categories) ? (ev.categories as string[]) : [];
    for (const c of cats) {
      categoryCounts.set(c, (categoryCounts.get(c) ?? 0) + 1);
    }
  }
  const topCategories = [...categoryCounts.entries()]
    .map(([category, count]) => ({ category, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Bucket last-7-days by day (YYYY-MM-DD).
  const dayBuckets = new Map<string, number>();
  for (const ev of recentEventsRaw) {
    const d = ev.createdAt;
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    dayBuckets.set(key, (dayBuckets.get(key) ?? 0) + 1);
  }
  // Fill in missing days (zero-count days should still appear in the chart).
  const last7Days: { date: string; count: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    last7Days.push({ date: key, count: dayBuckets.get(key) ?? 0 });
  }

  return {
    totalBlocked,
    totalFlagged,
    totalReviewed,
    pendingReview,
    approvalRate: totalReviewed > 0 ? approvedCount / totalReviewed : 0,
    topCategories,
    byContentType: byContentTypeAgg.map((g) => ({ contentType: g.contentType, count: g._count })),
    bySeverity: bySeverityAgg.map((g) => ({ severity: g.severity, count: g._count })),
    last7Days,
  };
}

/**
 * Paginated moderation queue.
 */
export async function getModerationQueue(opts: {
  page: number;
  pageSize: number;
  status?: ModerationStatus;
  contentType?: ModerationContentType;
}): Promise<{ items: ModerationQueueItem[]; total: number }> {
  const page = Math.max(1, opts.page);
  const pageSize = Math.min(50, Math.max(1, opts.pageSize));
  const where: {
    status?: ModerationStatus;
    contentType?: ModerationContentType;
  } = {};
  if (opts.status) where.status = opts.status;
  if (opts.contentType) where.contentType = opts.contentType;

  const [rows, total] = await Promise.all([
    db.moderationEvent.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        user: {
          select: { id: true, fullName: true, username: true },
        },
        reviewer: {
          select: { id: true, fullName: true, username: true },
        },
      },
    }),
    db.moderationEvent.count({ where }),
  ]);

  const items: ModerationQueueItem[] = rows.map((r) => ({
    id: r.id,
    contentType: r.contentType as ModerationContentType,
    contentId: r.contentId,
    userId: r.user?.id ?? "",
    userFullName: r.user?.fullName ?? "(deleted user)",
    userUsername: r.user?.username ?? "(deleted)",
    status: r.status as ModerationStatus,
    action: r.action as ModerationResult["action"],
    severity: r.severity as ModerationResult["severity"],
    score: r.score,
    categories: Array.isArray(r.categories) ? (r.categories as ModerationQueueItem["categories"]) : [],
    reasons: Array.isArray(r.reasons) ? (r.reasons as string[]) : [],
    contentPreview: r.contentPreview ?? "",
    createdAt: r.createdAt.toISOString(),
    reviewedAt: r.reviewedAt?.toISOString() ?? null,
    reviewedBy: r.reviewer?.id ?? null,
    reviewedByName: r.reviewer?.fullName ?? null,
  }));

  return { items, total };
}

/**
 * Admin action on a moderation event.
 *
 * Updates the event's status + records the reviewer. Also records an
 * audit log entry.
 *
 * When status="REJECTED", optionally also DELETE the underlying content
 * (only when the content still exists — BLOCKed content has contentId=null
 * and is already gone).
 *
 * @returns The updated event (or null when not found).
 */
export async function updateModerationEventStatus(opts: {
  eventId: string;
  newStatus: ModerationStatus;
  adminId: string;
  deleteContent?: boolean;
}): Promise<{ ok: boolean; notFound?: boolean }> {
  const event = await db.moderationEvent.findUnique({
    where: { id: opts.eventId },
    select: { id: true, contentId: true, contentType: true, status: true },
  });
  if (!event) return { ok: false, notFound: true };

  await db.moderationEvent.update({
    where: { id: opts.eventId },
    data: {
      status: opts.newStatus,
      reviewedAt: new Date(),
      reviewedById: opts.adminId,
    },
  });

  // Optionally delete the underlying content (only for REJECTED + when
  // the content still exists — i.e. was published before being flagged).
  if (opts.deleteContent && opts.newStatus === "REJECTED" && event.contentId) {
    try {
      switch (event.contentType) {
        case "post":
          await db.post.delete({ where: { id: event.contentId } });
          break;
        case "article":
          await db.article.delete({ where: { id: event.contentId } });
          break;
        case "post_comment":
          await db.postComment.delete({ where: { id: event.contentId } });
          break;
        case "article_comment":
          await db.articleComment.delete({ where: { id: event.contentId } });
          break;
        // profile_bio / profile_full_name — the User row itself isn't
        // deleted (that would delete the user account); we just leave the
        // moderation event as REJECTED. The user can edit their profile
        // to clear the offending bio/name.
        default:
          break;
      }
    } catch (err) {
      // Content may already be deleted (e.g. user deleted it themselves).
      // Log + continue — the moderation event is still updated.
      logger.warn("application", "Moderation event: couldn't delete content", {
        error: err instanceof Error ? err.message : String(err),
        contentType: event.contentType,
        contentId: event.contentId,
      });
    }
  }

  return { ok: true };
}

/**
 * Get a single moderation event by ID — used by the admin "view original"
 * modal. Returns the full event row (including the 200-char preview).
 *
 * NOTE: we do NOT store the full original text. Admins see only the 200-char
 * preview + the matched rule IDs + reasons. If they need the full text,
 * they can navigate to the content (when contentId is non-null).
 */
export async function getModerationEventById(
  eventId: string
): Promise<ModerationQueueItem | null> {
  const r = await db.moderationEvent.findUnique({
    where: { id: eventId },
    include: {
      user: { select: { id: true, fullName: true, username: true } },
      reviewer: { select: { id: true, fullName: true, username: true } },
    },
  });
  if (!r) return null;
  return {
    id: r.id,
    contentType: r.contentType as ModerationContentType,
    contentId: r.contentId,
    userId: r.user?.id ?? "",
    userFullName: r.user?.fullName ?? "(deleted user)",
    userUsername: r.user?.username ?? "(deleted)",
    status: r.status as ModerationStatus,
    action: r.action as ModerationResult["action"],
    severity: r.severity as ModerationResult["severity"],
    score: r.score,
    categories: Array.isArray(r.categories) ? (r.categories as ModerationQueueItem["categories"]) : [],
    reasons: Array.isArray(r.reasons) ? (r.reasons as string[]) : [],
    contentPreview: r.contentPreview ?? "",
    createdAt: r.createdAt.toISOString(),
    reviewedAt: r.reviewedAt?.toISOString() ?? null,
    reviewedBy: r.reviewer?.id ?? null,
    reviewedByName: r.reviewer?.fullName ?? null,
  };
}
