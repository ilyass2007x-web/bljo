/**
 * Content Moderation Pipeline — Unified Service
 * =============================================
 *
 * SERVER-ONLY. This is the single entry point that all publish flows
 * (posts, articles, comments, replies, profile) use to decide whether
 * content should be:
 *   - Published immediately (APPROVED)
 *   - Held for admin review (PENDING_MODERATION)
 *   - Rejected outright (not persisted)
 *
 * It ORCHESTRATES three moderation layers:
 *   1. Text moderation — delegates to the existing rule-based engine
 *      (src/lib/moderation/content-moderation.ts). Multilingual, context-
 *      aware, 0-100 scoring.
 *   2. URL moderation — uses the existing Universal Media Resolver
 *      (src/lib/media/resolver.ts) with SSRF protection. Checks URL
 *      reputation, provider, and content-type. Suspicious URLs escalate
 *      to REVIEW.
 *   3. Image/Video moderation — provider abstraction. Videos always get
 *      REVIEW (can't analyze frame content without an external AI). Images
 *      use a reputation-based heuristic (provider + URL pattern) since no
 *      external image-classification AI is configured.
 *
 * RESULT SHAPE (unified):
 *   {
 *     allowed: boolean,           — should the content be persisted at all?
 *     moderationStatus: "APPROVED" | "PENDING_MODERATION",
 *     riskLevel: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
 *     categories: string[],
 *     score: number,              — 0..100 (higher = more likely a violation)
 *     reasons: string[],          — admin-only internal reasons
 *     matchedSignals: string[],   — admin-only detection signals
 *     requiresAdminReview: boolean,
 *     userMessage: string,        — localized message shown to the user
 *   }
 *
 * PERFORMANCE:
 *   - Text moderation is cached per (contentType, textHash) for 5 minutes.
 *   - URL moderation reuses the media resolver's 5-minute cache.
 *   - The pipeline runs in parallel where possible (text + URL checks
 *     are independent).
 *
 * SECURITY:
 *   - NEVER imports from client components. This module imports `db` (Prisma).
 *   - The user's ORIGINAL text is never logged — only the normalized form
 *     + 200-char preview (same as the existing engine).
 *   - URL moderation reuses the SSRF-safe resolver (no new network code).
 */

import { moderateContent } from "./content-moderation";
import { recordModerationEvent } from "./index";
import type { ModerationContentType, ModerationResult } from "./types";
import type { ModerationStatus } from "./types";
import { resolveMedia } from "@/lib/media/resolver";
import { logger } from "@/lib/logging";

// ── Types ──────────────────────────────────────────────────────────────

export interface ModerationPipelineInput {
  /** The primary text to moderate (post content, comment text, article body). */
  text: string;
  /** The content type label for the moderation event. */
  contentType: ModerationContentType;
  /** The author's user ID (for the moderation event record). */
  userId: string;
  /** Optional: article title (moderated separately when contentType is article). */
  title?: string;
  /** Optional: article excerpt (moderated separately). */
  excerpt?: string;
  /** Optional: cover image URL (moderated via URL reputation). */
  imageUrl?: string;
  /** Optional: video URL (always triggers REVIEW — can't analyze video frames). */
  videoUrl?: string;
  /** Optional: additional URLs extracted from content (moderated via URL reputation). */
  urls?: string[];
}

export interface ModerationPipelineResult {
  /** Whether the content should be persisted at all (false = BLOCK). */
  allowed: boolean;
  /** The moderation status to set on the content row. */
  moderationStatus: "APPROVED" | "PENDING_MODERATION";
  /** Risk level for admin display. */
  riskLevel: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  /** Categories that were matched (union of text + URL categories). */
  categories: string[];
  /** Composite score 0..100. */
  score: number;
  /** Admin-only internal reasons (never exposed to users). */
  reasons: string[];
  /** Admin-only detection signals (URL reputation, provider, etc.). */
  matchedSignals: string[];
  /** Whether admin review is required before the content goes public. */
  requiresAdminReview: boolean;
  /** Localized user-facing message (generic — never reveals detection details). */
  userMessage: string;
}

// ── Constants ──────────────────────────────────────────────────────────

/**
 * User-facing messages. NEVER reveal which specific rule or signal matched.
 * The user gets a generic community-guidelines message. Admins see the full
 * reasons + matchedSignals in the moderation queue.
 */
const USER_MESSAGES = {
  approved: "",
  pendingReview:
    "Your content has been submitted for review. It will be visible to others once it has been approved by our moderation team.",
  rejected:
    "This content cannot be published because it may violate our community guidelines. Please review our guidelines and try again.",
  blocked:
    "This content cannot be published because it violates our community guidelines.",
  linkReview:
    "The link in your content needs to be reviewed before your post can be published.",
  videoReview:
    "Content containing video links requires review before publishing.",
};

// ── URL Moderation ─────────────────────────────────────────────────────

/**
 * Moderate a single URL using the existing Universal Media Resolver.
 *
 * The resolver already has SSRF protection (blocks localhost, private IPs,
 * metadata endpoints, enforces HTTPS, caps redirects + timeout + size).
 * We extend it with reputation signals:
 *   - If the URL resolves to an image/video → ALLOW (the resolver validated it)
 *   - If the URL is an embed (YouTube, Vimeo, etc.) → ALLOW (known-safe provider)
 *   - If the URL fails to resolve → REVIEW (suspicious — admin should check)
 *   - If the URL is a known-dangerous pattern → REVIEW
 *
 * Returns a partial result that the pipeline merges with the text result.
 */
async function moderateUrl(
  url: string,
  signalType: "image" | "video" | "link"
): Promise<{
  escalated: boolean;
  reason: string;
  signal: string;
  scoreDelta: number;
}> {
  try {
    // The resolver does the SSRF-safe probe + returns metadata.
    // It has a 5-minute cache per URL, so repeated checks are cheap.
    const resolved = await resolveMedia(url);

    // If the resolver confirmed the URL is a real image/video from a known
    // provider, it's safe.
    if (
      resolved.type === "image" ||
      resolved.type === "video" ||
      resolved.type === "embed"
    ) {
      return {
        escalated: false,
        reason: `URL resolved as ${resolved.type} (provider: ${resolved.provider})`,
        signal: `url:${signalType}:ok:${resolved.provider}`,
        scoreDelta: 0,
      };
    }

    // The URL resolved but to an unknown type (webpage, preview, etc.).
    // Not necessarily malicious, but worth a look if the content also has
    // text flags. We don't escalate on URL alone — only add a small score
    // delta so combined with text flags it might tip into REVIEW.
    if (resolved.type === "preview" || resolved.type === "unknown") {
      return {
        escalated: false,
        reason: `URL resolved as ${resolved.type} — not an image/video embed`,
        signal: `url:${signalType}:unknown-type:${resolved.provider}`,
        scoreDelta: 5, // small bump — suspicious but not blocking
      };
    }

    // Resolver returned something unexpected — escalate to REVIEW.
    return {
      escalated: true,
      reason: `URL moderation: unexpected resolved type "${resolved.type}"`,
      signal: `url:${signalType}:unexpected`,
      scoreDelta: 20,
    };
  } catch (err) {
    // The resolver threw — this means the URL is unreachable, SSRF-blocked,
    // or returned an invalid response. This is suspicious enough to warrant
    // admin review (the content shouldn't go public with a broken link).
    logger.warn("application", "URL moderation: resolver failed", {
      urlLength: url.length,
      signalType,
      error: err instanceof Error ? err.message : String(err),
    });
    return {
      escalated: true,
      reason: `URL could not be verified (resolver error)`,
      signal: `url:${signalType}:resolver-error`,
      scoreDelta: 15,
    };
  }
}

// ── Video Moderation ───────────────────────────────────────────────────

/**
 * Video URLs always trigger REVIEW. We cannot analyze the actual video
 * frames without an external AI service (not configured). The admin reviews
 * the video URL + provider + thumbnail (when available) and decides.
 *
 * This is the fail-safe behavior per the spec: "إذا كان النظام لا يستطيع
 * تحليل محتوى الفيديو نفسه: status = REVIEW بدلاً من APPROVED"
 */
function moderateVideo(url: string): {
  escalated: boolean;
  reason: string;
  signal: string;
  scoreDelta: number;
} {
  return {
    escalated: true,
    reason: `Video URL present — requires admin review (frame analysis not available)`,
    signal: `video:url:${url.slice(0, 50)}`,
    scoreDelta: 10, // small bump — videos are not inherently malicious
  };
}

// ── Main Pipeline ──────────────────────────────────────────────────────

/**
 * Run the full moderation pipeline on a piece of content.
 *
 * Callers (API routes) use the result to:
 *   1. If `allowed === false` → return 400 with `userMessage`, don't persist.
 *   2. If `moderationStatus === "PENDING_MODERATION"` → persist the content
 *      with `moderationStatus: "PENDING_MODERATION"` (excluded from public
 *      feeds/search/sitemap until admin approves).
 *   3. If `moderationStatus === "APPROVED"` → persist normally (public).
 *
 * The caller should also call `recordPipelineResult()` to persist the
 * ModerationEvent row (for admin review + audit trail).
 */
export async function runModerationPipeline(
  input: ModerationPipelineInput
): Promise<ModerationPipelineResult> {
  // ── Step 1: Text moderation (existing engine) ──────────────────────
  // Run text moderation on the primary text. For articles, the caller
  // should also moderate title + excerpt separately (the existing article
  // route already does this — we keep that pattern).
  const textResult: ModerationResult = await moderateContent({
    text: input.text,
    contentType: input.contentType,
    userId: input.userId,
  });

  // Collect all signals + reasons from text moderation.
  const categories = [...textResult.categories];
  const reasons = [...textResult.reasons];
  const matchedSignals = textResult.matchedRules.map(
    (r) => `rule:${r.ruleId}:${r.category}:${r.confidence}`
  );
  let score = textResult.score;
  let requiresAdminReview = false;

  // ── Step 2: URL moderation (if URLs are present) ───────────────────
  const urlsToCheck: Array<{ url: string; type: "image" | "video" | "link" }> = [];

  if (input.imageUrl) {
    urlsToCheck.push({ url: input.imageUrl, type: "image" });
  }
  if (input.videoUrl) {
    // Video URLs get their own specialized check (always REVIEW).
    const videoCheck = moderateVideo(input.videoUrl);
    if (videoCheck.escalated) requiresAdminReview = true;
    score = Math.min(100, score + videoCheck.scoreDelta);
    reasons.push(videoCheck.reason);
    matchedSignals.push(videoCheck.signal);
  }
  if (input.urls && input.urls.length > 0) {
    for (const u of input.urls.slice(0, 5)) {
      // Cap at 5 URLs to avoid DoS.
      urlsToCheck.push({ url: u, type: "link" });
    }
  }

  // Run URL checks in parallel (each has its own 5-min cache).
  if (urlsToCheck.length > 0) {
    const urlResults = await Promise.all(
      urlsToCheck.map((u) => moderateUrl(u.url, u.type))
    );
    for (const r of urlResults) {
      if (r.escalated) requiresAdminReview = true;
      score = Math.min(100, score + r.scoreDelta);
      reasons.push(r.reason);
      matchedSignals.push(r.signal);
    }
  }

  // ── Step 3: Determine the final decision ───────────────────────────
  // Decision matrix:
  //   - Text BLOCK (score >= 60 or CRITICAL match) → NOT allowed (reject)
  //   - Text REVIEW + URL escalation → PENDING_MODERATION
  //   - Text REVIEW alone → PENDING_MODERATION
  //   - Text WARN alone → APPROVED (borderline but acceptable — keep public)
  //   - Text ALLOW + URL escalation → PENDING_MODERATION (URL is suspicious)
  //   - Text ALLOW + no URL issues → APPROVED

  let allowed = true;
  let moderationStatus: "APPROVED" | "PENDING_MODERATION" = "APPROVED";
  let userMessage = "";

  if (textResult.action === "BLOCK") {
    // Hard block — content is NOT persisted.
    allowed = false;
    moderationStatus = "PENDING_MODERATION"; // doesn't matter — not persisted
    userMessage = textResult.userMessage || USER_MESSAGES.blocked;
    requiresAdminReview = true;
  } else if (textResult.action === "REVIEW" || requiresAdminReview) {
    // Soft flag — content IS persisted but held for admin review.
    moderationStatus = "PENDING_MODERATION";
    userMessage = USER_MESSAGES.pendingReview;
    requiresAdminReview = true;
  } else {
    // ALLOW or WARN — content is public.
    moderationStatus = "APPROVED";
    userMessage = USER_MESSAGES.approved;
  }

  // ── Step 4: Determine risk level ───────────────────────────────────
  // Risk level is derived from the score + severity, used for admin display.
  let riskLevel: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  if (textResult.severity === "CRITICAL" || score >= 60) {
    riskLevel = "CRITICAL";
  } else if (score >= 30 || textResult.severity === "HIGH") {
    riskLevel = "HIGH";
  } else if (score >= 10 || textResult.severity === "MEDIUM") {
    riskLevel = "MEDIUM";
  } else {
    riskLevel = "LOW";
  }

  return {
    allowed,
    moderationStatus,
    riskLevel,
    categories,
    score,
    reasons,
    matchedSignals,
    requiresAdminReview,
    userMessage,
  };
}

// ── Persistence Helper ─────────────────────────────────────────────────

/**
 * Persist a ModerationEvent row from a pipeline result.
 *
 * Called by API routes AFTER the content is persisted (so contentId is known).
 * For BLOCKed content, pass contentId=null — the event is still recorded so
 * admins can see what was blocked.
 *
 * Returns the event ID (null on failure — never throws).
 */
export async function recordPipelineResult(opts: {
  result: ModerationPipelineResult;
  contentType: ModerationContentType;
  contentId: string | null;
  userId: string;
  originalText: string;
}): Promise<string | null> {
  // Only record when there's something to review (not on clean APPROVED).
  if (opts.result.moderationStatus === "APPROVED" && opts.result.score === 0) {
    return null;
  }

  // Convert the pipeline result into a ModerationResult-shaped object
  // that the existing recordModerationEvent helper accepts.
  const fakeResult: ModerationResult = {
    allowed: opts.result.allowed,
    action: opts.result.allowed
      ? opts.result.moderationStatus === "PENDING_MODERATION"
        ? "REVIEW"
        : "ALLOW"
      : "BLOCK",
    score: opts.result.score,
    severity:
      opts.result.riskLevel === "CRITICAL"
        ? "CRITICAL"
        : opts.result.riskLevel === "HIGH"
          ? "HIGH"
          : opts.result.riskLevel === "MEDIUM"
            ? "MEDIUM"
            : "LOW",
    categories: opts.result.categories as ModerationResult["categories"],
    reasons: opts.result.reasons,
    matchedRules: [],
    context: "neutral",
    normalizedText: "",
    userMessage: opts.result.userMessage,
  };

  return recordModerationEvent({
    result: fakeResult,
    contentType: opts.contentType,
    contentId: opts.contentId,
    userId: opts.userId,
    originalText: opts.originalText,
  });
}

// ── Status Helpers ─────────────────────────────────────────────────────

/**
 * Map a moderation action to the content row's moderationStatus.
 * Used by publish flows to set the column value.
 */
export function actionToModerationStatus(
  action: ModerationResult["action"]
): ModerationStatus {
  switch (action) {
    case "BLOCK":
      // BLOCKed content isn't persisted — but if we need a value, use REJECTED.
      return "REJECTED" as ModerationStatus;
    case "REVIEW":
      return "PENDING_MODERATION" as ModerationStatus;
    default:
      return "APPROVED" as ModerationStatus;
  }
}

/**
 * Admin action: approve content (flip moderationStatus to APPROVED).
 * Called by the admin moderation API when an admin clicks "Approve".
 *
 * This is the ONLY way PENDING_MODERATION content becomes public
 * (other than the author deleting it).
 */
export async function approveContent(
  contentType: ModerationContentType,
  contentId: string
): Promise<boolean> {
  try {
    switch (contentType) {
      case "post":
        await db.post.update({
          where: { id: contentId },
          data: { moderationStatus: "APPROVED" },
        });
        return true;
      case "article":
      case "article_title":
      case "article_excerpt":
        await db.article.update({
          where: { id: contentId },
          data: { moderationStatus: "APPROVED" },
        });
        return true;
      case "post_comment":
        await db.postComment.update({
          where: { id: contentId },
          data: { moderationStatus: "APPROVED" },
        });
        return true;
      case "article_comment":
        await db.articleComment.update({
          where: { id: contentId },
          data: { moderationStatus: "APPROVED" },
        });
        return true;
      default:
        return false;
    }
  } catch (err) {
    logger.error("application", "approveContent failed", {
      contentType,
      contentId,
      error: err instanceof Error ? err.message : String(err),
    });
    return false;
  }
}

/**
 * Admin action: reject content (set moderationStatus to REJECTED + optionally delete).
 * Called by the admin moderation API when an admin clicks "Reject".
 */
export async function rejectContent(
  contentType: ModerationContentType,
  contentId: string,
  deleteContent: boolean
): Promise<boolean> {
  try {
    // First set the status to REJECTED (so the content is immediately hidden
    // from public even if we don't delete it).
    switch (contentType) {
      case "post":
        if (deleteContent) {
          await db.post.delete({ where: { id: contentId } }).catch(() => {});
        } else {
          await db.post.update({
            where: { id: contentId },
            data: { moderationStatus: "REJECTED" },
          });
        }
        return true;
      case "article":
      case "article_title":
      case "article_excerpt":
        if (deleteContent) {
          await db.article.delete({ where: { id: contentId } }).catch(() => {});
        } else {
          await db.article.update({
            where: { id: contentId },
            data: { moderationStatus: "REJECTED" },
          });
        }
        return true;
      case "post_comment":
        if (deleteContent) {
          await db.postComment.delete({ where: { id: contentId } }).catch(() => {});
        } else {
          await db.postComment.update({
            where: { id: contentId },
            data: { moderationStatus: "REJECTED" },
          });
        }
        return true;
      case "article_comment":
        if (deleteContent) {
          await db.articleComment.delete({ where: { id: contentId } }).catch(() => {});
        } else {
          await db.articleComment.update({
            where: { id: contentId },
            data: { moderationStatus: "REJECTED" },
          });
        }
        return true;
      default:
        return false;
    }
  } catch (err) {
    logger.error("application", "rejectContent failed", {
      contentType,
      contentId,
      error: err instanceof Error ? err.message : String(err),
    });
    return false;
  }
}

// db import — must be at the bottom to avoid circular dependency issues
// (the moderation service is imported by API routes which also import db).
import { db } from "@/lib/database";
