/**
 * Moderation Engine — Rules Database
 * ====================================
 *
 * Server-only. Pure data + pure functions. NO DB, NO Node-only modules.
 *
 * SECURITY: this file contains offensive word lists by necessity. They
 * are loaded ONLY server-side (imported by content-moderation.ts which
 * is imported only by API routes). They are NEVER shipped to the browser.
 *
 * Each rule defines:
 *   - ruleId: stable identifier used in admin logs (e.g. "sexual_explicit_en_1").
 *   - category: which policy area (sexual_explicit, profanity, etc.).
 *   - severity: how serious a single match is (LOW/MEDIUM/HIGH/CRITICAL).
 *   - pattern: regex matched against the NORMALIZED text (lowercase,
 *              zero-width-stripped, diacritics-stripped, leetspeak-collapsed).
 *   - confidence: 0..1 — how sure we are that this match is real. Lower
 *                 confidence means the term is ambiguous (could be medical,
 *                 could be profanity) and the engine should rely on context.
 *
 * WORD LIST DESIGN (anti-obfuscation):
 *   Patterns are written with word-boundary awareness (\b) on the
 *   SPACED form, AND we ALSO test the SPACE-STRIPPED form (so "p o r n"
 *   matches). We test BOTH forms for every rule, then take the highest
 *   confidence match. This is done by `matchRules()` below.
 *
 * MULTILINGUAL COVERAGE:
 *   English, Arabic (MSA), Moroccan Darija, and French. Darija terms are
 *   derived from French/Arabic transliterations and are intentionally a
 *   small set — over-blocking Darija risks false positives.
 *
 * CONTEXT-AWARENESS:
 *   If the surrounding text contains strong educational/medical/news
 *   context markers (see CONTEXT_RULES), the severity of LOW/MEDIUM
 *   matches is downgraded (and CRITICAL matches are kept unchanged —
 *   CSA / exploitation content is blocked regardless of context).
 */

import type {
  ModerationCategory,
  ModerationSeverity,
  MatchedRule,
  ModerationContext,
} from "./types";

/**
 * A single pattern-based rule. The `pattern` is matched against the
 * normalized text. Patterns MUST use `i` flag (case-insensitive) —
 * though normalization already lowercases, we keep the flag as
 * defense-in-depth.
 */
export interface ModerationRule {
  ruleId: string;
  category: ModerationCategory;
  severity: ModerationSeverity;
  /** Confidence 0..1 — base confidence before context adjustment. */
  confidence: number;
  /** Regex pattern (use \b for word boundary; tested on normalized text). */
  pattern: RegExp;
  /**
   * If true, this rule is allowed to be downgraded by educational/medical
   * context. CRITICAL-severity rules set this to false (CSA / exploitation
   * is blocked regardless of context). Default: true.
   */
  contextSensitive?: boolean;
}

// ─── Sexual / Explicit ─────────────────────────────────────────────────────
// Patterns are written to match the explicit form. Educational context
// (pregnancy, anatomy, sexual health) is handled separately — these
// patterns only fire on the explicit words themselves.
//
// The list is intentionally focused: only unambiguous explicit terms.
// Terms like "sex" alone are NOT included (they appear in "sexism",
// "sextant", "Sussex" etc.) — we require compound forms.
const SEXUAL_EXPLICIT_RULES: ModerationRule[] = [
  {
    ruleId: "sexual_explicit_en_1",
    category: "sexual_explicit",
    severity: "HIGH",
    confidence: 0.9,
    pattern: /\bporn(?:o|ography|ographic|ograph)?\b|\bpr0n\b|\bxvideos?\b|\bonlyfans\b|\bredtube\b|\bpornhub\b|\bxhamster\b|\bcamwhore\b/i,
  },
  {
    ruleId: "sexual_explicit_en_2",
    category: "sexual_explicit",
    severity: "HIGH",
    confidence: 0.9,
    pattern: /\b(?:hardcore|hardcor)\s+(?:sex|porn|fucking|fuck)\b|\b(?:anal|oral|vaginal)\s+(?:sex|intercourse|penetration)\b/i,
  },
  {
    ruleId: "sexual_explicit_en_3",
    category: "sexual_explicit",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /\b(?:nude|naked|nudes?)\s+(?:pics?|photos?|selfies?|snapshots?|videos?)\b|\bsend\s+(?:me\s+)?(?:nudes?|nude\s+pics?)\b/i,
  },
  {
    ruleId: "sexual_explicit_en_4",
    category: "sexual_explicit",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /\b(?:sexy?|hot)\s+(?:pics?|photos?|snapshots?)\s+(?:of|from)\s+(?:you|yourself|ur\s+self)\b/i,
  },
  {
    ruleId: "sexual_explicit_en_5",
    category: "sexual_explicit",
    severity: "HIGH",
    confidence: 0.9,
    pattern: /\b(?: masturbating|masturbation|fingering\s+yourself|jerking\s+off|giving\s+a\s+blowjob|giving\s+head|eating\s+out|sucking\s+dick|fingering\s+pussy|fucking\s+(?:her|him|them|my|your|a))\b/i,
  },
  // Arabic explicit terms — focused list. Diacritics already stripped
  // by normalize.ts so we only need the bare-letter form.
  {
    ruleId: "sexual_explicit_ar_1",
    category: "sexual_explicit",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /(?:سكس|سكسي|نيك|قحبة|عرص|شرموطة|متناكة|متناك|لبوة|طيز|كس|زب|متعة\s+جنسية|جماع|مومس|بغاء|دعارة)/i,
  },
  // Moroccan Darija explicit terms — kept focused to avoid false positives.
  {
    ruleId: "sexual_explicit_darija_1",
    category: "sexual_explicit",
    severity: "HIGH",
    confidence: 0.8,
    pattern: /(?:كيكس|كسك|زبك|زبي|طيزك|طيزي|نبوسك|نبوسك\s+الطيز|كنيوك|كنييك|نيك|كحبة|قحبة|شرفونة|مخنث|لواط|لواطي)/i,
  },
  // French explicit terms.
  {
    ruleId: "sexual_explicit_fr_1",
    category: "sexual_explicit",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /(?:porno|pornographie|pornographique|partouze|sodomie|fellation|cunnilingus|ejaculation|baise|baiser|putes?|salope|encule|enculer|niquer|niquée|couilles|chatte|bite|queue)\b/i,
  },
];

// ─── Sexual Solicitation ────────────────────────────────────────────────────
const SEXUAL_SOLICITATION_RULES: ModerationRule[] = [
  {
    ruleId: "sexual_solicitation_en_1",
    category: "sexual_solicitation",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /\b(?:selling|sell|buy|buying)\s+(?:nudes?|nude\s+pics?|sex\s+videos?|sex\s+tapes?|custom\s+porn)\b/i,
  },
  {
    ruleId: "sexual_solicitation_en_2",
    category: "sexual_solicitation",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /\b(?:escort|prostitute|hooker|call\s+girl|sugar\s+baby|sugar\s+daddy)\s+(?:service|available|near|for\s+hire|booking|book\s+me)\b/i,
  },
  {
    ruleId: "sexual_solicitation_en_3",
    category: "sexual_solicitation",
    severity: "HIGH",
    confidence: 0.8,
    pattern: /\b(?:dm\s+me|pm\s+me|message\s+me|add\s+me|kik\s+me|snap\s+me|snapchat\s+me)\s+(?:for|to)\s+(?:nudes?|sex|hookup|fun|pics?|videos?)\b/i,
  },
  {
    ruleId: "sexual_solicitation_en_4",
    category: "sexual_solicitation",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /\b(?:looking\s+for|wanna|want\s+to|down\s+for|dtf|hmu\s+for)\s+(?:sex|hookup|fuck|suck|blowjob|quickie|nsa|fwb)\b/i,
  },
  {
    ruleId: "sexual_solicitation_ar_1",
    category: "sexual_solicitation",
    severity: "HIGH",
    confidence: 0.8,
    pattern: /(?:بغيت\s+نيك|بغيت\s+ننبوسك|عايز\s+نيك|عايزة\s+نيك|نبحث\s+عن\s+جنس|أبحث\s+عن\s+جنس|مومس\s+موجودة|دعارة\s+موجودة|بغيت\s+قحبة|كنقلب\s+على\s+قحبة)/i,
  },
  {
    ruleId: "sexual_solicitation_fr_1",
    category: "sexual_solicitation",
    severity: "HIGH",
    confidence: 0.8,
    pattern: /(?:je\s+cherche\s+(?:une\s+)?pute|je\s+veux\s+baiser|cherche\s+plan\s+cul|plan\s+cul\s+(?:ce\s+soir|dispo|disponible)|escort\s+(?:dispo|disponible|disponible\s+ce\s+soir))/i,
  },
];

// ─── Sexual Exploitation (CSA, trafficking) — CRITICAL ─────────────────────
// ALWAYS blocked, even in "educational" context. contextSensitive=false.
const SEXUAL_EXPLOITATION_RULES: ModerationRule[] = [
  {
    ruleId: "sexual_exploitation_en_1",
    category: "sexual_exploitation",
    severity: "CRITICAL",
    confidence: 0.95,
    pattern: /\b(?:cp|child\s*porn|kiddie\s*porn|pedo(?:phile|philia)?|underage\s+(?:sex|nudes?|porn|pics?))\b|\blolicon\b|\bshotacon\b|\bminor\s+(?:nudes?|sex|porn|rape)\b/i,
    contextSensitive: false,
  },
  {
    ruleId: "sexual_exploitation_en_2",
    category: "sexual_exploitation",
    severity: "CRITICAL",
    confidence: 0.95,
    pattern: /\b(?:trafficking|human\s+trafficking|sex\s+trafficking|sex\s+slave|sex\s+slavery)\b/i,
    contextSensitive: false,
  },
  {
    ruleId: "sexual_exploitation_en_3",
    category: "sexual_exploitation",
    severity: "CRITICAL",
    confidence: 0.9,
    pattern: /\b(?:rape|raped|raping|molest|molested|molesting)\s+(?:a\s+)?(?:child|minor|kid|girl|boy|teen|baby|toddler)\b/i,
    contextSensitive: false,
  },
];

// ─── Hate Speech ────────────────────────────────────────────────────────────
// Focused, unambiguous slurs. We do NOT block words that have legitimate
// alternative meanings (e.g. "gay" alone — used in many non-derogatory
// contexts). Slurs are blocked as standalone tokens.
const HATE_SPEECH_RULES: ModerationRule[] = [
  {
    ruleId: "hate_en_1",
    category: "hate_speech",
    severity: "HIGH",
    confidence: 0.95,
    pattern: /\bn[i1]gg(?:er|a|ers|as)\b|\bn[i1]ggr\b/i,
  },
  {
    ruleId: "hate_en_2",
    category: "hate_speech",
    severity: "HIGH",
    confidence: 0.9,
    pattern: /\bf[a4]gg[o0]ts?\b|\bf[a4]gs\b|\bqueers?\s+(?:are|should|must|all)\b|\bkill\s+all\s+(?:gays?|fags|jews?|muslims?|blacks?|whites?)\b/i,
  },
  {
    ruleId: "hate_en_3",
    category: "hate_speech",
    severity: "HIGH",
    confidence: 0.9,
    pattern: /\bkikes?\b|\bspics?\b|\bwops?\b|\bchinks?\b|\bgooks?\b|\btrannies\b/i,
  },
  {
    ruleId: "hate_en_4",
    category: "hate_speech",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /\b(?:gas|burn|hang|shoot|kill|exterminate|eradicate)\s+all\s+(?:jews?|muslims?|blacks?|gays?|immigrants?|refugees?)\b/i,
  },
  // Arabic hate speech — unambiguous slurs only.
  {
    ruleId: "hate_ar_1",
    category: "hate_speech",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /(?:اقتل\s+اليهود|اقتل\s+المسلمين|اقتل\s+السود|الموت\s+لليهود|الموت\s+للمسلمين|أكره\s+اليهود|أكره\s+السود|أكره\s+المسلمين|كنس\s+اليهود|كنس\s+المسلمين)/i,
  },
  {
    ruleId: "hate_fr_1",
    category: "hate_speech",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /(?:mort\s+aux\s+(?:juifs|musulmans|arabes|noirs)|tuez\s+tous\s+les\s+(?:juifs|musulmans|arabes|noirs)|je\s+haïs\s+les\s+(?:juifs|musulmans|arabes|noirs|gays))/i,
  },
];

// ─── Threats / Violence ─────────────────────────────────────────────────────
const THREATS_RULES: ModerationRule[] = [
  {
    ruleId: "threat_en_1",
    category: "threats",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /\b(?:i[''’]?ll|i\s+will|gonna|going\s+to)\s+(?:kill|murder|shoot|stab|behead|rape|hunt\s+down|find\s+and\s+(?:kill|hurt))\s+(?:you|him|her|them|u|ur\s+family|your\s+family)\b/i,
  },
  {
    ruleId: "threat_en_2",
    category: "threats",
    severity: "HIGH",
    confidence: 0.85,
    pattern: /\b(?:you(?:'re|r)\s+(?:dead|gonna\s+die|going\s+to\s+die|a\s+dead\s+man))\b|\b(?:i\s+swear\s+i[''’]?ll|i\s+promise\s+i[''’]?ll)\s+(?:kill|find|hunt)\b/i,
  },
  {
    ruleId: "threat_en_3",
    category: "threats",
    severity: "HIGH",
    confidence: 0.8,
    pattern: /\b(?:bomb\s+(?:threat|school|mosque|church|synagogue|airport))\b|\b(?:school\s+shooting|mass\s+shooting)\b/i,
  },
  {
    ruleId: "threat_ar_1",
    category: "threats",
    severity: "HIGH",
    confidence: 0.8,
    pattern: /(?:غادي\s+نقتلك|غادي\s+نقتلكم|سوف\s+أقتلك|سأقتلك|سوف\s+أقتلكم|سأقتلكم|رايدك\s+تموت|بغيتك\s+تموت|سوف\s+أذبحك|سأذبحك)/i,
  },
  {
    ruleId: "threat_fr_1",
    category: "threats",
    severity: "HIGH",
    confidence: 0.8,
    pattern: /(?:je\s+vais\s+(?:te|vous)\s+tuer|tu\s+vas\s+(?:crever|mourir)|je\s+te\s+tuerai|je\s+vous\s+tuerai)/i,
  },
];

// ─── Harassment ─────────────────────────────────────────────────────────────
// Targeted personal attacks. Less severe than hate speech (no protected-class
// angle), but still actionable when repeated.
const HARASSMENT_RULES: ModerationRule[] = [
  {
    ruleId: "harassment_en_1",
    category: "harassment",
    severity: "MEDIUM",
    confidence: 0.7,
    pattern: /\b(?:you(?:'re|r)\s+(?:so\s+)?(?:ugly|stupid|retarded|worthless|pathetic|useless|trash|garbage|a\s+loser|a\s+joke))\b/i,
  },
  {
    ruleId: "harassment_en_2",
    category: "harassment",
    severity: "MEDIUM",
    confidence: 0.7,
    pattern: /\b(?:go\s+kill\s+yourself|go\s+die|nobody\s+(?:likes|cares\s+about)\s+you|everyone\s+hates\s+you|you\s+should\s+(?:not\s+exist|never\s+have\s+been\s+born))\b/i,
  },
  {
    ruleId: "harassment_en_3",
    category: "harassment",
    severity: "MEDIUM",
    confidence: 0.65,
    pattern: /\b(?:shut\s+up\s+(?:you|u)\s+(?:ugly|stupid|dumb|fat|trashy)\s+(?:bitch|whore|slut))\b/i,
  },
];

// ─── Profanity (extreme) ───────────────────────────────────────────────────
// Lower severity by default — caught here so the engine has SOMETHING
// to log even when the surrounding context is benign.
const PROFANITY_RULES: ModerationRule[] = [
  {
    ruleId: "profanity_en_1",
    category: "profanity",
    severity: "LOW",
    confidence: 0.6,
    pattern: /\bf[uo]ck(?:ing|er|ed)?\b|\bf[uo]ck\b|\bfck\b|\bwtf\b|\bbitch(?:es)?\b|\basshole\b|\bdouchebag\b/i,
  },
  {
    ruleId: "profanity_en_2",
    category: "profanity",
    severity: "LOW",
    confidence: 0.55,
    pattern: /\bshit(?:ty|head|hole)?\b|\bcrappy?\b|\bpiss(?:ed)?\b/i,
  },
  {
    ruleId: "profanity_ar_1",
    category: "profanity",
    severity: "LOW",
    confidence: 0.6,
    pattern: /(?:كلب|حمار|تبن|خوار|غبي|أحمق|تخلف|زبالة|خرا|وسخ|حقير)/i,
  },
  {
    ruleId: "profanity_darija_1",
    category: "profanity",
    severity: "LOW",
    confidence: 0.55,
    pattern: /(?:كلب|حمار|تبن|وسخ|حقير|مغفل|أحمق|غبي|زفت|خرا)/i,
  },
  {
    ruleId: "profanity_fr_1",
    category: "profanity",
    severity: "LOW",
    confidence: 0.55,
    pattern: /(?:merde|putain|connard|salope|enculé|bordel|emmerde|foutre)/i,
  },
];

// ─── Illegal / Dangerous ────────────────────────────────────────────────────
const ILLEGAL_RULES: ModerationRule[] = [
  {
    ruleId: "illegal_en_drugs_1",
    category: "illegal",
    severity: "MEDIUM",
    confidence: 0.7,
    pattern: /\b(?:selling|buying|sell|buy|looking\s+for)\s+(?:cocaine|heroin|crack|meth|fentanyl|mdma|lsd|ketamine|weed\s+in\s+bulk)\b/i,
  },
  {
    ruleId: "illegal_en_weapons_1",
    category: "illegal",
    severity: "MEDIUM",
    confidence: 0.7,
    pattern: /\b(?:selling|buying|sell|buy)\s+(?:unregistered\s+)?(?:firearm|gun|pistol|rifle|handgun|ak[-]?47|ammunition|silencer|grenade)\b/i,
  },
  {
    ruleId: "illegal_en_fraud_1",
    category: "illegal",
    severity: "MEDIUM",
    confidence: 0.7,
    pattern: /\b(?:stolen\s+(?:credit\s+card|card|card\s+numbers?|id|passport))\b|\b(?:cc\s+dumps?|fullz|carding)\b/i,
  },
];

// ─── Spam ────────────────────────────────────────────────────────────────────
// Detection: 5+ consecutive identical chars (post-normalization) OR a URL
// appearing 4+ times in the same content (a common spam-bot signature).
const SPAM_RULES: ModerationRule[] = [
  {
    ruleId: "spam_repeat_1",
    category: "spam",
    severity: "LOW",
    confidence: 0.6,
    // Five or more of the same word back-to-back. Defensive: also matches
    // runs of the same punctuation-only token.
    pattern: /\b(\w+)(\s+\1){4,}\b/i,
  },
  {
    ruleId: "spam_caps_1",
    category: "spam",
    severity: "LOW",
    confidence: 0.5,
    // 30+ consecutive uppercase letters after normalization (post-lowercase
    // we look at the original text instead — handled separately in
    // content-moderation.ts because this regex needs the non-normalized form).
    // We include a stub here so the engine has a single rules array; the
    // actual caps-spam check is done in code.
    pattern: /\b(?=[A-Z]{30,})[A-Z\s]+\b/,
  },
];

// Aggregate ALL rules in a single array. Order matters only for the
// "first match wins" tie-breaker in case of equal confidence — we put
// most-severe categories first so the engine reports the most-serious
// match as the headline severity.
export const ALL_RULES: ModerationRule[] = [
  ...SEXUAL_EXPLOITATION_RULES,
  ...SEXUAL_SOLICITATION_RULES,
  ...SEXUAL_EXPLICIT_RULES,
  ...HATE_SPEECH_RULES,
  ...THREATS_RULES,
  ...ILLEGAL_RULES,
  ...HARASSMENT_RULES,
  ...PROFANITY_RULES,
  ...SPAM_RULES,
];

// ─── Context Detection ──────────────────────────────────────────────────────
//
// When the text contains clear educational/medical/news context markers,
// we down-grade LOW/MEDIUM severity matches (CRITICAL is never downgraded).
//
// We do NOT skip the rules entirely — we just lower the score. This is
// safer than skipping because:
//   1. An explicit abuser could include "medical" keywords to evade.
//   2. The rules engine still records the match for admin review.
const CONTEXT_PATTERNS: { context: ModerationContext; pattern: RegExp }[] = [
  {
    context: "medical",
    pattern: /(?:anatomy|anatomical|reproductive\s+(?:health|system|organs?)|pregnancy|menstruation|menopause|contraception|std|sti|hiv|aids|breast\s+cancer|testicular\s+cancer|cervical|prostate|gynecolog|urologist|medical|clinical|patient|treatment|diagnosis|symptom|vaccine|vaccination)/i,
  },
  {
    context: "educational",
    pattern: /(?:sexual\s+health|sex\s+education|sex\s+ed|comprehensive\s+sex\s+education|consent\s+education|health\s+class|health\s+curriculum|anatomy\s+class|biology\s+class|biology\s+textbook|research\s+paper|peer[- ]reviewed|academic\s+(?:journal|paper|study)|world\s+health\s+organization|united\s+nations|unicef|planned\s+parenthood)/i,
  },
  {
    context: "news",
    pattern: /(?:according\s+to\s+(?:a\s+)?(?:report|study|research|article)|breaking\s+news|news\s+report|investigative\s+report|the\s+(?:new\s+york\s+times|washington\s+post|guardian|bbc|reuters|ap\s+news)|associated\s+press|investigative\s+journalism|news\s+coverage)/i,
  },
  {
    context: "discussion",
    pattern: /(?:how\s+does\s+(?:pregnancy|menstruation|puberty)\s+work|what\s+is\s+(?:puberty|menstruation|anatomy)|is\s+it\s+(?:safe|normal)|should\s+i\s+(?:see\s+a\s+doctor|talk\s+to\s+my\s+doctor))/i,
  },
];

/**
 * Detect the dominant context of the input text.
 *
 * We test ALL context patterns and return the FIRST match (priority order:
 * medical → educational → news → discussion → explicit → neutral). The
 * "explicit" context is set when the rules engine found any sexual-explicit
 * match without a benign context marker — used for severity tuning.
 */
export function detectContext(
  normalizedText: string,
  hasExplicitMatch: boolean
): ModerationContext {
  for (const { context, pattern } of CONTEXT_PATTERNS) {
    if (pattern.test(normalizedText)) {
      return context;
    }
  }
  return hasExplicitMatch ? "explicit" : "neutral";
}

/**
 * Run all rules against the normalized + space-stripped forms of the input.
 *
 * For each rule, we test BOTH forms:
 *   - normalizedText (preserves word boundaries)
 *   - stripSpaces(normalizedText) (defeats "p o r n" obfuscation)
 *
 * We collect ALL matches (a single text can trigger multiple rules across
 * multiple categories). The caller (scoring.ts) combines them into a
 * final score + severity.
 *
 * CONTEXT ADJUSTMENT: when a rule matches AND the surrounding text contains
 * a benign context marker (medical/educational/news/discussion), the rule's
 * confidence is multiplied by 0.5 (effectively downgraded). CRITICAL
 * severity rules with `contextSensitive: false` are NEVER downgraded.
 */
export function matchRules(
  normalizedText: string,
  spaceStripped: string
): { matches: MatchedRule[]; context: ModerationContext } {
  const matches: MatchedRule[] = [];

  // First pass: collect raw matches (no context adjustment yet).
  let hasExplicit = false;
  for (const rule of ALL_RULES) {
    const spacedMatch = normalizedText.match(rule.pattern);
    const strippedMatch = spaceStripped.match(rule.pattern);
    const match = spacedMatch ?? strippedMatch;
    if (!match) continue;

    if (rule.category === "sexual_explicit" || rule.category === "sexual_solicitation") {
      hasExplicit = true;
    }

    matches.push({
      ruleId: rule.ruleId,
      category: rule.category,
      severity: rule.severity,
      confidence: rule.confidence,
      // Use the matched substring (truncated to 60 chars for log safety).
      match: (match[0] ?? "").slice(0, 60),
    });
  }

  // Detect context AFTER collecting matches (so we know if any explicit
  // match fired without a benign context marker).
  const context = detectContext(normalizedText, hasExplicit);

  // Second pass: apply context adjustment.
  // For benign contexts + contextSensitive rules, halve the confidence.
  const isBenign =
    context === "medical" ||
    context === "educational" ||
    context === "news" ||
    context === "discussion";

  if (isBenign) {
    for (const m of matches) {
      const rule = ALL_RULES.find((r) => r.ruleId === m.ruleId);
      if (!rule) continue;
      // CRITICAL / exploitation rules are never downgraded.
      if (rule.contextSensitive === false) continue;
      // Otherwise, downgrade confidence by 50%.
      m.confidence = m.confidence * 0.5;
    }
  }

  return { matches, context };
}

/**
 * Caps-lock spam check — runs on the ORIGINAL (non-normalized) text.
 * Returns true when 50%+ of letters are uppercase AND there are 30+
 * uppercase letters total. This is a strong spam signal (ALL-CAPS
*  shouting), separate from the keyword-based rules.
 */
export function isCapsLockSpam(originalText: string): boolean {
  const letters = originalText.replace(/[^A-Za-z]/g, "");
  if (letters.length < 30) return false;
  const upper = originalText.replace(/[^A-Z]/g, "").length;
  return upper / letters.length >= 0.5;
}
