/**
 * Article SEO helpers — shared between /articles/[id]/page.tsx
 * (generateMetadata + JSON-LD) and any future server-side route that
 * needs to surface article metadata.
 *
 * DESIGN PRINCIPLES (per CentryChat SEO spec):
 *   - Pure functions where possible (no DB access inside the helpers
 *     that build the final Metadata + JSON-LD). The caller fetches the
 *     article row and passes it in. This keeps the helpers testable and
 *     side-effect free.
 *   - All URLs are ABSOLUTE (Next.js requires absolute URLs for OG /
 *     Twitter / canonical / JSON-LD). The base URL comes from
 *     NEXT_PUBLIC_APP_BASE_URL — never hard-coded.
 *   - All values are SANITIZED for JSON/HTML context via
 *     JSON.stringify — no manual string concatenation that could leak
 *     user-controlled HTML into a <script type="application/ld+json">
 *     block. The caller already does JSON.stringify at render time,
 *     which is safe (it escapes </script> sequences via \u003c by default
 *     in modern V8/Node, plus we strip control chars here).
 *   - Fallbacks are layered: excerpt → content-extract → title. Empty
 *     author → CentryChat. Missing cover → platform default OG image.
 *
 * NO DATABASE CHANGES. The helpers operate only on already-fetched data.
 */
import type { Metadata } from "next";

// ── Types ───────────────────────────────────────────────────────────────────

/**
 * Minimal article projection that this module needs. The caller (the
 * /articles/[id] page route) is responsible for fetching exactly these
 * fields from Prisma — no more, no less. Keeping this narrow means we
 * don't accidentally tie the SEO layer to a wider Prisma type.
 */
export interface ArticleSeoInput {
  id: string;
  title: string;
  content: string;
  excerpt: string | null;
  coverImage: string | null;
  status: string;
  publishedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
  author: {
    id: string;
    fullName: string;
    username: string;
    avatarUrl: string | null;
  };
  // Optional: interaction counts (used in JSON-LD interactionStatistic).
  likeCount?: number;
  commentCount?: number;
  viewCount?: number;
  shareCount?: number;
  /**
   * Optional: video thumbnail URL — used as og:image fallback when the
   * article has NO coverImage but DOES have a videoUrl (e.g. a YouTube
   * thumbnail). Better than the platform default OG image because it's
   * content-specific (the reader sees the actual video thumbnail in
   * the WhatsApp/Twitter preview, not a generic logo).
   *
   * Passed in by the /articles/[id] page route after running resolveMedia()
   * on the article's videoUrl. The resolver returns thumbnailUrl for
   * known embed platforms (YouTube hqdefault, Vimeo, etc.).
   */
  videoThumbnailUrl?: string | null;
  // ── Per-article SEO control overrides (PHASE-7 SEO audit) ────────
  // When NULL/false, the auto-generated defaults are used. When non-null,
  // they override the auto-generated value. See migration
  // 20260820000050_add_article_seo_fields/migration.sql for rationale.
  seoNoindex?: boolean | null;
  seoNofollow?: boolean | null;
  customSeoTitle?: string | null;
  customMetaDescription?: string | null;
  customCanonical?: string | null;
}

/** Platform-level context needed to brand the metadata. */
export interface PlatformSeoContext {
  /** Public platform name (from PlatformSetting "platform.name"). */
  name: string;
  /** Public platform description (from PlatformSetting "platform.description"). */
  description: string;
  /**
   * Absolute base URL of the deployment, e.g. "https://centrychat.app".
   * Comes from NEXT_PUBLIC_APP_BASE_URL. Always stripped of trailing /.
   */
  baseUrl: string;
  /**
   * Optional default OG image (absolute URL) — used when the article has
   * no coverImage. Comes from PlatformSetting "platform.default_og_image"
   * when set; otherwise falls back to `${baseUrl}/icon.svg`.
   */
  defaultOgImage?: string | null;
  /**
   * Optional platform logo URL (absolute) — used as publisher.logo in
   * JSON-LD. Falls back to `${baseUrl}/icon.svg` when unset.
   */
  logoUrl?: string | null;
}

// ── Sanitization helpers ────────────────────────────────────────────────────

/**
 * Strip ASCII control characters (incl. NUL, BEL, vertical tab, etc.)
 * from a string. These are not allowed inside JSON-LD <script> tags
 * (some browsers will reject the script silently) and they're a sign
 * of either an editor paste artifact or an injection attempt.
 *
 * Preserves newlines (\n), tabs (\t), and all printable Unicode.
 */
export function stripControlChars(input: string): string {
  return input.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "");
}

/** Truncate a string to a max length, cutting at the nearest word boundary. */
export function truncateAtWord(input: string, maxLen: number): string {
  if (input.length <= maxLen) return input;
  const slice = input.slice(0, maxLen);
  const lastSpace = slice.lastIndexOf(" ");
  // If there's no space at all in the slice, just hard-cut.
  const cutAt = lastSpace > maxLen * 0.6 ? lastSpace : maxLen;
  return `${slice.slice(0, cutAt).trimEnd()}…`;
}

/**
 * Extract a clean meta description from the article body.
 *
 * Priority:
 *   1. excerpt (if non-empty, sanitized) — already a curated summary.
 *   2. First meaningful paragraph of `content` (skipping blank lines
 *      and pure-decoration markdown).
 *   3. Fall back to the title (the caller passes it separately).
 *
 * Target length: 140–160 chars. We truncate at a word boundary so the
 * description never ends mid-word.
 *
 * Sanitization (spec §6 — "نظف HTML, Markdown, excessive whitespace,
 * scripts, unwanted characters"):
 *   - Strip ASCII control chars (\u0000-\u0008, \u000B, \u000C, \u000E-\u001F)
 *   - Strip HTML tags (defense-in-depth — article content is plain text
 *     but the editor may paste HTML)
 *   - Strip HTML entities (&nbsp; → space, &amp; → &)
 *   - Strip markdown images, links, headings, list markers, dividers
 *   - Collapse multiple whitespace into a single space
 *   - Trim leading/trailing whitespace
 *
 * No keyword stuffing — we don't add anything that wasn't already in
 * the source content. We only TRIM and CLEAN.
 */
export function extractMetaDescription(
  excerpt: string | null | undefined,
  content: string | null | undefined,
  title: string,
  maxLen = 155
): string {
  const sanitize = (s: string): string =>
    stripControlChars(s)
      // Strip HTML tags (defense-in-depth — content may have pasted HTML).
      .replace(/<[^>]+>/g, "")
      // Decode common HTML entities (covers ~95% of cases).
      .replace(/&nbsp;/g, " ")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      // Collapse runs of whitespace (incl. newlines) into a single space.
      .replace(/\s+/g, " ")
      .trim();

  const cleanExcerpt = excerpt ? sanitize(excerpt) : "";
  if (cleanExcerpt) {
    return truncateAtWord(cleanExcerpt, maxLen);
  }

  const cleanContent = content ? sanitize(content) : "";
  if (cleanContent) {
    // Split into paragraphs and find the first one that has actual text
    // content (not just markdown headings / images / dividers).
    const paragraphs = cleanContent.split(/\n{2,}/);
    for (const raw of paragraphs) {
      const line = raw.trim();
      if (!line) continue;
      // Skip pure-decoration lines: markdown headings, images, dividers,
      // blockquote-only lines, and bare URLs.
      if (/^#{1,6}\s/.test(line)) continue;       // # Heading
      if (/^!\[/.test(line)) continue;              // ![alt](url)
      if (/^(-{3,}|\*{3,}|_{3,})$/.test(line)) continue; // ---
      if (/^>\s*$/.test(line)) continue;            // empty blockquote
      // Strip leading markdown list markers + remaining inline image
      // markdown for the description text.
      const prose = line
        .replace(/^[-*+]\s+/, "")
        .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
        .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
        .trim();
      if (prose.length >= 25) {
        return truncateAtWord(prose, maxLen);
      }
    }
    // No "good" paragraph found — use the first non-decoration line.
    const firstLine = cleanContent.split("\n").map((l) => l.trim()).find(Boolean);
    if (firstLine) {
      return truncateAtWord(
        firstLine
          .replace(/^#{1,6}\s+/, "")
          .replace(/^[-*+]\s+/, "")
          .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
          .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
          .trim(),
        maxLen
      );
    }
  }

  // Last resort: the title (always non-empty per DB constraints).
  return truncateAtWord(stripControlChars(title).trim(), maxLen);
}

// ── URL helpers ─────────────────────────────────────────────────────────────

/**
 * Resolve the absolute base URL from the admin-configured "platform.site_url"
 * PlatformSetting, with env var fallback, with localhost dev fallback.
 *
 * SINGLE SOURCE OF TRUTH (per PHASE-7 SEO audit):
 *   1. PlatformSetting "platform.site_url" (admin-editable via Admin → SEO
 *      → Domain Settings). This is the AUTHORITATIVE source — when the
 *      admin changes it, ALL SEO surfaces (sitemap, robots, canonical, OG,
 *      JSON-LD) pick up the new value within 30s (the getSetting cache TTL).
 *   2. NEXT_PUBLIC_APP_BASE_URL env var (set in Netlify dashboard). Used as
 *      fallback when the DB PlatformSetting is empty/unset.
 *   3. http://localhost:3000 — dev/test only. In production, throws when
 *      both #1 and #2 are missing (fail-closed — prevents localhost URLs
 *      from leaking into Google's index).
 *
 * @async This function reads from the DB (getSetting). All SEO surfaces that
 *        can be async (sitemap.ts, robots.ts, layout.tsx generateMetadata,
 *        /articles/[id] generateMetadata, /topics/[tag] generateMetadata,
 *        loadPlatformSeoContext) MUST use this async version. They already
 *        await other async calls, so this is a drop-in replacement.
 *
 * CACHING: getSetting has a 30s in-memory cache (via cacheGetOrSet in
 *   src/lib/cache/index.ts). So repeat hits on a hot server are essentially
 *   free — no DB query on every request.
 */
export async function loadBaseUrl(): Promise<string> {
  // Try the admin-configured platform.site_url FIRST (single source of truth).
  // Try/catch around the DB read so a DB outage doesn't crash the page —
  // we fall through to the env var.
  let dbValue: string | null = null;
  try {
    const { getSetting } = await import("@/lib/settings");
    dbValue = await getSetting("platform.site_url");
  } catch {
    // DB unreachable — fall through to env var.
  }
  const raw = dbValue || process.env.NEXT_PUBLIC_APP_BASE_URL;
  if (!raw) {
    const env = process.env.NODE_ENV;
    // Fail-closed in production AND when NODE_ENV is unset/empty (a
    // misconfigured deployment is treated as production — same pattern
    // as the AUTH_SECRET fix in src/lib/auth/session.ts).
    if (env !== "development" && env !== "test") {
      throw new Error(
        "NEXT_PUBLIC_APP_BASE_URL (or platform.site_url PlatformSetting) " +
          "must be set to the public deployment URL (e.g. https://centrychat.netlify.app). " +
          "Without it, canonical URLs, OG metadata, sitemap entries, and " +
          "robots.txt would leak localhost URLs to search engines."
      );
    }
    return "http://localhost:3000";
  }
  return raw.replace(/\/+$/, "");
}

/**
 * Synchronous fallback that reads ONLY from the env var (no DB access).
 *
 * USED BY: code paths that must be sync (e.g. the proxy.ts middleware which
 * can't await). For all SEO-critical surfaces, prefer the async loadBaseUrl()
 * above — it has the admin-configurable platform.site_url as primary source.
 *
 * @deprecated prefer loadBaseUrl() in any code path that can be async.
 */
export function resolveBaseUrl(): string {
  const raw = process.env.NEXT_PUBLIC_APP_BASE_URL;
  if (!raw) {
    const env = process.env.NODE_ENV;
    if (env !== "development" && env !== "test") {
      throw new Error(
        "NEXT_PUBLIC_APP_BASE_URL must be set to the public deployment URL " +
          "(e.g. https://centrychat.netlify.app). Without it, canonical URLs, " +
          "OG metadata, sitemap entries, and robots.txt would leak localhost " +
          "URLs to search engines."
      );
    }
    return "http://localhost:3000";
  }
  return raw.replace(/\/+$/, "");
}

/**
 * Resolve a possibly-relative URL to an absolute one using the site
 * base URL. Pass-through if the input is already absolute (http/https).
 * Returns null if the input is null/empty.
 *
 * Used for coverImage (which the article editor stores verbatim — could
 * be either a Cloudinary/https URL or a relative path) and for the
 * platform default OG image.
 */
/**
 * Hostnames known to serve EMBEDDED VIDEO (YouTube, Vimeo, TikTok, etc.)
 * or SOCIAL POSTS (X, Instagram) — NOT direct images.
 *
 * Used by `isPlausibleImageUrl` to reject URLs that would NOT work as
 * og:image. Crawlers (WhatsApp, Facebook, Twitter) reject video-embed
 * URLs as og:image — they need a direct image URL or a thumbnail.
 *
 * List is intentionally CONSERVATIVE — only hostnames we're SURE about
 * are rejected. Everything else passes through (crawlers will probe).
 */
const NON_IMAGE_HOSTNAMES = new Set([
  "youtube.com",
  "www.youtube.com",
  "m.youtube.com",
  "youtu.be",
  "youtube-nocookie.com",
  "www.youtube-nocookie.com",
  "vimeo.com",
  "player.vimeo.com",
  "tiktok.com",
  "www.tiktok.com",
  "m.tiktok.com",
  "instagram.com",
  "www.instagram.com",
  "x.com",
  "twitter.com",
  "www.x.com",
  "www.twitter.com",
  "facebook.com",
  "www.facebook.com",
  "m.facebook.com",
  "fb.watch",
  "reddit.com",
  "www.reddit.com",
]);

/**
 * Check whether a URL is PLAUSIBLY a direct image URL.
 *
 * Returns TRUE when the URL passes these checks:
 *   - non-empty
 *   - starts with http:// or https:// (relative URLs are also accepted
 *     — they'll be resolved to absolute by the caller)
 *   - NOT pointing at a known non-image host (YouTube/Vimeo/TikTok/etc.)
 *
 * Returns FALSE when the URL is clearly NOT a direct image (e.g. a
 * YouTube watch URL the user pasted into coverImage by mistake).
 *
 * This is a HEURISTIC — we don't probe the URL here (too slow for the
 * metadata path). The caller decides whether to use the URL as og:image
 * based on this heuristic. If FALSE, the caller falls back to the next
 * available image source (video thumbnail, then platform default).
 */
export function isPlausibleImageUrl(input: string | null | undefined): boolean {
  if (!input) return false;
  const trimmed = input.trim();
  if (!trimmed) return false;
  if (!/^https?:\/\//i.test(trimmed)) return false;
  let host = "";
  try {
    host = new URL(trimmed).hostname.toLowerCase();
  } catch {
    return false;
  }
  return !NON_IMAGE_HOSTNAMES.has(host);
}

/**
 * Guess the MIME type of an image URL based on its file extension.
 *
 * Used to populate `og:image:type` — a hint some crawlers (Telegram,
 * Discord) prefer when deciding which image to render. WhatsApp ignores
 * this hint and probes the URL itself.
 *
 * Returns the MIME type as a string (e.g. "image/jpeg"), or null if the
 * extension is unknown or missing (the caller should omit `type` in
 * that case — let the crawler probe).
 */
export function guessImageMimeType(url: string | null | undefined): string | null {
  if (!url) return null;
  const trimmed = url.trim().toLowerCase();
  if (!trimmed) return null;
  // Strip query string + hash before checking the extension.
  const path = trimmed.split(/[?#]/)[0];
  if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
  if (path.endsWith(".png")) return "image/png";
  if (path.endsWith(".gif")) return "image/gif";
  if (path.endsWith(".webp")) return "image/webp";
  if (path.endsWith(".bmp")) return "image/bmp";
  // SVG is technically a valid MIME type, but WhatsApp rejects SVG images.
  // We still return the correct MIME — the caller decides whether to use
  // the URL based on the production fallback policy (see buildArticleMetadata:
  // SVG fallback is replaced with /og-default.png).
  if (path.endsWith(".svg")) return "image/svg+xml";
  return null;
}

export function toAbsoluteUrl(
  input: string | null | undefined,
  baseUrl: string
): string | null {
  if (!input) return null;
  const trimmed = input.trim();
  if (!trimmed) return null;
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  // Relative path — prepend base URL (normalizing any duplicate slashes).
  const path = trimmed.startsWith("/") ? trimmed : `/${trimmed}`;
  return `${baseUrl}${path}`;
}

/**
 * Resolve the BEST og:image URL for an article, in priority order:
 *
 *   1. article.coverImage      — only if it's a plausible IMAGE URL
 *                              (rejects YouTube/Vimeo/etc. URLs the
 *                              user may have pasted by mistake)
 *   2. videoThumbnailUrl      — YouTube/Vimeo thumbnail (better than
 *                              a generic logo because it's content-specific)
 *   3. platform.default_og_image — admin-configured in Customization panel
 *   4. /og-default.png        — the CentryChat-branded 1200x630 PNG
 *                              (deployed in /public — raster, WhatsApp-safe)
 *
 * Returns { url, source } where source is a string identifying which
 * fallback was used (useful for debugging — "cover" | "video-thumb" |
 * "platform-default" | "builtin").
 */
export function resolveArticleOgImage(
  article: Pick<ArticleSeoInput, "coverImage" | "videoThumbnailUrl">,
  ctx: PlatformSeoContext
): { url: string; source: "cover" | "video-thumb" | "platform-default" | "builtin" } {
  const baseUrl = ctx.baseUrl.replace(/\/+$/, "");

  // 1. Real cover image — only if it's a plausible direct image URL.
  if (article.coverImage && isPlausibleImageUrl(article.coverImage)) {
    const abs = toAbsoluteUrl(article.coverImage, baseUrl);
    if (abs) return { url: abs, source: "cover" };
  }

  // 2. Video thumbnail (YouTube hqdefault, Vimeo thumbnail, etc.).
  //    Resolve to absolute in case it's relative (rare — YouTube thumbnails
  //    are always https://i.ytimg.com/...).
  if (article.videoThumbnailUrl && isPlausibleImageUrl(article.videoThumbnailUrl)) {
    const abs = toAbsoluteUrl(article.videoThumbnailUrl, baseUrl);
    if (abs) return { url: abs, source: "video-thumb" };
  }

  // 3. Platform-configured default OG image (admin panel →
  //    platform.default_og_image setting). When set, prefer it over the
  //    builtin /og-default.png so the admin can fully customize.
  if (ctx.defaultOgImage) {
    const abs = toAbsoluteUrl(ctx.defaultOgImage, baseUrl);
    if (abs) return { url: abs, source: "platform-default" };
  }

  // 4. Builtin /og-default.png — a 1200x630 PNG with CentryChat branding.
  //    This is the LAST-RESORT fallback. WhatsApp rejects SVG (the old
  //    /icon.svg fallback) so we use a raster PNG that always renders.
  return { url: `${baseUrl}/og-default.png`, source: "builtin" };
}

/** Build the canonical article URL: `${baseUrl}/articles/${id}`. */
export function buildArticleUrl(articleId: string, baseUrl: string): string {
  return `${baseUrl}/articles/${encodeURIComponent(articleId)}`;
}

/** Build the author's profile URL inside the SPA: `${baseUrl}/?view=profile&username=…`. */
export function buildAuthorProfileUrl(username: string, baseUrl: string): string {
  return `${baseUrl}/?view=profile&username=${encodeURIComponent(username)}`;
}

// ── Language detection ──────────────────────────────────────────────────────

/**
 * Detect the dominant language tag for an article based on its content.
 *
 * Returns a BCP-47 language tag suitable for `inLanguage` (JSON-LD) and
 * `og:locale` (Open Graph). The detection is intentionally SIMPLE —
 * Arabic vs Latin (English/French) — because that's the actual language
 * matrix the platform supports today (see src/lib/i18n/index.ts: en, ar, fr).
 *
 * Detection rule:
 *   - If the text contains a meaningful ratio of Arabic-script characters
 *     (U+0600..U+06FF range), classify as "ar" (with the regional variant
 *     "ar_MA" for og:locale, since the platform targets the Moroccan
 *     audience by default per the spec).
 *   - Otherwise default to "en" (English). The platform's default UI
 *     language is "en" (see DEFAULTS in src/lib/settings/index.ts).
 *
 * This is a HEURISTIC — it is intentionally NOT used to override any
 * user-set language preference. It only fills in `inLanguage` / og:locale
 * when the article itself doesn't carry an explicit language field (the
 * current Article model has no per-article language column, so we always
 * infer). When the platform later adds an article-level language field,
 * the caller can pass it and skip detection.
 */
export function detectArticleLanguage(text: string): {
  inLanguage: string;
  ogLocale: string;
} {
  const sample = text.slice(0, 2000); // first 2k chars is plenty
  const arabicChars = (sample.match(/[\u0600-\u06FF]/g) ?? []).length;
  // Threshold: at least 15% Arabic chars among all letter chars → "ar".
  // 15% is conservative — mixed Arabic/Latin content (e.g. an Arabic
  // article with English brand names) still classifies as "ar" because
  // the primary readership is Arabic.
  const letterChars = (sample.match(/[\p{L}]/gu) ?? []).length;
  if (letterChars > 0 && arabicChars / letterChars >= 0.15) {
    return { inLanguage: "ar", ogLocale: "ar_MA" };
  }
  return { inLanguage: "en", ogLocale: "en_US" };
}

// ── JSON-LD builders ────────────────────────────────────────────────────────

/**
 * Build the Article JSON-LD structured data object.
 *
 * Schema.org/Article is the default. NewsArticle is NOT auto-applied —
 * the platform does not currently distinguish news from regular articles
 * in the DB schema, so forcing NewsArticle would be misleading.
 *
 * Fields populated (per spec §6):
 *   - @context, @type
 *   - headline        (article.title)
 *   - description     (extracted meta description)
 *   - image           (coverImage absolute URL — wrapped in ImageObject
 *                      when available; falls back to default OG image)
 *   - datePublished   (publishedAt || createdAt — real, never faked)
 *   - dateModified    (updatedAt — real, never faked)
 *   - author          (Person with name + url to profile; if author is
 *                      the platform itself, Organization instead)
 *   - publisher       (Organization: platform name + logo)
 *   - mainEntityOfPage(@type WebPage, @id = canonical URL)
 *   - url             (canonical URL)
 *   - inLanguage      (detected from content)
 *   - interactionStatistic (LikeAction / CommentAction / WatchAction —
 *                      only when counts are provided)
 *
 * SECURITY: every string field is sanitized via stripControlChars. The
 * caller renders the resulting object via JSON.stringify inside a
 * `<script type="application/ld+json">` tag, which is safe (Next.js
 * + modern V8 escape `</script>` sequences in JSON.stringify output).
 */
export function buildArticleJsonLd(
  article: ArticleSeoInput,
  ctx: PlatformSeoContext
): Record<string, unknown> {
  const baseUrl = ctx.baseUrl.replace(/\/+$/, "");
  const articleUrl = buildArticleUrl(article.id, baseUrl);
  // ── Per-article SEO overrides (PHASE-7 SEO audit) ────────────────
  // Same logic as buildArticleMetadata: custom values override defaults.
  // JSON-LD MUST stay consistent with <meta> tags (Google cross-checks).
  const customTitle = article.customSeoTitle?.trim() || null;
  const customDesc = article.customMetaDescription?.trim() || null;
  const customCanonicalUrl = article.customCanonical?.trim() || null;
  const canonicalUrl = customCanonicalUrl
    ? stripControlChars(customCanonicalUrl)
    : articleUrl;
  const headline = stripControlChars(customTitle ?? article.title);
  const description = customDesc
    ? truncateAtWord(stripControlChars(customDesc), 155)
    : extractMetaDescription(article.excerpt, article.content, article.title);
  const { inLanguage, ogLocale } = detectArticleLanguage(
    `${article.title}\n\n${article.content}`
  );

  // Image: use the unified resolver (cover → video thumbnail →
  // platform default → /og-default.png). Same priority order as the
  // <meta og:image> tag so JSON-LD and OG stay CONSISTENT (spec §25).
  const { url: imageUrl } = resolveArticleOgImage(article, ctx);

  // Author — always present in the DB (article must have an author). We
  // model it as a Person with a profile URL (the SPA's `?view=profile`
  // deep link). Per spec §7: do NOT invent an Author Profile URL system
  // if one doesn't exist — the SPA already supports `?view=profile`.
  const authorProfileUrl = buildAuthorProfileUrl(article.author.username, baseUrl);
  const author: Record<string, unknown> = {
    "@type": "Person",
    name: stripControlChars(article.author.fullName),
    url: authorProfileUrl,
  };

  // Publisher — always the platform (Organization). Logo uses the
  // platform's configured logo URL when set, otherwise the builtin
  // /icon.svg (the favicon — fine for JSON-LD publisher.logo, which
  // is NOT subject to WhatsApp's SVG rejection; that only affects
  // og:image meta tags).
  const publisherLogoUrl = ctx.logoUrl
    ? toAbsoluteUrl(ctx.logoUrl, baseUrl)
    : `${baseUrl}/icon.svg`;
  const publisher = {
    "@type": "Organization",
    name: stripControlChars(ctx.name),
    url: baseUrl,
    logo: {
      "@type": "ImageObject",
      url: publisherLogoUrl,
    },
  };

  // Interaction statistics — only include when the caller provided the
  // counts (the SSR page fetches them via Prisma _count). Omitting a
  // missing count is better than emitting "0" (which would be misleading
  // — it could mean "no engagement yet" or "we don't track this").
  const interactionStatistic: unknown[] = [];
  if (article.likeCount != null) {
    interactionStatistic.push({
      "@type": "InteractionCounter",
      interactionType: "https://schema.org/LikeAction",
      userInteractionCount: article.likeCount,
    });
  }
  if (article.commentCount != null) {
    interactionStatistic.push({
      "@type": "InteractionCounter",
      interactionType: "https://schema.org/CommentAction",
      userInteractionCount: article.commentCount,
    });
  }
  if (article.viewCount != null) {
    interactionStatistic.push({
      "@type": "InteractionCounter",
      interactionType: "https://schema.org/WatchAction",
      userInteractionCount: article.viewCount,
    });
  }

  // Dates — always real DB values. datePublished falls back to createdAt
  // when publishedAt is null (e.g. an article published before the
  // publishedAt column existed — old data). dateModified always uses
  // updatedAt; if updatedAt === createdAt (never edited), that's fine —
  // it's still the truth.
  const datePublished = article.publishedAt ?? article.createdAt;

  const jsonLd: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline,
    description,
    image: imageUrl,
    datePublished: datePublished.toISOString(),
    dateModified: article.updatedAt.toISOString(),
    author,
    publisher,
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": canonicalUrl,
    },
    url: canonicalUrl,
    inLanguage,
  };

  if (interactionStatistic.length > 0) {
    jsonLd.interactionStatistic = interactionStatistic;
  }

  // og:locale is included as a sibling field for compatibility with
  // crawlers that look at JSON-LD for locale info. It's NOT a standard
  // schema.org property, but it doesn't break validation (schema.org
  // ignores unknown properties).
  jsonLd.inLanguage = inLanguage;
  // Stash the OG locale for the caller to use in the <meta> tags.
  // (Not part of JSON-LD output — we expose it via a separate field.)
  (jsonLd as Record<string, unknown>).__ogLocale = ogLocale;

  return jsonLd;
}

/**
 * Build a BreadcrumbList JSON-LD for the article page.
 *
 * Per spec §15: only add BreadcrumbList when the system has categories.
 * The current Article model has NO categories — but we can still emit
 * a minimal Home → Article breadcrumb, which is helpful for search
 * engines to understand the site hierarchy.
 *
 * If/when the platform adds categories, this function should be
 * extended to insert the category in the middle of the chain.
 */
export function buildBreadcrumbJsonLd(
  article: Pick<ArticleSeoInput, "id" | "title">,
  ctx: PlatformSeoContext
): Record<string, unknown> {
  const baseUrl = ctx.baseUrl.replace(/\/+$/, "");
  const articleUrl = buildArticleUrl(article.id, baseUrl);
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: stripControlChars(ctx.name),
        item: baseUrl,
      },
      {
        "@type": "ListItem",
        position: 2,
        name: stripControlChars(article.title),
        item: articleUrl,
      },
    ],
  };
}

/**
 * Build the Organization JSON-LD for the root layout (site-wide).
 *
 * Per spec §31: only emit Organization schema when we have real platform
 * data. We always have at least the platform name + base URL, so this
 * is safe to emit on every page.
 */
export function buildOrganizationJsonLd(
  ctx: PlatformSeoContext
): Record<string, unknown> {
  const baseUrl = ctx.baseUrl.replace(/\/+$/, "");
  const logoUrl = ctx.logoUrl
    ? toAbsoluteUrl(ctx.logoUrl, baseUrl)
    : `${baseUrl}/icon.svg`;
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: stripControlChars(ctx.name),
    url: baseUrl,
    description: stripControlChars(ctx.description),
    logo: {
      "@type": "ImageObject",
      url: logoUrl,
    },
  };
}

// ── Next.js Metadata builder ────────────────────────────────────────────────

/**
 * Build the Next.js `Metadata` object for an article page.
 *
 * This is consumed by `generateMetadata()` in
 * src/app/articles/[id]/page.tsx. It produces:
 *   - title (format: `Article Title | Platform Name`)
 *   - description (extracted)
 *   - canonical URL (absolute)
 *   - OpenGraph (article type, with image, locale, site name,
 *     publishedTime, modifiedTime, authors — emits both
 *     <meta name="author"> and <meta property="article:author">)
 *   - Twitter Card (summary_large_image)
 *   - robots (index, follow — only when PUBLISHED, with
 *     max-image-preview:large hint for Google search results)
 *   - alternates.canonical
 *   - other (article:author, article:publisher — emitted as
 *     <meta name="..."> via Next.js `other` field; the standard
 *     <meta property="article:author"> is emitted via openGraph.authors)
 *
 * The title separator is `|` per the spec example
 *   "لامين يامال: مسيرته من روكافوندا إلى برشلونة | CentryChat"
 * (the existing implementation used `—` em-dash; switching to `|` per
 * spec without breaking anything — it's a metadata-only change).
 */
export function buildArticleMetadata(
  article: ArticleSeoInput,
  ctx: PlatformSeoContext
): Metadata {
  const baseUrl = ctx.baseUrl.replace(/\/+$/, "");
  const articleUrl = buildArticleUrl(article.id, baseUrl);

  // ── Per-article SEO overrides (PHASE-7 SEO audit) ────────────────
  // When the author/admin set a custom value, use it. Otherwise fall back
  // to the auto-generated defaults. This is the SINGLE PLACE where the
  // override logic lives — every downstream field (title, description,
  // canonical, OG, Twitter, JSON-LD) reads from these resolved values.
  const customTitle = article.customSeoTitle?.trim() || null;
  const customDesc = article.customMetaDescription?.trim() || null;
  const customCanonicalUrl = article.customCanonical?.trim() || null;

  // Description: prefer custom → auto-extract from excerpt/content → title.
  const description = customDesc
    ? truncateAtWord(stripControlChars(customDesc), 155)
    : extractMetaDescription(article.excerpt, article.content, article.title);

  // Title: prefer custom → article.title. The visible <title> format is
  // "{Title} | {Platform Name}" so the platform brand is always visible
  // in the browser tab + search results.
  const rawTitle = (customTitle ?? article.title).trim();
  const title = stripControlChars(rawTitle);

  // Canonical: prefer custom → default /articles/{id}.
  const canonicalUrl = customCanonicalUrl
    ? stripControlChars(customCanonicalUrl)
    : articleUrl;

  const { ogLocale } = detectArticleLanguage(
    `${article.title}\n\n${article.content}`
  );

  const platformName = stripControlChars(ctx.name);

  // Author profile URL (used in article:author + JSON-LD + the standard
  // <meta name="author"> tag). Same value across all three for consistency.
  const authorProfileUrl = buildAuthorProfileUrl(article.author.username, baseUrl);
  const authorName = stripControlChars(article.author.fullName);

  // OG image — unified resolver picks the best URL (cover → video thumbnail →
  // platform default → /og-default.png). The result is ALWAYS a valid
  // absolute URL pointing at a raster image (PNG/JPEG/GIF/WebP) — never
  // an SVG (WhatsApp rejects SVG).
  const { url: imageUrl } = resolveArticleOgImage(article, ctx);
  const imageMimeType = guessImageMimeType(imageUrl);
  const isHttps = imageUrl.startsWith("https://");

  // Only published articles are indexable. Drafts / other statuses get
  // noindex (defensive — the page route already 404s drafts, but this
  // belt-and-suspenders in case a draft somehow reaches the metadata
  // builder without going through the 404 path).
  //
  // PHASE-7 SEO audit: also respect the per-article seoNoindex/seoNofollow
  // overrides. When seoNoindex=true → noindex. When seoNofollow=true →
  // add nofollow. These are admin/author-controlled per article.
  const isPublished = article.status === "PUBLISHED";
  const noindex = !isPublished || article.seoNoindex === true;
  const nofollow = !isPublished || article.seoNofollow === true;

  // Build the OG image object. We OMIT width/height because we don't
  // actually know the dimensions of the cover image at metadata-build
  // time (would require a HEAD probe — too slow for the metadata path).
  // Crawlers (WhatsApp, Facebook, Twitter, Telegram, LinkedIn) all
  // probe the image URL themselves and read its real dimensions.
  //
  // Spec §14: "يفضل Social Preview image مناسبة لـOpen Graph. مثلاً:
  // 1200 × 630" — "preferred" (يفضل), not mandatory. Lying about
  // dimensions when we don't know them would be WORSE than omitting.
  //
  // The object literal type is inferred by TypeScript (compatible with
  // Next.js OGImageDescriptor — has url, optional secureUrl, type, alt).
  const ogImage = {
    url: imageUrl,
    alt: title, // spec §10 — alt text fallback to article title.
    ...(isHttps ? { secureUrl: imageUrl } : {}), // og:image:secure_url alias.
    ...(imageMimeType ? { type: imageMimeType } : {}), // og:image:type hint.
  };

  return {
    title: `${title} | ${platformName}`,
    description,
    keywords: undefined, // No meta keywords — spec §26 explicitly forbids keyword stuffing.
    authors: [{ name: authorName, url: authorProfileUrl }],
    openGraph: {
      title,
      description,
      url: canonicalUrl, // OG:url should match canonical (per Google's spec)
      siteName: platformName,
      type: "article",
      locale: ogLocale,
      // openGraph.authors renders <meta property="article:author"> — this
      // is the canonical OG property (not <meta name="author"> which is
      // emitted separately by the top-level `authors` field above).
      // Spec §11 requires article:author. Both meta tags are emitted.
      authors: [authorName],
      images: [ogImage],
      ...(article.publishedAt && {
        publishedTime: article.publishedAt.toISOString(),
      }),
      modifiedTime: article.updatedAt.toISOString(),
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [
        {
          url: imageUrl,
          alt: title,
        },
      ],
    },
    robots: {
      index: !noindex,
      follow: !nofollow,
      // Hint to Google: prefer the LARGE image preview in search
      // results (vs 'standard' or 'none'). Spec §13 implies this —
      // we want a rich visual card in Google search.
      // Note: Next.js's Robots type uses the kebab-case key (not
      // camelCase) — see node_modules/.../metadata-types.d.ts.
      "max-image-preview": "large" as const,
    },
    alternates: {
      canonical: canonicalUrl,
    },
    // Article-level OG properties not covered by Next.js's typed fields.
    // - article:publisher: identifies the publishing Organization. Some
    //   crawlers (Facebook) use this to attribute the article to a brand.
    //   Points to the platform homepage URL.
    other: {
      "article:publisher": baseUrl,
    },
  };
}

// ── Platform context loader ────────────────────────────────────────────────

/**
 * Load the PlatformSeoContext from PlatformSetting (with the existing
 * 30-second cache). This is the ONLY function in this module that touches
 * the DB. Call it from generateMetadata / the page route, NOT from the
 * pure JSON-LD / Metadata builders.
 *
 * Defaults:
 *   - name: the platform.name PlatformSetting (default "CentryChat" —
 *     the canonical brand name; matches the spec §24 publisher + §7
 *     title suffix).
 *   - description: the platform.description setting, or a neutral
 *     placeholder.
 *   - baseUrl: NEXT_PUBLIC_APP_BASE_URL (resolved via resolveBaseUrl()).
 *   - defaultOgImage: the platform.default_og_image setting if set
 *     (otherwise null — the builders will fall back to /og-default.png).
 *   - logoUrl: the platform.logo_url setting if set (otherwise null —
 *     the builders will fall back to /icon.svg for JSON-LD publisher.logo,
 *     which is fine since SVG is only rejected by og:image meta tags).
 */
export async function loadPlatformSeoContext(): Promise<PlatformSeoContext> {
  // Lazy import to keep this module testable without pulling the DB
  // into pure-function call sites. In practice Next.js bundling keeps
  // this as a single chunk — no runtime cost.
  const { getSetting } = await import("@/lib/settings");

  // Use the async loadBaseUrl() so the admin-editable platform.site_url
  // is the primary source (single source of truth — env var is fallback).
  const baseUrl = await loadBaseUrl();

  // Use Promise.all to fetch all settings in parallel (each getSetting
  // is independently cached for 30s, so this is cheap on repeat hits).
  const [name, description, defaultOgImage, logoUrl] = await Promise.all([
    getSetting("platform.name"),
    getSetting("platform.description"),
    getSetting("platform.default_og_image"),
    getSetting("platform.logo_url"),
  ]);

  return {
    name: name ?? "Platform",
    description: description ?? "A self-hostable messaging platform.",
    baseUrl,
    defaultOgImage: defaultOgImage || null,
    logoUrl: logoUrl || null,
  };
}

/**
 * Render a JSON-LD object to a safe HTML string for use inside
 * `<script type="application/ld+json" dangerouslySetInnerHTML={{__html:...}} />`.
 *
 * Uses JSON.stringify — modern V8 escapes `</script>` and `<!--` sequences
 * automatically when serializing strings, preventing the classic
 * JSON-LD XSS via `</script><script>...` payloads. We additionally
 * strip ASCII control chars defensively.
 *
 * Returns the serialized string. The caller does NOT need to escape
 * anything further.
 *
 * SECURITY FIX (C-1 + H-2): JSON.stringify does NOT escape `<` or `</`.
 * This means a string containing `</script><script>alert(1)</script>`
 * would break out of the <script type="application/ld+json"> block and
 * execute as arbitrary JavaScript — a stored/reflected XSS vector.
 *
 * The fix: replace ALL `<` characters with their Unicode escape `\u003c`.
 * This is safe inside a JSON string (JSON.parse still reads it as `<`)
 * but prevents the browser from interpreting `</script>` as a tag close.
 *
 * This is the OWASP-recommended approach for JSON-LD in <script> blocks.
 */
export function serializeJsonLd(obj: unknown): string {
  return JSON.stringify(obj).replace(/</g, "\\u003c");
}
