/**
 * SEO helper for Playlist public pages.
 *
 * Builds the Metadata object + JSON-LD for a public Playlist. The logic
 * mirrors buildArticleMetadata (single source of truth for OG/Twitter/
 * canonical/JSON-LD), but is simpler because Playlists don't have
 * per-item translations, custom SEO overrides, or moderation gates.
 */
import type { Metadata } from "next";
import { db } from "@/lib/database";
import {
  loadPlatformSeoContext,
  loadBaseUrl,
  toAbsoluteUrl,
  isPlausibleImageUrl,
  serializeJsonLd,
  stripControlChars,
  truncateAtWord,
} from "@/lib/seo/article";
import { resolveMedia } from "@/lib/media/resolver";
import { logger } from "@/lib/logging";

/** Minimal Playlist shape needed for SEO. */
export interface PlaylistSeoInput {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  coverImage: string | null;
  isPublic: boolean;
  createdAt: Date;
  updatedAt: Date;
  owner: {
    id: string;
    fullName: string;
    username: string;
    avatarUrl: string | null;
  };
  itemCount: number;
}

/** Build the public playlist URL: /playlist/[slug]. */
export function buildPlaylistUrl(slug: string, baseUrl: string): string {
  const base = baseUrl.replace(/\/+$/, "");
  return `${base}/playlist/${encodeURIComponent(slug)}`;
}

/** Build the owner's profile URL: /?view=profile&username=... */
export function buildPlaylistOwnerUrl(username: string, baseUrl: string): string {
  const base = baseUrl.replace(/\/+$/, "");
  return `${base}/?view=profile&username=${encodeURIComponent(username)}`;
}

/**
 * Resolve the best og:image for a playlist, in priority order:
 *   1. playlist.coverImage — if it's a plausible IMAGE URL
 *   2. first item's article.coverImage (when the playlist has items)
 *   3. platform.default_og_image — admin-configured in Customization panel
 *   4. /og-default.png — builtin fallback
 *
 * Returns absolute URL (HTTPS preferred).
 */
export async function resolvePlaylistOgImage(
  playlist: Pick<PlaylistSeoInput, "coverImage" | "id">,
  ctx: Awaited<ReturnType<typeof loadPlatformSeoContext>>
): Promise<{ url: string; source: "cover" | "first-item" | "platform-default" | "builtin" }> {
  const baseUrl = ctx.baseUrl.replace(/\/+$/, "");

  // 1. Playlist's own cover image.
  if (playlist.coverImage && isPlausibleImageUrl(playlist.coverImage)) {
    const abs = toAbsoluteUrl(playlist.coverImage, baseUrl);
    if (abs) return { url: abs, source: "cover" };
  }

  // 2. First item's article cover image (better than a generic logo
  //    because it's content-specific — e.g. an "Avatar Full Story"
  //    playlist shows the cover of Part 1).
  try {
    const firstItem = await db.playlistItem.findFirst({
      where: { playlistId: playlist.id },
      orderBy: [{ position: "asc" }, { addedAt: "asc" }, { id: "asc" }],
      select: {
        article: {
          select: { coverImage: true },
        },
      },
    });
    if (firstItem?.article?.coverImage && isPlausibleImageUrl(firstItem.article.coverImage)) {
      const abs = toAbsoluteUrl(firstItem.article.coverImage, baseUrl);
      if (abs) return { url: abs, source: "first-item" };
    }
  } catch {
    // Non-fatal — fall through to platform default.
  }

  // 3. Platform-configured default OG image.
  if (ctx.defaultOgImage) {
    const abs = toAbsoluteUrl(ctx.defaultOgImage, baseUrl);
    if (abs) return { url: abs, source: "platform-default" };
  }

  // 4. Builtin /og-default.png.
  return { url: `${baseUrl}/og-default.png`, source: "builtin" };
}

/**
 * Build the Next.js Metadata for a public Playlist page.
 *
 * Mirrors buildArticleMetadata: title, description, canonical, OG,
 * Twitter, robots (index only when public).
 */
export function buildPlaylistMetadata(
  playlist: PlaylistSeoInput,
  ctx: Awaited<ReturnType<typeof loadPlatformSeoContext>>,
  ogImageUrl: string
): Metadata {
  const baseUrl = ctx.baseUrl.replace(/\/+$/, "");
  const playlistUrl = buildPlaylistUrl(playlist.slug, baseUrl);

  const rawName = stripControlChars(playlist.name);
  const platformName = stripControlChars(ctx.name);

  // Description: prefer the playlist description; fall back to a generic
  // "{itemCount} parts" string. Cap at 160 chars.
  const descSource =
    playlist.description?.trim() ||
    `${playlist.itemCount} ${playlist.itemCount === 1 ? "part" : "parts"} in this playlist by ${playlist.owner.fullName}`;
  const description = truncateAtWord(stripControlChars(descSource), 155);

  // Private playlists are NEVER indexed (spec §18).
  const indexable = playlist.isPublic;

  return {
    title: `${rawName} | ${platformName}`,
    description,
    alternates: { canonical: playlistUrl },
    robots: indexable
      ? { index: true, follow: true }
      : { index: false, follow: false },
    openGraph: {
      title: rawName,
      description,
      url: playlistUrl,
      siteName: platformName,
      type: "website",
      images: ogImageUrl ? [{ url: ogImageUrl }] : undefined,
    },
    twitter: {
      card: "summary_large_image",
      title: rawName,
      description,
      images: ogImageUrl ? [ogImageUrl] : undefined,
    },
  };
}

/**
 * Build the JSON-LD ItemList for a public Playlist.
 *
 * Schema.org ItemList is the right type for an ordered list of content
 * (which is exactly what a Playlist is). Each item is a ListItem with
 * position + url + name pointing at the underlying Article.
 *
 * We include the first ~50 items (capped for performance + to avoid
 * JSON-LD payload bloat — Google's limit is reasonable here).
 */
export function buildPlaylistJsonLd(
  playlist: PlaylistSeoInput,
  items: Array<{ articleId: string; position: number; articleTitle: string | null }>,
  ctx: Awaited<ReturnType<typeof loadPlatformSeoContext>>
) {
  const baseUrl = ctx.baseUrl.replace(/\/+$/, "");
  const playlistUrl = buildPlaylistUrl(playlist.slug, baseUrl);
  const ownerUrl = buildPlaylistOwnerUrl(playlist.owner.username, baseUrl);

  return {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: stripControlChars(playlist.name),
    description: playlist.description
      ? truncateAtWord(stripControlChars(playlist.description), 300)
      : undefined,
    url: playlistUrl,
    numberOfItems: playlist.itemCount,
    datePublished: playlist.createdAt.toISOString(),
    dateModified: playlist.updatedAt.toISOString(),
    author: {
      "@type": "Person",
      name: stripControlChars(playlist.owner.fullName),
      url: ownerUrl,
    },
    itemListElement: items.map((item) => ({
      "@type": "ListItem",
      position: item.position + 1, // Schema.org positions are 1-indexed
      url: `${baseUrl}/articles/${item.articleId}`,
      name: item.articleTitle
        ? stripControlChars(item.articleTitle)
        : `Part ${item.position + 1}`,
    })),
  };
}

/**
 * Convenience: load platform SEO context with a safe fallback.
 * Mirrors the article page's pattern.
 */
export async function loadPlaylistSeoContext() {
  try {
    return await loadPlatformSeoContext();
  } catch {
    return null;
  }
}

/**
 * Resolve the playlist cover image media (server-side) so anonymous
 * visitors see the cover WITHOUT calling the auth-gated /api/v1/media/resolve
 * endpoint. Same pattern as the article page's resolveMedia for cover/video.
 *
 * Best-effort — returns null on failure (the UI renders a fallback card).
 */
export async function resolvePlaylistCoverMedia(coverImage: string | null) {
  if (!coverImage) return null;
  try {
    return await resolveMedia(coverImage);
  } catch (err) {
    logger.warn("seo", "Failed to resolve playlist cover media", {
      error: err instanceof Error ? err.message : String(err),
    });
    return null;
  }
}

/** Re-export for the page route to use. */
export { loadBaseUrl };
export { serializeJsonLd };
