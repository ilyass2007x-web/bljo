/**
 * Unified Content Ranking Engine
 * ==============================
 *
 * Multi-signal ranking for the unified Home Feed. Handles BOTH Posts AND
 * Articles as first-class content — they share the same scoring pipeline
 * so the algorithm doesn't fragment into two separate systems (spec §17).
 *
 * Scoring components (all configurable via RANKING_WEIGHTS):
 *   1. Recency — exponential time decay. Fresh content gets a boost but
 *      old high-engagement content can still surface.
 *   2. Engagement — likes (×3) + comments (×5) + shares (×4) + unique
 *      views (×0.5). Active signals (like/comment/share) are much
 *      stronger than passive views.
 *   3. Engagement Rate — (likes + comments + shares) / unique_views.
 *      Normalizes for audience size so a post with 10 likes from 20
 *      views outranks a post with 10 likes from 1000 views.
 *   4. Following Boost — flat bonus for content from followed authors.
 *   5. Exploration — boost for high-quality content from non-followed
 *      authors (discovery). Prevents the echo chamber.
 *   6. Diversity Penalty — Nth post from the same author gets a
 *      progressively lower score. Prevents one creator from filling
 *      the feed.
 *   7. Velocity — engagement-per-hour since publish. Surfaces trending
 *      content (high engagement in a short window).
 *   8. Quality — content-quality signals:
 *        Posts:    content length (sweet spot 50-280 chars), has URLs,
 *                  has mentions/hashtags (signals thoughtfulness).
 *        Articles: title quality, excerpt quality, content length,
 *                  has cover image, has video, reading time.
 *   9. New Content Boost — temporary boost for freshly-published content
 *      to give it a discovery opportunity. Decays as the content ages
 *      AND is removed if engagement stays at 0 (so a brand-new post with
 *      no engagement doesn't dominate).
 *  10. Self Penalty — the user's own content gets a small penalty so it
 *      doesn't dominate their own feed (they already see it when posting).
 *  11. Spam Penalty — placeholder for future spam detection (currently
 *      only flags posts with extremely low quality score AND zero
 *      engagement after 24h — a soft signal, never a hard ban).
 *
 * Anti-spam (spec §16, §25):
 *   - Engagement is computed from UNIQUE interactions only (PostLike /
 *     ArticleLike have @@unique([postId, userId]) / [articleId, userId]
 *     constraints — duplicate likes are impossible at the DB level).
 *   - Shares are counted from ArticleInteraction/PostInteraction rows
 *     where type='SHARE' — one row per share event (a user can share
 *     multiple times, but the velocity cap prevents runaway scores).
 *   - The velocity score is CAPPED at 20 engagement/hour to prevent
 *     a viral post from dominating forever.
 *
 * Architecture (spec §18 — "scalable architecture"):
 *   1. Retrieve candidate content (DB query, with _count aggregation —
 *      single SQL with LEFT JOINs, no N+1).
 *   2. Apply lightweight filters (status='PUBLISHED' for articles, etc.).
 *   3. Calculate ranking signals in-memory (O(n) where n = candidate pool).
 *   4. Rank candidates by total score.
 *   5. Apply diversity penalties (same author appearing multiple times).
 *   6. Return the top N items.
 *
 * Performance (spec §19, §22):
 *   - 1 DB query for the candidate pool (with _count for likes/comments/views).
 *   - 1 DB query for the user's followed IDs (reused for isFollowing).
 *   - 1 DB query for share counts (batched via groupBy).
 *   - Scoring is O(n) — typically 60-100 candidates per page.
 *   - Total: 3 queries + in-memory scoring. No N+1.
 *
 * Caching (spec §19):
 *   - The RANKING_WEIGHTS are loaded from the PlatformSetting table via
 *     getSetting (which uses a 30s in-memory cache). Admins can change
 *     weights via the admin panel without code redeploy.
 *   - The candidate pool is NOT cached — fresh data on every request
 *     ensures new content appears immediately (spec §21).
 *
 * Explainability (spec §27 — Admin debug mode):
 *   - Each ScoredContent item exposes its `components` (recency,
 *     engagement, engagementRate, following, exploration, diversity,
 *     velocity, quality, newContentBoost, self, spam) so an admin
 *     debug view can show WHY a piece of content ranked where it did.
 *
 * NOT FAKE AI (spec §46):
 *   - This is a real algorithmic ranking system using measurable signals.
 *   - No "AI" or "ML model" claim is made. No external AI/embedding
 *     dependency is added. The architecture is designed so a future
 *     embeddings/semantic-search system can be plugged in (via a
 *     `topicSimilarity` component) without rewriting the engine.
 */

import { calculateInterestMatch } from "@/lib/feed/personalization";

// ── Configurable Weights ────────────────────────────────────────────────────
// Defaults are sane; admins can override via PlatformSetting keys
// `algorithm.weight.<name>` (see src/lib/settings/index.ts). The
// `getRankingWeights()` helper reads them with a 30s cache.

export interface RankingWeights {
  /** Exponential decay rate for recency. 1.0 = ~3-hour half-life. */
  recencyDecay: number;
  /** Relative weight of a like (active engagement). */
  likeWeight: number;
  /** Relative weight of a comment (strongest active engagement). */
  commentWeight: number;
  /** Relative weight of a share (strongest distribution signal). */
  shareWeight: number;
  /** Relative weight of a unique view (passive engagement). */
  viewWeight: number;
  /** Multiplier for engagement-rate component (caps at 1.0 normalized). */
  engagementRateWeight: number;
  /** Flat bonus for content from a followed author. */
  followingBoost: number;
  /** Flat boost for non-followed content (discovery). */
  explorationBoost: number;
  /** Fraction of the candidate pool reserved for exploration (0-1). */
  explorationRatio: number;
  /** Per-repeat penalty for the same author in the candidate pool. */
  diversityPenalty: number;
  /** Bonus for high engagement-per-hour (trending surfacing). */
  velocityBonus: number;
  /** Multiplier for the content-quality component. */
  qualityWeight: number;
  /** Temporary boost for brand-new content (decays). */
  newContentBoost: number;
  /** Small penalty for the user's own content in their own feed. */
  selfPenalty: number;
  /** Cap for engagement-per-hour in velocity calc (prevents runaway). */
  velocityCap: number;
  // ── Phase 1 Personalized Feed — ADDITIVE new weights (spec §7) ──────────
  // All admin-configurable via `algorithm.weight.<name>` PlatformSetting
  // keys (the existing loadRankingWeights() in the unified feed route
  // auto-picks up any key in DEFAULT_RANKING_WEIGHTS — no extra wiring).
  //
  // These are deliberately SMALL relative to the existing signals (recency,
  // engagement, followingBoost) so the feed doesn't overfit to the user's
  // history at the expense of diversity + discovery. The 5-bucket mix +
  // the diversity penalty + the topic-diversity penalty below keep the
  // feed varied.
  /**
   * Multiplier for graded author-affinity score (0-1) from the user's
   * interaction history. SEPARATE from the binary `followingBoost` —
   * even non-followed authors the user has consistently engaged with
   * get a small boost. Default 8.0 (about half of followingBoost).
   */
  authorAffinityWeight: number;
  /**
   * Multiplier for short-term (session) interest match. Boosts content
   * whose topics match what the user has engaged with in the last 30 min.
   * Default 10.0 — slightly stronger than long-term affinity because
   * recency of intent matters.
   */
  shortTermBoostWeight: number;
  /**
   * Flat penalty applied when the candidate's topics are in the user's
   * explicit "not interested" list. Default 15.0 (large enough to demote
   * but not so large that it creates a hard filter — the user can still
   * see the content if it ranks high on other signals).
   */
  notInterestedPenalty: number;
  /**
   * Multiplier for content-type affinity (post vs article preference).
   * Small default (3.0) — should NOT dominate the feed mix.
   */
  contentTypeAffinityWeight: number;
  /**
   * Per-repeat penalty for the same TOPIC in the candidate pool.
   * Spec §5: "Do NOT show 20 consecutive posts about the same topic."
   * Default 2.0 (smaller than author diversityPenalty=5.0 because topic
   * repetition is less egregious than author repetition).
   */
  topicDiversityPenalty: number;
  /**
   * Phase 2 — Topics: boost for content whose author's topics intersect
   * with the user's EXPLICITLY followed topics (UserTopicFollow table).
   * This is a STRONG positive signal (stronger than graded authorAffinity)
   * because it represents an explicit user declaration.
   *
   * Default 12.0 — between `followingBoost=15.0` (binary follow of an
   * author) and `authorAffinityWeight=8.0` (graded engagement). The
   * difference is: following an AUTHOR boosts ALL their content; following
   * a TOPIC boosts content ABOUT that topic from ANY author.
   *
   * Scaled by match count (1 match → 0.6×, 2 matches → 0.8×, 3+ → 1.0×)
   * — the same topic appearing in multiple of the candidate's author's
   * topics is a stronger signal than a single match.
   */
  followedTopicBoostWeight: number;
}

export const DEFAULT_RANKING_WEIGHTS: RankingWeights = {
  // Phase 3 — tuned for a smarter mix:
  //   recencyDecay 0.5 → ~6h half-life (was 1.0 → 3h). Old high-engagement
  //   content stays surfacable longer. A 24h-old post still gets ~5% of
  //   the recency score (vs ~0% before) — engagement can push it up.
  recencyDecay: 0.5,
  likeWeight: 3.0,
  commentWeight: 5.0,
  shareWeight: 4.0,
  viewWeight: 0.5,
  engagementRateWeight: 12.0,
  followingBoost: 15.0,
  explorationBoost: 10.0,
  explorationRatio: 0.15,
  diversityPenalty: 5.0,
  velocityBonus: 8.0,
  qualityWeight: 10.0,
  newContentBoost: 12.0,
  selfPenalty: 5.0,
  velocityCap: 20.0,
  // ── Phase 1 Personalized Feed — new defaults (spec §7) ──────────────────
  // Tuned to be SIGNIFICANT but not dominant:
  //   - authorAffinityWeight 8.0  → ~half of followingBoost (15). A non-
  //     followed author the user has engaged with 10x ranks similar to a
  //     brand-new followed author.
  //   - shortTermBoostWeight 10.0 → slightly stronger than author affinity
  //     because recency of intent matters (last 30 min).
  //   - notInterestedPenalty 15.0 → matches followingBoost — a topic the
  //     user explicitly rejected is treated as the OPPOSITE of a follow.
  //   - contentTypeAffinityWeight 3.0 → small. Should NOT cause the feed
  //     to flip to all-posts or all-articles just because the user has a
  //     slight preference. The 5-bucket mix + diversity keep it varied.
  //   - topicDiversityPenalty 2.0 → per-repeat-topic penalty, smaller
  //     than author diversityPenalty (5.0) because topic repetition is a
  //     softer signal than author repetition.
  authorAffinityWeight: 8.0,
  shortTermBoostWeight: 10.0,
  notInterestedPenalty: 15.0,
  contentTypeAffinityWeight: 3.0,
  topicDiversityPenalty: 2.0,
  // Phase 2 — Topics: explicit topic-follow boost. Stronger than graded
  // authorAffinity (8.0) but weaker than binary author followingBoost (15.0).
  followedTopicBoostWeight: 12.0,
};

// ── Types ───────────────────────────────────────────────────────────────────

/**
 * A unified content item — either a Post or an Article — with all the
 * fields needed for ranking. The caller (the unified feed endpoint)
 * converts Prisma rows into this shape before passing to the ranker.
 */
export interface RankableContent {
  /** "post" | "article" — determines which quality signals apply. */
  type: "post" | "article";
  id: string;
  authorId: string;
  /** Posts: the content. Articles: the title (for quality scoring). */
  titleOrContent: string;
  /** Articles only: the excerpt (null for posts). */
  excerpt?: string | null;
  /** Articles only: full content length (for quality scoring). */
  contentLength?: number;
  /** Articles only: has a cover image. */
  hasCoverImage?: boolean;
  /** Articles only: has a video URL. */
  hasVideo?: boolean;
  /** Articles only: reading time in minutes. */
  readingTime?: number;
  /** The timestamp used for recency/velocity (createdAt for posts, publishedAt for articles). */
  timestamp: Date;
  /** Aggregated counts (from Prisma _count). */
  counts: {
    likes: number;
    comments: number;
    views: number;
    shares: number;
  };
}

/** Context about the current user needed for scoring. */
export interface RankingUserContext {
  userId: string;
  followedAuthorIds: Set<string>;
  /**
   * The user's interest profile — Map<topicSlug, score 0-1>.
   * Empty when the user has no interests yet (cold start). When empty, the
   * interestMatch component returns 0 for every candidate — they're ranked
   * purely on recency/engagement/trending/freshness/diversity signals.
   *
   * Optional (defaults to empty Map when omitted) for backward compatibility
   * with the existing /api/v1/posts endpoint (which doesn't yet pass this).
   */
  interestProfile?: Map<string, number>;
  /**
   * Map<authorId, topicSlugs[]> — the top 3 topics associated with each
   * candidate's author (inferred from their most-engaged ContentInteractions).
   * Used to compute the interestMatch score. When the author has no
   * interactions or the map is empty, interestMatch = 0 for that candidate.
   *
   * Optional — the ranker skips interestMatch if this is missing.
   */
  authorTopics?: Map<string, string[]>;
  /**
   * Phase 2 — Topics: Map<authorId, topicIds[]> — the top topic IDs
   * associated with each candidate's author (from explicit ArticleTopic/
   * PostTopic relationships). Used to compute the followedTopicBoost score.
   *
   * Phase 2.1 — IMPORTANT SEMANTIC CORRECTION:
   *   Despite the field NAME `authorTopicIds`, this map is keyed by
   *   CONTENT ID (not author ID). Each entry contains the Topic IDs
   *   attached to that specific piece of content (via ArticleTopic /
   *   PostTopic relationships), NOT the author's followed/created topics.
   *
   *   The field name is preserved for backward compatibility with the
   *   Phase 2 ranker interface (renaming would create unnecessary risk).
   *   The lookup in `scoreAndRankContent` uses `item.id` (content ID),
   *   NOT `item.authorId`.
   *
   *   Correct semantics:
   *     - CONTENT TOPICS → `authorTopicIds` (this field)
   *     - USER FOLLOWED TOPICS → ranking comparison (followedTopicIds)
   *
   *   When absent, the ranker's followedTopicBoost returns 0 (cold start).
   *
   *   The map key is a composite `"${item.type}:${item.id}"` to avoid
   *   collisions between Post cuids and Article cuids (both are cuids,
   *   so collisions are extremely unlikely but the composite key is the
   *   safety net).
   */
  authorTopicIds?: Map<string, string[]>;
  /**
   * Personalization weight (default 30). Loaded by the caller from the
   * `rec.weight.personalization` admin setting. Applied to the normalized
   * interest-match score.
   */
  personalizationWeight?: number;
  /**
   * Whether to include "reason" strings in the ScoredContent output (for the
   * admin debug view + future "Recommended because..." UI). False by default.
   */
  enableTransparency?: boolean;
  /**
   * Phase 4 — Feed Seed for DETERMINISTIC controlled variation.
   *
   * A 32-bit unsigned integer hashed from the client's per-session seed
   * string. Used by the ranker's seeded PRNG to apply jitter to near-equal-
   * scored items. Same seed → same jitter → same feed order across
   * pagination pages within a session. New session → new seed → new order.
   *
   * When omitted (or 0), the ranker falls back to Math.random() — but this
   * is only for backward compat with callers that don't pass a seed. The
   * unified feed endpoint ALWAYS passes a seed now.
   *
   * The seed makes the feed STABLE while the user scrolls (no reordering
   * mid-session) but VARIED on refresh/new session. This is the spec's
   * core requirement (§14: "don't reorder while scrolling", §15: "refresh
   * can produce a different order").
   */
  feedSeed?: number;
  // ── Phase 1 Personalized Feed — ADDITIVE new optional fields ──────────
  // All OPTIONAL — when absent, the corresponding scoring component is 0
  // (backward compat with existing callers like /api/v1/posts that don't
  // pass these). This preserves the existing API contract.
  /**
   * Graded author affinity: Map<authorId, score 0-1>. Derived from the
   * user's ContentInteraction history (see getUserInterestProfile). Unlike
   * the BINARY `followedAuthorIds` (which is follow / not-follow), this is
   * a graded signal — a non-followed author the user has engaged with 10x
   * gets a small boost, separate from the flat `followingBoost`.
   *
   * When absent or empty, authorAffinity component = 0 (only the binary
   * followingBoost applies — backward compat).
   */
  authorAffinity?: Map<string, number>;
  /**
   * Short-term (session) interests: Map<topicSlug, score 0-1>. Computed
   * from the user's ContentInteraction rows in the last 30 minutes (see
   * getUserInterestProfile). When the candidate's author's topics match
   * the user's short-term interests, the candidate gets a temporary boost.
   *
   * This is SEPARATE from the long-term `interestProfile` — both can fire
   * on the same candidate (long-term match → interestMatch, short-term
   * match → shortTermBoost). Short-term decays naturally as the user
   * stops engaging with that topic.
   */
  shortTermInterests?: Map<string, number>;
  /**
   * Topics the user explicitly marked "not interested" (via the existing
   * /api/v1/not-interested endpoint → engine.markNotInterested → stored on
   * RecommendationProfile.notInterestedTopics as JSON). When a candidate's
   * author's topics intersect with this set, the candidate gets a flat
   * penalty (admin-configurable: `algorithm.weight.notInterestedPenalty`).
   *
   * This is NOT a hard filter — high-quality content the user has shown
   * other interest in can still surface. It's a strong demotion.
   */
  notInterestedTopics?: Set<string>;
  /**
   * Content-type affinity (post vs article preference), each in [0, 1].
   * Derived from the user's positive interaction counts per type. When
   * the candidate's type matches the user's preferred type, a small boost.
   * When neutral (0.5/0.5), no boost.
   */
  contentTypeAffinity?: { post: number; article: number };
  /**
   * Phase 2 — Topics: Set of topic IDs the user EXPLICITLY follows (from
   * UserTopicFollow table). When a candidate's author's topics intersect
   * with this set, the candidate gets a strong positive boost (separate
   * from graded authorAffinity + binary followingBoost).
   *
   * When absent or empty, the followedTopicBoost component returns 0
   * (cold start, no follows).
   */
  followedTopicIds?: Set<string>;
}

/** A scored content item ready for sorting. */
export interface ScoredContent {
  item: RankableContent;
  score: number;
  components: ScoreComponents;
  /**
   * Optional human-readable reason for the score (spec §27 — transparency).
   * E.g. "matches your interest in football", "from someone you follow",
   * "trending now". Null when transparency is disabled OR when no specific
   * reason applies (e.g. a chronological-only cold-start candidate).
   */
  reason?: string | null;
}

/** Breakdown of the score for explainability (spec §27). */
export interface ScoreComponents {
  recency: number;
  engagement: number;
  engagementRate: number;
  following: number;
  exploration: number;
  diversity: number;
  velocity: number;
  quality: number;
  newContentBoost: number;
  self: number;
  spam: number;
  /**
   * Personalization score (spec §5, §6, §10) — how well the candidate's
   * topics match the user's interest profile. 0 when the user has no
   * interest profile (cold start) OR the candidate's author has no topics.
   */
  interestMatch: number;
  // ── Phase 1 Personalized Feed — ADDITIVE new components (spec §9) ──────
  // All DEFAULT to 0 when the corresponding input is absent (backward compat).
  /**
   * Graded author-affinity boost (separate from binary `following`).
   * Derived from the user's ContentInteraction history — even non-followed
   * authors the user has consistently engaged with get a small boost.
   */
  authorAffinity: number;
  /**
   * Short-term (session) interest boost. Boosts content whose topics match
   * what the user has engaged with in the last 30 minutes.
   */
  shortTermBoost: number;
  /**
   * Penalty applied when the candidate's topics are in the user's explicit
   * "not interested" list. Negative value (subtracted from total score).
   */
  notInterestedPenalty: number;
  /**
   * Content-type affinity boost — small boost when the candidate's type
   * (post/article) matches the user's preferred type.
   */
  contentTypeAffinity: number;
  /**
   * Topic-diversity penalty — applied per-repeat-topic in the candidate
   * pool (similar to the per-repeat-author `diversity` component, but for
   * topics). Negative value. Spec §5: "Do NOT show 20 consecutive posts
   * about the same topic."
   */
  topicDiversity: number;
  /**
   * Phase 2 — Topics: explicit topic-follow boost. Boosts content whose
   * author's topics intersect with the user's explicitly followed topics.
   * Stronger than graded authorAffinity, weaker than binary followingBoost.
   */
  followedTopicBoost: number;
}

// ── Scoring Functions ───────────────────────────────────────────────────────

/**
 * Recency score — exponential time decay.
 * score = e^(-decay * hoursSincePost) * 100
 *
 * With decay=1.0:
 *   - 1 hour old  → 37
 *   - 3 hours old → 5
 *   - 24 hours old → ~0
 *
 * Old high-engagement content can still surface because engagement
 * is added on top — a 24-hour-old post with 100 likes still scores
 * ~300 from engagement alone.
 */
function calculateRecencyScore(timestamp: Date, now: Date, decay: number): number {
  const hoursSince = Math.max(0, (now.getTime() - timestamp.getTime()) / (1000 * 60 * 60));
  return Math.exp(-decay * hoursSince) * 100;
}

/**
 * Engagement score — weighted sum of unique interactions.
 *
 * Likes/comments/shares are ACTIVE signals (the user took explicit
 * action). Views are passive (the user might have scrolled past).
 * Shares are weighted higher than likes because distributing content
 * is a stronger relevance signal.
 *
 * Anti-spam (spec §16, §25): all counts come from UNIQUE interactions
 * (DB-level @@unique constraints on PostLike/ArticleLike/PostView/
 * ArticleView prevent duplicate rows). The share count comes from
 * ArticleInteraction/PostInteraction where type='SHARE' — one row
 * per share event, so a user can share multiple times but the velocity
 * cap prevents that from dominating.
 */
function calculateEngagementScore(
  counts: RankableContent["counts"],
  w: RankingWeights
): number {
  return (
    counts.likes * w.likeWeight +
    counts.comments * w.commentWeight +
    counts.shares * w.shareWeight +
    counts.views * w.viewWeight
  );
}

/**
 * Engagement RATE score — (likes + comments + shares) / unique_views.
 *
 * Normalizes for audience size so a post with 10 likes from 20 views
 * (50% engagement) outranks a post with 10 likes from 1000 views (1%
 * engagement). The raw rate is bounded to [0, 1] via min(rate, 1.0)
 * so extremely high rates (e.g. 1 like from 1 view = 100%) don't
 * dominate. The bounded rate is then multiplied by the weight.
 *
 * Handles zero views safely (returns 0 — never NaN/Infinity, per spec §5).
 */
function calculateEngagementRateScore(
  counts: RankableContent["counts"],
  w: RankingWeights
): number {
  if (counts.views <= 0) return 0;
  const rate = (counts.likes + counts.comments + counts.shares) / counts.views;
  const bounded = Math.min(rate, 1.0);
  return bounded * w.engagementRateWeight;
}

/**
 * Velocity score — engagement-per-hour since publish.
 *
 * A post with 10 likes in 5 minutes has higher velocity than a post
 * with 10 likes in 5 hours. This surfaces trending content.
 *
 * The velocity is CAPPED (default 20/hour) to prevent a viral post
 * from generating a runaway score that dominates the feed forever.
 *
 * Formula: (likes + comments + shares) / max(hoursSince, 0.1)
 *   - Min 0.1 hour (6 min) prevents division by zero + avoids
 *     over-rewarding brand-new posts that haven't had time to accumulate
 *     real engagement.
 */
function calculateVelocityScore(
  counts: RankableContent["counts"],
  timestamp: Date,
  now: Date,
  w: RankingWeights
): number {
  const totalEngagement = counts.likes + counts.comments + counts.shares;
  if (totalEngagement === 0) return 0;

  const hoursSince = Math.max(
    (now.getTime() - timestamp.getTime()) / (1000 * 60 * 60),
    0.1
  );
  const engagementPerHour = totalEngagement / hoursSince;
  const capped = Math.min(engagementPerHour, w.velocityCap);

  return (capped / w.velocityCap) * w.velocityBonus;
}

/**
 * Content quality score (spec §8).
 *
 * For POSTS:
 *   - Content length sweet spot: 50-280 chars (full Twitter-like range).
 *     Very short content (<20 chars) gets a penalty (low-effort signal).
 *     Very long content (>500 chars) gets a small bonus (long-form posts).
 *   - URLs / mentions / hashtags add small bonuses (signals thoughtfulness).
 *
 * For ARTICLES:
 *   - Title quality: 10-200 chars is the sweet spot.
 *   - Excerpt present: bonus (improves SEO + click-through).
 *   - Content length: longer content is rewarded (up to a cap — not
 *     infinitely, so a 100k-char article doesn't dominate).
 *   - Has cover image: bonus (visual content is more engaging).
 *   - Has video: bonus (multimedia content).
 *   - Reading time 1-30 min: bonus (reasonable length).
 *
 * DOES NOT rank content simply because it is long (spec §8) — the
 * caps prevent runaway scores.
 */
function calculateQualityScore(item: RankableContent, w: RankingWeights): number {
  if (item.type === "post") {
    const len = item.titleOrContent.length;
    let lengthScore: number;
    if (len < 20) lengthScore = -2;       // very short — low effort
    else if (len <= 280) lengthScore = 5; // sweet spot
    else if (len <= 1000) lengthScore = 3; // medium-long
    else lengthScore = 1;                  // very long — small bonus

    // Thoughtfulness signals (URLs, mentions, hashtags).
    const hasUrl = /https?:\/\//i.test(item.titleOrContent);
    const hasMention = /@\w/.test(item.titleOrContent);
    const hasHashtag = /#\w/.test(item.titleOrContent);
    const thoughtfulness = (hasUrl ? 1 : 0) + (hasMention ? 0.5 : 0) + (hasHashtag ? 0.5 : 0);

    return (lengthScore + thoughtfulness) * (w.qualityWeight / 5);
  }

  // Article quality.
  const titleLen = item.titleOrContent.length;
  const contentLen = item.contentLength ?? 0;
  const hasExcerpt = !!item.excerpt && item.excerpt.length > 10;
  const hasCover = !!item.hasCoverImage;
  const hasVideo = !!item.hasVideo;
  const readingTime = item.readingTime ?? 1;

  let titleScore: number;
  if (titleLen < 10) titleScore = -2;
  else if (titleLen <= 200) titleScore = 5;
  else titleScore = 2;

  // Content length score (capped at 5000 chars — doesn't reward fluff).
  const contentScore = Math.min(contentLen / 500, 5);

  const excerptScore = hasExcerpt ? 2 : 0;
  const coverScore = hasCover ? 3 : 0;
  const videoScore = hasVideo ? 3 : 0;
  const readingTimeScore = readingTime >= 1 && readingTime <= 30 ? 2 : 0;

  const total = titleScore + contentScore + excerptScore + coverScore + videoScore + readingTimeScore;
  return total * (w.qualityWeight / 5);
}

/**
 * New content boost (spec §14).
 *
 * Gives brand-new content a temporary discovery opportunity. The boost
 * decays exponentially over 6 hours (half-life ~2 hours), so:
 *   - 30 min old → full boost
 *   - 2 hours old → half boost
 *   - 6+ hours old → no boost
 *
 * IMPORTANT (spec §14): "Remove the boost if the content performs
 * poorly." If a post has ZERO engagement after 1 hour, the boost is
 * halved. After 3 hours with zero engagement, the boost is removed.
 * This prevents the feed from being flooded with brand-new zero-
 * engagement content.
 */
function calculateNewContentBoost(
  item: RankableContent,
  now: Date,
  w: RankingWeights
): number {
  const hoursSince = Math.max(0, (now.getTime() - item.timestamp.getTime()) / (1000 * 60 * 60));
  if (hoursSince > 6) return 0; // boost window is 6 hours

  // Exponential decay: at 0h → full, at 2h → ~37%, at 6h → ~5% (then 0).
  const decayFactor = Math.exp(-0.5 * hoursSince);
  let boost = w.newContentBoost * decayFactor;

  // Performance-based removal: if the content has zero engagement
  // after a meaningful window, the boost is reduced/removed.
  const totalEngagement = item.counts.likes + item.counts.comments + item.counts.shares;
  if (totalEngagement === 0) {
    if (hoursSince > 3) return 0;          // 3h zero engagement → no boost
    else if (hoursSince > 1) boost *= 0.3;  // 1-3h zero → 30% of boost
    // else (under 1h): full boost — too early to judge
  }

  return boost;
}

/**
 * Spam penalty (spec §16).
 *
 * Placeholder for future spam detection. Currently only flags:
 *   - Posts with extremely low quality score (length < 5 chars)
 *     AND zero engagement after 24h.
 *   - Articles with title < 10 chars AND zero engagement after 24h.
 *
 * This is a SOFT signal (small penalty), never a hard ban. Normal
 * users are never incorrectly penalized — the conditions are strict.
 *
 * Future: detect repeated identical content, suspicious engagement
 * patterns (e.g. all likes from new accounts created same day), etc.
 */
function calculateSpamPenalty(item: RankableContent, now: Date): number {
  const hoursSince = (now.getTime() - item.timestamp.getTime()) / (1000 * 60 * 60);
  if (hoursSince < 24) return 0; // too early to judge

  const totalEngagement = item.counts.likes + item.counts.comments + item.counts.shares;
  if (totalEngagement > 0) return 0; // has engagement — not spam by this signal

  if (item.type === "post" && item.titleOrContent.length < 5) {
    return -3; // very short content with zero engagement after 24h
  }
  if (item.type === "article" && item.titleOrContent.length < 10) {
    return -3;
  }
  return 0;
}

// ── Phase 1 Personalized Feed — new scoring functions (spec §9) ──────────
//
// All four functions are PURE + NULL-SAFE — they return 0 when the
// corresponding input is absent. This preserves backward compatibility
// with callers that don't pass the new context fields (e.g. /api/v1/posts).
//
// PERFORMANCE: all four are O(1) per candidate — no DB access, no loops
// beyond the candidate's topic list (max ~3 entries). The total cost
// added to the ranking pass is O(n × topicsPerCandidate) = O(n).

/**
 * Graded author-affinity boost (spec §9 — Creator Affinity).
 *
 * Unlike the BINARY `following` boost (which is 0 or followingBoost), this
 * is a graded signal — a non-followed author the user has engaged with 10x
 * gets a fractional boost proportional to their affinity score (0-1).
 *
 * The boost is ADDITIVE with the binary following boost: a followed author
 * the user has also engaged with 10x gets BOTH the followingBoost AND the
 * authorAffinity boost. This rewards depth of engagement on top of the
 * binary follow signal.
 *
 * @param authorId - the candidate's author ID.
 * @param authorAffinity - Map<authorId, score 0-1>. Empty/absent → 0.
 * @param w - the ranking weights (uses authorAffinityWeight).
 * @returns the boost value (0 when no affinity, otherwise score × weight).
 */
function calculateAuthorAffinityScore(
  authorId: string,
  authorAffinity: Map<string, number> | undefined,
  w: RankingWeights
): number {
  if (!authorAffinity || authorAffinity.size === 0) return 0;
  const score = authorAffinity.get(authorId);
  if (score === undefined || score <= 0) return 0;
  // Clamp to [0, 1] defensively — the profile normalizes but this guards
  // against any future code paths that might pass unclamped values.
  const clamped = Math.max(0, Math.min(1, score));
  return clamped * w.authorAffinityWeight;
}

/**
 * Short-term (session) interest boost (spec §9 — Recent Interests).
 *
 * Boosts content whose topics match what the user has engaged with in the
 * LAST 30 MINUTES. This is the "user interacted with AI content 8 times
 * today → AI receives a temporary boost" signal.
 *
 * SEPARATE from the long-term interestMatch component — both can fire on
 * the same candidate. Short-term decays naturally as the user stops
 * engaging with that topic (the profile's 30-min window slides forward).
 *
 * @param candidateTopics - the candidate's author's top topics (max ~3).
 * @param shortTermInterests - Map<topicSlug, score 0-1>. Empty/absent → 0.
 * @param w - the ranking weights (uses shortTermBoostWeight).
 * @returns the boost value (0 when no match).
 */
function calculateShortTermBoostScore(
  candidateTopics: string[],
  shortTermInterests: Map<string, number> | undefined,
  w: RankingWeights
): { score: number; topTopic: string | null } {
  if (
    candidateTopics.length === 0 ||
    !shortTermInterests ||
    shortTermInterests.size === 0 ||
    w.shortTermBoostWeight === 0
  ) {
    return { score: 0, topTopic: null };
  }
  let totalMatch = 0;
  let topTopic: string | null = null;
  let topScore = 0;
  for (const slug of candidateTopics) {
    const score = shortTermInterests.get(slug) ?? 0;
    if (score > 0) {
      totalMatch += score;
      if (score > topScore) {
        topScore = score;
        topTopic = slug;
      }
    }
  }
  if (totalMatch <= 0) return { score: 0, topTopic: null };
  // Normalize by topic count to avoid inflation (same pattern as
  // calculateInterestMatch in personalization.ts).
  const normalized = totalMatch / candidateTopics.length;
  return { score: normalized * w.shortTermBoostWeight, topTopic };
}

/**
 * Not-interested penalty (spec §9 — explicit negative feedback).
 *
 * Applies a flat penalty when the candidate's author's topics intersect
 * with the user's explicit "not interested" list. This is NOT a hard
 * filter — high-quality content can still surface if other signals
 * (engagement, recency, etc.) compensate. The penalty is admin-configurable
 * via `algorithm.weight.notInterestedPenalty`.
 *
 * @param candidateTopics - the candidate's author's top topics.
 * @param notInterestedTopics - Set<topicSlug>. Empty/absent → 0.
 * @param w - the ranking weights (uses notInterestedPenalty).
 * @returns a NEGATIVE value (or 0 when no intersection).
 */
function calculateNotInterestedPenalty(
  candidateTopics: string[],
  notInterestedTopics: Set<string> | undefined,
  w: RankingWeights
): { penalty: number; matchedTopic: string | null } {
  if (
    candidateTopics.length === 0 ||
    !notInterestedTopics ||
    notInterestedTopics.size === 0 ||
    w.notInterestedPenalty === 0
  ) {
    return { penalty: 0, matchedTopic: null };
  }
  // Scale the penalty by the number of matching topics (more matches →
  // stronger demotion). Capped at 1× the penalty weight (so a candidate
  // with all 3 topics in the not-interested list gets the full penalty,
  // not 3× the penalty — that would be disproportionate).
  let matchCount = 0;
  let firstMatch: string | null = null;
  for (const slug of candidateTopics) {
    if (notInterestedTopics.has(slug)) {
      matchCount++;
      if (firstMatch === null) firstMatch = slug;
    }
  }
  if (matchCount === 0) return { penalty: 0, matchedTopic: null };
  // Linear scale: 1 match → 0.5× penalty, 2 matches → 0.75×, 3+ → 1×.
  const scale = Math.min(0.5 + 0.25 * (matchCount - 1), 1.0);
  return { penalty: -w.notInterestedPenalty * scale, matchedTopic: firstMatch };
}

/**
 * Content-type affinity boost (spec §9 — Content-Type Affinity).
 *
 * Small boost when the candidate's type (post/article) matches the user's
 * preferred type. Deliberately small (default weight 3.0) — should NOT
 * cause the feed to flip to all-posts or all-articles just because the
 * user has a slight preference. The 5-bucket mix + diversity keep it varied.
 *
 * @param candidateType - "post" | "article".
 * @param contentTypeAffinity - { post: 0-1, article: 0-1 }. Absent → 0.
 * @param w - the ranking weights (uses contentTypeAffinityWeight).
 * @returns the boost value (positive when user prefers this type, 0 when
 *          neutral or absent).
 */
function calculateContentTypeAffinityScore(
  candidateType: "post" | "article",
  contentTypeAffinity: { post: number; article: number } | undefined,
  w: RankingWeights
): number {
  if (!contentTypeAffinity || w.contentTypeAffinityWeight === 0) return 0;
  // Neutral baseline: 0.5/0.5 → no boost (the user has no preference).
  // When the user prefers one type, the OTHER type gets a NEGATIVE boost
  // (small demotion). This keeps the feed balanced — we don't want to
  // show ONLY the user's preferred type.
  const userScore = candidateType === "post"
    ? contentTypeAffinity.post
    : contentTypeAffinity.article;
  // Clamp defensively.
  const clamped = Math.max(0, Math.min(1, userScore));
  // Deviation from neutral (0.5). Range: [-0.5, +0.5].
  const deviation = clamped - 0.5;
  return deviation * w.contentTypeAffinityWeight;
}

/**
 * Phase 2 — Topics: explicit topic-follow boost (spec §11).
 *
 * Boosts content whose author's topics intersect with the user's
 * EXPLICITLY followed topics (UserTopicFollow table). This is a STRONG
 * positive signal — stronger than graded authorAffinity, weaker than
 * binary author followingBoost.
 *
 * Scaled by match count: 1 match → 0.6× weight, 2 matches → 0.8×, 3+ → 1.0×.
 * A candidate whose author writes about MULTIPLE of the user's followed
 * topics is a stronger match than one with a single overlap.
 *
 * @param candidateTopicIds - the candidate's topic IDs (resolved from
 *   ArticleTopic/PostTopic relationships, OR author's top topics as a
 *   proxy when content-level topics aren't available).
 * @param followedTopicIds - Set of topic IDs the user follows. Empty/absent → 0.
 * @param w - the ranking weights (uses followedTopicBoostWeight).
 * @returns the boost value (0 when no match).
 */
function calculateFollowedTopicBoost(
  candidateTopicIds: string[],
  followedTopicIds: Set<string> | undefined,
  w: RankingWeights
): { score: number; matchedTopicId: string | null } {
  if (
    candidateTopicIds.length === 0 ||
    !followedTopicIds ||
    followedTopicIds.size === 0 ||
    w.followedTopicBoostWeight === 0
  ) {
    return { score: 0, matchedTopicId: null };
  }
  let matchCount = 0;
  let firstMatch: string | null = null;
  for (const topicId of candidateTopicIds) {
    if (followedTopicIds.has(topicId)) {
      matchCount++;
      if (firstMatch === null) firstMatch = topicId;
    }
  }
  if (matchCount === 0) return { score: 0, matchedTopicId: null };
  // Linear scale: 1 match → 0.6×, 2 matches → 0.8×, 3+ → 1.0×.
  const scale = Math.min(0.6 + 0.2 * (matchCount - 1), 1.0);
  return {
    score: w.followedTopicBoostWeight * scale,
    matchedTopicId: firstMatch,
  };
}

// ── Seeded PRNG (Phase 4) ──────────────────────────────────────────────────

/**
 * mulberry32 — a fast, deterministic 32-bit PRNG.
 *
 * Given the same seed, it produces the SAME sequence of pseudo-random
 * numbers every time. This is what makes the feed STABLE within a session
 * (page 1 and page 2 use the same seed → same jitter decisions → consistent
 * ordering) but VARIED across sessions (new seed → new sequence → new order).
 *
 * We use this instead of Math.random() because Math.random() produces a
 * DIFFERENT sequence on every call — which would mean page 2 of a feed
 * session could apply different jitter than page 1, causing inconsistent
 * ranking + potential duplicates.
 *
 * The algorithm is tiny (4 lines), fast, and has good enough distribution
 * for UI jitter purposes. Not crypto-secure — which is fine, this is for
 * feed variation, not security.
 *
 * EXPORTED so the unified feed route can use the SAME PRNG for its
 * exploration-bucket shuffle (keeps the shuffle deterministic per session
 * too, not just the jitter).
 *
 * @param seed - a 32-bit unsigned integer (from the feed seed hash).
 * @returns a function that returns a pseudo-random float in [0, 1).
 */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ── Main Scoring Function ───────────────────────────────────────────────────

/**
 * Score a list of candidate content (posts + articles mixed) and return
 * them sorted by score (descending).
 *
 * This is the MAIN entry point for the unified ranking engine. It:
 *   1. Calculates individual score components for each item.
 *   2. Applies diversity penalties (same author appearing multiple times).
 *   3. Sorts by total score.
 *   4. Returns the top N items.
 *
 * @param candidates - The candidate pool (typically 3-5x the page size).
 * @param userCtx   - The current user's context (id + followed author IDs).
 * @param limit     - How many items to return (page size).
 * @param weights   - Configurable weights (defaults from DEFAULT_RANKING_WEIGHTS).
 * @returns ScoredContent[] sorted by score descending, length = min(limit, candidates.length).
 */
export function scoreAndRankContent(
  candidates: RankableContent[],
  userCtx: RankingUserContext,
  limit: number,
  weights: RankingWeights = DEFAULT_RANKING_WEIGHTS
): ScoredContent[] {
  const now = new Date();

  // Personalization inputs — pulled out for clarity. All optional.
  const interestProfile = userCtx.interestProfile ?? new Map<string, number>();
  const authorTopics = userCtx.authorTopics ?? new Map<string, string[]>();
  // Phase 2 — Topics: also resolve the explicit topic ID map (for
  // followedTopicBoost). Falls back to empty when not provided — preserves
  // backward compat with callers that only pass the slug-based authorTopics.
  const authorTopicIds = userCtx.authorTopicIds ?? new Map<string, string[]>();
  const personalizationWeight = userCtx.personalizationWeight ?? 30;
  const enableTransparency = userCtx.enableTransparency ?? false;
  // Phase 4/5 — the feed seed for deterministic controlled variation.
  // Declared here (before Phase 1) because the variation bonus in Phase 2
  // needs it. When 0/omitted, no variation is applied (backward compat).
  const feedSeed = userCtx.feedSeed ?? 0;

  // Phase 1: Calculate base scores (no diversity yet).
  const scored: ScoredContent[] = candidates.map((item) => {
    const isFollowing = userCtx.followedAuthorIds.has(item.authorId);
    const isOwn = item.authorId === userCtx.userId;

    const recency = calculateRecencyScore(item.timestamp, now, weights.recencyDecay);
    const engagement = calculateEngagementScore(item.counts, weights);
    const engagementRate = calculateEngagementRateScore(item.counts, weights);
    const following = isFollowing ? weights.followingBoost : 0;
    // Exploration boost — only for non-followed, non-self content.
    // Self-content doesn't get the exploration boost (it's not "discovery"
    // if it's your own content).
    const exploration = !isFollowing && !isOwn ? weights.explorationBoost : 0;
    const velocity = calculateVelocityScore(item.counts, item.timestamp, now, weights);
    const quality = calculateQualityScore(item, weights);
    const newContentBoost = calculateNewContentBoost(item, now, weights);
    const self = isOwn ? -weights.selfPenalty : 0;
    const spam = calculateSpamPenalty(item, now);

    // ── Personalization: interest match (spec §5, §6, §10) ────────────
    // Pure function — never throws. Returns 0 when the user has no interest
    // profile OR the candidate's author has no inferred topics (cold start).
    // The reason string is only set when transparency is enabled.
    const candidateTopics = authorTopics.get(item.authorId) ?? [];
    const { score: interestMatchRaw, reason: interestReason } =
      calculateInterestMatch(
        candidateTopics,
        interestProfile,
        personalizationWeight,
        enableTransparency
      );
    const interestMatch = interestMatchRaw;

    // ── Phase 1 Personalized Feed — new personalization components (spec §9) ──
    // All four are NULL-SAFE — return 0 when the corresponding input is
    // absent. This preserves backward compat with callers that don't pass
    // the new context fields.
    const authorAffinityScore = calculateAuthorAffinityScore(
      item.authorId,
      userCtx.authorAffinity,
      weights
    );
    const { score: shortTermBoostRaw, topTopic: shortTermTopic } =
      calculateShortTermBoostScore(
        candidateTopics,
        userCtx.shortTermInterests,
        weights
      );
    const shortTermBoost = shortTermBoostRaw;
    const { penalty: notInterestedPenalty, matchedTopic: notInterestedMatched } =
      calculateNotInterestedPenalty(
        candidateTopics,
        userCtx.notInterestedTopics,
        weights
      );
    const contentTypeAffinityScore = calculateContentTypeAffinityScore(
      item.type,
      userCtx.contentTypeAffinity,
      weights
    );

    // ── Phase 2 — Topics: followed topic boost (spec §11) ──────────────
    // Strong positive signal when the candidate's CONTENT's topics intersect
    // with the user's explicitly followed topics.
    //
    // Phase 2.1 — SEMANTIC CORRECTION: the lookup key is now
    // `"${item.type}:${item.id}"` (content-level), NOT `item.authorId`.
    // This is the correct semantic — we want the topics attached to THIS
    // piece of content (via ArticleTopic/PostTopic), not the author's
    // topics. The feed route populates this map with composite keys.
    //
    // When `authorTopicIds` is absent (backward compat), falls back to empty
    // (boost = 0 — existing behavior preserved for callers that don't pass it).
    const candidateTopicIdsForFollow = authorTopicIds.get(`${item.type}:${item.id}`) ?? [];
    const { score: followedTopicBoostScore, matchedTopicId: followedTopicMatch } =
      calculateFollowedTopicBoost(
        candidateTopicIdsForFollow,
        userCtx.followedTopicIds,
        weights
      );
    const followedTopicBoost = followedTopicBoostScore;

    // Pick the strongest reason for transparency (prefer personalization
    // over following over trending — they're not mutually exclusive, but
    // the "Recommended because..." UI shows one reason at a time).
    let reason: string | null = null;
    if (enableTransparency) {
      if (notInterestedMatched) {
        // Don't surface "not interested" as a reason — that would be
        // confusing ("Recommended because you're not interested in X").
        // Fall through to other reasons OR null.
      }
      // Prefer the followed-topic boost reason (Phase 2 — explicit declaration
      // is the strongest signal). The matchedTopicId is just an ID, so we
      // surface a generic "followed topic" reason. (A future UI improvement
      // would resolve the ID to a topic name.)
      if (followedTopicMatch) {
        reason = "from a topic you follow";
      } else if (shortTermTopic) {
        reason = `you've been engaging with ${shortTermTopic} recently`;
      } else if (interestReason) {
        reason = interestReason;
      } else if (authorAffinityScore > 0 && !isFollowing) {
        // Only surface author affinity as a reason when the user is NOT
        // already following (otherwise the "from someone you follow" reason
        // below is more accurate).
        reason = "from a creator you engage with often";
      } else if (isFollowing) {
        reason = "from someone you follow";
      } else if (velocity > 0) {
        reason = "trending now";
      } else if (newContentBoost > 0) {
        reason = "fresh content";
      }
      // else: null — no specific reason to surface (cold-start ranked
      // purely on recency + engagement, no transparency useful).
    }
    void followedTopicMatch; // marker — used above for reason picking

    const score =
      recency +
      engagement +
      engagementRate +
      following +
      exploration +
      velocity +
      quality +
      newContentBoost +
      self +
      spam +
      interestMatch +
      // ── Phase 1 Personalized Feed — new components (spec §9) ──────
      authorAffinityScore +
      shortTermBoost +
      notInterestedPenalty + // already negative
      contentTypeAffinityScore +
      // ── Phase 2 — Topics: explicit topic-follow boost (spec §11) ──
      followedTopicBoost;

    return {
      item,
      score,
      components: {
        recency,
        engagement,
        engagementRate,
        following,
        exploration,
        diversity: 0, // applied in phase 2
        velocity,
        quality,
        newContentBoost,
        self,
        spam,
        interestMatch,
        // Phase 1 Personalized Feed — new components (default 0 when input
        // absent, preserving backward compat).
        authorAffinity: authorAffinityScore,
        shortTermBoost,
        notInterestedPenalty,
        contentTypeAffinity: contentTypeAffinityScore,
        topicDiversity: 0, // applied in the topic-diversity pass below
        // Phase 2 — Topics: explicit topic-follow boost.
        followedTopicBoost,
      },
      reason,
    };
  });

  // Phase 2: Apply diversity penalties.
  // Sort by current score first (so the BEST item from each author is
  // at the top), then penalize subsequent items from the same author.
  // This prevents one creator from filling the entire feed (spec §12).
  //
  // Phase 5 — BEFORE sorting, apply a SEEDED variation bonus to each score.
  // This is the "controlled randomization" that makes the feed change on
  // refresh. The bonus is ±10% of the item's own score — large enough to
  // shift items within the same tier, but small enough that a score-3000
  // post never gets jumped by a score-300 post (3000×0.9=2700 >> 300×1.1=330).
  //
  // The bonus is DETERMINISTIC per (seed, item.id): we hash the feedSeed
  // + the item's id to produce a per-item PRNG seed. Same seed + same item
  // → same bonus → stable order while scrolling. New seed → different
  // bonuses → different order on refresh.
  if (feedSeed > 0) {
    for (const s of scored) {
      // Hash (feedSeed, item.id) → per-item PRNG seed.
      let itemSeed = feedSeed >>> 0;
      const idStr = s.item.id;
      for (let i = 0; i < idStr.length; i++) {
        itemSeed ^= idStr.charCodeAt(i);
        itemSeed = Math.imul(itemSeed, 0x01000193);
      }
      const itemRng = mulberry32(itemSeed >>> 0);
      // Random factor in [0.9, 1.1] — ±10% variation.
      const variationFactor = 0.9 + itemRng() * 0.2;
      s.score *= variationFactor;
    }
  }

  scored.sort((a, b) => b.score - a.score);

  const authorItemCount = new Map<string, number>();
  for (const s of scored) {
    const count = authorItemCount.get(s.item.authorId) ?? 0;
    if (count > 0) {
      const penalty = weights.diversityPenalty * count;
      s.score -= penalty;
      s.components.diversity = -penalty;
    }
    authorItemCount.set(s.item.authorId, count + 1);
  }

  // ── Phase 1 Personalized Feed — topic-diversity pass (spec §5) ──────
  // Spec §5: "Do NOT show 20 consecutive posts about the same topic."
  //
  // After the author-diversity pass above, we apply a SECOND pass that
  // penalizes repeated TOPICS in the candidate pool. This prevents the
  // filter-bubble failure mode where 5 different authors all post about
  // the same trending topic + the feed ends up monolithic despite the
  // author diversity.
  //
  // The penalty is SMALLER per-repeat than the author diversity (default
  // topicDiversityPenalty=2.0 vs diversityPenalty=5.0) because topic
  // repetition is a softer signal than author repetition — the same topic
  // covered by 3 different authors is genuinely valuable variety.
  //
  // Phase 2.1 — SEMANTIC CORRECTION: uses the `authorTopicIds` map
  // (keyed by composite content key) to get the content's first topic.
  // Falls back to the legacy `authorTopics` (slug-based, keyed by authorId)
  // when `authorTopicIds` is empty (backward compat with callers that
  // only pass the slug-based map).
  //
  // Only the candidate's FIRST topic counts toward the diversity tracker
  // — using all topics would over-penalize authors who write about
  // multiple topics (which is GOOD).
  //
  // Candidates with NO topics are NOT penalized — they have no topic
  // signal to track. They pass through untouched.
  if (weights.topicDiversityPenalty > 0 && (authorTopicIds.size > 0 || authorTopics.size > 0)) {
    const topicItemCount = new Map<string, number>();
    for (const s of scored) {
      // Phase 2.1 — prefer the content-level topic IDs (composite key)
      // when available. Fall back to the slug-based authorTopics map
      // for backward compatibility with callers that don't populate
      // authorTopicIds.
      const contentKey = `${s.item.type}:${s.item.id}`;
      const contentTopicIds = authorTopicIds.get(contentKey);
      let primaryTopic: string | undefined;
      if (contentTopicIds && contentTopicIds.length > 0) {
        // Use the first topic ID (content-level). Topic IDs are stable
        // cuids — fine for the diversity tracker.
        primaryTopic = contentTopicIds[0];
      } else {
        // Fallback to slug-based authorTopics (legacy Phase 1 path).
        const candidateTopicsLegacy = authorTopics.get(s.item.authorId) ?? [];
        primaryTopic = candidateTopicsLegacy[0];
      }
      if (!primaryTopic) continue; // no topic signal — skip
      const count = topicItemCount.get(primaryTopic) ?? 0;
      if (count > 0) {
        const penalty = weights.topicDiversityPenalty * count;
        s.score -= penalty;
        s.components.topicDiversity = -penalty;
      }
      topicItemCount.set(primaryTopic, count + 1);
    }
  }

  // Phase 3: Re-sort by final score.
  scored.sort((a, b) => b.score - a.score);

  // ── Phase 3.5: Controlled randomization for near-equal scores ───────
  // Spec §23: "If Post A score = 82 and Post B score = 81, sometimes swap
  // them. But if Post A = 95 and Post B = 40, never swap."
  //
  // Phase 4 — now SEEDED for deterministic per-session variation:
  //   - Same feedSeed → same PRNG sequence → same swap decisions → stable
  //     order while the user scrolls (no reordering mid-session).
  //   - New feedSeed (on refresh/new session) → new PRNG sequence →
  //     different swaps → varied order on refresh.
  //
  // The threshold is 8 points (was 3) — this makes more items eligible
  // for variation so the feed actually changes on refresh. A post with
  // score 95 still never gets jumped by a score-40 post (gap = 55 >> 8).
  //
  // IMPLEMENTATION: walk through the sorted list. For each adjacent pair
  // whose score difference is within JITTER_THRESHOLD, call the seeded
  // PRNG. If it returns < 0.5, swap them. This is a single pass — O(n).
  // (feedSeed was declared at the top of the function.)
  const rng = feedSeed > 0 ? mulberry32(feedSeed) : Math.random;
  const JITTER_THRESHOLD = 8.0;
  for (let i = 0; i < scored.length - 1; i++) {
    const a = scored[i]!;
    const b = scored[i + 1]!;
    if (Math.abs(a.score - b.score) <= JITTER_THRESHOLD) {
      // Seeded decision — same seed always makes the same choice here.
      if (rng() < 0.5) {
        scored[i] = b;
        scored[i + 1] = a;
      }
    }
  }

  return scored.slice(0, limit);
}

/**
 * Build the candidate pool size for the feed.
 *
 * Phase 5 — increased to 5x the requested limit (was 4x), capped at
 * 30-150. A larger pool gives the ranker more material to diversify
 * across + ensures the "seen IDs" exclusion doesn't shrink the pool
 * below a useful size on later pages. This is especially important
 * now that the FOLLOWING + RECOMMENDED buckets order by engagement
 * (not recency) — the pool needs to be large enough to contain both
 * high-engagement older posts AND recent posts for the ranker to mix.
 */
export function getCandidatePoolSize(requestedLimit: number): number {
  return Math.min(Math.max(requestedLimit * 5, 30), 150);
}

/**
 * Split a scored pool into "followed" and "exploration" buckets based
 * on the configured explorationRatio. This is used by the unified feed
 * endpoint to fetch the right mix of content (spec §3 + §13).
 */
export function splitByExploration<T extends { item: RankableContent }>(
  scored: T[],
  userCtx: RankingUserContext,
  explorationRatio: number
): { followed: T[]; exploration: T[] } {
  const followed: T[] = [];
  const exploration: T[] = [];
  for (const s of scored) {
    if (s.item.authorId === userCtx.userId) {
      // Self-content goes to followed (it's not "exploration").
      followed.push(s);
    } else if (userCtx.followedAuthorIds.has(s.item.authorId)) {
      followed.push(s);
    } else {
      exploration.push(s);
    }
  }
  // Cap the exploration bucket at explorationRatio * total.
  const maxExploration = Math.floor(scored.length * explorationRatio);
  return {
    followed,
    exploration: exploration.slice(0, maxExploration),
  };
}
