/**
 * User Interest Profile Service
 * =================================
 *
 * This module provides the PRIMARY interface for reading a user's
 * recommendation profile. It aggregates:
 *
 *   1. TOPIC interests (long-term) — from UserInterest table, with recency decay
 *   2. AUTHOR affinities — derived from ContentInteraction history
 *   3. LANGUAGE preferences — derived from the languages of interacted content
 *   4. SHORT-TERM (session) interests — from recent interactions in the last 30 min
 *
 * The profile is computed on-demand (not pre-materialized) using efficient
 * batch queries. Results are cached in-memory for 60 seconds per user to
 * avoid recomputing on every feed request.
 *
 * RECENCY DECAY (spec §12 + §13):
 *   Old interactions have less influence than recent ones. We apply an
 *   exponential decay factor based on the interaction's age:
 *     effectiveWeight = rawDelta × 2^(-ageDays / halfLifeDays)
 *   where halfLifeDays is admin-configurable (default 30). This means:
 *     - 0 days old → full weight (1.0)
 *     - 30 days old → half weight (0.5)
 *     - 60 days old → quarter weight (0.25)
 *     - 180 days old → ~3% weight
 *
 * This module does NOT modify the feed ordering — it only PROVIDES the
 * profile data that the feed ranker (Phase 2) will consume.
 */

import { db } from "@/lib/database";
import { getSettingNumber } from "@/lib/settings";
import { detectLanguage, extractKeywords } from "@/lib/articles/related";

// ── Types ───────────────────────────────────────────────────────────────────

export interface TopicInterest {
  topicSlug: string;
  topicName: string;
  /** The stored score (0.0-1.0) from UserInterest. */
  rawScore: number;
  /** The decayed score — reduced based on how recently the topic was interacted with. */
  effectiveScore: number;
  /** When the user last interacted with this topic. */
  lastInteractionAt: string;
}

export interface AuthorAffinity {
  authorId: string;
  authorFullName: string;
  authorUsername: string;
  /** 0.0-1.0 — how much the user interacts with this author's content. */
  score: number;
  /** Number of interactions with this author. */
  interactionCount: number;
}

export interface LanguagePreference {
  language: string;
  /** 0.0-1.0 — proportion of the user's interactions in this language. */
  score: number;
  interactionCount: number;
}

export interface SessionInterest {
  topicSlug: string;
  /** 0.0-1.0 — temporary session-level interest score. */
  score: number;
  interactionCount: number;
}

export interface UserInterestProfile {
  userId: string;
  /** Long-term topic interests (decayed). Sorted by effectiveScore desc. */
  topics: TopicInterest[];
  /** Author affinities (derived from interaction history). Sorted by score desc. */
  authors: AuthorAffinity[];
  /** Language preferences (derived from interacted content). */
  languages: LanguagePreference[];
  /** Short-term (session) interests — last 30 minutes. Reset on new session. */
  shortTermTopics: SessionInterest[];
  /** Total interaction count (all time). */
  totalInteractions: number;
  /** Whether the user has completed onboarding interest selection. */
  onboardingCompleted: boolean;
  /** Topics the user explicitly marked "not interested". */
  notInterestedTopics: string[];
  /**
   * Content-type affinity (spec §9 — Content-Type Affinity).
   *
   * Derived from the same `recentInteractions` data already fetched for author
   * affinity — NO additional DB query. Counts positive interactions per
   * contentType (post vs article), normalizes to [0, 1] each.
   *
   *   - score = positiveInteractionsForType / max(positiveInteractionsForAnyType, 1)
   *   - When the user has 0 interactions, both scores are 0.5 (neutral).
   *
   * Used by the ranker to give a small boost to the user's preferred content
   * type (without making the feed monolithic — the diversity penalty + the
   * 5-bucket mix keep the feed varied).
   *
   * Phase 1 Personalized Feed — ADDITIVE field. Default neutral when absent.
   */
  contentTypeAffinity: {
    /** 0.0-1.0 — proportion of the user's positive interactions on POSTS. */
    post: number;
    /** 0.0-1.0 — proportion of the user's positive interactions on ARTICLES. */
    article: number;
  };
  /** When the profile was last computed (for caching). */
  computedAt: string;
}

// ── In-memory cache ────────────────────────────────────────────────────────
//
// Cache the computed profile for 60 seconds per user. This avoids
// recomputing the profile on every feed request (which would be expensive
// — 3-4 queries per computation). The cache is module-level + per-user.
//
// The cache is cleared when:
//   - The TTL expires (60s).
//   - A new interaction is tracked (the trackInteraction path invalidates
//     the cache for that user — see the invalidateProfileCache helper).
const PROFILE_CACHE_TTL_MS = 60 * 1000; // 60 seconds
const profileCache = new Map<string, { profile: UserInterestProfile; expiresAt: number }>();

/**
 * Invalidate the cached profile for a user. Called by trackInteraction
 * after a new interaction is recorded, so the next profile read reflects
 * the new data.
 */
export function invalidateProfileCache(userId: string): void {
  profileCache.delete(userId);
}

/**
 * Invalidate ALL cached profiles. Used by admin "reset recommendation
 * data" operations.
 */
export function invalidateAllProfileCaches(): void {
  profileCache.clear();
}

// ── Recency decay ──────────────────────────────────────────────────────────

/**
 * Compute the recency decay factor for an interaction of a given age.
 *
 * Uses exponential decay: factor = 2^(-ageDays / halfLifeDays)
 *
 * With halfLifeDays=30 (default):
 *   - 0 days old → 1.0 (full weight)
 *   - 30 days old → 0.5 (half weight)
 *   - 60 days old → 0.25
 *   - 90 days old → 0.125
 *   - 180 days old → ~0.03
 *
 * @param ageDays - how many days ago the interaction occurred.
 * @param halfLifeDays - the half-life (admin-configurable, default 30).
 * @returns a factor in [0, 1].
 */
export function recencyDecayFactor(ageDays: number, halfLifeDays: number): number {
  if (ageDays <= 0) return 1.0;
  if (halfLifeDays <= 0) return 1.0; // no decay
  return Math.pow(2, -ageDays / halfLifeDays);
}

// ── Main entry point ───────────────────────────────────────────────────────

/**
 * Get the user's complete interest profile.
 *
 * This is the PRIMARY function the feed ranker (Phase 2) will call to
 * get the user's recommendation profile. It aggregates:
 *   - Topic interests (from UserInterest table, with recency decay applied)
 *   - Author affinities (derived from ContentInteraction history)
 *   - Language preferences (derived from interacted content's language)
 *   - Short-term session interests (last 30 minutes)
 *
 * PERFORMANCE:
 *   - 4 batch queries (UserInterest, ContentInteraction for authors,
 *     ContentInteraction for languages, ContentInteraction for session).
 *   - Results cached 60 seconds per user.
 *   - Total queries: 4 (plus 1 for the RecommendationProfile metadata).
 *
 * @param userId - the user whose profile to fetch.
 * @returns the complete profile. Empty arrays when the user has no
 *          interactions (cold start).
 */
export async function getUserInterestProfile(
  userId: string,
): Promise<UserInterestProfile> {
  // Check cache first.
  const cached = profileCache.get(userId);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.profile;
  }

  // Load the half-life setting (cached 30s via getSettingNumber).
  const halfLifeDays = (await getSettingNumber("interest.recency_decay_days")) ?? 30;
  const now = new Date();

  // ── 1. Fetch topic interests (long-term) ────────────────────────────
  // UserInterest stores the raw score. We apply recency decay based on
  // updatedAt (the last time the score was modified by an interaction).
  const interestRows = await db.userInterest.findMany({
    where: { userId, score: { gt: 0 } },
    include: {
      topic: { select: { slug: true, name: true } },
    },
    orderBy: { score: "desc" },
    take: 50, // top 50 topics — enough for the feed ranker
  }).catch(() => []);

  const topics: TopicInterest[] = interestRows.map((row) => {
    const ageDays = (now.getTime() - row.updatedAt.getTime()) / (1000 * 60 * 60 * 24);
    const decay = recencyDecayFactor(ageDays, halfLifeDays);
    return {
      topicSlug: row.topic.slug,
      topicName: row.topic.name,
      rawScore: row.score,
      effectiveScore: row.score * decay,
      lastInteractionAt: row.updatedAt.toISOString(),
    };
  });

  // ── 2. Fetch author affinities ──────────────────────────────────────
  // Derive from ContentInteraction history. We count interactions per
  // content author + apply recency decay. The "score" is the sum of
  // decayed interaction weights, normalized to [0, 1].
  //
  // We fetch the last 200 interactions (enough to capture the user's
  // recent author preferences without being too expensive).
  const recentInteractions = await db.contentInteraction.findMany({
    where: {
      userId,
      // Only positive interactions count toward author affinity.
      action: { in: ["like", "comment", "share", "save", "follow", "read", "read_long", "video_watch", "video_complete"] },
    },
    orderBy: { createdAt: "desc" },
    take: 200,
    select: {
      contentId: true,
      contentType: true,
      createdAt: true,
      action: true,
    },
  }).catch(() => []);

  // Build a map of authorId → { count, decayedScore }.
  // We need to resolve the authorId from the contentId. This requires
  // looking up the Post/Article tables. To avoid N+1, we batch by
  // content type.
  const postIds = recentInteractions
    .filter((i) => i.contentType === "post")
    .map((i) => i.contentId);
  const articleIds = recentInteractions
    .filter((i) => i.contentType === "article")
    .map((i) => i.contentId);

  const [posts, articles] = await Promise.all([
    postIds.length > 0
      ? db.post.findMany({
          where: { id: { in: postIds } },
          select: { id: true, authorId: true, author: { select: { fullName: true, username: true } } },
        }).catch(() => [])
      : [],
    articleIds.length > 0
      ? db.article.findMany({
          where: { id: { in: articleIds } },
          select: { id: true, authorId: true, author: { select: { fullName: true, username: true } } },
        }).catch(() => [])
      : [],
  ]);

  const postAuthorMap = new Map<string, typeof posts[number]>(posts.map((p) => [p.id, p] as const));
  const articleAuthorMap = new Map<string, typeof articles[number]>(articles.map((a) => [a.id, a] as const));

  // Aggregate author affinities with recency-weighted scoring.
  const authorStats = new Map<string, { count: number; decayedScore: number; fullName: string; username: string }>();
  for (const interaction of recentInteractions) {
    let authorId: string | null = null;
    let fullName = "";
    let username = "";
    if (interaction.contentType === "post") {
      const post = postAuthorMap.get(interaction.contentId);
      if (post) {
        authorId = post.authorId;
        fullName = post.author.fullName;
        username = post.author.username;
      }
    } else if (interaction.contentType === "article") {
      const article = articleAuthorMap.get(interaction.contentId);
      if (article) {
        authorId = article.authorId;
        fullName = article.author.fullName;
        username = article.author.username;
      }
    }
    if (!authorId) continue;

    const ageDays = (now.getTime() - interaction.createdAt.getTime()) / (1000 * 60 * 60 * 24);
    const decay = recencyDecayFactor(ageDays, halfLifeDays);
    const stats = authorStats.get(authorId) ?? { count: 0, decayedScore: 0, fullName, username };
    stats.count += 1;
    stats.decayedScore += decay;
    stats.fullName = fullName;
    stats.username = username;
    authorStats.set(authorId, stats);
  }

  // Normalize author scores to [0, 1] — divide by the max decayedScore.
  const maxAuthorScore = Math.max(1, ...[...authorStats.values()].map((s) => s.decayedScore));
  const authors: AuthorAffinity[] = [...authorStats.entries()]
    .map(([authorId, stats]) => ({
      authorId,
      authorFullName: stats.fullName,
      authorUsername: stats.username,
      score: stats.decayedScore / maxAuthorScore,
      interactionCount: stats.count,
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 20); // top 20 authors

  // ── 3. Fetch language preferences ───────────────────────────────────
  // Derive from the content the user interacted with. We detect the
  // language of each interacted post/article's title + content prefix,
  // then aggregate by language.
  const languageCounts = new Map<string, number>();
  for (const post of posts) {
    // We need the title/content to detect language — re-fetch with text fields.
    // This is a small query (max 200 IDs) — acceptable.
  }
  // Actually, to detect language we need the text. Let's fetch the text
  // for the interacted posts + articles in one batch.
  const [postsWithText, articlesWithText] = await Promise.all([
    postIds.length > 0
      ? db.post.findMany({
          where: { id: { in: postIds } },
          select: { id: true, content: true },
        }).catch(() => [])
      : [],
    articleIds.length > 0
      ? db.article.findMany({
          where: { id: { in: articleIds } },
          select: { id: true, title: true, content: true },
        }).catch(() => [])
      : [],
  ]);

  const postTextMap = new Map<string, string>(postsWithText.map((p) => [p.id, p.content] as const));
  const articleTextMap = new Map<string, string>(articlesWithText.map((a) => [a.id, `${a.title} ${a.content.slice(0, 500)}`] as const));

  for (const interaction of recentInteractions) {
    let text = "";
    if (interaction.contentType === "post") {
      text = postTextMap.get(interaction.contentId) ?? "";
    } else if (interaction.contentType === "article") {
      text = articleTextMap.get(interaction.contentId) ?? "";
    }
    if (text) {
      const lang = detectLanguage(text);
      languageCounts.set(lang, (languageCounts.get(lang) ?? 0) + 1);
    }
  }

  const totalLanguageInteractions = [...languageCounts.values()].reduce((a, b) => a + b, 0);
  const languages: LanguagePreference[] = [...languageCounts.entries()]
    .map(([language, count]) => ({
      language,
      score: totalLanguageInteractions > 0 ? count / totalLanguageInteractions : 0,
      interactionCount: count,
    }))
    .sort((a, b) => b.score - a.score);

  // ── 4. Fetch short-term (session) interests ─────────────────────────
  // "Session" = last 30 minutes. We count topic-tagged interactions
  // in this window + normalize to [0, 1].
  const sessionWindow = new Date(Date.now() - 30 * 60 * 1000);
  const sessionInteractions = await db.contentInteraction.findMany({
    where: {
      userId,
      createdAt: { gte: sessionWindow },
      topicId: { not: null },
    },
    select: {
      topicId: true,
      topic: { select: { slug: true } },
      action: true,
    },
  }).catch(() => []);

  const sessionTopicCounts = new Map<string, { count: number; score: number }>();
  for (const si of sessionInteractions) {
    if (!si.topic) continue;
    const slug = si.topic.slug;
    const stats = sessionTopicCounts.get(slug) ?? { count: 0, score: 0 };
    stats.count += 1;
    // Positive actions add, negative subtract.
    if (["like", "comment", "share", "save", "follow", "read", "read_long", "video_watch", "video_complete"].includes(si.action)) {
      stats.score += 1;
    } else if (["skip", "not_interested", "hide", "unfollow"].includes(si.action)) {
      stats.score -= 1;
    }
    sessionTopicCounts.set(slug, stats);
  }

  const maxSessionScore = Math.max(1, ...[...sessionTopicCounts.values()].map((s) => Math.abs(s.score)));
  const shortTermTopics: SessionInterest[] = [...sessionTopicCounts.entries()]
    .map(([topicSlug, stats]) => ({
      topicSlug,
      score: Math.max(0, stats.score / maxSessionScore), // clamp negatives to 0
      interactionCount: stats.count,
    }))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 10); // top 10 session topics

  // ── 5. Fetch recommendation profile metadata ────────────────────────
  const profile = await db.recommendationProfile.findUnique({
    where: { userId },
    select: { onboardingCompleted: true, notInterestedTopics: true, interactionCount: true },
  }).catch(() => null);

  let notInterestedTopics: string[] = [];
  if (profile?.notInterestedTopics) {
    try {
      notInterestedTopics = JSON.parse(profile.notInterestedTopics);
    } catch {
      // invalid JSON — ignore
    }
  }

  // ── Phase 1: Content-type affinity (spec §9) ──────────────────────────
  // Computed from the SAME `recentInteractions` data already fetched above
  // for author affinity — NO additional DB query. We count positive
  // interactions by contentType (post | article), then normalize to [0, 1].
  //
  // The normalization is RELATIVE: each type's score is its share of the
  // user's total positive interactions. So a user who interacts with 80%
  // posts + 20% articles gets post=0.8, article=0.2. The ranker then gives
  // a small boost to the user's preferred type.
  //
  // When the user has 0 positive interactions (cold start), both scores
  // are 0.5 (neutral — no preference).
  let postInteractions = 0;
  let articleInteractions = 0;
  for (const interaction of recentInteractions) {
    if (interaction.contentType === "post") postInteractions++;
    else if (interaction.contentType === "article") articleInteractions++;
  }
  const totalPositiveInteractions = postInteractions + articleInteractions;
  const contentTypeAffinity = totalPositiveInteractions > 0
    ? {
        post: postInteractions / totalPositiveInteractions,
        article: articleInteractions / totalPositiveInteractions,
      }
    : { post: 0.5, article: 0.5 }; // neutral default — cold start

  const result: UserInterestProfile = {
    userId,
    topics,
    authors,
    languages,
    shortTermTopics,
    totalInteractions: profile?.interactionCount ?? 0,
    onboardingCompleted: profile?.onboardingCompleted ?? false,
    notInterestedTopics,
    contentTypeAffinity,
    computedAt: now.toISOString(),
  };

  // Cache the result.
  profileCache.set(userId, { profile: result, expiresAt: Date.now() + PROFILE_CACHE_TTL_MS });

  return result;
}

/**
 * Get a lightweight summary of the user's top interests — for the admin
 * debug panel. Returns only the top 10 topics + top 5 authors + top 3
 * languages (enough for a quick overview without fetching the full profile).
 */
export async function getUserInterestSummary(userId: string): Promise<{
  topTopics: { topic: string; score: number }[];
  topAuthors: { author: string; score: number }[];
  topLanguages: { language: string; score: number }[];
  totalInteractions: number;
}> {
  const profile = await getUserInterestProfile(userId);
  return {
    topTopics: profile.topics.slice(0, 10).map((t) => ({
      topic: t.topicName,
      score: Number(t.effectiveScore.toFixed(3)),
    })),
    topAuthors: profile.authors.slice(0, 5).map((a) => ({
      author: a.authorFullName,
      score: Number(a.score.toFixed(3)),
    })),
    topLanguages: profile.languages.slice(0, 3).map((l) => ({
      language: l.language,
      score: Number(l.score.toFixed(3)),
    })),
    totalInteractions: profile.totalInteractions,
  };
}
