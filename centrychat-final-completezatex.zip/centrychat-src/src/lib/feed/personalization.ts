/**
 * Personalized Feed Mix + Interest Learning Helpers
 * ==================================================
 *
 * Pure functions for the CentryChat personalized feed (spec §1-§37). No DB
 * access inside these helpers — the caller fetches the data + passes it in.
 *
 * THREE CONCERNS:
 *
 * 1. FEED MIX BUCKETS (spec §15) — given the admin-configured mix weights
 *    (following/recommended/fresh/trending/exploration) + whether the user
 *    has any follows, compute the per-bucket POOL SIZE (how many candidates
 *    to fetch from each source). Handles the COLD START case where following=0
 *    → that bucket collapses and the remaining weights are re-normalized.
 *
 * 2. INTEREST MATCH SCORING (spec §5, §6, §10) — given a candidate post +
 *    the user's interest profile + the candidate's author's topics, compute
 *    a "personalization score" indicating how well the candidate matches
 *    the user's interests. Used as an ADDITIVE component in the unified
 *    ranking engine (alongside recency, engagement, etc.).
 *
 * 3. INTEREST DELTA COMPUTATION (spec §6, §7) — given an interaction type
 *    (view/like/comment/share/skip/not_interested/etc.), return the delta
 *    to apply to the user's interest score for that topic. Reads the
 *    admin-configured weights via getSettingNumber (cached 30s).
 *
 * NO FAKE DATA (spec §37): the helpers never invent interests or scores.
 * If the user has no interest profile, interestMatch = 0 (the candidate
 * is ranked purely on recency/engagement/trending signals — exactly the
 * cold-start behavior the spec requires).
 *
 * NO DB CHANGES: relies on the existing ContentTopic + UserInterest models
 * (already in prisma/schema.prisma). The helpers only READ these tables +
 * write small delta updates via the existing rule-based engine.
 */

import { getSettingNumber } from "@/lib/settings";

// ── Types ─────────────────────────────────────────────────────────────────

/**
 * The five feed-mix buckets (spec §15).
 *
 *   - following    : content from authors the user follows
 *   - recommended  : content matching the user's interests (personalization)
 *   - fresh        : brand-new content (published in last 1h)
 *   - trending     : high-velocity content (high engagement-per-hour)
 *   - exploration  : random content from non-followed authors (preserves
 *                    discovery even when the user has a strong interest profile)
 */
export type FeedMixBucket =
  | "following"
  | "recommended"
  | "fresh"
  | "trending"
  | "exploration";

export interface FeedMixWeights {
  following: number;
  recommended: number;
  fresh: number;
  trending: number;
  exploration: number;
}

/**
 * Per-bucket pool sizes — how many candidates to fetch from each source.
 * Sum = poolSize. The caller fetches each bucket via a separate Prisma query,
 * then merges them into a single candidate list for the unified ranker.
 */
export interface FeedMixBuckets {
  following: number;
  recommended: number;
  fresh: number;
  trending: number;
  exploration: number;
}

// ── Feed Mix Helpers ──────────────────────────────────────────────────────

/**
 * Default feed-mix weights (spec §15 example ratios).
 *
 *   following   : 25%
 *   recommended : 35%
 *   fresh       : 20%
 *   trending    : 15%
 *   exploration :  5%
 *
 * These match the spec example. Admins can override via the
 * `feed.mix.*` PlatformSetting keys (loaded via loadFeedMixWeights).
 */
export const DEFAULT_FEED_MIX_WEIGHTS: FeedMixWeights = {
  following: 0.25,
  recommended: 0.35,
  fresh: 0.20,
  trending: 0.15,
  exploration: 0.05,
};

/**
 * Load the admin-configured feed-mix weights (cached 30s via getSettingNumber).
 *
 * Falls back to DEFAULT_FEED_MIX_WEIGHTS when a setting is missing or invalid.
 * Never throws — invalid values silently fall back (defensive).
 */
export async function loadFeedMixWeights(): Promise<FeedMixWeights> {
  const [
    following,
    recommended,
    fresh,
    trending,
    exploration,
  ] = await Promise.all([
    getSettingNumber("feed.mix.following"),
    getSettingNumber("feed.mix.recommended"),
    getSettingNumber("feed.mix.fresh"),
    getSettingNumber("feed.mix.trending"),
    getSettingNumber("feed.mix.exploration"),
  ]);

  return {
    following: following ?? DEFAULT_FEED_MIX_WEIGHTS.following,
    recommended: recommended ?? DEFAULT_FEED_MIX_WEIGHTS.recommended,
    fresh: fresh ?? DEFAULT_FEED_MIX_WEIGHTS.fresh,
    trending: trending ?? DEFAULT_FEED_MIX_WEIGHTS.trending,
    exploration: exploration ?? DEFAULT_FEED_MIX_WEIGHTS.exploration,
  };
}

/**
 * Compute the per-bucket pool sizes given the total pool size + the mix
 * weights + whether the user has any follows.
 *
 * COLD START (spec §1, §16, §34):
 *   When hasFollows = false (new user, no follows), the `following` bucket
 *   is set to 0 and the remaining weights are re-normalized so they still
 *   sum to 1.0 of the poolSize. The result: the new user gets a feed filled
 *   with recommended + fresh + trending + exploration content — NO empty
 *   state, NO "follow someone first" wall.
 *
 *   When hasFollows = true, the weights are used as-is (normalized if they
 *   don't sum to 1.0 — the spec said ratios, not absolute values).
 *
 * Each bucket gets at least 0 candidates (we use Math.floor + distribute
 * the remainder to the highest-weighted buckets to avoid wasting pool slots).
 */
export function computeFeedMixBuckets(
  poolSize: number,
  weights: FeedMixWeights,
  hasFollows: boolean
): FeedMixBuckets {
  // Step 1: handle cold-start — drop the following bucket, re-normalize.
  const effectiveWeights: FeedMixWeights = { ...weights };
  if (!hasFollows) {
    effectiveWeights.following = 0;
  }

  const total =
    effectiveWeights.following +
    effectiveWeights.recommended +
    effectiveWeights.fresh +
    effectiveWeights.trending +
    effectiveWeights.exploration;

  // Defensive: if all weights are 0 (admin misconfiguration), fall back to
  // an even split across all 5 buckets so the feed is never empty.
  if (total <= 0) {
    const even = poolSize / 5;
    return {
      following: Math.floor(even),
      recommended: Math.floor(even),
      fresh: Math.floor(even),
      trending: Math.floor(even),
      exploration: poolSize - 4 * Math.floor(even),
    };
  }

  // Step 2: compute raw sizes (may have fractional remainder).
  const raw: FeedMixBuckets = {
    following: (effectiveWeights.following / total) * poolSize,
    recommended: (effectiveWeights.recommended / total) * poolSize,
    fresh: (effectiveWeights.fresh / total) * poolSize,
    trending: (effectiveWeights.trending / total) * poolSize,
    exploration: (effectiveWeights.exploration / total) * poolSize,
  };

  // Step 3: floor each + distribute the remainder to the highest-weighted
  // buckets. This ensures we use the FULL poolSize (no wasted slots).
  const floored: FeedMixBuckets = {
    following: Math.floor(raw.following),
    recommended: Math.floor(raw.recommended),
    fresh: Math.floor(raw.fresh),
    trending: Math.floor(raw.trending),
    exploration: Math.floor(raw.exploration),
  };

  const used =
    floored.following +
    floored.recommended +
    floored.fresh +
    floored.trending +
    floored.exploration;
  let remaining = poolSize - used;

  // Sort buckets by their raw fractional remainder (largest first) + give
  // each one +1 until the remainder is exhausted. This minimizes the "off-by-
  // one" rounding error — the buckets with the closest-to-next-integer sizes
  // get the leftover slots.
  const buckets: FeedMixBucket[] = [
    "following",
    "recommended",
    "fresh",
    "trending",
    "exploration",
  ];
  const order = buckets
    .filter((b) => (effectiveWeights as Record<FeedMixBucket, number>)[b] > 0)
    .sort((a, b) => {
      const ra = (raw as Record<FeedMixBucket, number>)[a];
      const rb = (raw as Record<FeedMixBucket, number>)[b];
      // Sort by the fractional remainder (descending) — buckets with the
      // largest remainder get the leftover slots first.
      return (rb % 1) - (ra % 1);
    });

  for (const b of order) {
    if (remaining <= 0) break;
    (floored as Record<FeedMixBucket, number>)[b] += 1;
    remaining -= 1;
  }

  // Final safety: if there's still leftover (shouldn't happen, but defensive),
  // dump it all into the recommended bucket — that's the most "personalized"
  // bucket so it's the safest default.
  if (remaining > 0) {
    floored.recommended += remaining;
  }

  return floored;
}

// ── Interest Match Scoring ────────────────────────────────────────────────

/**
 * A user's interest profile — a map of topic slug → score (0-1).
 *
 * Loaded from the UserInterest table by the caller (the feed endpoint).
 * Higher score = stronger interest. Topics not in the map = no interest
 * (treated as 0 for matching purposes).
 */
export type InterestProfile = Map<string, number>;

/**
 * Compute the "interest match" score for a candidate post given the user's
 * interest profile.
 *
 * Formula:
 *   - For each topic associated with the candidate's author:
 *       matchScore += userInterest[topicSlug] ?? 0
 *   - Normalize: divide by the number of topics (so a post with many topics
 *     doesn't artificially inflate).
 *   - Scale: multiply by `weight` (the personalization weight, default ~30).
 *
 * If the candidate has NO topics (most posts today — the topic system is
 * nascent), returns 0. The candidate is then ranked purely on recency,
 * engagement, trending, freshness — which is exactly the correct cold-start
 * behavior (spec §4 — "If new user and no sufficient data: use Trending +
 * Fresh + Popular + Diverse Content").
 *
 * If the USER has no interest profile, also returns 0 (same cold-start path).
 *
 * SECURITY / PRIVACY (spec §27):
 *   - This function is pure — it doesn't expose the user's interest profile.
 *   - The match score is INTERNAL to the ranking pipeline. The returned
 *     `reason` string (when transparency is enabled) only mentions the
 *     TOP topic that matched — never the full profile.
 *
 * @param candidateTopics - slugs of topics associated with the candidate
 *   (currently derived from the author's most-engaged topics, since posts
 *    don't have explicit topic tags yet — see getAuthorTopicsForFeed helper).
 * @param userProfile - the user's interest profile.
 * @param weight - the personalization weight (loaded from admin settings).
 * @param enableTransparency - if true, include a `reason` string for the
 *   explainability feature (spec §27). Always null when transparency is off.
 */
export function calculateInterestMatch(
  candidateTopics: string[],
  userProfile: InterestProfile,
  weight: number,
  enableTransparency: boolean
): { score: number; reason: string | null } {
  if (
    candidateTopics.length === 0 ||
    userProfile.size === 0 ||
    weight === 0
  ) {
    return { score: 0, reason: null };
  }

  let totalMatch = 0;
  let topTopic: string | null = null;
  let topScore = 0;

  for (const slug of candidateTopics) {
    const userScore = userProfile.get(slug) ?? 0;
    totalMatch += userScore;
    if (userScore > topScore) {
      topScore = userScore;
      topTopic = slug;
    }
  }

  if (totalMatch <= 0) {
    return { score: 0, reason: null };
  }

  // Normalize by topic count to avoid inflation.
  const normalized = totalMatch / candidateTopics.length;
  const score = normalized * weight;

  const reason =
    enableTransparency && topTopic
      ? `matches your interest in ${topTopic}`
      : null;

  return { score, reason };
}

// ── Interest Delta Computation ────────────────────────────────────────────

/**
 * Map interaction action strings to the admin setting key for the interest
 * delta. Returns null for actions that don't affect interests (e.g. the
 * system tracks `impression` + `click` for analytics, but they don't move
 * the interest score — only explicit user actions do, per spec §6 + §7).
 */
const ACTION_TO_SETTING_KEY: Record<string, string | null> = {
  view: "interest.weight.view",
  open: "interest.weight.open",
  read: "interest.weight.read",
  read_long: "interest.weight.read_long",
  like: "interest.weight.like",
  comment: "interest.weight.comment",
  share: "interest.weight.share",
  save: "interest.weight.save",
  follow: "interest.weight.follow_creator",
  profile_visit: "interest.weight.profile_visit",
  video_watch: "interest.weight.video_watch",
  video_complete: "interest.weight.video_complete",
  skip: "interest.weight.skip",
  not_interested: "interest.weight.not_interested",
  hide: "interest.weight.hide",
  unfollow: "interest.weight.unfollow_creator",
  // Analytics-only events — do NOT affect the interest score.
  impression: null,
  click: null,
};

/**
 * Get the interest delta for a given action, loaded from admin settings.
 *
 * Returns 0 for actions that don't affect interests. Negative deltas
 * reduce the score (skip, not_interested, unfollow). Positive deltas
 * increase it (view, like, comment, share, follow, read_long).
 *
 * The caller (the rule-based engine's trackInteraction) applies this delta
 * to the UserInterest.score column, clamped to [decayFloor, 1.0] where
 * decayFloor = the admin-configured `interest.decay_floor` (default 0.05).
 * The floor preserves a small residual for re-exploration (spec §17).
 *
 * @param action - one of: view, like, comment, share, save, follow,
 *   profile_visit, skip, not_interested, unfollow, read_long,
 *   impression, click
 */
export async function getInterestDeltaForAction(
  action: string
): Promise<{ delta: number; appliesToInterests: boolean }> {
  const key = ACTION_TO_SETTING_KEY[action];
  if (!key) {
    return { delta: 0, appliesToInterests: false };
  }
  const delta = (await getSettingNumber(key)) ?? 0;
  return { delta, appliesToInterests: true };
}

/**
 * Clamp a new interest score to [decayFloor, 1.0].
 *
 * The decay floor is admin-configurable (default 0.05). It prevents a
 * topic's score from ever reaching 0 — even after explicit "not interested"
 * clicks, a small residual is kept so the topic can still occasionally
 * surface for re-exploration (spec §17 — "don't delete entirely").
 *
 * @param newScore - the raw new score (delta already applied).
 * @param decayFloor - the admin-configured floor (loaded by the caller).
 */
export function clampInterestScore(
  newScore: number,
  decayFloor: number
): number {
  const floor = Math.max(0, decayFloor);
  return Math.max(floor, Math.min(1.0, newScore));
}

// ── Author Topic Inference (for personalization) ──────────────────────────

/**
 * Lightweight in-memory cache for author → topics mapping.
 *
 * Used by the feed endpoint to attach inferred topics to each candidate post
 * (since posts don't have explicit topic tags yet — the topic system is
 * nascent). The cache TTL is 5 minutes — long enough to amortize across a
 * single feed page (which fetches ~60-100 candidates) but short enough to
 * pick up new interactions.
 *
 * The cache is module-level + per-request (cleared on hot reload in dev).
 * It does NOT survive across server instances — that's fine because the
 * feed endpoint re-computes it cheaply on cache miss.
 */
const authorTopicsCache = new Map<
  string,
  { topics: string[]; expiresAt: number }
>();
const AUTHOR_TOPICS_CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

/**
 * Get the inferred topics for a list of authors.
 *
 * Currently infers from the authors' most-engaged ContentInteraction rows
 * (the topics they posted about most). This is a PROXY for "what topics
 * does this author write about" — when the topic system matures and posts
 * get explicit topic tags, this function should be replaced with a direct
 * lookup on the Post → ContentTopic relation.
 *
 * Returns a Map<authorId, string[]> (empty array for authors with no
 * interactions). The topics are slugs (URL-safe lowercase strings).
 *
 * PERFORMANCE:
 *   - ONE batched query (ContentInteraction.groupBy) for all authors at once.
 *   - Results cached 5 minutes per authorId.
 *   - The caller should pass a UNIQUE list of authorIds (dedupe first).
 */
export async function getAuthorTopicsBatch(
  authorIds: string[],
  fetchInteractions: (authorIds: string[]) => Promise<
    Array<{ userId: string; topicSlug: string; _count: number }>
  >
): Promise<Map<string, string[]>> {
  const out = new Map<string, string[]>();
  const now = Date.now();
  const missing: string[] = [];

  for (const id of authorIds) {
    const cached = authorTopicsCache.get(id);
    if (cached && cached.expiresAt > now) {
      out.set(id, cached.topics);
    } else {
      missing.push(id);
    }
  }

  if (missing.length === 0) {
    return out;
  }

  // Fetch interactions for all missing authors in ONE batch.
  const rows = await fetchInteractions(missing);
  const byAuthor = new Map<string, Array<{ topicSlug: string; _count: number }>>();
  for (const r of rows) {
    let list = byAuthor.get(r.userId);
    if (!list) {
      list = [];
      byAuthor.set(r.userId, list);
    }
    list.push({ topicSlug: r.topicSlug, _count: r._count });
  }

  // For each missing author, take their top 3 most-engaged topics.
  for (const id of missing) {
    const list = byAuthor.get(id) ?? [];
    list.sort((a, b) => b._count - a._count);
    const top3 = list.slice(0, 3).map((x) => x.topicSlug);
    out.set(id, top3);
    authorTopicsCache.set(id, {
      topics: top3,
      expiresAt: now + AUTHOR_TOPICS_CACHE_TTL_MS,
    });
  }

  return out;
}

/**
 * Clear the author-topics cache. Used by tests + admin "reset recommendation
 * data" operations to force a fresh fetch on the next feed request.
 */
export function clearAuthorTopicsCache(): void {
  authorTopicsCache.clear();
}
