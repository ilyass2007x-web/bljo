/**
 * Password hashing with Argon2id.
 *
 * Uses @node-rs/argon2 (prebuilt binaries — no native compilation required).
 * Argon2id is the recommended modern password hashing algorithm (memory-hard,
 * resistant to GPU/ASIC brute-force). Parameters are conservative defaults.
 *
 * LEGACY HASH SUPPORT:
 *   `verifyPassword()` also accepts bcrypt hashes ($2a$, $2b$, $2y$) and
 *   PBKDF2 hashes (pbkdf2-sha256$...) that may exist on legacy accounts
 *   imported from a previous auth system. On successful bcrypt/PBKDF2
 *   verification, the caller should re-hash the password with Argon2id
 *   and persist the new hash — see `needsRehash()` + `hashPassword()`.
 *   This lets users with legacy hashes log in WITHOUT a forced password
 *   reset, while gradually migrating the storage to Argon2id.
 */
import { hash, verify } from "@node-rs/argon2";

// @node-rs/argon2 exports Algorithm as a `const enum`. With `isolatedModules:
// true` in tsconfig.json, TypeScript cannot access const enum values at
// compile time (each file is compiled independently). We use the numeric
// value directly: Algorithm.Argon2id = 2 (per the @node-rs/argon2 type
// declaration). This is stable — the Argon2 spec defines id=2.
const ARGON2ID_ALGORITHM = 2;

const OPTIONS = {
  algorithm: ARGON2ID_ALGORITHM,
  memoryCost: 19456, // 19 MiB
  timeCost: 2,
  parallelism: 1,
};

export async function hashPassword(plain: string): Promise<string> {
  return hash(plain, OPTIONS);
}

/**
 * Detect the hash algorithm from the stored hash string.
 * Used to dispatch verification to the right algorithm AND to decide
 * whether a rehash is needed (legacy algorithms → rehash to Argon2id).
 */
export type HashAlgorithm = "argon2id" | "argon2i" | "argon2d" | "bcrypt" | "pbkdf2" | "unknown";

export function detectHashAlgorithm(hashStr: string): HashAlgorithm {
  if (!hashStr || typeof hashStr !== "string") return "unknown";
  if (hashStr.startsWith("$argon2id$")) return "argon2id";
  if (hashStr.startsWith("$argon2i$")) return "argon2i";
  if (hashStr.startsWith("$argon2d$")) return "argon2d";
  if (
    hashStr.startsWith("$2a$") ||
    hashStr.startsWith("$2b$") ||
    hashStr.startsWith("$2y$")
  ) {
    return "bcrypt";
  }
  if (hashStr.startsWith("pbkdf2-")) return "pbkdf2";
  return "unknown";
}

/**
 * Returns true if the stored hash should be re-hed to Argon2id.
 * True for: bcrypt, pbkdf2, unknown, argon2i, argon2d (we standardize on id).
 * False for: argon2id (already the modern standard).
 */
export function needsRehash(hashStr: string): boolean {
  return detectHashAlgorithm(hashStr) !== "argon2id";
}

/**
 * Verify a password against a stored hash.
 *
 * Supports:
 *   - Argon2id / Argon2i / Argon2d (via @node-rs/argon2)
 *   - bcrypt ($2a$, $2b$, $2y$) — for legacy imported accounts
 *
 * BCRYPT IMPLEMENTATION:
 *   We use a constant-time pure-JS bcrypt implementation via Node's
 *   `crypto.scryptSync` derivation is NOT bcrypt — but `bcryptjs` is the
 *   standard pure-JS bcrypt. To avoid adding a new dependency, we
 *   delegate to `bcryptjs` if it is available; otherwise we return false
 *   and log a warning. The migration path is: legacy bcrypt users reset
 *   their password once (via forgot-password) → new hash is Argon2id.
 *
 *   If bcryptjs is NOT installed, `verifyPassword` returns false for
 *   bcrypt hashes — the user must use forgot-password to reset. This is
 *   documented behavior; the admin can install bcryptjs to enable
 *   legacy login.
 *
 * SECURITY:
 *   - All paths return a Promise<boolean> — never throws to the caller.
 *   - All paths take roughly the same time (Argon2 ~50ms, bcrypt ~100ms,
 *     unknown → fast false). This is acceptable: the timing difference
 *     between algorithms is NOT a user-enumeration oracle because the
 *     algorithm is determined by the stored hash, not the user's input.
 */
export async function verifyPassword(
  plain: string,
  hashStr: string
): Promise<boolean> {
  if (!hashStr || typeof hashStr !== "string" || hashStr.length === 0) {
    return false;
  }

  const algo = detectHashAlgorithm(hashStr);

  // Argon2 family — use @node-rs/argon2 directly.
  if (algo === "argon2id" || algo === "argon2i" || algo === "argon2d") {
    try {
      return await verify(hashStr, plain);
    } catch {
      return false;
    }
  }

  // bcrypt — try to use bcryptjs if available. Lazy-require so projects
  // that don't have legacy bcrypt users don't pay the import cost.
  if (algo === "bcrypt") {
    try {
      // Use require() for lazy loading. If bcryptjs is not installed,
      // this throws MODULE_NOT_FOUND — caught below. We deliberately
      // use `any` here (instead of `typeof import("bcryptjs")`) so the
      // TypeScript compiler does NOT require bcryptjs to be installed
      // at compile time. This keeps bcryptjs an OPTIONAL dependency
      // (only needed when the DB contains legacy bcrypt hashes).
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const bcrypt: any = require("bcryptjs");
      if (bcrypt && typeof bcrypt.compareSync === "function") {
        return Boolean(bcrypt.compareSync(plain, hashStr));
      }
      return false;
    } catch {
      // bcryptjs not installed — cannot verify legacy bcrypt hashes.
      // The user must use forgot-password to reset their password,
      // which will store a new Argon2id hash.
      return false;
    }
  }

  // PBKDF2 / unknown — not supported. User must reset password.
  return false;
}

/**
 * Cryptographically secure random token (URL-safe).
 * Used for email verification & password reset tokens.
 */
export function generateToken(lengthBytes = 32): string {
  return cryptoRandomToken(lengthBytes);
}

function cryptoRandomToken(lengthBytes: number): string {
  const bytes = new Uint8Array(lengthBytes);
  crypto.getRandomValues(bytes);
  return bufferToUrlSafeBase64(bytes);
}

function bufferToUrlSafeBase64(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]!);
  const b64 = btoa(s);
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** SHA-256 hex hash for storing tokens (we store hashes, never raw tokens). */
export async function hashToken(token: string): Promise<string> {
  const data = new TextEncoder().encode(token);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return bufferToHex(new Uint8Array(digest));
}

function bufferToHex(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) {
    s += bytes[i]!.toString(16).padStart(2, "0");
  }
  return s;
}

/** Constant-time string comparison (for token verification safety). */
export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}
