/**
 * SSRF-safe HTTP infrastructure — shared across the platform.
 *
 * Exposes:
 *   - `ssrfSafeAgent`: an undici Agent with a pinned DNS lookup that
 *     validates every resolved IP against private/reserved ranges. The
 *     IP validated at lookup time is the SAME IP undici connects to.
 *   - `ssrfSafeFetch`: undici's own fetch (NOT the global fetch) bound
 *     to the SSRF-safe agent. The global fetch SILENTLY IGNORES the
 *     `dispatcher` option on Bun + throws on Node 24 — using undici's
 *     own fetch reliably respects `dispatcher` across all runtimes.
 *
 * USAGE:
 *   import { ssrfSafeFetch } from "@/lib/security/ssrf-agent";
 *   const res = await ssrfSafeFetch(url, { ...opts, dispatcher: ssrfSafeAgent });
 *   // OR even simpler (auto-applies the agent):
 *   const res = await ssrfSafeFetch(url, opts);
 *
 * SECURITY:
 *   - The agent's `connect.lookup` hook is called for EVERY TCP
 *     connect undici does (initial request + redirect follows).
 *   - For each resolved IP, `isPrivateIp` is called — if ANY is
 *     private, the lookup fails → fetch is aborted before TCP connect.
 *   - This closes the DNS-rebinding TOCTOU gap: an attacker can't
 *     return a public IP for our pre-check + a private IP for the
 *     actual fetch, because undici uses the IP we hand it.
 *
 * Used by:
 *   - src/lib/media/resolver.ts (article cover images, videos, og:image)
 *   - src/lib/ai-moderation/adapters/http.ts (provider endpoint fetches)
 *   - Any future server-side fetch with user/admin-controlled URLs.
 */
import { Agent, fetch as undiciFetch } from "undici";
import { promises as dns } from "node:dns";
import { isIP } from "node:net";

/**
 * Check whether an IP literal is in a private/loopback/reserved range.
 * Returns true when the IP is private (should be blocked).
 *
 * Mirrors `src/lib/media/resolver.ts#isPrivateIp` exactly — kept in
 * sync to ensure both code paths apply the same SSRF rules.
 */
export function isPrivateIp(ip: string, kind: number): boolean {
  if (kind === 4) {
    const parts = ip.split(".").map((p) => parseInt(p, 10));
    if (parts.length !== 4 || parts.some((p) => Number.isNaN(p))) return true;
    const [a, b] = parts;
    // 0.0.0.0/8          — "this network"
    if (a === 0) return true;
    // 10.0.0.0/8         — private
    if (a === 10) return true;
    // 100.64.0.0/10      — CGNAT
    if (a === 100 && b! >= 64 && b! <= 127) return true;
    // 127.0.0.0/8        — loopback
    if (a === 127) return true;
    // 169.254.0.0/16     — link-local (incl. 169.254.169.254 metadata)
    if (a === 169 && b === 254) return true;
    // 172.16.0.0/12      — private
    if (a === 172 && b! >= 16 && b! <= 31) return true;
    // 192.0.0.0/24       — IETF protocol assignments
    if (a === 192 && b === 0) return true;
    // 192.0.2.0/24       — TEST-NET-1
    if (a === 192 && b === 0 && parts[2] === 2) return true;
    // 192.168.0.0/16     — private
    if (a === 192 && b === 168) return true;
    // 198.18.0.0/15      — benchmark
    if (a === 198 && (b === 18 || b === 19)) return true;
    // 198.51.100.0/24    — TEST-NET-2
    if (a === 198 && b === 51 && parts[2] === 100) return true;
    // 203.0.113.0/24     — TEST-NET-3
    if (a === 203 && b === 0 && parts[2] === 113) return true;
    // 224.0.0.0/4        — multicast
    if (a >= 224 && a <= 239) return true;
    // 240.0.0.0/4        — reserved
    if (a >= 240) return true;
    return false;
  }
  if (kind === 6) {
    const lower = ip.toLowerCase();
    // ::1 — loopback
    if (lower === "::1") return true;
    // fc00::/7 — ULA (private)
    if (/^f[cd][0-9a-f]{2}:/.test(lower)) return true;
    // fe80::/10 — link-local
    if (/^fe[89ab][0-9a-f]:/.test(lower)) return true;
    // ::ffff:v4 — IPv4-mapped IPv6 (recurse into IPv4 check)
    const v4Mapped = lower.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (v4Mapped) {
      const v4Kind = isIP(v4Mapped[1]!);
      if (v4Kind) return isPrivateIp(v4Mapped[1]!, v4Kind);
    }
    // 2001:db8::/32 — documentation
    if (/^2001:db8:/.test(lower)) return true;
    return false;
  }
  return true; // unknown kind — block by default
}

/**
 * Custom DNS lookup hook for undici's Agent.
 *
 * Resolves the hostname via `dns.lookup` (which the OS uses for
 * getaddrinfo) + validates EVERY returned IP against `isPrivateIp`.
 * Only returns IPs that pass the check. If ALL resolved IPs are
 * private, the lookup fails → the fetch is aborted before any TCP
 * connection happens.
 *
 * This closes the DNS-rebinding TOCTOU gap: the IP we validate here is
 * the SAME IP that undici's HTTP connect() uses for the TCP connection.
 * An attacker can't return a public IP for our pre-check + a private IP
 * for the actual fetch — undici re-uses the IP we hand it via `lookup`.
 */
async function pinnedLookup(
  hostname: string,
  opts: { family?: number; all?: boolean } | undefined,
  cb: (err: NodeJS.ErrnoException | null, address: string, family: number) => void
): Promise<void> {
  try {
    const lookup = (await import("node:dns")).lookup;
    const family = opts?.family ?? 0;
    lookup(
      hostname,
      { family, all: true },
      (err: NodeJS.ErrnoException | null, addresses: Array<{ address: string; family: number }>) => {
        if (err) {
          cb(err, "", 0);
          return;
        }
        if (!addresses || addresses.length === 0) {
          cb(
            Object.assign(new Error(`No DNS records for ${hostname}`), { code: "ENOTFOUND" }),
            "",
            0
          );
          return;
        }
        // Validate EVERY returned IP. If ANY is private, reject.
        for (const a of addresses) {
          const kind = isIP(a.address);
          if (!kind) continue;
          if (isPrivateIp(a.address, kind)) {
            cb(
              Object.assign(
                new Error(`DNS pin blocked private IP for ${hostname}`),
                { code: "EPRIVATE" }
              ),
              "",
              0
            );
            return;
          }
        }
        // All IPs passed — return the first valid one. undici will connect
        // to this exact IP literal (no re-resolution).
        const first = addresses[0]!;
        cb(null, first.address, first.family);
      }
    );
  } catch (err) {
    const code =
      err && typeof err === "object" && "code" in err && typeof (err as { code?: unknown }).code === "string"
        ? (err as { code: string }).code
        : "EUNKNOWN";
    cb(
      Object.assign(err instanceof Error ? err : new Error("DNS pin lookup failed"), { code }),
      "",
      0
    );
  }
}

/**
 * Shared undici Agent that uses `pinnedLookup` for DNS resolution.
 *
 * Caching the Agent is fine — it's stateless aside from the lookup hook
 * (which is also stateless). All fetches that go through any SSRF-safe
 * fetch use this Agent via the `dispatcher` option.
 *
 * Why a module-level singleton: undici Agents are designed to be reused
 * (connection pool, TLS session cache). Creating one per fetch would
 * defeat that + cause socket churn.
 */
export const ssrfSafeAgent = new Agent({
  connect: {
    // The lookup hook is called for EVERY TCP connect undici does —
    // including the initial request + any internal redirect follows.
    lookup: pinnedLookup as never,
  },
});

/**
 * Re-export undici's fetch so callers don't need a separate import.
 * Use this in place of the global `fetch` for SSRF-safe fetches.
 */
export const ssrfSafeFetch = undiciFetch;

/**
 * Convenience: ssrfSafeFetch bound to ssrfSafeAgent. Use this when you
 * don't need to override the dispatcher (most cases).
 *
 * Example:
 *   const res = await ssrfFetch(url, { method: "GET", signal });
 *   // dispatcher is automatically set to ssrfSafeAgent.
 *
 * Returns undici's Response type (which is structurally compatible with
 * the global Response — most callers can use it interchangeably).
 */
export async function ssrfFetch(
  url: string | URL,
  init?: RequestInit & { timeoutMs?: number }
): Promise<Awaited<ReturnType<typeof undiciFetch>>> {
  const { timeoutMs, ...rest } = init ?? {};
  const controller = new AbortController();
  const timeout = timeoutMs ? setTimeout(() => controller.abort(), timeoutMs) : null;
  // Merge any existing signal with our timeout signal.
  if (rest.signal) {
    const externalSignal = rest.signal as AbortSignal;
    if (externalSignal.aborted) controller.abort();
    else externalSignal.addEventListener("abort", () => controller.abort(), { once: true });
  }
  try {
    return await undiciFetch(url as Parameters<typeof undiciFetch>[0], {
      ...rest,
      signal: controller.signal,
      dispatcher: ssrfSafeAgent,
    } as Parameters<typeof undiciFetch>[1]);
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}
