/**
 * Global Domain Blocklist — Central Security Service
 * ===================================================
 *
 * SERVER-ONLY. This is the SINGLE authoritative function for checking
 * whether a URL's domain is blocked by the admin-controlled blocklist.
 *
 * EVERY URL-accepting code path in the application calls `checkBlockedDomain(url)`:
 *   - Article cover image, video URL, content URLs
 *   - Post content URLs
 *   - Comment + reply URLs (post + article)
 *   - Profile avatar URL, bio URLs, website
 *   - Messaging URLs
 *   - The Universal Media Resolver (covers all `resolveMedia` callers)
 *
 * There is NO duplicated per-feature blocklist logic. This file is the
 * single source of truth.
 *
 * ── Security Guarantees ──────────────────────────────────────────────
 *   1. All decisions are made SERVER-SIDE. Client components never import
 *      this module (it imports `db` → Prisma → server-only).
 *   2. Domain normalization defeats bypasses:
 *        - "Example.COM" → "example.com"
 *        - "https://example.com" → "example.com"
 *        - "https://example.com:443" → "example.com"
 *        - "www.example.com" → "example.com" (leading www stripped)
 *        - "example.com." → "example.com" (trailing dot stripped)
 *   3. Subdomain matching uses SAFE suffix matching (never `includes()`):
 *        - "cdn.example.com" matches "example.com" with blockSubdomains=true
 *        - "example.com.evil.com" does NOT match "example.com"
 *        - "safeexample.com" does NOT match "example.com"
 *   4. Malformed URLs are safely rejected (returns `{ blocked: false, error: "..." }`).
 *   5. The blocklist is cached (30-second TTL) for performance. Admin
 *      changes invalidate the cache immediately.
 *
 * ── Hit Tracking ─────────────────────────────────────────────────────
 * Every time a blocked domain is detected, `recordBlockedDomainHit()`:
 *   - Creates a BlockedDomainHit row (with userId, context, attemptedUrl)
 *   - Increments the BlockedDomain.hitCount
 * Both writes are fire-and-forget (non-blocking) so the request isn't
 * slowed down. Failures are logged but never crash the request.
 */

import { db } from "@/lib/database";
import { cacheGetOrSet, getCache } from "@/lib/cache";
import { logger } from "@/lib/logging";

// ── Types ──────────────────────────────────────────────────────────────

export type BlockCheckContext =
  | "ARTICLE"
  | "POST"
  | "COMMENT"
  | "REPLY"
  | "PROFILE"
  | "MESSAGE"
  | "MEDIA"
  | "OTHER";

export interface BlockedDomainCheckResult {
  /** True if the URL's domain matches an active block rule. */
  blocked: boolean;
  /** The normalized domain that was checked (e.g. "example.com"). Null on parse error. */
  domain: string | null;
  /** The matched BlockedDomain rule (only present when blocked=true). */
  rule?: {
    id: string;
    domain: string;
    normalizedDomain: string;
    reason: string | null;
    blockSubdomains: boolean;
  };
  /** Present when the URL couldn't be parsed (malformed). NOT a block — just an error. */
  error?: string;
}

export interface BlockedDomainRule {
  id: string;
  domain: string;
  normalizedDomain: string;
  reason: string | null;
  notes: string | null;
  isActive: boolean;
  blockSubdomains: boolean;
  hitCount: number;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string | null;
}

// ── Constants ──────────────────────────────────────────────────────────

/** Cache key for the active blocklist. */
const BLOCKLIST_CACHE_KEY = "domain-blocklist:active";

/** Cache TTL (seconds). The blocklist is re-fetched at most every 30s.
 *  Admin changes invalidate immediately via `invalidateBlocklistCache()`. */
const BLOCKLIST_CACHE_TTL = 30;

/** Max length for an attempted URL (stored in BlockedDomainHit.attemptedUrl). */
const MAX_ATTEMPTED_URL_LENGTH = 2048;

// ── Domain Normalization ───────────────────────────────────────────────

/**
 * Extract the hostname from a URL string, safely.
 *
 * Handles:
 *   - Full URLs: "https://Example.COM:443/path?query=1#frag" → "example.com"
 *   - Bare domains: "Example.COM" → "example.com"
 *   - With trailing dot: "example.com." → "example.com"
 *   - With leading www: "www.example.com" → "example.com"
 *   - Punycode: "xn--example.com" → stays as-is (already ASCII)
 *
 * Defeats bypasses:
 *   - Protocol stripping (https://, http://, ftp://, etc.)
 *   - Port stripping (:443, :8080, etc.)
 *   - Case normalization (Example.COM → example.com)
 *   - Trailing dot removal (DNS-root form)
 *   - Leading "www." removal (so www.example.com and example.com share one rule)
 *
 * Returns null for:
 *   - Empty / whitespace-only input
 *   - URLs with credentials (user:pass@host) — we strip them but log a warning
 *   - Malformed URLs that the standard URL parser rejects
 *   - javascript:, data:, vbscript:, file: URLs (only http/https/protocol-less accepted)
 */
export function extractHostname(input: string): string | null {
  if (!input || typeof input !== "string") return null;
  const trimmed = input.trim();
  if (!trimmed) return null;

  // Reject dangerous protocols immediately — these can never be valid domains.
  if (/^\s*(javascript|data|vbscript|file):/i.test(trimmed)) {
    return null;
  }

  let hostname: string | null = null;

  // If the input has a protocol, use the standard URL parser.
  // We prepend "https://" when there's no protocol so the parser treats
  // bare domains like "example.com" as a URL (otherwise `new URL("example.com")`
  // throws because it's treated as a relative path).
  try {
    let urlStr = trimmed;
    if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(urlStr)) {
      // No protocol — prepend https:// for parsing.
      urlStr = "https://" + urlStr;
    }
    const parsed = new URL(urlStr);
    hostname = parsed.hostname;
  } catch {
    // The URL parser failed. Try a manual hostname extraction as a fallback
    // (handles cases like "example.com:8080" without a protocol, which
    // new URL() misinterprets as a path).
    const match = trimmed.match(/^(?:https?:\/\/)?([^/:?#]+)/i);
    if (match && match[1]) {
      hostname = match[1];
    } else {
      return null;
    }
  }

  if (!hostname) return null;

  // Normalize: lowercase + strip trailing dot.
  hostname = hostname.toLowerCase().replace(/\.+$/, "");

  // Strip leading "www." so www.example.com and example.com share one rule.
  // We only strip a SINGLE leading "www." (not "www.www.example.com" → "www.example.com").
  if (hostname.startsWith("www.")) {
    hostname = hostname.slice(4);
  }

  // Final validation: hostname must be a valid DNS name (letters, digits,
  // hyphens, dots). Reject anything with weird characters that could be
  // used for bypass attempts.
  if (!/^[a-z0-9.-]+$/.test(hostname)) {
    return null;
  }

  // Reject empty after normalization.
  if (!hostname || hostname.length < 3 || hostname.length > 253) {
    return null;
  }

  return hostname;
}

/**
 * Normalize a domain string for storage or comparison.
 * This is the SAME as `extractHostname` — they share the normalization logic.
 * Use `normalizeDomain` when you have a bare domain (e.g. from the admin
 * input field), and `extractHostname` when you have a full URL.
 *
 * Both return the same normalized form: lowercase, no protocol, no port,
 * no trailing dot, no leading "www.".
 */
export function normalizeDomain(input: string): string | null {
  return extractHostname(input);
}

// ── Blocklist Loading (cached) ─────────────────────────────────────────

/**
 * Load all ACTIVE blocklist rules from the DB, cached for 30 seconds.
 *
 * The cache stores the rules in a Map keyed by normalizedDomain for O(1)
 * lookup. On cache miss, we fetch all active rules in a single query.
 *
 * Admin changes (add/edit/disable/delete) call `invalidateBlocklistCache()`
 * so the next request re-fetches fresh data.
 *
 * NEVER throws — returns an empty array on DB failure (fail-OPEN: a DB
 * outage should not block all URL submissions across the platform).
 */
async function loadActiveBlocklist(): Promise<BlockedDomainRule[]> {
  try {
    return await cacheGetOrSet(
      BLOCKLIST_CACHE_KEY,
      BLOCKLIST_CACHE_TTL,
      async () => {
        const rows = await db.blockedDomain.findMany({
          where: { isActive: true },
          select: {
            id: true,
            domain: true,
            normalizedDomain: true,
            reason: true,
            notes: true,
            isActive: true,
            blockSubdomains: true,
            hitCount: true,
            createdAt: true,
            updatedAt: true,
            createdBy: true,
          },
        });
        return rows as BlockedDomainRule[];
      }
    );
  } catch (err) {
    // DB failure — fail-OPEN (don't block everything). Log the error.
    logger.error("security", "Failed to load domain blocklist — failing open", {
      error: err instanceof Error ? err.message : String(err),
    });
    return [];
  }
}

/**
 * Invalidate the blocklist cache. Called by admin write operations
 * (add/edit/disable/delete) so the next request sees the fresh data.
 */
export async function invalidateBlocklistCache(): Promise<void> {
  try {
    await getCache().delete(BLOCKLIST_CACHE_KEY);
  } catch {
    // Non-fatal — the cache will expire naturally within 30s.
  }
}

// ── Core Check Function ────────────────────────────────────────────────

/**
 * Check whether a URL's domain is blocked.
 *
 * This is THE single function every URL-accepting code path calls.
 * There is no per-feature blocklist logic anywhere else in the codebase.
 *
 * Algorithm:
 *   1. Parse the URL safely via `extractHostname`.
 *   2. If the URL is malformed, return `{ blocked: false, error: "..." }`.
 *   3. Load the active blocklist (cached for 30s).
 *   4. For each rule, check if the hostname matches:
 *      - Exact match: hostname === rule.normalizedDomain
 *      - Subdomain match (only when rule.blockSubdomains=true):
 *        hostname === rule.normalizedDomain OR
 *        hostname ends with "." + rule.normalizedDomain
 *        (the "." is critical — "example.com.evil.com" does NOT match "example.com")
 *   5. Return the first matching rule (there should only be one due to the
 *      UNIQUE constraint on normalizedDomain).
 *
 * @param url The URL to check (full URL or bare domain).
 * @returns {blocked, domain, rule?} — `blocked=true` when the domain matches an active rule.
 */
export async function checkBlockedDomain(
  url: string
): Promise<BlockedDomainCheckResult> {
  const hostname = extractHostname(url);
  if (!hostname) {
    return {
      blocked: false,
      domain: null,
      error: "Malformed or invalid URL",
    };
  }

  const rules = await loadActiveBlocklist();

  for (const rule of rules) {
    if (matchesDomain(hostname, rule.normalizedDomain, rule.blockSubdomains)) {
      return {
        blocked: true,
        domain: hostname,
        rule: {
          id: rule.id,
          domain: rule.domain,
          normalizedDomain: rule.normalizedDomain,
          reason: rule.reason,
          blockSubdomains: rule.blockSubdomains,
        },
      };
    }
  }

  return { blocked: false, domain: hostname };
}

/**
 * Check if a hostname matches a blocked domain rule.
 *
 * SAFE SUFFIX MATCHING — never uses `includes()` (which would match
 * "example.com.evil.com" as a substring of "example.com").
 *
 * Match conditions:
 *   1. Exact match: hostname === blockedDomain
 *   2. Subdomain match (only when blockSubdomains=true):
 *      hostname === "<something>.<blockedDomain>"
 *      → checked via `hostname.endsWith("." + blockedDomain)`
 *
 * Examples (blockedDomain = "example.com", blockSubdomains = true):
 *   ✓ "example.com"           → exact match
 *   ✓ "www.example.com"       → subdomain match (but note: www was already stripped by extractHostname)
 *   ✓ "cdn.example.com"       → subdomain match
 *   ✓ "media.example.com"     → subdomain match
 *   ✗ "example.com.evil.com"  → does NOT end with ".example.com" (ends with ".evil.com")
 *   ✗ "safeexample.com"       → does NOT end with ".example.com" (no dot before)
 *   ✗ "notexample.com"        → does NOT end with ".example.com"
 */
function matchesDomain(
  hostname: string,
  blockedDomain: string,
  blockSubdomains: boolean
): boolean {
  // Exact match (case already normalized to lowercase).
  if (hostname === blockedDomain) return true;

  // Subdomain match — only when blockSubdomains is enabled.
  // The "." prefix is CRITICAL for security.
  if (blockSubdomains && hostname.endsWith("." + blockedDomain)) {
    return true;
  }

  return false;
}

// ── Convenience: Boolean Wrapper ───────────────────────────────────────

/**
 * Simple boolean check — returns true if the URL's domain is blocked.
 *
 * Use this when you don't need the full result (e.g. in a filter or guard).
 * For the rule details + hit recording, use `checkBlockedDomain()` + `recordBlockedDomainHit()`.
 */
export async function isBlockedDomain(url: string): Promise<boolean> {
  const result = await checkBlockedDomain(url);
  return result.blocked;
}

// ── Hit Tracking ───────────────────────────────────────────────────────

/**
 * Record a "block hit" — that a user attempted to use a blocked domain.
 *
 * Creates:
 *   1. A BlockedDomainHit row (with userId, context, attemptedUrl)
 *   2. Increments BlockedDomain.hitCount
 *
 * Both writes are fire-and-forget (non-blocking). The caller should NOT
 * await this function — it's void. Failures are logged but never crash
 * the request.
 *
 * PRIVACY: we store ONLY the attempted URL (capped at 2048 chars). We do
 * NOT store the user's full message/post content — only the URL that was
 * blocked + which content type it appeared in.
 *
 * @param ruleId     The BlockedDomain.id that matched.
 * @param userId     The user who attempted it (null for anonymous requests).
 * @param context    Where the block was detected (ARTICLE, POST, etc.).
 * @param attemptedUrl The full URL the user tried to use.
 */
export function recordBlockedDomainHit(opts: {
  ruleId: string;
  userId: string | null;
  context: BlockCheckContext;
  attemptedUrl: string;
}): void {
  // Fire-and-forget — never block the request on hit recording.
  void (async () => {
    try {
      const safeUrl = opts.attemptedUrl.slice(0, MAX_ATTEMPTED_URL_LENGTH);

      // 1. Create the hit row.
      await db.blockedDomainHit.create({
        data: {
          blockedDomainId: opts.ruleId,
          userId: opts.userId,
          context: opts.context,
          attemptedUrl: safeUrl,
        },
      });

      // 2. Increment the rule's hitCount. We use updateMany with a
      //    conditional WHERE to avoid a race condition (the rule might
      //    have been deleted between the check + the increment).
      await db.blockedDomain
        .update({
          where: { id: opts.ruleId },
          data: { hitCount: { increment: 1 } },
        })
        .catch(() => {
          // Rule was deleted between check + increment — non-fatal.
        });
    } catch (err) {
      logger.warn("security", "Failed to record blocked domain hit", {
        ruleId: opts.ruleId,
        context: opts.context,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  })();
}

// ── URL Extraction from Text ───────────────────────────────────────────

/**
 * Extract all URLs from a text string. Used to check URLs embedded in
 * post/comment/message content.
 *
 * Matches:
 *   - Full URLs: "https://example.com/path" or "http://example.com"
 *   - Protocol-relative: "//example.com/path"
 *
 * Does NOT match bare domains without a protocol (e.g. "example.com" in
 * the middle of a sentence) — this is intentional to avoid false positives
 * on everyday text.
 *
 * Returns an array of URL strings (deduplicated).
 */
export function extractUrlsFromText(text: string): string[] {
  if (!text || typeof text !== "string") return [];
  const regex = /(?:https?:\/\/|\/\/)[^\s<>"']+/gi;
  const matches = text.match(regex) || [];
  // Deduplicate + strip trailing punctuation (commas, periods, etc. that
  // aren't part of the URL).
  const set = new Set<string>();
  for (const m of matches) {
    set.add(m.replace(/[.,;:!?)\]}>]+$/, ""));
  }
  return [...set];
}

/**
 * Check all URLs in a text string against the blocklist.
 *
 * Returns the FIRST blocked URL's result (there's usually only one).
 * If no URLs are found, or none are blocked, returns `{ blocked: false }`.
 *
 * Use this for post content, comment text, message text, article content,
 * and profile bios — anywhere users can embed URLs in free text.
 *
 * @param text     The text to scan for URLs.
 * @param userId   The user who submitted the text (for hit tracking).
 * @param context  Where the text was submitted (ARTICLE, POST, etc.).
 */
export async function checkTextForBlockedDomains(
  text: string,
  userId: string | null,
  context: BlockCheckContext
): Promise<BlockedDomainCheckResult & { blockedUrl?: string }> {
  const urls = extractUrlsFromText(text);
  for (const url of urls) {
    const result = await checkBlockedDomain(url);
    if (result.blocked && result.rule) {
      // Record the hit (fire-and-forget).
      recordBlockedDomainHit({
        ruleId: result.rule.id,
        userId,
        context,
        attemptedUrl: url,
      });
      return { ...result, blockedUrl: url };
    }
  }
  return { blocked: false, domain: null };
}

// ── Admin Helpers (for the API routes) ─────────────────────────────────

/**
 * Create a new blocked domain rule. Normalizes the domain + checks for
 * duplicates. Invalidates the cache.
 *
 * Returns the created rule, or throws an Error on validation failure.
 */
export async function createBlockedDomain(opts: {
  domain: string;
  reason?: string;
  notes?: string;
  isActive?: boolean;
  blockSubdomains?: boolean;
  adminId: string;
}): Promise<BlockedDomainRule> {
  const normalized = normalizeDomain(opts.domain);
  if (!normalized) {
    throw new Error("Invalid domain format. Please enter a valid domain (e.g. example.com).");
  }
  if (normalized.length > 253) {
    throw new Error("Domain too long (max 253 characters).");
  }

  // Check for duplicates (case-insensitive — normalizedDomain is UNIQUE).
  const existing = await db.blockedDomain.findUnique({
    where: { normalizedDomain: normalized },
    select: { id: true, isActive: true },
  });
  if (existing) {
    // If the existing rule is disabled, re-enable it instead of erroring.
    if (!existing.isActive) {
      const updated = await db.blockedDomain.update({
        where: { id: existing.id },
        data: {
          isActive: true,
          reason: opts.reason ?? null,
          notes: opts.notes ?? null,
          blockSubdomains: opts.blockSubdomains ?? true,
        },
      });
      await invalidateBlocklistCache();
      return updated as BlockedDomainRule;
    }
    throw new Error(`Domain "${normalized}" is already on the blocklist.`);
  }

  const rule = await db.blockedDomain.create({
    data: {
      domain: opts.domain.trim(),
      normalizedDomain: normalized,
      reason: opts.reason?.trim() || null,
      notes: opts.notes?.trim() || null,
      isActive: opts.isActive ?? true,
      blockSubdomains: opts.blockSubdomains ?? true,
      createdBy: opts.adminId,
    },
  });

  await invalidateBlocklistCache();
  return rule as BlockedDomainRule;
}

/**
 * Update an existing blocked domain rule. Invalidates the cache.
 */
export async function updateBlockedDomain(
  id: string,
  opts: {
    reason?: string;
    notes?: string;
    isActive?: boolean;
    blockSubdomains?: boolean;
  }
): Promise<BlockedDomainRule> {
  const rule = await db.blockedDomain.update({
    where: { id },
    data: {
      ...(opts.reason !== undefined && { reason: opts.reason.trim() || null }),
      ...(opts.notes !== undefined && { notes: opts.notes.trim() || null }),
      ...(opts.isActive !== undefined && { isActive: opts.isActive }),
      ...(opts.blockSubdomains !== undefined && { blockSubdomains: opts.blockSubdomains }),
    },
  });
  await invalidateBlocklistCache();
  return rule as BlockedDomainRule;
}

/**
 * Delete a blocked domain rule permanently. Invalidates the cache.
 * (Cascade-deletes all BlockedDomainHit rows for this rule.)
 */
export async function deleteBlockedDomain(id: string): Promise<void> {
  await db.blockedDomain.delete({ where: { id } });
  await invalidateBlocklistCache();
}

/**
 * Get stats for the admin dashboard.
 */
export async function getBlocklistStats(): Promise<{
  totalDomains: number;
  activeRules: number;
  disabledRules: number;
  hitsToday: number;
  hitsThisWeek: number;
}> {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const [totalDomains, activeRules, hitsToday, hitsThisWeek] = await Promise.all([
    db.blockedDomain.count(),
    db.blockedDomain.count({ where: { isActive: true } }),
    db.blockedDomainHit.count({ where: { createdAt: { gte: todayStart } } }),
    db.blockedDomainHit.count({ where: { createdAt: { gte: weekAgo } } }),
  ]);

  return {
    totalDomains,
    activeRules,
    disabledRules: totalDomains - activeRules,
    hitsToday,
    hitsThisWeek,
  };
}
