/**
 * CSRF (Cross-Site Request Forgery) protection.
 *
 * This app uses cookie-based session authentication (iron-session).
 * SameSite=Lax on the session cookie defends against top-level GET
 * CSRF, but does NOT fully defend against:
 *   - Cross-origin POSTs when the cookie is sent with `navigate` requests
 *   - Subdomain-based CSRF attacks (a compromised subdomain can set
 *     cookies that the browser sends with same-site requests)
 *   - Older browsers (some legacy browsers ignore SameSite=Lax)
 *
 * DEFENSE-IN-DEPTH: every state-changing API route additionally
 * verifies that the request originates from a same-origin context.
 * The check is based on the standard `Origin` / `Referer` headers
 * (RFC 6454 + Fetch standard), comparing the source origin against
 * the application's configured origin (`APP_ORIGIN`).
 *
 * WHY ORIGIN-BASED (NOT TOKEN-BASED):
 *   - Token-based CSRF would require either (a) a separate cookie
 *     that must be sent on every request (which weakens SameSite),
 *     or (b) a meta-tag/initial-request bootstrap (more complex).
 *   - Origin/Referer verification is the CSRF defense recommended
 *     by OWASP for modern SPA architectures with same-origin APIs.
 *   - Browsers ALWAYS send `Origin` for cross-origin requests to
 *     non-GET endpoints (this is mandated by the Fetch standard).
 *   - When `Origin` is absent (older browsers, same-origin navigate
 *     requests), `Referer` is checked as a fallback. If BOTH are
 *     absent AND the request is a state-changing mutation, we fail
 *     CLOSED (reject) — defense-in-depth.
 *
 * Browsers that do not send Origin for same-origin POSTs (rare in
 * modern browsers — the Fetch standard mandates it for cross-origin,
 * and modern Chromium sends it for same-origin too) are handled
 * gracefully: if Origin is absent, we check Referer; if both are
 * absent we reject the request.
 *
 * WHAT THIS DOES NOT DO:
 *   - This is not a substitute for the SameSite=Lax cookie flag.
 *     Both defenses apply together.
 *   - This is not a substitute for re-authentication on highly
 *     sensitive operations (e.g. password change re-prompts the
 *     current password — that's a separate defense layer).
 */

import { logger } from "@/lib/logging";

/**
 * Resolve ALL legitimate application origins for the CSRF check.
 *
 * Returns an ARRAY of valid origins (scheme + host + port). The CSRF
 * check passes when the request's Origin/Referer matches ANY of these.
 *
 * Sources (in priority order — all tried, all valid origins are collected):
 *   1. `NEXT_PUBLIC_APP_BASE_URL` env var — admin-configured canonical URL.
 *   2. The request URL's own origin — derived from `req.url`.
 *   3. Host header + X-Forwarded-Proto header — used when `req.url` is
 *      a path-only string (happens on some serverless configurations
 *      like Netlify Functions behind a proxy).
 *
 * WHY ALL THREE:
 *   - When the env var is set correctly AND the deployment matches →
 *     all three origins are identical, no behavior change.
 *   - When the env var is set WRONG (e.g. set to
 *     `https://centrychat.netlify.app` but deployed to
 *     `https://my-app.netlify.app`) → the env-derived origin is rejected,
 *     but the request-URL-derived origin STILL matches the browser's
 *     Origin header. This prevents the "Request blocked by security
 *     policy" production outage.
 *   - When `req.url` is a path-only string (some Netlify configs) →
 *     `new URL(requestUrl)` throws, so we fall back to reconstructing
 *     the full URL from the `Host` + `X-Forwarded-Proto` headers.
 *   - When the env var is UNSET (preview deployments, dev) → only the
 *     request-derived origins are used (works for all subdomains).
 *
 * SECURITY:
 *   - Adding the request-URL-derived origin does NOT weaken CSRF.
 *     The request URL + Host header come from the deployment itself.
 *     An attacker CANNOT spoof the Host header in a browser (browsers
 *     refuse to send arbitrary Host headers, and SNI/TLS cert validation
 *     would also fail). The Origin header is set by the browser, not
 *     the attacker — so a same-origin check against the request URL
 *     is exactly equivalent to checking that browser's Origin == deployment's Host.
 *   - Cross-site attacks (where the browser's Origin is a DIFFERENT
 *     site) are STILL blocked — none of the three origins would match
 *     the attacker's origin.
 */
function resolveAppOrigins(requestUrl: string, request?: Request): string[] {
  const origins: string[] = [];

  // 1. env var-derived origin (admin-configured canonical URL).
  const base = process.env.NEXT_PUBLIC_APP_BASE_URL;
  if (base) {
    try {
      const u = new URL(base);
      origins.push(`${u.protocol}//${u.host}`);
    } catch {
      // ignore — fall through to other sources
    }
  }

  // 2. request-URL-derived origin (when req.url is a full URL).
  try {
    const u = new URL(requestUrl);
    origins.push(`${u.protocol}//${u.host}`);
  } catch {
    // req.url is a path-only string (e.g. "/api/v1/auth/login") — this
    // happens on some Netlify serverless configurations where the
    // request URL is just the path. Fall through to step 3.
  }

  // 3. Reconstruct the full URL from the Host + X-Forwarded-Proto headers.
  //    This is the fallback for when req.url is path-only. The Host
  //    header is set by the deployment itself (or by a trusted reverse
  //    proxy like Netlify's edge) — it's the canonical hostname for
  //    the deployment.
  if (request) {
    const host = request.headers.get("host") ?? request.headers.get("x-forwarded-host");
    const proto =
      request.headers.get("x-forwarded-proto") ??
      // If there's no X-Forwarded-Proto, derive from the URL scheme
      // (https if requestUrl starts with https://, otherwise http).
      (requestUrl.startsWith("https://") ? "https" : "http");
    if (host) {
      origins.push(`${proto}://${host}`);
    }
  }

  // Dedupe (in case multiple sources produce the same origin).
  return Array.from(new Set(origins));
}

/**
 * Backward-compat: return a single canonical origin (the first one).
 * Kept for callers that still use `string` instead of `string[]`.
 */
function resolveAppOrigin(requestUrl: string, request?: Request): string | null {
  const origins = resolveAppOrigins(requestUrl, request);
  return origins.length > 0 ? origins[0]! : null;
}

/**
 * Returns true if `requestOrigin` is the same origin as `appOrigin`
 * (scheme + host + port must match exactly).
 *
 * Both inputs must be full origins like "https://example.com:443" —
 * the URL constructor normalizes default ports away (so "https://a"
 * and "https://a:443" compare as equal).
 */
function sameOrigin(requestOrigin: string, appOrigin: string): boolean {
  try {
    const a = new URL(requestOrigin);
    const b = new URL(appOrigin);
    // Compare protocol (lowercased), hostname (lowercased), and port.
    // URL normalizes :443 for https and :80 for http away.
    return (
      a.protocol.toLowerCase() === b.protocol.toLowerCase() &&
      a.hostname.toLowerCase() === b.hostname.toLowerCase() &&
      (a.port || "") === (b.port || "")
    );
  } catch {
    return false;
  }
}

/**
 * Inspect a request's Origin + Referer headers and decide whether to
 * accept a state-changing request.
 *
 * Returns:
 *   - { ok: true } when the request's Origin/Referer matches ANY of the
 *     configured app origins (env var + request URL).
 *   - { ok: false, reason } when the request is cross-origin (or both
 *     headers are absent on a mutation request — fail closed).
 *
 * This function should be called on EVERY state-changing endpoint:
 *   POST / PUT / PATCH / DELETE
 *
 * The `appOrigins` argument is the array of valid origins (from
 * `resolveAppOrigins`). The request passes when its Origin/Referer
 * matches ANY of them.
 */
export function checkCsrf(
  req: Request,
  appOrigins: string | string[]
): { ok: true } | { ok: false; reason: string } {
  const origins = Array.isArray(appOrigins) ? appOrigins : [appOrigins];
  if (origins.length === 0) {
    return { ok: false, reason: "No valid app origins configured" };
  }

  // The browser ALWAYS sends Origin for cross-origin CORS requests,
  // and modern browsers send it for same-origin non-GET requests too.
  const origin = req.headers.get("origin");
  if (origin) {
    for (const appOrigin of origins) {
      if (sameOrigin(origin, appOrigin)) {
        return { ok: true };
      }
    }
    // Cross-origin POST/PUT/PATCH/DELETE — reject.
    return { ok: false, reason: "Cross-origin request blocked by CSRF policy" };
  }
  // Origin absent — check Referer as a fallback. Same-origin requests
  // always include a Referer (subject to Referrer-Policy: strict-origin-when-cross-origin,
  // which we set, so the origin is preserved).
  const referer = req.headers.get("referer");
  if (referer) {
    for (const appOrigin of origins) {
      if (sameOrigin(referer, appOrigin)) {
        return { ok: true };
      }
    }
    return { ok: false, reason: "Cross-origin Referer blocked by CSRF policy" };
  }
  // Neither Origin nor Referer is present. This is suspicious for a
  // browser-initiated state-changing request — fail closed.
  //
  // Notes:
  //   - Some non-browser clients (curl, Postman, server-to-server)
  //     legitimately omit these headers. Server-to-server integrations
  //     that bypass the cookie session do not need CSRF protection
  //     (they're not authenticated via cookies).
  //   - For cookie-authenticated browser requests, BOTH Origin and
  //     Referer being absent is extremely rare (every modern browser
  //     sends at least one for non-GET requests).
  return {
    ok: false,
    reason: "Missing Origin and Referer headers — request blocked by CSRF policy",
  };
}

/**
 * Resolve ALL valid app origins from the request URL + env var + Host header,
 * then verify CSRF against any of them.
 *
 * This is the canonical entry point for API routes — `apiHandler`
 * calls this on every state-changing request.
 */
export function checkCsrfFromRequest(
  req: Request
): { ok: true } | { ok: false; reason: string } {
  const appOrigins = resolveAppOrigins(req.url, req);
  if (appOrigins.length === 0) {
    // Could not determine the legitimate origin. Fail closed for
    // state-changing requests — defense-in-depth.
    logger.error("security", "CSRF check failed: could not resolve any app origin", {
      hasBaseUrl: !!process.env.NEXT_PUBLIC_APP_BASE_URL,
      requestUrl: req.url,
      hasHostHeader: !!req.headers.get("host"),
    });
    return { ok: false, reason: "Server could not determine its own origin" };
  }
  return checkCsrf(req, appOrigins);
}

/**
 * Whether a request method is state-changing (requires CSRF check).
 */
export function isStateChangingMethod(method: string): boolean {
  const m = method.toUpperCase();
  return m === "POST" || m === "PUT" || m === "PATCH" || m === "DELETE";
}
