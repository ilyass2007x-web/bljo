/**
 * Anonymous visitor cookie.
 *
 * PURPOSE (per spec §2 — Anonymous Visitors):
 *   We need a stable per-browser identifier to dedup article views for
 *   LOGGED-OUT visitors. Without it, every Refresh would count as a new
 *   view — a 100-Refresh session would inflate the count by 100.
 *
 * PRIVACY (per spec §12):
 *   - The cookie value is a random cuid — NOT a fingerprint, NOT a hash of
 *     any personal data. It's just an opaque token.
 *   - It does NOT contain the user's IP, browser info, location, or any
 *     PII. It is purely a random per-browser marker.
 *   - HttpOnly: JavaScript cannot read it (prevents XSS-based tracking).
 *   - SameSite=Lax: prevents CSRF on cross-origin requests.
 *   - Secure in production: only sent over HTTPS.
 *   - 1-year max age: matches typical analytics cookie lifetime. After
 *     expiry, the visitor gets a new random token (treated as a new
 *     visitor — acceptable).
 *   - We do NOT link this token to a user account. When a logged-in user
 *     views an article, we use their userId for dedup (which takes
 *     precedence over the visitor token). The visitor token is only used
 *     for anonymous (logged-out) traffic.
 *
 * DEDUP MECHANICS:
 *   - The article-views endpoint uses @@unique([articleId, userId]) for
 *     dedup. For logged-in users, `userId` is the real user id.
 *   - For logged-OUT users, we need a stable identifier. We can't put the
 *     visitor token directly in `userId` (foreign-key constraint + it
 *     would pollute the User table). Instead we HASH the visitor token
 *     into a stable pseudo-userId prefixed with "anon:" — see
 *     `deriveAnonymousVisitorId()`. This goes into a separate column
 *     on ArticleView (anonymousVisitorId) which is part of the dedup
 *     unique index.
 *
 * SECURITY:
 *   - The token is generated server-side using crypto.randomUUID() —
 *     never trusted from the client. If a request arrives with a
 *     malformed / missing cookie, we generate a new token + set it in
 *     the response Set-Cookie header. The client cannot influence the
 *     value.
 *   - The token is opaque (a UUID) — there's no way for an attacker to
 *     craft a "fake" token to manipulate view counts beyond their own
 *     dedup window. Each token = one visitor = one view per article per
 *     dedup window.
 */

import { cookies } from "next/headers";
import { NextResponse } from "next/server";

/**
 * The cookie name. `cc` = CentryChat prefix to avoid collisions with any
 * third-party cookie. `visitor` = purpose.
 */
export const VISITOR_COOKIE_NAME = "cc_visitor";

/** Cookie lifetime: 365 days. Matches typical analytics cookie lifetime. */
const VISITOR_COOKIE_MAX_AGE_SECONDS = 365 * 24 * 60 * 60;

/**
 * Read the visitor token from the incoming request cookies. Returns null
 * when the cookie is missing or doesn't look like a valid UUID.
 *
 * Server-side only (uses next/headers).
 */
export async function getVisitorToken(): Promise<string | null> {
  const c = await cookies();
  const raw = c.get(VISITOR_COOKIE_NAME)?.value;
  if (!raw) return null;
  // Validate it looks like a UUID (crypto.randomUUID format).
  // This is a sanity check — the value is opaque so we don't care about
  // the exact format, but rejecting malformed values keeps the DB column
  // clean (in case someone manually sets a garbage cookie).
  if (!/^[a-f0-9-]{10,}$/i.test(raw)) return null;
  return raw;
}

/**
 * Generate a fresh visitor token (random UUID).
 * Used when no cookie is present.
 */
export function generateVisitorToken(): string {
  return crypto.randomUUID();
}

/**
 * Derive a stable pseudo-userId for an anonymous visitor token.
 *
 * This is stored in the `anonymousVisitorId` column on ArticleView (a NEW
 * column added in this task — see migration). It is NOT a foreign key to
 * User — it's just a stable string we use for dedup.
 *
 * We HASH the token (not store it raw) so that even if the DB leaks, an
 * attacker can't directly map a row back to a specific browser cookie.
 * The hash is SHA-256, truncated to 32 hex chars — collision-resistant
 * enough for a per-article dedup key (we only need to dedup within one
 * article's view table, ~10^6 rows max).
 *
 * The prefix "anon:" makes it visually obvious in any DB inspection that
 * this is NOT a real user id.
 */
export async function deriveAnonymousVisitorId(
  visitorToken: string
): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(visitorToken);
  // Use Web Crypto (available in Next.js server runtime) — no Node crypto
  // dependency, works in serverless + edge runtimes.
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashHex = Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  // Truncate to 32 hex chars (128 bits) — plenty for collision resistance
  // at our scale (10^6 views per article → 10^-31 collision probability).
  return `anon:${hashHex.slice(0, 32)}`;
}

/**
 * Set the visitor cookie on a NextResponse (so the next request from the
 * same browser carries it). Called when no cookie was present on the
 * incoming request — we generate a fresh token + set it before returning
 * the view-tracking response.
 *
 * Cookie attributes:
 *   - httpOnly: JavaScript cannot read this (XSS protection).
 *   - sameSite: "lax" (CSRF protection — cookie is sent on top-level
 *     navigations + same-site requests, NOT on cross-site POSTs).
 *   - secure: true in production (HTTPS only). False in dev (HTTP).
 *   - path: "/" (sent on all routes).
 *   - maxAge: 1 year.
 */
export function setVisitorCookieOnResponse(
  response: NextResponse,
  token: string
): void {
  response.cookies.set({
    name: VISITOR_COOKIE_NAME,
    value: token,
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: VISITOR_COOKIE_MAX_AGE_SECONDS,
  });
}
