/**
 * Security headers.
 *
 * Applied via next.config.ts or middleware. These helpers also let API routes
 * attach headers manually where needed.
 */
export const SECURITY_HEADERS: Record<string, string> = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  // PHASE 1 FIX (Video Chat unblock):
  // Previously `camera=(), microphone=()` — this BLOCKED every call to
  // `navigator.mediaDevices.getUserMedia({ video, audio })` at the
  // Permissions-Policy layer, BEFORE the browser could even show the
  // camera/mic permission prompt. The user-visible symptom was the
  // "failed" state in VideoChatScreen + ChatVideoCallDialog with the
  // message "Camera or microphone access was denied...".
  //
  // The fix allows camera + microphone for SAME-ORIGIN (self) only.
  // This is the SAME policy `netlify.toml` line 74 already declares —
  // but the response header set here in middleware takes precedence
  // over the Netlify static-file rule, so this is the single source
  // of truth on the wire. `geolocation` and `browsing-topics` remain
  // disabled (no feature uses them).
  //
  // Security: `camera=(self)` and `microphone=(self)` only allow
  // same-origin documents to request these devices — cross-origin
  // iframes and embeds still cannot. We never use `*` (which would
  // allow any origin). This is the minimum widening required for
  // Video Chat to function.
  //
  // HARDENING (security pass 2):
  //   - `display-capture=(self)` — required for `getDisplayMedia` if
  //     screen-share is ever added. Currently no feature uses it,
  //     but explicitly allowing self-origin is the safe default that
  //     doesn't break future legitimate use.
  //   - All other powerful features remain disabled (or default to
  //     the user's browser-set policy).
  "Permissions-Policy":
    "camera=(self), microphone=(self), display-capture=(self), geolocation=(), browsing-topics=(), interest-cohort=()",
  "Strict-Transport-Security": "max-age=63072000; includeSubDomains; preload",
  // Cross-Origin-Opener-Policy: same-origin allows the top-level
  // browsing context to be isolated from cross-origin openers.
  // Defense-in-depth against XS-Leaks / cross-origin window-popup
  // information leakage (e.g. measuring response sizes, navigations).
  // Set to "same-origin" (not "same-origin-plus-coep") so we don't
  // need crossOriginIsolated for embed iframes (AdSense, YouTube).
  "Cross-Origin-Opener-Policy": "same-origin",
  // Cross-Origin-Resource-Policy: same-site allows resources from
  // same-site registrable domains (so a separate CDN on a subdomain
  // of the same registrable domain can still serve assets). This is
  // a safer default than "same-origin" for deployments that use a
  // subdomain CDN, while still preventing arbitrary third-party sites
  // from loading our resources.
  "Cross-Origin-Resource-Policy": "same-site",
};

// CSP is conservative to avoid breaking Next.js internals. We allow 'self' and
// inline styles (Next.js requires this). Remote images are allowed from any
// https host (img-src https:). Direct video files are allowed from any https
// host (media-src https:). Platform embed iframes are allowed only from a
// curated allowlist of known embed hosts (frame-src).
//
// The frame-src allowlist is the SECURITY boundary for iframe embeds — only
// the listed domains can be loaded inside an <iframe>. This prevents user-
// pasted URLs from loading arbitrary third-party pages in an iframe context.
//
// `frame-ancestors 'none'` blocks anyone from embedding US in an iframe
// (clickjacking defense) — this is INDEPENDENT of frame-src (which controls
// what WE can embed).
//
// ADSENSE CRAWLER ACCESSIBILITY (per AdSense crawler audit):
// The AdSense library (adsbygoogle.js) is loaded from pagead2.googlesyndication.com.
// The library then internally loads ad creative via iframes from
// googleads.g.doubleclick.net + tpc.googlesyndication.com, and makes XHR calls
// back to pagead2.googlesyndication.com / googleads.g.doubleclick.net.
// Without these domains in script-src + frame-src + connect-src, the AdSense
// script + ads would be SILENTLY BLOCKED by CSP — pages would render fine but
// no ads would ever display. This was the root cause of "AdSense script doesn't
// load" in the previous build.
//
// SECURITY TRADE-OFF: adding these Google domains to the CSP allowlist is the
// OFFICIAL Google-recommended configuration for AdSense (see
// https://support.google.com/adsense/answer/9912581). The domains are
// first-party Google infrastructure — not arbitrary third-party CDNs. We use
// SPECIFIC subdomains (not *.googlesyndication.com wildcards) to keep the
// attack surface minimal.
export const CSP_HEADER =
  "default-src 'self'; " +
  // SECURITY FIX (L-2): Removed 'unsafe-eval' from script-src. Next.js 16
  // production builds don't require eval. 'unsafe-inline' is kept because
  // Next.js injects inline scripts for hydration data — removing it would
  // break the app. 'unsafe-eval' was likely a legacy default that's no
  // longer needed.
  //
  // ADSENSE FIX: added https://pagead2.googlesyndication.com so the
  // adsbygoogle.js library can load. Without this, CSP blocks the script
  // at the network level — the <script> tag is injected by AdSenseScript
  // but the browser refuses to fetch + execute it.
  "script-src 'self' 'unsafe-inline' https://pagead2.googlesyndication.com; " +
  "style-src 'self' 'unsafe-inline'; " +
  // img-src: allow any https image (direct images + og:image URLs).
  // data: + blob: are allowed for client-side object URLs (e.g. image
  // previews created via URL.createObjectURL).
  // AdSense also loads tracking pixels + ad images from its own domains —
  // already covered by the broad "https:" rule.
  "img-src 'self' data: blob: https: http:; " +
  // media-src: allow any https video/audio (direct video files).
  "media-src 'self' data: blob: https:; " +
  "font-src 'self' data:; " +
  // connect-src: AdSense library makes XHR/fetch calls to fetch ad
  // creatives + report metrics. Without these, ads fail to render even
  // when the script loads. ws: wss: kept for the realtime socket.io
  // mini-service (messaging presence).
  "connect-src 'self' ws: wss: https://pagead2.googlesyndication.com https://googleads.g.doubleclick.net; " +
  // frame-src: ALLOWLIST for platform embeds + AdSense ad iframes.
  // The AdSense library renders ad creative inside iframes from these
  // Google domains. Without them in frame-src, the iframe load is blocked
  // by CSP's default-src 'self' fallback — ads would never display.
  "frame-src 'self' " +
    // ── AdSense ad delivery iframes (must be listed explicitly) ──
    "https://pagead2.googlesyndication.com " +
    "https://googleads.g.doubleclick.net " +
    "https://tpc.googlesyndication.com " +
    "https://www.google.com " +
    // ── Platform embed allowlist (unchanged) ──
    "https://www.youtube-nocookie.com " +
    "https://www.youtube.com " +
    "https://player.vimeo.com " +
    "https://www.tiktok.com " +
    "https://www.instagram.com " +
    "https://www.facebook.com " +
    "https://platform.twitter.com " +
    "https://syndication.twitter.com " +
    "https://www.redditmedia.com " +
    "https://assets.pinterest.com " +
    "https://w.soundcloud.com " +
    "https://open.spotify.com " +
    "https://bandcamp.com " +
    "https://player.twitch.tv " +
    "https://clips.twitch.tv " +
    "https://www.dailymotion.com " +
    "https://streamable.com " +
    "https://giphy.com; " +
  // frame-ancestors: blocks anyone from embedding US in an iframe
  // (clickjacking defense). Independent of frame-src.
  "frame-ancestors 'none'; " +
  // object-src 'none' — defense-in-depth: block Flash / Java / old
  // plugin embeds entirely. No feature uses <object> / <embed> /
  // <applet>. Setting to 'none' is the standard hardened default.
  "object-src 'none'; " +
  // worker-src 'self' — only allow Web Workers from our origin
  // (blocks data: / blob: worker injection from user-controlled URLs).
  "worker-src 'self'; " +
  // manifest-src 'self' — only allow Web App Manifest from our origin.
  "manifest-src 'self'; " +
  "base-uri 'self'; " +
  "form-action 'self'";

export function applySecurityHeaders(headers: Headers): void {
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) {
    headers.set(k, v);
  }
  headers.set("Content-Security-Policy", CSP_HEADER);
}
