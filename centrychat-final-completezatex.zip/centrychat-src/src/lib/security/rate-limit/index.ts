/**
 * Rate limiting abstraction.
 *
 * Production (CACHE_PROVIDER=redis): counters are SHARED across all serverless
 *   instances via Upstash Redis REST → rate limits are enforced consistently
 *   regardless of which instance handles the request.
 *
 * Development (CACHE_PROVIDER=memory, the default): counters are per-process
 *   — fine for local dev, but NOT shared across instances in production.
 *
 * FAILURE BEHAVIOR (when Redis is unreachable or slow):
 *   The cache provider throws on failure (after a 2-second timeout). This
 *   helper CATCHES the error, logs a security warning, and returns
 *   `{ ok: true }` (fail-OPEN). Rationale:
 *     - A brief Redis outage should NOT take down the entire platform
 *       (login, registration, feed, search all rely on rate limits).
 *     - Rate limits are a defense-in-depth control, not the only security
 *       boundary. Login still has Argon2id hashing + session management +
 *       audit logs. Registration still has Gmail-only email validation.
 *     - The failure is LOGGED (not silent) — admins can see Redis outages
 *       in the logs and fix them.
 *     - This matches the previous in-memory behavior (which also doesn't
 *       share counters across instances), so the security posture during a
 *       Redis outage is no WORSE than the previous pre-fix state.
 *
 *   This is the safest behavior compatible with the existing architecture:
 *   fail-open with logging. The alternative (fail-closed → 429 every request)
 *   would cause a platform-wide outage on every Redis hiccup.
 *
 * Apply to: login, registration, password reset, email verification, search,
 * message sending, reports, post/article creation, comments, likes, shares,
 * follows, interactions, media resolver, collections mutations, admin APIs.
 */
import { getCache } from "@/lib/cache";
import { logger } from "@/lib/logging";

export interface RateLimitResult {
  ok: boolean;
  limit: number;
  remaining: number;
  resetAt: number; // epoch ms
}

export interface RateLimitOptions {
  /** Maximum number of requests in the window. */
  limit: number;
  /** Window size in seconds. */
  windowSeconds: number;
  /**
   * When the cache (Redis/Upstash) is unreachable, how should we
   * handle the rate-limit decision?
   *
   *   - "open"  (default): allow the request through, log a warning.
   *     Use for non-critical endpoints (analytics tracking, contact
   *     form, username-check) where availability matters more than
   *     the exact rate limit. This matches the previous behavior.
   *   - "closed": reject the request with 429 + a long Retry-After.
   *     Use for CRITICAL security endpoints (login, register,
   *     password-reset, email-verification) where bypassing the
   *     limit could allow brute-force / mass-account creation.
   *
   * Default is "open" for backward compatibility — every existing
   * caller continues to behave identically. New critical-security
   * callers pass { failMode: "closed" } to opt in.
   */
  failMode?: "open" | "closed";
}

/**
 * Global namespace prefix for ALL rate-limit keys.
 *
 * Why: prevents collisions with non-rate-limit cache uses
 *   (e.g. "feature:*" for feature flags, "media:resolve:*" for the URL
 *   resolver cache, "adsense:*" for ad config). Without this prefix, a
 *   rate-limit key like "like:<userId>" could theoretically collide with
 *   a future non-rate-limit cache key starting with "like:".
 *
 * The prefix is added INSIDE checkRateLimit (transparent to callers).
 * Callers continue to pass endpoint-specific keys like "login:ip:..." or
 * "post-create:<userId>" — the helper adds "ratelimit:" on top, so the
 * actual cache key becomes "ratelimit:login:ip:...".
 *
 * The prefix is also stripped from the LOG output (we log only the first
 * two segments after the prefix, e.g. "login:ip" instead of the full
 * "ratelimit:login:ip:1.2.3.4:user@example.com" — never logs the raw
 * email or IP).
 */
const RATE_LIMIT_KEY_PREFIX = "ratelimit:";

/**
 * Check + increment the rate-limit counter for the given key.
 *
 * @param key - MUST be namespaced + scoped (e.g. "login:ip:1.2.3.4:user@example.com").
 *   The caller is responsible for key isolation (user, IP, endpoint, email).
 *   Never include raw passwords or secrets in the key — normalized email +
 *   IP + endpoint name only. The "ratelimit:" prefix is added automatically.
 */
export async function checkRateLimit(
  key: string,
  opts: RateLimitOptions
): Promise<RateLimitResult> {
  const cache = getCache();
  // Add the global "ratelimit:" prefix for key isolation. Defensive: if
  // the caller already prefixed (shouldn't happen), don't double-prefix.
  const namespacedKey = key.startsWith(RATE_LIMIT_KEY_PREFIX)
    ? key
    : `${RATE_LIMIT_KEY_PREFIX}${key}`;
  let count: number;
  try {
    count = await cache.increment(namespacedKey, opts.windowSeconds);
  } catch (err) {
    // Cache (Redis/Upstash) is unreachable.
    //
    // failMode decides what happens:
    //   - "open" (default): allow the request. Availability > exact limit.
    //     The previous security posture is preserved (no worse than before).
    //   - "closed": reject the request with 429. Used by CRITICAL
    //     security endpoints (login, register, password-reset,
    //     email-verification) where bypassing the limit allows
    //     brute-force / mass-account creation. The 429 includes a
    //     generous Retry-After so legitimate users aren't punished.
    //
    // We log ONLY the first two segments after the prefix (e.g. "login:ip")
    // — never the full key (it may contain IP + email which are
    // sensitive in operational logs).
    const logSafeKeyPrefix = key
      .split(":")
      .slice(0, 2)
      .join(":"); // e.g. "login:ip" — never the full key
    const failMode = opts.failMode ?? "open";
    if (failMode === "closed") {
      logger.error(
        "security",
        "Rate-limit counter check failed — fail-CLOSED (critical endpoint)",
        {
          keyPrefix: logSafeKeyPrefix,
          error: err instanceof Error ? err.message : String(err),
        }
      );
      // Reject. Retry-After is set to the full window so the user
      // has to wait for the counter to expire before retrying (and
      // by then we expect Redis to be back).
      return {
        ok: false,
        limit: opts.limit,
        remaining: 0,
        resetAt: Date.now() + opts.windowSeconds * 1000,
      };
    }
    logger.error("security", "Rate-limit counter check failed — fail-open", {
      keyPrefix: logSafeKeyPrefix,
      error: err instanceof Error ? err.message : String(err),
    });
    return {
      ok: true,
      limit: opts.limit,
      remaining: opts.limit,
      resetAt: Date.now() + opts.windowSeconds * 1000,
    };
  }
  const ok = count <= opts.limit;
  const remaining = Math.max(0, opts.limit - count);
  return {
    ok,
    limit: opts.limit,
    remaining,
    resetAt: Date.now() + opts.windowSeconds * 1000,
  };
}

/** Convenience presets. */
export const RATE_LIMITS = {
  login: { limit: 10, windowSeconds: 60 }, // 10/min per ip+email
  register: { limit: 5, windowSeconds: 300 }, // 5/5min per ip
  passwordReset: { limit: 3, windowSeconds: 3600 }, // 3/hour per email (request link)
  passwordResetSubmit: { limit: 10, windowSeconds: 600 }, // 10/10min per ip (submit new password) — brute-force protection on the token
  emailVerify: { limit: 3, windowSeconds: 3600 }, // 3/hour per email
  messageSend: { limit: 60, windowSeconds: 60 }, // 60/min per user
  search: { limit: 30, windowSeconds: 60 }, // 30/min per user
  report: { limit: 10, windowSeconds: 600 }, // 10/10min per user
  adminWrite: { limit: 120, windowSeconds: 60 }, // 120/min per admin
  emailTest: { limit: 5, windowSeconds: 300 }, // 5/5min per admin (admin/email/test)
  // Phase: Security Audit H-1 — rate limits for mutation endpoints
  postCreate: { limit: 20, windowSeconds: 60 }, // 20 posts/min — prevents spam flooding
  articleCreate: { limit: 5, windowSeconds: 300 }, // 5 articles/5min — articles are longer-form
  comment: { limit: 30, windowSeconds: 60 }, // 30 comments/min
  like: { limit: 60, windowSeconds: 60 }, // 60 likes/min — prevents like-bombing
  share: { limit: 30, windowSeconds: 60 }, // 30 shares/min
  follow: { limit: 30, windowSeconds: 60 }, // 30 follows/min — prevents mass-follow bots
  interaction: { limit: 120, windowSeconds: 60 }, // 120 interactions/min — tracking events
  mediaResolve: { limit: 30, windowSeconds: 60 }, // 30 resolves/min — SSRF scan amplification
  // Phase 5 — Collections. Mutation rate limits (prevent spam).
  collectionCreate: { limit: 20, windowSeconds: 60 }, // 20 collections/min per user
  collectionItem: { limit: 60, windowSeconds: 60 }, // 60 add/remove/reorder/min per user
  collectionShare: { limit: 30, windowSeconds: 60 }, // 30 shares/min per user
  // Playlists — mutation rate limits (prevent spam). Mirrors the
  // Collections presets so user-perceived behavior is consistent across
  // both systems.
  playlistCreate: { limit: 20, windowSeconds: 60 }, // 20 playlists/min per user
  playlistItem: { limit: 60, windowSeconds: 60 }, // 60 add/remove/reorder/min per user
  // Contact form — public (no auth), so rate-limited by IP. Tight enough
  // to prevent spam, loose enough for legitimate users to retry on failure.
  contact: { limit: 5, windowSeconds: 3600 }, // 5 submissions/hour per IP
  // Analytics tracking — public (no auth), rate-limited by IP. Generous
  // enough for legitimate page navigation (a visitor browsing 30 pages
  // in 5 minutes is normal), tight enough to prevent event-spam flooding.
  analyticsTrack: { limit: 120, windowSeconds: 60 }, // 120 events/min per IP
  // Username availability check — public (used on the registration form).
  // Tight enough to prevent username enumeration (an attacker can't
  // brute-force the user table to find valid account names for
  // credential-stuffing), loose enough for a user typing/retyping a
  // username (the form also debounces client-side).
  usernameCheck: { limit: 10, windowSeconds: 600 }, // 10 checks/10min per IP
  // Video Chat signaling — rate-limited per user (only meaningful when
  // video chat is enabled). Generous enough for ICE candidate floods
  // (each connection generates ~10-30 candidates), tight enough to
  // prevent signaling-abuse attacks.
  videoChatSignal: { limit: 120, windowSeconds: 60 }, // 120 signals/min/user
} as const;

export function getClientIp(request: Request): string {
  const xff = request.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0]!.trim();
  const xri = request.headers.get("x-real-ip");
  if (xri) return xri;
  return "unknown";
}
