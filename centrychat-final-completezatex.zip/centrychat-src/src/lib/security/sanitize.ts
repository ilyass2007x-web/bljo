/**
 * Input validation & sanitization helpers.
 */
import { z } from "zod";

/**
 * Email validation — Gmail-only.
 *
 * SECURITY (spec §13): The platform only accepts @gmail.com addresses.
 * This prevents signup with disposable/temporary email services and
 * reduces spam/abuse.
 *
 * Validation chain:
 *   1. trim + lowercase (normalization — spec §15)
 *   2. zod .email() — validates RFC 5322 format
 *   3. .refine() — checks that the domain part (after @) is EXACTLY
 *      "gmail.com" (not "gmail.com.evil.com" or "gmail.comau")
 *
 * The domain check uses split("@") + strict equality, NOT endsWith(),
 * because endsWith("@gmail.com") would accept "user@gmail.com.evil.com"
 * (which ends with "@gmail.com" as a substring). The split approach
 * extracts the exact domain and compares it.
 *
 * Examples:
 *   user@gmail.com          → ✅ accepted
 *   USER@GMAIL.COM          → ✅ normalized to user@gmail.com → accepted
 *   user@yahoo.com           → ❌ rejected ("Only Gmail addresses are allowed")
 *   user@gmail.com.evil.com → ❌ rejected (domain is "gmail.com.evil.com")
 *   gmail.com.evil.com      → ❌ rejected (not a valid email — no @)
 */
export const EMAIL_SCHEMA = z
  .string()
  .trim()
  .toLowerCase()
  .email("Invalid email address")
  .max(254)
  .refine(
    (email) => {
      const parts = email.split("@");
      return parts.length === 2 && parts[1] === "gmail.com";
    },
    "Only @gmail.com email addresses are accepted"
  );

export const FULL_NAME_SCHEMA = z
  .string()
  .trim()
  .min(2, "Full name must be at least 2 characters")
  .max(80, "Full name is too long")
  .refine((v) => !/[<>]/.test(v), "Full name contains invalid characters");

export const PASSWORD_SCHEMA = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .max(128, "Password is too long")
  .refine(
    (v) => /[a-zA-Z]/.test(v) && /[0-9]/.test(v),
    "Password must contain letters and numbers"
  );

export const MESSAGE_SCHEMA = z
  .string()
  .trim()
  .min(1, "Message cannot be empty")
  .max(4000, "Message is too long (4000 characters max)");

export const REPORT_REASON_SCHEMA = z.enum([
  "SPAM",
  "ABUSE",
  "HARASSMENT",
  "OTHER",
]);

export const REPORT_DESCRIPTION_SCHEMA = z
  .string()
  .trim()
  .min(10, "Please describe the issue (at least 10 characters)")
  .max(2000, "Description is too long");

/** Strip control characters and normalize whitespace. Used before persisting user text. */
export function normalizeText(input: string): string {
  return input.replace(/\r\n/g, "\n").replace(/\u0000/g, "").trim();
}

/**
 * Validate an externally-hosted image URL (profile picture, article cover,
 * etc.).
 *
 * SECURITY (spec §15 — never trust image URLs from the client):
 *   - Only http:// and https:// protocols are allowed.
 *   - Reject javascript:, data:, vbscript:, file:, blob:, about: and any
 *     other scheme that could execute script or render arbitrary content.
 *   - Cap the length to a reasonable maximum (2048 chars) to prevent
 *     database bloat + reject obvious abuse.
 *   - Trim whitespace.
 *
 * Returns:
 *   - `null` when the input is empty, null, undefined, or fails validation
 *     (the caller treats this as "no URL set" — never persists garbage).
 *   - The trimmed URL string when valid.
 *
 * NOTE: We do NOT verify here that the URL actually points to an image —
 * that's the browser's job (the <img> tag's onError handler displays a
 * fallback). Server-side we only ensure the URL is SAFE to persist + render
 * (i.e. cannot execute script). The CSP in `src/proxy.ts` further restricts
 * which hosts can serve images to the platform.
 *
 * @param url raw input from the client
 * @param maxLen optional max length (default 2048)
 */
export function validateImageUrl(
  url: string | null | undefined,
  maxLen = 2048
): string | null {
  if (url == null) return null;
  if (typeof url !== "string") return null;
  const trimmed = url.trim();
  if (!trimmed) return null;
  if (trimmed.length > maxLen) return null;
  // Reject dangerous schemes FIRST (defense-in-depth — even if the regex
  // below would also reject them, this makes the intent explicit).
  // Note: we test against the lowercased trimmed string for case-insensitive
  // matching. Some browsers normalize `JavaScript:` to `javascript:`.
  const lower = trimmed.toLowerCase();
  if (
    lower.startsWith("javascript:") ||
    lower.startsWith("data:") ||
    lower.startsWith("vbscript:") ||
    lower.startsWith("file:") ||
    lower.startsWith("blob:") ||
    lower.startsWith("about:")
  ) {
    return null;
  }
  // Only allow http:// and https:// protocols. Anchor with ^ to prevent
  // scheme-prefix tricks like "https://evil.com javascript:alert(1)".
  if (!/^https?:\/\//i.test(trimmed)) return null;
  // Reject any whitespace inside the URL — legitimate image URLs never
  // contain raw spaces. This catches payloads like
  // "https://evil.com/ x javascript:alert(1)".
  if (/\s/.test(trimmed)) return null;
  // Reject any backslash — `new URL()` in browsers normalizes `\` to `/`,
  // which can be abused to smuggle protocols. Rejecting it outright is
  // the safe choice.
  if (/\\/.test(trimmed)) return null;
  return trimmed;
}

/** Escape HTML for safe text rendering in admin tables. */
export function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * Sanitize a metadata object for audit logging. Removes any key whose name matches
 * a sensitive pattern, plus any string value that looks like a connection string.
 */
export function sanitizeMetadata(
  meta: Record<string, unknown>
): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  const sensitive = /password|secret|token|cookie|authorization|apikey|api_key|database_url/i;
  for (const [k, v] of Object.entries(meta)) {
    if (sensitive.test(k)) {
      out[k] = "[REDACTED]";
      continue;
    }
    if (typeof v === "string" && /(postgres|mongodb|redis):\/\/[^\s]+/i.test(v)) {
      out[k] = "[REDACTED]";
      continue;
    }
    out[k] = v;
  }
  return out;
}
