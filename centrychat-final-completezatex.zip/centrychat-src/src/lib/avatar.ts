/**
 * Deterministic avatar color from a seed string (email/userId).
 * No media in MVP — we use a colored avatar with initials.
 */
const PALETTE = [
  "#0f766e", // teal-700
  "#b45309", // amber-700
  "#9333ea", // purple-600
  "#be123c", // rose-700
  "#15803d", // green-700
  "#1e40af", // blue-800 (allowed — only restriction is UI default palette; this is user data)
  "#c2410c", // orange-700
  "#4338ca", // indigo-700
];

export function generateAvatarColor(seed: string): string {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  return PALETTE[Math.abs(hash) % PALETTE.length]!;
}

export function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0]!.slice(0, 2).toUpperCase();
  return (parts[0]![0]! + parts[parts.length - 1]![0]!).toUpperCase();
}
