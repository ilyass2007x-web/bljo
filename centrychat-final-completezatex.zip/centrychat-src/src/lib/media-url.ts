/**
 * URL classification helpers — shared by the Profile Image URL field,
 * Article editor's image URL field, and Article editor's video URL field.
 *
 * Why this exists (spec §4 — Pinterest, §6 — Article Image Preview,
 * §7-9 — Video URL, §19 — Image URL CORS, §24 — Security):
 *
 *   The previous implementation gave the same generic "Unable to load
 *   this image." message for ALL image load failures. The user couldn't
 *   tell whether:
 *     - the URL was syntactically invalid,
 *     - the URL pointed to a webpage (e.g. a Pinterest pin) rather than
 *       a direct image,
 *     - the URL was a direct image but the host blocked hotlinking,
 *     - or the image just didn't exist.
 *
 *   This module differentiates the cases so the UI can show a useful,
 *   actionable error message instead of the same generic failure.
 *
 * SECURITY (spec §24): all of these helpers reject javascript:, data:,
 * vbscript:, file:, blob:, about: schemes. Only http:// and https:// are
 * allowed. The actual rendering still happens via <img onError> (for
 * images) or <video onError> (for direct video files), so the browser
 * remains the final source of truth for whether the URL is actually
 * renderable.
 */

/**
 * Hosts that are known to serve WEBPAGES (not direct images). Pasting a
 * URL from one of these hosts as a "Profile Picture URL" or "Article
 * Cover Image URL" is almost always a user error — they pasted a pin URL,
 * an Instagram post URL, etc. instead of the direct image file.
 *
 * The list is intentionally short + curated. We do NOT try to be
 * exhaustive — unknown hosts fall through to the regular "load + see if
 * it errors" path. We only call out the well-known social sites that
 * users consistently confuse for direct image hosts.
 *
 * NOTE: this is for UX guidance only — we never REFUSE the URL based on
 * host alone. The user might legitimately have a direct image URL on
 * one of these hosts (e.g. i.pinimg.com is Pinterest's CDN and serves
 * real images). The check is just used to render a more specific
 * helpful message when <img onError> eventually fires.
 *
 * @internal
 */
const KNOWN_WEBPAGE_HOSTS: ReadonlySet<string> = new Set([
  "pinterest.com",
  "www.pinterest.com",
  "pin.it",
  "instagram.com",
  "www.instagram.com",
  "facebook.com",
  "www.facebook.com",
  "fb.com",
  "twitter.com",
  "www.twitter.com",
  "x.com",
  "www.x.com",
  "tiktok.com",
  "www.tiktok.com",
  "linkedin.com",
  "www.linkedin.com",
  "reddit.com",
  "www.reddit.com",
  "snapchat.com",
  "weibo.com",
  "www.weibo.com",
]);

/**
 * Extract the hostname from a URL string. Returns the lowercased
 * hostname (without port) or null if the URL is malformed.
 *
 * @example
 *   hostnameOf("https://example.com/path")  // "example.com"
 *   hostnameOf("https://i.pinimg.com/x.jpg")  // "i.pinimg.com"
 *   hostnameOf("garbage")  // null
 */
function hostnameOf(url: string): string | null {
  try {
    // `new URL` throws on bare strings without a scheme. Prepend
    // "https:" if missing so the parser has something to anchor on.
    // (We only call this AFTER validateImageUrl has confirmed the URL
    // starts with http:// or https:// — but be defensive anyway.)
    const u = new URL(url);
    return u.hostname.toLowerCase();
  } catch {
    return null;
  }
}

/**
 * Validate that an image URL is syntactically safe:
 *   - Only http:// and https:// protocols are allowed.
 *   - Rejects javascript:, data:, vbscript:, file:, blob:, about:.
 *   - Caps length at 2048 chars.
 *   - Trims whitespace + rejects whitespace + backslashes inside the URL.
 *
 * Returns:
 *   - `null` when input is empty/null/undefined (means "no URL set").
 *   - `null` when input fails validation (the caller should treat
 *     this as "syntactically invalid").
 *   - The trimmed URL string when valid.
 *
 * Server-side validation (see src/lib/security/sanitize.ts →
 * `validateImageUrl`) is the source of truth — this is a client-side
 * mirror for instant feedback.
 */
export function isValidImageUrl(raw: string | null | undefined): string | null {
  if (raw == null) return null;
  if (typeof raw !== "string") return null;
  const trimmed = raw.trim();
  if (!trimmed) return null;
  if (trimmed.length > 2048) return null;
  const lower = trimmed.toLowerCase();
  if (
    lower.startsWith("javascript:") ||
    lower.startsWith("data:") ||
    lower.startsWith("vbscript:") ||
    lower.startsWith("file:") ||
    lower.startsWith("blob:") ||
    lower.startsWith("about:")
  ) {
    return null;
  }
  if (!/^https?:\/\//i.test(trimmed)) return null;
  if (/\s/.test(trimmed)) return null;
  if (/\\/.test(trimmed)) return null;
  return trimmed;
}

/**
 * The result of classifying an image URL.
 *   - "valid"           → URL is syntactically valid; the browser should
 *                         attempt to load it. The actual load result
 *                         (loaded vs. error) is determined by the
 *                         <img> element's onLoad/onError events.
 *   - "empty"           → no URL entered (the form should show the
 *                         initials avatar / fallback).
 *   - "invalid"         → URL doesn't start with http:// or https://,
 *                         or uses a dangerous scheme. The form should
 *                         show "URL must start with http:// or https://".
 *   - "known-webpage"   → URL syntactically valid AND host is a known
 *                         social-media site that serves webpages (not
 *                         direct images). The form should show a
 *                         helpful message like "This looks like a
 *                         Pinterest page URL. Please use a direct
 *                         image URL."
 */
export type ImageUrlClassification =
  | { kind: "empty" }
  | { kind: "invalid" }
  | { kind: "known-webpage"; url: string; host: string }
  | { kind: "valid"; url: string };

/**
 * Classify an image URL for the form's preview/error display logic.
 *
 * This does NOT decide whether to RENDER the image — that's the
 * browser's job. It only decides which helpful message to show BEFORE
 * the image finishes loading (or fails to load).
 */
export function classifyImageUrl(raw: string): ImageUrlClassification {
  const trimmed = raw.trim();
  if (!trimmed) return { kind: "empty" };
  const valid = isValidImageUrl(trimmed);
  if (!valid) return { kind: "invalid" };
  const host = hostnameOf(valid);
  if (host && KNOWN_WEBPAGE_HOSTS.has(host)) {
    return { kind: "known-webpage", url: valid, host };
  }
  return { kind: "valid", url: valid };
}

// ─────────────────────────────────────────────────────────────────────
// Video URL classification
// ─────────────────────────────────────────────────────────────────────

/**
 * Recognized video provider / type.
 *   - "youtube"  → https://www.youtube.com/watch?v=ID  |  https://youtu.be/ID
 *                  (also handles embed URLs, /shorts/ URLs, and t= param)
 *   - "vimeo"    → https://vimeo.com/ID  |  https://player.vimeo.com/video/ID
 *   - "direct"   → direct video file URL (any extension in VIDEO_FILE_EXTS)
 *   - "unknown"  → URL is syntactically valid http(s) but doesn't match
 *                  any of the above patterns. The browser may still be
 *                  able to play it via <video> if the response has a
 *                  video Content-Type — but we won't know until we try.
 */
export type VideoClassification =
  | { kind: "empty" }
  | { kind: "invalid" }
  | { kind: "youtube"; url: string; videoId: string; embedUrl: string }
  | { kind: "vimeo"; url: string; videoId: string; embedUrl: string }
  | { kind: "direct"; url: string; ext: string }
  | { kind: "unknown"; url: string };

/**
 * File extensions recognized as direct video files by the HTML5
 * <video> element. .mov is added for iOS-recorded videos (Safari
 * supports it; other browsers may or may not).
 */
const VIDEO_FILE_EXTS = ["mp4", "webm", "ogg", "ogv", "mov", "m4v", "mkv"] as const;

/**
 * Parse a YouTube URL and return the 11-char video ID, or null.
 *
 * Accepted URL formats (per spec §8):
 *   - https://www.youtube.com/watch?v=VIDEO_ID           ← canonical
 *   - https://youtube.com/watch?v=VIDEO_ID               ← no www
 *   - https://youtu.be/VIDEO_ID                          ← short
 *   - https://www.youtube.com/embed/VIDEO_ID             ← embed
 *   - https://www.youtube.com/shorts/VIDEO_ID            ← Shorts
 *   - https://m.youtube.com/watch?v=VIDEO_ID             ← mobile
 *
 * YouTube video IDs are always 11 chars: [A-Za-z0-9_-]{11}.
 *
 * Trailing params like &t=30s, &feature=share, &list=... are ignored
 * — the regex only captures the 11 chars after the v= (or after the
 * path segment for embed/shorts/youtu.be URLs).
 */
function parseYouTubeId(url: string): string | null {
  // Try the most common formats first (most specific → least specific).
  // youtu.be/ID  →  11 chars after the path (no query needed).
  const shortMatch = url.match(/youtu\.be\/([A-Za-z0-9_-]{11})(?:[?#]|$)/);
  if (shortMatch) return shortMatch[1]!;
  // youtube.com/embed/ID  or  youtube.com/shorts/ID
  const pathMatch = url.match(/youtube\.com\/(?:embed|shorts)\/([A-Za-z0-9_-]{11})(?:[?#]|$)/);
  if (pathMatch) return pathMatch[1]!;
  // youtube.com/watch?v=ID  (with optional other params)
  const watchMatch = url.match(/[?&]v=([A-Za-z0-9_-]{11})(?:&|$)/);
  if (watchMatch) return watchMatch[1]!;
  return null;
}

/**
 * Parse a Vimeo URL and return the numeric video ID, or null.
 *
 * Accepted formats:
 *   - https://vimeo.com/ID
 *   - https://www.vimeo.com/ID
 *   - https://player.vimeo.com/video/ID
 *   - https://vimeo.com/channels/staffpicks/ID
 */
function parseVimeoId(url: string): string | null {
  const m = url.match(/vimeo\.com\/(?:video\/|channels\/[^/]+\/)?(\d+)(?:[?#]|$)/);
  return m ? m[1]! : null;
}

/**
 * Get the lowercased file extension from a URL (without the dot).
 * Returns null if no extension is found.
 *
 * Strips the query string + fragment before extracting the extension.
 * @example
 *   extOf("https://example.com/video.mp4?t=10")  // "mp4"
 *   extOf("https://example.com/path/")           // null
 */
function extOf(url: string): string | null {
  const noQuery = url.split(/[?#]/)[0]!;
  const lastSlash = noQuery.lastIndexOf("/");
  const filename = lastSlash >= 0 ? noQuery.slice(lastSlash + 1) : noQuery;
  const dot = filename.lastIndexOf(".");
  if (dot <= 0) return null;
  return filename.slice(dot + 1).toLowerCase();
}

/**
 * Classify a video URL for the editor + reading page.
 *
 * Returns the classification with the original URL, the embed URL (for
 * YouTube/Vimeo), or the file extension (for direct files).
 *
 * "unknown" doesn't mean "won't play" — it means the URL didn't match
 * a known provider pattern, so we can't predict whether it'll play.
 * The UI should attempt <video src={url}> and let the browser decide.
 */
export function classifyVideoUrl(raw: string): VideoClassification {
  const trimmed = raw.trim();
  if (!trimmed) return { kind: "empty" };
  const valid = isValidImageUrl(trimmed);
  if (!valid) return { kind: "invalid" };

  // YouTube
  const ytId = parseYouTubeId(valid);
  if (ytId) {
    return {
      kind: "youtube",
      url: valid,
      videoId: ytId,
      embedUrl: `https://www.youtube-nocookie.com/embed/${ytId}`,
    };
  }

  // Vimeo
  const vimeoId = parseVimeoId(valid);
  if (vimeoId) {
    return {
      kind: "vimeo",
      url: valid,
      videoId: vimeoId,
      embedUrl: `https://player.vimeo.com/video/${vimeoId}`,
    };
  }

  // Direct video file
  const ext = extOf(valid);
  if (ext && (VIDEO_FILE_EXTS as readonly string[]).includes(ext)) {
    return { kind: "direct", url: valid, ext };
  }

  // Syntactically valid http(s) URL but not a known provider — let the
  // browser decide.
  return { kind: "unknown", url: valid };
}
