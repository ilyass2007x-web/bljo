import { NextResponse } from "next/server";
import { pingDatabase } from "@/lib/database";

export const dynamic = "force-dynamic";

export async function GET() {
  // Readiness: verify required dependencies (database connectivity).
  const db = await pingDatabase();
  if (!db.ok) {
    return NextResponse.json(
      { status: "not_ready", database: { ok: false, error: db.error } },
      { status: 503 }
    );
  }
  return NextResponse.json({
    status: "ready",
    database: { ok: true, latencyMs: db.latencyMs },
    timestamp: new Date().toISOString(),
  });
}
