import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getDatabaseProvider, pingDatabase } from "@/lib/database";
import { getStorageProvider } from "@/lib/storage";
import { getEmailProvider } from "@/lib/email";
import { getCache } from "@/lib/cache";
import { getJobs } from "@/lib/jobs";
import { getSetting } from "@/lib/settings";
import { cacheGetOrSet } from "@/lib/cache";
import { logger } from "@/lib/logging";
import { db } from "@/lib/database";

export const GET = apiHandler(async () => {
  await requireAdmin();

  const cacheKey = "admin:system-health";
  const TTL = 30;

  const result = await cacheGetOrSet(cacheKey, TTL, async () => {
    const now = new Date();

    const app = {
      environment: process.env.NODE_ENV ?? "development",
      nodeVersion: process.version,
      platform: process.platform,
      uptimeSeconds: Math.round(process.uptime()),
      memoryUsageMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
      buildId: process.env.NETLIFY ? "netlify" : "local",
      timestamp: now.toISOString(),
    };

    let database: { status: string; provider: string; latencyMs: number | null; ok: boolean };
    try {
      const dbPing = await pingDatabase();
      database = { status: dbPing.ok ? "healthy" : "unavailable", provider: getDatabaseProvider(), latencyMs: dbPing.latencyMs, ok: dbPing.ok };
    } catch (err) {
      database = { status: "unavailable", provider: getDatabaseProvider(), latencyMs: null, ok: false };
    }

    const auth = { status: "healthy", provider: "iron-session", note: "Always available (signed/encrypted cookies)." };
    const api = { status: "healthy", note: "This endpoint responding confirms API availability." };

    let messaging: { status: string; conversations: number | null; messages: number | null; realtime: string };
    try {
      const [convCount, msgCount] = await Promise.all([
        db.conversation.count().catch(() => null),
        db.message.count({ where: { deletedAt: null } }).catch(() => null),
      ]);
      messaging = { status: convCount != null ? "healthy" : "degraded", conversations: convCount, messages: msgCount, realtime: process.env.REALTIME_INTERNAL_URL ? "socket.io (configured)" : "disabled (polling fallback)" };
    } catch { messaging = { status: "unavailable", conversations: null, messages: null, realtime: "unknown" }; }

    let search: { status: string; totalSearches: number | null };
    try { const count = await db.searchQueryLog.count().catch(() => null); search = { status: count != null ? "healthy" : "degraded", totalSearches: count }; }
    catch { search = { status: "not_monitored", totalSearches: null }; }

    let algorithm: { status: string; weightsConfigured: boolean };
    try { const w = await getSetting("algorithm.weight.velocityBonus"); algorithm = { status: "healthy", weightsConfigured: w != null }; }
    catch { algorithm = { status: "not_monitored", weightsConfigured: false }; }

    const trending = { status: "healthy", note: "Uses the same scoreAndRankContent engine as the feed." };
    const seo = { status: "healthy", sitemap: "auto-generated at /sitemap.xml", robots: "auto-generated at /robots.txt" };

    const emailProvider = getEmailProvider();
    const resend = { status: emailProvider.name === "resend" ? "healthy" : emailProvider.name === "console" ? "not_monitored" : "unknown", provider: emailProvider.name, note: emailProvider.name === "console" ? "Console (dev mode)." : "Resend API configured." };

    const storageProvider = getStorageProvider();
    const cloudinary = { status: storageProvider.name === "noop" ? "not_monitored" : "healthy", provider: storageProvider.name, note: storageProvider.name === "noop" ? "No storage provider (text-only MVP)." : "Storage configured." };

    const cache = getCache();
    const cacheInfo = { status: "healthy", provider: cache.name, note: cache.name === "memory" ? "In-memory (per-process)." : "External cache." };
    const jobs = getJobs();
    const jobsInfo = { status: "healthy", provider: jobs.name, note: "Background job queue." };

    const responseTime = {
      dbLatencyMs: database.latencyMs,
      rating: database.latencyMs == null ? "unknown" : database.latencyMs < 50 ? "excellent" : database.latencyMs < 200 ? "good" : database.latencyMs < 1000 ? "slow" : "critical",
      apiLatencyMs: null,
      note: "DB latency via lightweight count(). API latency not tracked.",
    };

    const deployment = {
      platform: process.env.NETLIFY ? "Netlify (serverless)" : "Local/Custom",
      database: "Neon (PostgreSQL serverless)",
      note: "No local disk persistence. Prisma with connection pooling.",
    };

    const services = [
      { name: "Application", status: "healthy", details: `${app.environment} · Node ${app.nodeVersion} · ${app.uptimeSeconds}s uptime` },
      { name: "Database", status: database.status, details: `${database.provider} · ${database.latencyMs ?? "?"}ms latency` },
      { name: "Authentication", status: auth.status, details: auth.provider },
      { name: "API", status: api.status, details: "Responding" },
      { name: "Messaging", status: messaging.status, details: `${messaging.conversations ?? "?"} conversations · realtime: ${messaging.realtime}` },
      { name: "Search", status: search.status, details: `${search.totalSearches ?? "?"} total searches logged` },
      { name: "Algorithm", status: algorithm.status, details: algorithm.weightsConfigured ? "Custom weights active" : "Default weights" },
      { name: "Trending", status: trending.status, details: trending.note },
      { name: "SEO", status: seo.status, details: `${seo.sitemap} · ${seo.robots}` },
      { name: "Resend (Email)", status: resend.status, details: resend.provider },
      { name: "Cloudinary (Storage)", status: cloudinary.status, details: cloudinary.provider },
      { name: "Cache", status: cacheInfo.status, details: cacheInfo.provider },
      { name: "Jobs", status: jobsInfo.status, details: jobsInfo.provider },
    ];

    const overallHealth = database.status === "healthy" && auth.status === "healthy" && api.status === "healthy" ? "healthy" : "degraded";

    return { app, database, auth, api, messaging, search, algorithm, trending, seo, resend, cloudinary, cache: cacheInfo, jobs: jobsInfo, responseTime, deployment, services, overallHealth, lastChecked: now.toISOString() };
  });

  return ok({ health: result });
});
