import { apiHandler, ok, notFound, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getClientIp } from "@/lib/security/rate-limit";
import { recordAudit } from "@/lib/audit";
import { db } from "@/lib/database";
import {
  updateBlockedDomain,
  deleteBlockedDomain,
} from "@/lib/security/domain-blocklist";

/**
 * PATCH /api/v1/admin/blocked-domains/[id]
 * -----------------------------------------
 * Update a blocked domain rule (reason, notes, isActive, blockSubdomains).
 *
 * Body (all fields optional):
 *   { reason?, notes?, isActive?, blockSubdomains? }
 *
 * Used by the admin UI to:
 *   - Enable/disable a rule (isActive toggle)
 *   - Edit reason/notes
 *   - Toggle subdomain blocking
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return badRequest("Invalid rule id.");

  const body = await req.json().catch(() => ({} as Record<string, unknown>));

  const update: {
    reason?: string;
    notes?: string;
    isActive?: boolean;
    blockSubdomains?: boolean;
  } = {};

  if (typeof body.reason === "string") update.reason = body.reason;
  if (typeof body.notes === "string") update.notes = body.notes;
  if (typeof body.isActive === "boolean") update.isActive = body.isActive;
  if (typeof body.blockSubdomains === "boolean") update.blockSubdomains = body.blockSubdomains;

  try {
    const rule = await updateBlockedDomain(id, update);

    await recordAudit({
      adminId: admin.id,
      action: body.isActive === false
        ? "admin.domain.disabled"
        : body.isActive === true
          ? "admin.domain.enabled"
          : "admin.domain.updated",
      targetType: "blocked_domain",
      targetId: id,
      metadata: {
        domain: rule.normalizedDomain,
        changes: update,
      },
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });

    return ok({ rule, updated: true });
  } catch {
    return notFound("Blocked domain rule not found.");
  }
});

/**
 * DELETE /api/v1/admin/blocked-domains/[id]
 * ------------------------------------------
 * Permanently delete a blocked domain rule.
 * (Cascade-deletes all BlockedDomainHit rows for this rule.)
 *
 * The admin UI should require confirmation before calling this.
 * Prefer PATCH { isActive: false } for soft-disable.
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return badRequest("Invalid rule id.");

  // Fetch the rule first (to record its domain in the audit log before deletion).
  const rule = await db.blockedDomain.findUnique({
    where: { id },
    select: { normalizedDomain: true },
  });
  if (!rule) return notFound("Blocked domain rule not found.");

  await deleteBlockedDomain(id);

  await recordAudit({
    adminId: admin.id,
    action: "admin.domain.deleted",
    targetType: "blocked_domain",
    targetId: id,
    metadata: { domain: rule.normalizedDomain },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ deleted: true });
});
