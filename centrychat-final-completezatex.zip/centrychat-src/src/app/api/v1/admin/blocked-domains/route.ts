import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { checkRateLimit, RATE_LIMITS, getClientIp } from "@/lib/security/rate-limit";
import { recordAudit } from "@/lib/audit";
import { db } from "@/lib/database";
import {
  createBlockedDomain,
  getBlocklistStats,
} from "@/lib/security/domain-blocklist";

/**
 * GET /api/v1/admin/blocked-domains
 * ----------------------------------
 * List all blocked domain rules (active + disabled). Supports search +
 * status filter + pagination.
 *
 * Query params:
 *   - q        (search by domain or reason)
 *   - status   ("active" | "disabled" | "all")
 *   - page     (default 1)
 *   - pageSize (default 50, max 100)
 *
 * Also returns aggregate stats at the top of the response.
 */
export const GET = apiHandler(async (req) => {
  await requireAdmin();

  const url = new URL(req.url);
  const q = url.searchParams.get("q")?.trim() || "";
  const status = url.searchParams.get("status") || "all";
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(100, Math.max(1, Number(url.searchParams.get("pageSize") ?? "50")));

  const where: {
    isActive?: boolean;
    OR?: Array<{
      domain?: { contains: string; mode?: "insensitive" };
      reason?: { contains: string; mode?: "insensitive" };
      normalizedDomain?: { contains: string; mode?: "insensitive" };
    }>;
  } = {};
  if (status === "active") where.isActive = true;
  else if (status === "disabled") where.isActive = false;
  if (q) {
    where.OR = [
      { domain: { contains: q, mode: "insensitive" } },
      { reason: { contains: q, mode: "insensitive" } },
      { normalizedDomain: { contains: q, mode: "insensitive" } },
    ];
  }

  const [rules, total, stats] = await Promise.all([
    db.blockedDomain.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        creator: { select: { fullName: true, username: true } },
      },
    }),
    db.blockedDomain.count({ where }),
    getBlocklistStats(),
  ]);

  return ok({
    rules: rules.map((r) => ({
      id: r.id,
      domain: r.domain,
      normalizedDomain: r.normalizedDomain,
      reason: r.reason,
      notes: r.notes,
      isActive: r.isActive,
      blockSubdomains: r.blockSubdomains,
      hitCount: r.hitCount,
      createdAt: r.createdAt.toISOString(),
      updatedAt: r.updatedAt.toISOString(),
      createdBy: r.createdBy,
      creatorName: r.creator?.fullName ?? null,
      creatorUsername: r.creator?.username ?? null,
    })),
    total,
    page,
    pageSize,
    stats,
  });
});

/**
 * POST /api/v1/admin/blocked-domains
 * -----------------------------------
 * Add a new domain to the blocklist.
 *
 * Body:
 *   { domain: string, reason?: string, notes?: string,
 *     isActive?: boolean, blockSubdomains?: boolean }
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const rl = await checkRateLimit(`admin-write:${admin.id}`, RATE_LIMITS.adminWrite);
  if (!rl.ok) return badRequest("Rate limit exceeded. Please slow down.");

  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const domain = typeof body.domain === "string" ? body.domain.trim() : "";
  if (!domain) return badRequest("Domain is required.");

  try {
    const rule = await createBlockedDomain({
      domain,
      reason: typeof body.reason === "string" ? body.reason : undefined,
      notes: typeof body.notes === "string" ? body.notes : undefined,
      isActive: typeof body.isActive === "boolean" ? body.isActive : true,
      blockSubdomains: typeof body.blockSubdomains === "boolean" ? body.blockSubdomains : true,
      adminId: admin.id,
    });

    await recordAudit({
      adminId: admin.id,
      action: "admin.domain.blocked",
      targetType: "blocked_domain",
      targetId: rule.id,
      metadata: {
        domain: rule.normalizedDomain,
        blockSubdomains: rule.blockSubdomains,
        isActive: rule.isActive,
      },
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });

    return ok({ rule, created: true });
  } catch (err) {
    return badRequest(err instanceof Error ? err.message : "Failed to create block rule.");
  }
});
