import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * GET /api/v1/admin/blocked-domains/hits
 * ---------------------------------------
 * List "Blocked Activity" — the audit trail of every blocked URL attempt.
 *
 * Query params:
 *   - domainId  (filter by BlockedDomain.id)
 *   - context   (ARTICLE | POST | COMMENT | REPLY | PROFILE | MESSAGE | MEDIA | OTHER)
 *   - userId    (filter by user who attempted it)
 *   - page      (default 1)
 *   - pageSize  (default 50, max 100)
 *
 * Returns the hits newest-first, with the blocked domain + user info joined.
 */
export const GET = apiHandler(async (req) => {
  await requireAdmin();

  const url = new URL(req.url);
  const domainId = url.searchParams.get("domainId") || undefined;
  const context = url.searchParams.get("context") || undefined;
  const userId = url.searchParams.get("userId") || undefined;
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(100, Math.max(1, Number(url.searchParams.get("pageSize") ?? "50")));

  const where: {
    blockedDomainId?: string;
    context?: string;
    userId?: string;
  } = {};
  if (domainId) where.blockedDomainId = domainId;
  if (context) where.context = context;
  if (userId) where.userId = userId;

  const [hits, total] = await Promise.all([
    db.blockedDomainHit.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        blockedDomain: { select: { domain: true, normalizedDomain: true, reason: true } },
        user: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true } },
      },
    }),
    db.blockedDomainHit.count({ where }),
  ]);

  return ok({
    hits: hits.map((h) => ({
      id: h.id,
      domain: h.blockedDomain?.domain ?? "(deleted rule)",
      normalizedDomain: h.blockedDomain?.normalizedDomain ?? "",
      reason: h.blockedDomain?.reason ?? null,
      context: h.context,
      attemptedUrl: h.attemptedUrl,
      createdAt: h.createdAt.toISOString(),
      user: h.user
        ? {
            id: h.user.id,
            fullName: h.user.fullName,
            username: h.user.username,
            avatarColor: h.user.avatarColor,
            avatarUrl: h.user.avatarUrl,
          }
        : null,
    })),
    total,
    page,
    pageSize,
  });
});
