import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/admin/audit
 * ------------------------
 * Admin Audit Logs (spec §27-§33 — PHASE 10).
 *
 * Enhanced with search + filters (spec §30, §31):
 *   - Search by action, admin name, target ID.
 *   - Filter by action, targetType, date range.
 *   - Paginated (spec §29).
 *
 * SECURITY (spec §33):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Audit logs are append-only (no delete/edit endpoints — spec §33).
 *   - No secrets, passwords, or tokens in metadata (sanitized by recordAudit).
 *   - Search only safe fields (action, targetType, targetId — not metadata content).
 *
 * IMMUTABILITY (spec §33):
 *   This endpoint is READ-ONLY. No POST/PATCH/DELETE.
 *   Audit logs can only be created (via recordAudit), never modified.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const url = new URL(req.url);
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(100, Number(url.searchParams.get("pageSize") ?? "50"));
  const action = url.searchParams.get("action") ?? "";
  const targetType = url.searchParams.get("targetType") ?? "";
  const q = (url.searchParams.get("q") ?? "").trim();
  const sortBy = url.searchParams.get("sortBy") ?? "newest";

  // Build WHERE.
  const where: Prisma.AdminAuditLogWhereInput = {
    AND: [
      action ? { action } : {},
      targetType ? { targetType } : {},
      q ? {
        OR: [
          { action: { contains: q, mode: "insensitive" } },
          { targetId: { contains: q, mode: "insensitive" } },
          { admin: { fullName: { contains: q, mode: "insensitive" } } },
          { admin: { email: { contains: q, mode: "insensitive" } } },
        ],
      } : {},
    ],
  };

  const orderBy: Prisma.AdminAuditLogOrderByWithRelationInput =
    sortBy === "oldest" ? { createdAt: "asc" } : { createdAt: "desc" };

  const [logs, total] = await Promise.all([
    db.adminAuditLog.findMany({
      where,
      orderBy,
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        admin: { select: { id: true, fullName: true, email: true, role: true } },
      },
    }),
    db.adminAuditLog.count({ where }),
  ]);

  // Don't record an audit log for VIEWING audit logs (would be recursive noise).
  // Only record if this is a search (not a default listing).
  if (q || action || targetType) {
    await recordAudit({
      adminId: admin.id,
      action: "admin.audit.search",
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
      metadata: { q, action, targetType },
    });
  }

  return ok({
    logs: logs.map((l) => ({
      id: l.id,
      adminId: l.adminId,
      admin: l.admin,
      action: l.action,
      targetType: l.targetType,
      targetId: l.targetId,
      metadata: l.metadata ? (() => { try { return JSON.parse(l.metadata); } catch { return null; } })() : null,
      ipAddress: l.ipAddress,
      userAgent: l.userAgent,
      createdAt: l.createdAt.toISOString(),
    })),
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
  });
});
