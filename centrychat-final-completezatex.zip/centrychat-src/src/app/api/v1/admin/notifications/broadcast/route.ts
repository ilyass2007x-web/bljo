import { apiHandler, badRequest, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { sendNotificationEmail } from "@/lib/email";

export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    title?: string;
    message?: string;
    scope?: "all" | "active";
  }>(req);
  if (!body.title || !body.message) {
    return badRequest("title and message are required");
  }

  const users = await db.user.findMany({
    where: body.scope === "active" ? { status: "ACTIVE" } : {},
    select: { id: true, email: true },
  });

  // Create in-app notifications.
  await db.notification.createMany({
    data: users.map((u) => ({
      userId: u.id,
      type: "SYSTEM",
      title: body.title!,
      message: body.message!,
      metadata: JSON.stringify({ from: "admin", adminId: admin.id }),
    })),
  });

  // Best-effort email to active users with verified email.
  for (const u of users) {
    if (u.email) {
      try {
        await sendNotificationEmail(u.email, `[Broadcast] ${body.title}`, body.message);
      } catch {
        /* ignore */
      }
    }
  }

  await recordAudit({
    adminId: admin.id,
    action: "admin.notification.broadcast",
    metadata: { title: body.title, scope: body.scope ?? "all", recipients: users.length },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ sent: true, recipients: users.length });
});
