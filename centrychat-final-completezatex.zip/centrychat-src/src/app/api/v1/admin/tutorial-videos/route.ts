import { apiHandler, ok, badRequest, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  listTutorialVideoRecords,
  saveTutorialVideo,
  validateYouTubeUrl,
  TUTORIAL_LOCATIONS,
  TUTORIAL_LOCATION_META,
  type TutorialLocation,
} from "@/lib/tutorial-videos";

/**
 * GET /api/v1/admin/tutorial-videos
 * --------------------------------
 * Returns ALL tutorial video records (including disabled ones) so the
 * admin UI can show what's configured + let the admin edit/enable/disable.
 *
 * Admin-only — uses `requireAdmin()` (server-enforced RBAC). The
 * response shape is `{ tutorials: [{ location, record }, ...] }` where
 * `record` may be null for locations that haven't been configured yet.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  await recordAudit({
    adminId: admin.id,
    action: "admin.tutorial-videos.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  const tutorials = await listTutorialVideoRecords();
  return ok({ tutorials });
});

/**
 * PATCH /api/v1/admin/tutorial-videos
 * -----------------------------------
 * Save (create or update) ONE tutorial video. The request body is:
 *
 *   {
 *     "location": "PROFILE_IMAGE_TUTORIAL",
 *     "youtubeUrl": "https://youtube.com/watch?v=...",
 *     "enabled": true
 *   }
 *
 * Behavior:
 *   - Validates the YouTube URL via the existing `parseYouTube` helper
 *     (NOT modified). Rejects non-YouTube URLs with a descriptive error.
 *   - The thumbnail URL is derived from the video ID — admins never
 *     enter a thumbnail URL (spec §4).
 *   - Each location is fully independent (spec §9) — saving the PROFILE
 *     tutorial does NOT touch the ARTICLE tutorial, and vice versa.
 *   - Records an audit log entry for every save (admin accountability).
 *
 * Returns the saved record.
 */
export const PATCH = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    location?: string;
    youtubeUrl?: string;
    enabled?: boolean;
  }>(req);

  // Validate location.
  if (!body.location || !(TUTORIAL_LOCATIONS as readonly string[]).includes(body.location)) {
    return badRequest("Unknown tutorial location.");
  }
  const location = body.location as TutorialLocation;

  // Validate YouTube URL.
  const youtubeUrl = typeof body.youtubeUrl === "string" ? body.youtubeUrl.trim() : "";
  if (!youtubeUrl) {
    return badRequest("YouTube URL is required.");
  }
  const parsed = validateYouTubeUrl(youtubeUrl);
  if (!parsed) {
    return badRequest(
      "Invalid YouTube URL. Use https://youtube.com/watch?v=… or https://youtu.be/…"
    );
  }

  // `enabled` is a boolean — default to false when not provided.
  const enabled = body.enabled === true;

  let saved;
  try {
    saved = await saveTutorialVideo(location, { youtubeUrl, enabled }, admin.id);
  } catch (err) {
    return badRequest(err instanceof Error ? err.message : "Failed to save tutorial video.");
  }

  await recordAudit({
    adminId: admin.id,
    action: "admin.tutorial-videos.update",
    targetType: "setting",
    targetId: `tutorial.${location}`,
    metadata: {
      location,
      label: TUTORIAL_LOCATION_META[location].label,
      videoId: saved.videoId,
      enabled: saved.enabled,
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ tutorial: { location, record: saved } });
});
