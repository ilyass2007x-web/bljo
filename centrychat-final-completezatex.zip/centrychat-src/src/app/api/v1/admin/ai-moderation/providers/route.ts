import { apiHandler, ok, badRequest, notFound, forbidden, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp, checkRateLimit } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import {
  CreateProviderSchema,
  maskApiKey,
  encryptApiKey,
  validateEndpointUrl,
  testProvider,
  type ProviderType,
} from "@/lib/ai-moderation";

/**
 * GET /api/v1/admin/ai-moderation/providers
 * ------------------------------------------
 * List all configured AI moderation providers (active + inactive).
 *
 * SECURITY:
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - API keys are NEVER returned. The `apiKeyMasked` field shows only the last 4 chars.
 *   - Audit-logged.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const providers = await db.aiModerationProvider.findMany({
    orderBy: [{ priority: "asc" }, { createdAt: "asc" }],
  });

  await recordAudit({
    adminId: admin.id,
    action: "admin.ai_moderation.providers.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  // Mask the API key — NEVER return the encrypted form to the client.
  // (Even the encrypted form could leak the IV + authTag, which combined
  // with a compromised MODERATION_ENCRYPTION_KEY would reveal the key.)
  // We return only the masked form + a boolean `hasApiKey`.
  return ok({
    providers: providers.map((p) => ({
      id: p.id,
      name: p.name,
      type: p.type,
      model: p.model,
      endpoint: p.endpoint,
      priority: p.priority,
      supportsText: p.supportsText,
      supportsImage: p.supportsImage,
      supportsVideo: p.supportsVideo,
      healthStatus: p.healthStatus,
      lastHealthCheck: p.lastHealthCheck?.toISOString() ?? null,
      lastHealthError: p.lastHealthError,
      totalRequests: p.totalRequests,
      failedRequests: p.failedRequests,
      hasApiKey: !!p.apiKeyEncrypted,
      apiKeyMasked: p.apiKeyEncrypted ? maskApiKey(p.apiKeyEncrypted) : "",
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    })),
  });
});

/**
 * POST /api/v1/admin/ai-moderation/providers
 * ------------------------------------------
 * Create a new AI moderation provider.
 *
 * Body (CreateProviderSchema):
 *   { name, type, model, apiKey?, endpoint?, priority,
 *     supportsText, supportsImage, supportsVideo, testBeforeSave }
 *
 * When testBeforeSave=true (default), the adapter's healthCheck() is
 * called BEFORE the provider is persisted. If the check fails, the
 * provider is NOT saved (the admin sees the error message).
 *
 * SECURITY:
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - API key is AES-GCM encrypted at rest (never plaintext in DB).
 *   - Endpoint is SSRF-validated before persistence.
 *   - Rate-limited (admin write preset — 120/min).
 *   - Audit-logged (action: "admin.ai_moderation.providers.create").
 *     API key is NEVER in the audit metadata (sanitizeMetadata strips it).
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();

  // Rate limit — admin write preset.
  const rl = await checkRateLimit(`ai-mod-provider-create:${admin.id}`, {
    limit: 10,
    windowSeconds: 60,
  });
  if (!rl.ok) {
    return apiRateLimitedResponse(Math.ceil((rl.resetAt - Date.now()) / 1000));
  }

  const body = await parseJsonBody<unknown>(req);
  const parsed = CreateProviderSchema.safeParse(body);
  if (!parsed.success) {
    return badRequest("Invalid provider configuration", {
      errors: parsed.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
    });
  }
  const input = parsed.data;

  // SSRF-check the endpoint (when provided).
  if (input.endpoint) {
    const ssrfCheck = await validateEndpointUrl(input.endpoint, {
      isLocalProvider: input.type === "local",
    });
    if (!ssrfCheck.ok) {
      return badRequest(`Endpoint rejected: ${ssrfCheck.reason}`);
    }
  }

  // Pre-save test (when testBeforeSave is true + an API key or endpoint is provided).
  if (input.testBeforeSave) {
    const testResult = await testProvider({
      draftConfig: {
        type: input.type as ProviderType,
        model: input.model,
        apiKey: input.apiKey,
        endpoint: input.endpoint ?? null,
      },
    });
    if (!testResult.healthy) {
      // Don't save — return the test failure to the admin.
      return badRequest(`Provider test failed: ${testResult.reason}. Provider was NOT saved.`);
    }
  }

  // Encrypt the API key (when provided).
  const apiKeyEncrypted = input.apiKey ? encryptApiKey(input.apiKey) : null;

  // Persist.
  const provider = await db.aiModerationProvider.create({
    data: {
      name: input.name,
      type: input.type,
      model: input.model,
      apiKeyEncrypted,
      endpoint: input.endpoint ?? null,
      priority: input.priority,
      supportsText: input.supportsText,
      supportsImage: input.supportsImage,
      supportsVideo: input.supportsVideo,
      healthStatus: "unknown",
      updatedById: admin.id,
    },
  });

  await recordAudit({
    adminId: admin.id,
    action: "admin.ai_moderation.providers.create",
    targetType: "ai_moderation_provider",
    targetId: provider.id,
    metadata: {
      name: provider.name,
      type: provider.type,
      model: provider.model,
      priority: provider.priority,
      hasApiKey: !!apiKeyEncrypted,
      // NEVER include the API key in audit metadata.
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({
    provider: {
      id: provider.id,
      name: provider.name,
      type: provider.type,
      model: provider.model,
      priority: provider.priority,
      hasApiKey: !!apiKeyEncrypted,
      apiKeyMasked: apiKeyEncrypted ? maskApiKey(apiKeyEncrypted) : "",
    },
  });
});

// Avoid circular import — define a tiny inline helper.
function apiRateLimitedResponse(retryAfter: number): Response {
  return Response.json(
    { ok: false, error: { message: "Too many requests. Please try again later." } },
    { status: 429, headers: { "Retry-After": String(Math.ceil(retryAfter)) } }
  );
}
