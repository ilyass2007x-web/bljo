import { apiHandler, ok, badRequest, notFound, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp, checkRateLimit } from "@/lib/security/rate-limit";
import {
  applyReviewAction,
  ReviewActionSchema,
} from "@/lib/ai-moderation";

/**
 * PATCH /api/v1/admin/ai-moderation/reviews/:id
 * ---------------------------------------------
 * Admin action on a single review item (approve / reject / override).
 *
 * Body (ReviewActionSchema):
 *   { status: "APPROVED" | "REJECTED" | "OVERRIDDEN",
 *     notes?: string,
 *     overrideContentAction?: ContentAction,
 *     overrideUserAction?: UserAction }
 *
 * SECURITY (spec §18 — admin override has PRIORITY over AI):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Status is validated server-side (Zod).
 *   - The admin's identity comes from the session, NOT from the request body.
 *   - Every action audit-logged.
 *   - Rate-limited (30/min per admin — prevents accidental mass-action).
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return badRequest("Review ID is required");

  // Rate limit.
  const rl = await checkRateLimit(`ai-mod-review-action:${admin.id}`, {
    limit: 30,
    windowSeconds: 60,
  });
  if (!rl.ok) {
    return Response.json(
      { ok: false, error: { message: "Too many review actions. Please slow down." } },
      { status: 429, headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } }
    );
  }

  const body = await parseJsonBody<unknown>(req);
  const parsed = ReviewActionSchema.safeParse(body);
  if (!parsed.success) {
    return badRequest("Invalid review action", {
      errors: parsed.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
    });
  }
  const input = parsed.data;

  const result = await applyReviewAction(
    {
      reviewId: id,
      newStatus: input.status,
      notes: input.notes,
      overrideContentAction: input.overrideContentAction,
      overrideUserAction: input.overrideUserAction,
    },
    admin.id
  );

  if (result.notFound) return notFound("Review item not found");

  await recordAudit({
    adminId: admin.id,
    action: `admin.ai_moderation.reviews.${input.status.toLowerCase()}`,
    targetType: "ai_moderation_review",
    targetId: id,
    metadata: {
      notes: input.notes?.slice(0, 200),
      overrideContentAction: input.overrideContentAction,
      overrideUserAction: input.overrideUserAction,
      appliedActions: result.appliedActions,
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ ok: true, appliedActions: result.appliedActions });
});
