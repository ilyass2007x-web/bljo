import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  loadPolicy,
  savePolicy,
  ModerationPolicySchema,
} from "@/lib/ai-moderation";

/**
 * GET /api/v1/admin/ai-moderation/policy
 * --------------------------------------
 * Load the current moderation policy + version.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const { policy, version } = await loadPolicy();

  await recordAudit({
    adminId: admin.id,
    action: "admin.ai_moderation.policy.view",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ policy, version });
});

/**
 * PUT /api/v1/admin/ai-moderation/policy
 * --------------------------------------
 * Save a new moderation policy + bump the version.
 *
 * SECURITY:
 *   - requireAdmin() — admin-only.
 *   - The policy is validated with the Zod schema before persistence.
 *   - Audit-logged (action: "admin.ai_moderation.policy.update").
 *   - The version bump is atomic — concurrent saves are safe (last-write-wins
 *     on the version counter, but each save produces a unique snapshot).
 */
export const PUT = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const parsed = ModerationPolicySchema.safeParse(body);
  if (!parsed.success) {
    return badRequest("Invalid policy", {
      errors: parsed.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
    });
  }
  const policy = parsed.data;

  const newVersion = await savePolicy(policy, admin.id);

  await recordAudit({
    adminId: admin.id,
    action: "admin.ai_moderation.policy.update",
    targetType: "ai_moderation_policy",
    targetId: String(newVersion),
    metadata: {
      version: newVersion,
      enabled: policy.enabled,
      contentTypeCount: policy.contentTypes.length,
      categoryCount: Object.keys(policy.categories).length,
      failureMode: policy.failureMode,
      timeoutMs: policy.timeoutMs,
      maxRetries: policy.maxRetries,
      retentionDays: policy.retentionDays,
      escalationRulesCount: policy.escalationRules?.length ?? 0,
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ version: newVersion, saved: true });
});
