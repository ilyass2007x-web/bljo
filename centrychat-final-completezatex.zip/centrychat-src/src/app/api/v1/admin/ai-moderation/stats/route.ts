import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { getAiModerationStats, isEncryptionKeyConfigured } from "@/lib/ai-moderation";

/**
 * GET /api/v1/admin/ai-moderation/stats
 * -------------------------------------
 * Dashboard stats for the AI Moderation admin section.
 *
 * Returns:
 *   - Total / allowed / flagged / hidden / blocked / deleted counts
 *   - Pending reviews
 *   - Admin override counts (approve / reject / override)
 *   - User action counts (warnings / restrictions / suspensions / bans)
 *   - Provider error count + fallback usage
 *   - Average processing time
 *   - Top 10 violation categories
 *   - Last 7 days (results per day)
 *   - Provider list with health + counters
 *   - Encryption key status (true/false — admin needs to know if
 *     MODERATION_ENCRYPTION_KEY is unset, otherwise saved API keys can't
 *     be decrypted).
 *
 * SECURITY:
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - NEVER returns API keys (the providers list has only masked keys).
 *   - Audit-logged.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();

  const [stats, encryptionKeyConfigured] = await Promise.all([
    getAiModerationStats(),
    Promise.resolve(isEncryptionKeyConfigured()),
  ]);

  await recordAudit({
    adminId: admin.id,
    action: "admin.ai_moderation.stats.view",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({
    stats,
    encryptionKeyConfigured,
  });
});
