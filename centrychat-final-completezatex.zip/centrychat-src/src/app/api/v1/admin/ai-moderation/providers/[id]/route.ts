import { apiHandler, ok, badRequest, notFound, forbidden, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp, checkRateLimit } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import {
  UpdateProviderSchema,
  maskApiKey,
  encryptApiKey,
  validateEndpointUrl,
  type ProviderType,
} from "@/lib/ai-moderation";

/**
 * GET /api/v1/admin/ai-moderation/providers/:id
 * ----------------------------------------------
 * Fetch a single provider (admin detail view).
 * API key is masked — NEVER returned in full.
 */
export const GET = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return badRequest("Provider ID is required");

  const provider = await db.aiModerationProvider.findUnique({ where: { id } });
  if (!provider) return notFound("Provider not found");

  await recordAudit({
    adminId: admin.id,
    action: "admin.ai_moderation.providers.view",
    targetType: "ai_moderation_provider",
    targetId: id,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({
    provider: {
      id: provider.id,
      name: provider.name,
      type: provider.type,
      model: provider.model,
      endpoint: provider.endpoint,
      priority: provider.priority,
      supportsText: provider.supportsText,
      supportsImage: provider.supportsImage,
      supportsVideo: provider.supportsVideo,
      healthStatus: provider.healthStatus,
      lastHealthCheck: provider.lastHealthCheck?.toISOString() ?? null,
      lastHealthError: provider.lastHealthError,
      totalRequests: provider.totalRequests,
      failedRequests: provider.failedRequests,
      hasApiKey: !!provider.apiKeyEncrypted,
      apiKeyMasked: provider.apiKeyEncrypted ? maskApiKey(provider.apiKeyEncrypted) : "",
      createdAt: provider.createdAt.toISOString(),
      updatedAt: provider.updatedAt.toISOString(),
    },
  });
});

/**
 * PATCH /api/v1/admin/ai-moderation/providers/:id
 * -----------------------------------------------
 * Update a provider. Accepts partial updates — only the provided fields
 * are updated. When `apiKey` is omitted, the existing key is preserved.
 *
 * SECURITY:
 *   - requireAdmin() server-side.
 *   - SSRF-check the endpoint when changed.
 *   - API key (when provided) is AES-GCM encrypted at rest.
 *   - Audit-logged (NEVER logs the API key).
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return badRequest("Provider ID is required");

  const rl = await checkRateLimit(`ai-mod-provider-update:${admin.id}`, {
    limit: 30,
    windowSeconds: 60,
  });
  if (!rl.ok) {
    return Response.json(
      { ok: false, error: { message: "Too many requests. Please try again later." } },
      { status: 429, headers: { "Retry-After": String(Math.ceil((rl.resetAt - Date.now()) / 1000)) } }
    );
  }

  const body = await parseJsonBody<unknown>(req);
  const parsed = UpdateProviderSchema.safeParse(body);
  if (!parsed.success) {
    return badRequest("Invalid update", {
      errors: parsed.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
    });
  }
  const input = parsed.data;

  const existing = await db.aiModerationProvider.findUnique({ where: { id } });
  if (!existing) return notFound("Provider not found");

  // SSRF-check the new endpoint (when changed).
  if (input.endpoint !== undefined) {
    if (input.endpoint) {
      const ssrfCheck = await validateEndpointUrl(input.endpoint, {
        isLocalProvider: existing.type === "local",
      });
      if (!ssrfCheck.ok) {
        return badRequest(`Endpoint rejected: ${ssrfCheck.reason}`);
      }
    }
  }

  // Build the update payload. API key handling:
  //   - When `apiKey` is provided → re-encrypt + replace.
  //   - When `apiKey` is undefined → keep the existing encrypted key.
  //   - When `apiKey` is "" (empty string) → CLEAR the key (admin explicitly cleared it).
  const update: {
    name?: string;
    model?: string;
    apiKeyEncrypted?: string | null;
    endpoint?: string | null;
    priority?: number;
    supportsText?: boolean;
    supportsImage?: boolean;
    supportsVideo?: boolean;
    updatedById?: string;
  } = {};
  if (input.name !== undefined) update.name = input.name;
  if (input.model !== undefined) update.model = input.model;
  if (input.endpoint !== undefined) update.endpoint = input.endpoint || null;
  if (input.priority !== undefined) update.priority = input.priority;
  if (input.supportsText !== undefined) update.supportsText = input.supportsText;
  if (input.supportsImage !== undefined) update.supportsImage = input.supportsImage;
  if (input.supportsVideo !== undefined) update.supportsVideo = input.supportsVideo;
  if (input.apiKey !== undefined) {
    update.apiKeyEncrypted = input.apiKey ? encryptApiKey(input.apiKey) : null;
  }
  update.updatedById = admin.id;

  const updated = await db.aiModerationProvider.update({
    where: { id },
    data: update,
  });

  await recordAudit({
    adminId: admin.id,
    action: "admin.ai_moderation.providers.update",
    targetType: "ai_moderation_provider",
    targetId: id,
    metadata: {
      updatedFields: Object.keys(update).filter((k) => k !== "updatedById" && k !== "apiKeyEncrypted"),
      apiKeyChanged: input.apiKey !== undefined,
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({
    provider: {
      id: updated.id,
      name: updated.name,
      type: updated.type,
      model: updated.model,
      priority: updated.priority,
      hasApiKey: !!updated.apiKeyEncrypted,
      apiKeyMasked: updated.apiKeyEncrypted ? maskApiKey(updated.apiKeyEncrypted) : "",
    },
  });
});

/**
 * DELETE /api/v1/admin/ai-moderation/providers/:id
 * -------------------------------------------------
 * Delete a provider. Existing AiModerationResult rows have their
 * `providerId` set to NULL (SetNull relation) — the audit trail
 * (providerName + modelName denormalized columns) is preserved.
 *
 * SECURITY:
 *   - requireAdmin() server-side.
 *   - Audit-logged.
 *   - Cascade is configured in the Prisma schema — no manual cleanup needed.
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return badRequest("Provider ID is required");

  const existing = await db.aiModerationProvider.findUnique({ where: { id } });
  if (!existing) return notFound("Provider not found");

  // Snapshot the name for the audit log (after deletion, we can't read it).
  const { name, type } = existing;

  await db.aiModerationProvider.delete({ where: { id } });

  await recordAudit({
    adminId: admin.id,
    action: "admin.ai_moderation.providers.delete",
    targetType: "ai_moderation_provider",
    targetId: id,
    metadata: { name, type },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ deleted: true });
});
