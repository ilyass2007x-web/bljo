import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { getReviewQueue, ReviewFilterSchema } from "@/lib/ai-moderation";

/**
 * GET /api/v1/admin/ai-moderation/reviews
 * ---------------------------------------
 * Paginated review queue for AI-flagged content.
 *
 * Query params:
 *   - page (default 1)
 *   - pageSize (default 20, max 100)
 *   - status (PENDING | APPROVED | REJECTED | OVERRIDDEN)
 *   - providerId
 *   - contentType (post | article | post_comment | ...)
 *   - category (e.g. "sexual", "hate", ...)
 *   - userId
 *
 * SECURITY:
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - The review items contain the user's content preview (200 chars max) —
 *     NEVER exposed to non-admins.
 *   - Audit-logged.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const url = new URL(req.url);
  const params: Record<string, string> = {};
  for (const [k, v] of url.searchParams.entries()) {
    if (v) params[k] = v;
  }
  const parsed = ReviewFilterSchema.safeParse(params);
  if (!parsed.success) {
    return badRequest("Invalid filter", {
      errors: parsed.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
    });
  }
  const filter = parsed.data;

  const { items, total } = await getReviewQueue({
    status: filter.status,
    providerId: filter.providerId,
    contentType: filter.contentType,
    category: filter.category,
    userId: filter.userId,
    page: filter.page,
    pageSize: filter.pageSize,
  });

  await recordAudit({
    adminId: admin.id,
    action: "admin.ai_moderation.reviews.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
    metadata: {
      page: filter.page,
      pageSize: filter.pageSize,
      status: filter.status,
      contentType: filter.contentType,
    },
  });

  return ok({
    items,
    total,
    page: filter.page,
    pageSize: filter.pageSize,
    totalPages: Math.ceil(total / filter.pageSize),
  });
});
