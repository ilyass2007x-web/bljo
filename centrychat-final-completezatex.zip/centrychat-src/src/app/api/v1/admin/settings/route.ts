import { apiHandler, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { listSettings, setSetting } from "@/lib/settings";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  await recordAudit({
    adminId: admin.id,
    action: "admin.settings.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  const settings = await listSettings();
  return ok({ settings });
});

export const PUT = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{ key?: string; value?: string }>(req);
  if (!body.key) return ok({});

  await setSetting(body.key, String(body.value ?? ""), admin.id);
  await recordAudit({
    adminId: admin.id,
    action: "admin.settings.update",
    targetType: "setting",
    targetId: body.key,
    metadata: { value: String(body.value ?? "") },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  const settings = await listSettings();
  return ok({ settings });
});
