import { apiHandler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { destroySession } from "@/lib/auth/session";

export const DELETE = apiHandler(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const session = await db.adminSession.findUnique({ where: { id } });
  if (!session || session.userId !== user.id) {
    return ok({ deleted: false });
  }
  await db.adminSession.delete({ where: { id } });
  // If it's the current session, also clear the cookie.
  await recordAudit({
    adminId: user.id,
    action: "session.revoke",
    targetType: "session",
    targetId: session.sessionId.slice(0, 8),
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  return ok({ deleted: true });
});
