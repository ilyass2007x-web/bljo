import { apiHandler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";

export const GET = apiHandler(async (req) => {
  const user = await requireUser();
  const url = new URL(req.url);
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(50, Number(url.searchParams.get("pageSize") ?? "20"));

  const [sessions, total] = await Promise.all([
    db.adminSession.findMany({
      where: { userId: user.id },
      orderBy: { lastActiveAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    db.adminSession.count({ where: { userId: user.id } }),
  ]);

  return ok({
    sessions: sessions.map((s) => ({
      id: s.id,
      sessionId: s.sessionId.slice(0, 8) + "…", // partial only
      ipAddress: s.ipAddress,
      userAgent: s.userAgent,
      createdAt: s.createdAt.toISOString(),
      lastActiveAt: s.lastActiveAt.toISOString(),
      expiresAt: s.expiresAt.toISOString(),
    })),
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
  });
});
