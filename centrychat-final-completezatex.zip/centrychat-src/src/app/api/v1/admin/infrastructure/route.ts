import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { pingDatabase, getDatabaseProvider } from "@/lib/database";
import { getStorageProvider } from "@/lib/storage";
import { getEmailProvider } from "@/lib/email";
import { getCache } from "@/lib/cache";
import { getJobs } from "@/lib/jobs";
import { db } from "@/lib/database";

/**
 * GET /api/v1/admin/infrastructure
 * Shows the status of all infrastructure providers.
 * NEVER exposes secrets — only connection status + safe hints.
 */
export const GET = apiHandler(async () => {
  const admin = await requireAdmin();
  void admin;

  const dbPing = await pingDatabase();

  // Count external APIs by provider (for the APIs overview).
  const apiCounts = await db.externalApi.groupBy({
    by: ["provider"],
    _count: { provider: true },
    where: { status: "enabled" },
  });

  return ok({
    infrastructure: {
      database: {
        name: getDatabaseProvider(),
        connected: dbPing.ok,
        latencyMs: dbPing.latencyMs,
        // Safe hint — never the full URL or password.
        urlHint: process.env.DATABASE_URL
          ? `${process.env.DATABASE_URL.substring(0, 15)}...`
          : "[not configured]",
        error: dbPing.error ?? null,
      },
      storage: {
        name: getStorageProvider().name,
        configured: getStorageProvider().name !== "noop",
      },
      email: {
        name: getEmailProvider().name,
        configured: getEmailProvider().name !== "console",
      },
      cache: {
        name: getCache().name,
      },
      jobs: {
        name: getJobs().name,
      },
      realtime: {
        name: process.env.REALTIME_INTERNAL_URL ? "socket.io" : "disabled",
        configured: !!process.env.REALTIME_INTERNAL_URL,
      },
      externalApis: {
        enabled: apiCounts.map((a) => ({
          provider: a.provider,
          count: a._count.provider,
        })),
      },
    },
  });
});
