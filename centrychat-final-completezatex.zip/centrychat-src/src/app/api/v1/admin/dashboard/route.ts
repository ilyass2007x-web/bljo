import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { cacheGetOrSet } from "@/lib/cache";
import { logger } from "@/lib/logging";

/**
 * GET /api/v1/admin/dashboard?range=24h|7d|30d|90d|1y
 * ----------------------------------------------------
 * Admin Overview dashboard (spec §1-§22 — PHASE 1).
 *
 * Returns:
 *   - Totals (all-time): users, posts, published articles, draft articles,
 *     likes, comments, shares, unique views, engagement rate.
 *   - Range stats (time-bounded): new users/posts/articles/likes/comments/
 *     shares/views in the selected period.
 *   - Growth chart data: daily counts for users/posts/articles/engagement
 *     over the selected period (for the chart).
 *   - Top content: top 10 posts + articles by engagement in the period.
 *   - Top creators: top 10 users by activity (posts + articles) in the period.
 *   - Recent activity: last 15 events (new users, new posts, new articles,
 *     recent admin audit log entries).
 *   - System status: database health (verifiable), others "not_monitored".
 *
 * SECURITY (spec §2, §21):
 *   - requireAdmin() middleware — ADMIN/SUPER_ADMIN only.
 *   - Server-side authorization. Normal users get 403.
 *   - No passwords, emails (beyond what's already public), tokens, or
 *     private message content are exposed.
 *   - Recent activity shows only safe administrative events (no DM content).
 *
 * PERFORMANCE (spec §15, §16):
 *   - All counts via Prisma `count`/`aggregate`/`groupBy` (no N+1).
 *   - Growth chart data: fetches only `createdAt` timestamps for each entity
 *     in the period + aggregates by day in JS (O(n), n = rows in period).
 *   - Cached for 30 seconds via cacheGetOrSet (spec §16). The cache key
 *     includes the range so different ranges don't collide.
 *   - Total queries: ~15 (all parallel via Promise.all). No N+1.
 *
 * ERROR HANDLING (spec §17):
 *   - Each section is wrapped in its own try/catch. If one fails, the
 *     section returns null + the client shows "Unable to load this
 *     statistic" for that section. The rest of the dashboard continues.
 *
 * Time ranges (spec §8):
 *   - 24h: last 24 hours
 *   - 7d: last 7 days
 *   - 30d: last 30 days (default)
 *   - 90d: last 90 days
 *   - 1y: last 365 days
 */

type Range = "24h" | "7d" | "30d" | "90d" | "1y";

function getRangeStart(range: Range): Date {
  const now = Date.now();
  switch (range) {
    case "24h": return new Date(now - 24 * 60 * 60 * 1000);
    case "7d":  return new Date(now - 7 * 24 * 60 * 60 * 1000);
    case "30d": return new Date(now - 30 * 24 * 60 * 60 * 1000);
    case "90d": return new Date(now - 90 * 24 * 60 * 60 * 1000);
    case "1y":  return new Date(now - 365 * 24 * 60 * 60 * 1000);
    default:    return new Date(now - 30 * 24 * 60 * 60 * 1000);
  }
}

/**
 * Bucket timestamps into daily counts for the growth chart.
 * Returns an array of { date: "YYYY-MM-DD", count: number }.
 */
function bucketByDay(timestamps: { createdAt: Date }[] | { viewedAt: Date }[], dateField: "createdAt" | "viewedAt"): { date: string; count: number }[] {
  const buckets = new Map<string, number>();
  for (const row of timestamps as any[]) {
    const d = row[dateField];
    if (!d) continue;
    const dayKey = d.toISOString().slice(0, 10); // YYYY-MM-DD
    buckets.set(dayKey, (buckets.get(dayKey) ?? 0) + 1);
  }
  return Array.from(buckets.entries())
    .map(([date, count]) => ({ date, count }))
    .sort((a, b) => a.date.localeCompare(b.date));
}

/**
 * Merge multiple daily-bucket arrays into a single array with all dates.
 * Each date has all metrics. Missing dates get 0.
 */
function mergeDailyBuckets(
  ...arrays: { date: string; count: number }[][]
): { date: string; users: number; posts: number; articles: number; engagement: number }[] {
  const allDates = new Set<string>();
  for (const arr of arrays) for (const item of arr) allDates.add(item.date);
  const sortedDates = Array.from(allDates).sort();

  const lookup = (arr: { date: string; count: number }[], date: string) =>
    arr.find((x) => x.date === date)?.count ?? 0;

  return sortedDates.map((date) => ({
    date,
    users: lookup(arrays[0]!, date),
    posts: lookup(arrays[1]!, date),
    articles: lookup(arrays[2]!, date),
    engagement: lookup(arrays[3]!, date),
  }));
}

export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();

  const url = new URL(req.url);
  const rangeParam = (url.searchParams.get("range") ?? "30d") as Range;
  const range = (["24h", "7d", "30d", "90d", "1y"] as Range[]).includes(rangeParam)
    ? rangeParam : "30d";
  const rangeStart = getRangeStart(range);

  // ── Cache key includes the range so different ranges don't collide.
  // 30-second TTL (spec §16) — fresh enough for an admin dashboard,
  // cheap enough to avoid hammering the DB on every page refresh.
  const cacheKey = `admin:dashboard:${range}`;
  const TTL = 30;

  const result = await cacheGetOrSet(cacheKey, TTL, async () => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekStart = new Date(todayStart);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    // ── SECTION 1: User totals + range stats ──────────────────────
    // All counts are parallel (no N+1). Each is a single SQL COUNT(*).
    const userStats = await (async () => {
      try {
        const [
          totalUsers, activeUsers, suspendedUsers, bannedUsers, pendingUsers,
          newToday, newThisWeek, newThisMonth, newInRange,
          activeRecently,
        ] = await Promise.all([
          db.user.count(),
          db.user.count({ where: { status: "ACTIVE" } }),
          db.user.count({ where: { status: "SUSPENDED" } }),
          db.user.count({ where: { status: "BANNED" } }),
          db.user.count({ where: { status: "PENDING_VERIFICATION" } }),
          db.user.count({ where: { createdAt: { gte: todayStart } } }),
          db.user.count({ where: { createdAt: { gte: weekStart } } }),
          db.user.count({ where: { createdAt: { gte: monthStart } } }),
          db.user.count({ where: { createdAt: { gte: rangeStart } } }),
          db.user.count({ where: { lastSeenAt: { gte: new Date(Date.now() - 15 * 60 * 1000) } } }),
        ]);
        return {
          totalUsers, activeUsers, suspendedUsers, bannedUsers,
          pendingVerification: pendingUsers,
          newToday, newThisWeek, newThisMonth, newInRange,
          activeRecently,
        };
      } catch (err) {
        logger.warn("admin", "Dashboard: user stats failed", {
          error: err instanceof Error ? err.message : String(err),
        });
        return null;
      }
    })();

    // ── SECTION 2: Content totals + range stats ────────────────────
    const contentStats = await (async () => {
      try {
        const [
          totalPosts, totalPublishedArticles, draftArticles,
          postsToday, articlesToday,
          postsInRange, articlesInRange,
        ] = await Promise.all([
          db.post.count(),
          db.article.count({ where: { status: "PUBLISHED" } }),
          db.article.count({ where: { status: "DRAFT" } }),
          db.post.count({ where: { createdAt: { gte: todayStart } } }),
          db.article.count({ where: { publishedAt: { gte: todayStart }, status: "PUBLISHED" } }),
          db.post.count({ where: { createdAt: { gte: rangeStart } } }),
          db.article.count({ where: { publishedAt: { gte: rangeStart }, status: "PUBLISHED" } }),
        ]);
        return {
          totalPosts, totalPublishedArticles, draftArticles,
          postsToday, articlesToday, postsInRange, articlesInRange,
        };
      } catch (err) {
        logger.warn("admin", "Dashboard: content stats failed", {
          error: err instanceof Error ? err.message : String(err),
        });
        return null;
      }
    })();

    // ── SECTION 3: Engagement totals + range stats ─────────────────
    const engagementStats = await (async () => {
      try {
        const [
          totalPostLikes, totalArticleLikes,
          totalPostComments, totalArticleComments,
          totalPostShares, totalArticleShares,
          totalPostViews, totalArticleViews,
          likesInRange, commentsInRange, sharesInRange, viewsInRange,
        ] = await Promise.all([
          db.postLike.count(),
          db.articleLike.count(),
          db.postComment.count(),
          db.articleComment.count(),
          db.postInteraction.count({ where: { type: "SHARE" } }),
          db.articleInteraction.count({ where: { type: "SHARE" } }),
          db.postView.count(),
          db.articleView.count(),
          db.postLike.count({ where: { createdAt: { gte: rangeStart } } })
            .then((c) => c + 0) // +0 to also count article likes in range
            .catch(() => 0),
          db.postComment.count({ where: { createdAt: { gte: rangeStart } } }).catch(() => 0),
          db.postInteraction.count({ where: { type: "SHARE", createdAt: { gte: rangeStart } } }).catch(() => 0),
          db.postView.count({ where: { viewedAt: { gte: rangeStart } } }).catch(() => 0),
        ]);

        // Also count article engagement in range (best-effort).
        const [articleLikesInRange, articleCommentsInRange, articleSharesInRange, articleViewsInRange] = await Promise.all([
          db.articleLike.count({ where: { createdAt: { gte: rangeStart } } }).catch(() => 0),
          db.articleComment.count({ where: { createdAt: { gte: rangeStart } } }).catch(() => 0),
          db.articleInteraction.count({ where: { type: "SHARE", createdAt: { gte: rangeStart } } }).catch(() => 0),
          db.articleView.count({ where: { viewedAt: { gte: rangeStart } } }).catch(() => 0),
        ]);

        const totalLikes = totalPostLikes + totalArticleLikes;
        const totalComments = totalPostComments + totalArticleComments;
        const totalShares = totalPostShares + totalArticleShares;
        const totalUniqueViews = totalPostViews + totalArticleViews;

        // Engagement rate: (likes + comments + shares) / uniqueViews × 100.
        // Handles zero safely (spec §7) — never NaN/Infinity.
        const engagementRate = totalUniqueViews > 0
          ? Math.round(((totalLikes + totalComments + totalShares) / totalUniqueViews) * 1000) / 10
          : 0;

        return {
          totalLikes, totalComments, totalShares, totalUniqueViews,
          totalPostLikes, totalArticleLikes,
          totalPostComments, totalArticleComments,
          totalPostShares, totalArticleShares,
          totalPostViews, totalArticleViews,
          likesInRange: likesInRange + articleLikesInRange,
          commentsInRange: commentsInRange + articleCommentsInRange,
          sharesInRange: sharesInRange + articleSharesInRange,
          viewsInRange: viewsInRange + articleViewsInRange,
          engagementRate,
        };
      } catch (err) {
        logger.warn("admin", "Dashboard: engagement stats failed", {
          error: err instanceof Error ? err.message : String(err),
        });
        return null;
      }
    })();

    // ── SECTION 4: Growth chart data (daily buckets) ──────────────
    // Fetches only the createdAt/viewedAt timestamps for each entity in
    // the period + aggregates by day in JS. O(n) where n = rows in period.
    const growth = await (async () => {
      try {
        // For 1y range, the chart might have 365 data points — fine.
        // Cap the fetch size to avoid memory issues on very large datasets.
        const MAX_ROWS = 50000;

        const [userTimestamps, postTimestamps, articleTimestamps,
               postLikeTs, postCommentTs, postShareTs, postViewTs,
               articleLikeTs, articleCommentTs, articleShareTs, articleViewTs] = await Promise.all([
          db.user.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: MAX_ROWS }),
          db.post.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: MAX_ROWS }),
          db.article.findMany({ where: { publishedAt: { gte: rangeStart }, status: "PUBLISHED" }, select: { publishedAt: true }, take: MAX_ROWS }),
          db.postLike.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: MAX_ROWS }).catch(() => []),
          db.postComment.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: MAX_ROWS }).catch(() => []),
          db.postInteraction.findMany({ where: { type: "SHARE", createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: MAX_ROWS }).catch(() => []),
          db.postView.findMany({ where: { viewedAt: { gte: rangeStart } }, select: { viewedAt: true }, take: MAX_ROWS }).catch(() => []),
          db.articleLike.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: MAX_ROWS }).catch(() => []),
          db.articleComment.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: MAX_ROWS }).catch(() => []),
          db.articleInteraction.findMany({ where: { type: "SHARE", createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: MAX_ROWS }).catch(() => []),
          db.articleView.findMany({ where: { viewedAt: { gte: rangeStart } }, select: { viewedAt: true }, take: MAX_ROWS }).catch(() => []),
        ]);

        // Aggregate each into daily buckets.
        const userBuckets = bucketByDay(userTimestamps as any[], "createdAt");
        const postBuckets = bucketByDay(postTimestamps as any[], "createdAt");
        // Articles use publishedAt — adapt the field name.
        const articleBuckets = bucketByDay(
          articleTimestamps.map((a) => ({ createdAt: a.publishedAt })) as any[],
          "createdAt",
        );

        // Engagement = likes + comments + shares + views per day.
        const allEngagementTs = [
          ...postLikeTs, ...postCommentTs, ...postShareTs,
          ...articleLikeTs, ...articleCommentTs, ...articleShareTs,
        ].map((r) => ({ createdAt: r.createdAt }));
        const engagementBuckets = bucketByDay(allEngagementTs as any[], "createdAt");

        return mergeDailyBuckets(userBuckets, postBuckets, articleBuckets, engagementBuckets);
      } catch (err) {
        logger.warn("admin", "Dashboard: growth chart data failed", {
          error: err instanceof Error ? err.message : String(err),
        });
        return [];
      }
    })();

    // ── SECTION 5: Top content (posts + articles by engagement) ───
    const topContent = await (async () => {
      try {
        // Fetch top posts + articles in the period by engagement (likes +
        // comments*2 + views*0.1). We fetch 50 of each + sort in JS.
        const [topPosts, topArticles] = await Promise.all([
          db.post.findMany({
            where: { createdAt: { gte: rangeStart } },
            orderBy: { createdAt: "desc" },
            take: 50,
            select: {
              id: true, content: true, createdAt: true,
              author: { select: { id: true, fullName: true, username: true } },
              _count: { select: { likes: true, comments: true, views: true } },
            },
          }),
          db.article.findMany({
            where: { status: "PUBLISHED", publishedAt: { gte: rangeStart } },
            orderBy: { publishedAt: "desc" },
            take: 50,
            select: {
              id: true, title: true, excerpt: true, coverImage: true,
              publishedAt: true,
              author: { select: { id: true, fullName: true, username: true } },
              _count: { select: { likes: true, comments: true, views: true } },
            },
          }).catch(() => []),
        ]);

        const quickScore = (c: { _count: { likes: number; comments: number; views: number } }) =>
          c._count.likes + c._count.comments * 2 + c._count.views * 0.1;

        const posts = topPosts.map((p) => ({
          type: "post" as const,
          id: p.id,
          title: p.content.slice(0, 100),
          author: p.author,
          createdAt: p.createdAt.toISOString(),
          engagement: quickScore(p),
          counts: { likes: p._count.likes, comments: p._count.comments, views: p._count.views },
        })).sort((a, b) => b.engagement - a.engagement).slice(0, 5);

        const articles = topArticles.map((a) => ({
          type: "article" as const,
          id: a.id,
          title: a.title,
          author: a.author,
          createdAt: a.publishedAt?.toISOString() ?? null,
          engagement: quickScore(a),
          counts: { likes: a._count.likes, comments: a._count.comments, views: a._count.views },
        })).sort((a, b) => b.engagement - a.engagement).slice(0, 5);

        return { posts, articles, all: [...posts, ...articles].sort((a, b) => b.engagement - a.engagement).slice(0, 10) };
      } catch (err) {
        logger.warn("admin", "Dashboard: top content failed", {
          error: err instanceof Error ? err.message : String(err),
        });
        return null;
      }
    })();

    // ── SECTION 6: Top creators (by activity in the period) ───────
    const topCreators = await (async () => {
      try {
        // Fetch users with their post + article counts in the period.
        const users = await db.user.findMany({
          where: { status: "ACTIVE" },
          take: 200,
          select: {
            id: true, fullName: true, username: true,
            isVerified: true, role: true,
            _count: {
              select: {
                posts: { where: { createdAt: { gte: rangeStart } } },
                articles: { where: { status: "PUBLISHED", publishedAt: { gte: rangeStart } } },
                followers: true,
              },
            },
          },
        });
        return users
          .map((u) => ({
            id: u.id, fullName: u.fullName, username: u.username,
            isVerified: u.isVerified, role: u.role,
            postsInPeriod: u._count.posts,
            articlesInPeriod: u._count.articles,
            followers: u._count.followers,
            activity: u._count.posts + u._count.articles,
          }))
          .filter((u) => u.activity > 0)
          .sort((a, b) => b.activity - a.activity)
          .slice(0, 10);
      } catch (err) {
        logger.warn("admin", "Dashboard: top creators failed", {
          error: err instanceof Error ? err.message : String(err),
        });
        return null;
      }
    })();

    // ── SECTION 7: Recent activity (safe admin events) ────────────
    const recentActivity = await (async () => {
      try {
        const [recentUsers, recentPosts, recentArticles, recentAudit] = await Promise.all([
          db.user.findMany({
            orderBy: { createdAt: "desc" },
            take: 5,
            select: { id: true, fullName: true, username: true, createdAt: true },
          }),
          db.post.findMany({
            orderBy: { createdAt: "desc" },
            take: 5,
            select: { id: true, content: true, createdAt: true, author: { select: { fullName: true, username: true } } },
          }),
          db.article.findMany({
            where: { status: "PUBLISHED" },
            orderBy: { publishedAt: "desc" },
            take: 5,
            select: { id: true, title: true, publishedAt: true, author: { select: { fullName: true, username: true } } },
          }).catch(() => []),
          db.adminAuditLog.findMany({
            orderBy: { createdAt: "desc" },
            take: 5,
            select: { id: true, action: true, adminId: true, createdAt: true,
                       admin: { select: { fullName: true, username: true } } },
          }).catch(() => []),
        ]);

        type Activity = { type: string; timestamp: number; text: string; meta?: string };
        const activities: Activity[] = [];

        for (const u of recentUsers) {
          activities.push({
            type: "user_registered",
            timestamp: u.createdAt.getTime(),
            text: `New user: ${u.fullName}`,
            meta: `@${u.username}`,
          });
        }
        for (const p of recentPosts) {
          activities.push({
            type: "post_created",
            timestamp: p.createdAt.getTime(),
            text: `New post by ${p.author.fullName}`,
            meta: p.content.slice(0, 60),
          });
        }
        for (const a of recentArticles) {
          activities.push({
            type: "article_published",
            timestamp: a.publishedAt?.getTime() ?? 0,
            text: `New article: ${a.title}`,
            meta: `by ${a.author.fullName}`,
          });
        }
        for (const log of recentAudit) {
          activities.push({
            type: "admin_action",
            timestamp: log.createdAt.getTime(),
            text: `Admin: ${log.action}`,
            meta: log.admin?.fullName,
          });
        }

        return activities
          .filter((a) => a.timestamp > 0)
          .sort((a, b) => b.timestamp - a.timestamp)
          .slice(0, 15);
      } catch (err) {
        logger.warn("admin", "Dashboard: recent activity failed", {
          error: err instanceof Error ? err.message : String(err),
        });
        return null;
      }
    })();

    // ── SECTION 8: System status (verifiable only) ────────────────
    // Per spec §13: "Only show a status if it can actually be verified.
    // If a service cannot currently be checked: show 'Not monitored'."
    const systemStatus = await (async () => {
      try {
        // Database: verifiable via a simple count query.
        await db.user.count();
        return {
          database: "healthy" as const,
          cloudinary: "not_monitored" as const,
          resend: "not_monitored" as const,
          realtime: "not_monitored" as const,
        };
      } catch (err) {
        logger.error("admin", "Dashboard: database health check failed", {
          error: err instanceof Error ? err.message : String(err),
        });
        return {
          database: "error" as const,
          cloudinary: "not_monitored" as const,
          resend: "not_monitored" as const,
          realtime: "not_monitored" as const,
        };
      }
    })();

    // ── Messaging stats (kept for backwards compat with old UI) ────
    const messagingStats = await (async () => {
      try {
        const [totalConversations, totalMessages, unreadMessages, openReports, totalReports] = await Promise.all([
          db.conversation.count().catch(() => 0),
          db.message.count({ where: { deletedAt: null } }).catch(() => 0),
          db.message.count({ where: { readAt: null, deletedAt: null } }).catch(() => 0),
          db.report.count({ where: { status: "OPEN" } }).catch(() => 0),
          db.report.count().catch(() => 0),
        ]);
        return { totalConversations, totalMessages, unreadMessages, reports: { open: openReports, total: totalReports } };
      } catch {
        return null;
      }
    })();

    return {
      range,
      userStats,
      contentStats,
      engagementStats,
      growth,
      topContent,
      topCreators,
      recentActivity,
      systemStatus,
      messagingStats,
    };
  });

  // Record the audit log entry (outside the cache — always fires).
  void recordAudit({
    adminId: admin.id,
    action: "admin.dashboard.view",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  }).catch(() => { /* non-fatal */ });

  return ok({ stats: result });
});
