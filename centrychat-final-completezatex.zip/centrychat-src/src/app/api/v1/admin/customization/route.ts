import { apiHandler, badRequest, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getSetting, setSetting, listSettings } from "@/lib/settings";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

// SAFE customization: only CSS / JSON configuration. No JS execution.
export const GET = apiHandler(async () => {
  const admin = await requireAdmin();
  void admin;
  const [css, brandColor, name, description] = await Promise.all([
    getSetting("customization.custom_css"),
    getSetting("customization.brand_color"),
    getSetting("platform.name"),
    getSetting("platform.description"),
  ]);
  return ok({
    customization: {
      brandColor,
      customCss: css ?? "",
      platformName: name,
      platformDescription: description,
    },
  });
});

export const PUT = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    brandColor?: string;
    customCss?: string;
    platformName?: string;
    platformDescription?: string;
  }>(req);

  // Validate CSS: only allow a conservative subset (no url(), no @import, no expression()).
  if (body.customCss !== undefined) {
    const css = body.customCss ?? "";
    const forbidden = /@import|url\s*\(|expression\s*\(|javascript:/i;
    if (forbidden.test(css)) {
      return badRequest(
        "Custom CSS contains disallowed constructs (@import, url(), expression, javascript:)"
      );
    }
    if (css.length > 20000) {
      return badRequest("Custom CSS is too large (20KB max)");
    }
    await setSetting("customization.custom_css", css, admin.id);
  }
  if (body.brandColor !== undefined) {
    if (!/^#[0-9a-fA-F]{3,8}$/.test(body.brandColor)) {
      return badRequest("Invalid brand color (use hex like #0f172a)");
    }
    await setSetting("customization.brand_color", body.brandColor, admin.id);
  }
  if (body.platformName !== undefined) {
    if (body.platformName.length === 0 || body.platformName.length > 60) {
      return badRequest("Platform name must be 1-60 characters");
    }
    await setSetting("platform.name", body.platformName, admin.id);
  }
  if (body.platformDescription !== undefined) {
    if (body.platformDescription.length > 200) {
      return badRequest("Platform description too long (200 chars max)");
    }
    await setSetting("platform.description", body.platformDescription, admin.id);
  }

  await recordAudit({
    adminId: admin.id,
    action: "admin.customization.update",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
    metadata: { keys: Object.keys(body) },
  });

  const settings = await listSettings();
  return ok({ settings });
});
