import { apiHandler, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin, requireSuperAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";
import { isFeatureEnabled, setFeatureFlag } from "@/lib/features";
import { getSetting, getSettingNumber, setSetting } from "@/lib/settings";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

/**
 * GET /api/v1/admin/recommendation
 * Returns the current algorithm status, settings, and analytics.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin;

  const enabled = await isFeatureEnabled("recommendation_algorithm");
  const mode = await getSetting("rec.algorithm_mode") ?? "hybrid";

  // Weights
  const weights = {
    personalization: await getSettingNumber("rec.weight.personalization") ?? 1.0,
    freshness: await getSettingNumber("rec.weight.freshness") ?? 0.5,
    engagement: await getSettingNumber("rec.weight.engagement") ?? 0.3,
    following: await getSettingNumber("rec.weight.following") ?? 0.4,
    trending: await getSettingNumber("rec.weight.trending") ?? 0.2,
    diversity: await getSettingNumber("rec.weight.diversity") ?? 0.5,
  };
  const maxConsecutive = await getSettingNumber("rec.max_consecutive_creator") ?? 2;
  const transparency = await getSetting("rec.transparency_enabled") === "true";

  // Analytics — aggregated stats (never individual user behavior).
  const [totalProfiles, totalInteractions, totalEvents, impressionCount, clickCount, skipCount, notInterestedCount] = await Promise.all([
    db.recommendationProfile.count(),
    db.contentInteraction.count(),
    db.recommendationEvent.count(),
    db.recommendationEvent.count({ where: { event: "impression" } }),
    db.recommendationEvent.count({ where: { event: "click" } }),
    db.recommendationEvent.count({ where: { event: "skip" } }),
    db.recommendationEvent.count({ where: { event: "not_interested" } }),
  ]);

  // Users with recommendation profiles (affected by algorithm).
  const usersAffected = totalProfiles;

  // Click-through rate.
  const ctr = impressionCount > 0 ? (clickCount / impressionCount) * 100 : 0;
  const skipRate = impressionCount > 0 ? (skipCount / impressionCount) * 100 : 0;
  const notInterestedRate = impressionCount > 0 ? (notInterestedCount / impressionCount) * 100 : 0;

  return ok({
    status: {
      enabled,
      mode,
      engine: enabled ? "rule-based" : "basic",
      usersAffected,
      lastUpdated: new Date().toISOString(),
    },
    settings: {
      weights,
      maxConsecutiveCreator: maxConsecutive,
      transparencyEnabled: transparency,
    },
    analytics: {
      totalProfiles,
      totalInteractions,
      totalEvents,
      impressions: impressionCount,
      clicks: clickCount,
      skips: skipCount,
      notInterested: notInterestedCount,
      clickThroughRate: Math.round(ctr * 100) / 100,
      skipRate: Math.round(skipRate * 100) / 100,
      notInterestedRate: Math.round(notInterestedRate * 100) / 100,
    },
  });
});

/**
 * PATCH /api/v1/admin/recommendation
 * Update algorithm settings (weights, mode, enable/disable).
 */
export const PATCH = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    enabled?: boolean;
    mode?: string;
    weights?: Record<string, number>;
    maxConsecutiveCreator?: number;
    transparencyEnabled?: boolean;
  }>(req);

  // Enable/disable the algorithm.
  if (body.enabled !== undefined) {
    await setFeatureFlag("recommendation_algorithm", body.enabled, admin.id);
  }

  // Change algorithm mode.
  if (body.mode) {
    const validModes = ["personalized", "trending", "following", "hybrid"];
    if (!validModes.includes(body.mode)) {
      return ok({ error: "Invalid mode" });
    }
    await setSetting("rec.algorithm_mode", body.mode, admin.id);
  }

  // Update weights.
  if (body.weights) {
    for (const [key, value] of Object.entries(body.weights)) {
      await setSetting(`rec.weight.${key}`, String(value), admin.id);
    }
  }

  if (body.maxConsecutiveCreator !== undefined) {
    await setSetting("rec.max_consecutive_creator", String(body.maxConsecutiveCreator), admin.id);
  }

  if (body.transparencyEnabled !== undefined) {
    await setSetting("rec.transparency_enabled", String(body.transparencyEnabled), admin.id);
  }

  await recordAudit({
    adminId: admin.id,
    action: "admin.recommendation.update",
    targetType: "settings",
    targetId: "recommendation",
    metadata: { enabled: body.enabled, mode: body.mode },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ updated: true });
});

/**
 * DELETE /api/v1/admin/recommendation
 * Reset recommendation data (SUPER_ADMIN only).
 * Actions: reset_all | reset_user:<userId>
 */
export const DELETE = apiHandler(async (req) => {
  const admin = await requireSuperAdmin();
  const url = new URL(req.url);
  const action = url.searchParams.get("action") ?? "reset_all";
  const userId = url.searchParams.get("userId");

  const engine = getRecommendationEngine();

  if (action === "reset_user" && userId) {
    await engine.resetUserProfile(userId);
    await recordAudit({
      adminId: admin.id,
      action: "admin.recommendation.reset_user",
      targetType: "user",
      targetId: userId,
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });
    return ok({ reset: "user", userId });
  }

  if (action === "reset_all") {
    await engine.resetAllProfiles();
    await recordAudit({
      adminId: admin.id,
      action: "admin.recommendation.reset_all",
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });
    return ok({ reset: "all" });
  }

  return ok({ error: "Invalid action" });
});
