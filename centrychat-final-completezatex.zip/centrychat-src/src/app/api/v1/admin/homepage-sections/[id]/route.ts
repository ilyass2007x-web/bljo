import { apiHandler, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

/**
 * PATCH /api/v1/admin/homepage-sections/:id — update a section
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  const body = await parseJsonBody<{
    name?: string;
    enabled?: boolean;
    position?: number;
    maxItems?: number;
    visibility?: string;
  }>(req);

  const updated = await db.homepageSection.update({
    where: { id },
    data: {
      ...(body.name !== undefined ? { name: body.name } : {}),
      ...(body.enabled !== undefined ? { enabled: body.enabled } : {}),
      ...(body.position !== undefined ? { position: body.position } : {}),
      ...(body.maxItems !== undefined ? { maxItems: body.maxItems } : {}),
      ...(body.visibility !== undefined ? { visibility: body.visibility } : {}),
    },
  });

  await recordAudit({
    adminId: admin.id,
    action: "admin.homepage.update",
    targetType: "homepage_section",
    targetId: id,
    metadata: { enabled: body.enabled, position: body.position },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ section: updated });
});

/**
 * DELETE /api/v1/admin/homepage-sections/:id — delete a section
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  await db.homepageSection.delete({ where: { id } });

  await recordAudit({
    adminId: admin.id,
    action: "admin.homepage.delete",
    targetType: "homepage_section",
    targetId: id,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ deleted: true });
});
