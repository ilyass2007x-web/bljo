import { apiHandler, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

const VALID_TYPES = ["HOME", "FOR_YOU", "POSTS", "REELS", "TRENDING", "FOLLOWING", "POPULAR_USERS", "RECOMMENDED", "STORIES"];

/**
 * GET /api/v1/admin/homepage-sections — list all sections
 */
export const GET = apiHandler(async () => {
  const admin = await requireAdmin();
  void admin;
  const sections = await db.homepageSection.findMany({
    orderBy: { position: "asc" },
  });
  return ok({ sections });
});

/**
 * POST /api/v1/admin/homepage-sections — create a new section
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    name?: string;
    type?: string;
    enabled?: boolean;
    position?: number;
    maxItems?: number;
    visibility?: string;
  }>(req);

  if (!body.name || !body.type) {
    return ok({ error: "name and type are required" });
  }
  if (!VALID_TYPES.includes(body.type)) {
    return ok({ error: "invalid section type" });
  }

  const section = await db.homepageSection.create({
    data: {
      name: body.name,
      type: body.type,
      enabled: body.enabled ?? false,
      position: body.position ?? 0,
      maxItems: body.maxItems ?? 20,
      visibility: body.visibility ?? "public",
    },
  });

  await recordAudit({
    adminId: admin.id,
    action: "admin.homepage.add",
    targetType: "homepage_section",
    targetId: section.id,
    metadata: { name: body.name, type: body.type },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ section });
});
