import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getEmailProvider } from "@/lib/email";

/**
 * GET /api/v1/admin/email/status
 *
 * Returns the current email provider + safe configuration status. Used by
 * the admin panel to show whether Resend is wired up correctly.
 *
 * SECURITY: NEVER returns the API key, the from address value, or any
 * credential. Only returns boolean flags: provider name + isConfigured.
 */
export const GET = apiHandler(async () => {
  await requireAdmin();

  const providerName = getEmailProvider().name;
  const hasApiKey =
    typeof process.env.RESEND_API_KEY === "string" &&
    process.env.RESEND_API_KEY.trim().length > 0;
  const hasFromEmail =
    typeof process.env.RESEND_FROM_EMAIL === "string" &&
    process.env.RESEND_FROM_EMAIL.trim().length > 0;

  return ok({
    provider: providerName,
    // For the "resend" provider: is the API key configured?
    configured: providerName === "resend" ? hasApiKey : true,
    // Whether a custom sender (RESEND_FROM_EMAIL) is set.
    customSender: hasFromEmail,
    // Hint string shown in the admin UI — never reveals the actual values.
    hint:
      providerName === "console"
        ? "Emails are logged to the server console (dev mode). Set EMAIL_PROVIDER=resend in Netlify Environment Variables to send real email."
        : providerName === "resend" && !hasApiKey
          ? "EMAIL_PROVIDER is 'resend' but RESEND_API_KEY is not set. Add it in Netlify Environment Variables and redeploy."
          : providerName === "resend" && !hasFromEmail
            ? "Resend is configured with the default test sender (onboarding@resend.dev). Set RESEND_FROM_EMAIL to use your own domain."
            : "Resend is configured and ready to send email.",
  });
});
