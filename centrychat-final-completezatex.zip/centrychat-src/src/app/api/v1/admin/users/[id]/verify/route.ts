import { apiHandler, ok, notFound, parseJsonBody } from "@/lib/api";
import { requireAdmin, ForbiddenError } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { isSuperAdmin, hasRole } from "@/lib/permissions";

/**
 * POST /api/v1/admin/users/:id/verify
 * ------------------------------------
 * Toggle the verified badge on a user. Only admins can do this.
 *
 * SECURITY (hardened):
 *   - `requireAdmin()` — ADMIN or SUPER_ADMIN (server-side enforced).
 *   - RANK GUARDRAIL: a non-SUPER_ADMIN cannot verify/unverify another
 *     ADMIN or SUPER_ADMIN (mirrors the bulk-verify + single-action
 *     routes' rank protection). Previously missing — an ADMIN could
 *     verify another ADMIN, which is a privilege boundary the bulk
 *     routes already enforced.
 *   - Self-targeting is allowed (an admin can verify themselves — this
 *     matches the bulk-verify route's behavior). The guard is about
 *     RANK, not self-targeting.
 *   - Audit logged.
 *
 * Response shape:
 *   - 200 OK with `{ verified: boolean }` on success.
 *   - 404 if the user doesn't exist (no information disclosure).
 *   - 403 if the admin lacks rank to act on the target.
 */
export const POST = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  const body = await parseJsonBody<{ verified?: boolean }>(req);
  const verified = body.verified ?? true;

  const target = await db.user.findUnique({
    where: { id },
    select: { id: true, role: true, isVerified: true },
  });
  if (!target) return notFound("User not found");

  // Rank guardrail — mirrors src/app/api/v1/admin/users/bulk-verify/route.ts
  // lines 138-146: a non-SUPER_ADMIN cannot verify/unverify another ADMIN
  // or SUPER_ADMIN. This prevents an ADMIN from silently verifying another
  // ADMIN (which would be a privilege boundary the bulk route already
  // enforced — the single-action route now matches).
  if (
    !isSuperAdmin(admin.role) &&
    hasRole(target.role, "ADMIN")
  ) {
    throw new ForbiddenError(
      "Only super admins can verify or unverify another admin"
    );
  }

  await db.user.update({
    where: { id },
    data: { isVerified: verified },
  });

  await recordAudit({
    adminId: admin.id,
    action: verified ? "admin.user.verify" : "admin.user.unverify",
    targetType: "user",
    targetId: id,
    metadata: { verified },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ verified });
});
