import { apiHandler, notFound, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

/**
 * GET /api/v1/admin/users/:id
 * ----------------------------
 * Admin user detail inspection (spec §6, §7, §14).
 *
 * Returns:
 *   - Full profile info (username, fullName, email, role, status, bio,
 *     avatarUrl, avatarColor, isVerified, emailVerified, lastSeenAt,
 *     createdAt, twoFactorEnabled).
 *   - User statistics (spec §14): posts count, published articles count,
 *     followers count, following count, likes received, comments
 *     received, unique views received, shares received. All computed
 *     via efficient count queries with nested filters (no N+1).
 *   - Recent content (spec §7): last 5 posts, last 5 published articles.
 *   - Active admin sessions (security audit).
 *   - Related reports (moderation).
 *
 * SECURITY (spec §6, §26):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only (server-side).
 *   - No passwords, tokens, or authentication secrets exposed.
 *   - No private message content exposed.
 *
 * Performance (spec §25):
 *   - Engagement stats: 8 parallel count queries (PostLike/ArticleLike/
 *     PostComment/ArticleComment/PostView/ArticleView/PostInteraction/
 *     ArticleInteraction with nested authorId filter). No N+1.
 *   - Recent content: 2 findMany queries (posts + articles).
 *   - Total: ~14 queries, all parallel.
 */
export const GET = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;

  // Fetch the user's profile + basic _count.
  const user = await db.user.findUnique({
    where: { id },
    select: {
      id: true,
      fullName: true,
      email: true,
      emailVerified: true,
      role: true,
      status: true,
      lastSeenAt: true,
      createdAt: true,
      updatedAt: true,
      twoFactorEnabled: true,
      bio: true,
      avatarColor: true,
      avatarUrl: true,
      username: true,
      isVerified: true,
      language: true,
      _count: {
        select: {
          posts: true,
          articles: true,
          followers: true,
          following: true,
          messages: { where: { deletedAt: null } },
          reportsMade: true,
          reportsTarget: true,
          adminSessions: true,
        },
      },
    },
  });
  if (!user) return notFound("User not found");

  // ── Engagement stats: likes/comments/views/shares received ──────
  // These count ALL interactions on the user's posts + articles.
  // Uses nested Prisma filtering (post: { authorId: id }) — efficient,
  // no N+1, all in parallel.
  const [
    postLikesReceived, articleLikesReceived,
    postCommentsReceived, articleCommentsReceived,
    postViewsReceived, articleViewsReceived,
    postSharesReceived, articleSharesReceived,
    publishedArticleCount,
  ] = await Promise.all([
    db.postLike.count({ where: { post: { authorId: id } } }),
    db.articleLike.count({ where: { article: { authorId: id } } }),
    db.postComment.count({ where: { post: { authorId: id } } }),
    db.articleComment.count({ where: { article: { authorId: id } } }),
    db.postView.count({ where: { post: { authorId: id } } }),
    db.articleView.count({ where: { article: { authorId: id } } }),
    db.postInteraction.count({ where: { type: "SHARE", post: { authorId: id } } }),
    db.articleInteraction.count({ where: { type: "SHARE", article: { authorId: id } } }),
    db.article.count({ where: { authorId: id, status: "PUBLISHED" } }),
  ]);

  const likesReceived = postLikesReceived + articleLikesReceived;
  const commentsReceived = postCommentsReceived + articleCommentsReceived;
  const viewsReceived = postViewsReceived + articleViewsReceived;
  const sharesReceived = postSharesReceived + articleSharesReceived;

  // ── Recent content (spec §7) ─────────────────────────────────────
  const [recentPosts, recentArticles, sessions, reports] = await Promise.all([
    db.post.findMany({
      where: { authorId: id },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true, content: true, createdAt: true,
        _count: { select: { likes: true, comments: true, views: true } },
      },
    }),
    db.article.findMany({
      where: { authorId: id, status: "PUBLISHED" },
      orderBy: { publishedAt: "desc" },
      take: 5,
      select: {
        id: true, title: true, excerpt: true, coverImage: true,
        publishedAt: true, readingTime: true,
        _count: { select: { likes: true, comments: true, views: true } },
      },
    }).catch(() => []),
    db.adminSession.findMany({
      where: { userId: id },
      orderBy: { lastActiveAt: "desc" },
      take: 10,
      select: {
        id: true, sessionId: true, ipAddress: true, userAgent: true,
        createdAt: true, lastActiveAt: true, expiresAt: true,
      },
    }).catch(() => []),
    db.report.findMany({
      where: { OR: [{ reporterId: id }, { targetUserId: id }] },
      orderBy: { createdAt: "desc" },
      take: 10,
      select: {
        id: true, reporterId: true, targetUserId: true,
        reason: true, description: true, status: true, createdAt: true,
      },
    }).catch(() => []),
  ]);

  await recordAudit({
    adminId: admin.id,
    action: "admin.user.view",
    targetType: "user",
    targetId: id,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({
    user: {
      ...user,
      // Engagement stats (spec §14).
      stats: {
        posts: user._count.posts,
        publishedArticles: publishedArticleCount,
        draftArticles: user._count.articles - publishedArticleCount,
        followers: user._count.followers,
        following: user._count.following,
        likesReceived,
        commentsReceived,
        viewsReceived,
        sharesReceived,
        // Engagement rate (spec §14): (likes + comments + shares) / uniqueViews.
        // Handles zero safely — never NaN/Infinity.
        engagementRate: viewsReceived > 0
          ? Math.round(((likesReceived + commentsReceived + sharesReceived) / viewsReceived) * 1000) / 10
          : 0,
      },
      // Recent content (spec §7).
      recentPosts: recentPosts.map((p) => ({
        id: p.id,
        content: p.content.slice(0, 150),
        createdAt: p.createdAt.toISOString(),
        likeCount: p._count.likes,
        commentCount: p._count.comments,
        viewCount: p._count.views,
      })),
      recentArticles: recentArticles.map((a) => ({
        id: a.id,
        title: a.title,
        excerpt: a.excerpt,
        coverImage: a.coverImage,
        publishedAt: a.publishedAt?.toISOString() ?? null,
        readingTime: a.readingTime,
        likeCount: a._count.likes,
        commentCount: a._count.comments,
        viewCount: a._count.views,
      })),
    },
    sessions,
    reports,
  });
});
