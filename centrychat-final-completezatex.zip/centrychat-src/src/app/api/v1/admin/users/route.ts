import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/admin/users
 * ------------------------
 * Admin user management list (spec §2-§6, §14-§18, §24-§26).
 *
 * Features:
 *   - Case-insensitive search (Prisma `mode: "insensitive"` → PostgreSQL ILIKE)
 *     on fullName, email, username (spec §2).
 *   - Extended filters: role, status, verified, new (last 7 days),
 *     inactive (lastSeen > 7 days ago) (spec §4).
 *   - Extended sorting: createdAt (newest/oldest), email, fullName,
 *     lastSeenAt (most active), followers _count, following _count,
 *     posts _count, articles _count (spec §5).
 *   - Includes _count for followers, following, posts, articles per
 *     user — no N+1 (spec §15, §25).
 *   - Offset pagination (spec §24) — sufficient for admin browsing.
 *     For millions of users, a future iteration can switch to cursor.
 *
 * SECURITY (spec §2, §26):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only (server-side).
 *   - No passwords, tokens, or secrets exposed.
 *   - All queries use Prisma parameterized queries (no SQL injection).
 *
 * Performance (spec §25):
 *   - 2 queries: findMany (with _count aggregation) + count.
 *   - _count uses Prisma's LEFT JOIN + COUNT(*) — no N+1.
 *   - All sort options use database-level orderBy (no JS sorting).
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const url = new URL(req.url);

  // Search query (spec §2).
  const q = (url.searchParams.get("q") ?? "").trim();

  // Role filter (spec §4): USER | MODERATOR | ADMIN | SUPER_ADMIN.
  const role = url.searchParams.get("role") ?? "";

  // Status filter (spec §4): ACTIVE | SUSPENDED | BANNED | PENDING_VERIFICATION.
  const status = url.searchParams.get("status") ?? "";

  // Extended filter (spec §4): verified | new | inactive | admins | super_admins | normal.
  const filter = url.searchParams.get("filter") ?? "";

  // Pagination (spec §24).
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(50, Number(url.searchParams.get("pageSize") ?? "20"));

  // Sorting (spec §5).
  const sortBy = (url.searchParams.get("sortBy") ?? "createdAt") as
    | "createdAt"
    | "email"
    | "fullName"
    | "lastSeenAt"
    | "role"
    | "followers"
    | "following"
    | "posts"
    | "articles";
  const sortDir = url.searchParams.get("sortDir") === "asc" ? "asc" : "desc";

  // ── Build the WHERE clause ────────────────────────────────────────
  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const where: Prisma.UserWhereInput = {
    AND: [
      // Search (case-insensitive).
      q
        ? {
            OR: [
              { fullName: { contains: q, mode: "insensitive" } },
              { email: { contains: q, mode: "insensitive" } },
              { username: { contains: q, mode: "insensitive" } },
            ],
          }
        : {},
      // Role filter.
      role ? { role } : {},
      // Status filter.
      status ? { status } : {},
      // Extended filters.
      filter === "verified" ? { isVerified: true } : {},
      filter === "new" ? { createdAt: { gte: sevenDaysAgo } } : {},
      filter === "inactive" ? { lastSeenAt: { lt: sevenDaysAgo } } : {},
      filter === "admins" ? { role: { in: ["ADMIN", "SUPER_ADMIN"] } } : {},
      filter === "super_admins" ? { role: "SUPER_ADMIN" } : {},
      filter === "normal" ? { role: "USER" } : {},
    ],
  };

  // ── Build the orderBy clause ──────────────────────────────────────
  // For relation-count sorts, Prisma supports `orderBy: { followers: { _count: "desc" } }`.
  let orderBy: Prisma.UserOrderByWithRelationInput;
  switch (sortBy) {
    case "followers":
      orderBy = { followers: { _count: sortDir } };
      break;
    case "following":
      orderBy = { following: { _count: sortDir } };
      break;
    case "posts":
      orderBy = { posts: { _count: sortDir } };
      break;
    case "articles":
      orderBy = { articles: { _count: sortDir } };
      break;
    default:
      orderBy = { [sortBy]: sortDir } as Prisma.UserOrderByWithRelationInput;
  }

  const [users, total] = await Promise.all([
    db.user.findMany({
      where,
      orderBy,
      skip: (page - 1) * pageSize,
      take: pageSize,
      select: {
        id: true,
        fullName: true,
        email: true,
        username: true,
        emailVerified: true,
        role: true,
        status: true,
        isVerified: true,
        lastSeenAt: true,
        createdAt: true,
        twoFactorEnabled: true,
        avatarColor: true,
        avatarUrl: true,
        bio: true,
        _count: {
          select: {
            followers: true,
            following: true,
            posts: true,
            articles: { where: { status: "PUBLISHED" } },
          },
        },
      },
    }),
    db.user.count({ where }),
  ]);

  await recordAudit({
    adminId: admin.id,
    action: "admin.users.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
    metadata: { q, role, status, filter, page, pageSize, sortBy, sortDir },
  });

  return ok({
    users,
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
  });
});
