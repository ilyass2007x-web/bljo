import { apiHandler, badRequest, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin, ForbiddenError, NotFoundError } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { destroyAllUserSessions } from "@/lib/auth/session";
import { isSuperAdmin, hasRole, type Role } from "@/lib/permissions";

const ALLOWED_ACTIONS = [
  "SUSPEND",
  "UNSUSPEND",
  "BAN",
  "UNBAN",
  "VERIFY_EMAIL",
  "SET_ROLE",
  "DELETE",
] as const;
type Action = (typeof ALLOWED_ACTIONS)[number];

export const POST = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  const body = await parseJsonBody<{
    action?: string;
    role?: string;
    reason?: string;
  }>(req);

  const action = body.action as Action | undefined;
  if (!action || !ALLOWED_ACTIONS.includes(action)) {
    return badRequest("Invalid action");
  }

  const target = await db.user.findUnique({ where: { id } });
  if (!target) throw new NotFoundError("User not found");

  // Guardrails.
  if (action === "SET_ROLE") {
    const newRole = body.role as Role | undefined;
    if (!newRole || !["USER", "MODERATOR", "ADMIN", "SUPER_ADMIN"].includes(newRole)) {
      return badRequest("Invalid role");
    }
    // Only SUPER_ADMIN can grant ADMIN or SUPER_ADMIN.
    if (
      (newRole === "ADMIN" || newRole === "SUPER_ADMIN") &&
      !isSuperAdmin(admin.role)
    ) {
      throw new ForbiddenError("Only super admins can grant admin roles");
    }
    // Cannot demote someone of equal or higher rank unless super admin.
    if (!isSuperAdmin(admin.role) && hasRole(target.role, "ADMIN")) {
      throw new ForbiddenError("Cannot modify another admin");
    }
    await db.user.update({ where: { id }, data: { role: newRole } });
  } else if (action === "DELETE") {
    if (!isSuperAdmin(admin.role)) {
      throw new ForbiddenError("Only super admins can delete users");
    }
    if (target.id === admin.id) {
      throw new ForbiddenError("Cannot delete your own account");
    }
    await db.user.delete({ where: { id } });
  } else if (action === "SUSPEND") {
    // Self-protection (spec §20): can't suspend yourself.
    if (target.id === admin.id) {
      throw new ForbiddenError("Cannot suspend your own account");
    }
    if (!isSuperAdmin(admin.role) && hasRole(target.role, "ADMIN")) {
      throw new ForbiddenError("Cannot suspend another admin");
    }
    await db.user.update({ where: { id }, data: { status: "SUSPENDED" } });
    await destroyAllUserSessions(id);
  } else if (action === "BAN") {
    // Self-protection (spec §20): can't ban yourself.
    if (target.id === admin.id) {
      throw new ForbiddenError("Cannot ban your own account");
    }
    // Super-admin protection (spec §21): only super admin can ban another admin.
    if (!isSuperAdmin(admin.role) && hasRole(target.role, "ADMIN")) {
      throw new ForbiddenError("Cannot ban another admin");
    }
    await db.user.update({ where: { id }, data: { status: "BANNED" } });
    await destroyAllUserSessions(id);
  } else if (action === "UNSUSPEND" || action === "UNBAN") {
    await db.user.update({ where: { id }, data: { status: "ACTIVE" } });
  } else if (action === "VERIFY_EMAIL") {
    await db.user.update({
      where: { id },
      data: { emailVerified: new Date(), status: "ACTIVE" },
    });
  }

  await recordAudit({
    adminId: admin.id,
    action: `admin.user.${action.toLowerCase()}`,
    targetType: "user",
    targetId: id,
    metadata: { role: body.role, reason: body.reason, targetEmail: target.email },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ action, userId: id });
});
