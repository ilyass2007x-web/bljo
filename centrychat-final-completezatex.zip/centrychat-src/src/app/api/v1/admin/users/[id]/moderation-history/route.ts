import { apiHandler, ok, notFound } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { getUserModerationHistory, getUserWarnings } from "@/lib/moderation/warnings";

/**
 * GET /api/v1/admin/users/:id/moderation-history
 * ----------------------------------------------
 * Returns the unified moderation history for a user:
 *   - Warnings (from UserWarning table)
 *   - Moderation events (automated flags from ModerationEvent table)
 *   - Reports (user-submitted reports where this user is the target)
 *
 * Also returns summary stats:
 *   - totalWarnings
 *   - totalModerationEvents
 *   - totalReports
 *   - warningsByReason (for the "violations by category" chart)
 *
 * Used by the admin user detail panel to show a complete moderation timeline.
 *
 * Security: requireAdmin. The caller's rank guardrail (cannot view an admin
 * with equal or higher rank) is NOT enforced here — admins can view each
 * other's moderation history for accountability. SUPER_ADMIN-only actions
 * (like deleting a user) are enforced at the action endpoints, not here.
 */
export const GET = apiHandler(async (_req, ctx) => {
  await requireAdmin();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("User not found.");

  // Verify the user exists.
  const user = await db.user.findUnique({
    where: { id },
    select: { id: true, fullName: true, username: true, role: true },
  });
  if (!user) return notFound("User not found.");

  const [history, warnings] = await Promise.all([
    getUserModerationHistory(id),
    getUserWarnings(id),
  ]);

  // Summary stats.
  const totalWarnings = warnings.length;
  const totalModerationEvents = history.filter((h) => h.type === "moderation_event").length;
  const totalReports = history.filter((h) => h.type === "report").length;

  // Warnings by reason (for the "violations by category" chart).
  const warningsByReason: Record<string, number> = {};
  for (const w of warnings) {
    warningsByReason[w.reason] = (warningsByReason[w.reason] ?? 0) + 1;
  }

  return ok({
    user: {
      id: user.id,
      fullName: user.fullName,
      username: user.username,
      role: user.role,
    },
    history,
    summary: {
      totalWarnings,
      totalModerationEvents,
      totalReports,
      warningsByReason,
    },
  });
});
