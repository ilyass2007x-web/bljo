import { apiHandler, badRequest, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin, ForbiddenError } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { destroyAllUserSessions } from "@/lib/auth/session";
import { isSuperAdmin, hasRole, type Role } from "@/lib/permissions";
import { logger } from "@/lib/logging";

/**
 * POST /api/v1/admin/users/bulk-action
 * --------------------------------------
 * Bulk user actions (spec §23).
 *
 * Request body:
 *   { userIds: string[], action: "SUSPEND" | "UNSUSPEND" | "BAN" | "UNBAN" }
 *
 * SECURITY (spec §20, §21, §26):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Self-protection: the admin's own ID is automatically excluded
 *     (can't suspend/ban yourself — spec §20).
 *   - Super-admin protection: SUPER_ADMIN users are excluded for
 *     non-super-admin actors (an Admin can't suspend a Super Admin —
 *     spec §21).
 *   - Admin-to-admin protection: an Admin can't suspend/ban another
 *     Admin — only Super Admin can.
 *   - Role changes are NOT bulk-enabled (spec §23: "Role changes
 *     should NOT be bulk-enabled unless explicitly safe").
 *
 * Returns partial failure reporting (spec §23): the truth about how
 * many were updated vs how many were skipped (and why).
 */
const ALLOWED_BULK_ACTIONS = ["SUSPEND", "UNSUSPEND", "BAN", "UNBAN"] as const;
type BulkAction = (typeof ALLOWED_BULK_ACTIONS)[number];

export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    userIds?: string[];
    action?: string;
    reason?: string;
  }>(req);

  const action = body.action as BulkAction | undefined;
  if (!action || !ALLOWED_BULK_ACTIONS.includes(action)) {
    return badRequest("Invalid action. Allowed: SUSPEND, UNSUSPEND, BAN, UNBAN");
  }

  if (!Array.isArray(body.userIds) || body.userIds.length === 0) {
    return badRequest("userIds must be a non-empty array");
  }

  // Cap at 100 users per bulk action (spec §24 — scalable).
  const userIds = body.userIds.slice(0, 100);

  // ── Self-protection (spec §20): exclude the admin's own ID ────────
  const filteredIds = userIds.filter((id) => id !== admin.id);

  // Fetch all target users to check permissions.
  const targets = await db.user.findMany({
    where: { id: { in: filteredIds } },
    select: { id: true, role: true, status: true, email: true },
  });

  const targetMap = new Map(targets.map((t) => [t.id, t]));
  const actorIsSuperAdmin = isSuperAdmin(admin.role);

  // ── Process each user ─────────────────────────────────────────────
  let updated = 0;
  let skipped = 0;
  const skipReasons = { notFound: 0, insufficientRank: 0, alreadySet: 0 };

  for (const userId of filteredIds) {
    const target = targetMap.get(userId);
    if (!target) {
      skipped++;
      skipReasons.notFound++;
      continue;
    }

    // Super-admin protection (spec §21): non-super-admin can't
    // act on SUPER_ADMIN users.
    if (target.role === "SUPER_ADMIN" && !actorIsSuperAdmin) {
      skipped++;
      skipReasons.insufficientRank++;
      continue;
    }

    // Admin-to-admin protection: non-super-admin can't act on ADMIN users.
    if (hasRole(target.role, "ADMIN") && !actorIsSuperAdmin) {
      skipped++;
      skipReasons.insufficientRank++;
      continue;
    }

    // Check if the action would be a no-op (already in target status).
    const newStatus = action === "SUSPEND" ? "SUSPENDED"
      : action === "BAN" ? "BANNED"
      : "ACTIVE"; // UNSUSPEND, UNBAN
    if (target.status === newStatus) {
      skipped++;
      skipReasons.alreadySet++;
      continue;
    }

    try {
      await db.user.update({
        where: { id: userId },
        data: { status: newStatus },
      });

      // Destroy all sessions for SUSPEND/BAN (spec §8 — user can't
      // continue using the platform).
      if (action === "SUSPEND" || action === "BAN") {
        await destroyAllUserSessions(userId);
      }

      // Record audit per user (spec §22 — audit preparation).
      await recordAudit({
        adminId: admin.id,
        action: `admin.user.${action.toLowerCase()}`,
        targetType: "user",
        targetId: userId,
        metadata: {
          reason: body.reason ?? null,
          bulk: true,
          targetEmail: target.email,
        },
        ipAddress: getClientIp(req),
        userAgent: req.headers.get("user-agent") ?? undefined,
      });

      updated++;
    } catch (err) {
      logger.warn("admin", `Bulk ${action} failed for user`, {
        userId,
        error: err instanceof Error ? err.message : String(err),
      });
      skipped++;
      skipReasons.notFound++;
    }
  }

  return ok({
    requested: filteredIds.length,
    updated,
    skipped,
    skippedReasons: skipReasons,
    selfExcluded: userIds.length - filteredIds.length,
  });
});
