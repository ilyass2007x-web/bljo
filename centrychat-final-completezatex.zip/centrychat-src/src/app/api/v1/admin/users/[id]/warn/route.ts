import { apiHandler, ok, badRequest, notFound } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { getClientIp } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import {
  issueWarning,
  validateWarningInput,
  type WarningReason,
} from "@/lib/moderation/warnings";

/**
 * POST /api/v1/admin/users/:id/warn
 * ----------------------------------
 * Issue a formal warning to a user. Creates:
 *   1. A UserWarning row (permanent record in the user's moderation history)
 *   2. A Notification (so the user sees it in their notification bell)
 *   3. An AdminAuditLog entry (for admin accountability)
 *
 * Body:
 *   { reason: string, message: string, moderationEventId?: string }
 *
 * The reason must be one of:
 *   SEXUAL_CONTENT | NUDITY | VIOLENCE | HATE | HARASSMENT | SPAM | MALICIOUS_LINK | OTHER
 *
 * The message is editable by the admin + shown to the user. Max 1000 chars.
 *
 * Security:
 *   - requireAdmin (ADMIN or SUPER_ADMIN)
 *   - Rate-limited (adminWrite: 120/min per admin)
 *   - Cannot warn a user with equal or higher rank (unless SUPER_ADMIN)
 *   - Audit logged
 */
export const POST = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const rl = await checkRateLimit(`admin-write:${admin.id}`, RATE_LIMITS.adminWrite);
  if (!rl.ok) return badRequest("Rate limit exceeded. Please slow down.");

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("User not found.");

  const body = await req.json().catch(() => ({} as unknown));
  const reason = (body as { reason?: unknown })?.reason;
  const message = (body as { message?: unknown })?.message;
  const moderationEventId = (body as { moderationEventId?: unknown })?.moderationEventId;

  if (typeof reason !== "string" || typeof message !== "string") {
    return badRequest("Reason and message are required.");
  }

  const validationError = validateWarningInput({ reason, message });
  if (validationError) return badRequest(validationError);

  // Fetch the target user.
  const target = await db.user.findUnique({
    where: { id },
    select: { id: true, role: true, status: true, fullName: true },
  });
  if (!target) return notFound("User not found.");

  // Rank guardrail: non-SUPER_ADMIN cannot warn ADMIN or SUPER_ADMIN.
  // This mirrors the existing bulk-verify + single-action guardrails.
  if (
    admin.role !== "SUPER_ADMIN" &&
    (target.role === "ADMIN" || target.role === "SUPER_ADMIN")
  ) {
    return badRequest("Insufficient permissions to warn an admin. SUPER_ADMIN access required.");
  }

  // Self-protection: cannot warn yourself.
  if (target.id === admin.id) {
    return badRequest("You cannot warn yourself.");
  }

  const ipAddress = getClientIp(req);
  const userAgent = req.headers.get("user-agent") ?? undefined;

  const warningId = await issueWarning({
    userId: target.id,
    adminId: admin.id,
    reason: reason as WarningReason,
    message,
    moderationEventId: typeof moderationEventId === "string" ? moderationEventId : undefined,
    ipAddress,
    userAgent,
  });

  if (!warningId) {
    return badRequest("Failed to issue warning. Please try again.");
  }

  return ok({
    warningId,
    issued: true,
    message: "Warning sent successfully. The user has been notified.",
  });
});
