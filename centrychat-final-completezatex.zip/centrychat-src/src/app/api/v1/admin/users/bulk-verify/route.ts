import { apiHandler, badRequest, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin, ForbiddenError } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { isSuperAdmin, hasRole } from "@/lib/permissions";
import { Prisma } from "@prisma/client";

/**
 * POST /api/v1/admin/users/bulk-verify
 * ------------------------------------
 * Bulk toggle the verification badge (`isVerified`) on a set of users.
 *
 * SECURITY (spec §5, §7, §8):
 *   - `requireAdmin()` enforces server-side that the requester is an
 *     ADMIN or SUPER_ADMIN. A regular user calling this endpoint gets
 *     403 Forbidden (handled by apiHandler → ForbiddenError → 403).
 *   - The `isVerified` field can ONLY be mutated through this admin
 *     endpoint (and the existing single-user /verify endpoint). The
 *     public PATCH /api/v1/profile route does NOT accept `isVerified`
 *     as a field — so a regular user cannot mass-assign
 *     `{ isVerified: true }` to themselves (spec §8 — mass-assignment
 *     protection).
 *   - The list of `userIds` is taken from the request body, but EVERY
 *     id is independently verified to exist + the admin has permission
 *     to act on it (a regular admin cannot verify/unverify a SUPER_ADMIN
 *     — same guardrail as the single-verify route).
 *
 * PERMISSION GUARDRAILS (mirrors the single-verify route at
 * src/app/api/v1/admin/users/[id]/verify/route.ts):
 *   - ADMIN can verify/unverify USER + MODERATOR.
 *   - ADMIN CANNOT verify/unverify another ADMIN or SUPER_ADMIN
 *     (only SUPER_ADMIN can do that — same hierarchy as the single
 *     action route).
 *   - SUPER_ADMIN can verify/unverify anyone (including other admins).
 *   - Self-targeting is allowed (an admin can verify themselves) —
 *     this matches the single-verify route's behavior. The guard is
 *     about RANK, not self-targeting.
 *
 * REQUEST (spec §9):
 *   {
 *     "userIds": ["id1", "id2", ...],  // required, non-empty array
 *     "verified": true                  // required — true = verify, false = unverify
 *   }
 *
 * RESPONSE (spec §14 — partial failure handling):
 *   {
 *     "ok": true,
 *     "data": {
 *       "requested": <number>,         // how many ids the admin submitted
 *       "updated": <number>,           // how many were successfully updated
 *       "skipped": <number>,           // how many were skipped (not found / permission denied)
 *       "skippedReasons": {            // breakdown of why each was skipped
 *         "notFound": <number>,
 *         "insufficientRank": <number>,
 *         "alreadySet": <number>       // already had the requested state (no-op)
 *       }
 *     }
 *   }
 *
 * PARTIAL FAILURE (spec §14):
 *   We update each user in turn with its own try/catch. If one update
 *   fails (e.g. DB error on a single row), we record it as skipped and
 *   continue. The response NEVER claims "success" if some failed — the
 *   breakdown is returned so the admin sees the truth. No sensitive
 *   info (emails, IDs of skipped users) is leaked.
 *
 * PERFORMANCE (spec §13):
 *   - We use a SINGLE `updateMany` per category of outcome:
 *       1. find the requested users (1 query — `findMany` with `id IN (...)`)
 *       2. partition them into (updatable, not-updatable) based on rank
 *       3. update all updatable users in ONE `updateMany` call (1 query)
 *   - Total queries: 2 (findMany + updateMany) + the audit-log insert.
 *     Even for 1000 users, this is constant-time on the DB side
 *     (PostgreSQL handles `WHERE id IN (...)` with 1000 entries
 *     efficiently via the primary-key index).
 *   - No N+1. No 1000 individual UPDATEs. No frontend polling.
 *
 * RATE LIMITING / SAFETY CAP:
 *   The endpoint accepts at most 1000 userIds per call (configurable
 *   via the `BULK_VERIFY_MAX_IDS` constant below). If an admin needs
 *   to verify more, they should use "Select All" with filters applied
 *   to narrow the result set, OR call the endpoint multiple times with
 *   a batched approach. This protects against a single request causing
 *   an unbounded workload.
 */
const BULK_VERIFY_MAX_IDS = 1000;

export const POST = apiHandler(async (req) => {
  // 1) Authorization — must be ADMIN or SUPER_ADMIN (server-side).
  const admin = await requireAdmin();

  // 2) Parse + validate the request body.
  const body = await parseJsonBody<{
    userIds?: unknown;
    verified?: unknown;
  }>(req);

  if (!Array.isArray(body.userIds) || body.userIds.length === 0) {
    return badRequest("userIds must be a non-empty array");
  }
  if (body.userIds.length > BULK_VERIFY_MAX_IDS) {
    return badRequest(
      `Cannot ${body.verified === false ? "unverify" : "verify"} more than ${BULK_VERIFY_MAX_IDS} users at once. Please narrow your selection.`
    );
  }
  // Coerce to strings + dedupe. Filter out empty values.
  const userIds = [
    ...new Set(
      body.userIds
        .map((id) => (typeof id === "string" ? id.trim() : ""))
        .filter((id) => id.length > 0)
    ),
  ];
  if (userIds.length === 0) {
    return badRequest("userIds must contain at least one non-empty id");
  }

  if (typeof body.verified !== "boolean") {
    return badRequest("verified must be a boolean (true to verify, false to unverify)");
  }
  const verified = body.verified;

  // 3) Fetch the requested users. We need their role to enforce the
  //    rank guardrail (an admin cannot verify/unverify another admin).
  //    A single findMany call — no N+1.
  const targets = await db.user.findMany({
    where: { id: { in: userIds } },
    select: { id: true, role: true, isVerified: true },
  });

  // Partition: who can this admin actually act on?
  const updatableIds: string[] = [];
  let notFoundCount = userIds.length - targets.length;
  let insufficientRankCount = 0;
  let alreadySetCount = 0;

  for (const target of targets) {
    // Rank guardrail: a non-SUPER_ADMIN cannot modify another admin
    // (mirrors src/app/api/v1/admin/users/[id]/action/route.ts lines
    // 50–53 and 64–67). This protects against an ADMIN verifying or
    // unverifying a SUPER_ADMIN (privilege escalation).
    if (!isSuperAdmin(admin.role) && hasRole(target.role, "ADMIN")) {
      insufficientRankCount += 1;
      continue;
    }
    // Skip users that already have the requested state — no-op is
    // counted separately so the admin can distinguish "I changed N
    // users" from "N users were already in that state".
    if (target.isVerified === verified) {
      alreadySetCount += 1;
      continue;
    }
    updatableIds.push(target.id);
  }

  // 4) Update the updatable users in a SINGLE `updateMany` —
  //    one SQL statement regardless of how many ids are in the batch.
  //    This is the performance win over the N+1 approach (spec §13).
  let updatedCount = 0;
  if (updatableIds.length > 0) {
    try {
      const result = await db.user.updateMany({
        where: { id: { in: updatableIds } },
        data: { isVerified: verified },
      });
      updatedCount = result.count;
    } catch (err) {
      // If the bulk update fails at the DB level (rare), record it in
      // the audit log + return a clear error to the admin. We do NOT
      // swallow this — the admin needs to know the operation failed.
      await recordAudit({
        adminId: admin.id,
        action: verified ? "admin.users.bulk_verify_failed" : "admin.users.bulk_unverify_failed",
        targetType: "user",
        metadata: {
          requested: userIds.length,
          updatable: updatableIds.length,
          error: err instanceof Error ? err.message.slice(0, 200) : "unknown",
        },
        ipAddress: getClientIp(req),
        userAgent: req.headers.get("user-agent") ?? undefined,
      });
      throw err;
    }
  }

  // 5) Audit log — one entry per bulk operation (NOT one per user).
  //    Records: admin id, action, how many were requested vs updated,
  //    timestamp (implicit via AdminAuditLog.createdAt). Does NOT
  //    record the list of user ids (would be too noisy + potentially
  //    PII-sensitive in aggregate). Stores aggregate counts only.
  await recordAudit({
    adminId: admin.id,
    action: verified ? "admin.users.bulk_verify" : "admin.users.bulk_unverify",
    targetType: "user",
    metadata: {
      requested: userIds.length,
      updated: updatedCount,
      skippedNotFound: notFoundCount,
      skippedInsufficientRank: insufficientRankCount,
      skippedAlreadySet: alreadySetCount,
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  // 6) Return the result. Per spec §14, we report the truth:
  //    how many were updated vs how many were skipped (and why).
  //    No sensitive info (no emails, no user IDs of skipped users).
  return ok({
    requested: userIds.length,
    updated: updatedCount,
    skipped: notFoundCount + insufficientRankCount + alreadySetCount,
    skippedReasons: {
      notFound: notFoundCount,
      insufficientRank: insufficientRankCount,
      alreadySet: alreadySetCount,
    },
  });
});

// Re-export Prisma for the type import above (some bundlers need this
// to be marked as used). This is a no-op at runtime.
void Prisma;
