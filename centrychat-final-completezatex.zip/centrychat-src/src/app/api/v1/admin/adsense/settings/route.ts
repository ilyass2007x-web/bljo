import { apiHandler, ok, badRequest, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { setSetting } from "@/lib/settings";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  loadAdSenseSettings,
  isValidPublisherId,
  type AdSenseSettings,
} from "@/lib/ads/manager";

/**
 * GET /api/v1/admin/adsense/settings
 * -----------------------------------
 * Returns the current AdSense settings. ADMIN-only.
 *
 * The response includes the publisherId (which is public-safe — see the
 * comment on /api/v1/ads/config — but this endpoint is admin-gated anyway
 * because it's under /admin/*).
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  await recordAudit({
    adminId: admin.id,
    action: "admin.adsense.settings.read",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  const settings = await loadAdSenseSettings();
  return ok({ settings });
});

/**
 * PUT /api/v1/admin/adsense/settings
 * -----------------------------------
 * Updates AdSense settings. ADMIN-only. Validates the publisherId format
 * (spec §2 + §54) — rejects invalid values with a 400.
 *
 * Request body (any subset of these fields — omitted fields are unchanged):
 *   {
 *     enabled?: boolean,
 *     publisherId?: string,         // validated — must match /^ca-pub-\d{16}$/
 *                                   // or be empty (means "not configured")
 *     showToGuests?: boolean,
 *     showToUsers?: boolean,
 *     showToAdmin?: boolean,
 *     maxAdsPerPage?: number,      // 1-20 (sane bounds)
 *     minDistanceSlots?: number,   // 0-20
 *     excludedRoutes?: string[]    // array of view query-strings
 *   }
 */
export const PUT = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    enabled?: boolean;
    publisherId?: string;
    showToGuests?: boolean;
    showToUsers?: boolean;
    showToAdmin?: boolean;
    maxAdsPerPage?: number;
    minDistanceSlots?: number;
    excludedRoutes?: string[];
  }>(req);

  // Validate publisherId if provided (spec §2 + §54).
  if (body.publisherId !== undefined) {
    const trimmed = (body.publisherId ?? "").trim();
    if (!isValidPublisherId(trimmed)) {
      return badRequest(
        'Invalid Publisher ID format. Expected "ca-pub-XXXXXXXXXXXXXXXX" (16 digits) or empty.'
      );
    }
    body.publisherId = trimmed;
  }

  // Validate numeric bounds.
  if (body.maxAdsPerPage !== undefined) {
    if (typeof body.maxAdsPerPage !== "number" || body.maxAdsPerPage < 1 || body.maxAdsPerPage > 20) {
      return badRequest("maxAdsPerPage must be a number between 1 and 20.");
    }
  }
  if (body.minDistanceSlots !== undefined) {
    if (typeof body.minDistanceSlots !== "number" || body.minDistanceSlots < 0 || body.minDistanceSlots > 20) {
      return badRequest("minDistanceSlots must be a number between 0 and 20.");
    }
  }

  // Validate excludedRoutes (must be an array of strings).
  if (body.excludedRoutes !== undefined) {
    if (!Array.isArray(body.excludedRoutes) || body.excludedRoutes.some((r) => typeof r !== "string")) {
      return badRequest("excludedRoutes must be an array of strings.");
    }
  }

  // Persist each provided field. We use the existing setSetting helper so
  // the 30s settings cache is updated + the audit log records each change.
  // (The settings cache uses getSetting which auto-refreshes on next read.)
  const updates: { key: string; value: string }[] = [];
  if (body.enabled !== undefined) updates.push({ key: "adsense.enabled", value: String(body.enabled) });
  if (body.publisherId !== undefined) updates.push({ key: "adsense.publisher_id", value: body.publisherId });
  if (body.showToGuests !== undefined) updates.push({ key: "adsense.show_to_guests", value: String(body.showToGuests) });
  if (body.showToUsers !== undefined) updates.push({ key: "adsense.show_to_users", value: String(body.showToUsers) });
  if (body.showToAdmin !== undefined) updates.push({ key: "adsense.show_to_admin", value: String(body.showToAdmin) });
  if (body.maxAdsPerPage !== undefined) updates.push({ key: "adsense.max_ads_per_page", value: String(body.maxAdsPerPage) });
  if (body.minDistanceSlots !== undefined) updates.push({ key: "adsense.min_distance_slots", value: String(body.minDistanceSlots) });
  if (body.excludedRoutes !== undefined) updates.push({ key: "adsense.excluded_routes", value: body.excludedRoutes.join(",") });

  for (const u of updates) {
    await setSetting(u.key, u.value, admin.id);
  }

  await recordAudit({
    adminId: admin.id,
    action: "admin.adsense.settings.update",
    targetType: "setting",
    targetId: "adsense",
    metadata: { updatedFields: updates.map((u) => u.key) },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const settings: AdSenseSettings = await loadAdSenseSettings();
  return ok({ settings });
});
