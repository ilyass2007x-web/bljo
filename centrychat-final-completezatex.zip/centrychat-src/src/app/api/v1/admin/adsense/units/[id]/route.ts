import { apiHandler, ok, badRequest, notFound, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  isValidAdFormat,
  isValidAdPlacement,
  isValidAdDevice,
  isValidAdPage,
  isValidSlotId,
  serializeDevices,
  serializePages,
  invalidateAdUnitsCache,
  type AdDevice,
  type AdPage,
  type AdFormat,
  type AdPlacement,
} from "@/lib/ads/manager";

/**
 * GET /api/v1/admin/adsense/units/:id
 * -------------------------------------
 * Get a single ad unit by ID. ADMIN-only.
 */
export const GET = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return notFound("Ad unit not found.");

  await recordAudit({
    adminId: admin.id,
    action: "admin.adsense.units.read",
    targetType: "ad_unit",
    targetId: id,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const unit = await db.adUnit.findUnique({ where: { id } });
  if (!unit) return notFound("Ad unit not found.");

  // Reuse the toDTO mapper logic — inline here for simplicity.
  const { parseDevices, parsePages } = await import("@/lib/ads/manager");
  return ok({
    unit: {
      id: unit.id,
      name: unit.name,
      description: unit.description,
      slotId: unit.slotId,
      format: unit.format,
      placement: unit.placement,
      priority: unit.priority,
      active: unit.active,
      devices: parseDevices(unit.devices),
      pages: parsePages(unit.pages),
      rotation: unit.rotation,
      createdAt: unit.createdAt.toISOString(),
      updatedAt: unit.updatedAt.toISOString(),
    },
  });
});

/**
 * PATCH /api/v1/admin/adsense/units/:id
 * --------------------------------------
 * Update an existing ad unit. ADMIN-only. Partial update — only the
 * provided fields are changed.
 *
 * Same validation rules as POST (spec §26 + §54).
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return notFound("Ad unit not found.");

  // Verify the unit exists first (return 404 before parsing the body).
  const existing = await db.adUnit.findUnique({ where: { id }, select: { id: true, name: true } });
  if (!existing) return notFound("Ad unit not found.");

  const body = await parseJsonBody<{
    name?: string;
    description?: string;
    slotId?: string;
    format?: string;
    placement?: string;
    priority?: number;
    active?: boolean;
    devices?: unknown;
    pages?: unknown;
    rotation?: boolean;
  }>(req);

  // Build the update data — only fields that were provided.
  const data: Record<string, unknown> = {};

  if (body.name !== undefined) {
    if (typeof body.name !== "string" || body.name.trim().length < 2 || body.name.trim().length > 100) {
      return badRequest("Name must be 2-100 characters.");
    }
    data.name = body.name.trim();
  }
  if (body.description !== undefined) {
    if (typeof body.description !== "string") return badRequest("Description must be a string.");
    data.description = body.description.trim().slice(0, 500) || null;
  }
  if (body.slotId !== undefined) {
    if (typeof body.slotId !== "string" || !isValidSlotId(body.slotId)) {
      return badRequest("Ad Slot ID must be a numeric string (5-20 digits).");
    }
    data.slotId = body.slotId.trim();
  }
  if (body.format !== undefined) {
    if (typeof body.format !== "string" || !isValidAdFormat(body.format)) {
      return badRequest("Invalid format.");
    }
    data.format = body.format as AdFormat;
  }
  if (body.placement !== undefined) {
    if (typeof body.placement !== "string" || !isValidAdPlacement(body.placement)) {
      return badRequest("Invalid placement.");
    }
    data.placement = body.placement as AdPlacement;
  }
  if (body.priority !== undefined) {
    if (typeof body.priority !== "number" || body.priority < 1 || body.priority > 100) {
      return badRequest("Priority must be 1-100.");
    }
    data.priority = body.priority;
  }
  if (body.active !== undefined) {
    if (typeof body.active !== "boolean") return badRequest("active must be boolean.");
    data.active = body.active;
  }
  if (body.rotation !== undefined) {
    if (typeof body.rotation !== "boolean") return badRequest("rotation must be boolean.");
    data.rotation = body.rotation;
  }
  if (body.devices !== undefined) {
    if (!Array.isArray(body.devices)) return badRequest("devices must be an array.");
    const devices: AdDevice[] = body.devices.filter(
      (d): d is AdDevice => typeof d === "string" && isValidAdDevice(d)
    );
    data.devices = serializeDevices(devices);
  }
  if (body.pages !== undefined) {
    if (!Array.isArray(body.pages)) return badRequest("pages must be an array.");
    const pages: AdPage[] = body.pages.filter(
      (p): p is AdPage => typeof p === "string" && isValidAdPage(p)
    );
    data.pages = serializePages(pages);
  }

  const updated = await db.adUnit.update({
    where: { id },
    data,
  });

  invalidateAdUnitsCache();

  await recordAudit({
    adminId: admin.id,
    action: "admin.adsense.units.update",
    targetType: "ad_unit",
    targetId: id,
    metadata: { updatedFields: Object.keys(data) },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const { parseDevices, parsePages } = await import("@/lib/ads/manager");
  return ok({
    unit: {
      id: updated.id,
      name: updated.name,
      description: updated.description,
      slotId: updated.slotId,
      format: updated.format,
      placement: updated.placement,
      priority: updated.priority,
      active: updated.active,
      devices: parseDevices(updated.devices),
      pages: parsePages(updated.pages),
      rotation: updated.rotation,
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    },
  });
});

/**
 * DELETE /api/v1/admin/adsense/units/:id
 * ---------------------------------------
 * Delete an ad unit. ADMIN-only. Hard delete (no soft-delete column).
 *
 * The confirmation dialog is in the admin UI (spec §53). The server does
 * NOT prompt — it deletes on request. If the unit is referenced by an
 * active <AdSlot>, the next /api/v1/ads/config fetch simply won't return
 * it — no orphan references possible.
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return notFound("Ad unit not found.");

  const existing = await db.adUnit.findUnique({
    where: { id },
    select: { id: true, name: true, placement: true },
  });
  if (!existing) return notFound("Ad unit not found.");

  await db.adUnit.delete({ where: { id } });
  invalidateAdUnitsCache();

  await recordAudit({
    adminId: admin.id,
    action: "admin.adsense.units.delete",
    targetType: "ad_unit",
    targetId: id,
    metadata: { name: existing.name, placement: existing.placement },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ deleted: true, id });
});
