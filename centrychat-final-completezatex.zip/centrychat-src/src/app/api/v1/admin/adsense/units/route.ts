import { apiHandler, ok, badRequest, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  isValidAdFormat,
  isValidAdPlacement,
  isValidAdDevice,
  isValidAdPage,
  isValidSlotId,
  parseDevices,
  parsePages,
  serializeDevices,
  serializePages,
  invalidateAdUnitsCache,
  AD_FORMATS,
  AD_PLACEMENTS,
  AD_DEVICES,
  AD_PAGES,
  type AdFormat,
  type AdPlacement,
  type AdDevice,
  type AdPage,
} from "@/lib/ads/manager";

/**
 * AdSense Ad Units — CRUD API.
 *
 * All endpoints require requireAdmin(). The /api/v1/ads/config public
 * endpoint exposes ONLY the active subset — these admin endpoints return
 * the FULL row (including inactive units + description + rotation flag).
 */

interface AdUnitDTO {
  id: string;
  name: string;
  description: string | null;
  slotId: string;
  format: string;
  placement: string;
  priority: number;
  active: boolean;
  devices: AdDevice[];
  pages: AdPage[];
  rotation: boolean;
  createdAt: string;
  updatedAt: string;
}

function toDTO(row: {
  id: string;
  name: string;
  description: string | null;
  slotId: string;
  format: string;
  placement: string;
  priority: number;
  active: boolean;
  devices: string | null;
  pages: string | null;
  rotation: boolean;
  createdAt: Date;
  updatedAt: Date;
}): AdUnitDTO {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    slotId: row.slotId,
    format: row.format,
    placement: row.placement,
    priority: row.priority,
    active: row.active,
    devices: parseDevices(row.devices),
    pages: parsePages(row.pages),
    rotation: row.rotation,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/**
 * Validate a create/update payload.
 * Returns `null` if valid, or an error message string.
 */
function validateUnit(body: {
  name?: unknown;
  slotId?: unknown;
  format?: unknown;
  placement?: unknown;
  priority?: unknown;
  devices?: unknown;
  pages?: unknown;
}): string | null {
  if (typeof body.name !== "string" || body.name.trim().length < 2 || body.name.trim().length > 100) {
    return "Name must be 2-100 characters.";
  }
  if (typeof body.slotId !== "string" || !isValidSlotId(body.slotId)) {
    return "Ad Slot ID must be a numeric string (5-20 digits).";
  }
  if (typeof body.format !== "string" || !isValidAdFormat(body.format)) {
    return `Format must be one of: ${AD_FORMATS.join(", ")}.`;
  }
  if (typeof body.placement !== "string" || !isValidAdPlacement(body.placement)) {
    return `Placement must be one of: ${Object.keys(AD_PLACEMENTS).join(", ")}.`;
  }
  if (body.priority !== undefined) {
    if (typeof body.priority !== "number" || body.priority < 1 || body.priority > 100) {
      return "Priority must be a number between 1 and 100.";
    }
  }
  // devices + pages are optional arrays. We validate the contents below
  // in the body mapper (since the type system can't narrow the unknown).
  return null;
}

/**
 * GET /api/v1/admin/adsense/units
 * ---------------------------------
 * List ALL ad units (active + inactive). ADMIN-only.
 *
 * Query params:
 *   - search (optional, string) — filters by name/description/slotId substring
 *   - status  (optional, "active" | "inactive") — filters by active flag
 *   - placement (optional, AdPlacement) — filters by placement
 *   - format  (optional, AdFormat) — filters by format
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  await recordAudit({
    adminId: admin.id,
    action: "admin.adsense.units.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const url = new URL(req.url);
  const search = url.searchParams.get("search")?.trim() ?? "";
  const status = url.searchParams.get("status"); // "active" | "inactive"
  const placement = url.searchParams.get("placement");
  const format = url.searchParams.get("format");

  const where: Record<string, unknown> = {};
  if (search) {
    where.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { description: { contains: search, mode: "insensitive" } },
      { slotId: { contains: search } },
    ];
  }
  if (status === "active") where.active = true;
  else if (status === "inactive") where.active = false;
  if (placement && isValidAdPlacement(placement)) where.placement = placement;
  if (format && isValidAdFormat(format)) where.format = format;

  const rows = await db.adUnit.findMany({
    where,
    orderBy: [{ placement: "asc" }, { priority: "asc" }, { createdAt: "desc" }],
  });

  return ok({ units: rows.map(toDTO) });
});

/**
 * POST /api/v1/admin/adsense/units
 * ---------------------------------
 * Create a new ad unit. ADMIN-only. Validates all fields (spec §54).
 *
 * Request body:
 *   {
 *     name: string,           // 2-100 chars
 *     description?: string,   // optional, max 500 chars
 *     slotId: string,         // numeric, 5-20 digits
 *     format: AdFormat,       // DISPLAY | RESPONSIVE | IN_FEED | IN_ARTICLE
 *     placement: AdPlacement, // one of AD_PLACEMENTS keys
 *     priority?: number,     // default 10, range 1-100
 *     active?: boolean,      // default true
 *     devices?: AdDevice[],  // default [] (all devices)
 *     pages?: AdPage[],      // default [] (all pages)
 *     rotation?: boolean     // default false
 *   }
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    name?: string;
    description?: string;
    slotId?: string;
    format?: string;
    placement?: string;
    priority?: number;
    active?: boolean;
    devices?: unknown;
    pages?: unknown;
    rotation?: boolean;
  }>(req);

  const err = validateUnit(body);
  if (err) return badRequest(err);

  // Validate + normalize devices + pages (arrays of valid enum values).
  let devices: AdDevice[] = [];
  if (Array.isArray(body.devices)) {
    devices = body.devices.filter(
      (d): d is AdDevice => typeof d === "string" && isValidAdDevice(d)
    );
  }
  let pages: AdPage[] = [];
  if (Array.isArray(body.pages)) {
    pages = body.pages.filter(
      (p): p is AdPage => typeof p === "string" && isValidAdPage(p)
    );
  }

  // Check for duplicate (same slotId + placement) — soft warning, not hard
  // error (admin may want to set up rotation).
  const dup = await db.adUnit.findFirst({
    where: { slotId: body.slotId!, placement: body.placement! },
    select: { id: true, name: true },
  });

  const created = await db.adUnit.create({
    data: {
      name: body.name!.trim(),
      description: typeof body.description === "string" ? body.description.trim().slice(0, 500) : null,
      slotId: body.slotId!.trim(),
      format: body.format! as AdFormat,
      placement: body.placement! as AdPlacement,
      priority: typeof body.priority === "number" ? body.priority : 10,
      active: typeof body.active === "boolean" ? body.active : true,
      devices: serializeDevices(devices),
      pages: serializePages(pages),
      rotation: typeof body.rotation === "boolean" ? body.rotation : false,
    },
  });

  // Invalidate the active-units cache so the new unit appears immediately
  // on the next /api/v1/ads/config fetch (spec §43).
  invalidateAdUnitsCache();

  await recordAudit({
    adminId: admin.id,
    action: "admin.adsense.units.create",
    targetType: "ad_unit",
    targetId: created.id,
    metadata: {
      name: created.name,
      slotId: created.slotId,
      placement: created.placement,
      format: created.format,
      duplicateWarning: dup ? `Existing unit "${dup.name}" (${dup.id}) has the same slotId+placement.` : undefined,
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ unit: toDTO(created), duplicateWarning: dup ? dup.name : null });
});
