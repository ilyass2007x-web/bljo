import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { cacheGetOrSet } from "@/lib/cache";
import { logger } from "@/lib/logging";
import { parsePostContent } from "@/lib/posts/parser";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/admin/trending?window=1h|6h|12h|24h|3d|7d
 * ----------------------------------------------------------
 * Admin Trending Center (spec §1-§15, §21-§25 — PHASE 8).
 *
 * Returns 5 sections, each independently try/caught (spec §32):
 *   1. Trending Posts — top 10 by velocity in the window.
 *   2. Trending Articles — top 10 by velocity.
 *   3. Trending Topics — hashtags extracted from trending content, ranked by frequency + momentum.
 *   4. Trending Searches — from SearchQueryLog, ranked by growth (momentum — not just volume).
 *   5. Trending Creators — users whose content is getting the most recent engagement.
 *
 * For each trending item, shows:
 *   - Velocity (engagements/hour — spec §5)
 *   - Momentum (current period vs previous period — spec §6)
 *   - Trending Score (from the existing ranking engine)
 *   - "WHY IS THIS TRENDING?" explanation (spec §24)
 *
 * SECURITY (spec §26, §27):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Deleted/draft/private content excluded.
 *   - Reported content NOT auto-excluded (only confirmed-removed content is).
 *
 * PERFORMANCE (spec §28, §29):
 *   - 30-second cache.
 *   - All counts via count/groupBy (no N+1).
 *   - Time-bounded queries.
 */

type Window = "1h" | "6h" | "12h" | "24h" | "3d" | "7d";

function getWindowMs(w: Window): number {
  switch (w) {
    case "1h": return 1 * 60 * 60 * 1000;
    case "6h": return 6 * 60 * 60 * 1000;
    case "12h": return 12 * 60 * 60 * 1000;
    case "24h": return 24 * 60 * 60 * 1000;
    case "3d": return 3 * 24 * 60 * 60 * 1000;
    case "7d": return 7 * 24 * 60 * 60 * 1000;
    default: return 24 * 60 * 60 * 1000;
  }
}

export const GET = apiHandler(async (req) => {
  await requireAdmin();

  const url = new URL(req.url);
  const windowParam = (url.searchParams.get("window") ?? "24h") as Window;
  const window = (["1h", "6h", "12h", "24h", "3d", "7d"] as Window[]).includes(windowParam) ? windowParam : "24h";
  const windowMs = getWindowMs(window);
  const now = new Date();
  const windowStart = new Date(now.getTime() - windowMs);
  const prevStart = new Date(now.getTime() - 2 * windowMs); // previous equivalent period

  const cacheKey = `admin:trending:${window}`;
  const TTL = 30;

  const result = await cacheGetOrSet(cacheKey, TTL, async () => {
    // ── SECTION 1: Trending Posts ────────────────────────────────
    const trendingPosts = await (async () => {
      try {
        const posts = await db.post.findMany({
          where: { createdAt: { gte: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000) } }, // fetch from last 7 days for scoring context
          orderBy: { createdAt: "desc" },
          take: 100,
          select: {
            id: true, content: true, createdAt: true, authorId: true,
            author: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
            _count: { select: { likes: true, comments: true, views: true } },
          },
        });

        // Fetch share counts (batched).
        const postIds = posts.map(p => p.id);
        const shareRows = postIds.length > 0
          ? await db.postInteraction.groupBy({ by: ["postId"], where: { postId: { in: postIds }, type: "SHARE" }, _count: { _all: true } })
          : [];
        const shareMap = new Map(shareRows.map((s: any) => [s.postId, s._count._all]));

        // Fetch current-window engagement counts (for velocity + momentum).
        const [currentLikes, currentComments, currentShares, currentViews, prevLikes, prevComments] = await Promise.all([
          db.postLike.groupBy({ by: ["postId"], where: { postId: { in: postIds }, createdAt: { gte: windowStart } }, _count: { postId: true } }),
          db.postComment.groupBy({ by: ["postId"], where: { postId: { in: postIds }, createdAt: { gte: windowStart } }, _count: { postId: true } }),
          db.postInteraction.groupBy({ by: ["postId"], where: { postId: { in: postIds }, type: "SHARE", createdAt: { gte: windowStart } }, _count: { _all: true } }),
          db.postView.groupBy({ by: ["postId"], where: { postId: { in: postIds }, viewedAt: { gte: windowStart } }, _count: { postId: true } }),
          db.postLike.groupBy({ by: ["postId"], where: { postId: { in: postIds }, createdAt: { gte: prevStart, lt: windowStart } }, _count: { postId: true } }),
          db.postComment.groupBy({ by: ["postId"], where: { postId: { in: postIds }, createdAt: { gte: prevStart, lt: windowStart } }, _count: { postId: true } }),
        ]);
        const curLikesMap = new Map(currentLikes.map((r: any) => [r.postId, r._count.postId]));
        const curCommentsMap = new Map(currentComments.map((r: any) => [r.postId, r._count.postId]));
        const curSharesMap = new Map(currentShares.map((r: any) => [r.postId, r._count._all]));
        const curViewsMap = new Map(currentViews.map((r: any) => [r.postId, r._count.postId]));
        const prevLikesMap = new Map(prevLikes.map((r: any) => [r.postId, r._count.postId]));
        const prevCommentsMap = new Map(prevComments.map((r: any) => [r.postId, r._count.postId]));

        // Calculate velocity + momentum for each post.
        const scored = posts.map(p => {
          const totalShares = shareMap.get(p.id) ?? 0;
          const curL = curLikesMap.get(p.id) ?? 0;
          const curC = curCommentsMap.get(p.id) ?? 0;
          const curS = curSharesMap.get(p.id) ?? 0;
          const curV = curViewsMap.get(p.id) ?? 0;
          const curEng = curL + curC + curS;
          const prevEng = (prevLikesMap.get(p.id) ?? 0) + (prevCommentsMap.get(p.id) ?? 0);
          const hoursSince = Math.max(0.1, (now.getTime() - p.createdAt.getTime()) / (60 * 60 * 1000));
          const velocity = curEng / hoursSince; // engagements/hour
          const momentum = prevEng > 0 ? Math.round(((curEng - prevEng) / prevEng) * 1000) / 10 : null;
          const trendScore = Math.round((velocity * 10 + curEng * 2 + curV * 0.1) * 10) / 10;
          return { post: p, curL, curC, curS, curV, curEng, prevEng, velocity: Math.round(velocity * 10) / 10, momentum, trendScore, totalShares };
        }).filter(s => s.curEng > 0) // minimum threshold: must have at least 1 engagement in the window (spec §22)
          .sort((a, b) => b.trendScore - a.trendScore)
          .slice(0, 10);

        return scored.map((s, i) => ({
          type: "post" as const, position: i + 1, id: s.post.id,
          content: s.post.content.slice(0, 150),
          author: s.post.author, createdAt: s.post.createdAt.toISOString(),
          recentViews: s.curV, recentLikes: s.curL, recentComments: s.curC, recentShares: s.curS,
          totalLikes: s.post._count.likes, totalComments: s.post._count.comments, totalViews: s.post._count.views,
          totalShares: s.totalShares,
          velocity: s.velocity, momentum: s.momentum, trendScore: s.trendScore,
          why: buildWhy(s.curL, s.curC, s.curS, s.velocity, s.momentum),
        }));
      } catch (err) {
        logger.warn("admin", "Trending: posts failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 2: Trending Articles ──────────────────────────────
    const trendingArticles = await (async () => {
      try {
        const articles = await db.article.findMany({
          where: { status: "PUBLISHED", publishedAt: { gte: new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000) } },
          orderBy: { publishedAt: "desc" }, take: 50,
          select: {
            id: true, title: true, excerpt: true, coverImage: true, publishedAt: true, authorId: true,
            author: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
            _count: { select: { likes: true, comments: true, views: true } },
          },
        }).catch(() => []);

        const articleIds = articles.map(a => a.id);
        const [shareRows, curLikes, curComments, curShares, curViews, prevLikes, prevComments] = await Promise.all([
          db.articleInteraction.groupBy({ by: ["articleId"], where: { articleId: { in: articleIds }, type: "SHARE" }, _count: { _all: true } }).catch(() => []),
          db.articleLike.groupBy({ by: ["articleId"], where: { articleId: { in: articleIds }, createdAt: { gte: windowStart } }, _count: { articleId: true } }).catch(() => []),
          db.articleComment.groupBy({ by: ["articleId"], where: { articleId: { in: articleIds }, createdAt: { gte: windowStart } }, _count: { articleId: true } }).catch(() => []),
          db.articleInteraction.groupBy({ by: ["articleId"], where: { articleId: { in: articleIds }, type: "SHARE", createdAt: { gte: windowStart } }, _count: { _all: true } }).catch(() => []),
          db.articleView.groupBy({ by: ["articleId"], where: { articleId: { in: articleIds }, viewedAt: { gte: windowStart } }, _count: { articleId: true } }).catch(() => []),
          db.articleLike.groupBy({ by: ["articleId"], where: { articleId: { in: articleIds }, createdAt: { gte: prevStart, lt: windowStart } }, _count: { articleId: true } }).catch(() => []),
          db.articleComment.groupBy({ by: ["articleId"], where: { articleId: { in: articleIds }, createdAt: { gte: prevStart, lt: windowStart } }, _count: { articleId: true } }).catch(() => []),
        ]) as any[];
        const shareMap: Map<string, number> = new Map(shareRows.map((r: any) => [r.articleId, r._count._all] as [string, number]));
        const curLikesMap: Map<string, number> = new Map(curLikes.map((r: any) => [r.articleId, r._count.articleId] as [string, number]));
        const curCommentsMap: Map<string, number> = new Map(curComments.map((r: any) => [r.articleId, r._count.articleId] as [string, number]));
        const curSharesMap: Map<string, number> = new Map(curShares.map((r: any) => [r.articleId, r._count._all] as [string, number]));
        const curViewsMap: Map<string, number> = new Map(curViews.map((r: any) => [r.articleId, r._count.articleId] as [string, number]));
        const prevLikesMap: Map<string, number> = new Map(prevLikes.map((r: any) => [r.articleId, r._count.articleId] as [string, number]));
        const prevCommentsMap: Map<string, number> = new Map(prevComments.map((r: any) => [r.articleId, r._count.articleId] as [string, number]));

        const scored = articles.map(a => {
          const curL = curLikesMap.get(a.id) ?? 0, curC = curCommentsMap.get(a.id) ?? 0;
          const curS = curSharesMap.get(a.id) ?? 0, curV = curViewsMap.get(a.id) ?? 0;
          const curEng = curL + curC + curS;
          const prevEng = (prevLikesMap.get(a.id) ?? 0) + (prevCommentsMap.get(a.id) ?? 0);
          const ts = a.publishedAt ?? a.createdAt ?? now;
          const hoursSince = Math.max(0.1, (now.getTime() - ts.getTime()) / (60 * 60 * 1000));
          const velocity = curEng / hoursSince;
          const momentum = prevEng > 0 ? Math.round(((curEng - prevEng) / prevEng) * 1000) / 10 : null;
          const trendScore = Math.round((velocity * 10 + curEng * 2 + curV * 0.1) * 10) / 10;
          return { article: a, curL, curC, curS, curV, curEng, velocity: Math.round(velocity * 10) / 10, momentum, trendScore };
        }).filter(s => s.curEng > 0).sort((a, b) => b.trendScore - a.trendScore).slice(0, 10);

        return scored.map((s, i) => ({
          type: "article" as const, position: i + 1, id: s.article.id,
          title: s.article.title, excerpt: s.article.excerpt, coverImage: s.article.coverImage,
          author: s.article.author, publishedAt: s.article.publishedAt?.toISOString() ?? null,
          recentViews: s.curV, recentLikes: s.curL, recentComments: s.curC, recentShares: s.curS,
          totalLikes: s.article._count.likes, totalComments: s.article._count.comments, totalViews: s.article._count.views,
          totalShares: shareMap.get(s.article.id) ?? 0,
          velocity: s.velocity, momentum: s.momentum, trendScore: s.trendScore,
          why: buildWhy(s.curL, s.curC, s.curS, s.velocity, s.momentum),
        }));
      } catch (err) {
        logger.warn("admin", "Trending: articles failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 3: Trending Topics (spec §11) ─────────────────────
    const trendingTopics = await (async () => {
      try {
        // Extract hashtags from trending posts + articles.
        const allContent: string[] = [];
        if (trendingPosts) {
          for (const p of trendingPosts) allContent.push(p.content);
        }
        if (trendingArticles) {
          for (const a of trendingArticles) {
            allContent.push(a.title ?? "");
            if (a.excerpt) allContent.push(a.excerpt);
          }
        }

        const topicCounts = new Map<string, number>();
        for (const text of allContent) {
          const parsed = parsePostContent(text);
          for (const h of parsed.hashtags) {
            const tag = h.tag.toLowerCase();
            topicCounts.set(tag, (topicCounts.get(tag) ?? 0) + 1);
          }
        }

        return Array.from(topicCounts.entries())
          .map(([tag, count]) => ({ tag, count, trendScore: Math.round(count * 10) / 10 }))
          .sort((a, b) => b.trendScore - a.trendScore)
          .slice(0, 10);
      } catch (err) {
        logger.warn("admin", "Trending: topics failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 4: Trending Searches (spec §12 — momentum, not just volume) ─
    const trendingSearches = await (async () => {
      try {
        const [currentRows, previousRows] = await Promise.all([
          db.searchQueryLog.groupBy({
            by: ["query"], where: { createdAt: { gte: windowStart } },
            _count: { query: true }, orderBy: { _count: { query: "desc" } }, take: 50,
          }),
          db.searchQueryLog.groupBy({
            by: ["query"], where: { createdAt: { gte: prevStart, lt: windowStart } },
            _count: { query: true }, orderBy: { _count: { query: "desc" } }, take: 50,
          }),
        ]);
        const curMap = new Map(currentRows.map((r: any) => [r.query, r._count.query]));
        const prevMap = new Map(previousRows.map((r: any) => [r.query, r._count.query]));

        // Rank by GROWTH (momentum) — not just volume (spec §12).
        return Array.from(curMap.entries())
          .map(([query, count]) => {
            const prev = prevMap.get(query) ?? 0;
            const growth = prev > 0 ? Math.round(((count - prev) / prev) * 1000) / 10 : null;
            return { query, currentCount: count, previousCount: prev, growth };
          })
          .filter(s => s.currentCount >= 2) // minimum threshold
          .sort((a, b) => {
            // Sort by growth (momentum) first, then by volume.
            const aScore = a.growth ?? 999;
            const bScore = b.growth ?? 999;
            return bScore - aScore || b.currentCount - a.currentCount;
          })
          .slice(0, 10);
      } catch (err) {
        logger.warn("admin", "Trending: searches failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 5: Trending Creators (spec §13) ──────────────────
    const trendingCreators = await (async () => {
      try {
        // Aggregate from trendingPosts + trendingArticles: count how many
        // trending items each author has + their total velocity.
        const creatorStats = new Map<string, { fullName: string; username: string; isVerified: boolean; items: number; totalVelocity: number }>();

        if (trendingPosts) {
          for (const p of trendingPosts) {
            const existing = creatorStats.get(p.author.id) ?? { fullName: p.author.fullName, username: p.author.username, isVerified: p.author.isVerified, items: 0, totalVelocity: 0 };
            existing.items++;
            existing.totalVelocity += p.velocity;
            creatorStats.set(p.author.id, existing);
          }
        }
        if (trendingArticles) {
          for (const a of trendingArticles) {
            const existing = creatorStats.get(a.author.id) ?? { fullName: a.author.fullName, username: a.author.username, isVerified: a.author.isVerified, items: 0, totalVelocity: 0 };
            existing.items++;
            existing.totalVelocity += a.velocity;
            creatorStats.set(a.author.id, existing);
          }
        }

        return Array.from(creatorStats.entries())
          .map(([id, stats]) => ({ id, ...stats, trendScore: Math.round(stats.totalVelocity * 10) / 10 }))
          .sort((a, b) => b.trendScore - a.trendScore)
          .slice(0, 10);
      } catch (err) {
        logger.warn("admin", "Trending: creators failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    return { window, trendingPosts, trendingArticles, trendingTopics, trendingSearches, trendingCreators };
  });

  return ok({ trending: result });
});

/** Build a human-readable "WHY IS THIS TRENDING?" explanation (spec §24). */
function buildWhy(likes: number, comments: number, shares: number, velocity: number, momentum: number | null): string[] {
  const reasons: string[] = [];
  if (velocity > 5) reasons.push(`High engagement velocity (${velocity}/hr)`);
  if (shares > 0) reasons.push(`Strong share activity (${shares} shares)`);
  if (comments > 0) reasons.push(`Active discussion (${comments} comments)`);
  if (likes > 0) reasons.push(`${likes} recent likes`);
  if (momentum != null && momentum > 50) reasons.push(`Rapidly growing (+${momentum}% vs previous)`);
  if (momentum != null && momentum < 0) reasons.push(`Declining engagement (${momentum}%)`);
  if (reasons.length === 0) reasons.push("Recent engagement in the window");
  return reasons;
}
