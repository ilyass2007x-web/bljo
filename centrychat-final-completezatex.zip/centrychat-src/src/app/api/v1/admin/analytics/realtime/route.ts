import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";

/**
 * GET /api/v1/admin/analytics/realtime?minutes=5
 * ------------------------------------------------
 * Real-time traffic (spec §14, §15):
 *   - liveVisitors: count of sessions active in the last N minutes
 *   - currentlyReading: top articles being viewed right now (article_view
 *     events in the last N minutes, grouped by articleId)
 *
 * The `minutes` query param defaults to 5. Supported values: 5, 15, 30.
 *
 * IMPLEMENTATION (spec §14):
 *   We use the AnalyticsSession.lastSeenAt field as the "active" signal.
 *   A session is "live" if its lastSeenAt is within the last N minutes.
 *   This is reliable because every tracked event updates lastSeenAt —
 *   so a visitor who fired an event 2 minutes ago has lastSeenAt ≈ 2 min ago.
 *
 *   NO WebSocket required — this is a polling endpoint. The admin UI polls
 *   every 30 seconds (matching the existing unread-messages polling pattern).
 *
 * SECURITY: requireAdmin().
 *
 * NOT CACHED — real-time data must be fresh. The query is cheap (indexed
 * on lastSeenAt + a small groupBy).
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin;

  const url = new URL(req.url);
  const minutesParam = url.searchParams.get("minutes") ?? "5";
  const minutes = [5, 15, 30].includes(Number(minutesParam)) ? Number(minutesParam) : 5;
  const since = new Date(Date.now() - minutes * 60 * 1000);

  try {
    // ── Live visitors (unique sessions active in the last N minutes) ──
    const liveVisitors = await db.analyticsSession.count({
      where: { lastSeenAt: { gte: since } },
    });

    // ── Currently reading (top articles by article_view events in last N min) ──
    const readingGroups = await db.analyticsEvent.groupBy({
      by: ["articleId"],
      where: {
        eventType: "article_view",
        createdAt: { gte: since },
        articleId: { not: null },
      },
      _count: { id: true },
      orderBy: { _count: { id: "desc" } },
      take: 10,
    });

    // Hydrate article titles.
    const articleIds = readingGroups.map((g) => g.articleId!);
    const articles = articleIds.length > 0
      ? await db.article.findMany({
          where: { id: { in: articleIds } },
          select: { id: true, title: true },
        })
      : [];
    const articleMap = new Map(articles.map((a) => [a.id, a.title]));

    const currentlyReading = readingGroups.map((g) => ({
      articleId: g.articleId!,
      title: articleMap.get(g.articleId!) ?? "(deleted article)",
      readers: g._count.id,
    }));

    return ok({
      analytics: {
        liveVisitors,
        currentlyReading,
        minutes,
        fetchedAt: new Date().toISOString(),
      },
    });
  } catch (err) {
    logger.error("application", "Realtime analytics query failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return ok({
      analytics: {
        liveVisitors: 0,
        currentlyReading: [],
        minutes,
        fetchedAt: new Date().toISOString(),
        error: "Failed to load realtime data",
      },
    });
  }
});
