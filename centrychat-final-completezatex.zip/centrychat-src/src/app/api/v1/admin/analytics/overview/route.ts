import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { cachedAggregate } from "@/lib/analytics/admin-helpers";

/**
 * GET /api/v1/admin/analytics/overview
 * -------------------------------------
 * Article-views overview totals (spec PHASE 11):
 *   - totalViews: total ArticleView rows across all articles (all-time)
 *   - uniqueVisitors: distinct anonymousVisitorId + userId across all
 *     ArticleView rows
 *   - viewsToday / viewsYesterday / viewsLast7Days / viewsLast30Days:
 *     ArticleView counts filtered by viewedAt >= the corresponding cutoff
 *
 * WHY THIS IS A SEPARATE ENDPOINT (and not just folded into /traffic):
 *   The existing /traffic endpoint reads from the AnalyticsEvent table
 *   (granular event log — one row per tracking call, includes page_view
 *   and other event types). This endpoint reads from the ArticleView
 *   table, which is the CANONICAL unique-view source — one row per
 *   (article, user/visitor-token) with DB-level dedup. The two tables
 *   serve different purposes:
 *     - ArticleView  = unique view counts (what's shown on article cards)
 *     - AnalyticsEvent = full traffic event log (what powers the admin
 *       Traffic Analytics dashboard)
 *
 *   This endpoint exists so the admin can see the canonical ArticleView
 *   totals (matching the public view count on each article card) — without
 *   conflating them with the AnalyticsEvent-based metrics in /traffic.
 *
 * PERFORMANCE:
 *   - Each count() uses an indexed createdAt / viewedAt range.
 *   - uniqueVisitors uses two parallel counts (anonymousVisitorId distinct
 *     + userId distinct) since PostgreSQL COUNT(DISTINCT col) on a single
 *     nullable column would miss the dual-key dedup pattern.
 *   - Cached 30 seconds.
 *
 * SECURITY: requireAdmin() — ADMIN/SUPER_ADMIN only.
 */
export const GET = apiHandler(async () => {
  const admin = await requireAdmin();
  void admin;

  const data = await cachedAggregate(`admin:analytics:article-overview:v1`, async () => {
    try {
      const now = new Date();
      const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const startOfYesterday = new Date(startOfToday.getTime() - 24 * 60 * 60 * 1000);
      const last7Days = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const last30Days = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

      const [
        totalViews,
        anonVisitorCount,
        authUserCount,
        viewsToday,
        viewsYesterday,
        viewsLast7Days,
        viewsLast30Days,
      ] = await Promise.all([
        db.articleView.count(),
        // Unique anonymous visitors (distinct anonymousVisitorId, excluding NULL).
        db.articleView.groupBy({
          by: ["anonymousVisitorId"],
          where: { anonymousVisitorId: { not: null } },
          _count: { anonymousVisitorId: true },
        }).then((rows) => rows.length).catch(() => 0),
        // Unique authenticated users (distinct userId, excluding NULL).
        db.articleView.groupBy({
          by: ["userId"],
          where: { userId: { not: null } },
          _count: { userId: true },
        }).then((rows) => rows.length).catch(() => 0),
        db.articleView.count({ where: { viewedAt: { gte: startOfToday } } }),
        db.articleView.count({
          where: { viewedAt: { gte: startOfYesterday, lt: startOfToday } },
        }),
        db.articleView.count({ where: { viewedAt: { gte: last7Days } } }),
        db.articleView.count({ where: { viewedAt: { gte: last30Days } } }),
      ]);

      return {
        totalViews,
        uniqueVisitors: anonVisitorCount + authUserCount,
        viewsToday,
        viewsYesterday,
        viewsLast7Days,
        viewsLast30Days,
      };
    } catch (err) {
      logger.error("application", "Article overview analytics query failed", {
        error: err instanceof Error ? err.message : String(err),
      });
      return {
        totalViews: 0,
        uniqueVisitors: 0,
        viewsToday: 0,
        viewsYesterday: 0,
        viewsLast7Days: 0,
        viewsLast30Days: 0,
        error: "Failed to load overview",
      };
    }
  });

  return ok({ analytics: data });
});
