import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";

/**
 * GET /api/v1/admin/analytics/recent-activity?limit=20
 * -----------------------------------------------------
 * Recent article-view activity feed (spec PHASE 13):
 *   - Returns the most recent ArticleView rows (newest first).
 *   - Each row is enriched with the article title + the traffic source
 *     label + the device/browser/OS parsed from the User-Agent (NOT stored
 *     on ArticleView — derived from AnalyticsEvent when available).
 *   - Does NOT expose visitor IDs (privacy — spec PHASE 21).
 *
 * This powers the "Recent Traffic" section in the admin Traffic Analytics
 * dashboard. It uses the ArticleView table (the canonical unique-view
 * table) so each row in the feed represents one unique visitor's first
 * view of an article (per the first-touch attribution in
 * /api/v1/articles/[id]/views).
 *
 * RESPONSE SHAPE:
 *   {
 *     activity: Array<{
 *       articleId: string,
 *       articleTitle: string,
 *       authorFullName: string | null,        // nullable when article deleted
 *       source: string,                        // "google" | "direct" | etc.
 *       referralDomain: string | null,         // "google.com" | "facebook.com" | null
 *       viewedAt: string,                      // ISO timestamp
 *       device: string | null                  // "mobile" | "desktop" | "tablet" | null
 *     }>,
 *     fetchedAt: string
 *   }
 *
 * WHY THIS IS A SEPARATE ENDPOINT (and not part of /realtime):
 *   /realtime shows COUNTS (live visitors + currently reading top articles).
 *   This endpoint shows the chronological EVENT FEED (one row per recent
 *   unique view). They serve different admin UI sections.
 *
 * PERFORMANCE:
 *   - Single indexed ORDER BY viewedAt DESC LIMIT N query (uses the
 *     ArticleView_viewedAt index).
 *   - Article titles hydrated via a single findMany (IN clause on the
 *     top N articleIds).
 *   - The endpoint is NOT cached (recent activity must be fresh). The
 *     query is cheap (indexed, capped to `limit` rows).
 *
 * SECURITY:
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Never exposes anonymousVisitorId, userId, or IP.
 *   - Device/browser/OS are NOT stored on ArticleView (only on
 *     AnalyticsEvent), so we look them up from the most recent matching
 *     AnalyticsEvent (best-effort — null when not found).
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin;

  const url = new URL(req.url);
  const limitParam = url.searchParams.get("limit") ?? "20";
  // Cap to 1..100 to prevent excessive queries.
  let limit = Number(limitParam);
  if (!Number.isFinite(limit) || limit < 1) limit = 20;
  if (limit > 100) limit = 100;

  try {
    // ── Fetch the most recent ArticleView rows ──
    const recentViews = await db.articleView.findMany({
      orderBy: { viewedAt: "desc" },
      take: limit,
      select: {
        id: true,
        articleId: true,
        source: true,
        referralDomain: true,
        viewedAt: true,
      },
    });

    if (recentViews.length === 0) {
      return ok({
        analytics: {
          activity: [],
          fetchedAt: new Date().toISOString(),
        },
      });
    }

    // ── Hydrate article titles + authors (single findMany) ──
    const articleIds = Array.from(
      new Set(recentViews.map((v) => v.articleId)),
    );
    const articles = await db.article.findMany({
      where: { id: { in: articleIds } },
      select: {
        id: true,
        title: true,
        author: { select: { fullName: true } },
      },
    });
    const articleMap = new Map(articles.map((a) => [a.id, a]));

    // ── Best-effort: enrich with device from AnalyticsEvent ──
    // ArticleView doesn't store device/browser/OS (only AnalyticsEvent does).
    // We look up the most recent matching analytics event by articleId + time
    // window (within 30 seconds of the ArticleView row's viewedAt). This is
    // best-effort — when no matching event is found (e.g. tracking disabled
    // or data older than the analytics rollout), device is null.
    //
    // We do this in a single batched query (findMany with IN clause + order
    // by createdAt desc) to avoid N+1.
    const deviceMap = new Map<string, string | null>();
    if (recentViews.length > 0) {
      // Time window for matching: ±30 seconds around each view.
      const earliestView = recentViews[recentViews.length - 1]!.viewedAt;
      const earliestWindow = new Date(earliestView.getTime() - 30_000);
      const latestView = recentViews[0]!.viewedAt;
      const latestWindow = new Date(latestView.getTime() + 30_000);

      const matchingEvents = await db.analyticsEvent.findMany({
        where: {
          eventType: "article_view",
          articleId: { in: articleIds },
          createdAt: { gte: earliestWindow, lte: latestWindow },
        },
        select: {
          articleId: true,
          device: true,
          createdAt: true,
        },
        orderBy: { createdAt: "desc" },
        take: 500, // safety cap
      }).catch(() => []);

      // For each article, pick the device from the most recent matching event.
      for (const ev of matchingEvents) {
        if (ev.articleId && !deviceMap.has(ev.articleId) && ev.device) {
          deviceMap.set(ev.articleId, ev.device);
        }
      }
    }

    // ── Build the activity feed ──
    const activity = recentViews.map((v) => {
      const article = articleMap.get(v.articleId);
      return {
        articleId: v.articleId,
        articleTitle: article?.title ?? "(deleted article)",
        authorFullName: article?.author?.fullName ?? null,
        source: v.source ?? "direct",
        referralDomain: v.referralDomain,
        viewedAt: v.viewedAt.toISOString(),
        device: deviceMap.get(v.articleId) ?? null,
      };
    });

    return ok({
      analytics: {
        activity,
        fetchedAt: new Date().toISOString(),
      },
    });
  } catch (err) {
    logger.error("application", "Recent activity analytics query failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return ok({
      analytics: {
        activity: [],
        fetchedAt: new Date().toISOString(),
        error: "Failed to load recent activity",
      },
    });
  }
});
