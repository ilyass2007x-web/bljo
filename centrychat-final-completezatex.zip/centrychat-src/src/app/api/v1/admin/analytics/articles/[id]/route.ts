import { apiHandler, notFound, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import {
  parseRange,
  bucketKey,
  growthPercentage,
  cachedAggregate,
} from "@/lib/analytics/admin-helpers";
import { extractReferrerDomain } from "@/lib/analytics/classify-source";

/**
 * GET /api/v1/admin/analytics/articles/:id?range=30d
 * -----------------------------------------------------
 * Article traffic details (spec §8):
 *   - overview: total views, unique visitors, avg engagement, returning visitors
 *   - sources: [{ source, medium, visitors, percentage }]
 *   - overTime: [{ bucket, views, visitors }]
 *   - topReferrers: [{ domain, visits, percentage }]
 *   - countries: [{ country, visitors, percentage }] (empty when no Geo data)
 *   - devices: [{ device, visitors, percentage }]
 *
 * SECURITY: requireAdmin(). The articleId is validated to exist (404 otherwise).
 */
export const GET = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  void admin;
  const { id: articleId } = await ctx.params;
  if (!articleId) return notFound("Article not found");

  const url = new URL(req.url);
  const range = url.searchParams.get("range") ?? "30d";
  const customStart = url.searchParams.get("start");
  const customEnd = url.searchParams.get("end");
  const dr = parseRange(range, customStart, customEnd);

  // Verify the article exists.
  const article = await db.article.findUnique({
    where: { id: articleId },
    select: { id: true, title: true, status: true, publishedAt: true, author: { select: { fullName: true, username: true } } },
  });
  if (!article) return notFound("Article not found");

  const data = await cachedAggregate(`admin:analytics:article:${articleId}:${range}:${customStart ?? ""}:${customEnd ?? ""}`, async () => {
    // ── Canonical ArticleView totals (PHASE 12) ──
    // The existing /traffic + /sources endpoints read from AnalyticsEvent
    // (the granular event log). The article-specific view count displayed
    // on the public article card comes from the ArticleView table (one row
    // per (article, user/visitor-token), DB-level dedup). We pull the
    // canonical totals here so the admin sees the SAME numbers users see
    // publicly — and the Today/Week/Month breakdowns that aren't available
    // anywhere else.
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const last7Days = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const last30Days = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const [
      canonicalTotalViews,
      canonicalUniqueVisitors,
      canonicalViewsToday,
      canonicalViewsThisWeek,
      canonicalViewsThisMonth,
      // Per-source breakdown from ArticleView (the canonical unique-view
      // table). This is a more accurate "where did this article's unique
      // visitors come from" than the AnalyticsEvent-based breakdown (which
      // counts events, not unique viewers).
      articleViewSourceGroups,
    ] = await Promise.all([
      db.articleView.count({ where: { articleId } }),
      // Unique visitors = distinct (anonymousVisitorId) + distinct (userId)
      // (NULLs not counted).
      db.articleView.groupBy({
        by: ["anonymousVisitorId"],
        where: { articleId, anonymousVisitorId: { not: null } },
        _count: { anonymousVisitorId: true },
      }).then((rows) => rows.length).catch(() => 0),
      db.articleView.count({ where: { articleId, viewedAt: { gte: startOfToday } } }),
      db.articleView.count({ where: { articleId, viewedAt: { gte: last7Days } } }),
      db.articleView.count({ where: { articleId, viewedAt: { gte: last30Days } } }),
      db.articleView.groupBy({
        by: ["source"],
        where: { articleId, source: { not: null } },
        _count: { source: true },
        orderBy: { _count: { source: "desc" } },
      }).catch(() => []),
    ]);
    const uniqueAuthUsers = await db.articleView.groupBy({
      by: ["userId"],
      where: { articleId, userId: { not: null } },
      _count: { userId: true },
    }).then((rows) => rows.length).catch(() => 0);
    const canonicalUniqueVisitorsTotal = canonicalUniqueVisitors + uniqueAuthUsers;

    // Convert the ArticleView source groups into the same shape as the
    // AnalyticsEvent-based sources array (so the UI can use either).
    const articleViewSources = articleViewSourceGroups.map((g) => ({
      source: g.source ?? "direct",
      medium: "referral" as const, // ArticleView doesn't store medium — UI falls back
      visitors: g._count.source,
      pageViews: g._count.source,
      percentage: 0, // filled in below
    }));

    // Fetch all article_view events for this article in range.
    const events = await db.analyticsEvent.findMany({
      where: {
        articleId,
        createdAt: { gte: dr.start, lte: dr.end },
      },
      select: {
        sessionId: true,
        source: true,
        medium: true,
        referrer: true,
        country: true,
        device: true,
        createdAt: true,
      },
      orderBy: { createdAt: "asc" },
    });

    if (events.length === 0) {
      return {
        overview: { views: 0, uniqueVisitors: 0, returningVisitors: 0, avgEngagement: 0 },
        canonical: {
          totalViews: canonicalTotalViews,
          uniqueVisitors: canonicalUniqueVisitorsTotal,
          viewsToday: canonicalViewsToday,
          viewsThisWeek: canonicalViewsThisWeek,
          viewsThisMonth: canonicalViewsThisMonth,
        },
        canonicalSources: articleViewSources,
        sources: [],
        overTime: [],
        topReferrers: [],
        countries: [],
        devices: [],
        bucket: dr.bucket,
        range: dr.label,
      };
    }

    // ── Overview ──
    const uniqueSessions = new Set(events.map((e) => e.sessionId));
    const uniqueVisitors = uniqueSessions.size;
    const views = events.length;

    // Returning visitors: sessions that have at least one event BEFORE the
    // range start (i.e. they've visited before). We check this by querying
    // for events with sessionId IN (uniqueSessions) AND createdAt < dr.start.
    const returningSessions = new Set<string>();
    if (uniqueVisitors > 0) {
      const prevEvents = await db.analyticsEvent.findMany({
        where: {
          sessionId: { in: Array.from(uniqueSessions) },
          createdAt: { lt: dr.start },
        },
        select: { sessionId: true },
        take: uniqueVisitors * 2, // cap for safety
        distinct: ["sessionId"],
      });
      for (const e of prevEvents) returningSessions.add(e.sessionId);
    }
    const returningVisitors = returningSessions.size;
    const avgEngagement = views / (uniqueVisitors || 1);

    // ── Sources breakdown ──
    const sourceMap = new Map<string, { medium: string; visitors: Set<string>; views: number }>();
    for (const e of events) {
      if (!sourceMap.has(e.source)) {
        sourceMap.set(e.source, { medium: e.medium, visitors: new Set(), views: 0 });
      }
      const s = sourceMap.get(e.source)!;
      s.visitors.add(e.sessionId);
      s.views += 1;
    }
    const sources = Array.from(sourceMap.entries())
      .map(([source, s]) => ({
        source,
        medium: s.medium,
        visitors: s.visitors.size,
        percentage: Number(((s.visitors.size / (uniqueVisitors || 1)) * 100).toFixed(1)),
      }))
      .sort((a, b) => b.visitors - a.visitors);

    // ── Traffic over time ──
    const buckets = new Map<string, { views: number; visitors: Set<string> }>();
    for (const e of events) {
      const key = bucketKey(e.createdAt, dr.bucket);
      if (!buckets.has(key)) buckets.set(key, { views: 0, visitors: new Set() });
      const b = buckets.get(key)!;
      b.views += 1;
      b.visitors.add(e.sessionId);
    }
    const overTime = Array.from(buckets.entries())
      .map(([bucket, b]) => ({
        bucket,
        views: b.views,
        visitors: b.visitors.size,
      }))
      .sort((a, b) => a.bucket.localeCompare(b.bucket));

    // ── Top referrers ──
    const referrerMap = new Map<string, { visits: number }>();
    for (const e of events) {
      const domain = extractReferrerDomain(e.referrer);
      if (!domain) continue; // skip direct / invalid referrers
      if (!referrerMap.has(domain)) referrerMap.set(domain, { visits: 0 });
      referrerMap.get(domain)!.visits += 1;
    }
    const totalReferrerVisits = Array.from(referrerMap.values()).reduce((a, b) => a + b.visits, 0) || 1;
    const topReferrers = Array.from(referrerMap.entries())
      .map(([domain, r]) => ({
        domain,
        visits: r.visits,
        percentage: Number(((r.visits / totalReferrerVisits) * 100).toFixed(1)),
      }))
      .sort((a, b) => b.visits - a.visits)
      .slice(0, 10);

    // ── Countries (only when Geo data is available) ──
    const countryMap = new Map<string, Set<string>>();
    let hasCountryData = false;
    for (const e of events) {
      if (!e.country) continue;
      hasCountryData = true;
      if (!countryMap.has(e.country)) countryMap.set(e.country, new Set());
      countryMap.get(e.country)!.add(e.sessionId);
    }
    const countries = hasCountryData
      ? Array.from(countryMap.entries())
          .map(([country, visitors]) => ({
            country,
            visitors: visitors.size,
            percentage: Number(((visitors.size / (uniqueVisitors || 1)) * 100).toFixed(1)),
          }))
          .sort((a, b) => b.visitors - a.visitors)
          .slice(0, 10)
      : []; // empty when no Geo data — the UI shows "Country data not available"

    // ── Devices ──
    const deviceMap = new Map<string, Set<string>>();
    for (const e of events) {
      if (!e.device) continue;
      if (!deviceMap.has(e.device)) deviceMap.set(e.device, new Set());
      deviceMap.get(e.device)!.add(e.sessionId);
    }
    const devices = Array.from(deviceMap.entries())
      .map(([device, visitors]) => ({
        device,
        visitors: visitors.size,
        percentage: Number(((visitors.size / (uniqueVisitors || 1)) * 100).toFixed(1)),
      }))
      .sort((a, b) => b.visitors - a.visitors);

    return {
      overview: {
        views,
        uniqueVisitors,
        returningVisitors,
        avgEngagement: Number(avgEngagement.toFixed(2)),
      },
      // Canonical ArticleView totals (PHASE 12). These match the public
      // view count displayed on the article card (one row per unique
      // viewer). The `overview` fields above are derived from
      // AnalyticsEvent (granular event log) and may differ from the
      // canonical count when a visitor triggered multiple `article_view`
      // events (e.g. via SPA re-navigations).
      canonical: {
        totalViews: canonicalTotalViews,
        uniqueVisitors: canonicalUniqueVisitorsTotal,
        viewsToday: canonicalViewsToday,
        viewsThisWeek: canonicalViewsThisWeek,
        viewsThisMonth: canonicalViewsThisMonth,
      },
      // Per-source breakdown from the canonical ArticleView table.
      // This reflects the FIRST-TOUCH source attribution (the source that
      // brought each unique visitor to the article). When the source is
      // NULL (legacy rows from before tracking was rolled out), it's
      // excluded from this list.
      canonicalSources: articleViewSources,
      sources,
      overTime,
      topReferrers,
      countries,
      devices,
      bucket: dr.bucket,
      range: dr.label,
      hasCountryData,
    };
  }).catch((err) => {
    logger.error("application", "Article traffic details query failed", {
      articleId,
      error: err instanceof Error ? err.message : String(err),
    });
    return { error: "Failed to load article traffic details" };
  });

  return ok({
    article: {
      id: article.id,
      title: article.title,
      status: article.status,
      publishedAt: article.publishedAt?.toISOString() ?? null,
      author: article.author,
    },
    analytics: data,
  });
});
