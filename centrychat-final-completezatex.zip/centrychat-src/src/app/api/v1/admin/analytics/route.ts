import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { cacheGetOrSet } from "@/lib/cache";
import { logger } from "@/lib/logging";

/**
 * GET /api/v1/admin/analytics?range=24h|7d|30d|90d|1y
 * -------------------------------------------------------
 * Advanced Analytics Center (spec §1-§27 — PHASE 5).
 *
 * Returns ALL analytics in a single response (cached 30s):
 *   - User metrics: total, new in range, growth %, daily buckets.
 *   - Content metrics: posts created, articles published, drafts, daily buckets.
 *   - Engagement metrics: likes, comments, shares, unique views, engagement rate, growth %.
 *   - Follow metrics: new follows in range, daily buckets.
 *   - Comparison: current period vs previous equivalent period for each metric.
 *   - Top content: top 10 posts + articles by engagement in range.
 *   - Top creators: top 10 users by activity in range.
 *   - Posts vs Articles: side-by-side comparison of engagement metrics.
 *
 * ARCHITECTURE:
 *   - All counts via Prisma count() with date filters (no findMany-then-count).
 *   - Growth chart data: fetches only createdAt timestamps + buckets by day/week/month in JS.
 *   - Comparison: fetches current period + previous period counts in parallel.
 *   - Cached 30 seconds via cacheGetOrSet (spec §21).
 *   - Each section wrapped in try/catch (spec §24 — one failure doesn't crash).
 *
 * SECURITY (spec §18, §26):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only (server-side).
 *   - All data is aggregated — no individual user content exposed.
 *   - No passwords, tokens, private messages, or sensitive info.
 *
 * DATA ACCURACY (spec §25):
 *   - Every number comes from real database data.
 *   - Active/Returning users NOT shown unless reliable data exists (lastSeenAt
 *     is used as a proxy for "active recently" — clearly labeled).
 *   - Traffic sources NOT shown (not tracked in the DB — spec §15).
 */

type Range = "24h" | "7d" | "30d" | "90d" | "1y";

function getRangeStart(range: Range): Date {
  const now = Date.now();
  switch (range) {
    case "24h": return new Date(now - 24 * 60 * 60 * 1000);
    case "7d":  return new Date(now - 7 * 24 * 60 * 60 * 1000);
    case "30d": return new Date(now - 30 * 24 * 60 * 60 * 1000);
    case "90d": return new Date(now - 90 * 24 * 60 * 60 * 1000);
    case "1y":  return new Date(now - 365 * 24 * 60 * 60 * 1000);
    default:    return new Date(now - 30 * 24 * 60 * 60 * 1000);
  }
}

function getPrevRangeStart(range: Range): Date {
  // Previous equivalent period: the range BEFORE the current range.
  // For 30d: current = [now-30d, now], previous = [now-60d, now-30d].
  const now = Date.now();
  const rangeMs = now - getRangeStart(range).getTime();
  return new Date(now - 2 * rangeMs);
}

/** Bucket timestamps by day for growth charts. */
function bucketByDay<T extends { createdAt?: Date; viewedAt?: Date; publishedAt?: Date }>(
  rows: T[], field: "createdAt" | "viewedAt" | "publishedAt"
): { date: string; count: number }[] {
  const buckets = new Map<string, number>();
  for (const row of rows) {
    const d = row[field];
    if (!d) continue;
    const key = d.toISOString().slice(0, 10);
    buckets.set(key, (buckets.get(key) ?? 0) + 1);
  }
  return Array.from(buckets.entries()).map(([date, count]) => ({ date, count })).sort((a, b) => a.date.localeCompare(b.date));
}

/** Calculate growth percentage. Handles zero safely (spec §5). */
function growthPct(current: number, previous: number): number | null {
  if (previous === 0) return current > 0 ? null : 0; // null = "no comparison" (spec §13)
  return Math.round(((current - previous) / previous) * 1000) / 10;
}

export const GET = apiHandler(async (req) => {
  await requireAdmin();

  const url = new URL(req.url);
  const rangeParam = (url.searchParams.get("range") ?? "30d") as Range;
  const range = (["24h", "7d", "30d", "90d", "1y"] as Range[]).includes(rangeParam) ? rangeParam : "30d";
  const rangeStart = getRangeStart(range);
  const prevStart = getPrevRangeStart(range);
  const now = new Date();

  const cacheKey = `admin:analytics:${range}`;
  const TTL = 30;

  const result = await cacheGetOrSet(cacheKey, TTL, async () => {
    // ── SECTION 1: User metrics ──────────────────────────────────
    const users = await (async () => {
      try {
        const [total, newInRange, newInPrev, activeRecently, userTs] = await Promise.all([
          db.user.count(),
          db.user.count({ where: { createdAt: { gte: rangeStart } } }),
          db.user.count({ where: { createdAt: { gte: prevStart, lt: rangeStart } } }),
          // "Active recently" proxy: lastSeenAt within last 15 min.
          db.user.count({ where: { lastSeenAt: { gte: new Date(Date.now() - 15 * 60 * 1000) } } }),
          // Growth chart: fetch createdAt timestamps + bucket by day.
          db.user.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: 50000 }),
        ]);
        return {
          total, newInRange, newInPrev, activeRecently,
          growth: growthPct(newInRange, newInPrev),
          dailyBuckets: bucketByDay(userTs, "createdAt"),
        };
      } catch (err) {
        logger.warn("admin", "Analytics: user metrics failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 2: Content metrics ────────────────────────────────
    const content = await (async () => {
      try {
        const [totalPosts, totalArticles, totalDrafts, postsInRange, articlesInRange, postsInPrev, articlesInPrev, postTs, articleTs] = await Promise.all([
          db.post.count(),
          db.article.count({ where: { status: "PUBLISHED" } }),
          db.article.count({ where: { status: "DRAFT" } }),
          db.post.count({ where: { createdAt: { gte: rangeStart } } }),
          db.article.count({ where: { status: "PUBLISHED", publishedAt: { gte: rangeStart } } }),
          db.post.count({ where: { createdAt: { gte: prevStart, lt: rangeStart } } }),
          db.article.count({ where: { status: "PUBLISHED", publishedAt: { gte: prevStart, lt: rangeStart } } }),
          db.post.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: 50000 }),
          db.article.findMany({ where: { status: "PUBLISHED", publishedAt: { gte: rangeStart } }, select: { publishedAt: true, createdAt: true }, take: 50000 }),
        ]);
        return {
          totalPosts, totalArticles, totalDrafts,
          postsInRange, articlesInRange,
          postsGrowth: growthPct(postsInRange, postsInPrev),
          articlesGrowth: growthPct(articlesInRange, articlesInPrev),
          postBuckets: bucketByDay(postTs, "createdAt"),
          articleBuckets: bucketByDay(articleTs.map(a => ({ createdAt: a.publishedAt ?? a.createdAt }) as any), "createdAt"),
        };
      } catch (err) {
        logger.warn("admin", "Analytics: content metrics failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 3: Engagement metrics ─────────────────────────────
    const engagement = await (async () => {
      try {
        const [
          postLikes, articleLikes, postLikesPrev, articleLikesPrev,
          postComments, articleComments, postCommentsPrev, articleCommentsPrev,
          postShares, articleShares, postSharesPrev, articleSharesPrev,
          postViews, articleViews, postViewsPrev, articleViewsPrev,
          postLikeTs, articleLikeTs,
        ] = await Promise.all([
          db.postLike.count({ where: { createdAt: { gte: rangeStart } } }),
          db.articleLike.count({ where: { createdAt: { gte: rangeStart } } }),
          db.postLike.count({ where: { createdAt: { gte: prevStart, lt: rangeStart } } }),
          db.articleLike.count({ where: { createdAt: { gte: prevStart, lt: rangeStart } } }),
          db.postComment.count({ where: { createdAt: { gte: rangeStart } } }),
          db.articleComment.count({ where: { createdAt: { gte: rangeStart } } }),
          db.postComment.count({ where: { createdAt: { gte: prevStart, lt: rangeStart } } }),
          db.articleComment.count({ where: { createdAt: { gte: prevStart, lt: rangeStart } } }),
          db.postInteraction.count({ where: { type: "SHARE", createdAt: { gte: rangeStart } } }),
          db.articleInteraction.count({ where: { type: "SHARE", createdAt: { gte: rangeStart } } }),
          db.postInteraction.count({ where: { type: "SHARE", createdAt: { gte: prevStart, lt: rangeStart } } }),
          db.articleInteraction.count({ where: { type: "SHARE", createdAt: { gte: prevStart, lt: rangeStart } } }),
          db.postView.count({ where: { viewedAt: { gte: rangeStart } } }),
          db.articleView.count({ where: { viewedAt: { gte: rangeStart } } }),
          db.postView.count({ where: { viewedAt: { gte: prevStart, lt: rangeStart } } }),
          db.articleView.count({ where: { viewedAt: { gte: prevStart, lt: rangeStart } } }),
          db.postLike.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: 50000 }),
          db.articleLike.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: 50000 }),
        ]);

        const likes = postLikes + articleLikes;
        const comments = postComments + articleComments;
        const shares = postShares + articleShares;
        const views = postViews + articleViews;
        const prevLikes = postLikesPrev + articleLikesPrev;
        const prevComments = postCommentsPrev + articleCommentsPrev;
        const prevShares = postSharesPrev + articleSharesPrev;
        const prevViews = postViewsPrev + articleViewsPrev;

        // Engagement rate: (likes + comments + shares) / views × 100 (handles zero — spec §10).
        const engagementRate = views > 0 ? Math.round(((likes + comments + shares) / views) * 1000) / 10 : 0;

        // Merge like timestamps for the engagement growth chart.
        const allLikeTs = [...postLikeTs, ...articleLikeTs];

        return {
          likes, comments, shares, uniqueViews: views,
          postLikes, articleLikes, postComments, articleComments,
          postShares, articleShares, postViews, articleViews,
          engagementRate,
          likesGrowth: growthPct(likes, prevLikes),
          commentsGrowth: growthPct(comments, prevComments),
          sharesGrowth: growthPct(shares, prevShares),
          viewsGrowth: growthPct(views, prevViews),
          dailyBuckets: bucketByDay(allLikeTs, "createdAt"),
        };
      } catch (err) {
        logger.warn("admin", "Analytics: engagement metrics failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 4: Follow metrics ─────────────────────────────────
    const follows = await (async () => {
      try {
        const [newFollows, newFollowsPrev, followTs] = await Promise.all([
          db.follow.count({ where: { createdAt: { gte: rangeStart } } }),
          db.follow.count({ where: { createdAt: { gte: prevStart, lt: rangeStart } } }),
          db.follow.findMany({ where: { createdAt: { gte: rangeStart } }, select: { createdAt: true }, take: 50000 }),
        ]);
        return {
          newFollows,
          newFollowsPrev,
          growth: growthPct(newFollows, newFollowsPrev),
          dailyBuckets: bucketByDay(followTs, "createdAt"),
        };
      } catch (err) {
        logger.warn("admin", "Analytics: follow metrics failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 5: Top content (by engagement in range) ───────────
    const topContent = await (async () => {
      try {
        const [topPosts, topArticles] = await Promise.all([
          db.post.findMany({
            where: { createdAt: { gte: rangeStart } },
            orderBy: { createdAt: "desc" }, take: 50,
            select: { id: true, content: true, createdAt: true,
              author: { select: { id: true, fullName: true, username: true } },
              _count: { select: { likes: true, comments: true, views: true } } },
          }),
          db.article.findMany({
            where: { status: "PUBLISHED", publishedAt: { gte: rangeStart } },
            orderBy: { publishedAt: "desc" }, take: 50,
            select: { id: true, title: true, coverImage: true, publishedAt: true,
              author: { select: { id: true, fullName: true, username: true } },
              _count: { select: { likes: true, comments: true, views: true } } },
          }).catch(() => []),
        ]);

        const score = (c: { _count: { likes: number; comments: number; views: number } }) =>
          c._count.likes + c._count.comments * 2 + c._count.views * 0.1;

        const posts = topPosts.map(p => ({ type: "post" as const, id: p.id, title: p.content.slice(0, 80),
          author: p.author, createdAt: p.createdAt.toISOString(), engagement: score(p),
          likes: p._count.likes, comments: p._count.comments, views: p._count.views }))
          .sort((a, b) => b.engagement - a.engagement).slice(0, 10);

        const articles = topArticles.map(a => ({ type: "article" as const, id: a.id, title: a.title,
          author: a.author, coverImage: a.coverImage, publishedAt: a.publishedAt?.toISOString() ?? null,
          engagement: score(a), likes: a._count.likes, comments: a._count.comments, views: a._count.views }))
          .sort((a, b) => b.engagement - a.engagement).slice(0, 10);

        return { posts, articles };
      } catch (err) {
        logger.warn("admin", "Analytics: top content failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 6: Top creators ──────────────────────────────────
    const topCreators = await (async () => {
      try {
        const users = await db.user.findMany({
          where: { status: "ACTIVE" }, take: 200,
          select: { id: true, fullName: true, username: true, isVerified: true, role: true,
            _count: { select: {
              posts: { where: { createdAt: { gte: rangeStart } } },
              articles: { where: { status: "PUBLISHED", publishedAt: { gte: rangeStart } } },
              followers: true,
            } } },
        });
        return users.map(u => ({ id: u.id, fullName: u.fullName, username: u.username,
          isVerified: u.isVerified, role: u.role,
          postsInPeriod: u._count.posts, articlesInPeriod: u._count.articles,
          followers: u._count.followers, activity: u._count.posts + u._count.articles }))
          .filter(u => u.activity > 0).sort((a, b) => b.activity - a.activity).slice(0, 10);
      } catch (err) {
        logger.warn("admin", "Analytics: top creators failed", { error: err instanceof Error ? err.message : String(err) });
        return null;
      }
    })();

    // ── SECTION 7: Posts vs Articles comparison (spec §14) ──────
    const postsVsArticles = engagement ? {
      posts: { likes: engagement.postLikes, comments: engagement.postComments, shares: engagement.postShares, views: engagement.postViews },
      articles: { likes: engagement.articleLikes, comments: engagement.articleComments, shares: engagement.articleShares, views: engagement.articleViews },
    } : null;

    return { range, users, content, engagement, follows, topContent, topCreators, postsVsArticles };
  });

  return ok({ analytics: result });
});
