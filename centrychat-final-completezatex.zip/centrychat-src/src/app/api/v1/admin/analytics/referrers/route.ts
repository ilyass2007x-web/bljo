import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { parseRange, cachedAggregate } from "@/lib/analytics/admin-helpers";
import { extractReferrerDomain } from "@/lib/analytics/classify-source";

/**
 * GET /api/v1/admin/analytics/referrers?range=30d
 * -------------------------------------------------
 * Top referrers (spec §9):
 *   - [{ domain, visits, percentage }]
 *
 * Extracts the domain from each event's referrer + counts visits per domain.
 * Direct traffic (no referrer) is EXCLUDED from this list (it has its own
 * card in the overview).
 *
 * SECURITY: requireAdmin().
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin;

  const url = new URL(req.url);
  const range = url.searchParams.get("range") ?? "30d";
  const customStart = url.searchParams.get("start");
  const customEnd = url.searchParams.get("end");
  const dr = parseRange(range, customStart, customEnd);

  const data = await cachedAggregate(`admin:analytics:referrers:${range}:${customStart ?? ""}:${customEnd ?? ""}`, async () => {
    // Fetch referrers from events in range.
    const events = await db.analyticsEvent.findMany({
      where: {
        createdAt: { gte: dr.start, lte: dr.end },
        referrer: { not: null },
      },
      select: { referrer: true },
    });

    const referrerMap = new Map<string, number>();
    for (const e of events) {
      const domain = extractReferrerDomain(e.referrer);
      if (!domain) continue;
      referrerMap.set(domain, (referrerMap.get(domain) ?? 0) + 1);
    }

    const totalVisits = Array.from(referrerMap.values()).reduce((a, b) => a + b, 0) || 1;
    const referrers = Array.from(referrerMap.entries())
      .map(([domain, visits]) => ({
        domain,
        visits,
        percentage: Number(((visits / totalVisits) * 100).toFixed(1)),
      }))
      .sort((a, b) => b.visits - a.visits)
      .slice(0, 20);

    return { referrers, range: dr.label };
  }).catch((err) => {
    logger.error("application", "Referrers analytics query failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return { referrers: [], range: dr.label, error: "Failed to load referrers data" };
  });

  return ok({ analytics: data });
});
