import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import {
  parseRange,
  bucketKey,
  cachedAggregate,
} from "@/lib/analytics/admin-helpers";

/**
 * GET /api/v1/admin/analytics/sources?range=30d
 * -----------------------------------------------
 * Traffic sources breakdown (spec §4, §5):
 *   - sources: [{ source, medium, visitors, pageViews, percentage }]
 *   - overTime: [{ bucket, visitors, pageViews, articleViews }]
 *
 * The `sources` array powers the Donut chart. Each entry includes:
 *   - source: "google", "facebook", "direct", etc.
 *   - medium: "search", "social", "direct", "referral"
 *   - visitors: unique session count for this source
 *   - pageViews: total event count for this source
 *   - percentage: visitors / totalVisitors * 100
 *
 * The `overTime` array powers the Line/Area chart. Each entry is a time
 * bucket (hour/day/month depending on range) with:
 *   - bucket: the time bucket key (e.g. "2026-08-21")
 *   - visitors: unique sessions that started in this bucket
 *   - pageViews: total events in this bucket
 *   - articleViews: article_view events in this bucket
 *
 * SECURITY: requireAdmin().
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin;

  const url = new URL(req.url);
  const range = url.searchParams.get("range") ?? "30d";
  const customStart = url.searchParams.get("start");
  const customEnd = url.searchParams.get("end");
  const dr = parseRange(range, customStart, customEnd);

  const data = await cachedAggregate(`admin:analytics:sources:${range}:${customStart ?? ""}:${customEnd ?? ""}`, async () => {
    // ── Sources breakdown ──
    // Group events by source + count sessions (unique visitors) + total events.
    // Prisma's groupBy gives us the event count per source. For unique visitors,
    // we need a separate groupBy on sessions.
    const [eventGroups, sessionGroups] = await Promise.all([
      db.analyticsEvent.groupBy({
        by: ["source", "medium"],
        where: { createdAt: { gte: dr.start, lte: dr.end } },
        _count: { id: true },
        orderBy: { _count: { id: "desc" } },
      }),
      db.analyticsSession.groupBy({
        by: ["source", "medium"],
        where: { firstSeenAt: { gte: dr.start, lte: dr.end } },
        _count: { id: true },
        orderBy: { _count: { id: "desc" } },
      }),
    ]);

    // Build a lookup: source → session count (unique visitors).
    const sessionMap = new Map<string, number>();
    for (const g of sessionGroups) {
      sessionMap.set(g.source, (sessionMap.get(g.source) ?? 0) + g._count.id);
    }

    const totalVisitors = Array.from(sessionMap.values()).reduce((a, b) => a + b, 0) || 1;

    const sources = eventGroups.map((g) => ({
      source: g.source,
      medium: g.medium,
      visitors: sessionMap.get(g.source) ?? 0,
      pageViews: g._count.id,
      percentage: Number((((sessionMap.get(g.source) ?? 0) / totalVisitors) * 100).toFixed(1)),
    }));

    // ── Traffic over time ──
    // Fetch all events in the range, then bucket them in JS. This is the
    // simplest approach — Prisma doesn't support date_trunc in groupBy.
    // We select only createdAt + eventType (small payload) + use a cursor
    // to avoid loading millions of rows at once. For typical ranges (30d),
    // this is a few thousand rows — fast.
    const events = await db.analyticsEvent.findMany({
      where: { createdAt: { gte: dr.start, lte: dr.end } },
      select: { createdAt: true, eventType: true, sessionId: true },
      orderBy: { createdAt: "asc" },
    });

    // Bucket the events.
    const buckets = new Map<string, { visitors: Set<string>; pageViews: number; articleViews: number }>();
    for (const e of events) {
      const key = bucketKey(e.createdAt, dr.bucket);
      if (!buckets.has(key)) {
        buckets.set(key, { visitors: new Set(), pageViews: 0, articleViews: 0 });
      }
      const b = buckets.get(key)!;
      b.visitors.add(e.sessionId);
      b.pageViews += 1;
      if (e.eventType === "article_view") b.articleViews += 1;
    }

    const overTime = Array.from(buckets.entries())
      .map(([bucket, b]) => ({
        bucket,
        visitors: b.visitors.size,
        pageViews: b.pageViews,
        articleViews: b.articleViews,
      }))
      .sort((a, b) => a.bucket.localeCompare(b.bucket));

    return { sources, overTime, bucket: dr.bucket, range: dr.label };
  }).catch((err) => {
    logger.error("application", "Sources analytics query failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return { sources: [], overTime: [], bucket: dr.bucket, range: dr.label, error: "Failed to load sources data" };
  });

  return ok({ analytics: data });
});
