import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import {
  parseRange,
  growthPercentage,
  cachedAggregate,
} from "@/lib/analytics/admin-helpers";

/**
 * GET /api/v1/admin/analytics/articles?range=30d
 * ------------------------------------------------
 * Article traffic list (spec §7):
 *   - Articles sorted by traffic (article_view count) in the selected range.
 *   - Each row: title, views, unique visitors, top source, growth %, last visit.
 *
 * Columns returned per article:
 *   - id, title, slug (for linking)
 *   - views: article_view event count in range
 *   - uniqueVisitors: distinct session count for this article in range
 *   - topSource: the source that sent the most traffic to this article
 *   - growth: views growth % vs previous period
 *   - lastVisit: most recent article_view timestamp
 *
 * SECURITY: requireAdmin().
 *
 * PERFORMANCE:
 *   - Single groupBy on AnalyticsEvent (articleId, source) — indexed.
 *   - Articles hydrated via a single findMany (IN clause on the top N articleIds).
 *   - Cached 30 seconds.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin;

  const url = new URL(req.url);
  const range = url.searchParams.get("range") ?? "30d";
  const customStart = url.searchParams.get("start");
  const customEnd = url.searchParams.get("end");
  // sort: "views" (default) | "uniqueVisitors" | "growth" | "recent"
  const sortParam = url.searchParams.get("sort") ?? "views";
  const sort = (["views", "uniqueVisitors", "growth", "recent"].includes(sortParam))
    ? (sortParam as "views" | "uniqueVisitors" | "growth" | "recent")
    : "views";
  const dr = parseRange(range, customStart, customEnd);

  const data = await cachedAggregate(`admin:analytics:articles:${range}:${customStart ?? ""}:${customEnd ?? ""}:${sort}`, async () => {
    // ── Current period: group article_view events by articleId ──
    const currentGroups = await db.analyticsEvent.groupBy({
      by: ["articleId"],
      where: {
        eventType: "article_view",
        createdAt: { gte: dr.start, lte: dr.end },
        articleId: { not: null },
      },
      _count: { id: true },
      orderBy: { _count: { id: "desc" } },
      take: 50, // top 50 articles
    });

    if (currentGroups.length === 0) {
      return { articles: [], range: dr.label };
    }

    const articleIds = currentGroups.map((g) => g.articleId!);

    // Fetch article titles + the per-article source breakdown + unique visitor
    // counts in parallel.
    const [articles, sourceBreakdowns, uniqueVisitorCounts, prevGroups, lastVisits] = await Promise.all([
      db.article.findMany({
        where: { id: { in: articleIds } },
        select: {
          id: true,
          title: true,
          status: true,
          publishedAt: true,
          author: { select: { fullName: true, username: true } },
        },
      }),
      // Per-article source breakdown (for the "topSource" column).
      db.analyticsEvent.groupBy({
        by: ["articleId", "source"],
        where: {
          eventType: "article_view",
          createdAt: { gte: dr.start, lte: dr.end },
          articleId: { in: articleIds },
        },
        _count: { id: true },
        orderBy: { _count: { id: "desc" } },
      }),
      // Per-article unique visitor count (distinct sessions).
      // Prisma doesn't support _count of distinct, so we findMany + dedup in JS.
      db.analyticsEvent.findMany({
        where: {
          eventType: "article_view",
          createdAt: { gte: dr.start, lte: dr.end },
          articleId: { in: articleIds },
        },
        select: { articleId: true, sessionId: true },
      }),
      // Previous period for growth %.
      db.analyticsEvent.groupBy({
        by: ["articleId"],
        where: {
          eventType: "article_view",
          createdAt: { gte: dr.prevStart, lte: dr.prevEnd },
          articleId: { in: articleIds },
        },
        _count: { id: true },
      }),
      // Last visit timestamp per article.
      db.analyticsEvent.findMany({
        where: {
          eventType: "article_view",
          articleId: { in: articleIds },
        },
        select: { articleId: true, createdAt: true },
        orderBy: { createdAt: "desc" },
        take: 50,
      }),
    ]);

    // Build lookup maps.
    const articleMap = new Map(articles.map((a) => [a.id, a]));
    const sourceMap = new Map<string, { topSource: string; topCount: number }>();
    for (const s of sourceBreakdowns) {
      const id = s.articleId!;
      const existing = sourceMap.get(id);
      if (!existing || s._count.id > existing.topCount) {
        sourceMap.set(id, { topSource: s.source, topCount: s._count.id });
      }
    }
    const visitorMap = new Map<string, Set<string>>();
    for (const e of uniqueVisitorCounts) {
      const id = e.articleId!;
      if (!visitorMap.has(id)) visitorMap.set(id, new Set());
      visitorMap.get(id)!.add(e.sessionId);
    }
    const prevMap = new Map(prevGroups.map((g) => [g.articleId!, g._count.id]));
    const lastVisitMap = new Map<string, Date>();
    for (const v of lastVisits) {
      const id = v.articleId!;
      if (!lastVisitMap.has(id)) {
        lastVisitMap.set(id, v.createdAt);
      }
    }

    // Build the response in the same order as currentGroups (sorted by views).
    const result = currentGroups.map((g) => {
      const id = g.articleId!;
      const article = articleMap.get(id);
      const views = g._count.id;
      const uniqueVisitors = visitorMap.get(id)?.size ?? 0;
      const topSource = sourceMap.get(id)?.topSource ?? "direct";
      const prevViews = prevMap.get(id) ?? 0;
      const lastVisit = lastVisitMap.get(id);
      return {
        id,
        title: article?.title ?? "(deleted article)",
        status: article?.status ?? "UNKNOWN",
        publishedAt: article?.publishedAt?.toISOString() ?? null,
        author: article?.author ?? null,
        views,
        uniqueVisitors,
        topSource,
        growth: growthPercentage(views, prevViews),
        lastVisit: lastVisit?.toISOString() ?? null,
      };
    });

    // Apply the requested sort (PHASE 16 — sort by Views / Unique Visitors /
    // Growth / Recent Traffic). The default Prisma orderBy already sorts by
    // views DESC, but the admin UI lets the user re-sort client-side too —
    // this server-side sort ensures consistent order even when the result is
    // truncated.
    const sortFns: Record<typeof sort, (a: typeof result[number], b: typeof result[number]) => number> = {
      views: (a, b) => b.views - a.views,
      uniqueVisitors: (a, b) => b.uniqueVisitors - a.uniqueVisitors,
      growth: (a, b) => (b.growth ?? -Infinity) - (a.growth ?? -Infinity),
      recent: (a, b) => (b.lastVisit ?? "").localeCompare(a.lastVisit ?? ""),
    };
    result.sort(sortFns[sort]);

    return { articles: result, range: dr.label, sort };
  }).catch((err) => {
    logger.error("application", "Article traffic analytics query failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return { articles: [], range: dr.label, error: "Failed to load article traffic data" };
  });

  return ok({ analytics: data });
});
