import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { parseRange } from "@/lib/analytics/admin-helpers";

/**
 * GET /api/v1/admin/analytics/export?range=30d&format=csv
 * ---------------------------------------------------------
 * Export traffic analytics data (spec §28):
 *   - format=csv  → CSV file download
 *   - format=json → JSON file download
 *
 * Exports the events in the selected range as a flat table:
 *   timestamp, eventType, path, articleId, source, medium, referrer,
 *   device, browser, os, country
 *
 * NO sensitive data is included (no userId, no sessionId, no IP — those
 * are either hashed or never stored). The export is safe to share.
 *
 * SECURITY: requireAdmin(). Server-side only.
 *
 * PERFORMANCE:
 *   - Streams rows in batches (take + cursor pagination) to avoid loading
 *     millions of rows into memory at once.
 *   - Caps at 50,000 rows per export (defensive — larger exports should
 *     use a narrower date range).
 */
export async function GET(req: Request) {
  // Auth check — requireAdmin throws on non-admin, which we catch + convert
  // to a 403 response.
  try {
    const admin = await requireAdmin();
    void admin;
  } catch {
    return NextResponse.json(
      { ok: false, error: { message: "Admin access required" } },
      { status: 403 }
    );
  }

  const url = new URL(req.url);
  const range = url.searchParams.get("range") ?? "30d";
  const format = (url.searchParams.get("format") ?? "csv").toLowerCase();
  const customStart = url.searchParams.get("start");
  const customEnd = url.searchParams.get("end");
  const dr = parseRange(range, customStart, customEnd);

  if (format !== "csv" && format !== "json") {
    return NextResponse.json(
      { ok: false, error: { message: "Invalid format. Use csv or json." } },
      { status: 400 }
    );
  }

  try {
    // Fetch events in batches (cursor pagination) to avoid memory issues.
    const MAX_ROWS = 50_000;
    const allEvents: Array<{
      createdAt: Date;
      eventType: string;
      path: string;
      articleId: string | null;
      source: string;
      medium: string;
      referrer: string | null;
      device: string | null;
      browser: string | null;
      os: string | null;
      country: string | null;
    }> = [];
    let cursor: string | undefined;
    while (allEvents.length < MAX_ROWS) {
      const batch = await db.analyticsEvent.findMany({
        where: { createdAt: { gte: dr.start, lte: dr.end } },
        select: {
          id: true,
          createdAt: true,
          eventType: true,
          path: true,
          articleId: true,
          source: true,
          medium: true,
          referrer: true,
          device: true,
          browser: true,
          os: true,
          country: true,
        },
        orderBy: { createdAt: "asc" },
        take: 1000,
        ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
      });
      if (batch.length === 0) break;
      allEvents.push(...batch.map((b) => ({
        createdAt: b.createdAt,
        eventType: b.eventType,
        path: b.path,
        articleId: b.articleId,
        source: b.source,
        medium: b.medium,
        referrer: b.referrer,
        device: b.device,
        browser: b.browser,
        os: b.os,
        country: b.country,
      })));
      cursor = batch[batch.length - 1]!.id;
      if (batch.length < 1000) break;
    }

    // Build the response.
    const filename = `analytics-${range}-${new Date().toISOString().slice(0, 10)}.${format}`;

    if (format === "csv") {
      // CSV header.
      const headers = [
        "timestamp", "eventType", "path", "articleId", "source", "medium",
        "referrer", "device", "browser", "os", "country",
      ];
      const rows = allEvents.map((e) => [
        e.createdAt.toISOString(),
        e.eventType,
        csvEscape(e.path),
        e.articleId ?? "",
        e.source,
        e.medium,
        e.referrer ? csvEscape(e.referrer) : "",
        e.device ?? "",
        e.browser ?? "",
        e.os ?? "",
        e.country ?? "",
      ].join(","));
      const csv = [headers.join(","), ...rows].join("\n");
      return new NextResponse(csv, {
        status: 200,
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="${filename}"`,
        },
      });
    }

    // JSON.
    const json = JSON.stringify({
      range: dr.label,
      exportedAt: new Date().toISOString(),
      rowCount: allEvents.length,
      events: allEvents.map((e) => ({
        timestamp: e.createdAt.toISOString(),
        eventType: e.eventType,
        path: e.path,
        articleId: e.articleId,
        source: e.source,
        medium: e.medium,
        referrer: e.referrer,
        device: e.device,
        browser: e.browser,
        os: e.os,
        country: e.country,
      })),
    }, null, 2);
    return new NextResponse(json, {
      status: 200,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  } catch (err) {
    logger.error("application", "Analytics export failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return NextResponse.json(
      { ok: false, error: { message: "Failed to export analytics data" } },
      { status: 500 }
    );
  }
}

/** CSV cell escaping — wraps in quotes + escapes internal quotes. */
function csvEscape(s: string): string {
  if (/[",\n]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}
