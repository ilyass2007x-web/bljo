import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { parseRange, cachedAggregate } from "@/lib/analytics/admin-helpers";

/**
 * GET /api/v1/admin/analytics/devices?range=30d
 * -----------------------------------------------
 * Device analytics (spec §12):
 *   - devices: [{ device, visitors, percentage, views }]
 *   - browsers: [{ browser, visitors, percentage, views }]
 *   - operatingSystems: [{ os, visitors, percentage, views }]
 *
 * All breakdowns are by UNIQUE SESSIONS (visitors), not events. A visitor
 * who viewed 10 pages on Chrome counts once in the Chrome bucket.
 *
 * SECURITY: requireAdmin().
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin;

  const url = new URL(req.url);
  const range = url.searchParams.get("range") ?? "30d";
  const customStart = url.searchParams.get("start");
  const customEnd = url.searchParams.get("end");
  const dr = parseRange(range, customStart, customEnd);

  const data = await cachedAggregate(`admin:analytics:devices:${range}:${customStart ?? ""}:${customEnd ?? ""}`, async () => {
    // Group sessions by device / browser / OS. Sessions are the right
    // granularity (one visitor = one row, regardless of how many pages
    // they viewed).
    const [deviceGroups, browserGroups, osGroups] = await Promise.all([
      db.analyticsSession.groupBy({
        by: ["device"],
        where: { firstSeenAt: { gte: dr.start, lte: dr.end } },
        _count: { id: true },
        orderBy: { _count: { id: "desc" } },
      }),
      db.analyticsSession.groupBy({
        by: ["browser"],
        where: { firstSeenAt: { gte: dr.start, lte: dr.end } },
        _count: { id: true },
        orderBy: { _count: { id: "desc" } },
      }),
      db.analyticsSession.groupBy({
        by: ["os"],
        where: { firstSeenAt: { gte: dr.start, lte: dr.end } },
        _count: { id: true },
        orderBy: { _count: { id: "desc" } },
      }),
    ]);

    // Total for percentage calculation.
    const total = deviceGroups.reduce((a, g) => a + g._count.id, 0) || 1;

    const devices = deviceGroups.map((g) => ({
      device: g.device ?? "unknown",
      visitors: g._count.id,
      percentage: Number(((g._count.id / total) * 100).toFixed(1)),
    }));
    const browsers = browserGroups.map((g) => ({
      browser: g.browser ?? "other",
      visitors: g._count.id,
      percentage: Number(((g._count.id / total) * 100).toFixed(1)),
    }));
    const operatingSystems = osGroups.map((g) => ({
      os: g.os ?? "other",
      visitors: g._count.id,
      percentage: Number(((g._count.id / total) * 100).toFixed(1)),
    }));

    return { devices, browsers, operatingSystems, range: dr.label };
  }).catch((err) => {
    logger.error("application", "Devices analytics query failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return {
      devices: [],
      browsers: [],
      operatingSystems: [],
      range: dr.label,
      error: "Failed to load devices data",
    };
  });

  return ok({ analytics: data });
});
