import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import {
  parseRange,
  growthPercentage,
  cachedAggregate,
  hasAnyAnalyticsData,
} from "@/lib/analytics/admin-helpers";

/**
 * GET /api/v1/admin/analytics/traffic?range=30d
 * -----------------------------------------------
 * Traffic overview cards (spec §2):
 *   - Total Visitors (unique sessions in range)
 *   - Total Page Views (events in range)
 *   - Article Views (article_view events in range)
 *   - New Visitors (sessions whose firstSeenAt is in range)
 *   - Returning Visitors (sessions whose firstSeenAt is BEFORE range start)
 *   - Average Engagement (average events per session — proxy for engagement)
 *   - Traffic Growth (overall visitor growth % vs previous period)
 *
 * Each metric includes:
 *   - current: the value for the selected range
 *   - previous: the value for the previous equivalent range
 *   - growth: the percentage change (null when previous = 0)
 *
 * Cached 30 seconds per range (so refreshing the dashboard doesn't hammer
 * the DB). The cache is invalidated naturally when the range changes.
 *
 * SECURITY: requireAdmin() — server-side enforced.
 *
 * EMPTY STATE (spec §29): when the AnalyticsEvent table is empty, returns
 * { hasData: false } so the UI can render the "No traffic data yet" message
 * instead of misleading zeros.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin;

  const url = new URL(req.url);
  const range = url.searchParams.get("range") ?? "30d";
  const customStart = url.searchParams.get("start");
  const customEnd = url.searchParams.get("end");

  const dr = parseRange(range, customStart, customEnd);

  const data = await cachedAggregate(`admin:analytics:traffic:${range}:${customStart ?? ""}:${customEnd ?? ""}`, async () => {
    const hasData = await hasAnyAnalyticsData();
    if (!hasData) {
      return { hasData: false, range: dr.label, metrics: null };
    }

    // ── Current period ──
    const [
      totalVisitors,
      totalPageViews,
      articleViews,
      newVisitors,
      avgEngagementAgg,
    ] = await Promise.all([
      // Total unique visitors (sessions active in range).
      db.analyticsSession.count({
        where: { lastSeenAt: { gte: dr.start, lte: dr.end } },
      }),
      // Total page views (all events in range).
      db.analyticsEvent.count({
        where: { createdAt: { gte: dr.start, lte: dr.end } },
      }),
      // Article views (article_view events in range).
      db.analyticsEvent.count({
        where: {
          eventType: "article_view",
          createdAt: { gte: dr.start, lte: dr.end },
        },
      }),
      // New visitors (sessions whose firstSeenAt is in range).
      db.analyticsSession.count({
        where: { firstSeenAt: { gte: dr.start, lte: dr.end } },
      }),
      // Average engagement (events per session in range).
      // We compute this as totalEvents / totalSessions. Prisma doesn't
      // support AVG of a count, so we do it in JS.
      Promise.resolve(null),
    ]);

    // Average engagement: events per session.
    const sessionsInRange = totalVisitors || 1;
    const avgEngagement = totalPageViews / sessionsInRange;

    // Returning visitors = total visitors - new visitors.
    // (Sessions active in range whose firstSeenAt is BEFORE range start.)
    const returningVisitors = Math.max(0, totalVisitors - newVisitors);

    // ── Previous period (for growth %) ──
    const [
      prevVisitors,
      prevPageViews,
      prevArticleViews,
      prevNewVisitors,
    ] = await Promise.all([
      db.analyticsSession.count({
        where: { lastSeenAt: { gte: dr.prevStart, lte: dr.prevEnd } },
      }),
      db.analyticsEvent.count({
        where: { createdAt: { gte: dr.prevStart, lte: dr.prevEnd } },
      }),
      db.analyticsEvent.count({
        where: {
          eventType: "article_view",
          createdAt: { gte: dr.prevStart, lte: dr.prevEnd },
        },
      }),
      db.analyticsSession.count({
        where: { firstSeenAt: { gte: dr.prevStart, lte: dr.prevEnd } },
      }),
    ]);

    return {
      hasData: true,
      range: dr.label,
      metrics: {
        totalVisitors: {
          current: totalVisitors,
          previous: prevVisitors,
          growth: growthPercentage(totalVisitors, prevVisitors),
        },
        totalPageViews: {
          current: totalPageViews,
          previous: prevPageViews,
          growth: growthPercentage(totalPageViews, prevPageViews),
        },
        articleViews: {
          current: articleViews,
          previous: prevArticleViews,
          growth: growthPercentage(articleViews, prevArticleViews),
        },
        newVisitors: {
          current: newVisitors,
          previous: prevNewVisitors,
          growth: growthPercentage(newVisitors, prevNewVisitors),
        },
        returningVisitors: {
          current: returningVisitors,
          previous: Math.max(0, prevVisitors - prevNewVisitors),
          growth: growthPercentage(
            returningVisitors,
            Math.max(0, prevVisitors - prevNewVisitors)
          ),
        },
        avgEngagement: {
          current: Number(avgEngagement.toFixed(2)),
          previous: prevVisitors > 0 ? Number((prevPageViews / prevVisitors).toFixed(2)) : 0,
          growth: prevVisitors > 0
            ? growthPercentage(avgEngagement, prevPageViews / prevVisitors)
            : null,
        },
        // Overall traffic growth — uses total visitors as the proxy.
        trafficGrowth: growthPercentage(totalVisitors, prevVisitors),
      },
    };
  }).catch((err) => {
    logger.error("application", "Traffic analytics query failed", {
      error: err instanceof Error ? err.message : String(err),
    });
    return { hasData: false, range: dr.label, metrics: null, error: "Failed to load traffic data" };
  });

  return ok({ analytics: data });
});
