import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { SECURITY_HEADERS, CSP_HEADER } from "@/lib/security/headers";
import { RATE_LIMITS } from "@/lib/security/rate-limit";
import { logger } from "@/lib/logging";

/**
 * GET /api/v1/admin/security
 * --------------------------
 * Security Overview dashboard (spec §1-§42 — PHASE 10).
 *
 * Returns a READ-ONLY overview of the platform's security posture.
 * Does NOT expose any secrets, passwords, tokens, or private data.
 *
 * Returns:
 *   - Security headers status (which headers are active).
 *   - CSP status (the actual policy string — no secrets).
 *   - Rate limit configuration (the limits, not the secrets).
 *   - Session config (cookie name, TTL, HttpOnly, SameSite, Secure).
 *   - Password hashing algorithm (Argon2id — not the actual hashes).
 *   - Audit log stats (total logs, today, this week, by action).
 *   - Environment variable status (set/not-set, NOT the values — spec §23).
 *   - Input validation summary (which Zod schemas are active).
 *   - URL validation status (validateImageUrl active?).
 *
 * SECURITY (spec §31):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - No secrets, passwords, tokens, or env var VALUES exposed.
 *   - Only "set: true/false" for env vars (spec §23).
 */
export const GET = apiHandler(async () => {
  await requireAdmin();

  // ── Audit log stats ─────────────────────────────────────────────
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekStart = new Date(todayStart);
  weekStart.setDate(weekStart.getDate() - weekStart.getDay());

  const [totalLogs, todayLogs, weekLogs, byAction] = await Promise.all([
    db.adminAuditLog.count().catch(() => 0),
    db.adminAuditLog.count({ where: { createdAt: { gte: todayStart } } }).catch(() => 0),
    db.adminAuditLog.count({ where: { createdAt: { gte: weekStart } } }).catch(() => 0),
    db.adminAuditLog.groupBy({
      by: ["action"],
      _count: { action: true },
      orderBy: { _count: { action: "desc" } },
      take: 10,
    }).catch(() => []),
  ]);

  // ── Environment variable status (NOT values — spec §23) ────────
  const envVars = [
    "DATABASE_URL",
    "AUTH_SECRET",
    "NEXT_PUBLIC_APP_BASE_URL",
    "RESEND_API_KEY",
    "EMAIL_PROVIDER",
    "STORAGE_PROVIDER",
    "CACHE_PROVIDER",
    "UPSTASH_REDIS_REST_URL",
    "UPSTASH_REDIS_REST_TOKEN",
  ].map(key => ({
    key,
    set: !!process.env[key],
    // Never expose the value.
  }));

  return ok({
    security: {
      headers: {
        active: Object.keys(SECURITY_HEADERS).map(k => ({
          header: k,
          value: SECURITY_HEADERS[k],
        })),
        csp: CSP_HEADER,
        appliedVia: "middleware (src/proxy.ts)",
      },
      rateLimits: {
        login: RATE_LIMITS.login,
        register: RATE_LIMITS.register,
        passwordReset: RATE_LIMITS.passwordReset,
        messageSend: RATE_LIMITS.messageSend,
        search: RATE_LIMITS.search,
        report: RATE_LIMITS.report,
        adminWrite: RATE_LIMITS.adminWrite,
        note: (() => {
          const p = (process.env.CACHE_PROVIDER ?? "memory").toLowerCase();
          if (p === "redis") {
            return "Distributed (Upstash Redis REST). Shared across all serverless instances. Keys are namespaced 'ratelimit:*'. Fail-OPEN on Redis outage (logged).";
          }
          return "In-memory (per-process). Set CACHE_PROVIDER=redis in production for shared multi-instance enforcement.";
        })(),
      },
      session: {
        cookieName: "messenger_session",
        ttlSeconds: 60 * 60 * 24 * 7, // 7 days
        httpOnly: true,
        sameSite: "lax",
        secure: "auto (true in production, false in dev)",
        signed: true,
        encrypted: true,
        note: "iron-session. Cookie contains only userId + sessionId. Role/status re-fetched from DB on every request.",
      },
      password: {
        algorithm: "Argon2id",
        memoryCost: "19 MiB",
        timeCost: 2,
        parallelism: 1,
        note: "Memory-hard, GPU/ASIC resistant. Never logged, never returned in API responses.",
      },
      validation: {
        emailSchema: "Gmail-only (Zod .refine)",
        fullNameSchema: "2-80 chars, no < >",
        passwordSchema: "min 8, max 128, letters + numbers",
        messageSchema: "1-4000 chars",
        imageUrlValidator: "http/https only, rejects javascript:/data:/vbscript:/file:/blob:/about:",
        commentSchema: "1-500 chars",
        reportReasonSchema: "SPAM | ABUSE | HARASSMENT | OTHER",
      },
      xssProtection: {
        react: "React escapes by default (no dangerouslySetInnerHTML on user content)",
        articleContent: "whitespace-pre-wrap (plain text, no HTML rendering)",
        postContent: "React segments (text + safe <a> links, no HTML)",
        profileBio: "Plain text (dir=auto, React-escaped)",
        searchQueries: "Prisma parameterized (ILIKE, no SQL injection)",
      },
      idorProtection: {
        profileEdit: "Server derives userId from session (never from body)",
        postEdit: "Server verifies post.authorId === session.user.id",
        postDelete: "Server verifies ownership or admin role",
        articleEdit: "Server verifies article.authorId === session.user.id",
        commentDelete: "Server verifies comment.authorId === session.user.id OR admin",
        messageAccess: "Server verifies conversation membership",
        adminActions: "requireAdmin()/requireSuperAdmin() middleware",
      },
      corsPolicy: {
        configured: "credentials: 'include' (cookie-based, same-origin by default)",
        note: "No wildcard '*'. API requires session cookie. Cross-origin requests need explicit CORS config if needed.",
      },
      csrfProtection: {
        mechanism: "SameSite=Lax cookie + iron-session signed/encrypted",
        note: "SameSite=Lax prevents CSRF on state-changing requests from cross-origin. iron-session signature prevents cookie tampering.",
      },
      audit: {
        totalLogs,
        today: todayLogs,
        thisWeek: weekLogs,
        topActions: byAction.map((a: any) => ({ action: a.action, count: a._count.action })),
        immutable: true,
        appendOnly: true,
        note: "Audit logs are append-only. No delete endpoint for normal admins. Super Admin can view but not edit.",
      },
      envVars,
      dataSafety: {
        secretsNotInClient: "All secrets in .env (server-side only). Never in client-side code.",
        noRawSqlFromUserInput: "All queries via Prisma (parameterized). No $queryRaw from user input.",
        userContentSanitized: "React escapes user content. URLs validated server-side. No user-provided HTML in metadata.",
      },
    },
  });
});
