import { apiHandler, badRequest, notFound, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin, ForbiddenError } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { destroyAllUserSessions } from "@/lib/auth/session";
import { isSuperAdmin, hasRole } from "@/lib/permissions";
import { logger } from "@/lib/logging";

/**
 * GET /api/v1/admin/reports/:id
 * ------------------------------
 * Report detail view (spec §5, §6, §9).
 *
 * Returns:
 *   - Full report info (reason, description, status, priority, notes,
 *     resolutionNote, createdAt, resolvedAt).
 *   - Reporter info (spec §11 — admin-only, never exposed to the
 *     reported user).
 *   - Target user info (public profile fields only).
 *   - Content preview: for user reports, the user's public profile;
 *     for message reports, the message content (legitimate moderation
 *     workflow — spec §11).
 *   - Previous reports against the same user (spec §9 — aggregated
 *     report count against this user).
 *
 * SECURITY (spec §20, §11):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Reporter info is admin-only.
 *   - No private message content exposed beyond the specific reported
 *     message (legitimate moderation workflow per the existing privacy
 *     model).
 */
export const GET = apiHandler(async (_req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;

  const report = await db.report.findUnique({
    where: { id },
    include: {
      reporter: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true, email: true } },
      target: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true, status: true, role: true, bio: true, createdAt: true, _count: { select: { posts: true, articles: true, followers: true } } } },
    },
  });
  if (!report) return notFound("Report not found");

  // Fetch the reported message if this is a message report.
  let reportedMessage: any = null;
  if (report.targetMessageId) {
    reportedMessage = await db.message.findUnique({
      where: { id: report.targetMessageId },
      select: {
        id: true, content: true, createdAt: true,
        sender: { select: { id: true, fullName: true, username: true } },
      },
    }).catch(() => null);
  }

  // Previous reports against the same user (spec §9 — aggregated count).
  let previousReports: any[] = [];
  let reportCount = 0;
  if (report.targetUserId) {
    reportCount = await db.report.count({
      where: { targetUserId: report.targetUserId, id: { not: id } },
    });
    previousReports = await db.report.findMany({
      where: { targetUserId: report.targetUserId, id: { not: id } },
      orderBy: { createdAt: "desc" },
      take: 5,
      select: {
        id: true, reason: true, status: true, createdAt: true,
        reporter: { select: { fullName: true, username: true } },
      },
    });
  }

  await recordAudit({
    adminId: admin.id,
    action: "admin.report.view",
    targetType: "report",
    targetId: id,
  });

  return ok({
    report: {
      id: report.id,
      reporterId: report.reporterId,
      targetUserId: report.targetUserId,
      targetMessageId: report.targetMessageId,
      targetPostId: report.targetPostId,
      targetArticleId: report.targetArticleId,
      targetCommentId: report.targetCommentId,
      reason: report.reason,
      description: report.description,
      status: report.status,
      priority: report.priority,
      assignedToId: report.assignedToId,
      notes: report.notes,
      resolutionNote: report.resolutionNote,
      resolvedById: report.resolvedById,
      createdAt: report.createdAt.toISOString(),
      resolvedAt: report.resolvedAt?.toISOString() ?? null,
      reporter: report.reporter,
      target: report.target,
    },
    reportedMessage: reportedMessage ? {
      ...reportedMessage,
      createdAt: reportedMessage.createdAt.toISOString(),
    } : null,
    previousReports: previousReports.map((r) => ({
      ...r,
      createdAt: r.createdAt.toISOString(),
    })),
    totalReportsAgainstUser: reportCount,
  });
});

/**
 * PATCH /api/v1/admin/reports/:id
 * ---------------------------------
 * Update report status, priority, notes, or assignment (spec §7, §13, §17, §18).
 *
 * Request body (any subset):
 *   { status?, priority?, notes?, resolutionNote?, assignedToId? }
 *
 * SECURITY (spec §20):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - All fields validated server-side.
 *   - Audit recorded for every update (spec §19).
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  const body = await parseJsonBody<{
    status?: string;
    priority?: string;
    notes?: string;
    resolutionNote?: string;
    assignedToId?: string | null;
  }>(req);

  const report = await db.report.findUnique({ where: { id } });
  if (!report) return notFound("Report not found");

  const data: any = {};

  // Status update (spec §3).
  if (body.status !== undefined) {
    const validStatuses = ["OPEN", "INVESTIGATING", "RESOLVED", "DISMISSED"];
    if (!validStatuses.includes(body.status)) {
      return badRequest("Invalid status. Allowed: OPEN, INVESTIGATING, RESOLVED, DISMISSED");
    }
    data.status = body.status;
    // Set resolvedAt + resolvedById when resolving/dismissing.
    if (body.status === "RESOLVED" || body.status === "DISMISSED") {
      data.resolvedAt = new Date();
      data.resolvedById = admin.id;
    }
  }

  // Priority (spec §13).
  if (body.priority !== undefined) {
    const validPriorities = ["LOW", "NORMAL", "HIGH", "CRITICAL"];
    if (!validPriorities.includes(body.priority)) {
      return badRequest("Invalid priority. Allowed: LOW, NORMAL, HIGH, CRITICAL");
    }
    data.priority = body.priority;
  }

  // Internal notes (spec §18 — NEVER public).
  if (body.notes !== undefined) {
    data.notes = typeof body.notes === "string" ? body.notes.slice(0, 2000) : null;
  }

  // Resolution note.
  if (body.resolutionNote !== undefined) {
    data.resolutionNote = typeof body.resolutionNote === "string" ? body.resolutionNote.slice(0, 1000) : null;
  }

  // Assignment (spec §17).
  if (body.assignedToId !== undefined) {
    // Validate that the assigned admin is actually an admin.
    if (body.assignedToId !== null) {
      const assignee = await db.user.findUnique({
        where: { id: body.assignedToId },
        select: { role: true },
      });
      if (!assignee || !hasRole(assignee.role, "ADMIN")) {
        return badRequest("Can only assign to admin users");
      }
    }
    data.assignedToId = body.assignedToId;
  }

  const updated = await db.report.update({ where: { id }, data });

  await recordAudit({
    adminId: admin.id,
    action: "admin.report.update",
    targetType: "report",
    targetId: id,
    metadata: { status: body.status, priority: body.priority, assignedToId: body.assignedToId },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ report: { ...updated, createdAt: updated.createdAt.toISOString(), resolvedAt: updated.resolvedAt?.toISOString() ?? null } });
});

/**
 * POST /api/v1/admin/reports/:id
 * --------------------------------
 * Moderation action endpoint (spec §7, §8, §19).
 *
 * Request body: { action: "RESOLVE" | "REJECT" | "REVIEW" | "SUSPEND_USER" | "BAN_USER" | "DELETE_MESSAGE" }
 *
 * Actions:
 *   - RESOLVE: mark report as RESOLVED.
 *   - REJECT: mark report as DISMISSED.
 *   - REVIEW: mark report as INVESTIGATING.
 *   - SUSPEND_USER: suspend the reported user (super admin or admin if
 *     target is a normal user — spec §20, §21).
 *   - BAN_USER: ban the reported user (super admin only for admins).
 *   - DELETE_MESSAGE: delete the reported message (soft delete — content
 *     replaced, existing behavior).
 *
 * SECURITY (spec §20, §21):
 *   - requireAdmin() on all actions.
 *   - SUSPEND/BAN: self-protection (can't suspend/ban yourself),
 *     super-admin protection (can't act on SUPER_ADMIN without being one),
 *     admin-to-admin protection (can't act on ADMIN without being super admin).
 *   - All destructive actions require confirmation (handled by the UI).
 *   - Audit recorded (spec §19).
 */
export const POST = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  const body = await parseJsonBody<{ action?: string; reason?: string }>(req);

  const ALLOWED_ACTIONS = ["RESOLVE", "REJECT", "REVIEW", "SUSPEND_USER", "BAN_USER", "DELETE_MESSAGE"];
  const action = body.action;
  if (!action || !ALLOWED_ACTIONS.includes(action)) {
    return badRequest("Invalid action");
  }

  const report = await db.report.findUnique({ where: { id } });
  if (!report) return notFound("Report not found");

  // ── Status-only actions (RESOLVE, REJECT, REVIEW) ──────────────
  if (action === "RESOLVE" || action === "REJECT" || action === "REVIEW") {
    const newStatus = action === "RESOLVE" ? "RESOLVED"
      : action === "REJECT" ? "DISMISSED"
      : "INVESTIGATING";

    await db.report.update({
      where: { id },
      data: {
        status: newStatus,
        resolvedAt: (action === "RESOLVE" || action === "REJECT") ? new Date() : report.resolvedAt,
        resolvedById: (action === "RESOLVE" || action === "REJECT") ? admin.id : report.resolvedById,
      },
    });

    await recordAudit({
      adminId: admin.id,
      action: `admin.report.${action.toLowerCase()}`,
      targetType: "report",
      targetId: id,
      metadata: { reason: body.reason ?? null },
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });

    return ok({ action, reportId: id, newStatus });
  }

  // ── User actions (SUSPEND_USER, BAN_USER) ──────────────────────
  if (action === "SUSPEND_USER" || action === "BAN_USER") {
    if (!report.targetUserId) return badRequest("This report has no target user");

    const target = await db.user.findUnique({ where: { id: report.targetUserId }, select: { id: true, role: true, status: true, email: true } });
    if (!target) return notFound("Target user not found");

    // Self-protection (spec §20).
    if (target.id === admin.id) {
      throw new ForbiddenError("Cannot take action on your own account");
    }
    // Super-admin protection (spec §21).
    if (target.role === "SUPER_ADMIN" && !isSuperAdmin(admin.role)) {
      throw new ForbiddenError("Cannot take action on a Super Admin");
    }
    // Admin-to-admin protection.
    if (hasRole(target.role, "ADMIN") && !isSuperAdmin(admin.role)) {
      throw new ForbiddenError("Cannot take action on another admin");
    }

    const newStatus = action === "SUSPEND_USER" ? "SUSPENDED" : "BANNED";
    await db.user.update({ where: { id: target.id }, data: { status: newStatus } });
    await destroyAllUserSessions(target.id);

    // Also resolve the report.
    await db.report.update({
      where: { id },
      data: {
        status: "RESOLVED",
        resolvedAt: new Date(),
        resolvedById: admin.id,
        resolutionNote: `User ${newStatus.toLowerCase()} by ${admin.fullName}`,
      },
    });

    await recordAudit({
      adminId: admin.id,
      action: `admin.report.${action.toLowerCase()}`,
      targetType: "user",
      targetId: target.id,
      metadata: { reportId: id, reason: body.reason ?? null, newStatus },
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });

    logger.info("admin", `Report ${id}: user ${action}`, { targetUserId: target.id, adminId: admin.id });

    return ok({ action, reportId: id, userId: target.id, newStatus });
  }

  // ── Delete message (DELETE_MESSAGE) ─────────────────────────────
  if (action === "DELETE_MESSAGE") {
    if (!report.targetMessageId) return badRequest("This report has no target message");

    const message = await db.message.findUnique({ where: { id: report.targetMessageId }, select: { id: true, content: true } });
    if (!message) return notFound("Message not found");

    // Soft delete: replace content (existing behavior).
    await db.message.update({
      where: { id: message.id },
      data: { content: "[message deleted by admin]", deletedAt: new Date() },
    });

    // Resolve the report.
    await db.report.update({
      where: { id },
      data: {
        status: "RESOLVED",
        resolvedAt: new Date(),
        resolvedById: admin.id,
        resolutionNote: "Message deleted by admin",
      },
    });

    await recordAudit({
      adminId: admin.id,
      action: "admin.report.delete_message",
      targetType: "report",
      targetId: id,
      metadata: { messageId: message.id, reason: body.reason ?? null },
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
    });

    return ok({ action, reportId: id, messageId: message.id });
  }

  return badRequest("Unsupported action");
});
