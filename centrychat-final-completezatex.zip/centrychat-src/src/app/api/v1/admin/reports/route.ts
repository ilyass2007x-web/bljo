import { apiHandler, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/admin/reports
 * --------------------------
 * Admin Moderation & Reports Center list (spec §2, §3, §12, §14, §15, §23).
 *
 * Features:
 *   - Status filter: OPEN (Pending), INVESTIGATING (Under Review),
 *     RESOLVED, DISMISSED (Rejected), or all.
 *   - Priority filter: LOW, NORMAL, HIGH, CRITICAL.
 *   - Search: by reporter/target username, reason, report ID.
 *   - Sort: newest, oldest, priority.
 *   - Pagination: offset-based (sufficient for admin browsing).
 *   - Includes reporter + target user info (spec §11 — reporter protection:
 *     only admin-accessible, never exposed to the reported user).
 *   - Moderation statistics (spec §15): pending, today, this week,
 *     resolved, rejected, most reported type.
 *
 * SECURITY (spec §20):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Reporter info is returned to admins only (spec §11).
 *   - All queries parameterized (no SQL injection).
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const url = new URL(req.url);

  const status = url.searchParams.get("status") ?? "";
  const priority = url.searchParams.get("priority") ?? "";
  const q = (url.searchParams.get("q") ?? "").trim();
  const sortBy = url.searchParams.get("sortBy") ?? "newest";
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(50, Number(url.searchParams.get("pageSize") ?? "20"));

  // Build WHERE.
  const where: Prisma.ReportWhereInput = {
    AND: [
      status ? { status } : {},
      priority ? { priority } : {},
      q ? {
        OR: [
          { id: { contains: q, mode: "insensitive" } },
          { reason: { contains: q, mode: "insensitive" } },
          { reporter: { username: { contains: q, mode: "insensitive" } } },
          { reporter: { fullName: { contains: q, mode: "insensitive" } } },
          { target: { username: { contains: q, mode: "insensitive" } } },
          { target: { fullName: { contains: q, mode: "insensitive" } } },
          { description: { contains: q, mode: "insensitive" } },
        ],
      } : {},
    ],
  };

  // Build orderBy.
  const orderBy: Prisma.ReportOrderByWithRelationInput =
    sortBy === "oldest" ? { createdAt: "asc" }
    : sortBy === "priority" ? [{ priority: "desc" }, { createdAt: "desc" }] as any
    : { createdAt: "desc" }; // newest (default)

  const [reports, total] = await Promise.all([
    db.report.findMany({
      where,
      orderBy,
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        reporter: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
        target: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true, status: true, role: true } },
      },
    }),
    db.report.count({ where }),
  ]);

  // ── Moderation statistics (spec §15) ─────────────────────────────
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekStart = new Date(todayStart);
  weekStart.setDate(weekStart.getDate() - weekStart.getDay());

  const [
    pendingCount, todayCount, weekCount, resolvedCount, rejectedCount,
    reportsByReason,
  ] = await Promise.all([
    db.report.count({ where: { status: "OPEN" } }),
    db.report.count({ where: { createdAt: { gte: todayStart } } }),
    db.report.count({ where: { createdAt: { gte: weekStart } } }),
    db.report.count({ where: { status: "RESOLVED" } }),
    db.report.count({ where: { status: "DISMISSED" } }),
    db.report.groupBy({
      by: ["reason"],
      _count: { reason: true },
      orderBy: { _count: { reason: "desc" } },
      take: 5,
    }),
  ]);

  // Average resolution time (spec §16).
  const resolvedReports = await db.report.findMany({
    where: { status: "RESOLVED", resolvedAt: { not: null } },
    select: { createdAt: true, resolvedAt: true },
    take: 100, // last 100 resolved reports for the average
  }).catch(() => []);
  const avgResolutionMs = resolvedReports.length > 0
    ? resolvedReports.reduce((sum, r) => {
        const ms = (r.resolvedAt!.getTime() - r.createdAt.getTime());
        return sum + ms;
      }, 0) / resolvedReports.length
    : 0;
  const avgResolutionHours = Math.round((avgResolutionMs / (60 * 60 * 1000)) * 10) / 10;

  await recordAudit({
    adminId: admin.id,
    action: "admin.reports.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
    metadata: { status, priority, q, page, pageSize },
  });

  return ok({
    reports: reports.map((r) => ({
      id: r.id,
      reason: r.reason,
      description: r.description,
      status: r.status,
      priority: r.priority,
      assignedToId: r.assignedToId,
      notes: r.notes,
      resolutionNote: r.resolutionNote,
      createdAt: r.createdAt.toISOString(),
      resolvedAt: r.resolvedAt?.toISOString() ?? null,
      reporter: r.reporter,
      target: r.target,
      targetUserId: r.targetUserId,
      targetMessageId: r.targetMessageId,
      targetPostId: r.targetPostId,
      targetArticleId: r.targetArticleId,
      targetCommentId: r.targetCommentId,
    })),
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
    stats: {
      pending: pendingCount,
      today: todayCount,
      thisWeek: weekCount,
      resolved: resolvedCount,
      rejected: rejectedCount,
      avgResolutionHours,
      reportsByReason: reportsByReason.map((r) => ({ reason: r.reason, count: r._count.reason })),
    },
  });
});

/**
 * POST /api/v1/admin/reports
 * Create a report manually (admin override — spec §17 moderator assignment
 * preparation). Not typically used — reports are usually user-submitted.
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    reporterId?: string;
    targetUserId?: string;
    reason?: string;
    description?: string;
    priority?: string;
  }>(req);

  // Minimal validation — the admin is the actor.
  if (!body.targetUserId || !body.reason) {
    return ok({ created: false });
  }

  const report = await db.report.create({
    data: {
      reporterId: body.reporterId ?? admin.id,
      targetUserId: body.targetUserId,
      reason: body.reason,
      description: body.description ?? "",
      priority: body.priority ?? "NORMAL",
    },
  });

  await recordAudit({
    adminId: admin.id,
    action: "admin.report.create",
    targetType: "report",
    targetId: report.id,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ report: { id: report.id, status: report.status } });
});
