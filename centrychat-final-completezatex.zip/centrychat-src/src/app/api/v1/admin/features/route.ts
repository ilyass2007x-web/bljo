import { apiHandler, badRequest, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { listFeatureFlags, setFeatureFlag } from "@/lib/features";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  await recordAudit({
    adminId: admin.id,
    action: "admin.features.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  const flags = await listFeatureFlags();
  return ok({ flags });
});

export const PUT = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    key?: string;
    enabled?: boolean;
    configuration?: string;
  }>(req);

  // PHASE 1 FIX (Video Chat admin toggle crash):
  // Previously this branch returned `ok({})` (HTTP 200 with an EMPTY body)
  // when validation failed. The admin UI's `toggleVideoChat()` callback
  // then did `res.flags.find(...)` — which threw `TypeError: Cannot read
  // properties of undefined (reading 'find')` because `res.flags` was
  // undefined. The Switch visually flipped ON (optimistic) but the catch
  // path silently reverted it, leaving the admin confused.
  //
  // The fix returns HTTP 400 `badRequest` with a JSON `{ error: { ... } }`
  // body. The client's `ApiClientError` handler picks up the message
  // and shows a clear toast — no TypeError, no silent revert.
  //
  // Validation rules (UNCHANGED):
  //   - `key` must be a non-empty string
  //   - `enabled` must be a boolean
  //   - `configuration` is optional (string | undefined)
  if (!body || typeof body.key !== "string" || body.key.trim().length === 0 || typeof body.enabled !== "boolean") {
    return badRequest("key (non-empty string) + enabled (boolean) are required.");
  }

  await setFeatureFlag(body.key, body.enabled, admin.id, body.configuration);
  await recordAudit({
    adminId: admin.id,
    action: "admin.features.update",
    targetType: "feature_flag",
    targetId: body.key,
    metadata: { enabled: body.enabled },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  const flags = await listFeatureFlags();
  return ok({ flags });
});
