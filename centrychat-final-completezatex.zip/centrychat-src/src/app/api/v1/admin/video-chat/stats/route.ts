import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getVideoChatStats } from "@/lib/video-chat/matchmaking";

/**
 * GET /api/v1/admin/video-chat/stats
 * -----------------------------------
 * Returns aggregate video chat statistics for the admin dashboard.
 *
 * Stats:
 *   - activeSessions (in-memory count)
 *   - usersSearching (in-memory queue size)
 *   - connectedToday (DB count of sessions connected today)
 *   - p2pSuccessRate (P2P / total completed)
 *   - turnUsageRate (TURN / total completed)
 *   - failedRate (FAILED / total completed)
 *   - avgCallDurationSec
 *   - totalReports
 */
export const GET = apiHandler(async () => {
  await requireAdmin();
  const stats = await getVideoChatStats();
  return ok({ stats });
});
