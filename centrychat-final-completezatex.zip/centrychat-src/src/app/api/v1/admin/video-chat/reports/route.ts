import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * GET /api/v1/admin/video-chat/reports
 * -------------------------------------
 * List video chat reports for the admin dashboard.
 *
 * Query params:
 *   - status (OPEN | INVESTIGATING | RESOLVED | DISMISSED)
 *   - page (default 1)
 *   - pageSize (default 50, max 100)
 */
export const GET = apiHandler(async (req) => {
  await requireAdmin();

  const url = new URL(req.url);
  const status = url.searchParams.get("status") || undefined;
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(100, Math.max(1, Number(url.searchParams.get("pageSize") ?? "50")));

  const where: { status?: string } = {};
  if (status) where.status = status;

  const [reports, total] = await Promise.all([
    db.videoChatReport.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        reporter: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true } },
        reported: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true } },
        session: { select: { id: true, startedAt: true, durationSec: true, connectionType: true } },
      },
    }),
    db.videoChatReport.count({ where }),
  ]);

  return ok({
    reports: reports.map((r) => ({
      id: r.id,
      sessionId: r.sessionId,
      reason: r.reason,
      description: r.description,
      status: r.status,
      createdAt: r.createdAt.toISOString(),
      reviewedAt: r.reviewedAt?.toISOString() ?? null,
      reporter: r.reporter,
      reported: r.reported,
      session: r.session,
    })),
    total,
    page,
    pageSize,
  });
});
