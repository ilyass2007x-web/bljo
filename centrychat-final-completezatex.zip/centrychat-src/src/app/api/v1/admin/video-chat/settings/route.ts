import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getClientIp } from "@/lib/security/rate-limit";
import { recordAudit } from "@/lib/audit";
import { setSetting } from "@/lib/settings";
import { loadVideoChatSettings } from "@/lib/video-chat/config";

/**
 * GET /api/v1/admin/video-chat/settings
 * --------------------------------------
 * Load all video chat settings (for the admin UI).
 * Includes the TURN credential (admin-only — never exposed publicly).
 */
export const GET = apiHandler(async (req) => {
  await requireAdmin();
  const settings = await loadVideoChatSettings();
  return ok({ settings });
});

/**
 * PUT /api/v1/admin/video-chat/settings
 * --------------------------------------
 * Update video chat settings. Accepts a partial body — only the provided
 * fields are updated.
 *
 * Body (all optional):
 *   { turnEnabled, turnUrl, turnUsername, turnCredential,
 *     turnProtocol, turnPort, turnTls, stunUrl,
 *     maxDurationSec, queueTimeoutSec, minAccountAgeHours }
 */
export const PUT = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await req.json().catch(() => ({} as Record<string, unknown>));

  const updates: Array<{ key: string; value: string }> = [];

  if (typeof body.turnEnabled === "boolean") {
    updates.push({ key: "videochat.turn.enabled", value: String(body.turnEnabled) });
  }
  if (typeof body.turnUrl === "string") {
    updates.push({ key: "videochat.turn.url", value: body.turnUrl.trim() });
  }
  if (typeof body.turnUsername === "string") {
    updates.push({ key: "videochat.turn.username", value: body.turnUsername.trim() });
  }
  if (typeof body.turnCredential === "string") {
    updates.push({ key: "videochat.turn.credential", value: body.turnCredential });
  }
  if (typeof body.turnProtocol === "string") {
    if (!["udp", "tcp", "tls"].includes(body.turnProtocol)) {
      return badRequest("turnProtocol must be udp, tcp, or tls.");
    }
    updates.push({ key: "videochat.turn.protocol", value: body.turnProtocol });
  }
  if (typeof body.turnPort === "number") {
    if (body.turnPort < 1 || body.turnPort > 65535) {
      return badRequest("turnPort must be between 1 and 65535.");
    }
    updates.push({ key: "videochat.turn.port", value: String(body.turnPort) });
  }
  if (typeof body.turnTls === "boolean") {
    updates.push({ key: "videochat.turn.tls", value: String(body.turnTls) });
  }
  if (typeof body.stunUrl === "string") {
    updates.push({ key: "videochat.stun.url", value: body.stunUrl.trim() });
  }
  if (typeof body.maxDurationSec === "number") {
    if (body.maxDurationSec < 60 || body.maxDurationSec > 86400) {
      return badRequest("maxDurationSec must be between 60 and 86400.");
    }
    updates.push({ key: "videochat.max_duration_sec", value: String(body.maxDurationSec) });
  }
  if (typeof body.queueTimeoutSec === "number") {
    if (body.queueTimeoutSec < 10 || body.queueTimeoutSec > 300) {
      return badRequest("queueTimeoutSec must be between 10 and 300.");
    }
    updates.push({ key: "videochat.queue_timeout_sec", value: String(body.queueTimeoutSec) });
  }
  if (typeof body.minAccountAgeHours === "number") {
    if (body.minAccountAgeHours < 0 || body.minAccountAgeHours > 720) {
      return badRequest("minAccountAgeHours must be between 0 and 720.");
    }
    updates.push({ key: "videochat.min_account_age_hours", value: String(body.minAccountAgeHours) });
  }
  if (typeof body.debugLogging === "boolean") {
    updates.push({ key: "videochat.debug_logging", value: String(body.debugLogging) });
  }

  for (const u of updates) {
    await setSetting(u.key, u.value, admin.id);
  }

  await recordAudit({
    adminId: admin.id,
    action: "admin.videochat.settings.update",
    targetType: "setting",
    targetId: "videochat",
    metadata: { updatedFields: updates.map((u) => u.key) },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const settings = await loadVideoChatSettings();
  return ok({ settings, updated: true });
});
