import { apiHandler, badRequest, notFound, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { getSitePageForAdmin, saveSitePage } from "@/lib/site-pages";

/**
 * GET /api/v1/admin/site-pages/:slug
 * ------------------------------------
 * Returns a single SitePage (admin view — includes drafts).
 *
 * Auth: requireAdmin().
 *
 * Lazy-creates the row if missing (with default content as a draft) so
 * the admin can edit even on a fresh deploy.
 *
 * Valid slugs: about | privacy | terms | contact. Any other slug → 404.
 */
export const GET = apiHandler(async (_req, ctx) => {
  const admin = await requireAdmin();
  void admin;
  const { slug } = await ctx.params;
  if (!slug || !["about", "privacy", "terms", "contact"].includes(slug)) {
    return notFound("Page not found");
  }
  const page = await getSitePageForAdmin(slug);
  if (!page) {
    return notFound("Page not found");
  }
  return ok({ page });
});

/**
 * PUT /api/v1/admin/site-pages/:slug
 * ------------------------------------
 * Replace the content of a SitePage.
 *
 * Auth: requireAdmin().
 *
 * Body (any subset — only provided fields are updated):
 *   {
 *     title?: string,
 *     content?: { intro, sections[], contact? },
 *     seoTitle?: string,
 *     seoDescription?: string,
 *     isPublished?: boolean
 *   }
 *
 * Validation:
 *   - slug must be one of the 4 reserved slugs (clients cannot create
 *     arbitrary new pages).
 *   - title: non-empty, ≤200 chars.
 *   - content: validated via Zod (SitePageContentSchema).
 *   - seoTitle: ≤200 chars.
 *   - seoDescription: ≤300 chars.
 *   - Total JSON payload capped at 200 KB.
 *
 * Audit:
 *   - Records an `admin.site-page.update` audit log entry with IP + UA +
 *     a sanitized metadata blob (slug + isPublished + section count —
 *     never the content itself).
 *
 * Cache invalidation:
 *   - The public read cache for this slug is invalidated on save so
 *     visitors see the update within 30 seconds.
 *
 * Response: the saved SitePageRow.
 */
export const PUT = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { slug } = await ctx.params;
  if (!slug || !["about", "privacy", "terms", "contact"].includes(slug)) {
    return notFound("Page not found");
  }

  const body = await parseJsonBody<{
    title?: string;
    content?: unknown;
    seoTitle?: string;
    seoDescription?: string;
    isPublished?: boolean;
  }>(req);

  let saved;
  try {
    saved = await saveSitePage(
      slug,
      {
        title: body.title,
        content: body.content as never,
        seoTitle: body.seoTitle,
        seoDescription: body.seoDescription,
        isPublished: body.isPublished,
      },
      admin.id
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Invalid site page content";
    return badRequest(message);
  }

  // Audit log — record the action WITHOUT the content (privacy + log size).
  await recordAudit({
    adminId: admin.id,
    action: "admin.site-page.update",
    targetType: "site_page",
    targetId: slug,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
    metadata: {
      slug,
      isPublished: saved.isPublished,
      sectionCount: saved.content.sections.length,
      hasSeoTitle: !!saved.seoTitle,
      hasSeoDescription: !!saved.seoDescription,
    },
  });

  return ok({ page: saved });
});
