import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { listSitePagesForAdmin } from "@/lib/site-pages";

/**
 * GET /api/v1/admin/site-pages
 * ------------------------------
 * Returns ALL site pages (about, privacy, terms, contact) — including
 * drafts. Used by the "Pages & Legal" admin section to render the list.
 *
 * Auth: requireAdmin() — server-side enforced. Regular users get 403.
 *
 * Behavior:
 *   - Lazy-creates any missing rows with default content (as drafts)
 *     so the admin always sees all 4 cards.
 *   - Returns pages in the canonical order: about, privacy, terms, contact.
 *
 * Response shape:
 *   { pages: SitePageRow[] }
 */
export const GET = apiHandler(async () => {
  const admin = await requireAdmin();
  void admin; // auth boundary — admin object unused
  const pages = await listSitePagesForAdmin();
  return ok({ pages });
});
