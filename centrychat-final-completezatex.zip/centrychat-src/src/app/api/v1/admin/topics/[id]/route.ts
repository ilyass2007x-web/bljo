import { apiHandler, ok, badRequest, notFound } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import { adminUpdateTopic, adminDeactivateTopic } from "@/lib/topics";

/**
 * GET /api/v1/admin/topics/[id]
 * -----------------------------
 * Get a single topic by ID (admin view — includes inactive topics).
 */
export const GET = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;

  const topic = await db.contentTopic.findUnique({
    where: { id },
    select: {
      id: true, name: true, slug: true, description: true, isActive: true,
      createdAt: true, updatedAt: true,
      _count: { select: { followers: true, articles: true, posts: true } },
    },
  });
  if (!topic) return notFound("Topic not found.");

  void recordAudit({
    adminId: admin.id,
    action: "admin.topic.view",
    targetType: "topic",
    targetId: topic.id,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  }).catch(() => { /* non-fatal */ });

  return ok({
    topic: {
      id: topic.id,
      name: topic.name,
      slug: topic.slug,
      description: topic.description,
      isActive: topic.isActive,
      followerCount: topic._count.followers,
      articleCount: topic._count.articles,
      postCount: topic._count.posts,
      createdAt: topic.createdAt.toISOString(),
      updatedAt: topic.updatedAt.toISOString(),
    },
  });
});

/**
 * PATCH /api/v1/admin/topics/[id]
 * -------------------------------
 * Update a topic (name, description, isActive, slug).
 *
 * Slug changes are only allowed when the topic has NO followers (to avoid
 * breaking indexed URLs). See adminUpdateTopic for the safety check.
 *
 * SECURITY: requireAdmin() server-side.
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const { name, description, isActive, slug } = body as {
    name?: string;
    description?: string | null;
    isActive?: boolean;
    slug?: string;
  };

  try {
    const topic = await adminUpdateTopic(id, {
      name: name ?? undefined,
      description: description ?? undefined,
      isActive: typeof isActive === "boolean" ? isActive : undefined,
      slug: slug ?? undefined,
    });

    void recordAudit({
      adminId: admin.id,
      action: "admin.topic.update",
      targetType: "topic",
      targetId: topic.id,
      metadata: { updatedFields: Object.keys(body) },
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
    }).catch(() => { /* non-fatal */ });

    return ok({ topic });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Failed to update topic.";
    if (msg.includes("not found")) return notFound(msg);
    return badRequest(msg);
  }
});

/**
 * DELETE /api/v1/admin/topics/[id]
 * --------------------------------
 * Soft-delete a topic (deactivate). Sets isActive=false. Existing
 * relationships preserved (so it can be reactivated later).
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;

  try {
    await adminDeactivateTopic(id);
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Failed to deactivate topic.";
    return notFound(msg);
  }

  void recordAudit({
    adminId: admin.id,
    action: "admin.topic.deactivate",
    targetType: "topic",
    targetId: id,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  }).catch(() => { /* non-fatal */ });

  return ok({ deactivated: true, id });
});
