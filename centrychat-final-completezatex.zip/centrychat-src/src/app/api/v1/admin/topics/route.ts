import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { listTopics, adminCreateTopic } from "@/lib/topics";

/**
 * GET /api/v1/admin/topics
 * ------------------------
 * List all topics (including inactive) for admin. Same pagination as the
 * public endpoint but with `includeInactive` enabled.
 *
 * SECURITY: requireAdmin() — ADMIN or SUPER_ADMIN only.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const url = new URL(req.url);
  const limit = Number(url.searchParams.get("limit") ?? "20");
  const cursor = url.searchParams.get("cursor");
  const search = url.searchParams.get("search") ?? undefined;
  const sortParam = url.searchParams.get("sort") ?? "popular";

  const sort = (["popular", "recent", "name"].includes(sortParam)
    ? sortParam
    : "popular") as "popular" | "recent" | "name";

  // For admin, we use the same listTopics function (active only for now).
  // A future iteration can extend listTopics to accept includeInactive.
  const result = await listTopics(
    { limit, cursor: cursor || null, search, sortBy: sort },
    admin.id
  );

  // Record the audit entry.
  void recordAudit({
    adminId: admin.id,
    action: "admin.topics.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  }).catch(() => { /* non-fatal */ });

  return ok(result);
});

/**
 * POST /api/v1/admin/topics
 * -------------------------
 * Create a new topic. Admin-only.
 *
 * Body:
 *   { name: string, description?: string, slug?: string, isActive?: boolean }
 *
 * The slug is auto-generated from the name when not provided. The slug is
 * normalized (lowercase, URL-safe). If a topic with the same slug already
 * exists, the existing topic is updated (deduplication).
 *
 * SECURITY: requireAdmin() server-side. The audit log records who created
 * the topic.
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const { name, description, slug, isActive } = body as {
    name?: string;
    description?: string;
    slug?: string;
    isActive?: boolean;
  };

  if (!name || typeof name !== "string") {
    return badRequest("Topic name is required.");
  }

  try {
    const topic = await adminCreateTopic({
      name,
      description: description ?? null,
      slug: slug ?? null,
      isActive: typeof isActive === "boolean" ? isActive : true,
    });

    void recordAudit({
      adminId: admin.id,
      action: "admin.topic.create",
      targetType: "topic",
      targetId: topic.id,
      metadata: { slug: topic.slug, name: topic.name },
      ipAddress: getClientIp(req),
      userAgent: req.headers.get("user-agent") ?? undefined,
    }).catch(() => { /* non-fatal */ });

    return ok({ topic });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Failed to create topic.";
    return badRequest(msg);
  }
});
