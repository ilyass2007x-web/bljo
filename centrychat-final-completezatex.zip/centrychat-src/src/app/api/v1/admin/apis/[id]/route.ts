import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

/**
 * PATCH /api/v1/admin/apis/:id — update status/visibility
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({})) as { status?: string };
  const updated = await db.externalApi.update({
    where: { id },
    data: {
      ...(body.status !== undefined ? { status: body.status } : {}),
    },
  });
  await recordAudit({
    adminId: admin.id,
    action: "admin.api.update",
    targetType: "external_api",
    targetId: id,
    metadata: { status: body.status },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  return ok({ api: { id: updated.id, status: updated.status } });
});

/**
 * DELETE /api/v1/admin/apis/:id — delete an API integration
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  await db.externalApi.delete({ where: { id } });
  await recordAudit({
    adminId: admin.id,
    action: "admin.api.delete",
    targetType: "external_api",
    targetId: id,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  return ok({ deleted: true });
});
