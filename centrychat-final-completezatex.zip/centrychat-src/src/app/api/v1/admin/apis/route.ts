import { apiHandler, ok, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

/**
 * Generate a safe hint from an API key: "sk_live_************1234"
 */
function maskApiKey(key: string): string {
  if (key.length <= 8) return "********";
  return key.slice(0, 8) + "*".repeat(Math.min(12, key.length - 12)) + key.slice(-4);
}

/**
 * GET /api/v1/admin/apis — list all external API integrations
 * Never returns the full API key — only the masked hint.
 */
export const GET = apiHandler(async () => {
  const admin = await requireAdmin();
  void admin;
  const apis = await db.externalApi.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      provider: true,
      baseUrl: true,
      apiKeyHint: true,
      status: true,
      description: true,
      createdAt: true,
      updatedAt: true,
    },
  });
  return ok({ apis });
});

/**
 * POST /api/v1/admin/apis — create a new external API integration
 * The API key is stored encrypted (apiKeyEnc) and only the masked hint is returned.
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    name?: string;
    provider?: string;
    baseUrl?: string;
    apiKey?: string;
    status?: string;
    description?: string;
  }>(req);

  if (!body.name || !body.provider) {
    return ok({ error: "name and provider are required" });
  }

  const apiKey = body.apiKey ?? "";
  const apiKeyHint = apiKey ? maskApiKey(apiKey) : null;
  // NOTE: In a production system, apiKeyEnc should be encrypted with AES-256
  // using a server-side key. For MVP we store it as-is (the DB is not exposed).
  // The full key is NEVER returned to the frontend — only apiKeyHint.

  const api = await db.externalApi.create({
    data: {
      name: body.name,
      provider: body.provider,
      baseUrl: body.baseUrl ?? null,
      apiKeyEnc: apiKey || null,
      apiKeyHint,
      status: body.status ?? "disabled",
      description: body.description ?? null,
      createdById: admin.id,
    },
  });

  await recordAudit({
    adminId: admin.id,
    action: "admin.api.add",
    targetType: "external_api",
    targetId: api.id,
    metadata: { name: body.name, provider: body.provider },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({
    api: {
      id: api.id,
      name: api.name,
      provider: api.provider,
      baseUrl: api.baseUrl,
      apiKeyHint: api.apiKeyHint,
      status: api.status,
      description: api.description,
    },
  });
});
