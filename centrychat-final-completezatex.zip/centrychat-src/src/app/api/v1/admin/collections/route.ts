import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { serializeCollection, type CollectionDTO } from "@/lib/collections";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/admin/collections
 * -----------------------------
 * Phase 5 — Collections: admin moderation view.
 *
 * Returns ALL PUBLIC collections on the platform (private collections are
 * NEVER shown to admins here — they're private, period). Admins can use
 * this to discover public collections that violate policy + take action
 * via the owner-side DELETE endpoint (the owner is asked to delete; or a
 * future dedicated admin delete endpoint can be added per spec §32).
 *
 * Auth: ADMIN or SUPER_ADMIN only (requireAdmin() — server-side check,
 * IDOR-safe). Non-admins get 401/403.
 *
 * Query params:
 *   - ?search=<query> — filter by name (case-insensitive contains).
 *   - ?limit=<n>     — page size (default 100, max 200).
 *
 * Response: { collections: SerializedCollection[] }
 *
 * SECURITY: this endpoint is for ADMINS ONLY. The query filters by
 * isPublic=true — admins can NEVER see another user's PRIVATE collections
 * (privacy invariant: collection existence is private to the owner).
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  await recordAudit({
    adminId: admin.id,
    action: "admin.collections.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const url = new URL(req.url);
  const search = (url.searchParams.get("search") ?? "").trim();
  const limit = Math.min(
    Math.max(Number(url.searchParams.get("limit") ?? "100"), 1),
    200
  );

  const where: Prisma.CollectionWhereInput = { isPublic: true };
  if (search.length >= 2) {
    where.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { description: { contains: search, mode: "insensitive" } },
    ];
  }

  const collections = await db.collection.findMany({
    where,
    orderBy: { updatedAt: "desc" },
    take: limit,
    select: ADMIN_COLLECTIONS_SELECT,
  });

  return ok({
    collections: collections.map((c) =>
      serializeCollection(c as CollectionDTO)
    ),
  });
});

// ── Shared projection (same shape as the lib's COLLECTION_SELECT) ──────────
const ADMIN_COLLECTIONS_SELECT = {
  id: true,
  ownerId: true,
  name: true,
  description: true,
  isPublic: true,
  createdAt: true,
  updatedAt: true,
  owner: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: { select: { items: true } },
} as const satisfies Prisma.CollectionSelect;
