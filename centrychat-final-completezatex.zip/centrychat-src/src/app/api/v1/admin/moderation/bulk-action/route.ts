import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { getClientIp } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import {
  bulkIssueWarnings,
  validateWarningInput,
  type WarningReason,
} from "@/lib/moderation/warnings";
import { approveContent, rejectContent } from "@/lib/moderation/pipeline";

/**
 * POST /api/v1/admin/moderation/bulk-action
 * ------------------------------------------
 * Perform a bulk action on multiple moderation items or users.
 *
 * Supported actions:
 *   - "warn"      → issue the same warning to multiple users
 *   - "approve"   → approve multiple pieces of content (flip moderationStatus to APPROVED)
 *   - "reject"    → reject multiple pieces of content (set moderationStatus to REJECTED)
 *   - "dismiss"   → dismiss multiple moderation events (mark as DISMISSED)
 *
 * Body for "warn":
 *   { action: "warn", userIds: string[], reason: string, message: string }
 *
 * Body for "approve" / "reject":
 *   { action: "approve" | "reject", items: [{ contentType, contentId }] }
 *
 * Body for "dismiss":
 *   { action: "dismiss", eventIds: string[] }
 *
 * Security:
 *   - requireAdmin
 *   - Rate-limited (adminWrite: 120/min)
 *   - Cap 100 items per call
 *   - Rank guardrail: non-SUPER_ADMIN cannot act on ADMIN/SUPER_ADMIN
 *   - Self-protection: cannot warn yourself
 *   - Every action audit logged with aggregate counts (NOT individual user IDs)
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const rl = await checkRateLimit(`admin-write:${admin.id}`, RATE_LIMITS.adminWrite);
  if (!rl.ok) return badRequest("Rate limit exceeded. Please slow down.");

  const body = await req.json().catch(() => ({} as unknown));
  const action = (body as { action?: unknown })?.action;

  const ipAddress = getClientIp(req);
  const userAgent = req.headers.get("user-agent") ?? undefined;

  // ── Bulk Warn ──────────────────────────────────────────────────────
  if (action === "warn") {
    const userIds = (body as { userIds?: unknown })?.userIds;
    const reason = (body as { reason?: unknown })?.reason;
    const message = (body as { message?: unknown })?.message;

    if (!Array.isArray(userIds) || userIds.length === 0) {
      return badRequest("userIds must be a non-empty array.");
    }
    if (userIds.length > 100) {
      return badRequest("Cannot warn more than 100 users at once.");
    }
    if (typeof reason !== "string" || typeof message !== "string") {
      return badRequest("reason and message are required.");
    }

    const validationError = validateWarningInput({ reason, message });
    if (validationError) return badRequest(validationError);

    // Fetch all target users to check ranks.
    const targets = await db.user.findMany({
      where: { id: { in: userIds } },
      select: { id: true, role: true },
    });
    const targetMap = new Map(targets.map((t) => [t.id, t]));

    // Rank guardrail: filter out ADMIN/SUPER_ADMIN targets if the actor
    // is not SUPER_ADMIN. Also filter out self.
    const filteredIds = userIds.filter((id) => {
      const target = targetMap.get(id);
      if (!target) return false; // not found
      if (id === admin.id) return false; // self-protection
      if (
        admin.role !== "SUPER_ADMIN" &&
        (target.role === "ADMIN" || target.role === "SUPER_ADMIN")
      ) {
        return false; // insufficient rank
      }
      return true;
    });

    const selfExcluded = userIds.length - filteredIds.length;

    const result = await bulkIssueWarnings({
      userIds: filteredIds,
      adminId: admin.id,
      reason: reason as WarningReason,
      message,
      ipAddress,
      userAgent,
    });

    // Audit log with aggregate counts (NOT individual user IDs — privacy).
    await recordAudit({
      adminId: admin.id,
      action: "admin.moderation.bulk_warn",
      targetType: "user",
      metadata: {
        requested: result.requested,
        issued: result.issued,
        failed: result.failed,
        selfExcluded,
        reason,
        bulk: true,
      },
      ipAddress,
      userAgent,
    });

    return ok({
      ...result,
      selfExcluded,
      message: `Warnings sent to ${result.issued} user(s).${selfExcluded > 0 ? ` ${selfExcluded} user(s) skipped (self or insufficient rank).` : ""}`,
    });
  }

  // ── Bulk Approve / Reject content ─────────────────────────────────
  if (action === "approve" || action === "reject") {
    const items = (body as { items?: unknown })?.items;
    if (!Array.isArray(items) || items.length === 0) {
      return badRequest("items must be a non-empty array.");
    }
    if (items.length > 100) {
      return badRequest("Cannot process more than 100 items at once.");
    }

    const deleteContent = (body as { deleteContent?: unknown })?.deleteContent === true;
    let successCount = 0;
    let failCount = 0;

    for (const item of items) {
      const contentType = (item as { contentType?: unknown })?.contentType;
      const contentId = (item as { contentId?: unknown })?.contentId;
      if (typeof contentType !== "string" || typeof contentId !== "string") {
        failCount++;
        continue;
      }
      try {
        if (action === "approve") {
          const ok_flag = await approveContent(
            contentType as Parameters<typeof approveContent>[0],
            contentId
          );
          if (ok_flag) successCount++;
          else failCount++;
        } else {
          const ok_flag = await rejectContent(
            contentType as Parameters<typeof rejectContent>[0],
            contentId,
            deleteContent
          );
          if (ok_flag) successCount++;
          else failCount++;
        }
      } catch {
        failCount++;
      }
    }

    // Audit log.
    await recordAudit({
      adminId: admin.id,
      action: `admin.moderation.bulk_${action}`,
      targetType: "content",
      metadata: {
        requested: items.length,
        succeeded: successCount,
        failed: failCount,
        deleteContent,
        bulk: true,
      },
      ipAddress,
      userAgent,
    });

    return ok({
      requested: items.length,
      succeeded: successCount,
      failed: failCount,
      message: `${successCount} item(s) ${action === "approve" ? "approved" : "rejected"}. ${failCount} failed.`,
    });
  }

  // ── Bulk Dismiss moderation events ─────────────────────────────────
  if (action === "dismiss") {
    const eventIds = (body as { eventIds?: unknown })?.eventIds;
    if (!Array.isArray(eventIds) || eventIds.length === 0) {
      return badRequest("eventIds must be a non-empty array.");
    }
    if (eventIds.length > 100) {
      return badRequest("Cannot dismiss more than 100 events at once.");
    }

    const result = await db.moderationEvent.updateMany({
      where: { id: { in: eventIds } },
      data: {
        status: "DISMISSED",
        reviewedAt: new Date(),
        reviewedById: admin.id,
      },
    });

    await recordAudit({
      adminId: admin.id,
      action: "admin.moderation.bulk_dismiss",
      targetType: "moderation_event",
      metadata: {
        requested: eventIds.length,
        updated: result.count,
        bulk: true,
      },
      ipAddress,
      userAgent,
    });

    return ok({
      requested: eventIds.length,
      updated: result.count,
      message: `${result.count} event(s) dismissed.`,
    });
  }

  return badRequest(`Unknown action: ${action}. Supported: warn, approve, reject, dismiss.`);
});
