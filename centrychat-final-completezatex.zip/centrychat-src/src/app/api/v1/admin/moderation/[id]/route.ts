import { apiHandler, ok, notFound, badRequest, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { updateModerationEventStatus } from "@/lib/moderation";
import type { ModerationStatus, ModerationContentType } from "@/lib/moderation";
import { approveContent, rejectContent } from "@/lib/moderation/pipeline";
import { db } from "@/lib/database";

/**
 * PATCH /api/v1/admin/moderation/:id
 * -----------------------------------
 * Admin action on a single moderation event.
 *
 * Body: { status: "APPROVED" | "REJECTED" | "DISMISSED", deleteContent?: boolean }
 *
 * When the admin approves:
 *   - The moderation event status → APPROVED
 *   - The underlying content's moderationStatus → APPROVED (content becomes public)
 *
 * When the admin rejects:
 *   - The moderation event status → REJECTED
 *   - The underlying content's moderationStatus → REJECTED (content hidden)
 *   - If deleteContent=true, the content row is deleted entirely
 *
 * When the admin dismisses:
 *   - The moderation event status → DISMISSED
 *   - The underlying content's moderationStatus is NOT changed (dismiss
 *     means "no action needed" — the content keeps its current status).
 *
 * SECURITY (spec §17):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Status is validated server-side (don't trust client input).
 *   - The admin's identity comes from the session, NOT from the request body.
 *   - Every action audit logged.
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return badRequest("Invalid moderation event id.");

  const body = await parseJsonBody<{ status?: string; deleteContent?: boolean }>(req);
  const requestedStatus = body.status;

  // Validate the requested status.
  const validStatuses: ModerationStatus[] = ["APPROVED", "REJECTED", "DISMISSED"];
  if (!requestedStatus || !validStatuses.includes(requestedStatus as ModerationStatus)) {
    return badRequest("Invalid status. Allowed: APPROVED, REJECTED, DISMISSED.");
  }

  // Fetch the moderation event to get the contentId + contentType BEFORE
  // updating — we need them to flip the content's moderationStatus.
  const event = await db.moderationEvent.findUnique({
    where: { id },
    select: { id: true, contentId: true, contentType: true, status: true },
  });
  if (!event) return notFound("Moderation event not found.");

  // Update the moderation event status (existing helper handles the event row).
  const result = await updateModerationEventStatus({
    eventId: id,
    newStatus: requestedStatus as ModerationStatus,
    adminId: admin.id,
    deleteContent: body.deleteContent === true && requestedStatus === "REJECTED",
  });

  if (result.notFound) return notFound("Moderation event not found.");

  // ── Flip the content's moderationStatus ────────────────────────────
  // This is the critical step that makes PENDING_MODERATION content public
  // (on APPROVE) or hides it (on REJECT). DISMISS does NOT change the
  // content's status.
  if (event.contentId && event.contentType) {
    try {
      if (requestedStatus === "APPROVED") {
        await approveContent(
          event.contentType as ModerationContentType,
          event.contentId
        );
      } else if (requestedStatus === "REJECTED") {
        await rejectContent(
          event.contentType as ModerationContentType,
          event.contentId,
          body.deleteContent === true
        );
      }
    } catch (err) {
      // Non-fatal — the moderation event was updated, but the content
      // status flip failed. The admin can re-apply the action.
      console.error("Failed to flip content moderationStatus:", err);
    }
  }

  await recordAudit({
    adminId: admin.id,
    action: `admin.moderation.${requestedStatus.toLowerCase()}`,
    targetType: "moderation_event",
    targetId: id,
    metadata: {
      deleteContent: body.deleteContent === true,
      contentType: event.contentType,
      contentId: event.contentId,
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ ok: true });
});

