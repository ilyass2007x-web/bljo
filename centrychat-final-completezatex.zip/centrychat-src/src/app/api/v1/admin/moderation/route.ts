import { apiHandler, ok, notFound, badRequest, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  getModerationStats,
  getModerationQueue,
  getModerationEventById,
  updateModerationEventStatus,
} from "@/lib/moderation";
import type { ModerationStatus, ModerationContentType } from "@/lib/moderation";

/**
 * GET /api/v1/admin/moderation
 * -----------------------------
 * Returns BOTH the dashboard stats AND a paginated moderation queue.
 *
 * Query params:
 *   - page (default 1)
 *   - pageSize (default 20, max 50)
 *   - status (optional: PENDING | APPROVED | REJECTED | DISMISSED)
 *   - contentType (optional: post | article | post_comment | ...)
 *
 * SECURITY (spec §14 — privacy):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - The moderation event data (categories, reasons, contentPreview) is
 *     NEVER exposed to end users — only to authenticated admins.
 *   - Audit-logged so admin access is recorded.
 *
 * Response: { stats: ModerationStats, queue: { items, total, page, pageSize } }
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const url = new URL(req.url);
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(50, Math.max(1, Number(url.searchParams.get("pageSize") ?? "20")));
  const statusParam = url.searchParams.get("status");
  const contentTypeParam = url.searchParams.get("contentType");

  // Validate status filter (don't trust client input).
  const status: ModerationStatus | undefined =
    statusParam && ["PENDING", "APPROVED", "REJECTED", "DISMISSED"].includes(statusParam)
      ? (statusParam as ModerationStatus)
      : undefined;

  // Validate contentType filter.
  const validContentTypes: ModerationContentType[] = [
    "post",
    "article",
    "article_title",
    "article_excerpt",
    "post_comment",
    "article_comment",
    "profile_bio",
    "profile_full_name",
  ];
  const contentType: ModerationContentType | undefined =
    contentTypeParam && validContentTypes.includes(contentTypeParam as ModerationContentType)
      ? (contentTypeParam as ModerationContentType)
      : undefined;

  // Fetch stats + queue in parallel.
  const [stats, queue] = await Promise.all([
    getModerationStats(),
    getModerationQueue({ page, pageSize, status, contentType }),
  ]);

  await recordAudit({
    adminId: admin.id,
    action: "admin.moderation.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
    metadata: { page, pageSize, status, contentType },
  });

  return ok({
    stats,
    queue: {
      items: queue.items,
      total: queue.total,
      page,
      pageSize,
      totalPages: Math.ceil(queue.total / pageSize),
    },
  });
});

/**
 * GET /api/v1/admin/moderation/:id
 * ---------------------------------
 * Fetch a single moderation event by ID. Used by the admin "view original"
 * modal — returns the full event including the 200-char preview + reasons.
 *
 * SECURITY: never returns the FULL original text (we never stored it — only
 * the 200-char preview). Admins who need the full text can navigate to
 * the content (when contentId is non-null).
 */
export const POST = apiHandler(async (req) => {
  // This POST endpoint is a fallback for "view single event" — used by the
  // admin modal when the queue list doesn't have the full reasons array.
  // The body contains the eventId.
  const admin = await requireAdmin();
  const body = await parseJsonBody<{ eventId?: string }>(req);
  if (!body.eventId) return badRequest("Missing eventId");

  const item = await getModerationEventById(body.eventId);
  if (!item) return notFound("Moderation event not found.");

  await recordAudit({
    adminId: admin.id,
    action: "admin.moderation.view",
    targetType: "moderation_event",
    targetId: body.eventId,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ event: item });
});
