import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getDatabaseProvider, pingDatabase } from "@/lib/database";
import { getStorageProvider } from "@/lib/storage";
import { getEmailProvider } from "@/lib/email";
import { getCache } from "@/lib/cache";
import { getJobs } from "@/lib/jobs";

export const GET = apiHandler(async () => {
  const admin = await requireAdmin();
  void admin;
  const db = await pingDatabase();
  return ok({
    system: {
      environment: process.env.NODE_ENV ?? "development",
      nodeVersion: process.version,
      platform: process.platform,
      uptimeSeconds: process.uptime(),
      memoryUsageMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
    },
    providers: {
      database: { name: getDatabaseProvider(), ok: db.ok, latencyMs: db.latencyMs },
      storage: { name: getStorageProvider().name },
      email: { name: getEmailProvider().name },
      cache: { name: getCache().name },
      jobs: { name: getJobs().name },
      realtime: { name: process.env.REALTIME_INTERNAL_URL ? "socket.io" : "disabled" },
    },
  });
});
