import { apiHandler, ok, badRequest, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { setSetting } from "@/lib/settings";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  loadAdMobSettings,
  isValidAdMobAppId,
  bumpAdMobConfigVersion,
  type AdMobSettings,
} from "@/lib/admob/manager";

/**
 * GET /api/v1/admin/admob/settings
 * Returns the current AdMob global settings. ADMIN-only.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  await recordAudit({
    adminId: admin.id,
    action: "admin.admob.settings.read",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  const settings = await loadAdMobSettings();
  return ok({ settings });
});

/**
 * PUT /api/v1/admin/admob/settings
 * Updates AdMob global settings. ADMIN-only. Validates field values.
 *
 * Request body (any subset):
 *   {
 *     enabled?: boolean,
 *     environment?: "development" | "production",
 *     androidMinVersion?: string,
 *     iosMinVersion?: string
 *   }
 *
 * NOTE: config_version is NOT settable here — it's bumped automatically
 * by bumpAdMobConfigVersion() on every mutation (settings + apps + units).
 */
export const PUT = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    enabled?: boolean;
    environment?: string;
    androidMinVersion?: string;
    iosMinVersion?: string;
  }>(req);

  const updates: { key: string; value: string }[] = [];

  if (body.enabled !== undefined) {
    updates.push({ key: "admob.enabled", value: String(body.enabled) });
  }

  if (body.environment !== undefined) {
    const env = body.environment.toLowerCase();
    if (env !== "development" && env !== "production") {
      return badRequest("environment must be 'development' or 'production'.");
    }
    updates.push({ key: "admob.environment", value: env });
  }

  if (body.androidMinVersion !== undefined) {
    if (typeof body.androidMinVersion !== "string" || !/^\d+\.\d+\.\d+/.test(body.androidMinVersion)) {
      return badRequest("androidMinVersion must be a semver string (e.g. '1.4.0').");
    }
    updates.push({ key: "admob.android_min_version", value: body.androidMinVersion });
  }

  if (body.iosMinVersion !== undefined) {
    if (typeof body.iosMinVersion !== "string" || !/^\d+\.\d+\.\d+/.test(body.iosMinVersion)) {
      return badRequest("iosMinVersion must be a semver string (e.g. '1.4.0').");
    }
    updates.push({ key: "admob.ios_min_version", value: body.iosMinVersion });
  }

  for (const u of updates) {
    await setSetting(u.key, u.value, admin.id);
  }

  // Bump the config version so the mobile app detects the change (spec §21).
  await bumpAdMobConfigVersion(admin.id);

  await recordAudit({
    adminId: admin.id,
    action: "admin.admob.settings.update",
    targetType: "setting",
    targetId: "admob",
    metadata: { updatedFields: updates.map((u) => u.key) },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const settings: AdMobSettings = await loadAdMobSettings();
  return ok({ settings });
});
