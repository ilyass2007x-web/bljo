import { apiHandler, ok, badRequest, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  isValidAdMobPlatform,
  isValidAdMobFormat,
  isValidAdMobPlacement,
  isValidAdMobEnvironment,
  isValidAdMobAdUnitId,
  isFormatPlacementCompatible,
  bumpAdMobConfigVersion,
  invalidateAdMobCaches,
  ADMOB_FORMATS,
  ADMOB_PLACEMENTS,
  ADMOB_ENVIRONMENTS,
  type AdMobPlatform,
  type AdMobFormat,
  type AdMobPlacement,
  type AdMobEnvironment,
} from "@/lib/admob/manager";

/**
 * AdMob Ad Units — CRUD API.
 * All endpoints require requireAdmin().
 */

import { toDTO, type AdMobAdUnitDTO } from "./route-helpers";

export { AdMobAdUnitDTO };

/**
 * GET /api/v1/admin/admob/units?platform=android&search=&status=&placement=&format=
 * Lists all ad units (active + inactive). ADMIN-only.
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  await recordAudit({
    adminId: admin.id,
    action: "admin.admob.units.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const url = new URL(req.url);
  const search = url.searchParams.get("search")?.trim() ?? "";
  const status = url.searchParams.get("status");
  const platformFilter = url.searchParams.get("platform")?.toUpperCase();
  const placementFilter = url.searchParams.get("placement");
  const formatFilter = url.searchParams.get("format");

  const where: Record<string, unknown> = {};
  if (search) {
    where.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { description: { contains: search, mode: "insensitive" } },
      { adUnitId: { contains: search } },
    ];
  }
  if (status === "active") where.active = true;
  else if (status === "inactive") where.active = false;
  if (platformFilter && isValidAdMobPlatform(platformFilter)) where.platform = platformFilter;
  if (placementFilter && isValidAdMobPlacement(placementFilter)) where.placement = placementFilter;
  if (formatFilter && isValidAdMobFormat(formatFilter)) where.format = formatFilter;

  const rows = await db.adMobAdUnit.findMany({
    where,
    orderBy: [{ platform: "asc" }, { placement: "asc" }, { priority: "asc" }, { createdAt: "desc" }],
  });

  return ok({ units: rows.map(toDTO) });
});

/**
 * POST /api/v1/admin/admob/units
 * Creates a new ad unit. ADMIN-only. Validates all fields (spec §28 + §54).
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    name?: string;
    description?: string;
    platform?: string;
    adUnitId?: string;
    format?: string;
    placement?: string;
    priority?: number;
    active?: boolean;
    environment?: string;
    fallbackAdUnitId?: string;
  }>(req);

  // Validate required fields.
  if (typeof body.name !== "string" || body.name.trim().length < 2 || body.name.trim().length > 100) {
    return badRequest("Name must be 2-100 characters.");
  }
  if (!body.platform || !isValidAdMobPlatform(body.platform)) {
    return badRequest("platform must be 'ANDROID' or 'IOS'.");
  }
  if (typeof body.adUnitId !== "string" || !isValidAdMobAdUnitId(body.adUnitId)) {
    return badRequest('Ad Unit ID must be "ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ".');
  }
  if (typeof body.format !== "string" || !isValidAdMobFormat(body.format)) {
    return badRequest(`format must be one of: ${ADMOB_FORMATS.join(", ")}.`);
  }
  if (typeof body.placement !== "string" || !isValidAdMobPlacement(body.placement)) {
    return badRequest(`placement must be one of: ${Object.keys(ADMOB_PLACEMENTS).join(", ")}.`);
  }

  // Validate format-placement compatibility (spec §28).
  if (!isFormatPlacementCompatible(body.format as AdMobFormat, body.placement as AdMobPlacement)) {
    return badRequest(`Format "${body.format}" is not compatible with placement "${body.placement}".`);
  }

  if (body.priority !== undefined) {
    if (typeof body.priority !== "number" || body.priority < 1 || body.priority > 100) {
      return badRequest("priority must be 1-100.");
    }
  }

  const env = body.environment ?? "ALL";
  if (!isValidAdMobEnvironment(env)) {
    return badRequest(`environment must be one of: ${ADMOB_ENVIRONMENTS.join(", ")}.`);
  }

  const platform = body.platform as AdMobPlatform;
  const format = body.format as AdMobFormat;
  const placement = body.placement as AdMobPlacement;

  // Check for duplicate (same platform + adUnitId).
  const dup = await db.adMobAdUnit.findFirst({
    where: { platform, adUnitId: body.adUnitId!.trim() },
    select: { id: true, name: true },
  });

  const created = await db.adMobAdUnit.create({
    data: {
      name: body.name.trim(),
      description: typeof body.description === "string" ? body.description.trim().slice(0, 500) : null,
      platform,
      adUnitId: body.adUnitId!.trim(),
      format,
      placement,
      priority: typeof body.priority === "number" ? body.priority : 10,
      active: typeof body.active === "boolean" ? body.active : true,
      environment: env as AdMobEnvironment,
      fallbackAdUnitId: typeof body.fallbackAdUnitId === "string" ? body.fallbackAdUnitId.trim() || null : null,
    },
  });

  invalidateAdMobCaches();
  await bumpAdMobConfigVersion(admin.id);

  await recordAudit({
    adminId: admin.id,
    action: "admin.admob.units.create",
    targetType: "admob_ad_unit",
    targetId: created.id,
    metadata: {
      name: created.name,
      platform: created.platform,
      adUnitId: created.adUnitId,
      format: created.format,
      placement: created.placement,
      duplicateWarning: dup ? `Existing unit "${dup.name}" (${dup.id}) has the same platform+adUnitId.` : undefined,
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ unit: toDTO(created), duplicateWarning: dup ? dup.name : null });
});
