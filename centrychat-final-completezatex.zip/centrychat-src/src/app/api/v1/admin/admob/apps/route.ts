import { apiHandler, ok, badRequest, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  isValidAdMobPlatform,
  isValidAdMobAppId,
  ADMOB_PLATFORMS,
  bumpAdMobConfigVersion,
  invalidateAdMobCaches,
  type AdMobPlatform,
} from "@/lib/admob/manager";

/**
 * AdMob Applications — Android + iOS app settings.
 *
 * GET /api/v1/admin/admob/apps — list both apps.
 * PUT /api/v1/admin/admob/apps — update one or both apps.
 */

interface AdMobAppDTO {
  id: string;
  platform: string;
  appName: string;
  packageName: string | null;
  admobAppId: string;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

function toDTO(row: {
  id: string;
  platform: string;
  appName: string;
  packageName: string | null;
  admobAppId: string;
  enabled: boolean;
  createdAt: Date;
  updatedAt: Date;
}): AdMobAppDTO {
  return {
    ...row,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

/**
 * GET /api/v1/admin/admob/apps
 * Returns both the Android + iOS AdMobApp rows. If a row doesn't exist
 * yet (first time), it's created with defaults (empty admobAppId, disabled).
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  await recordAudit({
    adminId: admin.id,
    action: "admin.admob.apps.read",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  // Ensure both platform rows exist (upsert with defaults).
  for (const platform of ADMOB_PLATFORMS) {
    await db.adMobApp.upsert({
      where: { platform },
      create: { platform },
      update: {},
    });
  }

  const apps = await db.adMobApp.findMany({
    orderBy: { platform: "asc" },
  });

  return ok({ apps: apps.map(toDTO) });
});

/**
 * PUT /api/v1/admin/admob/apps
 * Updates one app (identified by `platform` in the body).
 *
 * Request body:
 *   {
 *     platform: "ANDROID" | "IOS",
 *     appName?: string,
 *     packageName?: string,
 *     admobAppId?: string,  // validated against ADMOB_APP_ID_REGEX
 *     enabled?: boolean
 *   }
 */
export const PUT = apiHandler(async (req) => {
  const admin = await requireAdmin();
  const body = await parseJsonBody<{
    platform?: string;
    appName?: string;
    packageName?: string;
    admobAppId?: string;
    enabled?: boolean;
  }>(req);

  if (!body.platform || !isValidAdMobPlatform(body.platform)) {
    return badRequest("platform must be 'ANDROID' or 'IOS'.");
  }
  const platform = body.platform as AdMobPlatform;

  // Validate admobAppId if provided.
  if (body.admobAppId !== undefined) {
    const trimmed = (body.admobAppId ?? "").trim();
    if (!isValidAdMobAppId(trimmed)) {
      return badRequest(
        'Invalid AdMob App ID format. Expected "ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY" or empty.'
      );
    }
    body.admobAppId = trimmed;
  }

  // Build the update data — only fields that were provided.
  const data: Record<string, unknown> = {};
  if (body.appName !== undefined) data.appName = String(body.appName).slice(0, 200);
  if (body.packageName !== undefined) data.packageName = String(body.packageName).slice(0, 200) || null;
  if (body.admobAppId !== undefined) data.admobAppId = body.admobAppId;
  if (body.enabled !== undefined) data.enabled = Boolean(body.enabled);

  // Upsert — the row may not exist yet (first time configuring this platform).
  const updated = await db.adMobApp.upsert({
    where: { platform },
    create: {
      platform,
      appName: (data.appName as string) ?? "",
      packageName: (data.packageName as string | null) ?? null,
      admobAppId: (data.admobAppId as string) ?? "",
      enabled: (data.enabled as boolean) ?? false,
    },
    update: data,
  });

  invalidateAdMobCaches();
  await bumpAdMobConfigVersion(admin.id);

  await recordAudit({
    adminId: admin.id,
    action: "admin.admob.apps.update",
    targetType: "admob_app",
    targetId: updated.id,
    metadata: { platform, updatedFields: Object.keys(data) },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ app: toDTO(updated) });
});
