import { apiHandler, ok, badRequest, notFound, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  isValidAdMobFormat,
  isValidAdMobPlacement,
  isValidAdMobEnvironment,
  isValidAdMobAdUnitId,
  isFormatPlacementCompatible,
  bumpAdMobConfigVersion,
  invalidateAdMobCaches,
  type AdMobFormat,
  type AdMobPlacement,
  type AdMobEnvironment,
} from "@/lib/admob/manager";

/**
 * GET /api/v1/admin/admob/units/:id
 * Get a single ad unit by ID. ADMIN-only.
 */
export const GET = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return notFound("Ad unit not found.");

  await recordAudit({
    adminId: admin.id,
    action: "admin.admob.units.read",
    targetType: "admob_ad_unit",
    targetId: id,
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const unit = await db.adMobAdUnit.findUnique({ where: { id } });
  if (!unit) return notFound("Ad unit not found.");

  const { toDTO } = await import("../route-helpers");
  return ok({ unit: toDTO(unit) });
});

/**
 * PATCH /api/v1/admin/admob/units/:id
 * Update an existing ad unit. ADMIN-only. Partial update.
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return notFound("Ad unit not found.");

  const existing = await db.adMobAdUnit.findUnique({
    where: { id },
    select: { id: true, name: true, platform: true, format: true, placement: true },
  });
  if (!existing) return notFound("Ad unit not found.");

  const body = await parseJsonBody<{
    name?: string;
    description?: string;
    adUnitId?: string;
    format?: string;
    placement?: string;
    priority?: number;
    active?: boolean;
    environment?: string;
    fallbackAdUnitId?: string;
  }>(req);

  const data: Record<string, unknown> = {};

  if (body.name !== undefined) {
    if (typeof body.name !== "string" || body.name.trim().length < 2 || body.name.trim().length > 100) {
      return badRequest("Name must be 2-100 characters.");
    }
    data.name = body.name.trim();
  }
  if (body.description !== undefined) {
    if (typeof body.description !== "string") return badRequest("Description must be a string.");
    data.description = body.description.trim().slice(0, 500) || null;
  }
  if (body.adUnitId !== undefined) {
    if (typeof body.adUnitId !== "string" || !isValidAdMobAdUnitId(body.adUnitId)) {
      return badRequest('Ad Unit ID must be "ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ".');
    }
    data.adUnitId = body.adUnitId.trim();
  }
  if (body.format !== undefined) {
    if (typeof body.format !== "string" || !isValidAdMobFormat(body.format)) {
      return badRequest("Invalid format.");
    }
    data.format = body.format as AdMobFormat;
  }
  if (body.placement !== undefined) {
    if (typeof body.placement !== "string" || !isValidAdMobPlacement(body.placement)) {
      return badRequest("Invalid placement.");
    }
    data.placement = body.placement as AdMobPlacement;
  }
  // Validate format-placement compatibility when either changed.
  const finalFormat = (data.format as AdMobFormat) ?? (existing.format as AdMobFormat);
  const finalPlacement = (data.placement as AdMobPlacement) ?? (existing.placement as AdMobPlacement);
  if (!isFormatPlacementCompatible(finalFormat, finalPlacement)) {
    return badRequest(`Format "${finalFormat}" is not compatible with placement "${finalPlacement}".`);
  }

  if (body.priority !== undefined) {
    if (typeof body.priority !== "number" || body.priority < 1 || body.priority > 100) {
      return badRequest("priority must be 1-100.");
    }
    data.priority = body.priority;
  }
  if (body.active !== undefined) {
    if (typeof body.active !== "boolean") return badRequest("active must be boolean.");
    data.active = body.active;
  }
  if (body.environment !== undefined) {
    if (typeof body.environment !== "string" || !isValidAdMobEnvironment(body.environment)) {
      return badRequest("Invalid environment.");
    }
    data.environment = body.environment as AdMobEnvironment;
  }
  if (body.fallbackAdUnitId !== undefined) {
    data.fallbackAdUnitId = typeof body.fallbackAdUnitId === "string" ? (body.fallbackAdUnitId.trim() || null) : null;
  }

  const updated = await db.adMobAdUnit.update({
    where: { id },
    data,
  });

  invalidateAdMobCaches();
  await bumpAdMobConfigVersion(admin.id);

  await recordAudit({
    adminId: admin.id,
    action: "admin.admob.units.update",
    targetType: "admob_ad_unit",
    targetId: id,
    metadata: { updatedFields: Object.keys(data) },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  const { toDTO } = await import("../route-helpers");
  return ok({ unit: toDTO(updated) });
});

/**
 * DELETE /api/v1/admin/admob/units/:id
 * Delete an ad unit. ADMIN-only. Hard delete.
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id) return notFound("Ad unit not found.");

  const existing = await db.adMobAdUnit.findUnique({
    where: { id },
    select: { id: true, name: true, platform: true, placement: true },
  });
  if (!existing) return notFound("Ad unit not found.");

  await db.adMobAdUnit.delete({ where: { id } });
  invalidateAdMobCaches();
  await bumpAdMobConfigVersion(admin.id);

  await recordAudit({
    adminId: admin.id,
    action: "admin.admob.units.delete",
    targetType: "admob_ad_unit",
    targetId: id,
    metadata: { name: existing.name, platform: existing.platform, placement: existing.placement },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ deleted: true, id });
});
