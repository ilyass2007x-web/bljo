/**
 * Shared helpers for the AdMob ad unit admin routes.
 *
 * Both /api/v1/admin/admob/units/route.ts (GET list + POST create) and
 * /api/v1/admin/admob/units/[id]/route.ts (GET + PATCH + DELETE) use the
 * same toDTO mapper. Extracting it here avoids circular imports.
 */

interface AdMobAdUnitRow {
  id: string;
  name: string;
  description: string | null;
  platform: string;
  adUnitId: string;
  format: string;
  placement: string;
  priority: number;
  active: boolean;
  environment: string;
  fallbackAdUnitId: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface AdMobAdUnitDTO {
  id: string;
  name: string;
  description: string | null;
  platform: string;
  adUnitId: string;
  format: string;
  placement: string;
  priority: number;
  active: boolean;
  environment: string;
  fallbackAdUnitId: string | null;
  createdAt: string;
  updatedAt: string;
}

export function toDTO(row: AdMobAdUnitRow): AdMobAdUnitDTO {
  return {
    ...row,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}
