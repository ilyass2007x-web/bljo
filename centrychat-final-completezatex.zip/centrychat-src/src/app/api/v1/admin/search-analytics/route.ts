import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { cacheGetOrSet } from "@/lib/cache";
import { logger } from "@/lib/logging";

/**
 * GET /api/v1/admin/search-analytics?range=24h|7d|30d|90d|1y
 * --------------------------------------------------------------
 * Smart Search Analytics (spec §15-§22 — PHASE 7).
 *
 * Returns:
 *   - Search volume: total (24h/7d/30d), daily buckets for trend chart.
 *   - Top searched queries (top 20 in range).
 *   - Zero-result queries (top 20 in range — spec §17).
 *   - Search success rate (hadResults vs !hadResults — spec §18, handles zero safely).
 *   - Average result count (search quality — spec §18).
 *   - Trending searches (last 24h, top 10).
 *   - CTR: NOT tracked yet → returns null (spec §19: "Where data exists").
 *   - Filter usage: NOT tracked yet → returns null (spec §20).
 *
 * SECURITY (spec §23, §26):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - All data is aggregated — no individual user IDs exposed.
 *
 * PERFORMANCE (spec §25):
 *   - All counts via groupBy/count (no N+1).
 *   - Daily buckets via timestamp-only fetch + JS aggregation.
 *   - 30s cache.
 *   - All queries time-bounded.
 */

type Range = "24h" | "7d" | "30d" | "90d" | "1y";

function getRangeStart(range: Range): Date {
  const now = Date.now();
  switch (range) {
    case "24h": return new Date(now - 24 * 60 * 60 * 1000);
    case "7d":  return new Date(now - 7 * 24 * 60 * 60 * 1000);
    case "30d": return new Date(now - 30 * 24 * 60 * 60 * 1000);
    case "90d": return new Date(now - 90 * 24 * 60 * 60 * 1000);
    case "1y":  return new Date(now - 365 * 24 * 60 * 60 * 1000);
    default:    return new Date(now - 30 * 24 * 60 * 60 * 1000);
  }
}

function bucketByDay(rows: { createdAt: Date }[]): { date: string; count: number }[] {
  const buckets = new Map<string, number>();
  for (const row of rows) {
    const key = row.createdAt.toISOString().slice(0, 10);
    buckets.set(key, (buckets.get(key) ?? 0) + 1);
  }
  return Array.from(buckets.entries())
    .map(([date, count]) => ({ date, count }))
    .sort((a, b) => a.date.localeCompare(b.date));
}

export const GET = apiHandler(async (req) => {
  await requireAdmin();

  const url = new URL(req.url);
  const rangeParam = (url.searchParams.get("range") ?? "7d") as Range;
  const range = (["24h", "7d", "30d", "90d", "1y"] as Range[]).includes(rangeParam) ? rangeParam : "7d";
  const rangeStart = getRangeStart(range);

  const cacheKey = `admin:search-analytics:${range}`;
  const TTL = 30;

  const result = await cacheGetOrSet(cacheKey, TTL, async () => {
    // ── Parallel queries ─────────────────────────────────────────
    const [
      topSearchedRows,
      zeroResultRows,
      trendingRows,
      volumeInRange,
      successCount,
      failCount,
      avgResult,
      timestamps,
    ] = await Promise.all([
      // Top searched terms in range (top 20).
      db.searchQueryLog.groupBy({
        by: ["query"],
        where: { createdAt: { gte: rangeStart } },
        _count: { query: true },
        orderBy: { _count: { query: "desc" } },
        take: 20,
      }),
      // Zero-result queries in range (top 20 — spec §17).
      db.searchQueryLog.groupBy({
        by: ["query"],
        where: { hadResults: false, createdAt: { gte: rangeStart } },
        _count: { query: true },
        orderBy: { _count: { query: "desc" } },
        take: 20,
      }),
      // Trending searches in last 24h (top 10).
      db.searchQueryLog.groupBy({
        by: ["query"],
        where: { createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
        _count: { query: true },
        orderBy: { _count: { query: "desc" } },
        take: 10,
      }),
      // Total search volume in range.
      db.searchQueryLog.count({ where: { createdAt: { gte: rangeStart } } }),
      // Successful searches (hadResults = true).
      db.searchQueryLog.count({ where: { hadResults: true, createdAt: { gte: rangeStart } } }),
      // Failed searches (hadResults = false).
      db.searchQueryLog.count({ where: { hadResults: false, createdAt: { gte: rangeStart } } }),
      // Average result count (search quality — spec §18).
      db.searchQueryLog.aggregate({
        where: { createdAt: { gte: rangeStart } },
        _avg: { resultCount: true },
      }),
      // Daily volume buckets for trend chart (spec §21).
      db.searchQueryLog.findMany({
        where: { createdAt: { gte: rangeStart } },
        select: { createdAt: true },
        take: 50000, // cap for memory safety
      }),
    ]);

    // ── Format ────────────────────────────────────────────────────
    const topSearched = topSearchedRows.map(r => ({ query: r.query, count: r._count.query }));
    const zeroResult = zeroResultRows.map(r => ({ query: r.query, count: r._count.query }));
    const trending = trendingRows.map(r => ({ query: r.query, count: r._count.query }));

    // Success rate (spec §18 — handles zero safely, never NaN/Infinity).
    const successRate = (successCount + failCount) > 0
      ? Math.round((successCount / (successCount + failCount)) * 1000) / 10
      : 0;

    return {
      range,
      volume: {
        total: volumeInRange,
        successful: successCount,
        failed: failCount,
        successRate,
        avgResultCount: avgResult._avg.resultCount != null
          ? Math.round(avgResult._avg.resultCount * 10) / 10
          : 0,
      },
      topSearched,
      zeroResult,
      trending,
      dailyBuckets: bucketByDay(timestamps),
      // CTR not tracked yet (spec §19: "Where data exists" — no click tracking yet).
      ctr: null,
      // Filter usage not tracked yet (spec §20 — SearchQueryLog doesn't have searchType field).
      filterUsage: null,
    };
  });

  return ok({ analytics: result });
});
