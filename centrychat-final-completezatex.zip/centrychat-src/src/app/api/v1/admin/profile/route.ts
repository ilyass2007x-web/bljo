import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getUserInterestSummary } from "@/lib/feed/interest-profile";

/**
 * GET /api/v1/admin/profile?userId=<id>
 *
 * Returns a summary of a user's recommendation interest profile for
 * admin/debug inspection (spec §24).
 *
 * SECURITY:
 *   - Requires ADMIN or SUPER_ADMIN role (server-side verified).
 *   - Never exposed publicly — this endpoint is admin-only.
 *   - Returns only aggregated interest scores, never individual interaction
 *     rows (those stay in the ContentInteraction table for internal use).
 *
 * Response shape:
 *   {
 *     topTopics: [{ topic: "Football", score: 0.91 }, ...],
 *     topAuthors: [{ author: "John Doe", score: 0.81 }, ...],
 *     topLanguages: [{ language: "en", score: 0.88 }, ...],
 *     totalInteractions: 142
 *   }
 *
 * This is a DEVELOPMENT/DEBUG tool — not intended for end-user consumption.
 * The data helps admins verify that the personalization system is working
 * correctly (different users have different profiles, interactions are
 * being tracked, decay is applied, etc.).
 */
export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin; // admin is verified, not used further

  const url = new URL(req.url);
  const userId = url.searchParams.get("userId");

  if (!userId || typeof userId !== "string") {
    return badRequest("userId query parameter is required");
  }

  const summary = await getUserInterestSummary(userId);

  return ok(summary);
});
