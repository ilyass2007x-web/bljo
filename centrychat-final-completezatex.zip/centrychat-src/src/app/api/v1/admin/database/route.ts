import { apiHandler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db, pingDatabase, getDatabaseProvider } from "@/lib/database";

export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();
  void admin;

  const ping = await pingDatabase();
  const userCount = await db.user.count();
  const messageCount = await db.message.count();

  // Migration status: for SQLite we can't query _prisma_migrations easily; report schema sync.
  let migrationCount = 0;
  try {
    const rows = await db.$queryRaw<{ count: number }[]>`SELECT COUNT(*) as count FROM _prisma_migrations`;
    migrationCount = Number((rows[0] as { count: number })?.count ?? 0);
  } catch {
    // SQLite without migrations table (db:push) — fine.
  }

  return ok({
    database: {
      provider: getDatabaseProvider(),
      connected: ping.ok,
      latencyMs: ping.latencyMs,
      error: ping.error ?? null,
      // We never expose DATABASE_URL or credentials.
      urlHint: process.env.DATABASE_URL ? "[configured]" : "[missing]",
      tables: {
        users: userCount,
        messages: messageCount,
      },
      migrations: {
        applied: migrationCount,
        method: migrationCount > 0 ? "prisma-migrate" : "prisma-db-push",
      },
    },
  });
});
