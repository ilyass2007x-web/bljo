import { apiHandler, ok, badRequest, notFound, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { getSetting } from "@/lib/settings";
import {
  DEFAULT_RANKING_WEIGHTS,
  type RankingWeights,
  type RankableContent,
  type ScoreComponents,
  scoreAndRankContent,
} from "@/lib/content/ranking";

/**
 * POST /api/v1/admin/algorithm/simulate
 * --------------------------------------
 * Algorithm Simulation tool (spec §17, §18, §19).
 *
 * Allows an admin to:
 *   - Select a specific Post or Article by ID + type.
 *   - Apply a hypothetical weight configuration (or use current).
 *   - See the full score breakdown (recency, engagement, velocity,
 *     quality, etc.) — the "WHY" behind the ranking.
 *   - Compare "Current Algorithm" vs "New Configuration" scores.
 *
 * Request body:
 *   { contentId: string, contentType: "post" | "article", weights?: Partial<RankingWeights> }
 *
 * SECURITY (spec §30):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Server-side authorization.
 *
 * Response: {
 *   current: { score, components },
 *   new: { score, components },
 *   content: { ...preview data },
 *   delta: number (new - current)
 * }
 */
export const POST = apiHandler(async (req) => {
  await requireAdmin();

  const body = await parseJsonBody<{
    contentId?: string;
    contentType?: string;
    weights?: Record<string, number>;
  }>(req);

  if (!body.contentId || !body.contentType) {
    return badRequest("contentId and contentType are required");
  }
  if (body.contentType !== "post" && body.contentType !== "article") {
    return badRequest("contentType must be 'post' or 'article'");
  }

  // ── Load current effective weights ──────────────────────────────
  const currentWeights = { ...DEFAULT_RANKING_WEIGHTS };
  const keys = Object.keys(currentWeights) as (keyof RankingWeights)[];
  await Promise.all(
    keys.map(async (k) => {
      const v = await getSetting(`algorithm.weight.${k}`);
      if (v != null && !Number.isNaN(Number(v))) {
        (currentWeights as any)[k] = Number(v);
      }
    })
  );

  // ── Build new weights from the request (overlay on defaults) ───
  const newWeights = { ...currentWeights };
  if (body.weights) {
    for (const [k, v] of Object.entries(body.weights)) {
      if (k in DEFAULT_RANKING_WEIGHTS && typeof v === "number" && Number.isFinite(v) && v >= -1000 && v <= 1000) {
        (newWeights as any)[k] = v;
      }
    }
  }

  // ── Fetch the content item + its engagement counts ──────────────
  let rankable: RankableContent | null = null;

  if (body.contentType === "post") {
    const post = await db.post.findUnique({
      where: { id: body.contentId },
      select: {
        id: true, content: true, createdAt: true, authorId: true,
        _count: { select: { likes: true, comments: true, views: true } },
      },
    });
    if (!post) return notFound("Post not found");

    const [shareCount] = await Promise.all([
      db.postInteraction.count({ where: { postId: post.id, type: "SHARE" } }),
    ]);

    rankable = {
      type: "post",
      id: post.id,
      authorId: post.authorId,
      titleOrContent: post.content,
      timestamp: post.createdAt,
      counts: { likes: post._count.likes, comments: post._count.comments, views: post._count.views, shares: shareCount },
    };
  } else {
    const article = await db.article.findUnique({
      where: { id: body.contentId },
      select: {
        id: true, title: true, excerpt: true, content: true, coverImage: true,
        videoUrl: true, status: true, publishedAt: true, readingTime: true, authorId: true, createdAt: true,
        _count: { select: { likes: true, comments: true, views: true } },
      },
    });
    if (!article) return notFound("Article not found");

    const [shareCount] = await Promise.all([
      db.articleInteraction.count({ where: { articleId: article.id, type: "SHARE" } }),
    ]);

    rankable = {
      type: "article",
      id: article.id,
      authorId: article.authorId,
      titleOrContent: article.title,
      excerpt: article.excerpt,
      contentLength: article.content.length,
      hasCoverImage: !!article.coverImage,
      hasVideo: !!article.videoUrl,
      readingTime: article.readingTime,
      timestamp: article.publishedAt ?? article.createdAt,
      counts: { likes: article._count.likes, comments: article._count.comments, views: article._count.views, shares: shareCount },
    };
  }

  // ── Score with both weight configurations ───────────────────────
  // We use a dummy user context (no follows — the simulation shows
  // the raw algorithm score without personalization).
  const dummyCtx = { userId: "simulation", followedAuthorIds: new Set<string>() };

  // Score with current weights.
  const currentScored = scoreAndRankContent([rankable], dummyCtx, 1, currentWeights);
  const currentResult = currentScored[0];

  // Score with new weights.
  const newScored = scoreAndRankContent([rankable], dummyCtx, 1, newWeights);
  const newResult = newScored[0];

  const delta = (newResult?.score ?? 0) - (currentResult?.score ?? 0);

  return ok({
    content: {
      id: rankable.id,
      type: rankable.type,
      preview: rankable.type === "post" ? rankable.titleOrContent.slice(0, 200) : rankable.titleOrContent,
    },
    current: {
      score: Math.round((currentResult?.score ?? 0) * 10) / 10,
      components: formatComponents(currentResult?.components),
    },
    new: {
      score: Math.round((newResult?.score ?? 0) * 10) / 10,
      components: formatComponents(newResult?.components),
    },
    delta: Math.round(delta * 10) / 10,
    currentWeights,
    newWeights,
    hasChanges: JSON.stringify(currentWeights) !== JSON.stringify(newWeights),
  });
});

function formatComponents(c?: ScoreComponents): Record<string, number> {
  if (!c) return {};
  const result: Record<string, number> = {};
  for (const [k, v] of Object.entries(c)) {
    result[k] = Math.round((v as number) * 10) / 10;
  }
  return result;
}
