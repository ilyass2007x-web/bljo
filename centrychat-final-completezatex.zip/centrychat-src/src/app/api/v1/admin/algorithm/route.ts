import { apiHandler, ok, badRequest, parseJsonBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { getSetting, setSetting } from "@/lib/settings";
import {
  DEFAULT_RANKING_WEIGHTS,
  type RankingWeights,
} from "@/lib/content/ranking";

/**
 * GET /api/v1/admin/algorithm
 * ----------------------------
 * Admin algorithm status + top content overview (spec §26, §27, §28).
 *
 * Returns:
 *   - Current ranking weights (effective, after admin overrides)
 *   - Default weights (for "reset to defaults" UI)
 *   - Top content by engagement (last 7 days)
 *   - Trending content (highest velocity, last 48h)
 *   - Most active creators (most posts + articles, last 30 days)
 *   - Most followed users
 *   - Engagement statistics (totals + averages)
 *
 * SECURITY (spec §26, §27): ADMIN/SUPER_ADMIN only. The middleware
 * `requireAdmin` enforces this. Normal users get 403.
 *
 * Performance: 6 parallel DB queries (no N+1). All use _count
 * aggregation + groupBy for O(1) per-result-row cost.
 */

export const GET = apiHandler(async () => {
  const admin = await requireAdmin();

  // ── Current ranking weights (with admin overrides applied) ────────
  const currentWeights = { ...DEFAULT_RANKING_WEIGHTS };
  const keys = Object.keys(currentWeights) as (keyof RankingWeights)[];
  await Promise.all(
    keys.map(async (k) => {
      const v = await getSetting(`algorithm.weight.${k}`);
      if (v != null && !Number.isNaN(Number(v))) {
        (currentWeights as any)[k] = Number(v);
      }
    })
  );

  // ── Time windows ───────────────────────────────────────────────────
  const now = new Date();
  const last48h = new Date(now.getTime() - 48 * 60 * 60 * 1000);
  const last7d = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const last30d = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  // ── Parallel queries for the dashboard ─────────────────────────────
  const [
    topPosts7d,
    topArticles7d,
    trendingPosts48h,
    trendingArticles48h,
    topCreators,
    mostFollowed,
    totals,
  ] = await Promise.all([
    // Top posts by engagement in the last 7 days (likes + comments + views).
    db.post.findMany({
      where: { createdAt: { gte: last7d } },
      orderBy: { createdAt: "desc" },
      take: 100,
      select: {
        id: true, content: true, createdAt: true,
        authorId: true,
        author: { select: { id: true, fullName: true, username: true } },
        _count: { select: { likes: true, comments: true, views: true } },
      },
    }),
    // Top articles by engagement in the last 7 days.
    db.article.findMany({
      where: { status: "PUBLISHED", publishedAt: { gte: last7d } },
      orderBy: { publishedAt: "desc" },
      take: 100,
      select: {
        id: true, title: true, publishedAt: true,
        authorId: true,
        author: { select: { id: true, fullName: true, username: true } },
        _count: { select: { likes: true, comments: true, views: true } },
      },
    }),
    // Trending posts in the last 48h (most engagement velocity).
    db.post.findMany({
      where: { createdAt: { gte: last48h } },
      orderBy: { createdAt: "desc" },
      take: 50,
      select: {
        id: true, content: true, createdAt: true,
        authorId: true,
        author: { select: { id: true, fullName: true, username: true } },
        _count: { select: { likes: true, comments: true, views: true } },
      },
    }),
    // Trending articles in the last 48h.
    db.article.findMany({
      where: { status: "PUBLISHED", publishedAt: { gte: last48h } },
      orderBy: { publishedAt: "desc" },
      take: 50,
      select: {
        id: true, title: true, publishedAt: true,
        authorId: true,
        author: { select: { id: true, fullName: true, username: true } },
        _count: { select: { likes: true, comments: true, views: true } },
      },
    }),
    // Most active creators (most posts + articles in the last 30 days).
    db.user.findMany({
      where: { status: "ACTIVE" },
      take: 100,
      select: {
        id: true, fullName: true, username: true,
        isVerified: true, role: true,
        _count: {
          select: {
            posts: { where: { createdAt: { gte: last30d } } },
            articles: { where: { status: "PUBLISHED", publishedAt: { gte: last30d } } },
            followers: true,
          },
        },
      },
    }),
    // Most followed users (top 50).
    db.user.findMany({
      where: { status: "ACTIVE" },
      take: 50,
      select: {
        id: true, fullName: true, username: true,
        isVerified: true, role: true,
        _count: { select: { followers: true } },
      },
    }),
    // Totals for the dashboard.
    Promise.all([
      db.post.count(),
      db.article.count({ where: { status: "PUBLISHED" } }),
      db.user.count({ where: { status: "ACTIVE" } }),
      db.postLike.count(),
      db.postComment.count(),
      db.articleLike.count(),
      db.articleComment.count(),
    ]),
  ]);

  // ── Compute engagement scores for the "top content" lists ──────────
  // Score = likes + comments*2 + views*0.1 (lightweight engagement sum).
  // We don't use the full ranking engine here — admin just needs a
  // quick "what's hot" view, not a personalized feed.
  const quickEngagement = (c: { _count: { likes: number; comments: number; views: number } }) =>
    c._count.likes + c._count.comments * 2 + c._count.views * 0.1;

  const topPosts = topPosts7d
    .map((p) => ({
      id: p.id,
      type: "post" as const,
      title: p.content.slice(0, 100),
      author: p.author,
      createdAt: p.createdAt.toISOString(),
      engagement: quickEngagement(p),
      counts: {
        likes: p._count.likes,
        comments: p._count.comments,
        views: p._count.views,
      },
    }))
    .sort((a, b) => b.engagement - a.engagement)
    .slice(0, 10);

  const topArticles = topArticles7d
    .map((a) => ({
      id: a.id,
      type: "article" as const,
      title: a.title,
      author: a.author,
      publishedAt: a.publishedAt?.toISOString() ?? null,
      engagement: quickEngagement(a),
      counts: {
        likes: a._count.likes,
        comments: a._count.comments,
        views: a._count.views,
      },
    }))
    .sort((a, b) => b.engagement - a.engagement)
    .slice(0, 10);

  const trendingPosts = trendingPosts48h
    .map((p) => {
      const hoursOld = Math.max(0.1, (now.getTime() - p.createdAt.getTime()) / (60 * 60 * 1000));
      const engagement = p._count.likes + p._count.comments + p._count.views;
      return {
        id: p.id,
        type: "post" as const,
        title: p.content.slice(0, 100),
        author: p.author,
        createdAt: p.createdAt.toISOString(),
        hoursOld: Math.round(hoursOld * 10) / 10,
        engagement,
        velocity: engagement / hoursOld, // engagements per hour
        counts: {
          likes: p._count.likes,
          comments: p._count.comments,
          views: p._count.views,
        },
      };
    })
    .sort((a, b) => b.velocity - a.velocity)
    .slice(0, 10);

  const trendingArticles = trendingArticles48h
    .map((a) => {
      const ts = a.publishedAt ?? now;
      const hoursOld = Math.max(0.1, (now.getTime() - ts.getTime()) / (60 * 60 * 1000));
      const engagement = a._count.likes + a._count.comments + a._count.views;
      return {
        id: a.id,
        type: "article" as const,
        title: a.title,
        author: a.author,
        publishedAt: a.publishedAt?.toISOString() ?? null,
        hoursOld: Math.round(hoursOld * 10) / 10,
        engagement,
        velocity: engagement / hoursOld,
        counts: {
          likes: a._count.likes,
          comments: a._count.comments,
          views: a._count.views,
        },
      };
    })
    .sort((a, b) => b.velocity - a.velocity)
    .slice(0, 10);

  // Most active creators: sort by (posts + articles in last 30d).
  const creators = topCreators
    .map((u) => ({
      id: u.id,
      fullName: u.fullName,
      username: u.username,
      isVerified: u.isVerified,
      role: u.role,
      posts30d: u._count.posts,
      articles30d: u._count.articles,
      followers: u._count.followers,
      activity30d: u._count.posts + u._count.articles,
    }))
    .sort((a, b) => b.activity30d - a.activity30d)
    .slice(0, 10);

  const mostFollowedUsers = mostFollowed
    .map((u) => ({
      id: u.id,
      fullName: u.fullName,
      username: u.username,
      isVerified: u.isVerified,
      role: u.role,
      followers: u._count.followers,
    }))
    .sort((a, b) => b.followers - a.followers);

  const [
    totalPosts, totalArticles, totalUsers,
    totalPostLikes, totalPostComments,
    totalArticleLikes, totalArticleComments,
  ] = totals;

  return ok({
    weights: {
      current: currentWeights,
      defaults: DEFAULT_RANKING_WEIGHTS,
      hasOverrides: JSON.stringify(currentWeights) !== JSON.stringify(DEFAULT_RANKING_WEIGHTS),
    },
    topContent: {
      posts: topPosts,
      articles: topArticles,
    },
    trending: {
      posts: trendingPosts,
      articles: trendingArticles,
    },
    creators,
    mostFollowed: mostFollowedUsers,
    stats: {
      totals: {
        posts: totalPosts,
        publishedArticles: totalArticles,
        activeUsers: totalUsers,
        postLikes: totalPostLikes,
        postComments: totalPostComments,
        articleLikes: totalArticleLikes,
        articleComments: totalArticleComments,
      },
      // Averages (avoid division by zero).
      averages: {
        likesPerPost: totalPosts > 0 ? Math.round((totalPostLikes / totalPosts) * 10) / 10 : 0,
        commentsPerPost: totalPosts > 0 ? Math.round((totalPostComments / totalPosts) * 10) / 10 : 0,
        likesPerArticle: totalArticles > 0 ? Math.round((totalArticleLikes / totalArticles) * 10) / 10 : 0,
        commentsPerArticle: totalArticles > 0 ? Math.round((totalArticleComments / totalArticles) * 10) / 10 : 0,
      },
    },
    requestedBy: { id: admin.id, role: admin.role },
  });
});

/**
 * PATCH /api/v1/admin/algorithm
 * ------------------------------
 * Update ranking weights (spec §28 — "Algorithm Configuration").
 *
 * Request body: { weights: Partial<RankingWeights> }
 *   Only the keys present in the body are updated — others are unchanged.
 *   All values must be finite numbers; otherwise the request is rejected.
 *
 * SECURITY: ADMIN/SUPER_ADMIN only. Validated server-side.
 *
 * Response: { weights: RankingWeights } — the new effective weights.
 */
export const PATCH = apiHandler(async (req) => {
  const admin = await requireAdmin();

  const body = await parseJsonBody<{ weights?: Record<string, unknown> }>(req);
  if (!body.weights || typeof body.weights !== "object") {
    return badRequest("Missing 'weights' object in request body");
  }

  // Validate every key + value. Only known weight keys are accepted;
  // unknown keys are silently ignored (defense-in-depth).
  const validKeys = new Set(Object.keys(DEFAULT_RANKING_WEIGHTS));
  const updates: { key: string; value: number }[] = [];
  for (const [k, v] of Object.entries(body.weights)) {
    if (!validKeys.has(k)) continue;
    if (typeof v !== "number" || !Number.isFinite(v)) {
      return badRequest(`Invalid value for weight '${k}': must be a finite number`);
    }
    // Additional sanity bounds — reject extreme values (e.g. -1000 or 1e10).
    if (v < -1000 || v > 1000) {
      return badRequest(`Weight '${k}' out of bounds (must be between -1000 and 1000)`);
    }
    updates.push({ key: k, value: v });
  }

  // ── Save a BACKUP of the current weights before applying changes ─
  // (spec §21, §23 — safe rollout + rollback). The backup is stored
  // as JSON in `algorithm.weights.backup`. The rollback endpoint reads
  // this to restore the previous configuration.
  const backupWeights = { ...DEFAULT_RANKING_WEIGHTS };
  const backupKeys = Object.keys(backupWeights) as (keyof RankingWeights)[];
  await Promise.all(
    backupKeys.map(async (k) => {
      const v = await getSetting(`algorithm.weight.${k}`);
      if (v != null && !Number.isNaN(Number(v))) {
        (backupWeights as any)[k] = Number(v);
      }
    })
  );
  await setSetting("algorithm.weights.backup", JSON.stringify(backupWeights), admin.id);

  // ── Persist the updates ───────────────────────────────────────────
  await Promise.all(
    updates.map(({ key, value }) =>
      setSetting(`algorithm.weight.${key}`, String(value), admin.id)
    )
  );

  // Re-read the effective weights to return them.
  const currentWeights = { ...DEFAULT_RANKING_WEIGHTS };
  const keys = Object.keys(currentWeights) as (keyof RankingWeights)[];
  await Promise.all(
    keys.map(async (k) => {
      const v = await getSetting(`algorithm.weight.${k}`);
      if (v != null && !Number.isNaN(Number(v))) {
        (currentWeights as any)[k] = Number(v);
      }
    })
  );

  return ok({
    weights: currentWeights,
    updated: updates.map((u) => u.key),
  });
});

/**
 * DELETE /api/v1/admin/algorithm
 * ------------------------------
 * Reset all ranking weights to defaults (spec §28).
 *
 * Sets all `algorithm.weight.*` values to empty string, which the
 * loadRankingWeights helper treats as "no override" — so the ranking
 * engine falls back to DEFAULT_RANKING_WEIGHTS.
 *
 * SECURITY: ADMIN/SUPER_ADMIN only.
 *
 * Response: { weights: RankingWeights, reset: true }
 */
export const DELETE = apiHandler(async () => {
  const admin = await requireAdmin();

  const keys = Object.keys(DEFAULT_RANKING_WEIGHTS);
  await Promise.all(
    keys.map((k) => setSetting(`algorithm.weight.${k}`, "", admin.id))
  );

  return ok({
    weights: DEFAULT_RANKING_WEIGHTS,
    reset: true,
  });
});
