import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { getSetting, setSetting } from "@/lib/settings";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  DEFAULT_RANKING_WEIGHTS,
  type RankingWeights,
} from "@/lib/content/ranking";
import { logger } from "@/lib/logging";

/**
 * POST /api/v1/admin/algorithm/rollback
 * --------------------------------------
 * Rollback to the previous algorithm configuration (spec §23).
 *
 * Restores the weights that were active BEFORE the last activation.
 * Uses the PlatformSetting table:
 *   - `algorithm.weights.backup` — stores the previous weights as JSON.
 *   - When a PATCH activates new weights, the current weights are
 *     saved to `algorithm.weights.backup` before the new ones are applied.
 *   - This endpoint reads the backup + applies it.
 *
 * If no backup exists, resets to DEFAULT_RANKING_WEIGHTS.
 *
 * SECURITY (spec §30):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - Audit recorded (spec §31 — ALGORITHM_ROLLED_BACK).
 */
export const POST = apiHandler(async (req) => {
  const admin = await requireAdmin();

  // ── Load the current effective weights (to back them up) ────────
  const currentWeights = { ...DEFAULT_RANKING_WEIGHTS };
  const keys = Object.keys(currentWeights) as (keyof RankingWeights)[];
  await Promise.all(
    keys.map(async (k) => {
      const v = await getSetting(`algorithm.weight.${k}`);
      if (v != null && !Number.isNaN(Number(v))) {
        (currentWeights as any)[k] = Number(v);
      }
    })
  );

  // ── Load the backup weights (the previous configuration) ────────
  const backupJson = await getSetting("algorithm.weights.backup");
  let backupWeights: RankingWeights | null = null;

  if (backupJson) {
    try {
      const parsed = JSON.parse(backupJson);
      if (parsed && typeof parsed === "object") {
        // Validate the backup has the same keys.
        backupWeights = { ...DEFAULT_RANKING_WEIGHTS };
        for (const k of keys) {
          if (typeof parsed[k] === "number" && Number.isFinite(parsed[k])) {
            (backupWeights as any)[k] = parsed[k];
          }
        }
      }
    } catch {
      // Invalid backup JSON — fall through to defaults.
    }
  }

  const targetWeights = backupWeights ?? DEFAULT_RANKING_WEIGHTS;

  // ── Save the CURRENT weights as the new backup (for double-rollback) ─
  await setSetting("algorithm.weights.backup", JSON.stringify(currentWeights), admin.id);

  // ── Apply the backup weights ─────────────────────────────────────
  await Promise.all(
    keys.map((k) =>
      setSetting(`algorithm.weight.${k}`, String((targetWeights as any)[k]), admin.id)
    )
  );

  await recordAudit({
    adminId: admin.id,
    action: "admin.algorithm.rollback",
    metadata: {
      previousWeights: currentWeights,
      restoredWeights: targetWeights,
      hadBackup: backupWeights !== null,
    },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  logger.info("admin", "Algorithm rolled back", { adminId: admin.id, hadBackup: backupWeights !== null });

  return ok({
    weights: targetWeights,
    rolledBack: true,
    hadBackup: backupWeights !== null,
  });
});
