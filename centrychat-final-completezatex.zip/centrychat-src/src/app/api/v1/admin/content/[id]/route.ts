import { apiHandler, ok, notFound, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";

/**
 * GET /api/v1/admin/content/:id?type=post|article
 * ----------------------------------------------
 * Content detail view (spec §7, §13).
 *
 * Returns full content + engagement stats for a Post or Article.
 * The `type` query param determines which table to query.
 *
 * SECURITY (spec §19):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - No private info exposed beyond what's needed for admin management.
 */

export const GET = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Content not found.");

  const url = new URL(req.url);
  const type = url.searchParams.get("type");
  if (type !== "post" && type !== "article") {
    return badRequest("Type must be 'post' or 'article'");
  }

  if (type === "post") {
    const post = await db.post.findUnique({
      where: { id },
      select: {
        id: true, content: true, createdAt: true, updatedAt: true, authorId: true,
        author: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
        _count: { select: { likes: true, comments: true, views: true } },
      },
    });
    if (!post) return notFound("Post not found.");

    const [shareCount] = await Promise.all([
      db.postInteraction.count({ where: { postId: id, type: "SHARE" } }),
    ]);
    // Report count: the Report model doesn't support Post/Article reports
    // yet (spec §16). reportCount is 0 until moderation is extended.
    const reportCount = 0;

    const likes = post._count.likes;
    const comments = post._count.comments;
    const views = post._count.views;
    const engagementRate = views > 0
      ? Math.round(((likes + comments + shareCount) / views) * 1000) / 10
      : 0;

    await recordAudit({
      adminId: admin.id, action: "admin.content.view", targetType: "post", targetId: id,
      ipAddress: getClientIp(req), userAgent: req.headers.get("user-agent") ?? undefined,
    });

    return ok({
      type: "post",
      content: {
        ...post,
        createdAt: post.createdAt.toISOString(),
        updatedAt: post.updatedAt.toISOString(),
      },
      stats: { likes, comments, views, shares: shareCount, engagementRate, reportCount },
    });
  }

  // Article.
  const article = await db.article.findUnique({
    where: { id },
    select: {
      id: true, title: true, excerpt: true, content: true, coverImage: true,
      videoUrl: true, status: true, publishedAt: true, readingTime: true,
      createdAt: true, updatedAt: true, authorId: true,
      author: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
      _count: { select: { likes: true, comments: true, views: true } },
    },
  });
  if (!article) return notFound("Article not found.");

  const shareCount = await db.articleInteraction.count({ where: { articleId: id, type: "SHARE" } });
  // Report count: the Report model doesn't support Post/Article reports
  // yet (spec §16). reportCount is 0 until moderation is extended.
  const reportCount = 0;

  const likes = article._count.likes;
  const comments = article._count.comments;
  const views = article._count.views;
  const engagementRate = views > 0
    ? Math.round(((likes + comments + shareCount) / views) * 1000) / 10
    : 0;

  await recordAudit({
    adminId: admin.id, action: "admin.content.view", targetType: "article", targetId: id,
    ipAddress: getClientIp(req), userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({
    type: "article",
    content: {
      ...article,
      publishedAt: article.publishedAt?.toISOString() ?? null,
      createdAt: article.createdAt.toISOString(),
      updatedAt: article.updatedAt.toISOString(),
    },
    stats: { likes, comments, views, shares: shareCount, engagementRate, reportCount },
  });
});
