import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/admin/content
 * --------------------------
 * Unified Content Management list (spec §1-§6, §13, §22-§23).
 *
 * Returns Posts AND Articles in a single paginated response.
 * The caller can filter by type (all/posts/articles), status
 * (published/drafts), and sort by various metrics.
 *
 * ARCHITECTURE:
 *   Posts and Articles live in different tables. We query them in
 *   parallel (each with their own filter + orderBy), merge by timestamp
 *   in JS, sort by the selected metric, and take the top N. This is
 *   O(n) where n = items fetched from both tables (typically 2 ×
 *   poolSize). Efficient for admin browsing (spec §22, §23).
 *
 * PAGINATION (spec §22):
 *   Cursor-based. The cursor encodes (timestamp, id, type) — the next
 *   page fetches items strictly older than the cursor's timestamp.
 *
 * SECURITY (spec §19, §26):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - No private content exposed (drafts ARE shown to admins — that's
 *     the point of content management — but NOT to normal users).
 *   - All queries use Prisma parameterized queries.
 *
 * Performance (spec §23):
 *   - 2 parallel DB queries (posts + articles with _count aggregation).
 *   - 2 parallel batch queries for share counts (PostInteraction +
 *     ArticleInteraction groupBy WHERE type=SHARE).
 *   - Total: 4 queries + in-memory merge/sort. No N+1.
 */

const POST_SELECT = {
  id: true,
  content: true,
  createdAt: true,
  updatedAt: true,
  authorId: true,
  author: {
    select: {
      id: true, fullName: true, username: true,
      avatarColor: true, avatarUrl: true, isVerified: true,
    },
  },
  _count: {
    select: { likes: true, comments: true, views: true },
  },
} as const satisfies Prisma.PostSelect;

const ARTICLE_SELECT = {
  id: true,
  title: true,
  excerpt: true,
  coverImage: true,
  videoUrl: true,
  content: true,
  status: true,
  publishedAt: true,
  readingTime: true,
  createdAt: true,
  updatedAt: true,
  authorId: true,
  author: {
    select: {
      id: true, fullName: true, username: true,
      avatarColor: true, avatarUrl: true, isVerified: true,
    },
  },
  _count: {
    select: { likes: true, comments: true, views: true },
  },
} as const satisfies Prisma.ArticleSelect;

interface CursorData {
  ts: string;
  id: string;
  type: "post" | "article";
}

function decodeCursor(raw: string | null): CursorData | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(Buffer.from(raw, "base64").toString("utf-8")) as Partial<CursorData>;
    if (!parsed.ts || !parsed.id || !parsed.type) return null;
    if (parsed.type !== "post" && parsed.type !== "article") return null;
    return { ts: parsed.ts, id: parsed.id, type: parsed.type };
  } catch { return null; }
}

function encodeCursor(c: CursorData): string {
  return Buffer.from(JSON.stringify(c), "utf-8").toString("base64");
}

type SortBy = "newest" | "oldest" | "views" | "likes" | "comments" | "shares" | "engagement";
type ContentType = "all" | "posts" | "articles";
type StatusFilter = "all" | "published" | "drafts" | "reported";

export const GET = apiHandler(async (req) => {
  const admin = await requireAdmin();

  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "20"), 1), 50);
  const cursorParam = url.searchParams.get("cursor");
  const cursor = decodeCursor(cursorParam);
  if (cursorParam && !cursor) return badRequest("Invalid cursor.");

  const q = (url.searchParams.get("q") ?? "").trim();
  const type = (url.searchParams.get("type") ?? "all") as ContentType;
  const statusFilter = (url.searchParams.get("status") ?? "all") as StatusFilter;
  const sortBy = (url.searchParams.get("sortBy") ?? "newest") as SortBy;

  const cursorDate = cursor ? new Date(cursor.ts) : null;
  // Pool size = 3x the limit, capped at 100 — gives the merge/sort
  // enough material to find the best items.
  const poolSize = Math.min(Math.max(limit * 3, 30), 100);

  // ── Build WHERE clauses for posts + articles ───────────────────
  const postSearch: Prisma.PostWhereInput = q ? {
    OR: [
      { content: { contains: q, mode: "insensitive" } },
      { author: { username: { contains: q, mode: "insensitive" } } },
      { author: { fullName: { contains: q, mode: "insensitive" } } },
    ],
  } : {};

  const articleSearch: Prisma.ArticleWhereInput = q ? {
    OR: [
      { title: { contains: q, mode: "insensitive" } },
      { excerpt: { contains: q, mode: "insensitive" } },
      { content: { contains: q, mode: "insensitive" } },
      { author: { username: { contains: q, mode: "insensitive" } } },
      { author: { fullName: { contains: q, mode: "insensitive" } } },
    ],
  } : {};

  // Status filter.
  const articleStatusWhere: Prisma.ArticleWhereInput = statusFilter === "published"
    ? { status: "PUBLISHED" }
    : statusFilter === "drafts"
    ? { status: "DRAFT" }
    : {};

  // Cursor filter (items strictly older than cursor.ts).
  const postCursor = cursor && cursorDate ? {
    OR: [
      { createdAt: { lt: cursorDate } },
      { createdAt: cursorDate, id: { lt: cursor.id } },
    ],
  } : {};
  const articleCursor = cursor && cursorDate ? {
    OR: [
      { publishedAt: { lt: cursorDate } },
      { publishedAt: cursorDate, id: { lt: cursor.id } },
    ],
  } : {};

  // ── Parallel fetch: posts + articles ────────────────────────────
  const queries: Promise<any>[] = [];

  // Posts (skip if type=articles).
  if (type !== "articles") {
    queries.push(
      db.post.findMany({
        where: { ...postSearch, ...postCursor },
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: poolSize,
        select: POST_SELECT,
      })
    );
  } else {
    queries.push(Promise.resolve([]));
  }

  // Articles (skip if type=posts).
  if (type !== "posts") {
    queries.push(
      db.article.findMany({
        where: { ...articleSearch, ...articleStatusWhere, publishedAt: { not: null }, ...articleCursor },
        orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
        take: poolSize,
        select: ARTICLE_SELECT,
      }).catch(() => [])
    );
  } else {
    queries.push(Promise.resolve([]));
  }

  // For "drafts" filter, also fetch draft articles (no publishedAt filter).
  if (type !== "posts" && statusFilter === "drafts") {
    queries.push(
      db.article.findMany({
        where: { ...articleSearch, status: "DRAFT", ...articleCursor },
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: poolSize,
        select: ARTICLE_SELECT,
      }).catch(() => [])
    );
  } else {
    queries.push(Promise.resolve([]));
  }

  const [postRows, articleRows, draftArticleRows] = await Promise.all(queries);
  const allArticleRows = [...articleRows, ...draftArticleRows];

  // ── Fetch share counts (batched) ────────────────────────────────
  const postIds = postRows.map((p: any) => p.id);
  const articleIds = allArticleRows.map((a: any) => a.id);

  const [postShareRows, articleShareRows] = await Promise.all([
    postIds.length > 0
      ? db.postInteraction.groupBy({
          by: ["postId"],
          where: { postId: { in: postIds }, type: "SHARE" },
          _count: { _all: true },
        })
      : [],
    articleIds.length > 0
      ? db.articleInteraction.groupBy({
          by: ["articleId"],
          where: { articleId: { in: articleIds }, type: "SHARE" },
          _count: { _all: true },
        })
      : [],
  ]);

  // Note: the existing Report model only supports User/Message reports
  // (targetUserId, targetMessageId) — NOT Post/Article reports. So
  // reportCount is always 0 for content items in this iteration.
  // When the Report model is extended to support content reports
  // (future moderation phase), these queries can be re-enabled.
  // (spec §16 — "Do not build the full Reports/Moderation system yet.")

  type ShareRow = { postId?: string; articleId?: string; _count: { _all: number } };
  const postShareMap = new Map((postShareRows as any[]).map((s) => [s.postId, s._count._all]));
  const articleShareMap = new Map((articleShareRows as any[]).map((s) => [s.articleId, s._count._all]));
  // Report counts are always 0 for content items in this iteration
  // (the Report model doesn't support Post/Article reports yet — spec §16).

  // ── Merge posts + articles into a unified list ──────────────────
  type MergedItem = {
    type: "post" | "article";
    id: string;
    ts: Date;
    raw: any;
    counts: { likes: number; comments: number; views: number; shares: number };
    reportCount: number;
    engagement: number;
  };

  const merged: MergedItem[] = [];

  for (const p of postRows) {
    const likes = p._count.likes;
    const comments = p._count.comments;
    const views = p._count.views;
    const shares = postShareMap.get(p.id) ?? 0;
    merged.push({
      type: "post",
      id: p.id,
      ts: p.createdAt,
      raw: p,
      counts: { likes, comments, views, shares },
      reportCount: 0, // Report model doesn't support content reports yet (spec §16)
      engagement: likes + comments * 2 + shares * 3 + views * 0.1,
    });
  }

  for (const a of allArticleRows) {
    const likes = a._count.likes;
    const comments = a._count.comments;
    const views = a._count.views;
    const shares = articleShareMap.get(a.id) ?? 0;
    merged.push({
      type: "article",
      id: a.id,
      ts: a.publishedAt ?? a.createdAt,
      raw: a,
      counts: { likes, comments, views, shares },
      reportCount: 0, // Report model doesn't support content reports yet (spec §16)
      engagement: likes + comments * 2 + shares * 3 + views * 0.1,
    });
  }

  // ── Sort by the selected metric ─────────────────────────────────
  switch (sortBy) {
    case "newest":
      merged.sort((a, b) => b.ts.getTime() - a.ts.getTime() || b.id.localeCompare(a.id));
      break;
    case "oldest":
      merged.sort((a, b) => a.ts.getTime() - b.ts.getTime() || a.id.localeCompare(b.id));
      break;
    case "views":
      merged.sort((a, b) => b.counts.views - a.counts.views);
      break;
    case "likes":
      merged.sort((a, b) => b.counts.likes - a.counts.likes);
      break;
    case "comments":
      merged.sort((a, b) => b.counts.comments - a.counts.comments);
      break;
    case "shares":
      merged.sort((a, b) => b.counts.shares - a.counts.shares);
      break;
    case "engagement":
      merged.sort((a, b) => b.engagement - a.engagement);
      break;
  }

  // ── Apply "reported" filter (spec §16) ──────────────────────────
  const filtered = statusFilter === "reported"
    ? merged.filter((m) => m.reportCount > 0)
    : merged;

  // ── Take the top N + determine nextCursor ───────────────────────
  const hasMore = filtered.length > limit;
  const page = hasMore ? filtered.slice(0, limit) : filtered;

  // Serialize.
  const items = page.map((item) => {
    if (item.type === "post") {
      const p = item.raw;
      return {
        type: "post" as const,
        id: p.id,
        content: p.content.slice(0, 200),
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
        author: p.author,
        counts: item.counts,
        reportCount: item.reportCount,
        engagement: Math.round(item.engagement * 10) / 10,
        engagementRate: item.counts.views > 0
          ? Math.round(((item.counts.likes + item.counts.comments + item.counts.shares) / item.counts.views) * 1000) / 10
          : 0,
      };
    }
    const a = item.raw;
    return {
      type: "article" as const,
      id: a.id,
      title: a.title,
      excerpt: a.excerpt,
      coverImage: a.coverImage,
      videoUrl: a.videoUrl,
      status: a.status,
      publishedAt: a.publishedAt?.toISOString() ?? null,
      readingTime: a.readingTime,
      createdAt: a.createdAt.toISOString(),
      updatedAt: a.updatedAt.toISOString(),
      author: a.author,
      counts: item.counts,
      reportCount: item.reportCount,
      engagement: Math.round(item.engagement * 10) / 10,
      engagementRate: item.counts.views > 0
        ? Math.round(((item.counts.likes + item.counts.comments + item.counts.shares) / item.counts.views) * 1000) / 10
        : 0,
    };
  });

  // Next cursor = last item's (ts, id, type).
  const lastItem = page[page.length - 1];
  const nextCursor = hasMore && lastItem
    ? encodeCursor({ ts: lastItem.ts.toISOString(), id: lastItem.id, type: lastItem.type })
    : null;

  await recordAudit({
    adminId: admin.id,
    action: "admin.content.list",
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
    metadata: { q, type, statusFilter, sortBy, limit },
  });

  return ok({ items, nextCursor, counts: { posts: postRows.length, articles: allArticleRows.length, total: filtered.length } });
});
