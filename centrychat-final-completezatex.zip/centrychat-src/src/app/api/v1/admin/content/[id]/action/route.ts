import { apiHandler, badRequest, ok, notFound, parseJsonBody } from "@/lib/api";
import { requireAdmin, ForbiddenError } from "@/lib/auth";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";
import { getClientIp } from "@/lib/security/rate-limit";
import { isSuperAdmin } from "@/lib/permissions";
import { logger } from "@/lib/logging";

/**
 * POST /api/v1/admin/content/:id/action?type=post|article
 * --------------------------------------------------------
 * Admin content actions (spec §8, §9, §19-§21).
 *
 * Request body: { action: "DELETE" | "PUBLISH" | "UNPUBLISH" }
 *
 * SECURITY (spec §19, §20, §21):
 *   - requireAdmin() — ADMIN/SUPER_ADMIN only.
 *   - DELETE: Super Admin only (most destructive action — spec §20).
 *   - Self-content protection: admins can't delete their OWN content
 *     without being super admin (prevents accidental self-damage).
 *   - Audit recorded for every action (spec §22 — audit preparation).
 *
 * SOFT DELETE (spec §10):
 *   The Post and Article models do NOT have a `deletedAt` field. This
 *   endpoint implements HARD DELETE (the existing behavior). A future
 *   iteration can add a `deletedAt DateTime?` column for soft-delete.
 *
 * Actions:
 *   - DELETE: permanently removes the content + cascades all
 *     interactions (likes, comments, views, shares — all cascade).
 *   - PUBLISH (articles only): sets status=PUBLISHED + publishedAt=now.
 *   - UNPUBLISH (articles only): sets status=DRAFT + publishedAt=null.
 *
 * Posts don't have a draft/publish status — they're always "published"
 * once created. So PUBLISH/UNPUBLISH are only valid for articles.
 */
const ALLOWED_ACTIONS = ["DELETE", "PUBLISH", "UNPUBLISH"] as const;
type Action = (typeof ALLOWED_ACTIONS)[number];

export const POST = apiHandler(async (req, ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Content not found.");

  const url = new URL(req.url);
  const type = url.searchParams.get("type");
  if (type !== "post" && type !== "article") {
    return badRequest("Type must be 'post' or 'article'");
  }

  const body = await parseJsonBody<{ action?: string; reason?: string }>(req);
  const action = body.action as Action | undefined;
  if (!action || !ALLOWED_ACTIONS.includes(action)) {
    return badRequest("Invalid action. Allowed: DELETE, PUBLISH, UNPUBLISH");
  }

  // ── DELETE ──────────────────────────────────────────────────────
  if (action === "DELETE") {
    // Only super admin can delete content (spec §20 — most destructive).
    if (!isSuperAdmin(admin.role)) {
      throw new ForbiddenError("Only super admins can delete content");
    }

    if (type === "post") {
      const post = await db.post.findUnique({ where: { id }, select: { authorId: true, content: true } });
      if (!post) return notFound("Post not found.");

      // Self-content protection: can't delete own content without being
      // super admin (you already are super admin here — but still check
      // to be explicit + future-proof for when non-super-admin delete
      // might be allowed).
      if (post.authorId === admin.id && !isSuperAdmin(admin.role)) {
        throw new ForbiddenError("Cannot delete your own content");
      }

      await db.post.delete({ where: { id } });

      await recordAudit({
        adminId: admin.id, action: "admin.content.delete", targetType: "post", targetId: id,
        metadata: { reason: body.reason ?? null, authorId: post.authorId, contentPreview: post.content.slice(0, 100) },
        ipAddress: getClientIp(req), userAgent: req.headers.get("user-agent") ?? undefined,
      });

      logger.info("admin", "Post deleted by admin", { postId: id, adminId: admin.id });
    } else {
      const article = await db.article.findUnique({ where: { id }, select: { authorId: true, title: true, status: true } });
      if (!article) return notFound("Article not found.");

      if (article.authorId === admin.id && !isSuperAdmin(admin.role)) {
        throw new ForbiddenError("Cannot delete your own content");
      }

      await db.article.delete({ where: { id } });

      await recordAudit({
        adminId: admin.id, action: "admin.content.delete", targetType: "article", targetId: id,
        metadata: { reason: body.reason ?? null, authorId: article.authorId, title: article.title },
        ipAddress: getClientIp(req), userAgent: req.headers.get("user-agent") ?? undefined,
      });

      logger.info("admin", "Article deleted by admin", { articleId: id, adminId: admin.id });
    }

    return ok({ action: "DELETE", id, type });
  }

  // ── PUBLISH / UNPUBLISH (articles only) ─────────────────────────
  if (action === "PUBLISH" || action === "UNPUBLISH") {
    if (type !== "article") {
      return badRequest("Publish/Unpublish is only available for articles");
    }

    const article = await db.article.findUnique({ where: { id }, select: { id: true, authorId: true, title: true, status: true } });
    if (!article) return notFound("Article not found.");

    // Admin protection: non-super-admin can't modify another admin's content.
    if (!isSuperAdmin(admin.role)) {
      const author = await db.user.findUnique({ where: { id: article.authorId }, select: { role: true } });
      if (author && (author.role === "ADMIN" || author.role === "SUPER_ADMIN")) {
        throw new ForbiddenError("Cannot modify another admin's content");
      }
    }

    const newStatus = action === "PUBLISH" ? "PUBLISHED" : "DRAFT";
    if (article.status === newStatus) {
      return ok({ action, id, type, skipped: true, reason: "already_set" });
    }

    await db.article.update({
      where: { id },
      data: {
        status: newStatus,
        publishedAt: action === "PUBLISH" ? new Date() : null,
      },
    });

    await recordAudit({
      adminId: admin.id, action: `admin.content.${action.toLowerCase()}`, targetType: "article", targetId: id,
      metadata: { authorId: article.authorId, title: article.title, newStatus },
      ipAddress: getClientIp(req), userAgent: req.headers.get("user-agent") ?? undefined,
    });

    return ok({ action, id, type, newStatus });
  }

  return badRequest("Unsupported action");
});
