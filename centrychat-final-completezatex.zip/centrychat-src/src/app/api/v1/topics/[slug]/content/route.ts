import { apiHandler, ok, notFound } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { getTopicBySlug, getContentForTopic } from "@/lib/topics";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/topics/[slug]/content
 * ---------------------------------
 * Get posts + articles for a topic, paginated.
 *
 * Returns the same shape as /api/v1/feed/unified (items[] with mixed
 * post/article entries) so the client can reuse the existing feed rendering
 * components (PostCard + ArticleCard).
 *
 * Auth: optional (anonymous users can browse public topic content).
 * Drafts + inactive topics are excluded.
 */
export const GET = apiHandler(async (req, ctx) => {
  const { slug } = await ctx.params;
  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "20"), 1), 50);

  // Resolve the topic. Inactive topics return 404 to public users.
  const viewer = await getCurrentUser();
  const topic = await getTopicBySlug(slug, {}, viewer?.id ?? null);
  if (!topic) return notFound("Topic not found.");

  // Get post + article IDs for this topic.
  const { posts: postIds, articles: articleIds } = await getContentForTopic(
    topic.id,
    { limit }
  );

  if (postIds.length === 0 && articleIds.length === 0) {
    return ok({ items: [], nextCursor: null, topic });
  }

  // Fetch full post + article rows with author info + counts.
  const POST_SELECT = {
    id: true,
    content: true,
    createdAt: true,
    updatedAt: true,
    authorId: true,
    author: {
      select: {
        id: true, fullName: true, username: true,
        avatarColor: true, avatarUrl: true, isVerified: true,
      },
    },
    _count: { select: { likes: true, comments: true, views: true } },
  } as const satisfies Prisma.PostSelect;

  const ARTICLE_SELECT = {
    id: true, title: true, excerpt: true, coverImage: true, videoUrl: true,
    imageZoom: true, imagePositionX: true, imagePositionY: true,
    publishedAt: true, readingTime: true,
    author: {
      select: {
        id: true, fullName: true, username: true,
        avatarColor: true, avatarUrl: true, isVerified: true,
      },
    },
    _count: { select: { likes: true, comments: true, views: true } },
  } as const satisfies Prisma.ArticleSelect;

  type PostRow = Prisma.PostGetPayload<{ select: typeof POST_SELECT }>;
  type ArticleRow = Prisma.ArticleGetPayload<{ select: typeof ARTICLE_SELECT }>;

  const [postRows, articleRows]: [PostRow[], ArticleRow[]] = await Promise.all([
    postIds.length > 0
      ? db.post.findMany({
          where: { id: { in: postIds.map((p) => p.id) } },
          select: POST_SELECT,
        })
      : Promise.resolve([]),
    articleIds.length > 0
      ? db.article.findMany({
          where: { id: { in: articleIds.map((a) => a.id) } },
          select: ARTICLE_SELECT,
        })
      : Promise.resolve([]),
  ]);

  // Batch-compute isLiked + shareCount for the current user.
  const postLikedSet = new Set<string>();
  const articleLikedSet = new Set<string>();
  const followersOfMeSet = new Set<string>();
  const postShareMap = new Map<string, number>();
  const articleShareMap = new Map<string, number>();

  if (viewer && (postRows.length > 0 || articleRows.length > 0)) {
    const postIdsForLikes = postRows.map((p) => p.id);
    const articleIdsForLikes = articleRows.map((a) => a.id);
    const [postLikes, articleLikes, followersOfMe, postShares, articleShares] = await Promise.all([
      postIdsForLikes.length > 0
        ? db.postLike.findMany({
            where: { userId: viewer.id, postId: { in: postIdsForLikes } },
            select: { postId: true },
          })
        : Promise.resolve([]),
      articleIdsForLikes.length > 0
        ? db.articleLike.findMany({
            where: { userId: viewer.id, articleId: { in: articleIdsForLikes } },
            select: { articleId: true },
          })
        : Promise.resolve([]),
      db.follow.findMany({
        where: { followingId: viewer.id },
        select: { followerId: true },
      }),
      postIdsForLikes.length > 0
        ? db.postInteraction.groupBy({
            by: ["postId"],
            where: { postId: { in: postIdsForLikes }, type: "SHARE" },
            _count: { _all: true },
          })
        : Promise.resolve([] as { postId: string; _count: { _all: number } }[]),
      articleIdsForLikes.length > 0
        ? db.articleInteraction.groupBy({
            by: ["articleId"],
            where: { articleId: { in: articleIdsForLikes }, type: "SHARE" },
            _count: { _all: true },
          })
        : Promise.resolve([] as { articleId: string; _count: { _all: number } }[]),
    ]);
    for (const l of postLikes) postLikedSet.add(l.postId);
    for (const l of articleLikes) articleLikedSet.add(l.articleId);
    for (const f of followersOfMe) followersOfMeSet.add(f.followerId);
    for (const s of postShares) postShareMap.set(s.postId, s._count._all);
    for (const s of articleShares) articleShareMap.set(s.articleId, s._count._all);
  }

  // Build the items array — interleave posts + articles by timestamp desc.
  type PostDTO = {
    id: string; content: string; createdAt: Date; updatedAt: Date;
    author: {
      id: string; fullName: string; username: string;
      avatarColor: string | null; avatarUrl: string | null; isVerified: boolean;
      isFollowing: boolean; isFollowedBy: boolean;
    };
    likeCount: number; commentCount: number; viewCount: number;
    shareCount: number; isLiked: boolean;
  };
  type ArticleDTO = {
    id: string; title: string; excerpt: string | null;
    coverImage: string | null; videoUrl: string | null;
    imageZoom: number | null; imagePositionX: number | null; imagePositionY: number | null;
    publishedAt: string | null; readingTime: number;
    author: {
      id: string; fullName: string; username: string;
      avatarColor: string | null; avatarUrl: string | null; isVerified: boolean;
      isFollowing: boolean; isFollowedBy: boolean;
    };
    likeCount: number; commentCount: number; viewCount: number;
    shareCount: number; isLiked: boolean;
  };
  type Item = { type: "post"; post: PostDTO } | { type: "article"; article: ArticleDTO };

  const postMap = new Map<string, PostRow>(postRows.map((p) => [p.id, p]));
  const articleMap = new Map<string, ArticleRow>(articleRows.map((a) => [a.id, a]));

  // Merge + sort by timestamp desc (posts use createdAt, articles use publishedAt).
  const merged: { ts: number; item: Item }[] = [];
  for (const p of postIds) {
    const row = postMap.get(p.id);
    if (!row) continue;
    merged.push({
      ts: p.createdAt.getTime(),
      item: {
        type: "post" as const,
        post: {
          id: row.id,
          content: row.content,
          createdAt: row.createdAt,
          updatedAt: row.updatedAt,
          author: {
            id: row.author.id,
            fullName: row.author.fullName,
            username: row.author.username,
            avatarColor: row.author.avatarColor,
            avatarUrl: row.author.avatarUrl,
            isVerified: row.author.isVerified,
            isFollowing: false, // set below
            isFollowedBy: followersOfMeSet.has(row.author.id),
          },
          likeCount: row._count.likes,
          commentCount: row._count.comments,
          viewCount: row._count.views,
          shareCount: postShareMap.get(row.id) ?? 0,
          isLiked: postLikedSet.has(row.id),
        },
      },
    });
  }
  for (const a of articleIds) {
    const row = articleMap.get(a.id);
    if (!row) continue;
    merged.push({
      ts: a.publishedAt?.getTime() ?? 0,
      item: {
        type: "article" as const,
        article: {
          id: row.id,
          title: row.title,
          excerpt: row.excerpt,
          coverImage: row.coverImage,
          videoUrl: row.videoUrl,
          imageZoom: row.imageZoom,
          imagePositionX: row.imagePositionX,
          imagePositionY: row.imagePositionY,
          publishedAt: row.publishedAt?.toISOString() ?? null,
          readingTime: row.readingTime,
          author: {
            id: row.author.id,
            fullName: row.author.fullName,
            username: row.author.username,
            avatarColor: row.author.avatarColor,
            avatarUrl: row.author.avatarUrl,
            isVerified: row.author.isVerified,
            isFollowing: false, // set below
            isFollowedBy: followersOfMeSet.has(row.author.id),
          },
          likeCount: row._count.likes,
          commentCount: row._count.comments,
          viewCount: row._count.views,
          shareCount: articleShareMap.get(row.id) ?? 0,
          isLiked: articleLikedSet.has(row.id),
        },
      },
    });
  }
  merged.sort((a, b) => b.ts - a.ts);

  // Batch-fetch isFollowing for the authors (single query for unique author IDs).
  if (viewer && merged.length > 0) {
    const uniqueAuthorIds = [...new Set(merged.map((m) =>
      m.item.type === "post" ? m.item.post.author.id : m.item.article.author.id
    ))];
    const followedAuthors = await db.follow.findMany({
      where: { followerId: viewer.id, followingId: { in: uniqueAuthorIds } },
      select: { followingId: true },
    });
    const followedSet = new Set(followedAuthors.map((f) => f.followingId));
    for (const m of merged) {
      if (m.item.type === "post") {
        m.item.post.author.isFollowing = followedSet.has(m.item.post.author.id);
      } else {
        m.item.article.author.isFollowing = followedSet.has(m.item.article.author.id);
      }
    }
  }

  return ok({
    items: merged.map((m) => m.item),
    nextCursor: null,
    topic,
  });
});
