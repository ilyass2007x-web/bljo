import { apiHandler, ok, notFound } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { getTopicBySlug } from "@/lib/topics";

/**
 * GET /api/v1/topics/[slug]
 * -------------------------
 * Get a single topic by slug. Public — anonymous users can fetch.
 *
 * Returns 404 when:
 *   - topic doesn't exist
 *   - topic is inactive (admin-deactivated)
 *
 * Auth: optional. When authenticated, includes `isFollowed`.
 */
export const GET = apiHandler(async (req, ctx) => {
  const { slug } = await ctx.params;
  const viewer = await getCurrentUser();
  const topic = await getTopicBySlug(slug, {}, viewer?.id ?? null);
  if (!topic) return notFound("Topic not found.");
  return ok({ topic });
});
