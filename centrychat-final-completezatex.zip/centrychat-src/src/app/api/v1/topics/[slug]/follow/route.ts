import { apiHandler, ok, badRequest, notFound, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { followTopic, unfollowTopic, getTopicBySlug } from "@/lib/topics";

/**
 * POST /api/v1/topics/[slug]/follow
 * ---------------------------------
 * Follow a topic. Idempotent — if already following, returns success.
 *
 * Auth: required (verified user). userId is taken from the session.
 *
 * Rate-limited: 30 follows/min per user (matches the existing follow rate limit).
 *
 * Side effects:
 *   - Creates a UserTopicFollow row (DB-level @@unique prevents duplicates).
 *   - Bumps the user's UserInterest.score for this topic to 0.8 (max) — reuses
 *     the EXISTING personalization pipeline.
 *   - Invalidates the interest profile cache for this user.
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const rl = await checkRateLimit(`topic-follow:${user.id}`, RATE_LIMITS.follow);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const { slug } = await ctx.params;
  if (!slug) return badRequest("Topic slug is required.");

  try {
    const result = await followTopic(user.id, slug);
    // Re-fetch the full topic DTO (with follower count + isFollowed).
    const topic = await getTopicBySlug(result.topicSlug, {}, user.id);
    return ok({ topic, alreadyFollowing: result.alreadyFollowing });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Failed to follow topic.";
    if (msg.includes("not found")) return notFound(msg);
    return badRequest(msg);
  }
});

/**
 * DELETE /api/v1/topics/[slug]/follow
 * -----------------------------------
 * Unfollow a topic. Idempotent — if not following, returns success.
 *
 * Does NOT zero out UserInterest.score — preserves the user's organic
 * interaction history (so re-following later doesn't lose affinity).
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const rl = await checkRateLimit(`topic-unfollow:${user.id}`, RATE_LIMITS.follow);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const { slug } = await ctx.params;
  if (!slug) return badRequest("Topic slug is required.");

  try {
    const result = await unfollowTopic(user.id, slug);
    return ok({ topicId: result.topicId, wasFollowing: result.wasFollowing });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Failed to unfollow topic.";
    if (msg.includes("not found")) return notFound(msg);
    return badRequest(msg);
  }
});
