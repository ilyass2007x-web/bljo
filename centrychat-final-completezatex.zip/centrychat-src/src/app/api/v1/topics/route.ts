import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireVerifiedUser, getCurrentUser } from "@/lib/auth";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { rateLimited } from "@/lib/api";
import { listTopics, getTrendingTopics, getRecommendedTopics } from "@/lib/topics";

/**
 * GET /api/v1/topics
 * ------------------
 * Public list of topics. Supports search + sort + cursor pagination.
 *
 * Query params:
 *   - limit    (default 20, max 50)  — page size
 *   - cursor   (optional)           — opaque cursor from previous response
 *   - search   (optional)           — case-insensitive name contains
 *   - sort     (default "popular")  — "popular" | "recent" | "name"
 *   - view     (optional)           — "trending" | "recommended" (alt mode)
 *
 * Auth: optional. When authenticated, includes `isFollowed` per topic.
 */
export const GET = apiHandler(async (req) => {
  const url = new URL(req.url);
  const limit = Number(url.searchParams.get("limit") ?? "20");
  const cursor = url.searchParams.get("cursor");
  const search = url.searchParams.get("search") ?? undefined;
  const sortParam = url.searchParams.get("sort") ?? "popular";
  const view = url.searchParams.get("view");

  // Validate sort param.
  const sort = (["popular", "recent", "name"].includes(sortParam)
    ? sortParam
    : "popular") as "popular" | "recent" | "name";

  // Auth is optional for public topics. Use getCurrentUser (not requireUser)
  // so anonymous users can browse topics.
  const viewer = await getCurrentUser();

  // Alt modes: trending + recommended (no pagination).
  if (view === "trending") {
    const topics = await getTrendingTopics(limit, viewer?.id ?? null);
    return ok({ topics, nextCursor: null });
  }
  if (view === "recommended") {
    // Recommended requires authentication.
    if (!viewer) {
      return ok({ topics: [], nextCursor: null });
    }
    const rl = await checkRateLimit(`topic-rec:${viewer.id}`, RATE_LIMITS.search);
    if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));
    const topics = await getRecommendedTopics(viewer.id, limit);
    return ok({ topics, nextCursor: null });
  }

  // Default: paginated list.
  if (search && search.trim().length < 2) {
    return badRequest("Search query must be at least 2 characters.");
  }

  const result = await listTopics(
    { limit, cursor: cursor || null, search, sortBy: sort },
    viewer?.id ?? null
  );
  return ok(result);
});
