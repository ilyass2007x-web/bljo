import { apiHandler, ok, notFound, badRequest, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { getSettingNumber } from "@/lib/settings";
import { db } from "@/lib/database";
import {
  getCollectionForOwner,
  serializeItem,
  hydrateCollectionItems,
  validateContentExists,
  validateContentType,
  validateContentId,
  countCollectionItems,
  getNextPosition,
  type CollectionContentType,
  type CollectionItemDTO,
} from "@/lib/collections";
import { Prisma } from "@prisma/client";

/**
 * GET /api/v1/collections/:id/items
 * ----------------------------------
 * List items in a collection, ordered by position ASC + addedAt ASC + id ASC.
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Auth: requires authenticated + verified user.
 *
 * Visibility rules (IDOR-safe):
 *   - Owner: sees all items regardless of collection visibility.
 *   - Non-owner: sees items ONLY if the collection is public.
 *   - Unauthorized/nonexistent: returns 404 (no leakage of private
 *     collection existence).
 *
 * Pagination: cursor-based. The cursor encodes the LAST item's
 * (position, addedAt, id) from the previous page. The next page seeks
 * strictly greater than (position, addedAt, id) — which matches the
 * ordering. Deterministic.
 *
 * Response: { items: SerializedItem[], nextCursor: string | null }
 *
 * PERFORMANCE:
 *   - 1 query for the collection (auth check + visibility).
 *   - 1 query for the items (batched, indexed by [collectionId, position]).
 *   - 1 batched hydrateCollectionItems call (max 4 queries for any number
 *     of items — 1 per contentType). No N+1.
 */
export const GET = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("collections"))) {
    return notFound("Collection not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Collection not found.");

  // Authorization: owner OR public. Use getCollectionForOwner first
  // (fast indexed lookup on ownerId); if not owner, fall back to public.
  let collection = await getCollectionForOwner(id, user.id);
  if (!collection) {
    // Not the owner — try as a public collection.
    const publicCollection = await db.collection.findFirst({
      where: { id, isPublic: true },
      select: { id: true },
    });
    if (publicCollection) {
      // Treat as a minimal collection DTO (we only need the id for the
      // items query below).
      collection = { id: publicCollection.id } as any;
    }
  }
  if (!collection) return notFound("Collection not found.");

  // ── Pagination params ──────────────────────────────────────────────
  const url = new URL(req.url);
  const limit = Math.min(
    Math.max(Number(url.searchParams.get("limit") ?? "20"), 1),
    50
  );
  const cursorParam = url.searchParams.get("cursor");

  // Cursor encodes (position, addedAt, id) of the LAST item from the
  // previous page. We seek strictly greater than (position, addedAt, id).
  let seek: { position: number; addedAt: Date; id: string } | null = null;
  if (cursorParam) {
    try {
      const decoded = JSON.parse(
        Buffer.from(cursorParam, "base64").toString("utf-8")
      ) as { position?: number; addedAt?: string; id?: string };
      if (
        typeof decoded.position === "number" &&
        typeof decoded.addedAt === "string" &&
        typeof decoded.id === "string"
      ) {
        seek = {
          position: decoded.position,
          addedAt: new Date(decoded.addedAt),
          id: decoded.id,
        };
      } else {
        return badRequest("Invalid cursor.");
      }
    } catch {
      return badRequest("Invalid cursor.");
    }
  }

  // ── Fetch items ─────────────────────────────────────────────────────
  // Pagination: "fetch all + slice in memory". Bounded by collection.max_items
  // (default 1000) — acceptable for the project's scale. Cursor seek would
  // require a unique constraint on (collectionId, position) which we don't
  // have (positions can repeat in theory — reorder normalizes them, but
  // defensive). The simpler approach is faster + correct.
  //
  // Ordering: position ASC, then addedAt ASC, then id ASC (deterministic
  // tiebreaker when two items share the same position — should never
  // happen because reorder rewrites positions, but defensive).
  const allItems = await db.collectionItem.findMany({
    where: { collectionId: id },
    orderBy: [{ position: "asc" }, { addedAt: "asc" }, { id: "asc" }],
    select: ITEM_LIST_SELECT,
  });

  // Determine the slice based on the cursor (position of the LAST item
  // from the previous page).
  let startIndex = 0;
  if (seek) {
    const idx = allItems.findIndex(
      (i) =>
        i.position === seek!.position &&
        i.addedAt.getTime() === seek!.addedAt.getTime() &&
        i.id === seek!.id
    );
    if (idx >= 0) startIndex = idx + 1;
  }

  const hasMore = startIndex + limit < allItems.length;
  const page = allItems.slice(startIndex, startIndex + limit);

  const lastItem = page.length > 0 ? page[page.length - 1] : null;
  const nextCursor = hasMore && lastItem
    ? Buffer.from(
        JSON.stringify({
          position: lastItem.position,
          addedAt:
            lastItem.addedAt instanceof Date
              ? lastItem.addedAt.toISOString()
              : lastItem.addedAt,
          id: lastItem.id,
        }),
        "utf-8"
      ).toString("base64")
    : null;

  // ── Batched content hydration ──────────────────────────────────────
  const hydrated = await hydrateCollectionItems(page);

  return ok({
    items: page.map((i) => ({
      ...serializeItem(i as CollectionItemDTO),
      content: hydrated.get(`${i.contentType}:${i.contentId}`) ?? null,
    })),
    nextCursor,
  });
});

/**
 * POST /api/v1/collections/:id/items
 * -----------------------------------
 * Add an item to a collection. Appends to the end (position = next).
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Body: { contentType: "post" | "article" | "video" | "discussion", contentId: string }
 *
 * Pre-insertion validation (spec §11):
 *   1. Verify collection ownership (IDOR-safe — non-owner gets 404).
 *   2. Verify the target content exists + is accessible.
 *   3. Verify collection capacity (collection.max_items, default 1000).
 *   4. Verify the item does not already exist (DB @@unique is the
 *      final protection; we check explicitly for a clean 409 response).
 *
 * On duplicate: returns 409 Conflict with a clear message (spec §37).
 *
 * Rate limit: collectionItem (default 60/minute) — prevents spam.
 *
 * Response: { item: SerializedItem }
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("collections"))) {
    return notFound("Collection not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Collection not found.");

  // ── 1. Ownership check ─────────────────────────────────────────────
  // IDOR-safe: filter by id AND ownerId — non-owner gets null → 404.
  const collection = await getCollectionForOwner(id, user.id);
  if (!collection) return notFound("Collection not found.");

  // ── Rate limit (after ownership — don't waste the check on non-owners)
  const rl = await checkRateLimit(
    `collection-item:${user.id}`,
    RATE_LIMITS.collectionItem
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  // ── 2. Validate body ───────────────────────────────────────────────
  const body = await req.json().catch(() => ({} as unknown));
  const contentType = validateContentType((body as { contentType?: unknown }).contentType);
  const contentId = validateContentId((body as { contentId?: unknown }).contentId);

  // ── 3. Verify content exists ───────────────────────────────────────
  const exists = await validateContentExists(contentType, contentId);
  if (!exists) {
    return badRequest("The content you're trying to save does not exist or is not accessible.");
  }

  // ── 4. Capacity check ──────────────────────────────────────────────
  const maxItems = (await getSettingNumber("collection.max_items")) ?? 1000;
  const currentCount = await countCollectionItems(id);
  if (currentCount >= maxItems) {
    return badRequest(
      `Collection is full (${maxItems} items max). Remove an item before adding more.`
    );
  }

  // ── 5. Duplicate check (clean 409, not a P2002 leak) ──────────────
  const existing = await db.collectionItem.findUnique({
    where: {
      collectionId_contentType_contentId: {
        collectionId: id,
        contentType,
        contentId,
      },
    },
    select: { id: true },
  });
  if (existing) {
    return badRequest("This content is already saved to this collection.");
  }

  // ── 6. Insert at the end (position = next) ─────────────────────────
  const nextPosition = await getNextPosition(id);
  const item = await db.collectionItem.create({
    data: {
      collectionId: id,
      contentType,
      contentId,
      position: nextPosition,
    },
    select: ITEM_LIST_SELECT,
  });

  // Bump the collection's updatedAt so it sorts first in the user's list.
  await db.collection.update({
    where: { id },
    data: { updatedAt: new Date() },
  });

  return ok({ item: serializeItem(item as CollectionItemDTO) });
});

// ── Shared projection ──────────────────────────────────────────────────────
const ITEM_LIST_SELECT = {
  id: true,
  collectionId: true,
  contentType: true,
  contentId: true,
  position: true,
  addedAt: true,
} as const satisfies Prisma.CollectionItemSelect;
