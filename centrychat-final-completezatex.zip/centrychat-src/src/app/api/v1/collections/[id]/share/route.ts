import { apiHandler, ok, notFound, badRequest, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { db } from "@/lib/database";
import { getCollectionForViewer, serializeCollection, type CollectionDTO } from "@/lib/collections";
import { notifyCollectionShared } from "@/lib/notifications";

/**
 * POST /api/v1/collections/:id/share
 * -----------------------------------
 * Share a PUBLIC collection with another user (direct user-to-user share).
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Body: { recipientId: string }   (the user to share WITH)
 *
 * Behavior:
 *   - The collection must be PUBLIC (private collections can never be shared).
 *   - The recipient must exist + be ACTIVE + email-verified.
 *   - Self-share is rejected (you can't share with yourself — would just
 *     be a no-op + noise).
 *   - On success, a COLLECTION_SHARED notification is sent to the recipient
 *     (via notifyCollectionShared — fire-and-forget, non-blocking).
 *
 * Authorization:
 *   - The sharer is the authenticated user (from session).
 *   - The recipientId is validated server-side — never trusted beyond a
 *     DB lookup. The recipient's identity is verified to exist + be active
 *     before any notification is sent.
 *
 * SECURITY:
 *   - recipientId is validated against the User table (must exist + ACTIVE).
 *   - Self-share is excluded (recipientId === user.id → 400).
 *   - Private collections return 404 (not 403) to avoid leaking existence
 *     to users who don't own them AND happen to know the collection ID.
 *   - The notification's metadata contains only safe fields (collectionId,
 *     collectionName, actorName) — no sensitive data.
 *
 * Rate limit: collectionShare (default 30/min) — prevents spam.
 *
 * Response: { ok: true, shared: true, recipient: { id, username, fullName } }
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("collections"))) {
    return notFound("Collection not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Collection not found.");

  // ── Rate limit ──────────────────────────────────────────────────────
  const rl = await checkRateLimit(
    `collection-share:${user.id}`,
    RATE_LIMITS.collectionShare
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  // ── Validate body ───────────────────────────────────────────────────
  const body = await req.json().catch(() => ({} as unknown));
  const rawRecipientId = (body as { recipientId?: unknown }).recipientId;
  if (typeof rawRecipientId !== "string" || rawRecipientId.trim().length === 0) {
    return badRequest("recipientId is required");
  }
  const recipientId = rawRecipientId.trim();

  // Self-share check.
  if (recipientId === user.id) {
    return badRequest("You cannot share a collection with yourself.");
  }

  // ── Fetch the collection (must be visible to the sharer) ───────────
  // getCollectionForViewer returns the collection if (a) the viewer owns
  // it OR (b) it's public. We need to check that the collection is PUBLIC
  // before sharing — private collections can never be shared.
  const collection = await getCollectionForViewer(id, user.id);
  if (!collection) return notFound("Collection not found.");

  // Enforce public-only sharing — private collections can never be shared.
  if (!collection.isPublic) {
    return badRequest(
      "Only public collections can be shared. Make the collection public first."
    );
  }

  // ── Validate the recipient exists + is ACTIVE + email-verified ─────
  // (matches the same pattern used by messaging: can only share with
  // ACTIVE users who have verified their email — prevents spam to
  // unverified accounts).
  const recipient = await db.user.findFirst({
    where: {
      id: recipientId,
      status: "ACTIVE",
      emailVerified: { not: null },
    },
    select: {
      id: true,
      username: true,
      fullName: true,
    },
  });
  if (!recipient) {
    return notFound("Recipient not found or not available for sharing.");
  }

  // ── Send the notification (fire-and-forget) ────────────────────────
  // notifyCollectionShared excludes self-shares (defensive — we already
  // checked above) + swallows notification failures (the share itself
  // already succeeded by the time the notification is sent).
  await notifyCollectionShared({
    recipientId: recipient.id,
    actorId: user.id,
    collectionId: collection.id,
    collectionName: collection.name,
    actorName: user.fullName,
  });

  // Return the (re-serialized) collection + the recipient summary so the
  // client can show a success toast with the recipient's name.
  return ok({
    ok: true,
    shared: true,
    collection: serializeCollection(collection as CollectionDTO),
    recipient: {
      id: recipient.id,
      username: recipient.username,
      fullName: recipient.fullName,
    },
  });
});
