import { apiHandler, ok, notFound, badRequest } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { getSettingNumber } from "@/lib/settings";
import { db } from "@/lib/database";
import {
  getCollectionForOwner,
  getCollectionForViewer,
  serializeCollection,
  type CollectionDTO,
} from "@/lib/collections";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/collections/:id
 * ----------------------------
 * Fetch a single collection by ID.
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Auth: requires authenticated + verified user.
 *
 * Visibility rules (IDOR-safe):
 *   - Owner: sees the collection regardless of isPublic.
 *   - Non-owner: sees the collection ONLY if isPublic=true.
 *   - Unauthorized/nonexistent: returns 404 (does NOT leak existence of
 *     private collections to non-owners).
 *
 * Response: { collection: SerializedCollection }
 */
export const GET = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("collections"))) {
    return notFound("Collection not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Collection not found.");

  const collection = await getCollectionForViewer(id, user.id);
  if (!collection) return notFound("Collection not found.");

  return ok({ collection: serializeCollection(collection) });
});

/**
 * PATCH /api/v1/collections/:id
 * -----------------------------
 * Edit a collection's name / description / isPublic.
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Body: { name?: string, description?: string|null, isPublic?: boolean }
 * At least ONE field must be present. Fields not provided are left untouched.
 *
 * Validation:
 *   - name: trimmed, length 1..collection.max_name_length (when provided).
 *   - description: trimmed, length 0..collection.max_description_length,
 *     null clears it (when provided). Empty string is treated as null.
 *   - isPublic: boolean only (when provided).
 *
 * Authorization: OWNER ONLY. Non-owner gets 404 (IDOR-safe).
 *
 * Response: { collection: SerializedCollection }
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("collections"))) {
    return notFound("Collection not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Collection not found.");

  // Authorization-aware fetch: filter by id AND ownerId — non-owner gets
  // null → 404 (no information leakage).
  const existing = await getCollectionForOwner(id, user.id);
  if (!existing) return notFound("Collection not found.");

  const body = await req.json().catch(() => ({} as unknown));
  const patch: Prisma.CollectionUpdateInput = {};

  // ── name ────────────────────────────────────────────────────────────
  if (body && "name" in (body as Record<string, unknown>)) {
    const rawName = (body as { name?: unknown }).name;
    if (typeof rawName !== "string") {
      return badRequest("name must be a string");
    }
    const name = rawName.trim();
    if (name.length === 0) {
      return badRequest("name cannot be empty");
    }
    const maxNameLength =
      (await getSettingNumber("collection.max_name_length")) ?? 100;
    if (name.length > maxNameLength) {
      return badRequest(`name must be at most ${maxNameLength} characters`);
    }
    patch.name = name;
  }

  // ── description ─────────────────────────────────────────────────────
  if (body && "description" in (body as Record<string, unknown>)) {
    const rawDescription = (body as { description?: unknown }).description;
    if (rawDescription === null || rawDescription === undefined) {
      patch.description = null;
    } else if (typeof rawDescription === "string") {
      const trimmed = rawDescription.trim();
      const maxDescLength =
        (await getSettingNumber("collection.max_description_length")) ?? 500;
      if (trimmed.length > maxDescLength) {
        return badRequest(
          `description must be at most ${maxDescLength} characters`
        );
      }
      patch.description = trimmed.length > 0 ? trimmed : null;
    } else {
      return badRequest("description must be a string or null");
    }
  }

  // ── isPublic ───────────────────────────────────────────────────────
  if (body && "isPublic" in (body as Record<string, unknown>)) {
    const rawIsPublic = (body as { isPublic?: unknown }).isPublic;
    if (typeof rawIsPublic !== "boolean") {
      return badRequest("isPublic must be a boolean");
    }
    patch.isPublic = rawIsPublic;
  }

  // Require at least one field to update.
  if (Object.keys(patch).length === 0) {
    return badRequest(
      "Provide at least one field to update (name, description, isPublic)."
    );
  }

  // Reject forbidden fields (ownerId / id / createdAt are never accepted).
  const forbidden = Object.keys(body as Record<string, unknown>).filter(
    (k) => !["name", "description", "isPublic"].includes(k)
  );
  if (forbidden.length > 0) {
    return badRequest(`Cannot update field(s): ${forbidden.join(", ")}`);
  }

  const updated = await db.collection.update({
    where: { id },
    data: patch,
    select: COLLECTION_DETAIL_SELECT,
  });

  return ok({ collection: serializeCollection(updated as CollectionDTO) });
});

/**
 * DELETE /api/v1/collections/:id
 * -------------------------------
 * Delete a collection. Cascade-deletes all its items (via the schema's
 * onDelete: Cascade on CollectionItem.collectionId).
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Authorization: OWNER ONLY. Non-owner gets 404 (IDOR-safe).
 *
 * CRITICAL: deleting a collection NEVER deletes the underlying content
 * (posts/articles/videos/discussions) — the polymorphic (contentType,
 * contentId) pair has NO foreign key to those tables. Only the
 * CollectionItem rows (the "saved bookmark" relationship) are deleted.
 *
 * Response: { ok: true, deleted: <collectionId> }
 */
export const DELETE = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("collections"))) {
    return notFound("Collection not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Collection not found.");

  // Authorization-aware fetch: filter by id AND ownerId.
  const existing = await getCollectionForOwner(id, user.id);
  if (!existing) return notFound("Collection not found.");

  // Delete the collection — the schema's cascade handles CollectionItem
  // cleanup automatically (onDelete: Cascade). The underlying Post/Article/
  // Video/Discussion content is NEVER touched.
  await db.collection.delete({ where: { id } });

  return ok({ ok: true, deleted: id });
});

// ── Shared projection ──────────────────────────────────────────────────────
// Duplicated from src/lib/collections/index.ts COLLECTION_SELECT to avoid
// a circular import (the lib's const is the canonical one — keep in sync).
const COLLECTION_DETAIL_SELECT = {
  id: true,
  ownerId: true,
  name: true,
  description: true,
  isPublic: true,
  createdAt: true,
  updatedAt: true,
  owner: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: { select: { items: true } },
} as const satisfies Prisma.CollectionSelect;
