import { apiHandler, ok, notFound, badRequest, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { db } from "@/lib/database";
import {
  getCollectionForOwner,
  reorderItem,
  normalizePositions,
} from "@/lib/collections";

/**
 * PATCH /api/v1/collections/:id/items/:itemId
 * --------------------------------------------
 * Reorder an item to a new position.
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Body: { position: number }  (0-indexed; clamped to [0, itemsCount-1])
 *
 * Behavior (spec §14):
 *   - Loads current ordered item IDs.
 *   - Removes the target item from the list.
 *   - Inserts it at the requested position (clamped to valid bounds).
 *   - Rewrites ALL sibling positions to a clean 0,1,2,... sequence.
 *   - Whole operation runs inside a Prisma transaction (no partial state
 *     on failure).
 *
 * Authorization: OWNER ONLY. Non-owner gets 404 (IDOR-safe).
 *
 * Rate limit: collectionItem (default 60/min).
 *
 * Response: { ok: true, orderedItemIds: string[] }
 *   (the new ordered list of item IDs, useful for client-side state sync)
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("collections"))) {
    return notFound("Collection not found.");
  }

  const { id, itemId } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Collection not found.");
  if (!itemId || typeof itemId !== "string") return notFound("Item not found.");

  // ── Ownership check (IDOR-safe) ─────────────────────────────────────
  const collection = await getCollectionForOwner(id, user.id);
  if (!collection) return notFound("Collection not found.");

  // ── Rate limit ──────────────────────────────────────────────────────
  const rl = await checkRateLimit(
    `collection-item:${user.id}`,
    RATE_LIMITS.collectionItem
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  // ── Validate body ──────────────────────────────────────────────────
  const body = await req.json().catch(() => ({} as unknown));
  const rawPosition = (body as { position?: unknown }).position;
  if (typeof rawPosition !== "number" || !Number.isFinite(rawPosition)) {
    return badRequest("position must be a number");
  }
  const newPosition = Math.floor(rawPosition);

  // ── Reorder (transactional, deterministic) ─────────────────────────
  try {
    const orderedIds = await reorderItem(id, itemId, newPosition, user.id);
    return ok({ ok: true, orderedItemIds: orderedIds });
  } catch (err) {
    // NotFoundError thrown by reorderItem when the item isn't in the collection.
    if (err instanceof Error && err.message.includes("not found")) {
      return notFound("Item not found in this collection.");
    }
    throw err;
  }
});

/**
 * DELETE /api/v1/collections/:id/items/:itemId
 * ---------------------------------------------
 * Remove an item from a collection.
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Authorization: OWNER ONLY. Non-owner gets 404 (IDOR-safe).
 *
 * After deletion, the remaining items' positions are normalized to a
 * clean 0,1,2,... sequence (transactional) so there are no gaps.
 *
 * CRITICAL: deleting a CollectionItem NEVER deletes the underlying content
 * (post/article/video/discussion) — only the "saved bookmark" relationship
 * is removed.
 *
 * Response: { ok: true, deleted: <itemId> }
 */
export const DELETE = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("collections"))) {
    return notFound("Collection not found.");
  }

  const { id, itemId } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Collection not found.");
  if (!itemId || typeof itemId !== "string") return notFound("Item not found.");

  // ── Ownership check (IDOR-safe) ─────────────────────────────────────
  // Filters by id AND ownerId — non-owner gets null → 404.
  const collection = await getCollectionForOwner(id, user.id);
  if (!collection) return notFound("Collection not found.");

  // ── Verify the item belongs to this collection ───────────────────────
  // Authorization-aware query: filter by id AND collectionId. If the item
  // doesn't exist OR belongs to a different collection, return 404 (no
  // leakage).
  const item = await db.collectionItem.findFirst({
    where: { id: itemId, collectionId: id },
    select: { id: true },
  });
  if (!item) return notFound("Item not found in this collection.");

  // ── Delete (cascade-safe: only the CollectionItem row is removed; the
  // underlying content is NEVER touched — no FK in that direction).
  await db.collectionItem.delete({ where: { id: itemId } });

  // ── Normalize remaining positions to 0,1,2,... (no gaps) ───────────
  // Best-effort — if normalization fails (e.g. concurrent reorder), the
  // item is still deleted. The next reorder call will re-normalize.
  try {
    await normalizePositions(id);
  } catch {
    // Non-fatal — positions might have small gaps, but the schema still
    // guarantees uniqueness via @@unique([collectionId, contentType, contentId]).
  }

  // Bump the collection's updatedAt so it re-sorts in the user's list.
  await db.collection.update({
    where: { id },
    data: { updatedAt: new Date() },
  });

  return ok({ ok: true, deleted: itemId });
});
