import { apiHandler, ok, badRequest, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { getSettingNumber } from "@/lib/settings";
import { db } from "@/lib/database";
import {
  countUserCollections,
  serializeCollection,
  type CollectionDTO,
} from "@/lib/collections";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/collections
 * -----------------------
 * List the authenticated user's OWN collections (private + public).
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Auth: requires authenticated + verified user.
 *
 * Query params:
 *   - ?public=true → list only the user's PUBLIC collections (for the
 *     "discover public collections" view + the share flow). Default
 *     false → returns ALL collections owned by the user.
 *   - ?search=<query> → filter by name (case-insensitive contains).
 *
 * Response: { collections: SerializedCollection[] }
 *
 * PERFORMANCE: 1 query, indexed by (ownerId). _count for items via the
 * relation's @@index([collectionId, position]). No N+1.
 *
 * SECURITY: ownerId is ALWAYS derived from the session. The query
 * filters by ownerId = user.id — users can NEVER see another user's
 * private collections. The `?public=true` filter only narrows WITHIN
 * the user's own collections, not across other users' collections.
 * For listing OTHER users' public collections, use the
 * /api/v1/search/all endpoint with `?type=collection` (which only
 * surfaces public collections by other owners).
 */
export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();

  // Feature flag — checked SERVER-SIDE, not just client-side.
  if (!(await isFeatureEnabled("collections"))) {
    return ok({ collections: [] });
  }

  const url = new URL(req.url);
  const onlyPublic = url.searchParams.get("public") === "true";
  const search = (url.searchParams.get("search") ?? "").trim();

  const where: Prisma.CollectionWhereInput = { ownerId: user.id };
  if (onlyPublic) where.isPublic = true;
  if (search.length >= 2) {
    where.name = { contains: search, mode: "insensitive" };
  }

  const collections = await db.collection.findMany({
    where,
    orderBy: { updatedAt: "desc" },
    take: 100, // safety cap — a single user shouldn't have > 100 collections
    select: COLLECTION_LIST_SELECT,
  });

  return ok({
    collections: collections.map((c) =>
      serializeCollection(c as CollectionDTO)
    ),
  });
});

/**
 * POST /api/v1/collections
 * ------------------------
 * Create a new collection owned by the authenticated user.
 *
 * Phase 5 — Collections. Gated by the `collections` feature flag.
 *
 * Body: { name: string, description?: string, isPublic?: boolean }
 *
 * Validation:
 *   - name required, trimmed, length 1..collection.max_name_length (default 100).
 *   - description optional, length 0..collection.max_description_length (default 500).
 *   - isPublic optional, boolean only (default false).
 *   - ownerId is NEVER accepted from the client — always derived from session.
 *
 * Limits:
 *   - max_per_user (default 100) — enforced before insert. Returns 409
 *     "Collection limit reached" when the user has too many collections.
 *
 * Rate limit: collection-create (default 20/minute) — prevents spam.
 *
 * Response: { collection: SerializedCollection }
 */
export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("collections"))) {
    return badRequest("Collections feature is disabled.");
  }

  const rl = await checkRateLimit(
    `collection-create:${user.id}`,
    RATE_LIMITS.collectionCreate
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await req.json().catch(() => ({} as unknown));
  const rawName = (body as { name?: unknown })?.name;
  const rawDescription = (body as { description?: unknown })?.description;
  const rawIsPublic = (body as { isPublic?: unknown })?.isPublic;

  // ── Validate name ──────────────────────────────────────────────────
  if (typeof rawName !== "string") {
    return badRequest("name is required");
  }
  const name = rawName.trim();
  if (name.length === 0) {
    return badRequest("name cannot be empty");
  }
  const maxNameLength = (await getSettingNumber("collection.max_name_length")) ?? 100;
  if (name.length > maxNameLength) {
    return badRequest(`name must be at most ${maxNameLength} characters`);
  }

  // ── Validate description ──────────────────────────────────────────
  let description: string | null = null;
  if (rawDescription !== undefined && rawDescription !== null) {
    if (typeof rawDescription !== "string") {
      return badRequest("description must be a string");
    }
    const trimmed = rawDescription.trim();
    const maxDescLength =
      (await getSettingNumber("collection.max_description_length")) ?? 500;
    if (trimmed.length > maxDescLength) {
      return badRequest(
        `description must be at most ${maxDescLength} characters`
      );
    }
    description = trimmed.length > 0 ? trimmed : null;
  }

  // ── Validate isPublic ─────────────────────────────────────────────
  let isPublic = false;
  if (rawIsPublic !== undefined) {
    if (typeof rawIsPublic !== "boolean") {
      return badRequest("isPublic must be a boolean");
    }
    isPublic = rawIsPublic;
  }

  // ── Enforce per-user collection limit ─────────────────────────────
  const maxPerUser =
    (await getSettingNumber("collection.max_per_user")) ?? 100;
  const currentCount = await countUserCollections(user.id);
  if (currentCount >= maxPerUser) {
    return badRequest(
      `Collection limit reached (${maxPerUser} per user). Delete a collection before creating a new one.`
    );
  }

  // ── Insert ─────────────────────────────────────────────────────────
  const collection = await db.collection.create({
    data: {
      ownerId: user.id,
      name,
      description,
      isPublic,
    },
    select: COLLECTION_LIST_SELECT,
  });

  return ok({ collection: serializeCollection(collection as CollectionDTO) });
});

// ── Shared projection ──────────────────────────────────────────────────────
// Reused by GET + POST + the [id] route + the items routes. Mirrors the
// COLLECTION_SELECT constant in src/lib/collections/index.ts — duplicated
// here as a route-local constant to avoid an import-cycle with the lib
// (the lib's COLLECTION_SELECT is `satisfies Prisma.CollectionSelect`,
// which makes it a value, not a type — it CAN be imported, but the route
// also needs the type, so we just re-declare the const here. Both must
// stay in sync; the lib version is the canonical one.)
const COLLECTION_LIST_SELECT = {
  id: true,
  ownerId: true,
  name: true,
  description: true,
  isPublic: true,
  createdAt: true,
  updatedAt: true,
  owner: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: { select: { items: true } },
} as const satisfies Prisma.CollectionSelect;
