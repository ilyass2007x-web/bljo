import { apiHandler, badRequest, ok, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { searchUsers } from "@/lib/messaging";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";

export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  const rl = await checkRateLimit(`search:user:${user.id}`, RATE_LIMITS.search);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const url = new URL(req.url);
  const q = url.searchParams.get("q") ?? "";
  if (q.trim().length < 2) {
    return badRequest("Query must be at least 2 characters");
  }

  const results = await searchUsers(q, 10, user.id);
  return ok({ users: results });
});
