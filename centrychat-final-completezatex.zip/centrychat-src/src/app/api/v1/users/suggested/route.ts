import { apiHandler, ok } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * GET /api/v1/users/suggested
 * ---------------------------
 * Returns a small list of users the current user might want to follow.
 *
 * Used by the Home Feed's "Who to follow" section when the feed is empty
 * (no follows + no own posts) OR as a persistent suggestion strip.
 *
 * Auth: requires authenticated + verified user.
 *
 * Algorithm (kept intentionally simple for Phase 8):
 *   - Exclude the current user (you can't follow yourself).
 *   - Exclude users the current user already follows (no duplicate suggestions).
 *   - Order by follower count DESC (popular users first) — this is a
 *     cheap proxy for "interesting accounts" without needing a
 *     recommendation algorithm. We use the existing @@index([followingId])
 *     on Follow to power the COUNT(*) per user.
 *   - Limit to 5 results (small enough to fit in a sidebar/strip, large
 *     enough to give the user a choice).
 *   - Only suggest ACTIVE users (skip suspended/banned/pending).
 *
 * Performance:
 *   - We fetch the current user's followed IDs in ONE query.
 *   - We fetch candidate users (ACTIVE, not self, not already followed) in
 *     ONE query with their _count.followers for ordering.
 *   - Total: 2 queries, regardless of how many users exist in the DB.
 *
 * Future enhancement:
 *   - When the recommendation algorithm is added (Phase 9+), this endpoint
 *     can be upgraded to use interest-based scoring, mutual follows, etc.
 *     The response shape stays the same so the UI doesn't need to change.
 *
 * Response: { users: SuggestedUserDTO[] }
 */
export const GET = apiHandler(async () => {
  const user = await requireVerifiedUser();

  // Fetch the IDs of users the current user already follows (to exclude them).
  const followed = await db.follow.findMany({
    where: { followerId: user.id },
    select: { followingId: true },
  });
  const followedIds = new Set(followed.map((f) => f.followingId));
  followedIds.add(user.id); // exclude self too

  // Fetch candidate users ordered by follower count DESC.
  // We use _count.followers for the sort — Prisma compiles this into a
  // single SQL with a LEFT JOIN + GROUP BY + ORDER BY COUNT(*) DESC.
  // take: 5 keeps the result set small.
  const candidates = await db.user.findMany({
    where: {
      id: { notIn: [...followedIds] },
      status: "ACTIVE",
    },
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
      bio: true,
      _count: {
        select: {
          followers: true,
          following: true,
        },
      },
    },
    orderBy: {
      followers: { _count: "desc" },
    },
    take: 5,
  });

  // Compute isFollowing + isFollowedBy for each candidate.
  // We already know isFollowing = false (we excluded followed users above).
  // isFollowedBy = does this candidate follow the current user? Batch query.
  const candidateIds = candidates.map((c) => c.id);
  const followedBySet = candidateIds.length > 0
    ? new Set(
        (
          await db.follow.findMany({
            where: { followerId: { in: candidateIds }, followingId: user.id },
            select: { followerId: true },
          })
        ).map((f) => f.followerId)
      )
    : new Set<string>();

  const users = candidates.map((c) => ({
    id: c.id,
    fullName: c.fullName,
    username: c.username,
    avatarColor: c.avatarColor,
    avatarUrl: c.avatarUrl,
    isVerified: c.isVerified,
    bio: c.bio,
    followersCount: c._count.followers,
    followingCount: c._count.following,
    isFollowing: false, // we excluded already-followed users
    isFollowedBy: followedBySet.has(c.id),
  }));

  return ok({ users });
});
