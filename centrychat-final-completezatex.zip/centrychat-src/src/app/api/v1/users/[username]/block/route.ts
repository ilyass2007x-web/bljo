import { apiHandler, ok, badRequest, rateLimited, notFound } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";

/**
 * POST /api/v1/users/[username]/block
 * ------------------------------------
 * Block a user. Prevents them from messaging you + from being matched
 * with you in video chat.
 *
 * Side effects:
 *   - Deletes any existing Follow in BOTH directions (blocker→blocked AND blocked→blocker).
 *   - The blocked user is NOT notified (silent block).
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { username } = await ctx.params;
  if (!username || typeof username !== "string") return notFound("User not found.");

  const rl = await checkRateLimit(`block:${user.id}`, RATE_LIMITS.follow);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  // Find the target user by username (case-insensitive).
  const target = await db.user.findUnique({
    where: { username: username.toLowerCase() },
    select: { id: true },
  });
  if (!target) return notFound("User not found.");

  // Self-protection.
  if (target.id === user.id) return badRequest("You cannot block yourself.");

  // Check if already blocked (idempotent).
  const existing = await db.block.findUnique({
    where: { blockerId_blockedId: { blockerId: user.id, blockedId: target.id } },
    select: { id: true },
  });
  if (existing) return ok({ blocked: true, alreadyBlocked: true });

  // Create the block + delete follows in both directions.
  await db.$transaction([
    db.block.create({
      data: { blockerId: user.id, blockedId: target.id },
    }),
    db.follow.deleteMany({
      where: { OR: [
        { followerId: user.id, followingId: target.id },
        { followerId: target.id, followingId: user.id },
      ] },
    }),
  ]);

  return ok({ blocked: true });
});

/**
 * DELETE /api/v1/users/[username]/block
 * --------------------------------------
 * Unblock a user.
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { username } = await ctx.params;
  if (!username || typeof username !== "string") return notFound("User not found.");

  const target = await db.user.findUnique({
    where: { username: username.toLowerCase() },
    select: { id: true },
  });
  if (!target) return notFound("User not found.");

  await db.block.deleteMany({
    where: { blockerId: user.id, blockedId: target.id },
  });

  return ok({ unblocked: true });
});
