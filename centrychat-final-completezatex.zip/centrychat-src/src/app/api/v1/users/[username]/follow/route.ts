import { apiHandler, ok, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { followUser, unfollowUser } from "@/lib/follow";
import { db } from "@/lib/database";
import { isFeatureEnabled } from "@/lib/features";

/**
 * POST /api/v1/users/:username/follow — follow a user
 */
export const POST = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const rl = await checkRateLimit(`follow:${user.id}`, RATE_LIMITS.follow);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));
  if (!(await isFeatureEnabled("follow_system"))) {
    return ok({ following: false, disabled: true });
  }
  const { username } = await ctx.params;
  const target = await db.user.findUnique({
    where: { username: username.toLowerCase().trim() },
    select: { id: true },
  });
  if (!target) return ok({ following: false });
  const result = await followUser(user.id, target.id);
  return ok(result);
});

/**
 * DELETE /api/v1/users/:username/follow — unfollow a user
 */
export const DELETE = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { username } = await ctx.params;
  const target = await db.user.findUnique({
    where: { username: username.toLowerCase().trim() },
    select: { id: true },
  });
  if (!target) return ok({ following: false });
  const result = await unfollowUser(user.id, target.id);
  return ok(result);
});
