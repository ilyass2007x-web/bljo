import { apiHandler, ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * GET /api/v1/users/:username/followers — list who follows this user
 * Includes isFollowing + isFollowedBy for each user (for FollowButton).
 */
export const GET = apiHandler(async (req, ctx) => {
  const { username } = await ctx.params;
  const url = new URL(req.url);
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(50, Number(url.searchParams.get("pageSize") ?? "20"));

  const target = await db.user.findUnique({
    where: { username: username.toLowerCase().trim() },
    select: { id: true },
  });
  if (!target) return ok({ users: [], total: 0 });

  const [rows, total] = await Promise.all([
    db.follow.findMany({
      where: { followingId: target.id },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        follower: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatarColor: true,
            avatarUrl: true,
            isVerified: true,
            bio: true,
          },
        },
      },
    }),
    db.follow.count({ where: { followingId: target.id } }),
  ]);

  // Get the current viewer to calculate follow relationships.
  const viewer = await getCurrentUser();
  const userIds = rows.map((r) => r.follower.id);

  let followsSet = new Set<string>();
  let followedBySet = new Set<string>();
  if (viewer && userIds.length > 0) {
    const viewerFollows = await db.follow.findMany({
      where: { followerId: viewer.id, followingId: { in: userIds } },
      select: { followingId: true },
    });
    followsSet = new Set(viewerFollows.map((f) => f.followingId));

    const followedBy = await db.follow.findMany({
      where: { followerId: { in: userIds }, followingId: viewer.id },
      select: { followerId: true },
    });
    followedBySet = new Set(followedBy.map((f) => f.followerId));
  }

  return ok({
    users: rows.map((r) => ({
      ...r.follower,
      isFollowing: followsSet.has(r.follower.id),
      isFollowedBy: followedBySet.has(r.follower.id),
    })),
    total,
    page,
    pageSize,
  });
});
