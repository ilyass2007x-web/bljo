import { apiHandler, ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import {
  listUserPlaylistsForViewer,
  serializePlaylist,
  type PlaylistDTO,
} from "@/lib/playlists";

/**
 * GET /api/v1/users/:username/playlists
 * -------------------------------------
 * List a user's playlists for a viewer (the public Profile use-case).
 *
 * PUBLIC endpoint — anonymous viewers can call it (they see only public
 * playlists; this is the FIX for the previous bug where visiting a
 * non-owner's Profile showed ZERO playlists even when public ones
 * existed).
 *
 * Visibility (IDOR-safe, enforced server-side):
 *   - When `viewer` is the owner of the playlists → returns ALL their
 *     playlists (public + private).
 *   - When `viewer` is NOT the owner (or anonymous) → returns ONLY the
 *     owner's PUBLIC playlists. Private playlists are filtered at the
 *     DB level — they're never even read from disk.
 *   - Admins (role === ADMIN / SUPER_ADMIN) see all playlists (read-only
 *     — they can't mutate via this endpoint).
 *
 * Query params:
 *   - ?limit=<n>  (default 100, max 200)
 *
 * Response: { playlists: SerializedPlaylist[] }
 *
 * SECURITY:
 *   - The viewer is derived from the session — never trusted from the
 *     client body / query string.
 *   - The `ownerUsername` is the URL-visible identifier (publicly
 *     known — usernames are shown on the public profile page).
 *   - The visibility filter is applied in the Prisma WHERE clause —
 *     not in post-processing. This is defense-in-depth: even if the
 *     client tried to bypass the check (impossible), the DB query
 *     itself would return only the allowed rows.
 *   - Feature flag `playlists` gates this endpoint. When OFF, returns
 *     an empty list (same behavior as the existing /api/v1/playlists).
 */
export const GET = apiHandler(async (req, ctx) => {
  // GET is viewer-friendly: a logged-out visitor can view public playlists
  // (so the public Profile screen works for anonymous referrers + Google
  // indexing).
  const viewer = await getCurrentUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return ok({ playlists: [] });
  }

  const { username } = await ctx.params;
  if (!username || typeof username !== "string") {
    return ok({ playlists: [] });
  }

  // Decode the URL-encoded username (e.g. spaces, special chars).
  const ownerUsername = decodeURIComponent(username);

  const url = new URL(req.url);
  const limit = Math.min(
    Math.max(Number(url.searchParams.get("limit") ?? "100"), 1),
    200
  );

  const playlists = await listUserPlaylistsForViewer(ownerUsername, viewer, {
    limit,
  });

  return ok({
    playlists: playlists.map((p: PlaylistDTO) => serializePlaylist(p)),
  });
});
