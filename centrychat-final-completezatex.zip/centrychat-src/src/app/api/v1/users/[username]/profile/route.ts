import { apiHandler, ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { getProfileByUsername } from "@/lib/follow";

/**
 * GET /api/v1/users/:username/profile
 * Returns the public profile of a user by their @username.
 */
export const GET = apiHandler(async (_req, ctx) => {
  const { username } = await ctx.params;
  const viewer = await getCurrentUser();
  const profile = await getProfileByUsername(viewer?.id, username);
  return ok({ profile });
});
