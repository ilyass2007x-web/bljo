import { apiHandler, ok } from "@/lib/api";
import { requireVerifiedUser, getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * GET /api/v1/users/:username/articles
 * List a user's articles. Published articles are public.
 * Drafts are visible only to the author (checked via session).
 *
 * BUG FIX (spec §11-§13): The previous version returned articles WITHOUT
 * the engagement fields (likeCount, commentCount, viewCount, shareCount,
 * isLiked). The ArticleCard component + ArticleActions component expect
 * these fields — when they're undefined, ArticleActions crashes on
 * `article.viewCount.toLocaleString()` → "Something went wrong" error
 * on the Profile page.
 *
 * FIX: Now includes _count for likes/comments/views + batch-computes
 * shareCount (via ArticleInteraction groupBy) + isLiked (via
 * ArticleLike findMany for the current viewer). All batched — no N+1.
 */
export const GET = apiHandler(async (req, ctx) => {
  const viewer = await getCurrentUser();
  const { username } = await ctx.params;

  const target = await db.user.findUnique({
    where: { username: username.toLowerCase().trim() },
    select: { id: true, username: true, status: true },
  });

  if (!target || target.status !== "ACTIVE") {
    return ok({ articles: [] });
  }

  // If the viewer IS the author, include drafts. Otherwise, only published.
  const includeDrafts = viewer?.id === target.id;
  const where = includeDrafts
    ? { authorId: target.id }
    : { authorId: target.id, status: "PUBLISHED" as const };

  const articles = await db.article.findMany({
    where,
    orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
    take: 50,
    select: {
      id: true,
      title: true,
      excerpt: true,
      coverImage: true,
      videoUrl: true,
      // Phase 18 — image presentation config (so the profile article
      // list shows the saved zoom/position chosen by the author).
      imageZoom: true,
      imagePositionX: true,
      imagePositionY: true,
      status: true,
      publishedAt: true,
      readingTime: true,
      author: {
        select: {
          id: true,
          fullName: true,
          username: true,
          avatarColor: true,
          avatarUrl: true,
          isVerified: true,
        },
      },
      _count: {
        select: {
          likes: true,
          comments: true,
          views: true,
        },
      },
    },
  });

  if (articles.length === 0) {
    return ok({ articles: [] });
  }

  // Batch-compute share counts + isLiked for all articles (no N+1).
  const articleIds = articles.map(a => a.id);

  const [shareRows, likedRows] = await Promise.all([
    db.articleInteraction.groupBy({
      by: ["articleId"],
      where: { articleId: { in: articleIds }, type: "SHARE" },
      _count: { _all: true },
    }),
    viewer
      ? db.articleLike.findMany({
          where: { userId: viewer.id, articleId: { in: articleIds } },
          select: { articleId: true },
        })
      : [],
  ]);

  type ShareRow = { articleId: string; _count: { _all: number } };
  const shareMap = new Map((shareRows as any as ShareRow[]).map(s => [s.articleId, s._count._all]));
  const likedSet = new Set((likedRows as any[]).map(l => l.articleId));

  return ok({
    articles: articles.map(a => ({
      id: a.id,
      title: a.title,
      excerpt: a.excerpt,
      coverImage: a.coverImage,
      videoUrl: a.videoUrl,
      // Phase 18 — image presentation config (nullable for old articles).
      imageZoom: a.imageZoom,
      imagePositionX: a.imagePositionX,
      imagePositionY: a.imagePositionY,
      status: a.status,
      publishedAt: a.publishedAt?.toISOString() ?? null,
      readingTime: a.readingTime,
      author: a.author,
      // ENGAGEMENT FIELDS (spec §13 — required by ArticleCard + ArticleActions).
      // Without these, ArticleActions crashes on `article.viewCount.toLocaleString()`.
      likeCount: a._count.likes,
      commentCount: a._count.comments,
      viewCount: a._count.views,
      shareCount: shareMap.get(a.id) ?? 0,
      isLiked: likedSet.has(a.id),
    })),
  });
});
