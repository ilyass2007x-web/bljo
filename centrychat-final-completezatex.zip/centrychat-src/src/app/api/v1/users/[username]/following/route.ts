import { apiHandler, ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * GET /api/v1/users/:username/following — list who this user is following
 * Includes isFollowing + isFollowedBy for each user (for FollowButton).
 */
export const GET = apiHandler(async (req, ctx) => {
  const { username } = await ctx.params;
  const url = new URL(req.url);
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1"));
  const pageSize = Math.min(50, Number(url.searchParams.get("pageSize") ?? "20"));

  const target = await db.user.findUnique({
    where: { username: username.toLowerCase().trim() },
    select: { id: true },
  });
  if (!target) return ok({ users: [], total: 0 });

  const [rows, total] = await Promise.all([
    db.follow.findMany({
      where: { followerId: target.id },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        following: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatarColor: true,
            avatarUrl: true,
            isVerified: true,
            bio: true,
          },
        },
      },
    }),
    db.follow.count({ where: { followerId: target.id } }),
  ]);

  // Get the current viewer to calculate follow relationships.
  const viewer = await getCurrentUser();
  const userIds = rows.map((r) => r.following.id);

  let followsSet = new Set<string>();
  let followedBySet = new Set<string>();
  if (viewer && userIds.length > 0) {
    const viewerFollows = await db.follow.findMany({
      where: { followerId: viewer.id, followingId: { in: userIds } },
      select: { followingId: true },
    });
    followsSet = new Set(viewerFollows.map((f) => f.followingId));

    const followedBy = await db.follow.findMany({
      where: { followerId: { in: userIds }, followingId: viewer.id },
      select: { followerId: true },
    });
    followedBySet = new Set(followedBy.map((f) => f.followerId));
  }

  return ok({
    users: rows.map((r) => ({
      ...r.following,
      isFollowing: followsSet.has(r.following.id),
      isFollowedBy: followedBySet.has(r.following.id),
    })),
    total,
    page,
    pageSize,
  });
});
