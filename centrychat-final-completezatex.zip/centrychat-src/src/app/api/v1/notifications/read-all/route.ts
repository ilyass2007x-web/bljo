import { apiHandler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * POST /api/v1/notifications/read-all
 *
 * Marks ALL of the current user's unread notifications as read in a SINGLE
 * database operation (updateMany). This is the batch approach required by
 * spec §8 — no per-notification requests.
 *
 * Security (spec §7): uses `userId: user.id` from the authenticated session.
 * The `where` clause ensures ONLY the current user's notifications are
 * updated — a malicious user cannot mark someone else's notifications.
 *
 * Sets both `read: true` AND `readAt: new Date()` so the UI can show
 * when the notification was read.
 */
export const POST = apiHandler(async () => {
  const user = await requireUser();
  // Exclude MESSAGE-type from the read-all operation. Message read
  // state is tracked SEPARATELY (via `Message.readAt` + conversation
  // `lastReadAt`). Marking old MESSAGE notifications as read here would
  // NOT affect the Messages badge (which doesn't use the Notification
  // table), but excluding them keeps the data model clean: "read all
  // notifications" means "read all GENERAL notifications" (Follow, Like,
  // Comment, etc.), NOT "read all messages". Per spec §7: "فتح
  // Notifications يجب أن يقرأ فقط Notifications العامة. لا يجب أن
  // يغير: Messages unread count."
  await db.notification.updateMany({
    where: { userId: user.id, read: false, type: { not: "MESSAGE" } },
    data: { read: true, readAt: new Date() },
  });
  return ok({ markedAllRead: true });
});
