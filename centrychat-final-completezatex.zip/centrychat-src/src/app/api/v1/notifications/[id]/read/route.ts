import { apiHandler, notFound, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * Mark a single notification as read. Sets read=true AND readAt=now.
 * The user must own the notification (server-side verified).
 */
export const POST = apiHandler(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;

  // Verify ownership — never trust the client.
  const notification = await db.notification.findUnique({
    where: { id },
  });
  if (!notification || notification.userId !== user.id) {
    return notFound("Notification not found");
  }

  if (!notification.read) {
    await db.notification.update({
      where: { id },
      data: { read: true, readAt: new Date() },
    });
  }

  // Return the notification so the client can navigate to its target.
  return ok({
    notification: {
      id: notification.id,
      type: notification.type,
      targetType: notification.targetType,
      targetId: notification.targetId,
      conversationId: notification.conversationId,
      messageId: notification.messageId,
    },
  });
});

/**
 * Get a single notification (with ownership verification).
 * Used to safely resolve a notification's target before navigating.
 */
export const GET = apiHandler(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;

  const notification = await db.notification.findUnique({
    where: { id },
  });
  if (!notification || notification.userId !== user.id) {
    return notFound("Notification not found");
  }

  return ok({
    notification: {
      id: notification.id,
      type: notification.type,
      title: notification.title,
      message: notification.message,
      read: notification.read,
      readAt: notification.readAt?.toISOString() ?? null,
      targetType: notification.targetType,
      targetId: notification.targetId,
      conversationId: notification.conversationId,
      messageId: notification.messageId,
      senderId: notification.senderId,
      metadata: notification.metadata ? JSON.parse(notification.metadata) : null,
      createdAt: notification.createdAt.toISOString(),
    },
  });
});
