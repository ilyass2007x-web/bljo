import { apiHandler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * GET /api/v1/notifications
 *
 * Returns the user's notifications, hydrated with the sender's public profile
 * (avatar, fullName, username, isVerified) so the Notifications page can render
 * rich notification cards without an extra round-trip per notification.
 *
 * Query params:
 *  - limit     (default 20, max 50)  — page size for infinite scroll
 *  - beforeId  (optional)           — cursor for pagination (createdAt < cursor)
 *  - unread    (optional, "true")    — only return unread notifications
 */
export const GET = apiHandler(async (req) => {
  const user = await requireUser();
  const url = new URL(req.url);
  const onlyUnread = url.searchParams.get("unread") === "true";
  // Pagination — load 20 initially, "load more" via beforeId cursor.
  const limit = Math.min(Number(url.searchParams.get("limit") ?? "20"), 50);
  const beforeId = url.searchParams.get("beforeId");

  // If beforeId is provided, find its createdAt for cursor pagination.
  let cursor: { createdAt: Date } | undefined;
  if (beforeId) {
    const before = await db.notification.findUnique({
      where: { id: beforeId },
      select: { createdAt: true },
    });
    if (before) cursor = { createdAt: before.createdAt };
  }

  const notifications = await db.notification.findMany({
    where: {
      userId: user.id,
      // Exclude MESSAGE-type notifications from the general Notifications
      // list. Message unread state is tracked SEPARATELY via
      // `Message.readAt` + conversation `unreadCount` (see main-nav.tsx).
      // Including MESSAGE-type here would cause double-counting: the user
      // would see the same unread message bump BOTH the Messages badge
      // AND the Notifications badge. Per spec §2: "لا تنشئ Notification
      // داخل Notification/Alerts system" for new messages.
      //
      // Old MESSAGE notifications created before this fix remain in the DB
      // (not deleted) but are simply excluded from this query — they don't
      // inflate the Notifications badge or appear in the list.
      type: { not: "MESSAGE" },
      ...(onlyUnread ? { read: false } : {}),
      ...(cursor ? { createdAt: { lt: cursor.createdAt } } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: limit + 1, // +1 to check if there are more
  });

  const hasMore = notifications.length > limit;
  const items = hasMore ? notifications.slice(0, limit) : notifications;

  // Hydrate sender profiles in a single query (avoid N+1).
  // Only the fields needed to render the notification card.
  const senderIds = Array.from(
    new Set(items.map((n) => n.senderId).filter((id): id is string => !!id))
  );
  const senders = senderIds.length > 0
    ? await db.user.findMany({
        where: { id: { in: senderIds } },
        select: {
          id: true,
          fullName: true,
          username: true,
          avatarColor: true,
          avatarUrl: true,
          isVerified: true,
        },
      })
    : [];
  const senderMap = new Map(senders.map((s) => [s.id, s]));

  // Unread count for the NOTIFICATIONS badge — excludes MESSAGE-type.
  // Message unread state is tracked separately by the Messages badge
  // (via conversation unreadCount, see main-nav.tsx).
  const unreadCount = await db.notification.count({
    where: { userId: user.id, read: false, type: { not: "MESSAGE" } },
  });

  return ok({
    notifications: items.map((n) => {
      const sender = n.senderId ? senderMap.get(n.senderId) : null;
      return {
        id: n.id,
        type: n.type,
        title: n.title,
        message: n.message,
        read: n.read,
        readAt: n.readAt?.toISOString() ?? null,
        targetType: n.targetType,
        targetId: n.targetId,
        conversationId: n.conversationId,
        messageId: n.messageId,
        senderId: n.senderId,
        sender: sender
          ? {
              id: sender.id,
              fullName: sender.fullName,
              username: sender.username,
              avatarColor: sender.avatarColor,
              avatarUrl: sender.avatarUrl,
              isVerified: sender.isVerified,
            }
          : null,
        metadata: n.metadata ? JSON.parse(n.metadata) : null,
        createdAt: n.createdAt.toISOString(),
      };
    }),
    unreadCount,
    hasMore,
  });
});
