import { apiHandler, badRequest, ok, rateLimited } from "@/lib/api";
import { isUsernameAvailable, suggestUsernames } from "@/lib/username";
import { checkRateLimit, RATE_LIMITS, getClientIp } from "@/lib/security/rate-limit";

/**
 * POST /api/v1/username-check
 * ----------------------------
 * Checks if a username is available. Returns suggestions if taken.
 *
 * SECURITY (hardened):
 *   - UNAUTHENTICATED endpoint (used by the registration form). To
 *     prevent username enumeration for credential-stuffing, the
 *     endpoint:
 *       1. Rate-limits per IP (10 requests/10min — generous enough
 *          for a user typing/retyping a username, tight enough to
 *          prevent enumerating the user table).
 *       2. Returns suggestions even when the username is taken — this
 *          is the desired UX (helps the user pick a variant), and
 *          doesn't leak the existing account beyond "this username
 *          is taken" (which is unavoidable for usability).
 *       3. NEVER returns the canonical-case username that's taken
 *          (some platforms return "John is taken, try John123" —
 *          we don't; suggestions are derived from the user's
 *          INPUT, not from the existing account).
 *
 * Response shape is unchanged for backward compatibility with the
 * registration form: `{ available: boolean, suggestions: string[] }`.
 */
export const POST = apiHandler(async (req) => {
  // Rate limit — keyed on IP. 10 checks per 10 minutes is the
  // tightest practical limit (a legitimate user types at most a few
  // usernames before registering). Combined with the form's existing
  // client-side debounce, this is the right shape.
  const ip = getClientIp(req);
  const rl = await checkRateLimit(`username-check:${ip}`, {
    limit: RATE_LIMITS.usernameCheck.limit,
    windowSeconds: RATE_LIMITS.usernameCheck.windowSeconds,
  });
  if (!rl.ok) {
    return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));
  }

  const body = await req.json().catch(() => ({})) as { username?: string };
  const username = (body.username ?? "").toLowerCase().trim();
  if (!username || username.length < 3) {
    return ok({ available: false, reason: "too_short" });
  }

  const available = await isUsernameAvailable(username);
  const suggestions = available ? [] : await suggestUsernames(username);
  return ok({ available, suggestions });
});
