import { apiHandler, badRequest, ok, parseJsonBody, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import {
  getOrCreateDirectConversation,
  listConversations,
} from "@/lib/messaging";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import { isFeatureEnabled } from "@/lib/features";

export const GET = apiHandler(async () => {
  const user = await requireVerifiedUser();
  if (!(await isFeatureEnabled("messaging"))) {
    return ok({ conversations: [] });
  }
  const conversations = await listConversations(user.id);
  return ok({ conversations });
});

export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  if (!(await isFeatureEnabled("messaging"))) {
    return badRequest("Messaging is currently disabled");
  }
  const rl = await checkRateLimit(`conversation:create:${user.id}`, {
    limit: 20,
    windowSeconds: 60,
  });
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await parseJsonBody<{ userId?: string }>(req);
  if (!body.userId) return badRequest("userId is required");

  const target = await db.user.findUnique({ where: { id: body.userId } });
  if (!target) return badRequest("User not found");
  if (target.status !== "ACTIVE" || !target.emailVerified) {
    return badRequest("User is not available");
  }

  const conv = await getOrCreateDirectConversation(user.id, body.userId);
  return ok({ conversation: conv });
});
