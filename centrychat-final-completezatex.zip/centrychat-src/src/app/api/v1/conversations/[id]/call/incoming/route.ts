import { apiHandler, forbidden, ok } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { getActiveCallForConversation } from "@/lib/chat-video-call/store";
import { resolveDirectConversationPeer } from "@/lib/chat-video-call/helpers";
import type { CallPeer } from "@/lib/chat-video-call/types";

/**
 * GET /api/v1/conversations/[id]/call/incoming
 * ==================================================
 *
 * Polling-based fallback for incoming-call detection on Netlify.
 *
 * WHY THIS EXISTS:
 *   The primary incoming-call mechanism is the realtime
 *   `conversation:call:incoming` event broadcast by the realtime
 *   mini-service (socket.io on port 3003 in dev). On Netlify production,
 *   there is NO persistent socket.io service — `broadcastRealtime`
 *   POSTs to `http://localhost:3003/internal/broadcast` (default) which
 *   silently fails (caught + logged). The recipient's `useRealtime` hook
 *   never receives the event → the incoming-call dialog never opens →
 *   the caller stays on "Ringing..." until the 45s ring timeout.
 *
 *   This endpoint provides a polling fallback that the recipient's
 *   messenger calls every ~5s when viewing a conversation. If a call is
 *   active (ringing, unanswered, recipient = current user), the
 *   recipient's UI opens the incoming-call dialog — same as if the
 *   realtime event had fired.
 *
 * DUPLICATE-EVENT HANDLING:
 *   The recipient's UI dedupes by callId (via `incomingCallIdRef` in
 *   ChatVideoCallDialog). If both the realtime event AND this poll fire
 *   for the same callId, only the first opens the dialog.
 *
 * SERVER-SIDE CHECKS:
 *   1. Authentication (requireVerifiedUser — email-verified + ACTIVE)
 *   2. video_chat feature flag enabled
 *   3. Conversation membership (resolveDirectConversationPeer — verifies
 *      the current user is a member of this DIRECT conversation)
 *   4. The active call's recipientId === current user (only the recipient
 *      sees the incoming-call banner — the caller already knows they
 *      initiated it)
 *
 * RESPONSE:
 *   - 200 OK with `{ call: null }` — no pending incoming call.
 *   - 200 OK with `{ call: { callId, caller, expiresAt } }` — there's
 *     an unanswered call from the OTHER user. The recipient's client
 *     opens the incoming-call UI.
 *
 * SECURITY:
 *   - The call is only returned if the current user is the recipient
 *     (NOT the caller — the caller already has the callId from
 *     /call/start's response).
 *   - The conversation membership check prevents a user from polling
 *     arbitrary conversations.
 */
export const GET = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  // DISABLED (TEMPORARY): env var hard kill switch + admin FeatureFlag.
  // Returns 403 immediately — no DB query, no membership resolution.
  // The client's messenger SKIPS the polling entirely when disabled
  // (see the `isVideoChatClientEnabled()` guard at the top of the
  // incoming-call useEffect in messenger.tsx) — so this 403 is just
  // defense-in-depth for a stale client.
  const enabled = await isVideoChatEnabled();
  if (!enabled) {
    return forbidden("Video chat is currently disabled.");
  }

  const { id: conversationId } = await ctx.params;

  // Verify the user is a member of this DIRECT conversation + resolve
  // the OTHER participant (server-side only — the body never tells us
  // who the peer is).
  const peer = await resolveDirectConversationPeer(user.id, conversationId);

  // Check for an active, unanswered call in this conversation where
  // the current user is the recipient.
  const activeCall = await getActiveCallForConversation(conversationId);
  if (!activeCall || activeCall.endedAt !== null) {
    return ok({ call: null });
  }
  // If the current user is the CALLER, they already know about the call
  // (they started it). Don't show it as "incoming" to them.
  if (activeCall.callerId === user.id) {
    return ok({ call: null });
  }
  // If the current user is NOT the recipient (shouldn't happen after the
  // membership check, but defense in depth), don't show it.
  if (activeCall.recipientId !== user.id) {
    return ok({ call: null });
  }
  // If the call has already been accepted, it's no longer "incoming".
  // The recipient either accepted (they're in the call) or rejected
  // (the call would have endedAt set). Either way, no incoming UI.
  if (activeCall.acceptedAt !== null) {
    return ok({ call: null });
  }
  // If the call has expired (ringing > 45s), don't show it.
  if (Date.now() > activeCall.expiresAt) {
    return ok({ call: null });
  }

  // Build the caller summary — the recipient's UI needs this to render
  // the incoming-call dialog without an extra fetch.
  const caller: CallPeer = {
    id: peer.recipient.id,
    fullName: peer.recipient.fullName,
    username: peer.recipient.username,
    avatarColor: peer.recipient.avatarColor,
    avatarUrl: peer.recipient.avatarUrl,
    isVerified: peer.recipient.isVerified,
  };

  return ok({
    call: {
      callId: activeCall.callId,
      conversationId: activeCall.conversationId,
      caller,
      expiresAt: activeCall.expiresAt,
    },
  });
});
