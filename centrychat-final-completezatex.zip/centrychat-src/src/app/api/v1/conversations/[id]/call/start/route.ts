import { apiHandler, badRequest, forbidden, ok, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { checkRateLimit } from "@/lib/security/rate-limit";
import { broadcastRealtime } from "@/lib/realtime/server";
import { db } from "@/lib/database";
import {
  createCall,
  createCallId,
  getActiveCallForConversation,
  RING_TIMEOUT_MS,
} from "@/lib/chat-video-call/store";
import {
  resolveDirectConversationPeer,
  buildCallerSummary,
} from "@/lib/chat-video-call/helpers";

/**
 * POST /api/v1/conversations/[id]/call/start
 * -------------------------------------------
 * Initiates a chat video call.
 *
 * Server-side checks:
 *   1. Authentication (requireVerifiedUser — email-verified + ACTIVE)
 *   2. video_chat feature flag enabled
 *   3. Rate limit (10 call starts per minute per user — same as video-chat queue)
 *   4. Conversation membership (resolveDirectConversationPeer)
 *   5. Conversation is DIRECT (1:1)
 *   6. No existing active call in this conversation ("busy")
 *
 * Returns: { callId, expiresAt, recipient } so the caller can render
 * the "ringing" UI immediately.
 *
 * Realtime: broadcasts `conversation:call:incoming` to the recipient
 * so their messenger opens the incoming-call UI without polling.
 */
export const POST = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();

  // DISABLED (TEMPORARY): env var hard kill switch + admin FeatureFlag.
  // Returns 403 immediately — no DB query, no rate-limit increment, no
  // realtime broadcast. The caller's UI shows "Video chat is currently
  // disabled." instead of "Calling...". The signal store + Redis cache
  // + chat-call helpers are all preserved.
  const enabled = await isVideoChatEnabled();
  if (!enabled) return forbidden("Video chat is currently disabled.");

  const rl = await checkRateLimit(
    `chat-call:start:${user.id}`,
    { limit: 10, windowSeconds: 60 } // 10 call starts/min per user (same as video-chat queue)
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const { id: conversationId } = await ctx.params;

  // Verify membership + resolve the other participant (server-side only).
  const peer = await resolveDirectConversationPeer(user.id, conversationId);

  // Refuse to call suspended/banned recipients.
  if (peer.recipient.status !== "ACTIVE") {
    return badRequest("This user is not available for calls right now.");
  }

  // Check for an existing active call in this conversation.
  // PHASE 3 FIX: store functions are now async (shared Redis-backed cache).
  const existing = await getActiveCallForConversation(conversationId);
  if (existing && existing.endedAt === null && Date.now() < existing.expiresAt) {
    // If the existing call is THIS user's (caller already has an outgoing
    // call in progress), return the existing callId so they can resume.
    if (existing.callerId === user.id && existing.acceptedAt === null) {
      return ok({
        callId: existing.callId,
        expiresAt: existing.expiresAt,
        recipient: peer.recipient,
        status: "ringing",
      });
    }
    // Otherwise the line is busy.
    return ok({
      callId: null,
      status: "busy",
    });
  }

  const callId = createCallId();
  const call = await createCall({
    callId,
    conversationId,
    callerId: user.id,
    recipientId: peer.recipientId,
  });
  if (!call) {
    return ok({ callId: null, status: "busy" });
  }

  // Hydrate caller info for the realtime payload (single DB hit).
  const callerRow = await db.user.findUnique({
    where: { id: user.id },
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  });
  if (!callerRow) return badRequest("Caller account not found.");

  // Broadcast the incoming call to the recipient (realtime).
  // Payload is self-contained so the recipient's client doesn't need
  // to fetch any additional data to render the incoming-call UI.
  await broadcastRealtime({
    event: "conversation:call:incoming",
    payload: {
      callId,
      conversationId,
      caller: buildCallerSummary(callerRow),
      expiresAt: call.expiresAt,
    },
    recipientIds: [peer.recipientId],
  });

  return ok({
    callId,
    expiresAt: call.expiresAt,
    recipient: peer.recipient,
    status: "ringing",
    ringTimeoutMs: RING_TIMEOUT_MS,
  });
});
