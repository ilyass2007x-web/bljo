import { apiHandler, notFound, ok } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";

export const GET = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  const membership = await db.conversationMember.findFirst({
    where: { conversationId: id, userId: user.id, leftAt: null },
    include: {
      conversation: {
        include: {
          members: { include: { user: true } },
        },
      },
    },
  });
  if (!membership) return notFound("Conversation not found");
  const conv = membership.conversation;
  const others = conv.members.filter((m) => m.userId !== user.id);
  return ok({
    conversation: {
      id: conv.id,
      type: conv.type,
      title: conv.title ?? others[0]?.user.fullName ?? "Conversation",
      members: conv.members.map((m) => ({
        userId: m.userId,
        fullName: m.user.fullName,
        avatarColor: m.user.avatarColor,
        role: m.user.role,
        status: m.user.status,
      })),
      createdAt: conv.createdAt.toISOString(),
      updatedAt: conv.updatedAt.toISOString(),
    },
  });
});
