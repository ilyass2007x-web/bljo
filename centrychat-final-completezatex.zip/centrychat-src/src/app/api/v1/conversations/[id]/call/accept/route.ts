import { apiHandler, badRequest, forbidden, notFound, ok, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { checkRateLimit } from "@/lib/security/rate-limit";
import { broadcastRealtime } from "@/lib/realtime/server";
import { acceptCall, getCall } from "@/lib/chat-video-call/store";

/**
 * POST /api/v1/conversations/[id]/call/accept
 * -------------------------------------------
 * The recipient accepts an incoming chat video call.
 *
 * Server-side checks:
 *   1. Authentication (requireVerifiedUser)
 *   2. Feature flag enabled
 *   3. Rate limit (60/min per user)
 *   4. Call exists + recipient is THIS user
 *   5. Call has not ended
 *
 * Realtime: broadcasts `conversation:call:event` with action="accept"
 * to the caller so they transition from "calling" → "connecting" and
 * start WebRTC negotiation.
 *
 * Body: { callId }
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  // DISABLED (TEMPORARY): env var hard kill switch + admin FeatureFlag.
  // Returns 403 immediately — no DB query, no acceptCall mutation, no
  // realtime broadcast. The caller's ring eventually times out
  // (RING_TIMEOUT_MS) and they see "No answer."
  const enabled = await isVideoChatEnabled();
  if (!enabled) return forbidden("Video chat is currently disabled.");

  const rl = await checkRateLimit(`chat-call:accept:${user.id}`, {
    limit: 60,
    windowSeconds: 60,
  });
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const { id: conversationId } = await ctx.params;
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const callId = typeof body.callId === "string" ? body.callId : "";
  if (!callId) return badRequest("callId is required.");

  // PHASE 3 FIX: store functions are now async (shared Redis-backed cache).
  const call = await getCall(callId);
  if (!call) return notFound("Call not found or has expired.");
  if (call.conversationId !== conversationId) {
    return badRequest("Call does not belong to this conversation.");
  }
  if (call.recipientId !== user.id) {
    return forbidden("Only the call recipient can accept.");
  }
  if (call.endedAt !== null) {
    return badRequest("Call has already ended.");
  }

  const accepted = await acceptCall(callId, user.id);
  if (!accepted) return badRequest("Could not accept call.");

  // Notify the caller that the recipient accepted. The caller will then
  // start the WebRTC negotiation by sending an offer.
  await broadcastRealtime({
    event: "conversation:call:event",
    payload: {
      callId,
      conversationId,
      action: "accept",
      byUserId: user.id,
    },
    recipientIds: [call.callerId],
  });

  return ok({ callId, status: "accepted" });
});
