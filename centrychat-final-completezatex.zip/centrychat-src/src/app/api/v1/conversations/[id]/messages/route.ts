import { apiHandler, badRequest, ok, parseJsonBody, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { listMessages, sendMessage } from "@/lib/messaging";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { isFeatureEnabled } from "@/lib/features";
import { broadcastRealtime } from "@/lib/realtime/server";

export const GET = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  const url = new URL(req.url);
  const beforeId = url.searchParams.get("beforeId") ?? undefined;
  const limit = Number(url.searchParams.get("limit") ?? "50");

  const messages = await listMessages(user.id, id, { beforeId, limit });
  return ok({ messages });
});

export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  if (!(await isFeatureEnabled("messaging"))) {
    return badRequest("Messaging is currently disabled");
  }
  const rl = await checkRateLimit(`message:send:${user.id}`, RATE_LIMITS.messageSend);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await parseJsonBody<{ content?: string }>(req);
  if (!body.content) return badRequest("content is required");

  const message = await sendMessage(user.id, id, body.content);

  // ── SEPARATE MESSAGE BADGE FROM NOTIFICATIONS BADGE ──────────────
  // We NO LONGER create a Notification row for new messages. The message
  // unread state is already tracked by `Message.readAt = null` (unread)
  // + the conversation's `unreadCount` (sum of messages where
  // `senderId != userId && readAt == null && createdAt > lastReadAt`).
  //
  // The Messages badge in main-nav.tsx fetches `/api/v1/conversations` and
  // sums up each conversation's `unreadCount`. The Notifications badge
  // fetches `/api/v1/notifications` which now excludes `type: "MESSAGE"`
  // from its unread count.
  //
  // Before this fix, `notifyMessageReceived()` created a Notification row
  // with `type: "MESSAGE"` — which inflated BOTH the Messages badge
  // (via conversation unreadCount) AND the Notifications badge (via
  // Notification unread count). That's why the user saw:
  //   Messages 🔴 1
  //   Notifications 🔴 1
  // After this fix, the user sees:
  //   Messages 🔴 1
  //   Notifications (no badge)
  //
  // Old MESSAGE-type notifications that were created before this fix
  // remain in the DB (we do NOT delete them — per spec §3 "لا تحذف
  // البيانات القديمة مباشرة"). They are simply excluded from the
  // notification unread count + list (see notifications/route.ts).

  // Broadcast the new message via realtime to all recipients (other members
  // of the conversation) AND to the sender's OTHER tabs/devices. The
  // sender's main tab already has the optimistic message (added instantly
  // in sendMessage() — see src/components/messenger/messenger.tsx); we
  // include the sender here so their OTHER tabs receive the message too.
  // The client dedupes by message ID — the optimistic temp placeholder is
  // replaced by the real message when the POST response arrives, and a
  // realtime event arriving in the meantime is deduped against the real ID.
  await broadcastRealtime({
    event: "message:new",
    payload: message,
    recipientIds: [...message.recipientIds, user.id],
  });

  return ok({ message });
});
