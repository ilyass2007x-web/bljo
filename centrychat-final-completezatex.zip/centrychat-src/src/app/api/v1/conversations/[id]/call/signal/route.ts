import { apiHandler, badRequest, forbidden, notFound, ok, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { checkRateLimit } from "@/lib/security/rate-limit";
import { getCall, popSignals, pushSignal, serializeSignal } from "@/lib/chat-video-call/store";

/**
 * Chat Video Call Signaling — REST-based (no WebSocket)
 * =======================================================
 *
 * Mirrors the existing /api/v1/video-chat/signal/route.ts pattern,
 * but scoped to conversation calls (callId) instead of queue sessions.
 *
 * Flow (caller = offerer, recipient = answerer):
 *   1. Recipient accepts → caller hears "accept" via realtime.
 *   2. Caller POSTs { type: "offer", sdp } → stored, recipient polls.
 *   3. Recipient GETs signals → receives offer, creates answer.
 *   4. Recipient POSTs { type: "answer", sdp } → stored, caller polls.
 *   5. Caller GETs signals → receives answer.
 *   6. Both POST { type: "ice", candidate } → stored.
 *   7. Both GET signals → receive ICE candidates.
 *   8. Either POSTs { type: "end" } → other side polls + tears down.
 *
 * PHASE 3 FIX: The signal store is now backed by the project's shared
 * cache abstraction (Redis/Upstash REST in production, in-memory in
 * dev). The previous per-process Map was unsuitable for Netlify
 * serverless — POST landed on Instance #X, GET polled Instance #Y,
 * the offer/answer/ICE candidates never reached the other peer.
 *
 * ── POST /api/v1/conversations/[id]/call/signal ──
 * Body: { callId, type: "offer"|"answer"|"ice"|"end", payload }
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  // DISABLED (TEMPORARY): env var hard kill switch + admin FeatureFlag.
  // Returns 403 immediately — no DB query, no signal push. Stale clients
  // (from a call started before disable) get a clean 403; the `end`
  // route is NOT blocked so they can still hang up.
  const enabled = await isVideoChatEnabled();
  if (!enabled) return forbidden("Video chat is currently disabled.");

  const rl = await checkRateLimit(`chat-call:signal:${user.id}`, {
    limit: 120,
    windowSeconds: 60, // same as video-chat/signal — allows 2 signals/sec
  });
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const { id: conversationId } = await ctx.params;
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const callId = typeof body.callId === "string" ? body.callId : "";
  const type = typeof body.type === "string" ? body.type : "";
  const payload = body.payload;

  if (!callId || !type) return badRequest("callId + type are required.");
  if (!["offer", "answer", "ice", "end"].includes(type)) {
    return badRequest("Invalid signal type.");
  }

  // PHASE 3 FIX: store functions are now async (shared Redis-backed cache).
  const call = await getCall(callId);
  if (!call) return notFound("Call not found or has expired.");
  if (call.conversationId !== conversationId) {
    return badRequest("Call does not belong to this conversation.");
  }
  // Only offer/answer/ice are gated on accepted state. "end" is allowed
  // at any point so a caller can cancel mid-negotiation.
  if (type !== "end") {
    if (call.endedAt !== null) return badRequest("Call has ended.");
    if (call.acceptedAt === null) {
      return badRequest("Call has not been accepted yet.");
    }
  }
  // Verify the sender is a participant.
  const isCaller = call.callerId === user.id;
  const isRecipient = call.recipientId === user.id;
  if (!isCaller && !isRecipient) {
    return forbidden("You are not a participant in this call.");
  }
  const toUserId = isCaller ? call.recipientId : call.callerId;

  await pushSignal({
    callId,
    fromUserId: user.id,
    toUserId,
    type: type as "offer" | "answer" | "ice" | "end",
    payload,
  });

  return ok({ sent: true });
});

/**
 * ── GET /api/v1/conversations/[id]/call/signal?callId=... ──
 * Polls for signals addressed to the current user.
 * Returns ALL pending signals for this user in this call, then clears
 * them (no double-delivery).
 */
export const GET = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  // DISABLED (TEMPORARY): same gate as POST. Stale polling clients get
  // 403, their existing catch branch swallows it as non-fatal.
  const enabled = await isVideoChatEnabled();
  if (!enabled) return forbidden("Video chat is currently disabled.");

  const { id: conversationId } = await ctx.params;
  const url = new URL(req.url);
  const callId = url.searchParams.get("callId") || "";
  if (!callId) return badRequest("callId is required.");

  // PHASE 3 FIX: store functions are now async (shared Redis-backed cache).
  const call = await getCall(callId);
  if (!call) return notFound("Call not found or has expired.");
  if (call.conversationId !== conversationId) {
    return badRequest("Call does not belong to this conversation.");
  }
  const isParticipant = call.callerId === user.id || call.recipientId === user.id;
  if (!isParticipant) return forbidden("You are not a participant in this call.");

  const mine = await popSignals(callId, user.id);

  return ok({
    signals: mine.map(serializeSignal),
    callState: {
      acceptedAt: call.acceptedAt,
      endedAt: call.endedAt,
      expiresAt: call.expiresAt,
    },
  });
});
