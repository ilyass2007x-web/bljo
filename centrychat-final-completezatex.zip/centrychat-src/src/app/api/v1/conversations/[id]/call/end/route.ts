import { apiHandler, badRequest, forbidden, notFound, ok, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnvEnabled } from "@/lib/video-chat/enabled";
import { checkRateLimit } from "@/lib/security/rate-limit";
import { broadcastRealtime } from "@/lib/realtime/server";
import { endCall, getCall, pushSignal } from "@/lib/chat-video-call/store";

/**
 * POST /api/v1/conversations/[id]/call/end
 * ----------------------------------------
 * Either party ends the call.
 *
 * Server-side checks:
 *   1. Authentication
 *   2. Feature flag enabled
 *   3. Rate limit (30/min per user — end events are rare, but cap to prevent spam)
 *   4. Call exists + user is a participant (caller or recipient)
 *
 * Realtime: broadcasts `conversation:call:event` with action="end" to
 * the OTHER participant so they tear down their WebRTC connection + UI.
 *
 * Also pushes a `type: "end"` WebRTC signal so even if the realtime
 * event is missed (recipient's tab is hidden), the signal poll will
 * pick it up.
 *
 * Body: { callId, reason?: "user_ended" | "timeout" | "rejected" | "busy" }
 *
 * DISABLED (TEMPORARY): This route is ALWAYS ALLOWED, even when Video
 * Chat is disabled. The `end` action is the cleanup path — users who
 * had an active call at the moment of disable must still be able to end
 * it (otherwise their UI is stuck in "Connecting..."). We only check
 * the env var (not the FeatureFlag) for a small performance boost and
 * to avoid the 30s cache TTL delay that could leave callers hanging.
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  // NOTE: NO disabled guard here — `end` is always allowed for cleanup.
  // The env var is read for monitoring/logging only (no behavior change).
  void isVideoChatEnvEnabled();

  const rl = await checkRateLimit(`chat-call:end:${user.id}`, {
    limit: 30,
    windowSeconds: 60,
  });
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const { id: conversationId } = await ctx.params;
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const callId = typeof body.callId === "string" ? body.callId : "";
  const reason = typeof body.reason === "string" ? body.reason : "user_ended";
  if (!callId) return badRequest("callId is required.");

  const call = await getCall(callId);
  if (!call) return notFound("Call not found or has expired.");
  if (call.conversationId !== conversationId) {
    return badRequest("Call does not belong to this conversation.");
  }
  const isCaller = call.callerId === user.id;
  const isRecipient = call.recipientId === user.id;
  if (!isCaller && !isRecipient) {
    return forbidden("Only call participants can end the call.");
  }

  // Mark the call as ended (idempotent — if already ended, returns same call).
  // PHASE 3 FIX: store functions are now async (shared Redis-backed cache).
  await endCall(callId, user.id);

  // Determine the OTHER participant to notify.
  const otherUserId = isCaller ? call.recipientId : call.callerId;

  // Notify the other side via realtime (immediate).
  await broadcastRealtime({
    event: "conversation:call:event",
    payload: {
      callId,
      conversationId,
      action: "end",
      byUserId: user.id,
      reason,
    },
    recipientIds: [otherUserId],
  });

  // Also push a WebRTC "end" signal (defensive — if realtime is unreachable,
  // the signal poll loop will pick this up on the next 500ms tick).
  await pushSignal({
    callId,
    fromUserId: user.id,
    toUserId: otherUserId,
    type: "end",
    payload: { reason },
  });

  return ok({ callId, status: "ended" });
});
