import { apiHandler, badRequest, forbidden, notFound, ok } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { getCall } from "@/lib/chat-video-call/store";

/**
 * GET /api/v1/conversations/[id]/call/status?callId=...
 * -----------------------------------------------------
 * Polls the current state of a chat video call. Used by the caller's
 * "ringing" UI as a fallback in case the realtime event is missed
 * (recipient's tab hidden, network hiccup, etc.).
 *
 * Returns:
 *   {
 *     callState: "ringing" | "accepted" | "ended" | "expired",
 *     acceptedAt, endedAt, expiresAt
 *   }
 *
 * This is a safety-net poll. The primary mechanism is the realtime
 * `conversation:call:event` event. The client polls this at ~2s
 * intervals during the "ringing" phase only.
 */
export const GET = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  // DISABLED (TEMPORARY): env var hard kill switch + admin FeatureFlag.
  // Returns 403 immediately — no DB query. Stale caller polls (from a
  // call started before disable) get a clean 403; their existing catch
  // branch swallows it as non-fatal + they keep polling until the call
  // ring expires server-side.
  const enabled = await isVideoChatEnabled();
  if (!enabled) return forbidden("Video chat is currently disabled.");

  const { id: conversationId } = await ctx.params;
  const url = new URL(req.url);
  const callId = url.searchParams.get("callId") || "";
  if (!callId) return badRequest("callId is required.");

  // PHASE 3 FIX: store functions are now async (shared Redis-backed cache).
  const call = await getCall(callId);
  if (!call) return notFound("Call not found or has expired.");
  if (call.conversationId !== conversationId) {
    return badRequest("Call does not belong to this conversation.");
  }
  const isParticipant = call.callerId === user.id || call.recipientId === user.id;
  if (!isParticipant) return forbidden("You are not a participant in this call.");

  let state: "ringing" | "accepted" | "ended" | "expired";
  if (call.endedAt !== null) state = "ended";
  else if (call.acceptedAt !== null) state = "accepted";
  else if (Date.now() > call.expiresAt) state = "expired";
  else state = "ringing";

  return ok({
    callState: state,
    acceptedAt: call.acceptedAt,
    endedAt: call.endedAt,
    expiresAt: call.expiresAt,
  });
});
