import { apiHandler, ok, notFound } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { assertConversationMember } from "@/lib/messaging";
import { broadcastRealtime } from "@/lib/realtime/server";

/**
 * POST /api/v1/conversations/:id/messages/read
 * ---------------------------------------------
 * Mark ALL unread messages FROM OTHER USERS in this conversation as read.
 *
 * This is a BATCH operation — a single request handles all unread messages
 * from all other members. No per-message requests (spec §10).
 *
 * Security (spec §8, §16):
 *   - Uses `requireVerifiedUser` — must be authenticated.
 *   - Calls `assertConversationMember` — must be a member of this conversation.
 *   - The `where` clause uses `senderId: { not: user.id }` — only marks
 *     messages FROM OTHERS as read, never the user's own messages (spec §11).
 *   - The `userId` comes from the session, NEVER from the request body.
 *
 * Realtime (spec §9):
 *   - After marking messages as read, broadcasts a `message:read` event to
 *     the SENDERS of those messages. This lets the sender see their
 *     checkmarks turn blue (✓✓) in real-time WITHOUT a page refresh.
 *   - The payload includes the conversationId + the readAt timestamp + the
 *     IDs of the senders whose messages were just marked as read (so the
 *     client can filter for the correct conversation).
 *
 * Response: { ok: true, markedRead: number }
 *   - markedRead = how many messages were marked as read (0 if none were unread)
 */
export const POST = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;

  if (!id || typeof id !== "string") {
    return notFound("Conversation not found.");
  }

  // Verify the user is a member of this conversation.
  await assertConversationMember(user.id, id);

  // Find all unread messages FROM OTHER USERS in this conversation.
  // We need the senderIds to broadcast the realtime event.
  const unreadMessages = await db.message.findMany({
    where: {
      conversationId: id,
      senderId: { not: user.id },
      readAt: null,
      deletedAt: null,
    },
    select: { id: true, senderId: true },
  });

  if (unreadMessages.length === 0) {
    return ok({ ok: true, markedRead: 0 });
  }

  // Batch update: mark all as read in a single SQL operation.
  const now = new Date();
  await db.message.updateMany({
    where: {
      id: { in: unreadMessages.map((m) => m.id) },
    },
    data: { readAt: now },
  });

  // Update the member's lastReadAt.
  await db.conversationMember.updateMany({
    where: { conversationId: id, userId: user.id },
    data: { lastReadAt: now },
  });

  // Broadcast a `message:read` realtime event to each unique sender.
  // The payload tells the sender: "your messages in conversation X were
  // just read at time Y". The sender's client uses this to update the
  // checkmarks from ✓ to ✓✓ blue.
  const uniqueSenderIds = [...new Set(unreadMessages.map((m) => m.senderId))];
  const messageIds = unreadMessages.map((m) => m.id);

  for (const senderId of uniqueSenderIds) {
    await broadcastRealtime({
      event: "message:read",
      payload: {
        conversationId: id,
        readAt: now.toISOString(),
        messageIds: messageIds.filter((mid) =>
          unreadMessages.find((m) => m.id === mid && m.senderId === senderId)
        ),
      },
      recipientIds: [senderId],
    });
  }

  return ok({ ok: true, markedRead: unreadMessages.length });
});
