import { apiHandler, ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { buildPublicAdsConfig } from "@/lib/ads/manager";

/**
 * GET /api/v1/ads/config
 * ----------------------
 * Returns the AdSense configuration that the client <AdSlot> components
 * consume to render ads.
 *
 * NO authentication required — this endpoint is callable by anyone
 * (including anonymous crawlers + logged-out visitors). The response is
 * intentionally limited to PUBLIC-safe fields:
 *   - publisherId (Google's publisher ID is ALREADY public — visible in
 *     the source of every AdSense page on the internet)
 *   - activeUnits (slot IDs are ALSO public — visible in data-ad-slot
 *     attribute of every rendered ad tag)
 *   - enabled flags + maxAdsPerPage + minDistanceSlots + excludedRoutes
 *
 * SECURITY (spec §5 + §38):
 *   - NO AdSense API credentials are stored or returned anywhere.
 *   - The viewerRole is computed from the session — guests get the
 *     showToGuests-gated config, logged-in users get showToUsers-gated,
 *     admins get showToAdmin-gated.
 *   - The endpoint NEVER returns inactive units (those are filtered at
 *     the DB query level via loadActiveAdUnits).
 *
 * PRIVACY (spec §27):
 *   - This endpoint does NOT expose the user's identity or any PII.
 *   - The viewerRole is a 3-value enum (GUEST/USER/ADMIN), not a user ID.
 *
 * CACHING:
 *   - The settings are cached 30s (via getSetting).
 *   - The active units are cached 60s (via cacheGetOrSet).
 *   - This endpoint itself is NOT cached at the HTTP layer — the client
 *     fetches once per page load + caches in React context (no N+1).
 *
 * Response shape:
 *   {
 *     enabled: boolean,
 *     publisherId: string, // empty when disabled or not configured
 *     showToGuests: boolean,
 *     showToUsers: boolean,
 *     showToAdmin: boolean,
 *     maxAdsPerPage: number,
 *     minDistanceSlots: number,
 *     excludedRoutes: string[],
 *     viewerRole: "GUEST" | "USER" | "ADMIN",
 *     activeUnits: PublicAdUnit[]
 *   }
 */
export const GET = apiHandler(async () => {
  // Determine viewer role from session. getCurrentUser returns null for
  // unauthenticated requests — that's the GUEST path.
  const user = await getCurrentUser();
  const viewerRole: "GUEST" | "USER" | "ADMIN" =
    !user ? "GUEST" :
    (user.role === "ADMIN" || user.role === "SUPER_ADMIN") ? "ADMIN" :
    "USER";

  const config = await buildPublicAdsConfig(viewerRole);
  return ok(config);
});
