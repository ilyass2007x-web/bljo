import { NextResponse } from "next/server";
import { pingDatabase, getDatabaseProvider } from "@/lib/database";

export const dynamic = "force-dynamic";

/**
 * Diagnostics endpoint — helps debug deployment issues.
 * Returns the status of all required configuration WITHOUT leaking secrets.
 *
 * SECURITY (hardened):
 *   - NEVER echoes any portion of DATABASE_URL, AUTH_SECRET, or any
 *     other secret-bearing env var. Previously the response included
 *     the first 15 characters of DATABASE_URL (which can include the
 *     username:password@host prefix on Neon connection strings) and
 *     the exact length of AUTH_SECRET (a side-channel for secret
 *     comparison). Both are now stripped — only the boolean "set:
 *     true/false" status is exposed.
 *   - The endpoint is intentionally public so deployers can
 *     self-diagnose config issues, but it returns ZERO sensitive
 *     values. Every field is a boolean or a coarse hint ("set" /
 *     "not set"), never a value or a length.
 */
export async function GET() {
  const db = await pingDatabase();

  return NextResponse.json({
    status: db.ok ? "ok" : "degraded",
    timestamp: new Date().toISOString(),
    checks: {
      database: {
        ok: db.ok,
        provider: getDatabaseProvider(),
        latencyMs: db.latencyMs,
        // Surface only a coarse category, never the raw error
        // (Prisma errors can include connection-string fragments).
        error: db.error ? "database_unreachable" : null,
      },
      // Boolean-only indicators. NEVER expose the length or any
      // substring of secret values.
      authSecret: {
        ok: !!process.env.AUTH_SECRET && process.env.AUTH_SECRET.length >= 32,
      },
      databaseUrl: {
        ok: !!process.env.DATABASE_URL,
      },
      emailProvider: {
        ok: true,
        name: process.env.EMAIL_PROVIDER ?? "console",
      },
      nodeEnv: process.env.NODE_ENV ?? "unknown",
    },
    instructions: !db.ok || !process.env.AUTH_SECRET || !process.env.DATABASE_URL
      ? {
          title: "Configuration incomplete",
          steps: [
            "1. In Netlify dashboard → Site settings → Environment variables",
            "2. Add DATABASE_URL (your Neon PostgreSQL connection string)",
            "3. Add AUTH_SECRET (generate with: openssl rand -hex 32)",
            "4. Redeploy the site",
            "5. Make sure prisma/schema.prisma uses provider = \"postgresql\"",
          ],
        }
      : null,
  });
}
