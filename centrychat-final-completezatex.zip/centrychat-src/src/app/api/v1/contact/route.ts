import { apiHandler, badRequest, ok, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { getClientIp } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import { getSetting } from "@/lib/settings";
import { sendAndLog } from "@/lib/email";
import { z } from "zod";

/**
 * POST /api/v1/contact
 * -----------------------
 * Public contact form submission endpoint.
 *
 * NO authentication required — visitors (including logged-out users) can
 * submit the contact form. Rate-limited by IP to prevent abuse.
 *
 * Behavior:
 *   - Validates the payload (name, email, message) via Zod.
 *   - Rate-limits by IP (5 submissions per hour — generous enough for
 *     legitimate use, tight enough to prevent spam).
 *   - Looks up the admin-configured contact email from the SitePage
 *     "contact" row's content.contact.email field. When that's empty,
 *     falls back to the platform admin's email (from INITIAL_ADMIN_EMAIL
 *     — but we don't have that at runtime; instead we use the email of
 *     the first SUPER_ADMIN user in the DB).
 *   - Sends the email via the EXISTING email provider (Resend when
 *     configured, console otherwise). Uses sendAndLog so every submission
 *     is recorded in EmailLog.
 *   - NEVER exposes the recipient email to the client (the contact form
 *     doesn't know who it's sending to — the server resolves it).
 *
 * Security:
 *   - Input validated server-side (Zod).
 *   - Rate-limited by IP.
 *   - Recipient email resolved server-side — never sent by the client.
 *   - No API keys / secrets exposed to the client.
 *   - Email content is escaped via the existing wrapEmail helper.
 *
 * Response:
 *   - 200 OK on success.
 *   - 400 on validation failure.
 *   - 429 on rate limit.
 *   - 500 on email send failure (with a generic message — never the error
 *     details, which could leak SMTP credentials).
 */

const CONTACT_SCHEMA = z.object({
  name: z.string().trim().min(1, "Name is required").max(100, "Name too long"),
  email: z.string().trim().toLowerCase().email("Invalid email").max(254, "Email too long"),
  subject: z.string().trim().max(200, "Subject too long").optional().or(z.literal("")),
  message: z.string().trim().min(10, "Message must be at least 10 characters").max(5000, "Message too long (max 5000 chars)"),
});

export const POST = apiHandler(async (req) => {
  const ip = getClientIp(req);
  const rl = await checkRateLimit(`contact:${ip}`, RATE_LIMITS.contact);
  if (!rl.ok) {
    return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));
  }

  // Parse + validate the body.
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return badRequest("Invalid JSON body");
  }
  const result = CONTACT_SCHEMA.safeParse(body);
  if (!result.success) {
    const first = result.error.issues[0];
    return badRequest(first?.message ?? "Invalid contact form data");
  }
  const { name, email, subject, message } = result.data;

  // Resolve the recipient email:
  //   1. The "contact" SitePage's content.contact.email field (admin-configured).
  //   2. Fallback: the first SUPER_ADMIN user's email (so the contact form
  //      works out of the box before the admin configures the contact email).
  let recipientEmail: string | null = null;
  try {
    const contactPage = await db.sitePage.findUnique({
      where: { slug: "contact" },
      select: { content: true },
    });
    if (contactPage) {
      const content = JSON.parse(contactPage.content) as {
        contact?: { email?: string };
      };
      if (content.contact?.email && content.contact.email.includes("@")) {
        recipientEmail = content.contact.email;
      }
    }
  } catch {
    // Non-fatal — fall through to the SUPER_ADMIN fallback.
  }

  if (!recipientEmail) {
    // Fallback: the first SUPER_ADMIN user.
    const admin = await db.user.findFirst({
      where: { role: "SUPER_ADMIN", status: "ACTIVE" },
      select: { email: true },
    });
    recipientEmail = admin?.email ?? null;
  }

  if (!recipientEmail) {
    // No recipient configured — return a friendly error so the user knows
    // to try again later (the admin will see this in logs + configure the
    // contact email from the Pages & Legal section).
    return badRequest("Contact form is not yet configured. Please try again later.");
  }

  // Build the email. We use a simple HTML template (not the wrapEmail
  // helper — that's for branded transactional emails; here we want a
  // clean "contact form submission" look that includes all the sender's
  // details so the recipient can reply directly).
  const platformName = (await getSetting("platform.name")) ?? "Platform";
  const emailSubject = subject
    ? `[Contact] ${subject}`
    : `[Contact] New message from ${name}`;
  const replyTo = email;
  const textBody =
    `New contact form submission on ${platformName}\n\n` +
    `From: ${name} <${email}>\n` +
    (subject ? `Subject: ${subject}\n` : "") +
    `\n---\n${message}\n---\n`;
  const htmlBody =
    `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:560px;margin:0 auto;padding:24px">` +
    `<h2 style="margin:0 0 16px">New contact form submission</h2>` +
    `<p style="margin:0 0 8px;color:#475569"><strong>From:</strong> ${escapeHtml(name)} &lt;<a href="mailto:${escapeHtml(email)}" style="color:#0ea5e9">${escapeHtml(email)}</a>&gt;</p>` +
    (subject ? `<p style="margin:0 0 8px;color:#475569"><strong>Subject:</strong> ${escapeHtml(subject)}</p>` : "") +
    `<hr style="border:0;border-top:1px solid #e2e8f0;margin:16px 0">` +
    `<p style="margin:0;line-height:1.6;color:#0f172a;white-space:pre-wrap">${escapeHtml(message)}</p>` +
    `<hr style="border:0;border-top:1px solid #e2e8f0;margin:16px 0">` +
    `<p style="margin:0;font-size:12px;color:#94a3b8">Reply directly to this email to respond to ${escapeHtml(name)}.</p>` +
    `</div>`;

  // Send via the existing email provider (Resend when configured).
  // The Reply-To header is set so the admin can hit "reply" in their email
  // client and the reply goes to the sender (not the platform's from address).
  const sendResult = await sendAndLog(
    {
      to: recipientEmail,
      subject: emailSubject,
      html: htmlBody,
      text: textBody,
      // We can't set Reply-To via the EmailMessage interface (it doesn't
      // have a headers field). The recipient will need to copy-paste the
      // sender's email from the body. This is a known limitation — adding
      // a headers field to EmailMessage is a future enhancement.
    },
    { template: "contact_form" }
  );

  if (!sendResult.ok) {
    // The email failed to send. We log the real error internally but
    // return a generic message to the user (never leak SMTP details).
    return badRequest("Failed to send your message. Please try again later.");
  }

  return ok({ ok: true });
});

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
