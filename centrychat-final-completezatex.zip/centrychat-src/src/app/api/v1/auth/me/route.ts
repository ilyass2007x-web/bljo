import { apiHandler, ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";

export const GET = apiHandler(async () => {
  const user = await getCurrentUser();
  return ok({ user });
});
