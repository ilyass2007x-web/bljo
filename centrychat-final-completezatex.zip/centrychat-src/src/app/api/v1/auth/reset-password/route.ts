import { apiHandler, badRequest, ok, parseJsonBody, rateLimited } from "@/lib/api";
import { consumeToken } from "@/lib/auth/tokens";
import { db } from "@/lib/database";
import { hashPassword } from "@/lib/security/password";
import { PASSWORD_SCHEMA } from "@/lib/security/sanitize";
import { destroyAllUserSessions } from "@/lib/auth/session";
import { checkRateLimit, RATE_LIMITS, getClientIp } from "@/lib/security/rate-limit";
import { logger } from "@/lib/logging";

export const POST = apiHandler(async (req) => {
  // Brute-force protection — rate-limit per IP to prevent token-guessing attacks.
  // (The token itself is 32 cryptographically random bytes, but defense in depth.)
  // FAIL-CLOSED: a Redis outage must NOT enable password-reset token
  // brute-force (even though the token is 256-bit, an attacker with
  // 1000 IPs could otherwise test ~10^7 tokens/hour — not enough to
  // hit a 256-bit space, but the fail-closed behavior is still the
  // secure default for a security-critical endpoint).
  const ip = getClientIp(req);
  const rl = await checkRateLimit(
    `password-reset:submit:${ip}`,
    { ...RATE_LIMITS.passwordResetSubmit, failMode: "closed" }
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await parseJsonBody<{
    token?: string;
    password?: string;
    confirmPassword?: string;
  }>(req);

  if (!body.token) return badRequest("Reset token is required");
  const password = PASSWORD_SCHEMA.safeParse(body.password ?? "");
  if (!password.success) return badRequest(password.error.issues[0]?.message);
  if (body.password !== body.confirmPassword) {
    return badRequest("Passwords do not match");
  }

  const consumed = await consumeToken(body.token, "PASSWORD_RESET");
  if (!consumed) {
    return badRequest("Invalid or expired reset token");
  }

  const passwordHash = await hashPassword(password.data);
  await db.user.update({
    where: { id: consumed.userId },
    data: { passwordHash },
  });

  // Revoke all existing sessions for this user.
  await destroyAllUserSessions(consumed.userId);

  logger.info("security", "Password reset completed", {
    userId: consumed.userId,
  });

  return ok({ reset: true });
});
