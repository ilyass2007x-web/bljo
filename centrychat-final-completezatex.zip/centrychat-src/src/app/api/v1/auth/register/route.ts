import { apiHandler, badRequest, ok, parseJsonBody, rateLimited } from "@/lib/api";
import { db } from "@/lib/database";
import {
  EMAIL_SCHEMA,
  FULL_NAME_SCHEMA,
  PASSWORD_SCHEMA,
} from "@/lib/security/sanitize";
import { hashPassword } from "@/lib/security/password";
import { createSession } from "@/lib/auth/session";
import { issueEmailVerificationToken } from "@/lib/auth/tokens";
import { sendVerificationEmail } from "@/lib/email";
import { getSettingBool } from "@/lib/settings";
import { checkRateLimit, RATE_LIMITS, getClientIp } from "@/lib/security/rate-limit";
import { getJobs } from "@/lib/jobs";
import { logger } from "@/lib/logging";
import { generateAvatarColor } from "@/lib/avatar";
import { normalizeGender, validateDateOfBirth } from "@/lib/profile";

export const POST = apiHandler(async (req) => {
  const registrationEnabled = await getSettingBool("platform.registration.enabled");
  if (!registrationEnabled) {
    return badRequest("Registration is currently disabled");
  }

  const ip = getClientIp(req);
  // FAIL-CLOSED: a Redis outage must NOT enable mass-account creation
  // (spam/abuse). A legitimate user can retry — the outage is rare.
  const rl = await checkRateLimit(`register:ip:${ip}`, {
    ...RATE_LIMITS.register,
    failMode: "closed",
  });
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await parseJsonBody<{
    fullName?: string;
    email?: string;
    username?: string;
    password?: string;
    confirmPassword?: string;
    gender?: string | null;
    dateOfBirth?: string | null;
    countryCode?: string | null;
  }>(req);

  const fullName = FULL_NAME_SCHEMA.safeParse(body.fullName ?? "");
  const email = EMAIL_SCHEMA.safeParse(body.email ?? "");
  const password = PASSWORD_SCHEMA.safeParse(body.password ?? "");
  if (!fullName.success) return badRequest(fullName.error.issues[0]?.message);
  if (!email.success) return badRequest(email.error.issues[0]?.message);
  if (!password.success) return badRequest(password.error.issues[0]?.message);
  if (body.password !== body.confirmPassword) {
    return badRequest("Passwords do not match");
  }

  // Username validation (case-insensitive uniqueness).
  const { USERNAME_SCHEMA, isUsernameAvailable, suggestUsernames } = await import("@/lib/username");
  const usernameParsed = USERNAME_SCHEMA.safeParse(body.username ?? "");
  if (!usernameParsed.success) {
    return badRequest(usernameParsed.error.issues[0]?.message);
  }
  const usernameAvailable = await isUsernameAvailable(usernameParsed.data);
  if (!usernameAvailable) {
    const suggestions = await suggestUsernames(usernameParsed.data);
    return badRequest("This username is already taken.", { suggestions });
  }

  // Gender — REQUIRED for new accounts (used by Video Chat matchmaking).
  // Must be one of MALE, FEMALE, PREFER_NOT_TO_SAY.
  // Existing accounts retain their nullable gender (backward compatible).
  const gender = normalizeGender(body.gender);
  if (!gender) {
    return badRequest("Please select your gender.");
  }

  // Country — REQUIRED for new accounts (used by Video Chat matchmaking).
  // Must be a valid ISO 3166-1 alpha-2 code.
  const { normalizeCountryCode } = await import("@/lib/countries");
  const countryCode = normalizeCountryCode(body.countryCode);
  if (!countryCode) {
    return badRequest("Please select your country.");
  }

  // Date of Birth — optional. Validated against:
  //   1. ISO date format (YYYY-MM-DD)
  //   2. Not in the future
  //   3. User is at least MINIMUM_AGE (13) years old
  //   4. Not more than MAXIMUM_REASONABLE_AGE years old
  // See src/lib/profile.ts for the validation logic.
  const dobResult = validateDateOfBirth(body.dateOfBirth);
  if (!dobResult.valid) {
    return badRequest(dobResult.error);
  }

  // CASE-INSENSITIVE existing-email check.
  // Legacy Production DB may store emails with mixed case (e.g. "User@Gmail.com").
  // EMAIL_SCHEMA lowercases the input — if we only checked `findUnique({ where: { email: lowercased } })`,
  // a legacy user with mixed-case email would slip through and create a duplicate
  // (which would then fail the unique constraint). Use `findFirst` with
  // `mode: 'insensitive'` to detect existing accounts regardless of stored case.
  const existing = await db.user.findFirst({
    where: { email: { equals: email.data, mode: "insensitive" } },
  });
  if (existing) {
    // Do not leak which emails are registered. Pretend success.
    return ok({ registered: true, verificationRequired: true });
  }

  const passwordHash = await hashPassword(password.data);

  // Check whether the verification email should be sent. This setting
  // now ONLY controls whether the email is SENT — it no longer controls
  // whether login is blocked (new users are always ACTIVE + auto-logged-in).
  const emailVerificationRequired = await getSettingBool(
    "platform.email_verification.required"
  );

  // ── ISSUE 3 FIX: Always create new users as ACTIVE + auto-login ────
  // Per spec: "Email verification must NOT block a newly registered user
  // from entering their account." The previous code set status to
  // "PENDING_VERIFICATION" when `email_verification.required` was true
  // (the default), which caused page.tsx to show a blocking
  // "Verify your email" screen — preventing the user from entering
  // their account until they clicked the email link.
  //
  // The fix: ALWAYS set status to "ACTIVE" + emailVerified to now().
  // The `email_verification.required` setting now ONLY controls whether
  // the verification email is SENT (not whether it blocks login).
  //
  // RESEND is NOT removed — the verification email is still sent (below)
  // via the existing sendVerificationEmail() function + the job queue.
  // The email is now informational (confirms the email address) rather
  // than blocking. The Forgot Password flow (which uses a DIFFERENT
  // email — password_reset, not verification) is completely unaffected.
  //
  // EXISTING USERS: we do NOT mass-update existing PENDING_VERIFICATION
  // users. They retain their current status. Only NEW registrations are
  // affected by this change. (Per spec: "Do not modify existing accounts
  // unnecessarily.") If an admin wants to activate existing pending
  // users, they can use the admin user-management panel.
  const status = "ACTIVE";
  const emailVerifiedAt = new Date();

  const user = await db.user.create({
    data: {
      fullName: fullName.data,
      email: email.data,
      username: usernameParsed.data,
      passwordHash,
      status,
      emailVerified: emailVerifiedAt,
      avatarColor: generateAvatarColor(email.data),
      // Optional demographic info — never required, never exposed publicly.
      gender,
      dateOfBirth: dobResult.value,
      // Required for new accounts — ISO 3166-1 alpha-2 country code.
      countryCode,
    },
  });

  logger.info("authentication", "User registered", {
    userId: user.id,
    email: user.email,
    // Log whether the user provided gender/dob (NOT the values themselves —
    // those are private). Useful for future analytics without leaking PII.
    hasGender: gender !== null,
    hasDateOfBirth: dobResult.value !== null,
    hasCountry: countryCode !== null,
  });

  // Notify all admins about the new user (real-time admin notification center).
  try {
    const { notifyAdminsNewUser } = await import("@/lib/notifications");
    await notifyAdminsNewUser({
      newUserId: user.id,
      newUserEmail: user.email,
      newUserFullName: user.fullName,
    });
  } catch {
    /* non-fatal */
  }

  // ── Still send the verification email (Resend stays) ──────────────
  // The email is now informational — it confirms the user's email
  // address but does NOT block login. The `email_verification.required`
  // setting controls whether the email is sent at all.
  //
  // We do NOT return early here (the old code did `return ok({ ... })`
  // before the auto-login block). Instead, we fall through to the
  // auto-login block below — so the user gets a session immediately.
  if (emailVerificationRequired) {
    try {
      const token = await issueEmailVerificationToken(user.id);
      // Send via job queue (non-blocking).
      getJobs().enqueue({
        type: "send-email",
        data: { kind: "verification", to: user.email, token },
      });
      // Also send synchronously in dev so the console provider logs immediately.
      // Pass `request` so the email template can derive the production URL.
      await sendVerificationEmail(user.email, token, { request: req });
    } catch {
      /* non-fatal — email send failure should NOT block registration */
    }
  }

  // ── Auto-login: create a session immediately ──────────────────────
  // The user is now ACTIVE, so we create a session + return it.
  // The client (auth-screen.tsx) will call fetchUser() + router.push("/")
  // to enter the app directly — no "Verify your email" blocking screen.
  const sessionId = await createSession(user.id, {
    ipAddress: ip,
    userAgent: req.headers.get("user-agent") ?? undefined,
  });
  return ok({
    registered: true,
    verificationRequired: false, // always false — login is never blocked
    sessionId,
    user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role },
  });
});

// Wire the email job handler.
import type { JobHandler } from "@/lib/jobs";
const emailJobHandler: JobHandler = {
  type: "send-email",
  async handle(data) {
    if (data.kind === "verification" && typeof data.to === "string" && typeof data.token === "string") {
      await sendVerificationEmail(data.to, data.token);
    } else if (data.kind === "password-reset" && typeof data.to === "string" && typeof data.token === "string") {
      const { sendPasswordResetEmail } = await import("@/lib/email");
      await sendPasswordResetEmail(data.to, data.token);
    }
  },
};
getJobs().register(emailJobHandler);
