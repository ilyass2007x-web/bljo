import {
  apiHandler,
  badRequest,
  err,
  ok,
  parseJsonBody,
  rateLimited,
} from "@/lib/api";
import { db } from "@/lib/database";
import { EMAIL_SCHEMA } from "@/lib/security/sanitize";
import { issuePasswordResetToken } from "@/lib/auth/tokens";
import {
  sendPasswordResetEmail,
  getEmailProvider,
} from "@/lib/email";
import {
  checkRateLimit,
  RATE_LIMITS,
  getClientIp,
} from "@/lib/security/rate-limit";
import { logger } from "@/lib/logging";

/**
 * POST /api/v1/auth/forgot-password
 *
 * Sends a password-reset email to the address supplied in the body.
 *
 * RESPONSE POLICY (per user spec — no more fake success):
 *  - User NOT found → return success (no email to send, prevents enumeration)
 *  - User found + Resend SUCCESS → return success
 *  - User found + Resend FAILURE → return ERROR (502) so the frontend shows
 *    a real error message instead of a fake "email sent" toast.
 *
 * The error message is GENERIC — it does NOT reveal whether the email exists.
 * It simply says "Could not send reset email. Please try again later."
 *
 * SAFE SERVER LOGS (never logs: API key, password, reset token, full email body):
 *  [Forgot Password] request received
 *  [Forgot Password] email lookup
 *  [Forgot Password] code/link generated
 *  [Forgot Password] attempting Resend
 *  [Forgot Password] Resend result
 *  [Forgot Password] final result
 *
 * CASE-INSENSITIVE EMAIL LOOKUP:
 *   Legacy Production DB may store emails with mixed case (e.g. "User@Gmail.com").
 *   The EMAIL_SCHEMA lowercases the input, so a case-sensitive `findUnique` would
 *   miss those users → silent success (no email sent). Using `findFirst` with
 *   `mode: 'insensitive'` matches regardless of stored case.
 */
export const POST = apiHandler(async (req) => {
  // ────────────────────────────────────────────────────────────────────────
  // STEP 1: Parse + validate body.
  // ────────────────────────────────────────────────────────────────────────
  const body = await parseJsonBody<{ email?: string }>(req);
  const email = EMAIL_SCHEMA.safeParse(body.email ?? "");
  if (!email.success) {
    logger.info("authentication", "[Forgot Password] rejected: invalid email format");
    return badRequest(email.error.issues[0]?.message);
  }

  // SAFE: log the email — it's already in the request body, not a secret.
  // (We do NOT log the reset token that gets generated later.)
  logger.info("authentication", "[Forgot Password] request received", {
    email: email.data,
  });

  // ────────────────────────────────────────────────────────────────────────
  // STEP 2: Rate limit — 3 requests per hour per email AND per IP.
  // ────────────────────────────────────────────────────────────────────────
  const ip = getClientIp(req);
  const [rlEmail, rlIp] = await Promise.all([
    checkRateLimit(`password-reset:email:${email.data}`, {
      ...RATE_LIMITS.passwordReset,
      failMode: "closed",
    }),
    checkRateLimit(`password-reset:ip:${ip}`, {
      ...RATE_LIMITS.passwordReset,
      failMode: "closed",
    }),
  ]);
  if (!rlEmail.ok || !rlIp.ok) {
    logger.info("authentication", "[Forgot Password] rate limited", {
      email: email.data,
    });
    return rateLimited(
      Math.ceil((Math.max(rlEmail.resetAt, rlIp.resetAt) - Date.now()) / 1000)
    );
  }

  // ────────────────────────────────────────────────────────────────────────
  // STEP 3: Look up the user (case-insensitive — see comment above).
  // If not found, we still return success to avoid revealing whether the
  // email exists.
  // ────────────────────────────────────────────────────────────────────────
  let user: Awaited<ReturnType<typeof db.user.findFirst>> | null = null;
  try {
    user = await db.user.findFirst({
      where: { email: { equals: email.data, mode: "insensitive" } },
    });
  } catch (e) {
    // Fallback to exact match if the case-insensitive query fails
    // (e.g. CITEXT column or legacy driver issue).
    logger.warn("authentication", "[Forgot Password] case-insensitive lookup failed, trying exact", {
      error: e instanceof Error ? e.message : String(e),
    });
    try {
      user = await db.user.findUnique({ where: { email: email.data } });
    } catch (e2) {
      logger.error("authentication", "[Forgot Password] user lookup failed (both paths)", {
        error: e2 instanceof Error ? e2.message : String(e2),
      });
      throw e2;
    }
  }

  if (!user) {
    logger.info("authentication", "[Forgot Password] email lookup: not found", {
      email: email.data,
    });
    // SECURITY: identical response shape & timing to the success case.
    // No email to send, no error to surface.
    return ok({ sent: true });
  }

  logger.info("authentication", "[Forgot Password] email lookup: found", {
    userId: user.id,
    language: user.language,
  });

  // ────────────────────────────────────────────────────────────────────────
  // STEP 4: Issue a cryptographically secure, single-use, 30-min-expiring
  // reset token. Stored as SHA-256 hash in the DB — never the raw token.
  // ────────────────────────────────────────────────────────────────────────
  let token: string;
  try {
    token = await issuePasswordResetToken(user.id);
    logger.info("authentication", "[Forgot Password] reset link generated", {
      userId: user.id,
    });
  } catch (e) {
    // Token creation failed — DB issue, Token table missing, etc.
    // Surface as a generic error so the user can retry.
    logger.error("authentication", "[Forgot Password] token creation failed", {
      userId: user.id,
      error: e instanceof Error ? e.message : String(e),
      errorName: e instanceof Error ? e.name : typeof e,
    });
    return err(
      502,
      "Could not generate reset token. Please try again later. If the problem persists, contact support.",
      { code: "TOKEN_GENERATION_FAILED" }
    );
  }

  // ────────────────────────────────────────────────────────────────────────
  // STEP 5: Send the email through the configured provider.
  //
  // CRITICAL: We surface the real Resend response to the client.
  // If Resend fails, we return HTTP 502 with a generic error message so
  // the frontend shows an error instead of a fake "email sent" toast.
  //
  // We pass `request: req` so the email template can derive the correct
  // production base URL from the request's Host header — even if
  // NEXT_PUBLIC_APP_BASE_URL env var is not set.
  // ────────────────────────────────────────────────────────────────────────
  const providerName = getEmailProvider().name;
  logger.info("authentication", "[Forgot Password] attempting email send", {
    provider: providerName,
    to: user.email,
    fromConfigured: !!(process.env.RESEND_FROM_EMAIL ?? "").trim(),
    envBaseUrl: process.env.NEXT_PUBLIC_APP_BASE_URL ?? process.env.APP_BASE_URL ?? "(unset)",
  });

  let sendOk = true;
  let sendError: string | null = null;

  try {
    await sendPasswordResetEmail(user.email, token, {
      lang: user.language,
      fullName: user.fullName,
      request: req, // ← lets the template derive the production URL from Host header
    });
    logger.info("authentication", "[Forgot Password] email send: SUCCESS", {
      provider: providerName,
      to: user.email,
    });
  } catch (e) {
    sendOk = false;
    sendError =
      e instanceof Error ? e.message.slice(0, 500) : String(e).slice(0, 500);
    // SAFE diagnostic — never logs the API key, password, or reset token.
    logger.error("authentication", "[Forgot Password] email send: FAILED", {
      provider: providerName,
      to: user.email,
      errorName: e instanceof Error ? e.name : typeof e,
      errorMessage: sendError,
    });
  }

  // ────────────────────────────────────────────────────────────────────────
  // STEP 6: Record the attempt in EmailLog so admins can see it in the
  // admin Email section (best-effort — never blocks the response).
  // ────────────────────────────────────────────────────────────────────────
  try {
    await db.emailLog.create({
      data: {
        userId: user.id,
        toEmail: user.email,
        template: "password_reset",
        provider: providerName,
        status: sendOk ? "sent" : "failed",
        error: sendError,
      },
    });
  } catch (logErr) {
    // Don't let a logging failure break the response.
    logger.warn("authentication", "[Forgot Password] EmailLog write failed", {
      error: logErr instanceof Error ? logErr.message : String(logErr),
    });
  }

  // ────────────────────────────────────────────────────────────────────────
  // STEP 7: Final result.
  // ────────────────────────────────────────────────────────────────────────
  if (!sendOk) {
    logger.info("authentication", "[Forgot Password] final result: ERROR (email send failed)", {
      userId: user.id,
    });
    return err(
      502,
      "Could not send reset email. Please try again later. If the problem persists, contact support.",
      { code: "EMAIL_SEND_FAILED" }
    );
  }

  logger.info("authentication", "[Forgot Password] final result: SUCCESS", {
    userId: user.id,
  });

  return ok({ sent: true });
});
