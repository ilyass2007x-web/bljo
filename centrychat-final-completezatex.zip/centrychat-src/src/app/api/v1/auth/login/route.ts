import { db } from "@/lib/database";
import { EMAIL_SCHEMA } from "@/lib/security/sanitize";
import {
  verifyPassword,
  hashPassword,
  detectHashAlgorithm,
  needsRehash,
} from "@/lib/security/password";
import { createSession } from "@/lib/auth/session";
import { toSafeUser, BadRequestError } from "@/lib/auth";
import {
  apiHandler,
  badRequest,
  ok,
  parseJsonBody,
  rateLimited,
  unauthorized,
} from "@/lib/api";
import {
  checkRateLimit,
  RATE_LIMITS,
  getClientIp,
} from "@/lib/security/rate-limit";
import { logger } from "@/lib/logging";
import { canLogin } from "@/lib/permissions";

/**
 * A real Argon2id hash of an unknown long random password.
 *
 * Used as a "dummy" hash to make login timing consistent whether or not
 * the email exists in the user table. Without this, an attacker could
 * measure the timing delta between "user not found" (very fast — no
 * Argon2id computation) and "user found + wrong password" (~50ms —
 * full Argon2id verification) to enumerate accounts.
 *
 * The hash is computed lazily on first use (per-process, then cached).
 * Hashing once per process startup is acceptable — the result is
 * deterministic for the lifetime of the process. The hash is for a
 * random 32-byte password that no one knows + is never used anywhere
 * else in the codebase.
 *
 * SECURITY: this hash is NOT a credential. It's a public, well-known
 * hash of an unknown random string. Its ONLY purpose is to make
 * Argon2id's `verify()` run through the full memory-hard computation
 * path on the "user not found" branch. The output of `verifyPassword`
 * against it is ALWAYS `false` — which is what we want (an unknown
 * email should always fail login).
 */
let _dummyHashCache: string | null = null;
async function getDummyHash(): Promise<string> {
  if (_dummyHashCache) return _dummyHashCache;
  const randomSecret =
    "dummy-timing-equalization-" +
    crypto.randomUUID() +
    crypto.randomUUID() +
    crypto.randomUUID();
  _dummyHashCache = await hashPassword(randomSecret);
  return _dummyHashCache;
}

export const POST = apiHandler(async (req) => {
  const body = await parseJsonBody<{
    email?: string;
    password?: string;
  }>(req);

  const email = EMAIL_SCHEMA.safeParse(body.email ?? "");
  if (!email.success) return badRequest(email.error.issues[0]?.message);
  if (!body.password) return badRequest("Password is required");

  const ip = getClientIp(req);
  // Rate limit keyed on BOTH (ip, email) — defends against brute-force
  // from a single attacker IP AND against distributed attacks targeting
  // a specific account (the email-keyed limit triggers regardless of IP).
  // Both keys run in parallel — if EITHER exceeds, the request is rejected.
  // FAIL-CLOSED on Redis outage: a Redis DoS must NOT enable password
  // brute-force. (Existing users can still log in — the request is only
  // rejected during an actual Redis outage.)
  const rlKey1 = `login:ip:${ip}:${email.data}`;
  const rlKey2 = `login:email:${email.data}`;
  const [rl1, rl2] = await Promise.all([
    checkRateLimit(rlKey1, { ...RATE_LIMITS.login, failMode: "closed" }),
    checkRateLimit(rlKey2, { ...RATE_LIMITS.login, failMode: "closed" }),
  ]);
  if (!rl1.ok || !rl2.ok) {
    const reset = Math.max(rl1.resetAt, rl2.resetAt);
    return rateLimited(Math.ceil((reset - Date.now()) / 1000));
  }

  // ────────────────────────────────────────────────────────────────────────
  // CASE-INSENSITIVE EMAIL LOOKUP
  // ────────────────────────────────────────────────────────────────────────
  // EMAIL_SCHEMA lowercases the input, but legacy Production DB may have
  // stored mixed-case emails (e.g. "User@Gmail.com") for users registered
  // before the lowercasing was added. A case-sensitive `findUnique` would
  // miss those users → "Invalid email or password" even with correct
  // credentials. Using `findFirst` with `mode: 'insensitive'` matches
  // regardless of stored case, so legacy users can still log in.
  //
  // The unique constraint on email still prevents duplicates from being
  // created at registration time (the register route also lowercases).
  // If for any reason two rows with the same email in different cases
  // exist (e.g. from before the lowercasing was enforced), `findFirst`
  // returns the first match — both would have the same password hash
  // since they're effectively the same account.
  // ────────────────────────────────────────────────────────────────────────
  let user: Awaited<ReturnType<typeof db.user.findFirst>> | null = null;
  try {
    user = await db.user.findFirst({
      where: { email: { equals: email.data, mode: "insensitive" } },
    });
  } catch (e) {
    // If the email column doesn't support `mode: 'insensitive'` (e.g.
    // CITEXT column or some legacy setups), fall back to exact match.
    // This is a defense-in-depth — the primary path should work.
    logger.warn("authentication", "Case-insensitive lookup failed, falling back to exact match", {
      error: e instanceof Error ? e.message : String(e),
    });
    try {
      user = await db.user.findUnique({ where: { email: email.data } });
    } catch (e2) {
      logger.error("authentication", "Login user lookup failed (both paths)", {
        error: e2 instanceof Error ? e2.message : String(e2),
      });
      throw e2; // let apiHandler surface as schema/connection error
    }
  }

  // SAFE diagnostic — never logs password, hash, token, or email content.
  // We log only the lookup outcome + the stored hash algorithm (so we can
  // detect legacy bcrypt users that need rehash).
  logger.info("authentication", "Login lookup", {
    userFound: !!user,
    hashAlgo: user ? detectHashAlgorithm(user.passwordHash) : "n/a",
  });

  // Always do a hash comparison to avoid timing-based user enumeration.
  // The dummy hash is a REAL Argon2id hash of an unknown long random
  // password — this ensures verify() runs the full Argon2id operation
  // (same memory/time parameters as a real hash) even when the user
  // doesn't exist.
  const passwordOk = user
    ? await verifyPassword(body.password, user.passwordHash)
    : await verifyPassword(body.password, await getDummyHash());

  logger.info("authentication", "Login password verify", {
    passwordVerifyReached: true,
    passwordVerifyOk: !!user ? passwordOk : false, // for unknown users, always false
  });

  if (!user || !passwordOk) {
    return unauthorized("Invalid email or password");
  }

  if (!canLogin(user.status)) {
    // SECURITY FIX: previously returned different messages for
    // BANNED / SUSPENDED / other inactive states — this allowed
    // account enumeration (an attacker probing emails would learn
    // which accounts are banned/suspended). Now we return the SAME
    // generic "Invalid email or password" message as for a wrong
    // password, and log the actual status server-side only.
    logger.info("authentication", "Login blocked — account not active", {
      userId: user.id,
      status: user.status,
    });
    return unauthorized("Invalid email or password");
  }

  // ────────────────────────────────────────────────────────────────────────
  // LAZY HASH MIGRATION (legacy bcrypt → Argon2id)
  // ────────────────────────────────────────────────────────────────────────
  // If the stored hash is a legacy algorithm (bcrypt, pbkdf2, argon2i/d),
  // re-hash the password with Argon2id and persist. This gradually
  // migrates the storage to the modern standard WITHOUT requiring a
  // forced password reset. We only do this when:
  //   1. The user just successfully authenticated (we have the plaintext).
  //   2. The stored hash is not already Argon2id.
  // The rehash is non-blocking — if it fails (e.g. transient DB issue),
  // we still let the user log in. The next successful login will retry.
  // ────────────────────────────────────────────────────────────────────────
  if (needsRehash(user.passwordHash)) {
    try {
      const newHash = await hashPassword(body.password);
      await db.user.update({
        where: { id: user.id },
        data: { passwordHash: newHash },
      });
      logger.info("authentication", "Password hash migrated to Argon2id", {
        userId: user.id,
        fromAlgo: detectHashAlgorithm(user.passwordHash),
        toAlgo: "argon2id",
      });
    } catch (e) {
      // Non-fatal — user still gets a session. We'll retry on next login.
      logger.warn("authentication", "Hash migration failed (non-fatal)", {
        userId: user.id,
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }

  // ────────────────────────────────────────────────────────────────────────
  // LAZY EMAIL NORMALIZATION (mixed-case → lowercase)
  // ────────────────────────────────────────────────────────────────────────
  // If the stored email has different casing than the lowercased input,
  // update it to lowercase. This brings the stored value in sync with
  // the validation layer, so future case-sensitive lookups also work.
  // We only do this when the lowercased email is DIFFERENT from the
  // stored email (avoids unnecessary DB writes).
  // ────────────────────────────────────────────────────────────────────────
  if (user.email !== user.email.toLowerCase()) {
    try {
      await db.user.update({
        where: { id: user.id },
        data: { email: user.email.toLowerCase() },
      });
      logger.info("authentication", "Email normalized to lowercase", {
        userId: user.id,
      });
    } catch (e) {
      // Non-fatal — user still gets a session. We'll retry on next login.
      logger.warn("authentication", "Email normalization failed (non-fatal)", {
        userId: user.id,
        error: e instanceof Error ? e.message : String(e),
      });
    }
  }

  // Update last seen.
  await db.user.update({
    where: { id: user.id },
    data: { lastSeenAt: new Date() },
  });

  logger.info("authentication", "Session creation reached", {
    userId: user.id,
  });

  const sessionId = await createSession(user.id, {
    ipAddress: ip,
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  logger.info("authentication", "User logged in", {
    userId: user.id,
    email: user.email,
  });

  return ok({
    sessionId,
    user: toSafeUser(user),
    requiresVerification: !user.emailVerified,
  });
});
