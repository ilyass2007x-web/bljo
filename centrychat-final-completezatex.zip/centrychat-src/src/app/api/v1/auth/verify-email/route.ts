import { apiHandler, badRequest, ok, parseJsonBody, rateLimited } from "@/lib/api";
import { consumeToken } from "@/lib/auth/tokens";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { getClientIp } from "@/lib/security/rate-limit";

/**
 * POST /api/v1/auth/verify-email
 * --------------------------------
 * Verifies a user's email using a token sent via email.
 *
 * SECURITY (H-1 fix):
 *   - Rate-limited per IP at 3/hour (RATE_LIMITS.emailVerify).
 *   - Fail-closed mode — if the rate-limit store (Upstash Redis) is
 *     unreachable in production, the request is REJECTED (429) instead
 *     of silently allowed. This prevents an attacker from spamming
 *     token-guess attempts during a Redis outage.
 *
 *   The 256-bit token is computationally unguessable, but the rate
 *   limit is defense-in-depth:
 *     - Prevents CPU amplification (each request runs Argon2id token
 *       hash comparison + DB lookup).
 *     - Prevents probing for token-derivation bugs or future regressions.
 *     - Mitigates request flooding (DoS).
 *
 * Auth: public (the user is not yet authenticated — they just received
 * the verification email).
 */
export const POST = apiHandler(async (req) => {
  // Rate-limit by IP — fail-closed.
  const ip = getClientIp(req);
  const rl = await checkRateLimit(
    `email-verify:ip:${ip}`,
    { ...RATE_LIMITS.emailVerify, failMode: "closed" }
  );
  if (!rl.ok) {
    return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));
  }

  const body = await parseJsonBody<{ token?: string }>(req);
  if (!body.token || typeof body.token !== "string") {
    return badRequest("Verification token is required");
  }

  const consumed = await consumeToken(body.token, "EMAIL_VERIFICATION");
  if (!consumed) {
    return badRequest("Invalid or expired verification token");
  }

  await db.user.update({
    where: { id: consumed.userId },
    data: {
      emailVerified: new Date(),
      status: "ACTIVE",
    },
  });

  logger.info("authentication", "Email verified", { userId: consumed.userId });

  return ok({ verified: true });
});
