import { apiHandler, ok } from "@/lib/api";
import { destroySession } from "@/lib/auth/session";
import { getCurrentUser } from "@/lib/auth";

export const POST = apiHandler(async (req) => {
  void req;
  const user = await getCurrentUser();
  await destroySession();
  return ok({ loggedOut: true, hadUser: !!user });
});
