import { apiHandler, badRequest, err, ok, rateLimited } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { issueEmailVerificationToken } from "@/lib/auth/tokens";
import { sendVerificationEmail, getEmailProvider } from "@/lib/email";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { logger } from "@/lib/logging";

/**
 * POST /api/v1/auth/resend-verification
 * -------------------------------------
 * Resends the email-verification token to the authenticated user.
 *
 * SECURITY (H-2 fix):
 *   - Fail-closed rate limit — if the rate-limit store (Upstash Redis) is
 *     unreachable in production, the request is REJECTED (429) instead of
 *     silently allowed. Previously this endpoint was fail-open, which was
 *     inconsistent with login/register/forgot-password (all fail-closed).
 *     A Redis outage would have allowed an attacker to spam verification
 *     emails (Resend quota is finite + harms sender reputation).
 *   - Retry-After header now correctly reports SECONDS (was ms before).
 *
 * AUDIT FIX (2026-09-22):
 *   Previously this route swallowed email-send failures with
 *   `} catch { /* logged by email provider *\/ }` and returned
 *   `ok({ sent: true })` regardless. The user saw a misleading "email
 *   sent" toast even when Resend returned an error. This was inconsistent
 *   with the forgot-password route, which surfaces Resend failures as
 *   HTTP 502. Now this route mirrors that pattern: captures the error,
 *   logs it via the structured logger, writes to EmailLog, and returns
 *   HTTP 502 with a generic message on failure. The message does NOT
 *   leak any internal state — it just says "try again later".
 */
export const POST = apiHandler(async (req) => {
  const user = await requireUser();
  if (user.emailVerified) return ok({ sent: true, alreadyVerified: true });

  const rl = await checkRateLimit(
    `email-verify:email:${user.email}`,
    { ...RATE_LIMITS.emailVerify, failMode: "closed" }
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const token = await issueEmailVerificationToken(user.id);
  const providerName = getEmailProvider().name;

  let sendOk = true;
  let sendError: string | null = null;

  try {
    // Pass `request` so the email template can derive the production URL.
    await sendVerificationEmail(user.email, token, { request: req });
    logger.info("authentication", "[Resend Verify] email send: SUCCESS", {
      provider: providerName,
      to: user.email,
      userId: user.id,
    });
  } catch (e) {
    sendOk = false;
    sendError =
      e instanceof Error ? e.message.slice(0, 500) : String(e).slice(0, 500);
    // SAFE diagnostic — never logs the API key, password, or verification token.
    logger.error("authentication", "[Resend Verify] email send: FAILED", {
      provider: providerName,
      to: user.email,
      userId: user.id,
      errorName: e instanceof Error ? e.name : typeof e,
      errorMessage: sendError,
    });
  }

  // Best-effort EmailLog write (same pattern as forgot-password).
  try {
    await db.emailLog.create({
      data: {
        userId: user.id,
        toEmail: user.email,
        template: "verification",
        provider: providerName,
        status: sendOk ? "sent" : "failed",
        error: sendError,
      },
    });
  } catch (logErr) {
    logger.warn("authentication", "[Resend Verify] EmailLog write failed", {
      userId: user.id,
      error: logErr instanceof Error ? logErr.message : String(logErr),
    });
  }

  if (!sendOk) {
    return err(
      502,
      "Could not send verification email. Please try again later. If the problem persists, contact support.",
      { code: "EMAIL_SEND_FAILED" }
    );
  }

  return ok({ sent: true });
});
