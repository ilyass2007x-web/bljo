import { apiHandler, badRequest, ok, parseJsonBody, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import {
  REPORT_DESCRIPTION_SCHEMA,
  REPORT_REASON_SCHEMA,
} from "@/lib/security/sanitize";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { isFeatureEnabled } from "@/lib/features";

export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  const url = new URL(req.url);
  const limit = Math.min(Number(url.searchParams.get("limit") ?? "20"), 50);

  const reports = await db.report.findMany({
    where: { reporterId: user.id },
    orderBy: { createdAt: "desc" },
    take: limit,
  });

  return ok({
    reports: reports.map((r) => ({
      id: r.id,
      reason: r.reason,
      description: r.description,
      status: r.status,
      resolutionNote: r.resolutionNote,
      createdAt: r.createdAt.toISOString(),
      resolvedAt: r.resolvedAt?.toISOString() ?? null,
    })),
  });
});

export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  if (!(await isFeatureEnabled("reports"))) {
    return badRequest("Reports are currently disabled");
  }
  const rl = await checkRateLimit(`report:user:${user.id}`, RATE_LIMITS.report);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await parseJsonBody<{
    targetUserId?: string;
    targetMessageId?: string;
    reason?: string;
    description?: string;
  }>(req);

  const reason = REPORT_REASON_SCHEMA.safeParse(body.reason ?? "");
  if (!reason.success) return badRequest(reason.error.issues[0]?.message);
  const description = REPORT_DESCRIPTION_SCHEMA.safeParse(body.description ?? "");
  if (!description.success)
    return badRequest(description.error.issues[0]?.message);
  if (!body.targetUserId && !body.targetMessageId) {
    return badRequest("A target user or message is required");
  }

  const report = await db.report.create({
    data: {
      reporterId: user.id,
      targetUserId: body.targetUserId ?? null,
      targetMessageId: body.targetMessageId ?? null,
      reason: reason.data,
      description: description.data,
    },
  });

  // Notify all admins about the new report (real-time admin notification center).
  try {
    const { notifyAdminsNewReport } = await import("@/lib/notifications");
    await notifyAdminsNewReport({
      reportId: report.id,
      reason: reason.data,
      reporterName: user.fullName,
    });
  } catch {
    /* non-fatal */
  }

  return ok({ report: { id: report.id, status: report.status } });
});
