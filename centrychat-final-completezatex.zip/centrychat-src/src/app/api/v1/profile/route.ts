import { apiHandler, badRequest, ok, parseJsonBody } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { FULL_NAME_SCHEMA } from "@/lib/security/sanitize";
import { isValidLanguage } from "@/lib/i18n";
import { USERNAME_SCHEMA, isUsernameAvailable, suggestUsernames } from "@/lib/username";
import { normalizeGender, validateDateOfBirth, formatDateOfBirthForInput } from "@/lib/profile";
import { validateImageSource } from "@/lib/articles/image-source-validation";
// Content moderation — runs on bio + full name when those fields are
// being updated. Username is NOT moderated (it's a system identifier,
// not free-form content). avatarUrl is NOT moderated (it's a URL, validated
// separately by the SSRF-safe image-source validator).
import { moderateContent, recordModerationEvent } from "@/lib/moderation";

export const PATCH = apiHandler(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody<{
    fullName?: string;
    username?: string;
    bio?: string | null;
    language?: string;
    notificationPrefs?: Record<string, boolean>;
    gender?: string | null;
    dateOfBirth?: string | null;
    countryCode?: string | null;
    avatarUrl?: string | null;
  }>(req);

  const data: {
    fullName?: string;
    username?: string;
    bio?: string | null;
    language?: string;
    notificationPrefs?: string;
    gender?: string | null;
    dateOfBirth?: Date | null;
    countryCode?: string | null;
    avatarUrl?: string | null;
  } = {};
  if (body.fullName !== undefined) {
    const fn = FULL_NAME_SCHEMA.safeParse(body.fullName);
    if (!fn.success) return badRequest(fn.error.issues[0]?.message);
    data.fullName = fn.data;
  }
  if (body.username !== undefined) {
    const parsed = USERNAME_SCHEMA.safeParse(body.username);
    if (!parsed.success) return badRequest(parsed.error.issues[0]?.message);
    const available = await isUsernameAvailable(parsed.data, user.id);
    if (!available) {
      const suggestions = await suggestUsernames(parsed.data);
      return badRequest("This username is already taken.", { suggestions });
    }
    data.username = parsed.data;
  }
  if (body.bio !== undefined) {
    if (body.bio !== null && (typeof body.bio !== "string" || body.bio.length > 200)) {
      return badRequest("Bio must be 200 characters or less");
    }
    data.bio = body.bio;
  }
  if (body.language !== undefined) {
    if (!isValidLanguage(body.language)) {
      return badRequest("Unsupported language");
    }
    data.language = body.language;
  }
  if (body.notificationPrefs !== undefined) {
    // Security notifications cannot be disabled.
    const prefs = { ...body.notificationPrefs, security: true };
    data.notificationPrefs = JSON.stringify(prefs);
  }
  // Gender — optional. Pass `null` to clear the field (set to "not provided").
  // Pass "MALE" / "FEMALE" / "PREFER_NOT_TO_SAY" (case-insensitive) to set.
  // Unknown values are silently rejected to null.
  if (body.gender !== undefined) {
    data.gender = normalizeGender(body.gender);
  }
  // Date of Birth — optional. Pass `null` or "" to clear. Pass ISO date
  // (YYYY-MM-DD) to set. Validated server-side against future date + age
  // limits (see src/lib/profile.ts).
  if (body.dateOfBirth !== undefined) {
    const dobResult = validateDateOfBirth(body.dateOfBirth);
    if (!dobResult.valid) {
      return badRequest(dobResult.error);
    }
    data.dateOfBirth = dobResult.value;
  }
  // Country — optional on update (required on registration). Pass `null` to
  // clear. Pass an ISO 3166-1 alpha-2 code to set. Validated server-side.
  if (body.countryCode !== undefined) {
    const { normalizeCountryCode } = await import("@/lib/countries");
    const normalized = normalizeCountryCode(body.countryCode);
    if (body.countryCode && !normalized) {
      return badRequest("Invalid country code. Please select a valid country.");
    }
    data.countryCode = normalized;
  }
  // Profile picture URL — optional. Pass `null` or "" to clear. Pass a
  // Pinterest link OR a direct image URL to set.
  //
  // Phase 18 follow-up — applies the SAME shared `validateImageSource`
  // as Article cover images: only Pinterest + direct image URLs are
  // accepted. The validator does the SSRF-safe HTTP probe + Content-Type
  // sniffing via the EXISTING resolver (NOT modified). Rejects Google
  // Images / Instagram / Facebook / TikTok / random webpages / broken URLs.
  //
  // The existing `validateImageUrl` is no longer the only guard for
  // avatarUrl — the shared validator calls it internally (step 1) and
  // then applies the platform allowlist + Content-Type check on top.
  // The existing `avatarUrl` column is reused — no new database field.
  if (body.avatarUrl !== undefined) {
    if (body.avatarUrl === null || body.avatarUrl === "") {
      data.avatarUrl = null;
    } else if (typeof body.avatarUrl === "string") {
      const result = await validateImageSource(body.avatarUrl);
      if (!result.ok) {
        return badRequest(
          result.error ??
            "Invalid profile image link. Use a Pinterest link or a direct image URL."
        );
      }
      data.avatarUrl = result.url;
    } else {
      return badRequest("Profile picture URL must be a string");
    }
  }

  // ── Domain Blocklist Check for URLs in bio ──────────────────────────
  // The avatarUrl is already protected via validateImageSource → resolveMedia
  // (which has the blocklist check). But bio text can contain URLs that
  // aren't probed by validateImageSource — so we scan the bio explicitly.
  if (typeof data.bio === "string" && data.bio.length > 0) {
    const { checkTextForBlockedDomains } = await import("@/lib/security/domain-blocklist");
    const blockCheck = await checkTextForBlockedDomains(data.bio, user.id, "PROFILE");
    if (blockCheck.blocked) {
      return badRequest("This content contains a link that cannot be used on this platform.");
    }
  }

  // ── Content Moderation on bio + full name (spec §1) ────────────────
  // Only runs when those fields are being updated. Other fields (username,
  // avatarUrl, gender, dateOfBirth, language, notificationPrefs) are NOT
  // free-form text and don't need moderation.
  if (typeof data.bio === "string" && data.bio.length > 0) {
    const m = await moderateContent({
      text: data.bio,
      contentType: "profile_bio",
      userId: user.id,
    });
    if (m.action === "BLOCK") {
      void recordModerationEvent({
        result: m,
        contentType: "profile_bio",
        contentId: user.id,
        userId: user.id,
        originalText: data.bio,
      });
      return badRequest(m.userMessage);
    }
    if (m.action !== "ALLOW") {
      void recordModerationEvent({
        result: m,
        contentType: "profile_bio",
        contentId: user.id,
        userId: user.id,
        originalText: data.bio,
      });
    }
  }
  if (typeof data.fullName === "string") {
    const m = await moderateContent({
      text: data.fullName,
      contentType: "profile_full_name",
      userId: user.id,
    });
    if (m.action === "BLOCK") {
      void recordModerationEvent({
        result: m,
        contentType: "profile_full_name",
        contentId: user.id,
        userId: user.id,
        originalText: data.fullName,
      });
      return badRequest(m.userMessage);
    }
    if (m.action !== "ALLOW") {
      void recordModerationEvent({
        result: m,
        contentType: "profile_full_name",
        contentId: user.id,
        userId: user.id,
        originalText: data.fullName,
      });
    }
  }

  const updated = await db.user.update({
    where: { id: user.id },
    data,
    select: {
      id: true,
      fullName: true,
      email: true,
      username: true,
      bio: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
      role: true,
      status: true,
      language: true,
      notificationPrefs: true,
      gender: true,
      dateOfBirth: true,
      countryCode: true,
    },
  });

  return ok({
    user: {
      ...updated,
      // Format DOB as YYYY-MM-DD so the user's own profile-edit form
      // (an <input type="date">) can use it directly as `value`.
      dateOfBirth: formatDateOfBirthForInput(updated.dateOfBirth),
      notificationPrefs: updated.notificationPrefs
        ? JSON.parse(updated.notificationPrefs)
        : null,
    },
  });
});

/**
 * GET — return the current user's profile including notification preferences
 * AND the user's own gender + date of birth (NEVER exposed publicly — only
 * the user's own /api/v1/profile and /api/v1/auth/me endpoints return these).
 *
 * DOB is formatted as YYYY-MM-DD for the profile-edit <input type="date">.
 */
export const GET = apiHandler(async () => {
  const user = await requireUser();
  const u = await db.user.findUnique({
    where: { id: user.id },
    select: {
      id: true,
      fullName: true,
      email: true,
      username: true,
      bio: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
      role: true,
      status: true,
      language: true,
      notificationPrefs: true,
      gender: true,
      dateOfBirth: true,
    },
  });
  if (!u) return ok({ user: null });
  return ok({
    user: {
      ...u,
      dateOfBirth: formatDateOfBirthForInput(u.dateOfBirth),
      notificationPrefs: u.notificationPrefs
        ? JSON.parse(u.notificationPrefs)
        : { message: true, security: true, system: true, account: true, moderation: true },
    },
  });
});
