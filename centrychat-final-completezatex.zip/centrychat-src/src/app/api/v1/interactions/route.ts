import { apiHandler, badRequest, ok, parseJsonBody, rateLimited} from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";
import { db } from "@/lib/database";

/**
 * POST /api/v1/interactions
 * Track a user interaction with content (view, like, skip, read, video_watch, etc.)
 * This feeds the recommendation algorithm's interest learning.
 *
 * Phase 1 Personalized Feed — extended with granular event types:
 *   Positive: view, open, read, read_long, like, comment, share, save,
 *             follow, profile_visit, video_watch, video_complete
 *   Negative: skip, not_interested, hide, unfollow
 *   Analytics-only (no interest delta): impression, click
 *
 * DEDUPLICATION (spec §17):
 *   For "view"/"open" events on the SAME content within 60 seconds, we
 *   skip the duplicate (no new ContentInteraction row, no interest delta).
 *   This prevents React re-renders / page refreshes from inflating the
 *   view count + interest score. The 60-second window is short enough to
 *   allow legitimate re-views (user revisits after a while) but long
 *   enough to suppress re-render storms.
 *
 * SECURITY (spec §20):
 *   - userId is ALWAYS derived from the session (requireVerifiedUser),
 *     NEVER from the request body.
 *   - contentType + contentId are validated (non-empty strings).
 *   - action is validated against the allowlist.
 *   - duration (when present) is validated as a non-negative integer.
 *
 * RESPONSE: { tracked: boolean, deduplicated?: boolean }
 *   tracked=true when a new interaction was recorded.
 *   tracked=true, deduplicated=true when a duplicate was detected + skipped
 *   (the caller doesn't need to distinguish — both are "success").
 */
const VALID_ACTIONS = new Set([
  // Positive signals
  "view", "open", "read", "read_long",
  "like", "comment", "share", "save",
  "follow", "profile_visit",
  "video_watch", "video_complete",
  // Negative signals
  "skip", "not_interested", "hide", "unfollow",
  // Analytics-only (no interest delta, but still recorded)
  "impression", "click",
]);

// Actions that are subject to the 60-second dedup window.
// These are "passive" events that can fire multiple times from re-renders.
// Active events (like, comment, share, follow, etc.) have their OWN
// dedup at the source (e.g. PostLike's @@unique constraint), so we
// don't need a time-window dedup here.
const DEDUP_ACTIONS = new Set(["view", "open", "impression"]);
const DEDUP_WINDOW_SECONDS = 60;

export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  const rl = await checkRateLimit(`interaction:${user.id}`, RATE_LIMITS.interaction);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));
  const body = await parseJsonBody<{
    contentType?: string;
    contentId?: string;
    action?: string;
    topicSlug?: string;
    duration?: number;
  }>(req);

  if (!body.contentType || !body.contentId || !body.action) {
    return badRequest("contentType, contentId, and action are required");
  }

  if (!VALID_ACTIONS.has(body.action)) {
    return badRequest(`Invalid action. Valid actions: ${[...VALID_ACTIONS].join(", ")}`);
  }

  // Validate duration (when present) — non-negative integer, max 1 hour.
  let duration: number | undefined;
  if (body.duration !== undefined && body.duration !== null) {
    if (typeof body.duration !== "number" || !Number.isFinite(body.duration) || body.duration < 0) {
      return badRequest("duration must be a non-negative number");
    }
    duration = Math.min(Math.floor(body.duration), 3600); // cap at 1h
  }

  // ── Deduplication for passive events ───────────────────────────────
  // Check if the same (userId, contentId, action) was recorded in the
  // last 60 seconds. If so, skip — this is a re-render/retry, not a
  // genuine new interaction.
  if (DEDUP_ACTIONS.has(body.action)) {
    const since = new Date(Date.now() - DEDUP_WINDOW_SECONDS * 1000);
    const existing = await db.contentInteraction.findFirst({
      where: {
        userId: user.id,
        contentId: body.contentId,
        action: body.action,
        createdAt: { gte: since },
      },
      select: { id: true },
    }).catch(() => null);
    if (existing) {
      // Duplicate detected — return success (tracked=true) so the client
      // doesn't retry, but don't record a new row.
      return ok({ tracked: true, deduplicated: true });
    }
  }

  const engine = getRecommendationEngine();
  await engine.trackInteraction({
    userId: user.id,
    contentType: body.contentType,
    contentId: body.contentId,
    action: body.action,
    topicSlug: body.topicSlug,
    duration,
  });

  return ok({ tracked: true });
});
