import { NextResponse } from "next/server";
import { pingDatabase, getDatabaseProvider } from "@/lib/database";

export const dynamic = "force-dynamic";

export async function GET() {
  const db = await pingDatabase();
  if (!db.ok) {
    return NextResponse.json(
      {
        status: "not_ready",
        database: { ok: false, provider: getDatabaseProvider(), error: db.error },
      },
      { status: 503 }
    );
  }
  return NextResponse.json({
    status: "ready",
    database: { ok: true, provider: getDatabaseProvider(), latencyMs: db.latencyMs },
    timestamp: new Date().toISOString(),
    version: "v1",
  });
}
