import { apiHandler, badRequest, ok, rateLimited } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { resolveMedia } from "@/lib/media/resolver";
import { logger } from "@/lib/logging";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";

/**
 * POST /api/v1/media/resolve
 *
 * Resolve any URL (image, video, social media post, webpage, etc.) into a
 * normalized `ResolvedMedia` object.
 *
 * Request body: { url: string }
 * Response:     { ok: true, data: { media: ResolvedMedia } }
 *
 * SECURITY:
 *   - requireUser: must be authenticated (avoids public SSRF abuse).
 *   - Server-side SSRF protection (now with DNS pinning via undici Agent):
 *     rejects private IPs, loopback, metadata endpoints, dangerous schemes.
 *     The DNS-rebinding TOCTOU gap is closed — the IP validated by
 *     `isPrivateHostname` is the SAME IP undici connects to.
 *     See src/lib/media/resolver.ts → pinnedLookup → ssrfSafeAgent.
 *   - 5-minute response cache per URL.
 *   - 5-second timeout per probe.
 *   - 5-redirect cap.
 *   - 5 MiB max body read.
 *
 * The endpoint NEVER proxies the response body to the client — only the
 * extracted metadata (Content-Type, og:image URL, title, etc.). The
 * client then loads the actual media (image/video/embed) directly from
 * the original host via its own <img>/<video>/<iframe> tags.
 *
 * Rate limit (H-3 fix):
 *   - 30 resolves/min per user (RATE_LIMITS.mediaResolve).
 *   - Prevents SSRF amplification abuse — without this, an authenticated
 *     user could flood external hosts with HTTP probes via the resolver,
 *     using the platform as a DDoS amplifier.
 *   - Fail-open by default — a Redis outage during normal traffic shouldn't
 *     break media resolution for legit users. The SSRF-safe resolver itself
 *     is the primary defense.
 */
export const POST = apiHandler(async (req) => {
  const user = await requireUser();

  // Rate limit per user — 30/min (RATE_LIMITS.mediaResolve).
  const rl = await checkRateLimit(
    `media-resolve:${user.id}`,
    RATE_LIMITS.mediaResolve
  );
  if (!rl.ok) {
    return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));
  }

  const body = await parseBody(req);

  if (!body.url || typeof body.url !== "string") {
    return badRequest("Missing `url` field");
  }
  const trimmed = body.url.trim();
  if (!trimmed) return badRequest("Empty URL");
  if (trimmed.length > 2048) return badRequest("URL too long");

  try {
    const media = await resolveMedia(trimmed);
    return ok({ media });
  } catch (err) {
    logger.error("application", "Media resolve failed", {
      url: trimmed,
      userId: user.id,
      error: err instanceof Error ? err.message : "unknown",
    });
    return ok({
      media: {
        originalUrl: trimmed,
        provider: "unknown",
        type: "unknown",
        mediaUrl: "",
        embedUrl: null,
        thumbnailUrl: null,
        title: null,
        description: null,
        contentType: null,
        probed: false,
        note: "resolver-error",
      },
    });
  }
});

async function parseBody(req: Request): Promise<{ url?: unknown }> {
  try {
    return (await req.json()) as { url?: unknown };
  } catch {
    return {};
  }
}
