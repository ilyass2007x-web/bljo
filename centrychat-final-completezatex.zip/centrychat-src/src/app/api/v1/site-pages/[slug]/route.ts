import { apiHandler, notFound, ok } from "@/lib/api";
import { getPublishedSitePage, type SitePageSlug } from "@/lib/site-pages";

/**
 * GET /api/v1/site-pages/:slug
 * --------------------------------
 * Public read endpoint for a single SitePage.
 *
 * NO authentication required — returns the PUBLISHED content only.
 * Drafts (isPublished=false) return 404 — the public cannot see them.
 *
 * Valid slugs: about | privacy | terms | contact
 * Any other slug returns 404.
 *
 * Caching:
 *   - Server-side: cacheGetOrSet (30s TTL) keyed by slug.
 *   - When the admin saves via PUT /api/v1/admin/site-pages/:slug, the
 *     cache for that slug is invalidated — the next public fetch (within
 *     30s) returns the updated content.
 *
 * Response shape:
 *   { page: { slug, title, content, seoTitle, seoDescription } | null }
 *   When page is null (not found / draft / unknown slug), the response
 *   is HTTP 404 with a "Not found" error (so the SPA can show a 404 page).
 */
export const GET = apiHandler(async (_req, ctx) => {
  const { slug } = await ctx.params;
  if (!slug || !["about", "privacy", "terms", "contact"].includes(slug)) {
    return notFound("Page not found");
  }
  const page = await getPublishedSitePage(slug as SitePageSlug);
  if (!page) {
    return notFound("Page not found");
  }
  return ok({ page });
});
