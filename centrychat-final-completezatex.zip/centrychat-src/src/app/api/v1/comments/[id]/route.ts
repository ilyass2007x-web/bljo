import { apiHandler, ok, notFound } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { canModerate } from "@/lib/permissions";

/**
 * DELETE /api/v1/comments/:id
 * ---------------------------
 * Delete a post comment (top-level OR reply at any depth).
 *
 * Replies live in the SAME PostComment table as top-level comments —
 * they just have `parentCommentId` set instead of NULL. The same ID
 * space + the same DELETE handler serve both, so this endpoint works
 * for deleting comments AND replies without any special-casing.
 *
 * Auth: requires authenticated + verified user.
 * Authorization (server-side, source of truth):
 *   - The comment's AUTHOR can delete their own comment.
 *   - The POST'S AUTHOR can delete any comment on their own post
 *     (per spec §10 — gives post owners moderation power over their
 *     own content).
 *   - MODERATOR / ADMIN / SUPER_ADMIN can delete any comment (matches
 *     the UI's `canDelete` logic in CommentsPage — admins see the
 *     trash icon on every comment). This was previously missing,
 *     causing admins to receive "Comment not found" (404 used as
 *     defense-in-depth to avoid leaking the comment's existence to
 *     non-authorized users) even though the comment existed.
 *   - Anyone else gets 404 (we don't leak the comment's existence
 *     to non-authorized users — this avoids information disclosure).
 *
 * Note: existing admin moderation is respected — admins still delete via
 * their own moderation tools (AdminPanel). This endpoint is for
 * self-deletion + post-author + admin moderation only.
 *
 * Cascade: the Prisma schema's `onDelete: Cascade` on
 * `PostComment.replies` (self-relation) + `PostComment.likes` handles
 * cleanup of nested replies + likes automatically. Deleting a parent
 * comment removes all of its descendants in one SQL operation.
 *
 * Response: { ok: true }
 */
export const DELETE = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;

  if (!id || typeof id !== "string") {
    return notFound("Comment not found.");
  }

  // Fetch the comment with the post's authorId so we can check ALL
  // ownership paths in a single query.
  const comment = await db.postComment.findUnique({
    where: { id },
    select: {
      authorId: true,
      post: {
        select: { authorId: true },
      },
    },
  });

  if (!comment) {
    return notFound("Comment not found.");
  }

  // Authorization: comment author OR post author OR moderator/admin.
  // `canModerate` returns true for MODERATOR / ADMIN / SUPER_ADMIN
  // (any role with rank >= MODERATOR), matching the UI's `canDelete`
  // logic in comments-page.tsx + article-comments-page.tsx which
  // renders the trash button for ADMIN / SUPER_ADMIN (and would
  // also cover MODERATOR if/when the UI exposes it).
  const isCommentAuthor = comment.authorId === user.id;
  const isPostAuthor = comment.post.authorId === user.id;
  const isModerator = canModerate(user.role);

  if (!isCommentAuthor && !isPostAuthor && !isModerator) {
    // Not authorized — return 404 to avoid leaking the comment's existence.
    return notFound("Comment not found.");
  }

  await db.postComment.delete({ where: { id } });

  return ok({ ok: true });
});
