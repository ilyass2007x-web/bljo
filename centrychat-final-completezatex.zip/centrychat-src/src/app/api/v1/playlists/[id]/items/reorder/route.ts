import { apiHandler, ok, notFound, badRequest, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { db } from "@/lib/database";
import {
  getPlaylistForOwner,
  reorderItems,
  reorderItem,
} from "@/lib/playlists";

/**
 * PATCH /api/v1/playlists/:id/items/reorder
 * ------------------------------------------
 * Reorder items in a playlist (owner only).
 *
 * Two supported body shapes:
 *
 *   1. Single-item move (matches the Collection reorder API):
 *        { itemId: string, newPosition: number }
 *      Removes the item from its current position, inserts it at the
 *      requested `newPosition` (clamped to [0, length-1]), then rewrites
 *      ALL sibling positions to a clean 0,1,2,... sequence.
 *
 *   2. Full-list drag-and-drop (preferred for @dnd-kit Sortable):
 *        { orderedItemIds: string[] }
 *      The client sends the complete ordered list of item IDs after a
 *      drag. We rewrite positions 0,1,2,... to match.
 *
 * The two modes are mutually exclusive — the API detects which one
 * based on which field is present in the body. If both are present,
 * `orderedItemIds` takes precedence (it's the more explicit intent).
 *
 * SECURITY:
 *   - Owner-only — verified via getPlaylistForOwner (IDOR-safe).
 *   - For mode 2 (orderedItemIds), every ID in the list is verified
 *     to belong to this playlist (no mixing IDs from different
 *     playlists). The list must contain EXACTLY the same set of IDs
 *     as the current playlist (no duplicates, no missing items).
 *
 * Rate limit: playlistItem (default 60/minute per user).
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return notFound("Playlist not found.");
  }

  const rl = await checkRateLimit(
    `playlist-item:${user.id}`,
    RATE_LIMITS.playlistItem
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Playlist not found.");

  // ── Ownership check ───────────────────────────────────────────────
  const playlist = await getPlaylistForOwner(id, user.id);
  if (!playlist) return notFound("Playlist not found.");

  const body = await req.json().catch(() => ({} as unknown));

  // ── Mode 2: full-list drag-and-drop (preferred) ──────────────────
  const rawOrderedIds = (body as { orderedItemIds?: unknown }).orderedItemIds;
  if (rawOrderedIds !== undefined) {
    if (!Array.isArray(rawOrderedIds) || rawOrderedIds.length === 0) {
      return badRequest("orderedItemIds must be a non-empty array of item IDs");
    }
    // Validate types (array of strings).
    const orderedItemIds = rawOrderedIds as unknown[];
    if (!orderedItemIds.every((v) => typeof v === "string")) {
      return badRequest("orderedItemIds must contain only strings");
    }
    const newOrder = await reorderItems(
      id,
      orderedItemIds as string[],
      user.id
    );
    // Bump the playlist's updatedAt so it sorts first in the user's list.
    await db.playlist.update({
      where: { id },
      data: { updatedAt: new Date() },
    });
    return ok({ orderedItemIds: newOrder });
  }

  // ── Mode 1: single-item move (matches Collection reorder API) ────
  const itemId = (body as { itemId?: unknown }).itemId;
  const newPosition = (body as { newPosition?: unknown }).newPosition;
  if (typeof itemId !== "string" || typeof newPosition !== "number") {
    return badRequest(
      "Body must contain either { orderedItemIds: string[] } or { itemId: string, newPosition: number }"
    );
  }
  if (!Number.isInteger(newPosition) || newPosition < 0) {
    return badRequest("newPosition must be a non-negative integer");
  }
  const newOrder = await reorderItem(id, itemId, newPosition, user.id);
  await db.playlist.update({
    where: { id },
    data: { updatedAt: new Date() },
  });
  return ok({ orderedItemIds: newOrder });
});
