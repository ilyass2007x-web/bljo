import { apiHandler, ok, notFound, badRequest, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser, getCurrentUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { getSettingNumber } from "@/lib/settings";
import { db } from "@/lib/database";
import {
  getPlaylistForOwner,
  getPlaylistForViewer,
  serializeItem,
  hydratePlaylistItems,
  validateArticleExistsAndPublished,
  countPlaylistItems,
  getNextPosition,
  type PlaylistItemDTO,
} from "@/lib/playlists";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/playlists/:id/items
 * -------------------------------
 * List items in a playlist, ordered by position ASC + addedAt ASC + id ASC.
 *
 * Auth: requires authenticated + verified user (anonymous visitors use
 * the /playlist/[slug] server-rendered page, which fetches items directly
 * from the DB — this API endpoint is for the SPA collection-detail view
 * + the Add-to-Playlist dialog preview).
 *
 * Visibility (IDOR-safe):
 *   - Owner: sees all items regardless of playlist visibility.
 *   - Non-owner: sees items ONLY if the playlist is public.
 *   - Non-existent / private-non-owner: 404 (no leakage).
 *
 * Response: { items: SerializedItem[] (with hydrated Article data) }
 */
export const GET = apiHandler(async (req, ctx) => {
  const viewer = await getCurrentUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return notFound("Playlist not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Playlist not found.");

  // Authorization: owner OR public. Use getPlaylistForViewer (handles
  // owner + admin + public visibility in one call).
  const playlist = await getPlaylistForViewer(id, viewer);
  if (!playlist) return notFound("Playlist not found.");

  // Fetch all items (no cursor pagination here — playlists are capped at
  // playlist.max_items = 200 by default, manageable in one shot).
  const url = new URL(req.url);
  const limit = Math.min(
    Math.max(Number(url.searchParams.get("limit") ?? "200"), 1),
    500
  );

  const allItems = await db.playlistItem.findMany({
    where: { playlistId: id },
    orderBy: [{ position: "asc" }, { addedAt: "asc" }, { id: "asc" }],
    take: limit,
    select: ITEM_LIST_SELECT,
  });

  // Batched content hydration — single findMany for all article IDs.
  const hydrated = await hydratePlaylistItems(allItems);

  return ok({
    items: allItems.map((i) => ({
      ...serializeItem(i as PlaylistItemDTO),
      article: hydrated.get(i.articleId) ?? null,
    })),
  });
});

/**
 * POST /api/v1/playlists/:id/items
 * --------------------------------
 * Add an Article to a playlist. Appends to the end (position = next).
 *
 * Body: { articleId: string }
 *
 * Pre-insertion validation:
 *   1. Verify playlist ownership (IDOR-safe — non-owner gets 404).
 *   2. Verify the target Article exists + is PUBLISHED.
 *   3. Verify playlist capacity (playlist.max_items, default 200).
 *   4. Verify the item does not already exist (DB @@unique is the
 *      final protection; we check explicitly for a clean 400 response).
 *
 * On duplicate: returns 400 with "already in this playlist" message
 * (the UI uses this to mark the playlist as "already added").
 *
 * Rate limit: playlistItem (default 60/minute per user).
 *
 * SECURITY:
 *   - articleId is validated server-side (existence + PUBLISHED status).
 *     A fake articleId OR a draft articleId is rejected with 400.
 *   - The client cannot supply a `position` — new items ALWAYS append to
 *     the end. Reordering is a separate endpoint (PATCH .../items/reorder).
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return notFound("Playlist not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Playlist not found.");

  // ── 1. Ownership check ────────────────────────────────────────────
  const playlist = await getPlaylistForOwner(id, user.id);
  if (!playlist) return notFound("Playlist not found.");

  // ── Rate limit (after ownership — don't waste the check on non-owners)
  const rl = await checkRateLimit(
    `playlist-item:${user.id}`,
    RATE_LIMITS.playlistItem
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  // ── 2. Validate body ──────────────────────────────────────────────
  const body = await req.json().catch(() => ({} as unknown));
  const rawArticleId = (body as { articleId?: unknown }).articleId;
  if (typeof rawArticleId !== "string" || rawArticleId.trim().length === 0) {
    return badRequest("articleId is required");
  }
  const articleId = rawArticleId.trim();

  // ── 3. Verify article exists + is PUBLISHED ───────────────────────
  const exists = await validateArticleExistsAndPublished(articleId);
  if (!exists) {
    return badRequest(
      "The article you're trying to add does not exist or is not published."
    );
  }

  // ── 4. Capacity check ──────────────────────────────────────────────
  const maxItems = (await getSettingNumber("playlist.max_items")) ?? 200;
  const currentCount = await countPlaylistItems(id);
  if (currentCount >= maxItems) {
    return badRequest(
      `Playlist is full (${maxItems} items max). Remove an item before adding more.`
    );
  }

  // ── 5. Duplicate check (clean 400, not a P2002 leak) ─────────────
  const existing = await db.playlistItem.findUnique({
    where: {
      playlistId_articleId: { playlistId: id, articleId },
    },
    select: { id: true },
  });
  if (existing) {
    return badRequest("This article is already in this playlist.");
  }

  // ── 6. Insert at the end (position = next) ────────────────────────
  const nextPosition = await getNextPosition(id);
  const item = await db.playlistItem.create({
    data: {
      playlistId: id,
      articleId,
      position: nextPosition,
    },
    select: ITEM_LIST_SELECT,
  });

  // Bump the playlist's updatedAt so it sorts first in the user's list.
  await db.playlist.update({
    where: { id },
    data: { updatedAt: new Date() },
  });

  return ok({ item: serializeItem(item as PlaylistItemDTO) });
});

// ── Shared projection ──────────────────────────────────────────────────────
const ITEM_LIST_SELECT = {
  id: true,
  playlistId: true,
  articleId: true,
  position: true,
  addedAt: true,
} as const satisfies Prisma.PlaylistItemSelect;
