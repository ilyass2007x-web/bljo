import { apiHandler, ok, badRequest, notFound, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser, getCurrentUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { getSettingNumber } from "@/lib/settings";
import { db } from "@/lib/database";
import {
  getPlaylistForOwner,
  getPlaylistForViewer,
  serializePlaylist,
  validatePlaylistDescription,
  validatePlaylistName,
  type PlaylistDTO,
} from "@/lib/playlists";
import { validateImageSource } from "@/lib/articles/image-source-validation";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/playlists/:id
 * -------------------------
 * Fetch a single playlist by ID. Visibility:
 *   - Owner: sees everything they own (any visibility).
 *   - Non-owner: sees ONLY public playlists. Private playlists return 404
 *     (no existence leakage — IDOR-safe).
 *   - Admin: can view any playlist (read-only).
 *
 * The response includes the playlist row + itemCount. The items themselves
 * are fetched separately via GET /api/v1/playlists/:id/items.
 */
export const GET = apiHandler(async (req, ctx) => {
  // GET is public-friendly: a logged-out visitor can view a public playlist.
  // We use getCurrentUser (not requireVerifiedUser) so anonymous visitors
  // can deep-link to a public playlist via /playlist/[slug] (which calls
  // the slug endpoint, not this one — but the admin panel + share dialog
  // may call this endpoint directly).
  const viewer = await getCurrentUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return notFound("Playlist not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Playlist not found.");

  const playlist = await getPlaylistForViewer(id, viewer);
  if (!playlist) return notFound("Playlist not found.");

  return ok({ playlist: serializePlaylist(playlist) });
});

/**
 * PATCH /api/v1/playlists/:id
 * ---------------------------
 * Update a playlist (owner only).
 *
 * Body: { name?, description?, coverImage?, isPublic? } — only fields
 * present in the body are updated.
 *
 * Validation (same as POST create):
 *   - name: 1..playlist.max_name_length
 *   - description: 0..playlist.max_description_length
 *   - coverImage: validated via shared `validateImageSource`
 *   - isPublic: boolean only
 *
 * SECURITY:
 *   - Owner-only — verified via getPlaylistForOwner (IDOR-safe: filters
 *     by id AND ownerId). Non-owner gets 404 (no leakage).
 *   - Slug is NOT updated on PATCH — it stays immutable after creation
 *     (so existing /playlist/[slug] links keep working). This matches
 *     the topic-slug immutability rule.
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return notFound("Playlist not found.");
  }

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Playlist not found.");

  // ── Ownership check (IDOR-safe) ───────────────────────────────────
  const playlist = await getPlaylistForOwner(id, user.id);
  if (!playlist) return notFound("Playlist not found.");

  const body = await req.json().catch(() => ({} as unknown));
  const maxNameLength = (await getSettingNumber("playlist.max_name_length")) ?? 120;
  const maxDescLength =
    (await getSettingNumber("playlist.max_description_length")) ?? 1000;

  const data: Prisma.PlaylistUpdateInput = {};

  // ── Validate name ──────────────────────────────────────────────────
  if ((body as { name?: unknown }).name !== undefined) {
    data.name = validatePlaylistName(
      (body as { name?: unknown }).name,
      maxNameLength
    );
    // Note: slug is NOT regenerated on name change (immutability rule).
  }

  // ── Validate description ───────────────────────────────────────────
  if ((body as { description?: unknown }).description !== undefined) {
    data.description = validatePlaylistDescription(
      (body as { description?: unknown }).description,
      maxDescLength
    );
  }

  // ── Validate isPublic ──────────────────────────────────────────────
  if ((body as { isPublic?: unknown }).isPublic !== undefined) {
    const v = (body as { isPublic?: unknown }).isPublic;
    if (typeof v !== "boolean") {
      return badRequest("isPublic must be a boolean");
    }
    data.isPublic = v;
  }

  // ── Validate coverImage ───────────────────────────────────────────
  const rawCover = (body as { coverImage?: unknown }).coverImage;
  if (rawCover !== undefined) {
    if (rawCover === null) {
      data.coverImage = null;
    } else if (typeof rawCover === "string") {
      const trimmed = rawCover.trim();
      if (trimmed.length === 0) {
        data.coverImage = null;
      } else {
        const result = await validateImageSource(trimmed);
        if (!result.ok) {
          return badRequest(
            result.error ??
              "Invalid cover image link. Use a Pinterest link or a direct image URL."
          );
        }
        data.coverImage = result.url;
      }
    } else {
      return badRequest("coverImage must be a string");
    }
  }

  // ── Persist ───────────────────────────────────────────────────────
  const updated = await db.playlist.update({
    where: { id },
    data,
    select: PLAYLIST_DETAIL_SELECT,
  });

  return ok({ playlist: serializePlaylist(updated as PlaylistDTO) });
});

/**
 * DELETE /api/v1/playlists/:id
 * ----------------------------
 * Delete a playlist (owner only).
 *
 * Cascade strategy: PlaylistItem rows are cascade-deleted with the
 * playlist (via the FK on playlistItem.playlistId). The Articles
 * themselves are UNAFFECTED — only the items are removed.
 *
 * SECURITY: owner-only via getPlaylistForOwner (IDOR-safe).
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return notFound("Playlist not found.");
  }

  const rl = await checkRateLimit(
    `playlist-item:${user.id}`,
    RATE_LIMITS.playlistItem
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Playlist not found.");

  // Ownership check (IDOR-safe).
  const playlist = await getPlaylistForOwner(id, user.id);
  if (!playlist) return notFound("Playlist not found.");

  await db.playlist.delete({ where: { id } });

  return ok({ deleted: true, id });
});

// ── Shared projection ──────────────────────────────────────────────────────
const PLAYLIST_DETAIL_SELECT = {
  id: true,
  ownerId: true,
  name: true,
  slug: true,
  description: true,
  coverImage: true,
  isPublic: true,
  createdAt: true,
  updatedAt: true,
  owner: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: { select: { items: true } },
} as const satisfies Prisma.PlaylistSelect;
