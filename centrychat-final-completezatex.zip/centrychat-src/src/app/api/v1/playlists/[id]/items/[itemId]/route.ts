import { apiHandler, ok, notFound, badRequest, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { db } from "@/lib/database";
import {
  getPlaylistForOwner,
  normalizePositions,
} from "@/lib/playlists";

/**
 * DELETE /api/v1/playlists/:id/items/:itemId
 * ------------------------------------------
 * Remove an item from a playlist (owner only).
 *
 * Removes the PlaylistItem row. The Article itself is UNAFFECTED — only
 * the playlist entry is removed (spec §3: "Delete Content from the
 * Playlist without deleting the original Article").
 *
 * After deletion, remaining items' positions are normalized to a clean
 * 0,1,2,... sequence (spec §3: "Reorder all elements").
 *
 * SECURITY: owner-only — verified via getPlaylistForOwner (IDOR-safe).
 * We also verify the item belongs to the playlist (filtering by
 * playlistId AND id) so a client can't delete an item from a different
 * playlist by mixing IDs.
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return notFound("Playlist not found.");
  }

  const rl = await checkRateLimit(
    `playlist-item:${user.id}`,
    RATE_LIMITS.playlistItem
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const { id, itemId } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Playlist not found.");
  if (!itemId || typeof itemId !== "string") return notFound("Item not found.");

  // ── Ownership check ───────────────────────────────────────────────
  const playlist = await getPlaylistForOwner(id, user.id);
  if (!playlist) return notFound("Playlist not found.");

  // ── Delete the item (filtered by playlistId AND id — defensive)
  // The unique constraint on (playlistId, articleId) means we can use
  // a findFirst to locate the item by id + playlistId.
  const item = await db.playlistItem.findFirst({
    where: { id: itemId, playlistId: id },
    select: { id: true },
  });
  if (!item) return notFound("Item not found.");

  await db.playlistItem.delete({ where: { id: itemId } });

  // Normalize remaining positions (transactional — no gaps after deletion).
  await normalizePositions(id);

  return ok({ deleted: true, id: itemId });
});
