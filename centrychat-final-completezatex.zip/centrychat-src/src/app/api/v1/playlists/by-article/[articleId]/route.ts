import { apiHandler, ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import {
  getPlaylistsContainingArticle,
  serializePlaylist,
} from "@/lib/playlists";

/**
 * GET /api/v1/playlists/by-article/:articleId
 * -------------------------------------------
 * Return the playlists that contain the given Article (spec §5, §17).
 *
 * Used by the Article reading page to render the "Playlist Navigation"
 * section: when an Article is part of one or more Playlists, the article
 * page shows each playlist's items + highlights the current article's
 * position so the user can navigate to the next/previous part.
 *
 * Visibility (IDOR-safe):
 *   - PUBLIC playlists containing this article → returned to anyone.
 *   - PRIVATE playlists containing this article → returned ONLY if the
 *     viewer is the owner.
 *   - Anonymous viewers → only public playlists.
 *
 * Query params:
 *   - ?limit=<n>  (default 10, max 50)  — cap the number of playlists
 *     returned. An article that's in 50 playlists would otherwise produce
 *     a huge payload.
 *
 * Response: { playlists: SerializedPlaylist[] }
 */
export const GET = apiHandler(async (req, ctx) => {
  // GET is viewer-friendly: a logged-out visitor can see the public
  // playlists that contain this article (so the article reading page
  // works for anonymous referrers too — important for SEO).
  const viewer = await getCurrentUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return ok({ playlists: [] });
  }

  const { articleId } = await ctx.params;
  if (!articleId || typeof articleId !== "string") {
    return ok({ playlists: [] });
  }

  const url = new URL(req.url);
  const limit = Math.min(
    Math.max(Number(url.searchParams.get("limit") ?? "10"), 1),
    50
  );

  const playlists = await getPlaylistsContainingArticle(articleId, viewer, {
    limit,
  });

  return ok({
    playlists: playlists.map((p) => serializePlaylist(p)),
  });
});
