import { apiHandler, ok, notFound } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import {
  getPublicPlaylistBySlug,
  serializePlaylist,
} from "@/lib/playlists";

/**
 * GET /api/v1/playlists/slug/:slug
 * -------------------------------
 * Fetch a playlist by its public slug.
 *
 * Used by the client-side Add-to-Playlist dialog + the SEO-friendly
 * /playlist/[slug] route (which renders the page server-side from a
 * direct DB query — this endpoint is for the SPA fallback / share
 * link preview).
 *
 * Visibility (IDOR-safe):
 *   - Owner can view their own playlist by slug (any visibility).
 *   - Admin can view any playlist by slug.
 *   - Non-owner / unauth viewer can view ONLY public playlists by slug.
 *   - Private playlist by slug → 404 (no existence leakage).
 *
 * Auth: optional (anonymous visitors can view public playlists).
 */
export const GET = apiHandler(async (req, ctx) => {
  const viewer = await getCurrentUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return notFound("Playlist not found.");
  }

  const { slug } = await ctx.params;
  if (!slug || typeof slug !== "string") {
    return notFound("Playlist not found.");
  }

  const playlist = await getPublicPlaylistBySlug(slug, viewer);
  if (!playlist) return notFound("Playlist not found.");

  return ok({ playlist: serializePlaylist(playlist) });
});
