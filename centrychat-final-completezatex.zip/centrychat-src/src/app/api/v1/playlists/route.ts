import { apiHandler, ok, badRequest, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import { getSettingNumber } from "@/lib/settings";
import { db } from "@/lib/database";
import {
  countUserPlaylists,
  generateUniquePlaylistSlug,
  serializePlaylist,
  validatePlaylistDescription,
  validatePlaylistName,
  type PlaylistDTO,
} from "@/lib/playlists";
import { validateImageSource } from "@/lib/articles/image-source-validation";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/playlists
 * ---------------------
 * List the authenticated user's OWN playlists (private + public).
 *
 * Auth: requires authenticated + verified user.
 *
 * Query params:
 *   - ?public=true → list only the user's PUBLIC playlists (for the
 *     "discover public playlists" view + the share flow).
 *   - ?search=<query> → filter by name (case-insensitive contains).
 *
 * Response: { playlists: SerializedPlaylist[] }
 *
 * SECURITY: ownerId is ALWAYS derived from the session. The query filters
 * by ownerId = user.id — users can NEVER see another user's private
 * playlists. For listing OTHER users' public playlists, use the
 * /api/v1/search/all endpoint with `?type=playlist`.
 */
export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return ok({ playlists: [] });
  }

  const url = new URL(req.url);
  const onlyPublic = url.searchParams.get("public") === "true";
  const search = (url.searchParams.get("search") ?? "").trim();

  const where: Prisma.PlaylistWhereInput = { ownerId: user.id };
  if (onlyPublic) where.isPublic = true;
  if (search.length >= 2) {
    where.name = { contains: search, mode: "insensitive" };
  }

  const playlists = await db.playlist.findMany({
    where,
    orderBy: { updatedAt: "desc" },
    take: 100, // safety cap — a single user shouldn't have > 100 playlists
    select: PLAYLIST_LIST_SELECT,
  });

  return ok({
    playlists: playlists.map((p) => serializePlaylist(p as PlaylistDTO)),
  });
});

/**
 * POST /api/v1/playlists
 * ----------------------
 * Create a new playlist owned by the authenticated user.
 *
 * Body: { name: string, description?: string, coverImage?: string, isPublic?: boolean }
 *
 * Validation:
 *   - name required, trimmed, length 1..playlist.max_name_length (default 120).
 *   - description optional, length 0..playlist.max_description_length (default 1000).
 *   - coverImage optional — validated via the shared `validateImageSource`
 *     helper (Pinterest + direct image URLs only — same path as
 *     Article.coverImage + User.avatarUrl). Rejected with a clear 400.
 *   - isPublic optional, boolean only (default false — safe default).
 *   - ownerId is NEVER accepted from the client — always derived from session.
 *   - slug is GENERATED server-side from the name (with collision handling).
 *
 * Limits:
 *   - max_per_user (default 100) — enforced before insert. Returns 400
 *     "Playlist limit reached" when the user has too many playlists.
 *
 * Rate limit: playlistCreate (default 20/minute per user) — prevents spam.
 *
 * Response: { playlist: SerializedPlaylist }
 */
export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return badRequest("Playlists feature is disabled.");
  }

  const rl = await checkRateLimit(
    `playlist-create:${user.id}`,
    RATE_LIMITS.playlistCreate
  );
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await req.json().catch(() => ({} as unknown));
  const maxNameLength = (await getSettingNumber("playlist.max_name_length")) ?? 120;
  const maxDescLength =
    (await getSettingNumber("playlist.max_description_length")) ?? 1000;

  // ── Validate name + description ───────────────────────────────────
  const name = validatePlaylistName(
    (body as { name?: unknown }).name,
    maxNameLength
  );
  const description = validatePlaylistDescription(
    (body as { description?: unknown }).description,
    maxDescLength
  );

  // ── Validate isPublic ─────────────────────────────────────────────
  const rawIsPublic = (body as { isPublic?: unknown }).isPublic;
  let isPublic = false;
  if (rawIsPublic !== undefined) {
    if (typeof rawIsPublic !== "boolean") {
      return badRequest("isPublic must be a boolean");
    }
    isPublic = rawIsPublic;
  }

  // ── Validate coverImage (if provided) ─────────────────────────────
  // Uses the same shared validator as Article.coverImage + User.avatarUrl
  // (Pinterest + direct image URLs only — rejects Instagram/Facebook/
  // TikTok/Google-search pages + dangerous schemes).
  let coverImage: string | null = null;
  const rawCover = (body as { coverImage?: unknown }).coverImage;
  if (rawCover !== undefined && rawCover !== null) {
    if (typeof rawCover !== "string") {
      return badRequest("coverImage must be a string");
    }
    const trimmed = rawCover.trim();
    if (trimmed.length > 0) {
      const result = await validateImageSource(trimmed);
      if (!result.ok) {
        return badRequest(
          result.error ??
            "Invalid cover image link. Use a Pinterest link or a direct image URL."
        );
      }
      coverImage = result.url ?? null;
    }
  }

  // ── Enforce per-user playlist limit ───────────────────────────────
  const maxPerUser = (await getSettingNumber("playlist.max_per_user")) ?? 100;
  const currentCount = await countUserPlaylists(user.id);
  if (currentCount >= maxPerUser) {
    return badRequest(
      `Playlist limit reached (${maxPerUser} per user). Delete a playlist before creating a new one.`
    );
  }

  // ── Generate slug (server-side — client never supplies it) ───────
  const slug = await generateUniquePlaylistSlug(name);

  // ── Insert ─────────────────────────────────────────────────────────
  const playlist = await db.playlist.create({
    data: {
      ownerId: user.id,
      name,
      slug,
      description,
      coverImage: coverImage ?? null,
      isPublic,
    },
    select: PLAYLIST_LIST_SELECT,
  });

  return ok({ playlist: serializePlaylist(playlist as PlaylistDTO) });
});

// ── Shared projection ──────────────────────────────────────────────────────
const PLAYLIST_LIST_SELECT = {
  id: true,
  ownerId: true,
  name: true,
  slug: true,
  description: true,
  coverImage: true,
  isPublic: true,
  createdAt: true,
  updatedAt: true,
  owner: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: { select: { items: true } },
} as const satisfies Prisma.PlaylistSelect;
