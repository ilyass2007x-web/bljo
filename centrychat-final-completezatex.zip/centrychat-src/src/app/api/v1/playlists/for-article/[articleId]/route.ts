import { apiHandler, ok } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isFeatureEnabled } from "@/lib/features";
import {
  getPlaylistsContainingArticleForUser,
} from "@/lib/playlists";

/**
 * GET /api/v1/playlists/for-article/:articleId
 * --------------------------------------------
 * Return the AUTHENTICATED USER's own playlists that contain this article
 * (spec §16: "if the content is already in a playlist, show it as added
 * + don't allow duplication").
 *
 * Used by the Save-to-Playlist dialog to render the already-added state
 * per playlist (green check + "Already in this playlist" tooltip).
 *
 * SECURITY:
 *   - Auth required (no anonymous access — the dialog is auth-gated).
 *   - Returns ONLY the user's OWN playlists (private + public). Other
 *     users' playlists containing this article are NEVER exposed
 *     (privacy: playlist membership is private to the owner).
 *   - The query filters by ownerId = user.id inside the service helper.
 *
 * Response: { playlistIds: Array<{ id, name, slug, isPublic }> }
 *   (minimal projection — the dialog only needs to highlight which
 *   playlists already contain this article.)
 */
export const GET = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();

  if (!(await isFeatureEnabled("playlists"))) {
    return ok({ playlistIds: [] });
  }

  const { articleId } = await ctx.params;
  if (!articleId || typeof articleId !== "string") {
    return ok({ playlistIds: [] });
  }

  const rows = await getPlaylistsContainingArticleForUser(user.id, articleId);
  return ok({ playlistIds: rows });
});
