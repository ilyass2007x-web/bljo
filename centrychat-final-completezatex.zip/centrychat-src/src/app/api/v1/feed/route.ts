import { apiHandler, ok } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";
import { db } from "@/lib/database";

/**
 * GET /api/v1/feed?type=for_you|following|trending
 * Returns a personalized feed of recommended content.
 *
 * When recommendation_algorithm is OFF, returns a basic chronological feed.
 * When ON, returns the personalized recommendation feed.
 */
export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  const url = new URL(req.url);
  const feedType = (url.searchParams.get("type") ?? "for_you") as "for_you" | "following" | "trending";
  const limit = Math.min(Number(url.searchParams.get("limit") ?? "20"), 50);

  const engine = getRecommendationEngine();
  const result = await engine.getFeed({
    userId: user.id,
    limit,
    feedType,
  });

  // Hydrate the feed items with full profile data (since we currently recommend profiles).
  // In the future, this will also hydrate posts and reels.
  const profileIds = result.items
    .filter((i) => i.contentType === "profile")
    .map((i) => i.contentId);

  const profiles = profileIds.length > 0
    ? await db.user.findMany({
        where: { id: { in: profileIds } },
        select: {
          id: true,
          fullName: true,
          username: true,
          avatarColor: true,
          avatarUrl: true,
          isVerified: true,
          bio: true,
          createdAt: true,
          _count: { select: { followers: true, following: true } },
        },
      })
    : [];

  // Check which profiles the current user follows.
  const followingIds = new Set(
    (await db.follow.findMany({
      where: { followerId: user.id, followingId: { in: profileIds } },
      select: { followingId: true },
    })).map((f) => f.followingId)
  );

  const profileMap = new Map(profiles.map((p) => [p.id, p]));

  return ok({
    feed: result.items.map((item) => {
      const profile = profileMap.get(item.contentId);
      return {
        contentType: item.contentType,
        contentId: item.contentId,
        score: item.score,
        reason: item.reason,
        profile: profile
          ? {
              ...profile,
              isFollowing: followingIds.has(profile.id),
              followersCount: profile._count.followers,
              followingCount: profile._count.following,
            }
          : null,
      };
    }),
    nextCursor: result.nextCursor,
  });
});
