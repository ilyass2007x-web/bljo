import { apiHandler, ok, badRequest } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { getSetting, getSettingBool, getSettingNumber } from "@/lib/settings";
import type { Prisma } from "@prisma/client";
import type { PostDTO } from "@/app/api/v1/posts/route";
import {
  scoreAndRankContent,
  getCandidatePoolSize,
  DEFAULT_RANKING_WEIGHTS,
  mulberry32,
  type RankableContent,
  type RankingWeights,
} from "@/lib/content/ranking";
import {
  loadFeedMixWeights,
  computeFeedMixBuckets,
  getAuthorTopicsBatch,
  type FeedMixBuckets,
} from "@/lib/feed/personalization";
// Phase 1 Personalized Feed — use the rich getUserInterestProfile() instead
// of reading UserInterest rows directly. This gives the ranker access to
// author affinities, short-term session interests, not-interested topics,
// and content-type affinity — all signals that already-existed in the
// profile module but weren't being consumed by the feed route.
import { getUserInterestProfile } from "@/lib/feed/interest-profile";
// Phase 2 — Topics: get the user's explicitly followed topic IDs (used for
// the new followedTopicBoost signal in the ranker).
import { getFollowedTopicIds, batchGetContentTopicIds } from "@/lib/topics";
// Phase 1 — Security Correctness: block visibility filtering.
import { getBlockedAuthorIds } from "@/lib/block";

/**
 * GET /api/v1/feed/unified
 * ------------------------
 * Unified Home feed — merges Short Posts AND published Articles into a
 * single stream ranked by a multi-signal algorithm (spec §1-§22).
 *
 * CENTRYCHAT PERSONALIZED FEED (spec §1-§38):
 *   The feed is now bucketed into 5 SOURCES that are merged + ranked together:
 *
 *     1. FOLLOWING    — content from authors the user follows (incl. self).
 *     2. RECOMMENDED  — content from authors whose inferred topics match
 *                       the user's interest profile (personalization).
 *     3. FRESH        — brand-new content published in the last hour.
 *     4. TRENDING     — high-velocity content (high engagement-per-hour).
 *     5. EXPLORATION  — random content from non-followed authors (discovery).
 *
 *   The per-bucket POOL SIZE comes from admin-configured weights
 *   `feed.mix.{following,recommended,fresh,trending,exploration}` (spec §15).
 *
 * COLD START (spec §1, §16, §34):
 *   When the user has NO follows (new user), the `following` bucket
 *   collapses to 0 and the remaining weights are re-normalized — the new
 *   user gets a feed filled with recommended + fresh + trending + exploration
 *   content. NO empty state, NO "follow someone first" wall.
 *
 *   Even more: when the user ALSO has no interest profile (brand-new user,
 *   zero interactions), the `recommended` bucket returns 0 candidates
 *   (no topics to match against) — but the fresh/trending/exploration buckets
 *   still fill the feed. The new user immediately sees content.
 *
 * RANKING (spec PART 1):
 *   Uses the unified ranking engine (src/lib/content/ranking.ts) which
 *   considers: recency, engagement, engagement rate, following,
 *   exploration, diversity, velocity, quality, new-content boost,
 *   self-penalty, spam signals, AND interestMatch (personalization).
 *   Weights are configurable via admin settings (algorithm.weight.*).
 *
 * ARCHITECTURE (spec §18):
 *   1. Retrieve the user's followed author IDs (1 query).
 *   2. Load the user's interest profile (UserInterest rows, 1 query).
 *   3. Compute the per-bucket pool sizes (computeFeedMixBuckets).
 *   4. In parallel, fetch the 5 buckets (5-7 queries):
 *      - following: posts + articles from followed authors
 *      - recommended: posts + articles from authors whose topics match
 *        the user's interests (the author-topics cache makes this fast)
 *      - fresh: posts + articles published in the last hour
 *      - trending: posts + articles with high engagement-per-hour
 *      - exploration: random posts + articles from non-followed authors
 *   5. Merge all candidates into a single RankableContent[] array.
 *   6. Rank via scoreAndRankContent (in-memory, O(n)).
 *   7. Hydrate the top-N with full data + isLiked + isFollowing.
 *
 * PAGINATION (spec §20):
 *   Cursor-based (not OFFSET). The cursor encodes the OLDEST item's
 *   (timestamp, id, type) from the previous page. The next page fetches
 *   items strictly older than that timestamp, ranks them, returns the
 *   top N. This allows multi-signal ranking WITHIN each page while
 *   preserving stable infinite-scroll pagination.
 *
 * PERFORMANCE (spec §19, §22, §24):
 *   - 1 DB query for followed author IDs.
 *   - 1 DB query for the user's interest profile.
 *   - 1 batched DB query for author-topics (cached 5min per authorId).
 *   - 5-7 parallel DB queries for the buckets (posts + articles per bucket).
 *   - 1 batch query for share counts.
 *   - 1 batch query for isLiked.
 *   - Total: 9-12 queries + in-memory scoring. No N+1.
 *
 * CACHING (spec §19):
 *   - The candidate pool is NOT cached — fresh data on every request.
 *   - The ranking weights + feed-mix weights are cached 30s via getSetting.
 *   - Author-topics are cached 5min per authorId (in-memory).
 *
 * Auth: requires authenticated, verified user.
 */

const ARTICLE_CARD_SELECT = {
  id: true,
  title: true,
  excerpt: true,
  coverImage: true,
  videoUrl: true,
  publishedAt: true,
  readingTime: true,
  content: true,
  authorId: true,
  author: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const satisfies Prisma.ArticleSelect;

const POST_SELECT = {
  id: true,
  content: true,
  createdAt: true,
  updatedAt: true,
  authorId: true,
  author: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const satisfies Prisma.PostSelect;

interface CursorData {
  /**
   * Phase 3 — the cursor now carries the list of content IDs already
   * shown to the user (across all previous pages), NOT a timestamp.
   *
   * WHY: the old cursor was `{ ts, id, type }` and the next page fetched
   * items strictly OLDER than `ts`. This broke ranked pagination — a
   * high-engagement post from 1h ago that didn't make page 1's top-N
   * was permanently lost (page 2 only looked at older items).
   *
   * The new approach: each page is independently ranked from the full
   * candidate pool MINUS the already-seen IDs. This way:
   *   - Page 1: rank all candidates, return top N, remember their IDs.
   *   - Page 2: rank all candidates EXCEPT page 1's IDs, return top N.
   *   - Page 3: rank all candidates EXCEPT page 1+2's IDs, return top N.
   *
   * The cursor is opaque (base64 JSON). The client passes it back as
   * `?cursor=...` — it never inspects or modifies it.
   *
   * SIZE LIMIT: to keep the cursor URL from growing unboundedly, we cap
   * the seenIds list at 200 (10 pages × 20 items). When the list exceeds
   * 200, the oldest IDs are dropped (the user has scrolled past them
   * anyway — they won't reappear because the candidate pool's recency
   * window naturally excludes very old content).
   */
  seenIds: string[];
  /** Page number (1-indexed) — used for analytics + debugging only. */
  page: number;
}

const MAX_SEEN_IDS = 200;

function decodeCursor(raw: string | null): CursorData | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(
      Buffer.from(raw, "base64").toString("utf-8")
    ) as Partial<CursorData>;
    if (!Array.isArray(parsed.seenIds)) return null;
    return {
      seenIds: parsed.seenIds.filter((x): x is string => typeof x === "string"),
      page: typeof parsed.page === "number" ? parsed.page : 1,
    };
  } catch {
    return null;
  }
}

function encodeCursor(c: CursorData): string {
  return Buffer.from(JSON.stringify(c), "utf-8").toString("base64");
}

/**
 * Phase 4 — Hash a string seed into a 32-bit unsigned integer.
 *
 * Used by the ranker's seeded PRNG. We use a simple FNV-1a-like hash
 * (fast, good distribution for short strings). The seed comes from the
 * client's `?seed=...` query param — a per-session random 8-char string.
 *
 * The hash is deterministic: the same seed string always produces the
 * same 32-bit integer → the same PRNG sequence → the same feed ordering.
 * This is what makes pagination stable within a session (page 2 uses the
 * same seed as page 1 → consistent jitter).
 */
function hashSeed(str: string): number {
  let hash = 0x811c9dc5; // FNV offset basis (32-bit)
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    // FNV prime (32-bit) — multiply + keep as 32-bit unsigned.
    hash = Math.imul(hash, 0x01000193);
  }
  // Force unsigned 32-bit.
  return hash >>> 0;
}

/**
 * Load ranking weights from admin settings (with 30s cache via getSetting).
 * Falls back to DEFAULT_RANKING_WEIGHTS if any setting is missing.
 *
 * Admin-configurable keys (spec §28):
 *   algorithm.weight.recencyDecay, .likeWeight, .commentWeight, etc.
 */
async function loadRankingWeights(): Promise<RankingWeights> {
  const w = { ...DEFAULT_RANKING_WEIGHTS };
  const keys = Object.keys(w) as (keyof RankingWeights)[];
  await Promise.all(
    keys.map(async (k) => {
      const v = await getSetting(`algorithm.weight.${k}`);
      if (v != null && !Number.isNaN(Number(v))) {
        (w as any)[k] = Number(v);
      }
    })
  );
  return w;
}

export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();

  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "20"), 1), 50);
  const cursorParam = url.searchParams.get("cursor");
  const cursor = decodeCursor(cursorParam);
  if (cursorParam && !cursor) {
    return badRequest("Invalid cursor.");
  }

  // Phase 4 — Feed Seed for controlled variation.
  // The client sends a per-session seed (?seed=...) that the ranker uses
  // for DETERMINISTIC jitter. Same seed → same order across pagination
  // pages within one session (stable while scrolling). New session /
  // refresh → new seed → new order (variation on refresh).
  //
  // The seed is a short string (8 chars). We hash it to a 32-bit integer
  // that the ranker's PRNG uses as its starting state. When no seed is
  // provided (backward compat with older clients), we fall back to a
  // time-based seed — but this means pagination could get inconsistent
  // ordering across pages. The client always sends the seed now.
  const feedSeedParam = url.searchParams.get("seed");
  const feedSeed = feedSeedParam
    ? hashSeed(feedSeedParam)
    : Math.floor(Math.random() * 0xffffffff);

  // Phase 3 — the set of content IDs already shown to the user (from
  // previous pages). These are EXCLUDED from the candidate pool so they
  // don't reappear. Replaces the old timestamp-based cursor.
  const seenIds = new Set<string>(cursor?.seenIds ?? []);
  const pageNumber = (cursor?.page ?? 0) + 1;

  // Load ranking weights + feed-mix weights + transparency flag (all cached 30s).
  const [weights, feedMixWeights, enableTransparency, personalizationWeight] = await Promise.all([
    loadRankingWeights(),
    loadFeedMixWeights(),
    getSettingBool("rec.transparency_enabled"),
    getSettingNumber("rec.weight.personalization"),
  ]);

  // ── Step 1: fetch followed author IDs (1 query) ────────────────────
  const followed = await db.follow.findMany({
    where: { followerId: user.id },
    select: { followingId: true },
  });
  const followedIdsSet = new Set(followed.map((f) => f.followingId));

  // ── Block filtering (Phase 1 — Security Correctness) ─────────────
  // Single batched query for the viewer's block graph (both directions —
  // see src/lib/block.ts). The resulting IDs are excluded from EVERY
  // bucket's candidate pool: FOLLOWING, FRESH, TRENDING, EXPLORATION,
  // and RECOMMENDED. Filtering happens at the DB query level via
  // `authorId: { notIn: [...] }` (or by filtering the input ID list
  // for buckets that use `in: [...]`). No N+1, no JS post-filtering,
  // no risk of leaking blocked content past pagination.
  const blockedAuthorIds = await getBlockedAuthorIds(user.id);

  // Exclude blocked authors from the FOLLOWING bucket's author list.
  // (self is intentionally kept — the user sees their own content.)
  const feedAuthorIds = [user.id, ...followedIdsSet].filter(
    (id) => !blockedAuthorIds.has(id)
  );

  // ── Step 2: load the user's interest profile (1 query, cached 60s) ─
  // Phase 1 Personalized Feed — switched from a direct `db.userInterest.findMany`
  // to the richer `getUserInterestProfile()` (src/lib/feed/interest-profile.ts).
  //
  // The richer profile provides 5 personalization signals the previous
  // direct query did NOT surface:
  //   1. Long-term topic interests (decayed) — was already there.
  //   2. Author affinities (graded 0-1) — NEW. Lets the ranker give a
  //      small boost to non-followed authors the user has engaged with.
  //   3. Short-term (session, last 30 min) interests — NEW. Lets the
  //      ranker boost topics the user is engaging with RIGHT NOW.
  //   4. notInterestedTopics — NEW. Lets the ranker apply a penalty.
  //   5. contentTypeAffinity (post vs article) — NEW. Lets the ranker
  //      give a small boost to the user's preferred content type.
  //
  // The profile is CACHED for 60s per user (see PROFILE_CACHE_TTL_MS in
  // interest-profile.ts) + invalidated on every new interaction. So this
  // is essentially free on hot paths.
  //
  // Empty profile (cold start) is fine — all the new components return 0
  // when the profile is empty, and the existing buckets (fresh /
  // trending / exploration) fill the feed.
  const interestProfile = await getUserInterestProfile(user.id).catch(() => null);

  // ── Phase 2 — Topics: fetch the user's followed topic IDs (1 query, cached) ──
  // Used by the ranker's new `followedTopicBoost` component. Empty when the
  // user follows no topics (cold start) — the ranker's component returns 0
  // in that case.
  const followedTopicIds = await getFollowedTopicIds(user.id);

  // Build the legacy `Map<slug, score>` for the existing `calculateInterestMatch`
  // (which uses LONG-TERM decayed topic scores).
  const interestProfileMap = new Map<string, number>(
    interestProfile?.topics
      ? interestProfile.topics.map((t) => [t.topicSlug, t.effectiveScore])
      : []
  );

  // Build the NEW context maps from the profile (all empty when cold start):
  //   - authorAffinity: Map<authorId, score 0-1> — graded affinity.
  //   - shortTermInterests: Map<topicSlug, score 0-1> — last 30 min.
  //   - notInterestedTopics: Set<topicSlug> — explicit rejections.
  //   - contentTypeAffinity: { post, article } — 0-1 each.
  const authorAffinityMap = new Map<string, number>(
    interestProfile?.authors
      ? interestProfile.authors.map((a) => [a.authorId, a.score])
      : []
  );
  const shortTermInterestsMap = new Map<string, number>(
    interestProfile?.shortTermTopics
      ? interestProfile.shortTermTopics.map((t) => [t.topicSlug, t.score])
      : []
  );
  const notInterestedTopicsSet = new Set<string>(
    interestProfile?.notInterestedTopics ?? []
  );
  const contentTypeAffinity = interestProfile?.contentTypeAffinity
    ?? { post: 0.5, article: 0.5 }; // neutral default on cold start / error

  // ── Step 3: compute per-bucket pool sizes (cold-start aware) ───────
  const poolSize = getCandidatePoolSize(limit);
  const hasFollows = followedIdsSet.size > 0;
  const buckets = computeFeedMixBuckets(poolSize, feedMixWeights, hasFollows);

  // ── Step 4: build the WHERE conditions for each bucket ─────────────
  // All buckets respect the cursor (when paginating) — they only fetch
  // items strictly older than the cursor's timestamp.

  // (a) FOLLOWING bucket — posts + articles from authors the user follows
  //     (including self). When the user has no follows, this bucket is 0
  //     (cold start — see computeFeedMixBuckets).
  //
  //     Phase 3: NO timestamp cursor filter — the candidate pool is fetched
  //     from the full recency window, and already-seen IDs are excluded via
  //     `id: { notIn: seenIds }`. This lets high-engagement older content
  //     from followed authors surface on later pages (was impossible with
  //     the old timestamp cursor).
  //
  //     Phase 1 — Security Correctness: blocked authors are filtered OUT
  //     of `feedAuthorIds` above (single source of truth), so they never
  //     enter the FOLLOWING bucket's candidate pool.
  const followingPostWhere: Prisma.PostWhereInput = {
    authorId: { in: feedAuthorIds },
    moderationStatus: "APPROVED",
    ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
  };
  const followingArticleWhere: Prisma.ArticleWhereInput = {
    status: "PUBLISHED",
    moderationStatus: "APPROVED",
    authorId: { in: feedAuthorIds },
    publishedAt: { not: null },
    ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
  };

  // Phase 1 — Security Correctness: combined self + block exclusion list
  // used by every bucket that filters via `authorId: { not: user.id }`.
  // Spread into the bucket WHERE clauses below as `notIn: excludedAuthorIds`.
  // Pre-computed ONCE so all buckets share the same exclusion set.
  const excludedAuthorIds = [user.id, ...blockedAuthorIds];
  const excludedAuthorFilter =
    blockedAuthorIds.size > 0
      ? { authorId: { notIn: excludedAuthorIds } }
      : { authorId: { not: user.id } };

  // (b) FRESH bucket — posts + articles published in the LAST HOUR.
  //     The "1 hour ago" timestamp is computed fresh on each request.
  //     Phase 3: seen IDs are excluded (no timestamp cursor).
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  const freshPostWhere: Prisma.PostWhereInput = {
    ...excludedAuthorFilter,
    moderationStatus: "APPROVED",
    createdAt: { gte: oneHourAgo },
    ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
  };
  const freshArticleWhere: Prisma.ArticleWhereInput = {
    status: "PUBLISHED",
    moderationStatus: "APPROVED",
    ...excludedAuthorFilter,
    publishedAt: { not: null, gte: oneHourAgo },
    ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
  };

  // (c) TRENDING bucket — posts + articles with high engagement-per-hour.
  //     Phase 3 FIX: this bucket now orders by ENGAGEMENT (likes desc) instead
  //     of recency. The old code used `orderBy: createdAt desc` which made the
  //     trending bucket identical to the fresh bucket — just the newest posts
  //     in the 48h window. Now it returns the MOST-LIKED posts in the 48h
  //     window, which is what "trending" actually means.
  //     The ranker applies the velocity boost on top.
  const trendingWindowStart = new Date(Date.now() - 48 * 60 * 60 * 1000);
  const trendingPostWhere: Prisma.PostWhereInput = {
    ...excludedAuthorFilter,
    moderationStatus: "APPROVED",
    createdAt: { gte: trendingWindowStart },
    ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
  };
  const trendingArticleWhere: Prisma.ArticleWhereInput = {
    status: "PUBLISHED",
    moderationStatus: "APPROVED",
    ...excludedAuthorFilter,
    publishedAt: { not: null, gte: trendingWindowStart },
    ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
  };

  // (d) EXPLORATION bucket — random posts + articles from non-followed,
  //     non-self authors. Phase 3 FIX: fetches a LARGER pool (2x the bucket
  //     size) and the caller shuffles it in-memory before passing to the
  //     ranker. This provides actual discovery (random content the user
  //     hasn't seen) instead of just "newest from non-followed authors"
  //     (which is what the old `orderBy: createdAt desc` gave us).
  //     When the user has no follows, this bucket is the LARGEST (cold-start).
  //
  //     Phase 1 — Security Correctness: blocked authors are added to the
  //     exclusion list so they never appear in exploration either.
  const explorationExcludeIds = hasFollows
    ? [...new Set([...feedAuthorIds, ...blockedAuthorIds])]
    : excludedAuthorIds;
  const explorationPostWhere: Prisma.PostWhereInput = {
    authorId: { notIn: explorationExcludeIds },
    moderationStatus: "APPROVED",
    ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
  };
  const explorationArticleWhere: Prisma.ArticleWhereInput = {
    status: "PUBLISHED",
    moderationStatus: "APPROVED",
    authorId: { notIn: explorationExcludeIds },
    publishedAt: { not: null },
    ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
  };

  // (e) RECOMMENDED bucket — posts + articles from authors whose inferred
  //     topics match the user's interest profile. We fetch the user's TOP
  //     interest topic slugs, find authors who have interacted with those
  //     topics, then fetch their recent posts/articles.
  //
  //     When the user has NO interest profile (cold start), this bucket
  //     is EMPTY — we don't fetch anything. The other buckets still
  //     fill the feed.
  const topInterestSlugs = [...interestProfileMap.entries()]
    .filter(([, score]) => score > 0.1)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([slug]) => slug);

  // Fetch candidate authors for the recommended bucket — users who have
  // interacted with the user's top interest topics (excluding self + followed).
  //
  // Phase 1 — Security Correctness: blocked authors are filtered OUT of the
  // candidate list here (single source of truth) so the recommended bucket's
  // `authorId: { in: recommendedAuthorIds }` queries can never surface blocked
  // content. Done at the source rather than via a separate `notIn` filter so
  // we don't risk two `authorId` conditions colliding in the Prisma WHERE.
  let recommendedAuthorIds: string[] = [];
  if (topInterestSlugs.length > 0) {
    const topics = await db.contentTopic.findMany({
      where: { slug: { in: topInterestSlugs } },
      select: { id: true },
    });
    const topicIds = topics.map((t) => t.id);
    if (topicIds.length > 0) {
      const authorInteractions = await db.contentInteraction.groupBy({
        by: ["userId"],
        where: {
          topicId: { in: topicIds },
          userId: { notIn: [...feedAuthorIds] },
          // Only consider "positive" interactions (likes, comments, shares, follows)
          // — views + skips don't strongly indicate the author writes about a topic.
          action: { in: ["like", "comment", "share", "follow", "save"] },
        },
        _count: { _all: true },
        take: 30, // top 30 authors by interaction count
        orderBy: { _count: { userId: "desc" } as any },
      });
      recommendedAuthorIds = authorInteractions
        .map((r) => r.userId)
        .filter((id) => !blockedAuthorIds.has(id));
    }
  }

  // Now fire all bucket queries in parallel.
  const queries: Promise<any>[] = [];

  // FOLLOWING bucket (skip if pool size = 0, e.g. cold start with no follows).
  // Phase 5 FIX: order by ENGAGEMENT (likes + comments) instead of recency.
  // The old `orderBy: createdAt desc` made this bucket return only the NEWEST
  // posts from followed authors — which meant old high-engagement posts from
  // followed authors never entered the candidate pool → never got ranked →
  // never appeared in the feed. This was the #1 cause of the "chronological
  // feed" bug. Now we fetch the MOST-ENGAGING posts from followed authors
  // (regardless of age), so the ranker has diverse material to work with.
  if (buckets.following > 0) {
    queries.push(
      db.post.findMany({
        where: followingPostWhere,
        orderBy: [
          { likes: { _count: "desc" } },
          { comments: { _count: "desc" } },
        ],
        take: buckets.following,
        select: POST_SELECT,
      })
    );
    queries.push(
      db.article.findMany({
        where: followingArticleWhere,
        orderBy: [
          { likes: { _count: "desc" } },
          { comments: { _count: "desc" } },
        ],
        take: buckets.following,
        select: ARTICLE_CARD_SELECT,
      })
    );
  } else {
    queries.push(Promise.resolve([]));
    queries.push(Promise.resolve([]));
  }

  // RECOMMENDED bucket (skip if no recommended authors OR pool size = 0).
  // Phase 5 FIX: same as following — order by ENGAGEMENT, not recency.
  // Phase 2.4 — ALSO fetch content from the user's FOLLOWED TOPICS via
  // ArticleTopic/PostTopic relationships (Prisma `some` relation filter).
  // This gives followed-topic content a direct path into the candidate pool.
  // The ranker's `followedTopicBoost` (weight 12.0) then gives these
  // candidates a strong positive signal. The `topicDiversityPenalty`
  // (weight 2.0) prevents the feed from becoming a single-topic echo chamber.
  //
  // PERFORMANCE: 2 additional queries (1 for posts, 1 for articles) ONLY
  // when the user follows topics. Uses Prisma's `some` relation filter
  // (single JOIN, indexed by `@@index([topicId])` + `@@index([postId])` /
  // `@@index([articleId])`). NO N+1. The existing dedup step (Step 5)
  // prevents duplicates when the same content appears in both the
  // author-based AND topic-based recommended buckets.
  const hasFollowedTopics = followedTopicIds.size > 0;
  if (buckets.recommended > 0 && recommendedAuthorIds.length > 0) {
    queries.push(
      db.post.findMany({
        where: {
          authorId: { in: recommendedAuthorIds },
          // Phase 1 — Security Correctness: moderation gate (was missing —
          // PENDING_MODERATION / REJECTED posts could surface in the
          // recommended bucket even though every other bucket filtered them).
          moderationStatus: "APPROVED",
          ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
        },
        orderBy: [
          { likes: { _count: "desc" } },
          { comments: { _count: "desc" } },
        ],
        take: buckets.recommended,
        select: POST_SELECT,
      })
    );
    queries.push(
      db.article.findMany({
        where: {
          status: "PUBLISHED",
          // Phase 1 — Security Correctness: moderation gate (was missing —
          // PUBLISHED-but-PENDING_MODERATION articles could surface here).
          moderationStatus: "APPROVED",
          authorId: { in: recommendedAuthorIds },
          publishedAt: { not: null },
          ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
        },
        orderBy: [
          { likes: { _count: "desc" } },
          { comments: { _count: "desc" } },
        ],
        take: buckets.recommended,
        select: ARTICLE_CARD_SELECT,
      })
    );
    // Phase 2.4 — topic-based recommended queries (only when user follows topics).
    // These are SEPARATE from the author-based queries above. Both sets of
    // results are merged + deduplicated in Step 5.
    //
    // Phase 1 — Security Correctness: moderation gate + block filtering
    // (was missing — unmoderated content + blocked authors could surface
    // here). Uses the shared `excludedAuthorFilter` so blocked authors are
    // filtered at the DB level.
    if (hasFollowedTopics) {
      queries.push(
        db.post.findMany({
          where: {
            // Posts that have at least one of the user's followed topics assigned.
            topics: { some: { topicId: { in: [...followedTopicIds] } } },
            moderationStatus: "APPROVED",
            ...excludedAuthorFilter,
            ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
          },
          orderBy: [{ createdAt: "desc" }, { id: "desc" }],
          take: buckets.recommended,
          select: POST_SELECT,
        })
      );
      queries.push(
        db.article.findMany({
          where: {
            status: "PUBLISHED",
            moderationStatus: "APPROVED",
            publishedAt: { not: null },
            // Articles that have at least one of the user's followed topics.
            topics: { some: { topicId: { in: [...followedTopicIds] } } },
            ...excludedAuthorFilter,
            ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
          },
          orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
          take: buckets.recommended,
          select: ARTICLE_CARD_SELECT,
        })
      );
    } else {
      queries.push(Promise.resolve([]));
      queries.push(Promise.resolve([]));
    }
  } else if (buckets.recommended > 0 && hasFollowedTopics) {
    // No author-based recommendations but user follows topics — still fetch
    // topic-based content.
    //
    // Phase 1 — Security Correctness: moderation gate + block filtering
    // (was missing here too — see comment on the topic-based branch above).
    queries.push(Promise.resolve([])); // author-based posts (empty)
    queries.push(Promise.resolve([])); // author-based articles (empty)
    queries.push(
      db.post.findMany({
        where: {
          topics: { some: { topicId: { in: [...followedTopicIds] } } },
          moderationStatus: "APPROVED",
          ...excludedAuthorFilter,
          ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
        },
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: buckets.recommended,
        select: POST_SELECT,
      })
    );
    queries.push(
      db.article.findMany({
        where: {
          status: "PUBLISHED",
          moderationStatus: "APPROVED",
          publishedAt: { not: null },
          topics: { some: { topicId: { in: [...followedTopicIds] } } },
          ...excludedAuthorFilter,
          ...(seenIds.size > 0 ? { id: { notIn: [...seenIds] } } : {}),
        },
        orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
        take: buckets.recommended,
        select: ARTICLE_CARD_SELECT,
      })
    );
  } else {
    queries.push(Promise.resolve([]));
    queries.push(Promise.resolve([]));
    queries.push(Promise.resolve([]));
    queries.push(Promise.resolve([]));
  }

  // FRESH bucket (skip if pool size = 0).
  if (buckets.fresh > 0) {
    queries.push(
      db.post.findMany({
        where: freshPostWhere,
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: buckets.fresh,
        select: POST_SELECT,
      })
    );
    queries.push(
      db.article.findMany({
        where: freshArticleWhere,
        orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
        take: buckets.fresh,
        select: ARTICLE_CARD_SELECT,
      })
    );
  } else {
    queries.push(Promise.resolve([]));
    queries.push(Promise.resolve([]));
  }

  // TRENDING bucket (skip if pool size = 0).
  // Phase 3 FIX: order by ENGAGEMENT (likes desc) instead of recency.
  // This makes the trending bucket return the most-liked posts in the
  // 48h window, not just the newest. The ranker applies velocity boost
  // on top of this candidate pool.
  if (buckets.trending > 0) {
    queries.push(
      db.post.findMany({
        where: trendingPostWhere,
        // Order by likes count desc (engagement-based), then comments desc
        // as a tiebreaker. Prisma supports ordering by _count.
        orderBy: [
          { likes: { _count: "desc" } },
          { comments: { _count: "desc" } },
        ],
        take: buckets.trending,
        select: POST_SELECT,
      })
    );
    queries.push(
      db.article.findMany({
        where: trendingArticleWhere,
        orderBy: [
          { likes: { _count: "desc" } },
          { comments: { _count: "desc" } },
        ],
        take: buckets.trending,
        select: ARTICLE_CARD_SELECT,
      })
    );
  } else {
    queries.push(Promise.resolve([]));
    queries.push(Promise.resolve([]));
  }

  // EXPLORATION bucket (skip if pool size = 0).
  // Phase 5: fetch 3x the bucket size + order by createdAt DESC (to get a
  // recent pool), then SHUFFLE in-memory with the seeded PRNG. The 3x fetch
  // ensures the shuffle has enough material to produce actual randomization
  // (was 2x — not enough when the bucket size is small). The shuffle is
  // deterministic per session (seeded) so pagination is stable.
  if (buckets.exploration > 0) {
    const explorationTake = buckets.exploration * 3; // fetch 3x for shuffle room
    queries.push(
      db.post.findMany({
        where: explorationPostWhere,
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: explorationTake,
        select: POST_SELECT,
      })
    );
    queries.push(
      db.article.findMany({
        where: explorationArticleWhere,
        orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
        take: explorationTake,
        select: ARTICLE_CARD_SELECT,
      })
    );
  } else {
    queries.push(Promise.resolve([]));
    queries.push(Promise.resolve([]));
  }

  // Destructure the parallel results. Each pair = (posts, articles) per bucket.
  // Phase 2.4 — the recommended bucket now has 4 results instead of 2:
  //   [0] author-based recommended posts
  //   [1] author-based recommended articles
  //   [2] topic-based recommended posts (Phase 2.4 — from followed topics)
  //   [3] topic-based recommended articles (Phase 2.4 — from followed topics)
  const [
    followingPosts = [],
    followingArticles = [],
    recommendedPosts = [],
    recommendedArticles = [],
    // Phase 2.4 — topic-based recommended content (from followed topics).
    recommendedTopicPosts = [],
    recommendedTopicArticles = [],
    freshPosts = [],
    freshArticles = [],
    trendingPosts = [],
    trendingArticles = [],
    explorationPostsRaw = [],
    explorationArticlesRaw = [],
  ] = await Promise.all(queries);

  // ── Phase 3: shuffle the exploration bucket in-memory ──────────────
  // The exploration queries fetched 2x the bucket size, ordered by recency.
  // We shuffle the results so the ranker gets a RANDOM sample of recent
  // non-followed content — actual discovery. Fisher-Yates shuffle.
  // We then trim back to the bucket size (the ranker doesn't need 2x).
  //
  // Phase 4 — the shuffle is now SEEDED with the feedSeed. Same seed →
  // same shuffle order → stable exploration across pagination pages.
  // New session → new seed → different exploration sample.
  const explorationRng = mulberry32(feedSeed);
  function shuffleAndTrim<T>(arr: T[], n: number): T[] {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(explorationRng() * (i + 1));
      [a[i], a[j]] = [a[j]!, a[i]!];
    }
    return a.slice(0, n);
  }
  const explorationPosts = buckets.exploration > 0
    ? shuffleAndTrim(explorationPostsRaw as any[], buckets.exploration)
    : [];
  const explorationArticles = buckets.exploration > 0
    ? shuffleAndTrim(explorationArticlesRaw as any[], buckets.exploration)
    : [];

  // ── Step 5: merge all candidates into RankableContent[] ────────────
  const toRankablePost = (p: any): RankableContent => ({
    type: "post" as const,
    id: p.id,
    authorId: p.authorId,
    titleOrContent: p.content,
    timestamp: p.createdAt,
    counts: {
      likes: p._count.likes,
      comments: p._count.comments,
      views: p._count.views,
      shares: 0, // fetched below
    },
  });
  const toRankableArticle = (a: any): RankableContent => ({
    type: "article" as const,
    id: a.id,
    authorId: a.authorId,
    titleOrContent: a.title,
    excerpt: a.excerpt,
    contentLength: a.content.length,
    hasCoverImage: !!a.coverImage,
    hasVideo: !!a.videoUrl,
    readingTime: a.readingTime,
    timestamp: a.publishedAt ?? new Date(0),
    counts: {
      likes: a._count.likes,
      comments: a._count.comments,
      views: a._count.views,
      shares: 0, // fetched below
    },
  });

  // Combine all bucket outputs. Deduplicate by (type, id) — a post can
  // appear in multiple buckets (e.g. a fresh post from a followed author
  // is in BOTH following AND fresh). The ranker scores each candidate
  // once — we don't want the same post to be ranked twice.
  const seenKeys = new Set<string>();
  const candidates: RankableContent[] = [];
  const allPosts = [
    ...followingPosts,
    ...recommendedPosts,
    // Phase 2.4 — topic-based recommended posts (from followed topics).
    ...recommendedTopicPosts,
    ...freshPosts,
    ...trendingPosts,
    ...explorationPosts,
  ];
  const allArticles = [
    ...followingArticles,
    ...recommendedArticles,
    // Phase 2.4 — topic-based recommended articles (from followed topics).
    ...recommendedTopicArticles,
    ...freshArticles,
    ...trendingArticles,
    ...explorationArticles,
  ];
  for (const p of allPosts) {
    const key = `post:${p.id}`;
    if (seenKeys.has(key)) continue;
    seenKeys.add(key);
    candidates.push(toRankablePost(p));
  }
  for (const a of allArticles) {
    const key = `article:${a.id}`;
    if (seenKeys.has(key)) continue;
    seenKeys.add(key);
    candidates.push(toRankableArticle(a));
  }

  if (candidates.length === 0) {
    // ── EMPTY FEED FALLBACK (spec §34, §35) ──────────────────────────
    // When ALL buckets returned 0 candidates (e.g. brand-new platform with
    // no published content), return an empty items array. The HomeFeed
    // component shows the "Who to follow" suggestions in this case.
    return ok({ items: [], nextCursor: null });
  }

  // ── Step 6: fetch author-topics batch (for interestMatch scoring) ──
  // Cached 5min per authorId. Returns Map<authorId, topicSlugs[]>.
  const uniqueAuthorIds = [...new Set(candidates.map((c) => c.authorId))];
  const authorTopics = await getAuthorTopicsBatch(
    uniqueAuthorIds,
    async (ids) => {
      // ONE batched query: ContentInteraction.groupBy on userId + topic.slug,
      // restricted to positive actions (like/comment/share/follow/save).
      const rows = await db.contentInteraction.groupBy({
        by: ["userId", "topicId"],
        where: {
          userId: { in: ids },
          action: { in: ["like", "comment", "share", "follow", "save"] },
          topicId: { not: null },
        },
        _count: { _all: true },
        orderBy: { _count: { userId: "desc" } as any },
        take: 90, // top 3 topics per author × 30 authors
      });
      // Hydrate topic slugs in ONE batch.
      const topicIds = [...new Set(rows.map((r) => r.topicId).filter(Boolean))] as string[];
      const topics = topicIds.length > 0
        ? await db.contentTopic.findMany({
            where: { id: { in: topicIds } },
            select: { id: true, slug: true },
          })
        : [];
      const topicSlugById = new Map(topics.map((t) => [t.id, t.slug]));
      return rows.map((r) => ({
        userId: r.userId,
        topicSlug: topicSlugById.get(r.topicId as string) ?? "",
        _count: r._count._all,
      }));
    }
  );

  // ── Step 7: fetch share counts for the candidates (batched) ────────
  const candidatePostIds = candidates.filter((c) => c.type === "post").map((c) => c.id);
  const candidateArticleIds = candidates.filter((c) => c.type === "article").map((c) => c.id);

  const [postShareRows, articleShareRows] = await Promise.all([
    candidatePostIds.length > 0
      ? db.postInteraction.groupBy({
          by: ["postId"],
          where: { postId: { in: candidatePostIds }, type: "SHARE" },
          _count: { _all: true },
        })
      : [],
    candidateArticleIds.length > 0
      ? db.articleInteraction.groupBy({
          by: ["articleId"],
          where: { articleId: { in: candidateArticleIds }, type: "SHARE" },
          _count: { _all: true },
        })
      : [],
  ]);
  type PostShareRow = { postId: string; _count: { _all: number } };
  type ArticleShareRow = { articleId: string; _count: { _all: number } };
  const postShareRowsTyped: PostShareRow[] = postShareRows as any;
  const articleShareRowsTyped: ArticleShareRow[] = articleShareRows as any;
  const postShareMap = new Map(postShareRowsTyped.map((s) => [s.postId, s._count._all]));
  const articleShareMap = new Map(articleShareRowsTyped.map((s) => [s.articleId, s._count._all]));

  for (const c of candidates) {
    if (c.type === "post") c.counts.shares = postShareMap.get(c.id) ?? 0;
    else c.counts.shares = articleShareMap.get(c.id) ?? 0;
  }

  // ── Step 8: rank the candidates with the extended user context ──────
  // The user context now includes the user's interest profile + author topics
  // + personalization weight + transparency flag. The ranker computes the
  // interestMatch component on top of the existing signals (recency,
  // engagement, velocity, etc.).
  //
  // Phase 2 — Topics: the user context ALSO now includes 4 new
  // optional fields that the ranker uses for the new personalization
  // components:
  //   - authorAffinity        → authorAffinity boost (graded, separate from
  //                            binary followingBoost).
  //   - shortTermInterests    → shortTermBoost (last 30 min interest match).
  //   - notInterestedTopics   → notInterestedPenalty (explicit rejections).
  //   - contentTypeAffinity   → contentTypeAffinity boost (post vs article).
  //
  // All four are NULL-SAFE in the ranker (return 0 when absent) so existing
  // callers of scoreAndRankContent that don't pass these continue to work.
  //
  // Phase 2.1 — Topics: batch-fetch the content-level topic IDs for ALL
  // candidate posts + articles (2 queries total — 1 for ArticleTopic,
  // 1 for PostTopic). The resulting map is keyed by composite
  // `"${item.type}:${item.id}"` to avoid collisions between Post cuids
  // and Article cuids. The ranker's followedTopicBoost + topicDiversity
  // components use this map.
  //
  // PERFORMANCE: 2 batched queries (one per content type), bounded by the
  // candidate pool size (~30-150 items). Uses the `@@index([articleId])`
  // and `@@index([postId])` indexes. NO N+1 — the map is built once +
  // reused for every candidate in the ranker.
  //
  // REUSES the `candidatePostIds` + `candidateArticleIds` variables declared
  // above (for the share-count batch fetch) — no duplicate array building.
  const [postTopicIdMap, articleTopicIdMap] = await Promise.all([
    candidatePostIds.length > 0
      ? batchGetContentTopicIds("post", candidatePostIds)
      : Promise.resolve(new Map<string, string[]>()),
    candidateArticleIds.length > 0
      ? batchGetContentTopicIds("article", candidateArticleIds)
      : Promise.resolve(new Map<string, string[]>()),
  ]);

  // Merge into a single map keyed by composite `"${type}:${id}"`.
  const contentTopicIds = new Map<string, string[]>();
  for (const [id, ids] of postTopicIdMap) {
    contentTopicIds.set(`post:${id}`, ids);
  }
  for (const [id, ids] of articleTopicIdMap) {
    contentTopicIds.set(`article:${id}`, ids);
  }

  const userCtx = {
    userId: user.id,
    followedAuthorIds: followedIdsSet,
    interestProfile: interestProfileMap,
    authorTopics,
    personalizationWeight: personalizationWeight ?? 30,
    enableTransparency,
    // Phase 4 — pass the feed seed so the ranker's jitter is DETERMINISTIC
    // per session. Same seed → same PRNG sequence → same feed order across
    // pagination pages. New session → new seed → new (but still
    // ranking-quality-first) order.
    feedSeed,
    // Phase 1 Personalized Feed — new personalization context (all empty
    // on cold start, gracefully degraded by the ranker).
    authorAffinity: authorAffinityMap,
    shortTermInterests: shortTermInterestsMap,
    notInterestedTopics: notInterestedTopicsSet,
    contentTypeAffinity,
    // Phase 2 — Topics: explicit topic-follow signal. Empty when the user
    // follows no topics — the ranker's followedTopicBoost returns 0.
    followedTopicIds,
    // Phase 2.1 — Topics: content-level topic IDs (keyed by composite
    // `${type}:${id}`). Used by the ranker's followedTopicBoost +
    // topicDiversity components. Empty map on cold start — both components
    // gracefully degrade to 0.
    authorTopicIds: contentTopicIds,
  };
  const scored = scoreAndRankContent(candidates, userCtx, limit, weights);

  // ── Step 9: hydrate the top-N scored items with full data ──────────
  // Build a lookup map from ALL fetched posts/articles (across all buckets).
  const postRowMap = new Map<string, any>(allPosts.map((p) => [p.id, p]));
  const articleRowMap = new Map<string, any>(allArticles.map((a) => [a.id, a]));

  const topPostIds = scored.filter((s) => s.item.type === "post").map((s) => s.item.id);
  const topArticleIds = scored.filter((s) => s.item.type === "article").map((s) => s.item.id);

  const [postLikedRows, articleLikedRows, followersOfMe] = await Promise.all([
    topPostIds.length > 0
      ? db.postLike.findMany({
          where: { userId: user.id, postId: { in: topPostIds } },
          select: { postId: true },
        })
      : [],
    topArticleIds.length > 0
      ? db.articleLike.findMany({
          where: { userId: user.id, articleId: { in: topArticleIds } },
          select: { articleId: true },
        })
      : [],
    db.follow.findMany({
      where: { followingId: user.id },
      select: { followerId: true },
    }),
  ]);
  const postLikedSet = new Set(postLikedRows.map((l) => l.postId));
  const articleLikedSet = new Set(articleLikedRows.map((l) => l.articleId));
  const followerIdsSet = new Set(followersOfMe.map((f) => f.followerId));

  // ── Step 10: build the response items ──────────────────────────────
  // Include the `reason` field from the scored item when transparency is
  // enabled (spec §27). The reason explains WHY the post was recommended
  // — useful for the future "Recommended because..." UI.
  const items = scored
    .map(({ item, reason }) => {
      if (item.type === "post") {
        const p = postRowMap.get(item.id);
        if (!p) return null;
        const postDTO: PostDTO = {
          id: p.id,
          content: p.content,
          createdAt: p.createdAt,
          updatedAt: p.updatedAt,
          author: {
            ...p.author,
            isFollowing: followedIdsSet.has(p.author.id),
            isFollowedBy: followerIdsSet.has(p.author.id),
          },
          likeCount: p._count.likes,
          commentCount: p._count.comments,
          viewCount: p._count.views,
          // shareCount from the postShareMap computed in step 7
          // (used for ranking; same value surfaced to the UI).
          shareCount: postShareMap.get(p.id) ?? 0,
          isLiked: postLikedSet.has(p.id),
          // Phase 2.1 — Topics: include the post's content-level topic IDs.
          topicIds: postTopicIdMap.get(p.id) ?? [],
        };
        return { type: "post" as const, post: postDTO, reason: reason ?? null };
      }
      const a = articleRowMap.get(item.id);
      if (!a) return null;
      return {
        type: "article" as const,
        article: {
          id: a.id,
          title: a.title,
          excerpt: a.excerpt,
          coverImage: a.coverImage,
          videoUrl: a.videoUrl,
          publishedAt: a.publishedAt?.toISOString() ?? null,
          readingTime: a.readingTime,
          author: {
            ...a.author,
            isFollowing: followedIdsSet.has(a.author.id),
            isFollowedBy: false,
          },
          likeCount: a._count.likes,
          commentCount: a._count.comments,
          viewCount: a._count.views,
          shareCount: articleShareMap.get(a.id) ?? 0,
          isLiked: articleLikedSet.has(a.id),
          // Phase 2.1 — Topics: include the article's content-level topic IDs.
          topicIds: articleTopicIdMap.get(a.id) ?? [],
        },
        reason: reason ?? null,
      };
    })
    .filter((x): x is NonNullable<typeof x> => x !== null);

  // ── Step 11: determine the next cursor ──────────────────────────────
  // Phase 3 — the cursor now carries the SET of already-seen IDs (not a
  // timestamp). We add the IDs of all items returned on THIS page to the
  // existing seenIds set, then encode the new set into the cursor. The
  // next page will exclude all of these IDs from its candidate pool.
  //
  // SIZE LIMIT: when the seenIds set exceeds MAX_SEEN_IDS (200), we drop
  // the OLDEST entries (FIFO). This keeps the cursor URL from growing
  // unboundedly. The dropped IDs are from early pages — the user has
  // scrolled well past them, and the candidate pool's recency window
  // naturally excludes very old content anyway.
  const returnedIds = items.map((it) =>
    it.type === "post" ? it.post.id : it.article.id
  );
  const newSeenIds = [...seenIds, ...returnedIds];
  // Cap at MAX_SEEN_IDS — drop the oldest (first entries).
  const cappedSeenIds =
    newSeenIds.length > MAX_SEEN_IDS
      ? newSeenIds.slice(newSeenIds.length - MAX_SEEN_IDS)
      : newSeenIds;

  // The cursor is null when there are no more items to return. We detect
  // "no more items" by checking if the candidate pool was smaller than
  // the limit (i.e. we returned fewer items than requested). When the
  // pool is exhausted, pagination stops.
  const nextCursor =
    items.length < limit
      ? null
      : encodeCursor({ seenIds: cappedSeenIds, page: pageNumber });

  return ok({ items, nextCursor });
});
