import { apiHandler, ok } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import type { Prisma } from "@prisma/client";
import type { PostDTO } from "@/app/api/v1/posts/route";
import {
  scoreAndRankContent,
  DEFAULT_RANKING_WEIGHTS,
  type RankableContent,
} from "@/lib/content/ranking";
import { getBlockedAuthorIds } from "@/lib/block";

/**
 * GET /api/v1/feed/trending
 * --------------------------
 * Trending content — posts + articles with the highest engagement
 * VELOCITY in a recent time window (spec §24, §25).
 *
 * Trending is NOT just "highest lifetime views". A piece of content
 * with 100 interactions in 2 hours is more trending than one with
 * 1,000 interactions over 6 months.
 *
 * Algorithm (spec §24):
 *   1. Fetch all posts + articles published within the recent window
 *      (default 48 hours — long enough to surface content that's still
 *      getting engagement, short enough to focus on what's "hot now").
 *   2. Fetch their engagement counts (likes + comments + shares +
 *      unique views).
 *   3. Run them through the unified ranking engine with elevated
 *      velocity + recency weights (so the velocity signal dominates,
 *      surfacing "fast-moving" content).
 *   4. Apply diversity (one item per author in the top N, with a
 *      progressive penalty for repeat authors).
 *   5. Return the top N.
 *
 * ANTI-ABUSE (spec §25):
 *   - All engagement comes from UNIQUE interactions (DB-level
 *     @@unique on PostLike/ArticleLike/PostView/ArticleView prevents
 *     duplicate rows from the same user).
 *   - Shares come from PostInteraction/ArticleInteraction type='SHARE'
 *     — one row per share event (a user can share multiple times,
 *     but the velocity cap prevents that from dominating).
 *   - The velocity score is CAPPED at 20 engagement/hour to prevent
 *     a viral post from generating a runaway score.
 *   - Self-content is excluded entirely (the user's own posts/articles
 *     are not "trending" to themselves).
 *
 * Auth: requires authenticated + verified user (the trending feed is
 * personalized — self-content is excluded, follow state is included).
 *
 * Response: { items: UnifiedFeedItem[], nextCursor: string | null }
 */

const ARTICLE_CARD_SELECT = {
  id: true,
  title: true,
  excerpt: true,
  coverImage: true,
  videoUrl: true,
  publishedAt: true,
  readingTime: true,
  content: true,
  authorId: true,
  author: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const satisfies Prisma.ArticleSelect;

const POST_SELECT = {
  id: true,
  content: true,
  createdAt: true,
  updatedAt: true,
  authorId: true,
  author: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const satisfies Prisma.PostSelect;

interface CursorData {
  ts: string;
  id: string;
  type: "post" | "article";
}

function decodeCursor(raw: string | null): CursorData | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(
      Buffer.from(raw, "base64").toString("utf-8")
    ) as Partial<CursorData>;
    if (!parsed.ts || !parsed.id || !parsed.type) return null;
    if (parsed.type !== "post" && parsed.type !== "article") return null;
    return { ts: parsed.ts, id: parsed.id, type: parsed.type };
  } catch {
    return null;
  }
}

function encodeCursor(c: CursorData): string {
  return Buffer.from(JSON.stringify(c), "utf-8").toString("base64");
}

export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();

  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "20"), 1), 50);
  const cursorParam = url.searchParams.get("cursor");
  const cursor = decodeCursor(cursorParam);
  if (cursorParam && !cursor) {
    return ok({ items: [], nextCursor: null });
  }

  // Trending window: 48 hours. Content older than 48h is not "trending".
  const WINDOW_HOURS = 48;
  const now = new Date();
  const windowStart = new Date(now.getTime() - WINDOW_HOURS * 60 * 60 * 1000);

  const cursorDate = cursor ? new Date(cursor.ts) : null;
  if (cursor && cursorDate && Number.isNaN(cursorDate.getTime())) {
    return ok({ items: [], nextCursor: null });
  }
  const rightEdge = cursorDate ?? now;

  // ── Block filtering (Phase 1 — Security Correctness) ─────────────
  // Single batched query for the viewer's block graph (both directions).
  // The resulting IDs are merged with the self-exclusion filter below
  // into ONE `authorId: { notIn: [...] }` constraint, so:
  //   - self is excluded (existing behavior)
  //   - blocked authors are excluded (new behavior)
  //   - filtering happens at the DB level (no N+1, no JS post-filtering,
  //     no risk of leaking blocked content past pagination).
  // Trending always has an authenticated viewer (`requireVerifiedUser`),
  // so this Set is always populated correctly.
  const blockedAuthorIds = await getBlockedAuthorIds(user.id);
  const excludedAuthorIds = new Set<string>(blockedAuthorIds);
  excludedAuthorIds.add(user.id); // self-exclusion (existing behavior)
  const excludedAuthorFilter = { authorId: { notIn: [...excludedAuthorIds] } };

  // (a) Posts within the window (excluding self + blocked authors).
  // Moderation gate (Phase 1 — Security Correctness): only APPROVED posts
  // enter the trending candidate pool. PENDING_MODERATION / REJECTED /
  // REMOVED posts are excluded — matches /api/v1/feed/unified. Previously
  // this route returned unmoderated posts in the trending feed.
  const postWhere: Prisma.PostWhereInput = {
    ...excludedAuthorFilter,
    moderationStatus: "APPROVED",
    createdAt: { gte: windowStart, lt: rightEdge },
    ...(cursor && cursorDate
      ? {
          OR: [
            { createdAt: { lt: cursorDate } },
            { createdAt: cursorDate, id: { lt: cursor.id } },
          ],
        }
      : {}),
  };

  // (b) Published articles within the window (excluding self + blocked).
  // Moderation gate (Phase 1 — Security Correctness): adds
  // `moderationStatus: "APPROVED"` to match /api/v1/feed/unified.
  // Previously only `status: "PUBLISHED"` was filtered — PUBLISHED-but-
  // PENDING_MODERATION articles were leaking into the trending feed.
  const articleWhere: Prisma.ArticleWhereInput = {
    status: "PUBLISHED",
    moderationStatus: "APPROVED",
    ...excludedAuthorFilter,
    publishedAt: { not: null, gte: windowStart, lt: rightEdge },
    ...(cursor && cursorDate
      ? {
          OR: [
            { publishedAt: { lt: cursorDate } },
            { publishedAt: cursorDate, id: { lt: cursor.id } },
          ],
        }
      : {}),
  };

  const poolSize = Math.min(Math.max(limit * 3, 30), 100);

  const [postRows, articleRows] = await Promise.all([
    db.post.findMany({
      where: postWhere,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: poolSize,
      select: POST_SELECT,
    }),
    db.article.findMany({
      where: articleWhere,
      orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
      take: poolSize,
      select: ARTICLE_CARD_SELECT,
    }),
  ]);

  const candidates: RankableContent[] = [
    ...postRows.map((p) => ({
      type: "post" as const,
      id: p.id,
      authorId: p.authorId,
      titleOrContent: p.content,
      timestamp: p.createdAt,
      counts: {
        likes: p._count.likes,
        comments: p._count.comments,
        views: p._count.views,
        shares: 0,
      },
    })),
    ...articleRows.map((a) => ({
      type: "article" as const,
      id: a.id,
      authorId: a.authorId,
      titleOrContent: a.title,
      excerpt: a.excerpt,
      contentLength: a.content.length,
      hasCoverImage: !!a.coverImage,
      hasVideo: !!a.videoUrl,
      readingTime: a.readingTime,
      timestamp: a.publishedAt ?? new Date(0),
      counts: {
        likes: a._count.likes,
        comments: a._count.comments,
        views: a._count.views,
        shares: 0,
      },
    })),
  ];

  if (candidates.length === 0) {
    return ok({ items: [], nextCursor: null });
  }

  // Fetch share counts (batched).
  const postIds = candidates.filter((c) => c.type === "post").map((c) => c.id);
  const articleIds = candidates.filter((c) => c.type === "article").map((c) => c.id);
  const [postShareRows, articleShareRows] = await Promise.all([
    postIds.length > 0
      ? db.postInteraction.groupBy({
          by: ["postId"],
          where: { postId: { in: postIds }, type: "SHARE" },
          _count: { _all: true },
        })
      : [],
    articleIds.length > 0
      ? db.articleInteraction.groupBy({
          by: ["articleId"],
          where: { articleId: { in: articleIds }, type: "SHARE" },
          _count: { _all: true },
        })
      : [],
  ]);
  type PostShareRow = { postId: string; _count: { _all: number } };
  type ArticleShareRow = { articleId: string; _count: { _all: number } };
  const postShareMap = new Map(
    (postShareRows as any as PostShareRow[]).map((s) => [s.postId, s._count._all])
  );
  const articleShareMap = new Map(
    (articleShareRows as any as ArticleShareRow[]).map((s) => [s.articleId, s._count._all])
  );
  for (const c of candidates) {
    if (c.type === "post") c.counts.shares = postShareMap.get(c.id) ?? 0;
    else c.counts.shares = articleShareMap.get(c.id) ?? 0;
  }

  // Rank with elevated velocity/recency weights (trending prioritizes
  // fast-moving recent content).
  const trendingWeights = {
    ...DEFAULT_RANKING_WEIGHTS,
    velocityBonus: DEFAULT_RANKING_WEIGHTS.velocityBonus * 2.5,
    recencyDecay: DEFAULT_RANKING_WEIGHTS.recencyDecay * 1.5,
    followingBoost: 0, // trending is global — no following boost
    explorationBoost: 0, // trending IS exploration by definition
    newContentBoost: DEFAULT_RANKING_WEIGHTS.newContentBoost * 0.5,
    diversityPenalty: DEFAULT_RANKING_WEIGHTS.diversityPenalty * 2, // stronger diversity for trending
  };

  const userCtx = { userId: user.id, followedAuthorIds: new Set<string>() };
  const scored = scoreAndRankContent(candidates, userCtx, limit, trendingWeights);

  // Hydrate top-N with full data + isLiked.
  const postRowMap = new Map(postRows.map((p) => [p.id, p]));
  const articleRowMap = new Map(articleRows.map((a) => [a.id, a]));

  const topPostIds = scored.filter((s) => s.item.type === "post").map((s) => s.item.id);
  const topArticleIds = scored.filter((s) => s.item.type === "article").map((s) => s.item.id);

  const [postLikedRows, articleLikedRows] = await Promise.all([
    topPostIds.length > 0
      ? db.postLike.findMany({
          where: { userId: user.id, postId: { in: topPostIds } },
          select: { postId: true },
        })
      : [],
    topArticleIds.length > 0
      ? db.articleLike.findMany({
          where: { userId: user.id, articleId: { in: topArticleIds } },
          select: { articleId: true },
        })
      : [],
  ]);
  const postLikedSet = new Set(postLikedRows.map((l) => l.postId));
  const articleLikedSet = new Set(articleLikedRows.map((l) => l.articleId));
  // postShareMap was already computed above (for the ranking candidate pool).
  // We reuse it here to attach shareCount to the hydrated post DTOs.

  const items = scored
    .map(({ item }) => {
      if (item.type === "post") {
        const p = postRowMap.get(item.id);
        if (!p) return null;
        const postDTO: PostDTO = {
          id: p.id,
          content: p.content,
          createdAt: p.createdAt,
          updatedAt: p.updatedAt,
          author: {
            ...p.author,
            isFollowing: false,
            isFollowedBy: false,
          },
          likeCount: p._count.likes,
          commentCount: p._count.comments,
          viewCount: p._count.views,
          // shareCount is computed via a separate groupBy query below —
          // attached via postShareMap after the .map() loop. Set to 0
          // here as a placeholder; the actual value is filled in after.
          shareCount: postShareMap.get(p.id) ?? 0,
          isLiked: postLikedSet.has(p.id),
          // Phase 2.1 — Topics: trending route doesn't batch-fetch content
          // topic IDs (keep the route lean). Set to empty array — the ranker
          // gracefully handles missing topics (no boost, no penalty).
          topicIds: [],
        };
        return { type: "post" as const, post: postDTO };
      }
      const a = articleRowMap.get(item.id);
      if (!a) return null;
      return {
        type: "article" as const,
        article: {
          id: a.id,
          title: a.title,
          excerpt: a.excerpt,
          coverImage: a.coverImage,
          videoUrl: a.videoUrl,
          publishedAt: a.publishedAt?.toISOString() ?? null,
          readingTime: a.readingTime,
          author: {
            ...a.author,
            isFollowing: false,
            isFollowedBy: false,
          },
          likeCount: a._count.likes,
          commentCount: a._count.comments,
          viewCount: a._count.views,
          shareCount: articleShareMap.get(a.id) ?? 0,
          isLiked: articleLikedSet.has(a.id),
        },
      };
    })
    .filter((x): x is NonNullable<typeof x> => x !== null);

  const lastReturned = scored[scored.length - 1];
  const nextCursor = lastReturned
    ? encodeCursor({
        ts: lastReturned.item.timestamp.toISOString(),
        id: lastReturned.item.id,
        type: lastReturned.item.type,
      })
    : null;

  return ok({ items, nextCursor });
});
