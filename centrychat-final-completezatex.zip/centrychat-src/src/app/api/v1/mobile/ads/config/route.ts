import { apiHandler, ok, badRequest } from "@/lib/api";
import { getClientIp, checkRateLimit } from "@/lib/security/rate-limit";
import { buildMobileAdConfig, isValidAdMobPlatform, type AdMobPlatform } from "@/lib/admob/manager";

/**
 * GET /api/v1/mobile/ads/config?platform=android&appVersion=1.4.0
 * ----------------------------------------------------------------
 * The PUBLIC mobile ad configuration endpoint.
 *
 * This is the endpoint the future CentryChat mobile app (Android/iOS)
 * fetches to get its ad configuration. The response drives the AdMob SDK
 * — the app uses the returned `placements` map to know which ad units to
 * load at each placement.
 *
 * NO authentication required (spec §46 — public read access). The response
 * is intentionally limited to PUBLIC-safe fields:
 *   - appId (AdMob App ID — already public, visible in the app binary)
 *   - placements (ad unit IDs — also public, visible in the app binary)
 *   - version (for cache invalidation)
 *   - enabled flags
 *
 * SECURITY (spec §11):
 *   - NO AdMob API credentials / Service Account credentials are returned.
 *   - The endpoint returns ONLY the public identifiers the app needs to
 *     initialize the AdMob SDK.
 *
 * RATE LIMITING (spec §47):
 *   - 60 requests per minute per IP. The mobile app should cache the
 *     response locally + only re-fetch when the version changes (spec §19).
 *   - This prevents abuse + reduces server load.
 *
 * SAFE DEFAULTS (spec §20 + §48 + §49):
 *   - When AdMob is globally disabled OR no app is configured OR no active
 *     units exist, the response is: { enabled: false, placements: {} }.
 *   - The mobile app uses safe defaults: NO ads shown. No guessing of
 *     ad unit IDs.
 *
 * CACHING:
 *   - The settings are cached 30s (via getSetting).
 *   - The apps + units are cached 60s (via cacheGetOrSet).
 *   - This endpoint itself is NOT cached at the HTTP layer — the mobile
 *     app caches locally + re-fetches periodically (spec §19).
 *
 * VERSIONING (spec §21):
 *   - The response includes `version`. The app compares against its cached
 *     version + refreshes only when changed.
 *   - When the admin changes a setting, the config version bumps (via
 *     bumpAdMobConfigVersion in the admin CRUD endpoints).
 *
 * Query params:
 *   - platform (required): "android" | "ios"
 *   - appVersion (optional): the app's version string (e.g. "1.4.0").
 *     When provided, the API checks against the minimum supported version
 *     (spec §22). When omitted, the check is skipped.
 *
 * Response shape:
 *   {
 *     version: number,
 *     enabled: boolean,
 *     platform: "ANDROID" | "IOS",
 *     appId: string,
 *     environment: "development" | "production",
 *     placements: {
 *       "APP_HOME_BANNER": { enabled, adUnitId, format, priority, fallbackAdUnitId? },
 *       ...
 *     },
 *     reason?: string  // when enabled=false, explains why (for debugging)
 *   }
 */
export const GET = apiHandler(async (req) => {
  const url = new URL(req.url);
  const platformParam = url.searchParams.get("platform")?.trim().toUpperCase();
  const appVersion = url.searchParams.get("appVersion")?.trim() || undefined;

  // Validate platform.
  if (!platformParam) {
    return badRequest('Missing "platform" query parameter. Example: ?platform=android');
  }
  if (!isValidAdMobPlatform(platformParam)) {
    return badRequest(
      `Unsupported platform: "${platformParam}". Use "android" or "ios".`
    );
  }

  // Rate limit: 60 requests per minute per IP (spec §47).
  // The mobile app should cache locally + only re-fetch when the version
  // changes — this limit is generous enough for periodic polling.
  const clientIp = getClientIp(req);
  const rateLimitKey = `mobile_ads_config:${clientIp}`;
  const rateLimit = await checkRateLimit(rateLimitKey, {
    limit: 60,
    windowSeconds: 60,
  });
  if (!rateLimit.ok) {
    return badRequest("Rate limit exceeded. Please try again in a moment.");
  }

  // Build the config for the requested platform.
  const config = await buildMobileAdConfig(platformParam as AdMobPlatform, appVersion);

  // Set Cache-Control header so CDNs / proxies cache for a short time.
  // 60s matches the server-side cache TTL — a good balance between
  // freshness + load reduction.
  const response = ok(config);
  response.headers.set("Cache-Control", "public, max-age=60, s-maxage=60");
  return response;
});
