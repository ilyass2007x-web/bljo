import { apiHandler, ok, parseJsonBody } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { editMessage, deleteMessage } from "@/lib/messaging";
import { broadcastRealtime } from "@/lib/realtime/server";

export const PATCH = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  const body = await parseJsonBody<{ content?: string }>(req);
  if (!body.content) return ok({});

  const updated = await editMessage(user.id, id, body.content);
  await broadcastRealtime({
    event: "message:update",
    payload: updated,
    recipientIds: updated.recipientIds,
  });
  return ok({ message: updated });
});

export const DELETE = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  const result = await deleteMessage(user.id, id);
  await broadcastRealtime({
    event: "message:delete",
    payload: { messageId: id, conversationId: result.conversationId },
    recipientIds: result.recipientIds,
  });
  return ok({ deleted: true });
});
