import { apiHandler, badRequest, ok, notFound, parseJsonBody } from "@/lib/api";
import { requireVerifiedUser, getCurrentUser, ForbiddenError } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import {
  validateImageConfigField,
} from "@/lib/articles/image-config";
import { validateImageSource } from "@/lib/articles/image-source-validation";
import { validateVideoSource } from "@/lib/articles/video-source-validation";
import { invalidateTranslationsForArticle } from "@/lib/articles/translate";
// Content moderation — runs on the EDITED fields (spec §9). Only fields
// present in the PATCH body are moderated.
import { moderateContent, recordModerationEvent } from "@/lib/moderation";
// Phase 2.1 — Topics: validate + sync topic IDs on article update.
import { validateTopicIds, syncContentTopics, getContentTopicIds } from "@/lib/topics";

/** Same shape as in /api/v1/articles/route.ts — Phase 18 image config. */
type ArticleImageConfigFields = {
  imageZoom?: number | null;
  imagePositionX?: number | null;
  imagePositionY?: number | null;
};

/** Parse + validate the Phase 18 image config fields from the PATCH body. */
function parseImageConfigPatch(
  body: Record<string, unknown>,
  opts: { coverImageCleared: boolean }
): ArticleImageConfigFields {
  if (opts.coverImageCleared) {
    return { imageZoom: null, imagePositionX: null, imagePositionY: null };
  }
  const out: ArticleImageConfigFields = {};
  if (body.imageZoom !== undefined) {
    out.imageZoom = validateImageConfigField("imageZoom", body.imageZoom);
  }
  if (body.imagePositionX !== undefined) {
    out.imagePositionX = validateImageConfigField("imagePositionX", body.imagePositionX);
  }
  if (body.imagePositionY !== undefined) {
    out.imagePositionY = validateImageConfigField("imagePositionY", body.imagePositionY);
  }
  return out;
}

/**
 * GET /api/v1/articles/:id
 * Fetch a single article. Published articles are public.
 * Drafts are visible only to the author + admins.
 *
 * Phase — Article social features: returns likeCount, commentCount,
 * viewCount (via Prisma _count), shareCount (via batch query on
 * ArticleInteraction), and isLiked (via query on ArticleLike for the
 * current user). All counts come from the DB — never from the client.
 */
export const GET = apiHandler(async (req, ctx) => {
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Article not found.");

  // Use getCurrentUser (not requireVerifiedUser) so a draft can be
  // fetched by an UNVERIFIED-but-authenticated author/admin. The draft
  // visibility check below enforces ownership.
  const viewer = await getCurrentUser();

  const article = await db.article.findUnique({
    where: { id },
    select: {
      id: true,
      authorId: true,
      title: true,
      content: true,
      excerpt: true,
      coverImage: true,
      videoUrl: true,
      // Phase 18 — image presentation config.
      imageZoom: true,
      imagePositionX: true,
      imagePositionY: true,
      // Cover image visibility inside the article detail page.
      showCoverInArticle: true,
      status: true,
      moderationStatus: true,
      publishedAt: true,
      readingTime: true,
      createdAt: true,
      updatedAt: true,
      author: {
        select: {
          id: true,
          fullName: true,
          username: true,
          avatarColor: true,
          avatarUrl: true,
          isVerified: true,
        },
      },
      _count: {
        select: { likes: true, comments: true, views: true },
      },
    },
  });

  if (!article) return notFound("Article not found.");

  // Drafts: only the author or an admin can view
  if (article.status !== "PUBLISHED") {
    if (!viewer || (viewer.id !== article.authorId && viewer.role !== "ADMIN" && viewer.role !== "SUPER_ADMIN")) {
      return notFound("Article not found.");
    }
  }

  // Moderation gate: PENDING_MODERATION and REJECTED articles are hidden
  // from everyone EXCEPT the author + admins. The author sees their own
  // pending article (so they know it was received) + can edit it.
  if (article.moderationStatus !== "APPROVED") {
    if (!viewer || (viewer.id !== article.authorId && viewer.role !== "ADMIN" && viewer.role !== "SUPER_ADMIN")) {
      return notFound("Article not found.");
    }
  }

  // Batch-compute isLiked + shareCount (2 queries).
  const [likedRow, shareCount] = viewer
    ? await Promise.all([
        db.articleLike.findUnique({
          where: { articleId_userId: { articleId: id, userId: viewer.id } },
          select: { articleId: true },
        }),
        db.articleInteraction.count({
          where: { articleId: id, type: "SHARE" },
        }),
      ])
    : [null, 0];

  return ok({
    article: {
      ...article,
      publishedAt: article.publishedAt?.toISOString() ?? null,
      createdAt: article.createdAt.toISOString(),
      updatedAt: article.updatedAt.toISOString(),
      likeCount: article._count.likes,
      commentCount: article._count.comments,
      viewCount: article._count.views,
      shareCount,
      isLiked: !!likedRow,
      // Phase 2.1 — Topics: include the assigned topic IDs so the editor
      // can hydrate the topic selector on edit.
      topicIds: await getContentTopicIds("article", id),
    },
  });
});

/**
 * PATCH /api/v1/articles/:id
 * Update an article (owner only).
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;

  const article = await db.article.findUnique({
    where: { id },
    select: { id: true, authorId: true, status: true },
  });
  if (!article) return notFound("Article not found.");
  if (article.authorId !== user.id && user.role !== "ADMIN" && user.role !== "SUPER_ADMIN") {
    throw new ForbiddenError("You can only edit your own articles");
  }

  const body = await parseJsonBody<{
    title?: string;
    content?: string;
    excerpt?: string;
    coverImage?: string;
    videoUrl?: string;
    status?: string;
    imageZoom?: number;
    imagePositionX?: number;
    imagePositionY?: number;
    showCoverInArticle?: boolean;
    // Phase 2.1 — Topics: when provided, REPLACES all existing topic
    // relationships for this article. Pass [] to clear all topics.
    // Omit the field to leave topics unchanged.
    topicIds?: string[];
  }>(req);

  const data: ArticleImageConfigFields & Record<string, unknown> = {};
  // Moderation results for the EDITED fields (null when the field wasn't
  // in the PATCH body OR the field's moderation result was ALLOW). Used
  // AFTER the update to record WARN/REVIEW events for admin review.
  let titleModerationResult: Awaited<ReturnType<typeof moderateContent>> | null = null;
  let contentModerationResult: Awaited<ReturnType<typeof moderateContent>> | null = null;
  let excerptModerationResult: Awaited<ReturnType<typeof moderateContent>> | null = null;
  if (body.title !== undefined) {
    const title = typeof body.title === "string" ? body.title.trim() : "";
    if (title.length < 3) return badRequest("Title must be at least 3 characters");
    if (title.length > 200) return badRequest("Title too long");
    data.title = title;
  }
  if (body.content !== undefined) {
    const content = typeof body.content === "string" ? body.content.trim() : "";
    if (content.length < 10) return badRequest("Content too short");
    // ── Domain Blocklist Check for edited content URLs ──────────────────
    const { checkTextForBlockedDomains } = await import("@/lib/security/domain-blocklist");
    const contentBlock = await checkTextForBlockedDomains(content, user.id, "ARTICLE");
    if (contentBlock.blocked) {
      return badRequest("This content contains a link that cannot be used on this platform.");
    }
    data.content = content;
    const wordCount = content.split(/\s+/).length;
    data.readingTime = Math.max(1, Math.ceil(wordCount / 200));
  }
  if (body.excerpt !== undefined) {
    data.excerpt = body.excerpt?.trim()?.slice(0, 300) || null;
  }

  // ── Content Moderation on EDITED fields (spec §9) ──────────────────
  // Only fields present in the PATCH body are moderated. A BLOCK on any
  // one of them prevents the article from being updated.
  if (typeof data.title === "string") {
    const m = await moderateContent({
      text: data.title,
      contentType: "article_title",
      userId: user.id,
    });
    if (m.action === "BLOCK") {
      void recordModerationEvent({
        result: m,
        contentType: "article_title",
        contentId: id,
        userId: user.id,
        originalText: data.title,
      });
      return badRequest(m.userMessage);
    }
    // Stash the result for later WARN/REVIEW logging after the update succeeds.
    titleModerationResult = m;
  }
  if (typeof data.content === "string") {
    const m = await moderateContent({
      text: data.content,
      contentType: "article",
      userId: user.id,
    });
    if (m.action === "BLOCK") {
      void recordModerationEvent({
        result: m,
        contentType: "article",
        contentId: id,
        userId: user.id,
        originalText: data.content,
      });
      return badRequest(m.userMessage);
    }
    contentModerationResult = m;
  }
  if (data.excerpt !== undefined && typeof data.excerpt === "string") {
    const m = await moderateContent({
      text: data.excerpt,
      contentType: "article_excerpt",
      userId: user.id,
    });
    if (m.action === "BLOCK") {
      void recordModerationEvent({
        result: m,
        contentType: "article_excerpt",
        contentId: id,
        userId: user.id,
        originalText: data.excerpt,
      });
      return badRequest(m.userMessage);
    }
    excerptModerationResult = m;
  }
  // ── End moderation ───────────────────────────────────────────────────

  let coverImageCleared = false;
  if (body.coverImage !== undefined) {
    const raw = body.coverImage?.trim() || "";
    if (!raw) {
      // Empty / null → clear the cover image.
      data.coverImage = null;
      coverImageCleared = true;
    } else {
      // Phase 18 follow-up — only Pinterest + direct image URLs accepted.
      // Shared validator does the SSRF-safe HTTP probe + Content-Type sniffing.
      const result = await validateImageSource(raw);
      if (!result.ok) {
        return badRequest(result.error ?? "Invalid image link. Use a Pinterest link or a direct image URL.");
      }
      data.coverImage = result.url;
      coverImageCleared = false;
    }
  }
  if (body.videoUrl !== undefined) {
    const url = body.videoUrl?.trim() || "";
    if (!url) {
      // Empty string → clear the video URL.
      data.videoUrl = null;
    } else {
      // ── SSRF-safe video URL validation ──────────────────────────────
      // Phase 18 follow-up: previously, videoUrl only got a regex check
      // (`^https?://` + blacklist regex). This left an SSRF gap — the URL
      // was persisted as-is + later fetched server-side by the article
      // reading page (which probes it via resolveMedia, but resolveMedia
      // itself had a DNS-rebinding TOCTOU gap that's now closed via DNS
      // pinning in src/lib/media/resolver.ts).
      //
      // Now: validate the URL AT WRITE TIME via `validateVideoSource`,
      // which runs it through the SSRF-safe resolver (with DNS pinning).
      // Only accepts:
      //   - Recognized embed providers (YouTube/Vimeo/TikTok/etc.) —
      //     pattern-matched, no HTTP probe.
      //   - Direct video URLs — Content-Type sniffed via the resolver.
      //   - Pinterest URLs (video pins).
      const videoResult = await validateVideoSource(url);
      if (!videoResult.ok) {
        // ── Domain Blocklist Check (additional defense-in-depth) ─────
        // Even on validation failure, log the hit if the domain is on
        // the blocklist — useful for the admin to see abuse patterns.
        const { checkBlockedDomain, recordBlockedDomainHit } = await import("@/lib/security/domain-blocklist");
        const videoBlock = await checkBlockedDomain(url);
        if (videoBlock.blocked && videoBlock.rule) {
          recordBlockedDomainHit({
            ruleId: videoBlock.rule.id,
            userId: user.id,
            context: "ARTICLE",
            attemptedUrl: url,
          });
          return badRequest("This link cannot be used on this platform.");
        }
        return badRequest(
          videoResult.error ??
            "Invalid video link. Use a YouTube/Vimeo/TikTok link or a direct video URL."
        );
      }
      // ── Domain Blocklist Check for accepted videoUrl ──────────────
      // Even after validation passes, run the blocklist check — the
      // blocklist may include domains that the resolver would accept
      // (e.g. adult content hosts) but the platform wants to block.
      const { checkBlockedDomain, recordBlockedDomainHit } = await import("@/lib/security/domain-blocklist");
      const videoBlock = await checkBlockedDomain(videoResult.url!);
      if (videoBlock.blocked && videoBlock.rule) {
        recordBlockedDomainHit({
          ruleId: videoBlock.rule.id,
          userId: user.id,
          context: "ARTICLE",
          attemptedUrl: videoResult.url!,
        });
        return badRequest("This link cannot be used on this platform.");
      }
      data.videoUrl = videoResult.url;
    }
  }
  if (body.status !== undefined) {
    const newStatus = body.status === "PUBLISHED" ? "PUBLISHED" : "DRAFT";
    if (newStatus === "PUBLISHED" && article.status !== "PUBLISHED") {
      data.publishedAt = new Date();
    }
    data.status = newStatus;
  }
  // Cover image visibility inside the article detail page.
  // Only update when the field is explicitly provided as a boolean.
  if (typeof body.showCoverInArticle === "boolean") {
    data.showCoverInArticle = body.showCoverInArticle;
  }

  // Phase 18 — image presentation config. Parsed AFTER coverImage so
  // we know whether the cover was cleared (in which case the config
  // is also cleared, see parseImageConfigPatch).
  try {
    const imageConfigFields = parseImageConfigPatch(body, { coverImageCleared });
    Object.assign(data, imageConfigFields);
  } catch (err) {
    return badRequest(err instanceof Error ? err.message : "Invalid image configuration");
  }

  const updated = await db.article.update({
    where: { id },
    data,
    select: {
      id: true,
      title: true,
      content: true,
      excerpt: true,
      coverImage: true,
      videoUrl: true,
      // Phase 18 — image presentation config (returned to the editor so
      // the author can see the previously-saved zoom/position when
      // re-opening the article).
      imageZoom: true,
      imagePositionX: true,
      imagePositionY: true,
      // Cover image visibility inside the article detail page.
      showCoverInArticle: true,
      status: true,
      publishedAt: true,
      readingTime: true,
      createdAt: true,
      updatedAt: true,
      author: {
        select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true },
      },
      _count: {
        select: { likes: true, comments: true, views: true },
      },
    },
  });

  logger.info("application", "Article updated", { articleId: id, userId: user.id });

  // ── Record moderation events for WARN/REVIEW on the EDITED fields ──
  if (titleModerationResult && titleModerationResult.action !== "ALLOW") {
    void recordModerationEvent({
      result: titleModerationResult,
      contentType: "article_title",
      contentId: id,
      userId: user.id,
      originalText: typeof data.title === "string" ? data.title : "",
    });
  }
  if (contentModerationResult && contentModerationResult.action !== "ALLOW") {
    void recordModerationEvent({
      result: contentModerationResult,
      contentType: "article",
      contentId: id,
      userId: user.id,
      originalText: typeof data.content === "string" ? data.content : "",
    });
  }
  if (excerptModerationResult && excerptModerationResult.action !== "ALLOW") {
    void recordModerationEvent({
      result: excerptModerationResult,
      contentType: "article_excerpt",
      contentId: id,
      userId: user.id,
      originalText: typeof data.excerpt === "string" ? data.excerpt : "",
    });
  }

  // ── Translation Invalidation (spec §27) ──────────────────────────────
  // When the article's title, description (excerpt), or content changes,
  // ALL cached translations become stale (the source text no longer matches
  // what was translated). We delete them so the next translation request
  // regenerates fresh content.
  //
  // We check the `data` object (which only contains fields the user actually
  // changed) — if title/excerpt/content is in there, we invalidate.
  // (Image/video/status changes do NOT affect translations — we skip
  // invalidation for those to avoid unnecessary cache purges.)
  //
  // This is best-effort: if the invalidation fails (DB error), the
  // translation endpoint also has a DEFENSIVE check (hasArticleContentChanged)
  // that compares the sourceContentHash on every request. So even if this
  // invalidation misses, the next translation request will detect the
  // stale cache + regenerate.
  if ("title" in data || "excerpt" in data || "content" in data) {
    void invalidateTranslationsForArticle(id);
  }

  // ── Phase 2.1 — Topics: validate + sync topic relationships ──────────
  // Run AFTER the article update succeeds. If topic validation fails, the
  // article was already updated (title/content/etc.) — we return the error
  // so the client knows the topics weren't synced, but the article changes
  // are persisted. The user can fix the topic IDs + re-save.
  let articleTopicIds: string[] | undefined;
  if (body.topicIds !== undefined) {
    const validation = await validateTopicIds(body.topicIds);
    if (!validation.ok) {
      return badRequest(validation.error);
    }
    await syncContentTopics("article", id, validation.topicIds);
    articleTopicIds = validation.topicIds;
  } else {
    // Topic field not provided — fetch existing topic IDs for the response.
    articleTopicIds = await getContentTopicIds("article", id);
  }

  // Batch-compute isLiked + shareCount for the PATCH response.
  const [likedRow, shareCount] = await Promise.all([
    db.articleLike.findUnique({
      where: { articleId_userId: { articleId: id, userId: user.id } },
      select: { articleId: true },
    }),
    db.articleInteraction.count({
      where: { articleId: id, type: "SHARE" },
    }),
  ]);

  return ok({
    article: {
      ...updated,
      publishedAt: updated.publishedAt?.toISOString() ?? null,
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
      likeCount: updated._count.likes,
      commentCount: updated._count.comments,
      viewCount: updated._count.views,
      shareCount,
      isLiked: !!likedRow,
      // Phase 2.1 — Topics: include the (possibly updated) topic IDs.
      topicIds: articleTopicIds,
    },
  });
});

/**
 * DELETE /api/v1/articles/:id
 * Delete an article (owner or admin only). Dispatches a `post:deleted`
 * window event (handled by the unified Home feed + Profile feed) so the
 * article is removed from any open feeds immediately without a re-fetch.
 */
export const DELETE = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;

  const article = await db.article.findUnique({
    where: { id },
    select: { id: true, authorId: true, status: true },
  });
  if (!article) return notFound("Article not found.");
  if (article.authorId !== user.id && user.role !== "ADMIN" && user.role !== "SUPER_ADMIN") {
    throw new ForbiddenError("You can only delete your own articles");
  }

  await db.article.delete({ where: { id } });
  logger.info("application", "Article deleted", { articleId: id, userId: user.id });

  // ── Translation Cleanup (spec §27) ──────────────────────────────────
  // When the article is deleted, ALL cached translations become orphaned.
  // We delete them so they don't linger in the DB. (The article itself
  // is gone, so the translations are useless.)
  //
  // Best-effort — if this fails, the translations are simply orphaned
  // (harmless — they'll never be queried again because the articleId no
  // longer matches any article).
  void invalidateTranslationsForArticle(id);

  return ok({ deleted: true, id });
});
