import { apiHandler, ok, badRequest, notFound } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import {
  translateArticle,
  hasArticleContentChanged,
  invalidateTranslationsForArticle,
} from "@/lib/articles/translate";
import { isValidTranslationLanguage } from "@/lib/articles/languages";

/**
 * GET /api/v1/articles/:id/translation?lang=XX
 * ----------------------------------------------
 * Returns the article translated into the requested language.
 *
 * NO authentication required — anonymous visitors (Google referrers,
 * Incognito browsers) can also request translations. The translation
 * cache is shared across all users (same article + language = same
 * cached row).
 *
 * Cache strategy (spec §6):
 *   1. Look up an existing ArticleTranslation row.
 *   2. If found AND sourceContentHash matches → return cached (NO LLM call).
 *   3. If found BUT hash differs → article was edited → delete stale + regenerate.
 *   4. If not found → call the LLM, store, return.
 *
 * SECURITY (spec §9):
 *   - articleId is validated (must be a PUBLISHED article).
 *   - languageCode is validated against the SUPPORTED_TRANSLATION_LANGUAGES list.
 *   - The LLM is server-side only (z-ai-web-dev-sdk) — API keys never exposed.
 *   - Translated content is sanitized via stripControlChars before storage.
 *
 * RATE LIMITING (spec §28 — Translation Limits):
 *   - For now, we rely on the LLM API's own rate limits. A future enhancement
 *     could add per-IP rate limiting via the existing rate-limit infrastructure.
 *   - The cache naturally limits LLM calls — once a translation exists, it's
 *     served from cache without any LLM call.
 *
 * ERROR HANDLING (spec §5 — Translation Error):
 *   - If the LLM call fails, we return a 503 with a clear message.
 *   - The ORIGINAL article remains visible to the user — the client never
 *     sees a broken page. The client shows the error toast + falls back to
 *     the original content.
 *
 * SEO (spec §8):
 *   - This endpoint does NOT affect the article's SSR metadata. The
 *     /articles/[id] page's <title>, og:*, canonical, JSON-LD are ALWAYS
 *     in the original language — search engines see the original content.
 *   - Translations are a USER EXPERIENCE feature only.
 *
 * Query params:
 *   - lang (required) — 2-letter ISO 639-1 language code (e.g. "ar", "fr").
 *
 * Response shape:
 *   {
 *     translation: {
 *       articleId: string,
 *       languageCode: string,
 *       translatedTitle: string,
 *       translatedDescription: string | null,
 *       translatedContent: string,
 *       languageNativeName: string,  // e.g. "العربية"
 *       dir: "ltr" | "rtl",
 *       fromCache: boolean
 *     }
 *   }
 *
 * Status codes:
 *   200 — translation returned (cached or fresh).
 *   400 — invalid or missing language code.
 *   404 — article not found or not published.
 *   503 — translation service unavailable (LLM error).
 */
export const GET = apiHandler(async (req, ctx) => {
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") {
    return notFound("Article not found.");
  }

  const url = new URL(req.url);
  const lang = url.searchParams.get("lang")?.trim().toLowerCase();

  // Validate the language code.
  if (!lang) {
    return badRequest('Missing "lang" query parameter. Example: ?lang=ar');
  }
  if (!isValidTranslationLanguage(lang)) {
    return badRequest(
      `Unsupported language code: "${lang}". Use a 2-letter ISO 639-1 code (e.g. "ar", "fr", "es").`
    );
  }

  // Determine the viewer (may be null for anonymous visitors).
  // We don't require auth — translations are available to everyone.
  const viewer = await getCurrentUser();

  // Fetch the article. Only PUBLISHED articles can be translated — drafts
  // are private + shouldn't be cached.
  const article = await db.article.findUnique({
    where: { id },
    select: {
      id: true,
      title: true,
      content: true,
      excerpt: true,
      status: true,
      authorId: true,
    },
  });

  if (!article || article.status !== "PUBLISHED") {
    return notFound("Article not found.");
  }

  // ── Defensive: if the article has been edited since its translations
  // were generated, invalidate ALL of them (spec §27). This catches the
  // edge case where the PATCH endpoint's invalidation didn't fire (e.g.
  // a direct DB edit bypassed the API).
  // ─────────────────────────────────────────────────────────────────────
  const contentChanged = await hasArticleContentChanged(id, {
    id: article.id,
    title: article.title,
    content: article.content,
    excerpt: article.excerpt,
  });
  if (contentChanged) {
    await invalidateTranslationsForArticle(id);
    logger.info("application", "Translations invalidated (content changed)", {
      articleId: id,
    });
  }

  // ── Translate (from cache or fresh) ────────────────────────────────
  try {
    const translation = await translateArticle(
      {
        id: article.id,
        title: article.title,
        content: article.content,
        excerpt: article.excerpt,
      },
      lang
    );

    return ok({ translation });
  } catch (err) {
    // Log the FULL technical error server-side for debugging (spec §11 + §12).
    // The user NEVER sees the technical details — only a clean message.
    logger.error("application", "Translation failed", {
      articleId: id,
      languageCode: lang,
      error: err instanceof Error ? err.message : String(err),
      viewerId: viewer?.id,
    });

    // Return ONLY the clean user-facing message (spec §11).
    // Do NOT include err.message — it may contain internal details like
    // ".z-ai-config", "/etc", "SDK error", or API internals.
    return badRequest(
      "Unable to translate this article right now. Please try again."
    );
  }
});
