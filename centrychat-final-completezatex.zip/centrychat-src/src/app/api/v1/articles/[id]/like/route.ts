import { apiHandler, ok, notFound, rateLimited} from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { Prisma } from "@prisma/client";
import { notifyArticleLiked } from "@/lib/notifications";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";

/**
 * POST /api/v1/articles/:id/like
 * ------------------------------
 * Toggle like on an article. Atomically adds OR removes the like in a
 * single Prisma transaction. Mirrors the post like endpoint's design.
 *
 * Auth: requires authenticated + verified user.
 *
 * Behavior:
 *   - If the user has NOT liked the article → CREATE the like. The
 *     @@unique([articleId, userId]) constraint guarantees no duplicates,
 *     even under concurrent double-tap requests (P2002 swallowed).
 *   - If the user HAS liked the article → DELETE the like.
 *
 * Notification: only the request that actually CREATES the like fires
 * the LIKE notification. Self-action (liking own article) is excluded.
 *
 * Response: { liked: boolean, likeCount: number }
 */
export const POST = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  const rl = await checkRateLimit(`like:${user.id}`, RATE_LIMITS.like);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  if (!id || typeof id !== "string") {
    return notFound("Article not found.");
  }

  // Fetch the article to verify it exists + is published + get authorId
  // for the notification. Drafts can't be liked (they're not publicly
  // accessible). Only the author can "like" their own draft, but that's
  // a self-action which notifyArticleLiked skips anyway.
  const article = await db.article.findUnique({
    where: { id },
    select: { id: true, authorId: true, status: true },
  });
  if (!article || article.status !== "PUBLISHED") {
    return notFound("Article not found.");
  }

  // Track whether THIS request actually created the like (vs. just found
  // it already existed). Only the creator fires the notification.
  let didCreateLike = false;

  // Atomic toggle in a transaction. deleteMany returns { count: number }
  // — if count=1, we unliked; if count=0, we need to create.
  const result = await db.$transaction(async (tx) => {
    const deleteResult = await tx.articleLike.deleteMany({
      where: { articleId: id, userId: user.id },
    });

    if (deleteResult.count > 0) {
      return { liked: false };
    }

    // Was not liked — try to create. Swallow P2002 (concurrent winner).
    try {
      await tx.articleLike.create({
        data: { articleId: id, userId: user.id },
      });
      didCreateLike = true;
      return { liked: true };
    } catch (err) {
      if (
        err instanceof Prisma.PrismaClientKnownRequestError &&
        err.code === "P2002"
      ) {
        return { liked: true };
      }
      throw err;
    }
  });

  // Fire the LIKE notification — best-effort, fire-and-forget.
  if (didCreateLike) {
    void notifyArticleLiked({
      articleId: id,
      articleAuthorId: article.authorId,
      actorId: user.id,
      actorFullName: user.fullName,
      actorUsername: user.username,
      actorIsVerified: user.isVerified,
    });

    // ── CentryChat Interest Learning (spec §6) ────────────────────────
    // Fire-and-forget a trackInteraction call. The action "like" has a
    // positive delta (admin-configured, default +0.10) that increases the
    // user's interest score for the article's topic (when known).
    //
    // topicSlug is NOT passed here because articles don't have explicit
    // topic tags yet (the topic system is nascent). The engine still
    // records the raw interaction for analytics.
    void getRecommendationEngine().trackInteraction({
      userId: user.id,
      contentType: "article",
      contentId: id,
      action: "like",
    });
  }

  // Re-fetch the accurate like count from the database.
  const likeCount = await db.articleLike.count({ where: { articleId: id } });

  return ok({ liked: result.liked, likeCount });
});
