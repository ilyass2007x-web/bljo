import { NextResponse } from "next/server";
import { apiHandler, ok, notFound } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { Prisma } from "@prisma/client";
import { logger } from "@/lib/logging";
import { checkRateLimit, getClientIp } from "@/lib/security/rate-limit";
import {
  isCrawlerUserAgent,
  cleanUserAgentForLog,
} from "@/lib/security/bot-detection";
import {
  getVisitorToken,
  generateVisitorToken,
  deriveAnonymousVisitorId,
  setVisitorCookieOnResponse,
} from "@/lib/security/visitor-cookie";
import { classifyWithInternal } from "@/lib/analytics/classify-source";
// ── Phase 3.5: unified view analytics ──────────────────────────────────
// The /views route is the SINGLE canonical entry point for valid article
// views. When a NEW unique view is recorded, it ALSO fires an article_view
// AnalyticsEvent via the helper below. This keeps the public ArticleView
// counter and the admin AnalyticsEvent stream in sync — they represent
// the SAME underlying valid view events (no separate counter, no
// divergence). The client NO LONGER calls /api/v1/analytics/track for
// article_view — that would double-count.
import {
  recordArticleViewAnalytics,
  buildViewTrackContext,
} from "@/lib/analytics/article-view-tracking";

/**
 * POST /api/v1/articles/:id/views
 * =================================
 * Record a unique view on a PUBLIC article.
 *
 * PUBLIC ACCESS (spec §1, §5, §21):
 *   This endpoint is callable by BOTH authenticated users AND anonymous
 *   visitors (Google referrers, direct link clicks, Incognito browsers).
 *   No authentication is required to record a view on a public article.
 *
 * DEDUP MECHANICS (spec §3, §4, §11, §15, §16):
 *   Two layers of protection against view inflation:
 *
 *   LAYER 1 — Database unique constraints (authoritative):
 *     - Logged-in user:  `@@unique([articleId, userId])` — one row per
 *                       (article, user). Refresh = no-op (upsert).
 *     - Anonymous visitor: `@@unique([articleId, anonymousVisitorId])` —
 *                       one row per (article, visitor token). Refresh = no-op.
 *     The upsert is atomic at the DB level — even concurrent requests
 *     can't create duplicate rows (P2002 is caught + treated as a no-op).
 *
 *   LAYER 2 — Rate limiting (per IP, defense-in-depth):
 *     A single IP can record at most 60 article-view requests per minute.
 *     Exceeding that returns 429 — protects against scripted inflation
 *     even if the attacker rotates visitor tokens (e.g. by clearing
 *     cookies between requests).
 *
 * BOT EXCLUSION (spec §6, §18, §19):
 *   The User-Agent is checked against a curated list of known crawlers
 *   (Googlebot, Bingbot, Facebook, Twitterbot, WhatsApp, Discord, Slack,
 *   LinkedIn, Telegram, Pinterest, etc.). When the UA matches, the
 *   request is a no-op (no view recorded, returns `recorded: false`).
 *   This is a heuristic — the DB dedup layer is the authoritative guard.
 *
 * AUTHOR SELF-VIEW EXCLUSION (spec §6):
 *   If the viewer is the article's author, we skip recording. The author's
 *   own views never count toward the public view count.
 *
 * RESPONSE (spec §14):
 *   Returns `{ recorded: boolean, viewCount: number }` where:
 *     - `recorded: true` if a NEW view was inserted (or the existing row's
 *       `viewedAt` was bumped for re-views after the dedup window — see
 *       the comment block inside the handler for the dedup window logic).
 *     - `recorded: false` if the request was a duplicate, from a bot,
 *       from the author, or hit the rate limit.
 *     - `viewCount`: the current UNIQUE viewer count for this article
 *       (one row per user OR per anonymous visitor token). The caller can
 *       use this to update the UI without re-fetching the article.
 *
 * ERROR HANDLING (spec §22):
 *   View tracking failures NEVER return an error status — they always
 *   return 200 + `recorded: false`. This ensures the article reading
 *   experience is never broken by a tracking failure.
 *
 * COOKIES (spec §2):
 *   When an anonymous visitor has no `cc_visitor` cookie, we generate a
 *   fresh random UUID + set it via Set-Cookie on the response. The
 *   cookie is HttpOnly + SameSite=Lax + Secure (in production) — see
 *   src/lib/security/visitor-cookie.ts for the full privacy model.
 */
export const POST = apiHandler(async (req, ctx) => {
  const { id } = await ctx.params;

  if (!id || typeof id !== "string") {
    return notFound("Article not found.");
  }

  // ── 1. Bot / crawler exclusion (spec §6, §18, §19) ──────────────────
  // First line of defense — known crawlers are short-circuited to a no-op
  // response. This prevents social-media link-preview fetchers (WhatsApp,
  // Facebook, X, Discord, Slack) + search-engine bots (Googlebot, Bingbot)
  // from inflating view counts.
  //
  // NOTE: this is a heuristic, NOT a security boundary. The DB dedup layer
  // is the authoritative guard. We use this check because:
  //   1. It's fast (skips the DB query entirely).
  //   2. It catches the COMMON case (most crawlers identify themselves).
  //   3. Even if a crawler slips through, the dedup layer limits it to
  //      one row per (article, visitor token).
  const userAgent = req.headers.get("user-agent");
  if (isCrawlerUserAgent(userAgent)) {
    // Return the CURRENT view count (so the UI doesn't show 0 if the bot
    // happened to be the first visitor — extremely rare but defensive).
    const currentCount = await db.articleView
      .count({ where: { articleId: id } })
      .catch(() => 0);
    return ok({ recorded: false, viewCount: currentCount });
  }

  // ── 2. Rate limiting (per IP, defense-in-depth) ─────────────────────
  // Even with cookie-based dedup, an attacker could rotate visitor tokens
  // (clear cookies between requests) to inflate counts. This IP-level rate
  // limit caps the abuse: 60 view requests per minute per IP. Exceeding
  // returns a soft no-op (200 + recorded: false) rather than a hard 429 —
  // we don't want to break the article reading experience for legitimate
  // users behind a shared NAT (corporate network, mobile carrier).
  const clientIp = getClientIp(req);
  const rateLimitKey = `article-view:ip:${clientIp}`;
  const rateLimit = await checkRateLimit(rateLimitKey, {
    limit: 60,
    windowSeconds: 60,
  }).catch(() => ({ ok: true } as const)); // fail open on rate-limit errors
  if (!rateLimit.ok) {
    const currentCount = await db.articleView
      .count({ where: { articleId: id } })
      .catch(() => 0);
    return ok({ recorded: false, viewCount: currentCount, rateLimited: true });
  }

  // ── 3. Article existence + status check ──────────────────────────────
  // Verify the article exists AND is PUBLISHED. Drafts / deleted / unknown
  // articles return 404 (spec §28 — never return 200 for missing content).
  const article = await db.article.findUnique({
    where: { id },
    select: { id: true, authorId: true, status: true },
  });
  if (!article || article.status !== "PUBLISHED") {
    return notFound("Article not found.");
  }

  // ── 4. Resolve the viewer identity (authenticated OR anonymous) ──────
  // Try to get the logged-in user. If that fails (no session), fall back
  // to anonymous visitor tracking via the `cc_visitor` cookie.
  //
  // We use `getCurrentUser()` (NOT `requireUser()`) — it returns null
  // for anonymous visitors instead of throwing 401. This is the KEY
  // change that enables public view tracking.
  const user = await getCurrentUser().catch(() => null);

  // Author self-view exclusion (spec §6).
  if (user && article.authorId === user.id) {
    const currentCount = await db.articleView
      .count({ where: { articleId: id } })
      .catch(() => 0);
    return ok({ recorded: false, viewCount: currentCount });
  }

  // ── 5. Build the dedup key + row data ────────────────────────────────
  // For logged-in users: dedup by userId.
  // For anonymous visitors: dedup by anonymousVisitorId (hash of cookie).
  //
  // We also need to set the visitor cookie on the response if the visitor
  // doesn't have one yet — that's why we track `needsSetCookie` + the
  // `newVisitorToken` value.
  let userId: string | null = user?.id ?? null;
  let anonymousVisitorId: string | null = null;
  let needsSetCookie = false;
  let newVisitorToken: string | null = null;

  if (!userId) {
    // Anonymous visitor — get or generate the visitor token.
    let visitorToken = await getVisitorToken().catch(() => null);
    if (!visitorToken) {
      // No cookie present — generate a fresh one. We'll set it on the
      // response via Set-Cookie so the next request from this browser
      // carries it.
      visitorToken = generateVisitorToken();
      needsSetCookie = true;
      newVisitorToken = visitorToken;
    }
    // Hash the token into a stable pseudo-id for the DB column. We never
    // store the raw cookie value — only the SHA-256 hash (privacy).
    anonymousVisitorId = await deriveAnonymousVisitorId(visitorToken);
  }

  // ── 5b. Traffic source classification (spec §4, §5, §6, §7, §8) ───────
  // Read the Referer header (server-side — same data the client would
  // send via document.referrer). Classify it into { source, referralDomain }
  // using the existing classifyWithInternal() helper, which handles:
  //   - same-site referrers → "internal" (spec §7)
  //   - Google localized domains → "google" (spec §4)
  //   - Bing/Yahoo/DuckDuckGo/other search → "search" medium
  //   - Facebook/Instagram/TikTok/YouTube/Reddit/X/WhatsApp/Telegram/etc.
  //     → recognized social sources (spec §9)
  //   - other external sites → "referral" medium with the hostname
  //   - empty referrer → "direct" (spec §6)
  //
  // We use FIRST-TOUCH attribution: the source is captured on the FIRST
  // view (when the row is CREATED) and NOT updated on re-views (when the
  // row is updated by the upsert's onConflict). This matches standard
  // analytics conventions (Google Analytics, Mixpanel) — the source that
  // brought the visitor to the article is preserved even if they later
  // re-open the article from a different referrer.
  const refererHeader = req.headers.get("referer") ?? req.headers.get("referrer");
  const currentHost = req.headers.get("host");
  const classified = classifyWithInternal(refererHeader, currentHost);

  // ── 6. Atomic upsert (spec §9) ───────────────────────────────────────
  // Prisma's `upsert` compiles to `INSERT ... ON CONFLICT DO UPDATE` on
  // PostgreSQL — atomic at the DB level. The unique constraint on
  // (articleId, userId) for logged-in users OR (articleId, anonymousVisitorId)
  // for anonymous visitors determines which row conflicts.
  //
  // For LOGGED-IN users:
  //   - conflict target: (articleId, userId)
  //   - on conflict: bump viewedAt (no new row, no count inflation).
  //
  // For ANONYMOUS visitors:
  //   - conflict target: (articleId, anonymousVisitorId)
  //   - on conflict: bump viewedAt.
  //
  // We choose which `where` clause + `create` payload to use based on
  // whether userId or anonymousVisitorId is set.
  //
  // ── Phase 3.5: detect NEW view vs re-view ─────────────────────────────
  // We do a cheap findFirst BEFORE the upsert to know if the row already
  // exists. If it does NOT exist, the upsert will CREATE a new row → that
  // counts as a NEW valid view → we'll fire an article_view AnalyticsEvent
  // afterward. If it DOES exist, the upsert will just bump viewedAt →
  // NO new AnalyticsEvent (avoids double-counting on re-views).
  //
  // The findFirst is cheap because the table is indexed by (articleId, userId)
  // and (articleId, anonymousVisitorId) — both unique constraint indexes.
  // We only select `id` (single column, no joins).
  //
  // NOTE: the findFirst is intentionally BEFORE the upsert to avoid race
  // conditions where two concurrent requests both see "doesn't exist" →
  // both fire analytics events. The DB unique constraint still prevents
  // duplicate ArticleView rows (P2002 caught below). In the rare race
  // case, both events fire but only one ArticleView row survives — the
  // admin "article_view" event count might briefly exceed the public
  // count by 1 for that article. This is acceptable + self-corrects on
  // the next aggregation window.
  let recorded = false;
  let isNewView = false; // Phase 3.5: tracks whether the upsert CREATED a new row
  try {
    if (userId) {
      // Logged-in user path.
      // Check existence FIRST (cheap — indexed by articleId_userId).
      const existing = await db.articleView.findUnique({
        where: { articleId_userId: { articleId: id, userId } },
        select: { id: true },
      });
      isNewView = !existing;

      await db.articleView.upsert({
        where: { articleId_userId: { articleId: id, userId } },
        create: {
          articleId: id,
          userId,
          anonymousVisitorId: null,
          // Traffic source attribution (first-touch — spec §4-§8).
          source: classified.source,
          referralDomain: classified.referralDomain,
        },
        update: {
          // Bump viewedAt on re-view — this is an analytics signal (the
          // user revisited the article) but does NOT create a new row
          // and does NOT inflate the view count.
          // NOTE: source + referralDomain are NOT updated here (first-touch
          // attribution — preserves the original traffic source).
          viewedAt: new Date(),
        },
      });
      recorded = true;
    } else if (anonymousVisitorId) {
      // Anonymous visitor path.
      // Check existence FIRST (cheap — indexed by articleId_anonymousVisitorId).
      const existing = await db.articleView.findFirst({
        where: { articleId: id, anonymousVisitorId },
        select: { id: true },
      });
      isNewView = !existing;

      // NOTE: Prisma generates the unique constraint name from the column
      // list, so `articleId_anonymousVisitorId` is the compound key Prisma
      // generates for `@@unique([articleId, anonymousVisitorId])`.
      await db.articleView.upsert({
        where: {
          articleId_anonymousVisitorId: {
            articleId: id,
            anonymousVisitorId,
          },
        },
        create: {
          articleId: id,
          userId: null,
          anonymousVisitorId,
          // Traffic source attribution (first-touch — spec §4-§8).
          source: classified.source,
          referralDomain: classified.referralDomain,
        },
        update: {
          // Bump viewedAt on re-view. source + referralDomain NOT updated
          // (first-touch attribution).
          viewedAt: new Date(),
        },
      });
      recorded = true;
    }
  } catch (err) {
    // P2002 = unique constraint violation. This happens if:
    //   1. Two concurrent requests race past the upsert (rare).
    //   2. The conflict target doesn't match what Prisma expects (shouldn't
    //      happen, but defensive).
    // Either way, this is a no-op for us — the row already exists, no
    // new view was recorded.
    if (
      err instanceof Prisma.PrismaClientKnownRequestError &&
      err.code === "P2002"
    ) {
      recorded = false;
      isNewView = false; // race-condition: row already existed → not a new view
    } else {
      // Real error — log it but DON'T fail the request (spec §22). View
      // tracking failures must never break the article reading experience.
      logger.warn("application", "Failed to record article view", {
        articleId: id,
        userId: userId ?? "(anonymous)",
        anonymousVisitorId: anonymousVisitorId ?? "(none)",
        ip: clientIp,
        userAgent: cleanUserAgentForLog(userAgent),
        error: err instanceof Error ? err.message : String(err),
      });
      recorded = false;
      isNewView = false;
    }
  }

  // ── 6b. Phase 3.5 — Fire the analytics event (only for NEW views) ────
  // When a NEW unique view was just recorded (isNewView === true), we fire
  // an `article_view` AnalyticsEvent in the BACKGROUND. This is the SINGLE
  // canonical path for article_view analytics events — the client no longer
  // calls /api/v1/analytics/track for article_view (it would double-count).
  //
  // The AnalyticsEvent inherits the SAME source/medium classification the
  // ArticleView row was created with — guaranteeing the public counter and
  // the admin "article views" metric always agree.
  //
  // Fire-and-forget: the helper schedules the DB write via queueMicrotask.
  // The /views route returns to the client immediately.
  if (recorded && isNewView) {
    const trackCtx = buildViewTrackContext(req, userId, anonymousVisitorId);
    recordArticleViewAnalytics({
      articleId: id,
      ctx: trackCtx,
      path: `/articles/${id}`,
      referrer: refererHeader,
      source: classified.source,
      medium: classified.medium,
      utm: null, // UTM not collected by the /views route (the client doesn't send it here)
    });
  }

  // ── 7. Compute the new view count ────────────────────────────────────
  // Return the current unique viewer count so the UI can update without
  // re-fetching the article. This is the SERVER'S authoritative number —
  // we don't trust any client-supplied count (spec §8).
  const viewCount = await db.articleView
    .count({ where: { articleId: id } })
    .catch(() => 0);

  // ── 8. Build the response (optionally setting the visitor cookie) ─────
  // For anonymous visitors who didn't have a cookie, we set it now. The
  // cookie is HttpOnly + SameSite=Lax + Secure (in production) — see
  // src/lib/security/visitor-cookie.ts.
  //
  // We use NextResponse.json directly (instead of the `ok()` helper) so
  // we can attach the Set-Cookie header. The shape matches `ok()`:
  // { ok: true, data: {...} }.
  const responseBody = {
    recorded,
    viewCount,
    // Include the rate-limited flag so the client can opt to NOT retry
    // immediately (back off until the rate limit window resets).
    rateLimited: !rateLimit.ok,
  };

  if (needsSetCookie && newVisitorToken) {
    const response = NextResponse.json(
      { ok: true, data: responseBody },
      { status: 200 }
    );
    setVisitorCookieOnResponse(response, newVisitorToken);
    return response;
  }

  return ok(responseBody);
});

// Re-export removed: `export { getCurrentUser }` violated Next.js 16's route
// file signature contract (only HTTP method exports are allowed). Consumers
// import `getCurrentUser` directly from `@/lib/auth` — this re-export was
// unused dead code.
