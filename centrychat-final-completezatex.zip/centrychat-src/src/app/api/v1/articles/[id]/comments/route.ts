import { apiHandler, ok, badRequest, notFound, rateLimited} from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser, getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { validateCommentContent, parsePostContent } from "@/lib/posts/parser";
import { notifyArticleCommented, notifyCommentReplied, notifyMentioned } from "@/lib/notifications";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";
// Content moderation — same as for posts. Articles comments + replies are
// moderated independently (spec §10).
import { moderateContent, recordModerationEvent } from "@/lib/moderation";
import { Prisma } from "@prisma/client";

/**
 * GET /api/v1/articles/:id/comments
 * Phase 3 — Deep Discussions: flat fetch + tree build + multi-sort.
 * Mirrors the post comments API. See that route for detailed comments.
 */
export const GET = apiHandler(async (req, ctx) => {
  const viewer = await getCurrentUser();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Article not found.");

  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "20"), 1), 50);
  const cursorParam = url.searchParams.get("cursor");
  const sortParam = url.searchParams.get("sort") ?? "newest";
  const sort = (["top", "newest", "oldest"].includes(sortParam) ? sortParam : "newest") as "top" | "newest" | "oldest";

  const article = await db.article.findUnique({
    where: { id },
    select: { id: true, authorId: true, status: true },
  });
  if (!article) return notFound("Article not found.");
  if (article.status !== "PUBLISHED") {
    const isOwner = viewer?.id === article.authorId;
    const isAdmin = viewer?.role === "ADMIN" || viewer?.role === "SUPER_ADMIN";
    if (!isOwner && !isAdmin) return notFound("Article not found.");
  }

  let seek: { createdAt: Date; id: string } | null = null;
  if (cursorParam) {
    try {
      const decoded = JSON.parse(Buffer.from(cursorParam, "base64").toString("utf-8"));
      if (decoded.createdAt && decoded.id) seek = { createdAt: new Date(decoded.createdAt), id: decoded.id };
    } catch { /* invalid cursor */ }
  }

  // Phase 3 — fetch ALL comments flat (1 query, cap 2000).
  const MAX_COMMENTS_FLAT = 2000;
  const allComments = await db.articleComment.findMany({
    where: { articleId: id },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: MAX_COMMENTS_FLAT,
    select: FLAT_COMMENT_SELECT,
  });

  // Batch-fetch isLiked.
  const allCommentIds = new Set(allComments.map((c) => c.id));
  const likedIds = viewer
    ? new Set((await db.articleCommentLike.findMany({
        where: { userId: viewer.id, commentId: { in: [...allCommentIds] } },
        select: { commentId: true },
      })).map((l) => l.commentId))
    : new Set<string>();

  // Build tree.
  const commentMap = new Map<string, any>();
  for (const c of allComments) {
    commentMap.set(c.id, {
      ...c, isLiked: likedIds.has(c.id), likeCount: c._count.likes, replies: [] as any[],
    });
  }
  const topLevel: any[] = [];
  for (const c of allComments) {
    if (c.parentCommentId === null) {
      topLevel.push(commentMap.get(c.id));
    } else {
      const parent = commentMap.get(c.parentCommentId);
      if (parent) parent.replies.push(commentMap.get(c.id));
    }
  }

  // Phase 3.2 fix — Recursively normalize every parent's `replies` array
  // to (createdAt ASC, id ASC). Required because: the flat fetch is DESC
  // + tree-building pushes replies in DESC order, BUT the client appends
  // new replies with `[...c.replies, newReply]` (expecting oldest-first).
  // Without this normalization, a new reply visually lands BELOW older
  // replies for one render, then jumps to the TOP on next refresh.
  //
  // This sorts ONLY the inner `replies` arrays — it does NOT touch the
  // top-level array. Top-level sorting is handled by the existing
  // topLevel.sort(...) calls below (which only re-order the outermost
  // array, not inner replies).
  sortRepliesAsc(topLevel);

  // Sort.
  if (sort === "top") {
    topLevel.sort((a, b) => {
      const aScore = (a.likeCount ?? 0) + (a.replies?.length ?? 0);
      const bScore = (b.likeCount ?? 0) + (b.replies?.length ?? 0);
      if (bScore !== aScore) return bScore - aScore;
      return b.createdAt.getTime() - a.createdAt.getTime();
    });
  } else if (sort === "oldest") {
    topLevel.sort((a, b) => {
      const diff = a.createdAt.getTime() - b.createdAt.getTime();
      if (diff !== 0) return diff;
      return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
    });
  } else {
    topLevel.sort((a, b) => {
      const diff = b.createdAt.getTime() - a.createdAt.getTime();
      if (diff !== 0) return diff;
      return b.id < a.id ? -1 : b.id > a.id ? 1 : 0;
    });
  }

  // Paginate.
  let paginatedTopLevel = topLevel;
  if (seek) {
    const cursorIdx = topLevel.findIndex(
      (c) => c.createdAt.getTime() === seek!.createdAt.getTime() && c.id === seek!.id
    );
    if (cursorIdx >= 0) paginatedTopLevel = topLevel.slice(cursorIdx + 1);
  }

  const hasMore = paginatedTopLevel.length > limit;
  const page = hasMore ? paginatedTopLevel.slice(0, limit) : paginatedTopLevel;

  const nextCursor = hasMore && page.length > 0
    ? Buffer.from(JSON.stringify({
        createdAt: page[page.length - 1]!.createdAt instanceof Date
          ? (page[page.length - 1]!.createdAt as Date).toISOString()
          : page[page.length - 1]!.createdAt,
        id: page[page.length - 1]!.id,
      }), "utf-8").toString("base64")
    : null;

  const serialized = page.map((c) => serializeComment(c));
  const commentCount = allComments.length;

  return ok({ comments: serialized, nextCursor, commentCount });
});

function serializeComment(c: any): any {
  return {
    ...c,
    createdAt: c.createdAt instanceof Date ? c.createdAt.toISOString() : c.createdAt,
    updatedAt: c.updatedAt instanceof Date ? c.updatedAt.toISOString() : c.updatedAt,
    replies: (c.replies ?? []).map((r: any) => serializeComment(r)),
  };
}

/**
 * Phase 3.2 fix — Recursively sort every parent's `replies` array by
 * (createdAt ASC, id ASC). Mutates the tree in place. Required to match
 * the client's optimistic-append pattern (`[...c.replies, newReply]`)
 * which assumes existing replies are oldest-first.
 *
 * Recurses to arbitrary depth. Does NOT sort the input array itself —
 * only the inner `replies` arrays of each node (the top-level array
 * is sorted separately by the topLevel.sort(...) calls below).
 */
function sortRepliesAsc(comments: any[]) {
  for (const c of comments) {
    if (c.replies && c.replies.length > 0) {
      c.replies.sort((a: any, b: any) => {
        const diff = a.createdAt.getTime() - b.createdAt.getTime();
        if (diff !== 0) return diff;
        return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
      });
      sortRepliesAsc(c.replies);
    }
  }
}

/**
 * POST /api/v1/articles/:id/comments
 * Phase 3 — multi-level replies + mention parsing.
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Article not found.");
  const rl = await checkRateLimit(`comment:${user.id}`, RATE_LIMITS.comment);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const article = await db.article.findUnique({
    where: { id }, select: { id: true, authorId: true, status: true },
  });
  if (!article || article.status !== "PUBLISHED") return notFound("Article not found.");

  const body = await req.json().catch(() => ({} as unknown));
  const content = (body as { content?: unknown })?.content;
  const parentCommentId = (body as { parentCommentId?: unknown })?.parentCommentId;

  const result = validateCommentContent(content);
  if (!result.ok) return badRequest(result.error);

  // Phase 3 — validate parent (any depth, not just top-level).
  let parentComment: { id: string; authorId: string; articleId: string } | null = null;
  if (typeof parentCommentId === "string" && parentCommentId.trim()) {
    parentComment = await db.articleComment.findUnique({
      where: { id: parentCommentId.trim() },
      select: { id: true, authorId: true, articleId: true },
    });
    if (!parentComment || parentComment.articleId !== id) {
      return badRequest("Parent comment not found on this article.");
    }
  }

  // ── Domain Blocklist Check for URLs in comment/reply content ────────
  // HARD REJECT — blocked domains never enter the database. The context
  // is "REPLY" when this is a reply (parentCommentId set), "COMMENT" otherwise.
  {
    const { checkTextForBlockedDomains } = await import("@/lib/security/domain-blocklist");
    const ctx = typeof parentCommentId === "string" && parentCommentId.trim() ? "REPLY" : "COMMENT";
    const blockCheck = await checkTextForBlockedDomains(result.value, user.id, ctx);
    if (blockCheck.blocked) {
      return badRequest("This content contains a link that cannot be used on this platform.");
    }
  }

  // ── Content Moderation ─────────────────────────────────────────────
  // Same engine, different contentType ("article_comment") so the admin
  // queue can distinguish article comments from post comments. Replies
  // are also moderated here (parentCommentId !== null doesn't matter to
  // the engine).
  const moderationResult = await moderateContent({
    text: result.value,
    contentType: "article_comment",
    userId: user.id,
  });
  if (moderationResult.action === "BLOCK") {
    void recordModerationEvent({
      result: moderationResult,
      contentType: "article_comment",
      contentId: null,
      userId: user.id,
      originalText: result.value,
    });
    return badRequest(moderationResult.userMessage);
  }

  const comment = await db.articleComment.create({
    data: {
      articleId: id, authorId: user.id, content: result.value,
      parentCommentId: parentComment ? parentComment.id : null,
    },
    select: FLAT_COMMENT_SELECT,
  });

  // Record WARN/REVIEW for admin review.
  if (moderationResult.action !== "ALLOW") {
    void recordModerationEvent({
      result: moderationResult,
      contentType: "article_comment",
      contentId: comment.id,
      userId: user.id,
      originalText: result.value,
    });
  }

  // Notifications.
  if (parentComment) {
    if (parentComment.authorId !== user.id) {
      void notifyCommentReplied({
        contentType: "article", contentId: id, contentAuthorId: article.authorId,
        parentCommentId: parentComment.id, parentCommentAuthorId: parentComment.authorId,
        replyId: comment.id, replyAuthorId: user.id, actorFullName: user.fullName,
        actorUsername: user.username, actorIsVerified: user.isVerified,
        replyPreview: result.value.slice(0, 100),
      });
    }
  } else {
    void notifyArticleCommented({
      articleId: id, articleAuthorId: article.authorId, commentId: comment.id,
      actorId: user.id, actorFullName: user.fullName, actorUsername: user.username,
      actorIsVerified: user.isVerified, commentPreview: result.value.slice(0, 100),
    });
  }

  // Phase 3 — mention notifications.
  const parsed = parsePostContent(result.value);
  if (parsed.mentions.length > 0) {
    const mentionedUsernames = parsed.mentions.map((m) => m.username);
    const mentionedUsers = await db.user.findMany({
      where: { username: { in: mentionedUsernames.map((u) => u.toLowerCase()) }, status: "ACTIVE" },
      select: { id: true, username: true },
    }).catch(() => []);
    for (const mentionedUser of mentionedUsers) {
      void notifyMentioned({
        mentionedUserId: mentionedUser.id, actorId: user.id,
        contentType: "article", contentId: id, commentId: comment.id,
        actorName: user.fullName,
      });
    }
  }

  void getRecommendationEngine().trackInteraction({
    userId: user.id, contentType: "article", contentId: id, action: "comment",
  });

  return ok({ comment: { ...comment, isLiked: false, likeCount: 0, replies: [] } });
});

const FLAT_COMMENT_SELECT = {
  id: true, articleId: true, content: true, parentCommentId: true,
  createdAt: true, updatedAt: true,
  author: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
  _count: { select: { likes: true } },
} as const satisfies Prisma.ArticleCommentSelect;

export type CommentDTO = Prisma.ArticleCommentGetPayload<{ select: typeof FLAT_COMMENT_SELECT }>;
