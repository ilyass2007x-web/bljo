import { apiHandler, ok, notFound, parseJsonBody, rateLimited} from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";

/**
 * POST /api/v1/articles/:id/share
 * --------------------------------
 * Record a SHARE interaction on an article. Mirrors the post share
 * endpoint's design.
 *
 * Auth: requires authenticated + verified user.
 *
 * Behavior:
 *   - Records an ArticleInteraction row with type="SHARE".
 *   - The optional `method` field tracks how the article was shared
 *     (native, link_copy, etc.) — same convention as the Post share.
 *
 * Response: { shared: true, shareCount: number }
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  const rl = await checkRateLimit(`share:${user.id}`, RATE_LIMITS.share);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  if (!id || typeof id !== "string") {
    return notFound("Article not found.");
  }

  const article = await db.article.findUnique({
    where: { id },
    select: { id: true, status: true },
  });
  if (!article || article.status !== "PUBLISHED") {
    return notFound("Article not found.");
  }

  const body = await parseJsonBody<{ method?: string }>(req);
  const method = typeof body.method === "string" && body.method.length <= 50
    ? body.method : "native";

  // Record the SHARE interaction. userId is nullable for anonymous
  // shares, but since this endpoint requires auth, we always have a user.
  await db.articleInteraction.create({
    data: {
      articleId: id,
      userId: user.id,
      type: "SHARE",
      metadata: JSON.stringify({ shareMethod: method }),
    },
  });

  // Re-fetch the accurate share count from the database.
  const shareCount = await db.articleInteraction.count({
    where: { articleId: id, type: "SHARE" },
  });

  // Fire-and-forget: track the "share" interaction for the recommendation
  // engine. Sharing an article is a strong positive signal.
  void getRecommendationEngine().trackInteraction({
    userId: user.id,
    contentType: "article",
    contentId: id,
    action: "share",
  });

  return ok({ shared: true, shareCount });
});
