import { apiHandler, ok, notFound } from "@/lib/api";
import { db } from "@/lib/database";
import { findRelatedArticles } from "@/lib/articles/related";

/**
 * GET /api/v1/articles/:id/related
 * ----------------------------------
 * Returns related articles for a given article.
 *
 * PUBLIC endpoint (no auth required) — works for both logged-in users AND
 * anonymous visitors (Google referrers, direct link clicks). The article
 * reading page is server-rendered, so the recommendations must be available
 * without a session.
 *
 * Query params:
 *   - limit (optional, default 5, max 6) — how many recommendations to return.
 *
 * Response:
 *   { articles: RelatedArticleDTO[] }
 *
 * The response is EMPTY (not an error) when:
 *   - The source article doesn't exist or isn't published.
 *   - No candidates are available (e.g. new platform with < 2 articles).
 *   - A database error occurs (graceful degradation — the article page
 *     still works, the recommendations section just hides itself).
 *
 * SECURITY:
 *   - Only PUBLISHED articles are candidates (drafts excluded).
 *   - The current article is always excluded (enforced in findRelatedArticles).
 *   - No user-specific data is exposed.
 *
 * PERFORMANCE (spec §12):
 *   - 1 query for the source article (PK lookup).
 *   - 1 query for the candidate pool (30 articles, indexed).
 *   - 1 batch query for share counts (groupBy).
 *   - Scoring is in-memory O(30). Total: 3 DB queries.
 */
export const GET = apiHandler(async (req, ctx) => {
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") {
    return notFound("Article not found.");
  }

  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "5"), 1), 6);

  // Verify the source article exists + is published. This is a fast PK lookup.
  // If it doesn't exist, return 404 (not an empty array) so the caller knows
  // the article ID is invalid.
  const source = await db.article.findUnique({
    where: { id },
    select: { id: true, status: true },
  }).catch(() => null);

  if (!source || source.status !== "PUBLISHED") {
    return notFound("Article not found.");
  }

  // Find related articles. This function handles all the scoring + diversity
  // + fallback logic. It NEVER throws — errors are caught + return an empty
  // array so the article page continues working.
  const articles = await findRelatedArticles(id, limit);

  return ok({ articles });
});
