import { apiHandler, ok, notFound } from "@/lib/api";
import { requireUser, ForbiddenError } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * GET /api/v1/articles/:id/insights
 * ----------------------------------
 * Returns aggregated analytics for a single article. Mirrors the post
 * insights endpoint's design.
 *
 * SECURITY (spec §3, §8, §9, §25):
 *   - The requesting user is resolved from the session (never from the
 *     client).
 *   - The article's authorId is compared against the session user's ID.
 *   - Only the article OWNER or an ADMIN/SUPER_ADMIN can access this
 *     endpoint. A normal user trying another user's article ID gets 403.
 *   - No individual viewer identities are returned — only aggregated
 *     counts + percentages.
 *
 * METRICS (spec §9):
 *   - uniqueViews: COUNT(*) on ArticleView (one row per (articleId, userId))
 *   - likes: COUNT(*) on ArticleLike
 *   - comments: COUNT(*) on ArticleComment
 *   - shares: COUNT(*) on ArticleInteraction WHERE type = 'SHARE'
 *   - engagementRate: (likes + comments + shares) / uniqueViews × 100
 *   - followerViews: views from users who follow the article's author
 *   - nonFollowerViews: views from users who don't follow the author
 *
 * PERFORMANCE (spec §22):
 *   All metrics are computed via batch COUNT queries (no N+1). Uses
 *   the existing indexes on ArticleView, ArticleLike, ArticleComment,
 *   ArticleInteraction.
 */
export const GET = apiHandler(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;

  if (!id || typeof id !== "string") {
    return notFound("Article not found.");
  }

  // Fetch the article to verify ownership.
  const article = await db.article.findUnique({
    where: { id },
    select: {
      id: true,
      authorId: true,
      title: true,
      excerpt: true,
      publishedAt: true,
      status: true,
    },
  });

  if (!article) return notFound("Article not found.");

  // Authorization: only the owner or an admin can view insights.
  const isOwner = article.authorId === user.id;
  const isAdmin = user.role === "ADMIN" || user.role === "SUPER_ADMIN";
  if (!isOwner && !isAdmin) {
    throw new ForbiddenError("You can only view insights for your own articles");
  }

  // ── Run all count queries in parallel (no N+1) ──────────────────
  const [uniqueViews, likes, comments, shares, followerViewRows] = await Promise.all([
    db.articleView.count({ where: { articleId: id } }),
    db.articleLike.count({ where: { articleId: id } }),
    db.articleComment.count({ where: { articleId: id } }),
    db.articleInteraction.count({ where: { articleId: id, type: "SHARE" } }),
    db.articleView.findMany({
      where: { articleId: id },
      select: { userId: true },
    }),
  ]);

  // Batch-check follow relationships for all viewers (follower vs non-follower).
  const viewerIds = followerViewRows
    .map((v) => v.userId)
    .filter((id): id is string => !!id);

  let followerCount = 0;
  let nonFollowerCount = 0;

  if (viewerIds.length > 0) {
    const follows = await db.follow.findMany({
      where: {
        followerId: { in: viewerIds },
        followingId: article.authorId,
      },
      select: { followerId: true },
    });
    const followerSet = new Set(follows.map((f) => f.followerId));
    for (const vid of viewerIds) {
      if (followerSet.has(vid)) {
        followerCount++;
      } else {
        nonFollowerCount++;
      }
    }
  }

  // Anonymous views (userId = null) are counted as non-follower.
  const anonViews = followerViewRows.filter((v) => !v.userId).length;
  nonFollowerCount += anonViews;

  // Engagement rate (spec §6 / §9).
  const totalEngagement = likes + comments + shares;
  const engagementRate = uniqueViews > 0
    ? Math.round((totalEngagement / uniqueViews) * 1000) / 10
    : 0;

  return ok({
    article: {
      id: article.id,
      title: article.title,
      excerpt: article.excerpt ?? article.title.slice(0, 200),
      publishedAt: article.publishedAt?.toISOString() ?? null,
    },
    metrics: {
      uniqueViews,
      likes,
      comments,
      shares,
      engagementRate,
    },
    audience: {
      followerViews: followerCount,
      nonFollowerViews: nonFollowerCount,
      followerPercentage: uniqueViews > 0
        ? Math.round((followerCount / uniqueViews) * 1000) / 10
        : 0,
      nonFollowerPercentage: uniqueViews > 0
        ? Math.round((nonFollowerCount / uniqueViews) * 1000) / 10
        : 0,
    },
    trafficSources: null,
  });
});
