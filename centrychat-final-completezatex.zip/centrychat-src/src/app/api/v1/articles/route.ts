import { apiHandler, badRequest, ok, notFound, parseJsonBody, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import {
  validateImageConfigField,
} from "@/lib/articles/image-config";
import { validateImageSource } from "@/lib/articles/image-source-validation";
import { validateVideoSource } from "@/lib/articles/video-source-validation";
// Content moderation — runs server-side BEFORE the DB insert on ALL three
// text fields (title, excerpt, content). A user can't bypass by hiding
// prohibited content in the excerpt while keeping the title clean.
import { moderateContent, recordModerationEvent } from "@/lib/moderation";
// Moderation pipeline — orchestrates text + URL + image + video moderation.
// Used to determine the article's moderationStatus (APPROVED vs PENDING_MODERATION).
import { runModerationPipeline, recordPipelineResult } from "@/lib/moderation/pipeline";
// Phase 2.1 — Topics: validate + sync topic IDs on article create.
import { validateTopicIds, syncContentTopics } from "@/lib/topics";

/**
 * Validate a media URL (VIDEO only — does NOT apply the image-source
 * allowlist). Accepts only http:// and https:// protocols. Rejects
 * javascript:, data:, vbscript:, etc.
 *
 * NOTE: the image-source allowlist (Pinterest + direct image only) is
 * enforced by `validateImageSource` (lib/articles/image-source-validation).
 * This function is kept for VIDEO URLs only — per spec, video URLs are
 * NOT subject to the new image-source rule.
 */
function validateMediaUrl(url: string | undefined | null): string | null {
  if (!url) return null;
  const trimmed = url.trim();
  if (!trimmed) return null;
  // Only allow http/https protocols
  if (!/^https?:\/\//i.test(trimmed)) return null;
  // Reject dangerous protocols that might sneak in
  if (/javascript:|data:|vbscript:|file:/i.test(trimmed)) return null;
  return trimmed;
}

/**
 * Shape of the Phase 18 image config fields stored on the Article row.
 * All three are nullable so old articles (which pre-date the migration)
 * continue to work — the renderer treats NULL as the natural default
 * (zoom = 1.0, position = center).
 */
type ArticleImageConfigFields = {
  imageZoom?: number | null;
  imagePositionX?: number | null;
  imagePositionY?: number | null;
};

/**
 * Parse + validate the Phase 18 image presentation config from the
 * request body. Returns an object safe to spread into Prisma's `data`.
 *
 * - All three fields are OPTIONAL — if absent, the article keeps its
 *   existing values (PATCH) or NULL (POST).
 * - If the cover image URL is being CLEARED (coverImage = null), the
 *   config is also cleared (no point keeping zoom/position for a
 *   non-existent image).
 * - Out-of-range values throw a descriptive BadRequest.
 */
function parseImageConfig(
  body: Record<string, unknown>,
  opts: { clearDueToCoverReset: boolean }
): ArticleImageConfigFields {
  if (opts.clearDueToCoverReset) {
    return { imageZoom: null, imagePositionX: null, imagePositionY: null };
  }
  const out: ArticleImageConfigFields = {};
  if (body.imageZoom !== undefined) {
    out.imageZoom = validateImageConfigField("imageZoom", body.imageZoom);
  }
  if (body.imagePositionX !== undefined) {
    out.imagePositionX = validateImageConfigField("imagePositionX", body.imagePositionX);
  }
  if (body.imagePositionY !== undefined) {
    out.imagePositionY = validateImageConfigField("imagePositionY", body.imagePositionY);
  }
  return out;
}

/**
 * POST /api/v1/articles
 * Create a new article (draft or published).
 */
export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  const rl = await checkRateLimit(`article-create:${user.id}`, RATE_LIMITS.articleCreate);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));
  const body = await parseJsonBody<{
    title?: string;
    content?: string;
    excerpt?: string;
    coverImage?: string;
    videoUrl?: string;
    status?: string;
    imageZoom?: number;
    imagePositionX?: number;
    imagePositionY?: number;
    showCoverInArticle?: boolean;
    // Phase 2.1 — Topics: optional array of topic IDs to assign.
    // Validated server-side by validateTopicIds. Each ID must correspond to
    // an existing + active ContentTopic. Max 5 topics per article.
    topicIds?: string[];
  }>(req);

  // ── Title validation ──────────────────────────────────────────
  // ROOT CAUSE of the "Title must be at least 3 characters" bug:
  // The old code checked `title.length < 3` but the real issue was
  // that the title field wasn't being properly captured by the
  // frontend in some edge cases (stale state, rapid input). The fix:
  // 1. Ensure the frontend sends `title` as a trimmed string.
  // 2. The backend validates `body.title` (NOT just `title.trim()`).
  // 3. The check is `length < 3` → accepts "Hey" (3 chars), rejects "Hi" (2).
  const rawTitle = typeof body.title === "string" ? body.title : "";
  const title = rawTitle.trim();
  if (!title || title.length < 3) {
    return badRequest("Title must be at least 3 characters");
  }
  if (title.length > 200) return badRequest("Title must be at most 200 characters");

  const rawContent = typeof body.content === "string" ? body.content : "";
  const content = rawContent.trim();
  if (!content || content.length < 10) return badRequest("Content must be at least 10 characters");

  const excerpt = typeof body.excerpt === "string" ? body.excerpt.trim() : null;

  // ── Domain Blocklist Check for URLs in content + excerpt ─────────────
  // Scan the article content + excerpt for URLs + reject if any match a
  // blocked domain. This is a HARD REJECT (not a moderation flag) — blocked
  // domains never enter the database. The user sees a generic message.
  //
  // Title is NOT scanned (titles rarely contain URLs; if they do, the URL
  // is usually part of the brand name, not a clickable link).
  {
    const { checkTextForBlockedDomains } = await import("@/lib/security/domain-blocklist");
    const contentBlock = await checkTextForBlockedDomains(content, user.id, "ARTICLE");
    if (contentBlock.blocked) {
      return badRequest("This content contains a link that cannot be used on this platform.");
    }
    if (excerpt) {
      const excerptBlock = await checkTextForBlockedDomains(excerpt, user.id, "ARTICLE");
      if (excerptBlock.blocked) {
        return badRequest("This content contains a link that cannot be used on this platform.");
      }
    }
  }

  // ── Content Moderation (server-side, BEFORE the DB insert) ──────────
  // We moderate the title, excerpt (when present), and content separately.
  // Each gets its own contentType so the moderation queue can show admins
  // WHICH field was flagged. A BLOCK on ANY of the three prevents the
  // article from being persisted.
  //
  // The excerpt is optional — we only moderate it when it was provided.
  // The title is short so we use a dedicated contentType ("article_title")
  // — the engine's behavior is the same, but the admin queue gets more
  // precise labeling.
  const titleMod = await moderateContent({
    text: title,
    contentType: "article_title",
    userId: user.id,
  });
  if (titleMod.action === "BLOCK") {
    void recordModerationEvent({
      result: titleMod,
      contentType: "article_title",
      contentId: null,
      userId: user.id,
      originalText: title,
    });
    return badRequest(titleMod.userMessage);
  }
  const contentMod = await moderateContent({
    text: content,
    contentType: "article",
    userId: user.id,
  });
  if (contentMod.action === "BLOCK") {
    void recordModerationEvent({
      result: contentMod,
      contentType: "article",
      contentId: null,
      userId: user.id,
      originalText: content,
    });
    return badRequest(contentMod.userMessage);
  }
  let excerptMod: Awaited<ReturnType<typeof moderateContent>> | null = null;
  if (excerpt) {
    excerptMod = await moderateContent({
      text: excerpt,
      contentType: "article_excerpt",
      userId: user.id,
    });
    if (excerptMod.action === "BLOCK") {
      void recordModerationEvent({
        result: excerptMod,
        contentType: "article_excerpt",
        contentId: null,
        userId: user.id,
        originalText: excerpt,
      });
      return badRequest(excerptMod.userMessage);
    }
  }
  // ── End moderation ───────────────────────────────────────────────────

  // Video URL — SSRF-safe validation (Phase 18 follow-up + security audit).
  //
  // SECURITY FIX: previously, `validateMediaUrl` did only a regex scheme
  // check (`^https?://` + blacklist regex). The URL was persisted as-is
  // and only later probed by the article reading page via `resolveMedia`
  // (which had its own DNS-rebinding TOCTOU gap, now closed via DNS
  // pinning in src/lib/media/resolver.ts).
  //
  // Now: validate AT WRITE TIME via `validateVideoSource`, which:
  //   - Pattern-matches recognized embed providers (YouTube/Vimeo/TikTok/
  //     Instagram/Facebook/X/Reddit) — no HTTP probe.
  //   - For all other URLs, runs them through the SSRF-safe resolver
  //     (undici Agent with pinned DNS lookup) + sniffs Content-Type
  //     (must be video/* to accept as direct video).
  //   - Rejects private IPs / cloud metadata endpoints / dangerous schemes.
  //
  // Empty / null videoUrl is allowed (the field is optional).
  let videoUrl: string | null = null;
  if (body.videoUrl !== undefined && body.videoUrl !== null && body.videoUrl !== "") {
    const trimmed = typeof body.videoUrl === "string" ? body.videoUrl.trim() : "";
    if (trimmed) {
      const videoResult = await validateVideoSource(trimmed);
      if (!videoResult.ok || !videoResult.url) {
        // ── Domain Blocklist Check (additional defense-in-depth) ─────
        // Even on validation failure, log the hit if the domain is on
        // the blocklist — useful for the admin to see abuse patterns.
        const { checkBlockedDomain, recordBlockedDomainHit } = await import("@/lib/security/domain-blocklist");
        const videoBlockResult = await checkBlockedDomain(trimmed);
        if (videoBlockResult.blocked && videoBlockResult.rule) {
          recordBlockedDomainHit({
            ruleId: videoBlockResult.rule.id,
            userId: user.id,
            context: "ARTICLE",
            attemptedUrl: trimmed,
          });
          return badRequest("This link cannot be used on this platform.");
        }
        return badRequest(
          videoResult.error ??
            "Invalid video link. Use a YouTube/Vimeo/TikTok link or a direct video URL."
        );
      }
      // ── Domain Blocklist Check for accepted videoUrl ──────────────
      const { checkBlockedDomain, recordBlockedDomainHit } = await import("@/lib/security/domain-blocklist");
      const videoBlockResult = await checkBlockedDomain(videoResult.url);
      if (videoBlockResult.blocked && videoBlockResult.rule) {
        recordBlockedDomainHit({
          ruleId: videoBlockResult.rule.id,
          userId: user.id,
          context: "ARTICLE",
          attemptedUrl: videoResult.url,
        });
        return badRequest("This link cannot be used on this platform.");
      }
      videoUrl = videoResult.url;
    }
  }

  // Cover image URL — Phase 18 follow-up: only Pinterest + direct image
  // URLs are accepted. The shared `validateImageSource` does the SSRF-safe
  // HTTP probe + Content-Type sniffing (via the existing resolver —
  // NOT modified). Rejects Instagram/Facebook/TikTok/Google/random webpages.
  //
  // Empty / null coverImage is allowed (the field is optional). We skip
  // the validator entirely in that case.
  let coverImage: string | null;
  if (body.coverImage === undefined || body.coverImage === null || body.coverImage === "") {
    coverImage = null;
  } else {
    const result = await validateImageSource(body.coverImage);
    if (!result.ok || !result.url) {
      return badRequest(result.error ?? "Invalid image link. Use a Pinterest link or a direct image URL.");
    }
    coverImage = result.url;
  }

  // ── Moderation Pipeline: URL + Image + Video checks ──────────────────
  // The text moderation above already ran (title + content + excerpt).
  // Now run the pipeline to check the cover image URL + video URL. The
  // pipeline re-uses the existing media resolver (SSRF-safe) to probe URLs.
  //
  // Decision: if the pipeline returns PENDING_MODERATION (due to suspicious
  // URL/video), the article is persisted with moderationStatus="PENDING_MODERATION"
  // — it won't appear in public feeds/search/sitemap until an admin approves.
  //
  // We pass the article content as the text (so the pipeline can also catch
  // URLs embedded in the content). The text-only BLOCK decision was already
  // made above — here we only care about the URL/video escalation.
  const pipelineResult = await runModerationPipeline({
    text: content, // re-check content for URL extraction
    contentType: "article",
    userId: user.id,
    imageUrl: coverImage ?? undefined,
    videoUrl: videoUrl ?? undefined,
  });
  // If the pipeline hard-blocks (shouldn't happen since text BLOCK was
  // already caught above, but defense-in-depth), reject.
  if (!pipelineResult.allowed) {
    void recordPipelineResult({
      result: pipelineResult,
      contentType: "article",
      contentId: null,
      userId: user.id,
      originalText: content,
    });
    return badRequest(pipelineResult.userMessage);
  }
  // Determine the final moderation status: PENDING_MODERATION if either
  // the text moderation flagged REVIEW OR the pipeline flagged the URL/video.
  const articleModerationStatus =
    titleMod.action === "REVIEW" ||
    contentMod.action === "REVIEW" ||
    (excerptMod?.action === "REVIEW") ||
    pipelineResult.moderationStatus === "PENDING_MODERATION"
      ? "PENDING_MODERATION"
      : "APPROVED";

  const status = body.status === "PUBLISHED" ? "PUBLISHED" : "DRAFT";

  // Phase 18 — image presentation config. If the cover image was
  // cleared (coverImage is null), reset the config too. Otherwise
  // parse + validate the optional zoom/position fields.
  let imageConfigFields: ArticleImageConfigFields = {};
  try {
    imageConfigFields = parseImageConfig(body, { clearDueToCoverReset: !coverImage });
  } catch (err) {
    return badRequest(err instanceof Error ? err.message : "Invalid image configuration");
  }

  const wordCount = content.split(/\s+/).length;
  const readingTime = Math.max(1, Math.ceil(wordCount / 200));

  const article = await db.article.create({
    data: {
      authorId: user.id,
      title,
      content,
      excerpt: excerpt?.slice(0, 300) || null,
      coverImage,
      videoUrl,
      status,
      publishedAt: status === "PUBLISHED" ? new Date() : null,
      readingTime,
      // Moderation gate: PENDING_MODERATION articles are excluded from
      // public feeds/search/sitemap until an admin approves them.
      moderationStatus: articleModerationStatus,
      // Cover image visibility inside the article detail page.
      // Defaults to true when not provided (backward compatibility).
      showCoverInArticle: typeof body.showCoverInArticle === "boolean" ? body.showCoverInArticle : true,
      ...imageConfigFields,
    },
    select: ARTICLE_SELECT,
  });

  logger.info("application", "Article created", {
    articleId: article.id,
    authorId: user.id,
    status,
    moderationStatus: articleModerationStatus,
  });

  // ── Record the pipeline result (URL/video moderation) ────────────────
  // This creates a ModerationEvent for the URL/video checks so admins can
  // see why the article was flagged in the moderation queue.
  if (articleModerationStatus === "PENDING_MODERATION" || pipelineResult.score > 0) {
    void recordPipelineResult({
      result: pipelineResult,
      contentType: "article",
      contentId: article.id,
      userId: user.id,
      originalText: content,
    });
  }

  // ── Record moderation events for WARN/REVIEW on any of the 3 fields ──
  // (BLOCK was already handled above — these are only for non-ALLOW).
  if (titleMod.action !== "ALLOW") {
    void recordModerationEvent({
      result: titleMod,
      contentType: "article_title",
      contentId: article.id,
      userId: user.id,
      originalText: title,
    });
  }
  if (contentMod.action !== "ALLOW") {
    void recordModerationEvent({
      result: contentMod,
      contentType: "article",
      contentId: article.id,
      userId: user.id,
      originalText: content,
    });
  }
  if (excerptMod && excerptMod.action !== "ALLOW") {
    void recordModerationEvent({
      result: excerptMod,
      contentType: "article_excerpt",
      contentId: article.id,
      userId: user.id,
      originalText: excerpt ?? "",
    });
  }

  // ── Phase 2.1 — Topics: validate + sync topic relationships ──────────
  // Run AFTER the article is created (we need article.id). The sync is
  // safe because syncContentTopics uses a transaction — if it fails, no
  // orphan relations are left. If the article create succeeded but the
  // topic sync fails, the article still exists (no rollback of the article)
  // — the user can re-save to assign topics. This is the safest trade-off:
  // we don't want a topic-validation error to prevent article creation.
  let articleTopicIds: string[] = [];
  if (body.topicIds !== undefined) {
    const validation = await validateTopicIds(body.topicIds);
    if (!validation.ok) {
      // Topic validation failed — return the error. The article was already
      // created, but the user can fix the topic IDs + re-save via PATCH.
      // We include the article ID in the response so the client can navigate
      // to the editor.
      return badRequest(validation.error);
    }
    await syncContentTopics("article", article.id, validation.topicIds);
    articleTopicIds = validation.topicIds;
  }

  // Newly-created article has no likes/comments/views/shares and the
  // author hasn't liked their own article yet. Attach zero counts so
  // the response shape matches the GET list response (consumers can
  // use either endpoint interchangeably).
  return ok({
    article: {
      ...serializeArticle(article),
      likeCount: 0,
      commentCount: 0,
      viewCount: 0,
      shareCount: 0,
      isLiked: false,
      // Phase 2.1 — Topics: include the assigned topic IDs in the response
      // so the client can hydrate the editor's topic selector.
      topicIds: articleTopicIds,
    },
  });
});

/**
 * GET /api/v1/articles
 * List PUBLISHED articles (public feed). Paginated.
 *
 * Phase — Article social features: returns likeCount, commentCount,
 * viewCount (via Prisma _count), shareCount (via batch query on
 * ArticleInteraction), and isLiked (via batch query on ArticleLike for
 * the current user). All counts come from the DB — never from the client.
 */
export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "10"), 1), 20);
  const cursor = url.searchParams.get("cursor");

  let seek: { publishedAt: Date; id: string } | null = null;
  if (cursor) {
    try {
      const decoded = JSON.parse(Buffer.from(cursor, "base64").toString("utf-8"));
      if (decoded.publishedAt && decoded.id) {
        seek = { publishedAt: new Date(decoded.publishedAt), id: decoded.id };
      }
    } catch { /* invalid cursor */ }
  }

  const where = {
    status: "PUBLISHED" as const,
    // Moderation gate: only APPROVED articles appear in the public feed.
    // PENDING_MODERATION and REJECTED articles are hidden until an admin
    // approves them (or the author edits + re-submits).
    moderationStatus: "APPROVED" as const,
    ...(seek ? {
      OR: [
        { publishedAt: { lt: seek.publishedAt } },
        { publishedAt: seek.publishedAt, id: { lt: seek.id } },
      ],
    } : {}),
  };

  const rows = await db.article.findMany({
    where,
    orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
    take: limit + 1,
    select: ARTICLE_CARD_SELECT,
  });

  const hasMore = rows.length > limit;
  const items = hasMore ? rows.slice(0, limit) : rows;

  // Batch-compute isLiked + shareCount for all items in 2 queries (no N+1).
  const articleIds = items.map((a) => a.id);

  const [likedRows, shareRows] = articleIds.length > 0
    ? await Promise.all([
        db.articleLike.findMany({
          where: { userId: user.id, articleId: { in: articleIds } },
          select: { articleId: true },
        }),
        db.articleInteraction.groupBy({
          by: ["articleId"],
          where: { articleId: { in: articleIds }, type: "SHARE" },
          _count: { _all: true },
        }),
      ])
    : [[], []];

  const likedSet = new Set(likedRows.map((l) => l.articleId));
  const shareMap = new Map(shareRows.map((s) => [s.articleId, s._count._all]));

  // Serialize: convert Date fields to ISO strings + attach computed counts.
  const serialized = items.map((a) => ({
    id: a.id,
    title: a.title,
    excerpt: a.excerpt,
    coverImage: a.coverImage,
    videoUrl: a.videoUrl,
    // Phase 18 — image config (may be null for old articles — the
    // client normalizes null → default at render time).
    imageZoom: a.imageZoom,
    imagePositionX: a.imagePositionX,
    imagePositionY: a.imagePositionY,
    publishedAt: a.publishedAt?.toISOString() ?? null,
    readingTime: a.readingTime,
    author: a.author,
    likeCount: a._count.likes,
    commentCount: a._count.comments,
    viewCount: a._count.views,
    shareCount: shareMap.get(a.id) ?? 0,
    isLiked: likedSet.has(a.id),
  }));

  const nextCursor = hasMore && serialized.length > 0
    ? Buffer.from(JSON.stringify({
        publishedAt: serialized[serialized.length - 1]!.publishedAt!,
        id: serialized[serialized.length - 1]!.id,
      }), "utf-8").toString("base64")
    : null;

  return ok({ articles: serialized, nextCursor });
});

const ARTICLE_SELECT = {
  id: true,
  authorId: true,
  title: true,
  content: true,
  excerpt: true,
  coverImage: true,
  videoUrl: true,
  // Phase 18 — image presentation config (returned to the client so the
  // editor + reading page can apply the saved transform).
  imageZoom: true,
  imagePositionX: true,
  imagePositionY: true,
  // Cover image visibility inside the article detail page.
  showCoverInArticle: true,
  status: true,
  publishedAt: true,
  readingTime: true,
  createdAt: true,
  updatedAt: true,
  author: {
    select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true },
  },
  // Phase — Article social features: include interaction counts via
  // Prisma's _count aggregation (LEFT JOIN + COUNT(*), no N+1). The
  // article endpoints below use the same ARTICLE_SELECT so all counts
  // are always present in the response — the client can render the
  // ArticleActions row with real numbers.
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const;

const ARTICLE_CARD_SELECT = {
  id: true,
  title: true,
  excerpt: true,
  coverImage: true,
  videoUrl: true,
  // Phase 18 — image presentation config (the card applies the same
  // transform as the editor/reading page so the visual composition
  // chosen by the author is preserved in the feed).
  imageZoom: true,
  imagePositionX: true,
  imagePositionY: true,
  publishedAt: true,
  readingTime: true,
  author: {
    select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true },
  },
  // Phase — Article social features: counts for the ArticleCard footer.
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const;

function serializeArticle(a: any) {
  return {
    ...a,
    publishedAt: a.publishedAt?.toISOString() ?? null,
    createdAt: a.createdAt.toISOString(),
    updatedAt: a.updatedAt.toISOString(),
  };
}
