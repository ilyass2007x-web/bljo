import { apiHandler, ok, badRequest } from "@/lib/api";
import { getEnabledTutorialVideo, TUTORIAL_LOCATIONS } from "@/lib/tutorial-videos";

/**
 * GET /api/v1/settings/public/tutorial-videos?location=PROFILE_IMAGE_TUTORIAL
 *
 * Returns the ENABLED tutorial video for the given location. Returns
 * `{ video: null }` when:
 *   - The location is unknown
 *   - No video is configured for that location
 *   - The video is configured but disabled by the admin
 *
 * Public endpoint — no auth required. Users can ONLY view. Admin
 * configuration happens via /api/v1/admin/tutorial-videos (admin-only).
 *
 * The 30-second server-side cache (in getEnabledTutorialVideo) keeps
 * this endpoint cheap even under heavy load — at most one DB hit per
 * 30s per location.
 */
export const GET = apiHandler(async (req) => {
  const url = new URL(req.url);
  const location = url.searchParams.get("location");

  if (!location || !(TUTORIAL_LOCATIONS as readonly string[]).includes(location)) {
    return badRequest("Unknown tutorial location.");
  }

  const video = await getEnabledTutorialVideo(location as typeof TUTORIAL_LOCATIONS[number]);
  return ok({ video });
});
