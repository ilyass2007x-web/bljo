import { apiHandler, ok } from "@/lib/api";
import { getSetting } from "@/lib/settings";
import { isFeatureEnabled } from "@/lib/features";

/**
 * GET /api/v1/settings/public
 * --------------------------------
 * Returns ONLY the public-safe platform branding fields + the
 * `collections` feature flag:
 *   - platformName (from `platform.name` setting)
 *   - platformDescription (from `platform.description` setting)
 *   - collectionsEnabled (from the FeatureFlag table — server-side source
 *     of truth, mirroring `isFeatureEnabled("collections")`)
 *
 * NO authentication required. This endpoint is called by client-side
 * components (auth-screen, messenger, etc.) to display the current
 * platform name dynamically. The browser tab title + meta description
 * are set SERVER-SIDE via `generateMetadata` in layout.tsx — this
 * endpoint is for the CLIENT-SIDE brand-name display only.
 *
 * Privacy: only `platform.name` + `platform.description` + the
 * `collections` feature flag are exposed. Other settings (admin emails,
 * other feature flags, recommendation weights, custom CSS, etc.) are
 * NOT exposed here — those require admin auth via the existing
 * `/api/v1/admin/customization` route.
 *
 * Caching:
 *   - Server-side: `getSetting()` uses a 30s in-memory cache
 *     (cacheGetOrSet), so this endpoint hits the DB at most every 30s.
 *     `isFeatureEnabled` uses the same cache (30s).
 *   - Client-side: the client store (src/lib/client/platform.ts) caches
 *     the value for the lifetime of the tab + refetches on focus.
 *
 * Revalidation:
 *   - When the admin changes Platform Name in Settings, the next
 *     client-side fetch (within 30s) returns the new value.
 *   - When the admin toggles the `collections` feature flag, the next
 *     client-side fetch (within 30s) returns the new value — the
 *     PostCard / ArticleCard re-render to show/hide the Save button.
 *   - The layout's `generateMetadata` re-runs on every page navigation,
 *     so the browser tab updates on the next route change.
 */
export const GET = apiHandler(async () => {
  const [platformName, platformDescription, collectionsEnabled, playlistsEnabled] = await Promise.all([
    getSetting("platform.name"),
    getSetting("platform.description"),
    isFeatureEnabled("collections"),
    isFeatureEnabled("playlists"),
  ]);

  return ok({
    platformName: platformName ?? "Platform",
    platformDescription: platformDescription ?? "A self-hostable messaging platform.",
    collectionsEnabled,
    playlistsEnabled,
  });
});
