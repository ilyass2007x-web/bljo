import { apiHandler, ok, badRequest, rateLimited} from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser, getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";
import {
  validatePostContent,
  parsePostContent,
  POST_MAX_LENGTH,
} from "@/lib/posts/parser";
// Content moderation — server-side, runs BEFORE the DB insert. NEVER trust
// client-provided moderation results. Uses the unified pipeline which
// orchestrates text + URL + image + video moderation.
import { runModerationPipeline, recordPipelineResult } from "@/lib/moderation/pipeline";
// Legacy text-only moderation (still used for the BLOCK decision in the
// non-pipeline path — kept for backward compatibility if the pipeline
// is ever disabled).
import { moderateContent as moderateContentTextOnly, recordModerationEvent } from "@/lib/moderation";
import {
  scoreAndRankPosts,
  getCandidatePoolSize,
  type RankablePost,
  type UserContext,
  FEED_WEIGHTS,
} from "@/lib/posts/ranking";
import type { Prisma } from "@prisma/client";
// Phase 2.1 — Topics: validate + sync topic IDs on post create.
import { validateTopicIds, syncContentTopics, batchGetContentTopicIds } from "@/lib/topics";

/**
 * POST /api/v1/posts
 * ---------------
 * Create a new text post. Phase 1 — text only, no media.
 *
 * Auth: requires an authenticated user with emailVerified + ACTIVE status
 * (uses requireVerifiedUser so suspended/banned/PENDING_VERIFICATION users
 * cannot post).
 *
 * Request body:
 *   { "content": string }
 *
 * The authorId is taken from the session, NOT from the request body —
 * clients cannot post on behalf of another user.
 *
 * Response: { post: PostDTO } where PostDTO includes interaction counts
 * (likeCount, commentCount, viewCount) + isLiked (whether the current user
 * has liked this post). All counts come from the database, never the client.
 */
export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  const rl = await checkRateLimit(`post-create:${user.id}`, RATE_LIMITS.postCreate);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await req.json().catch(() => ({} as unknown));
  const content = (body as { content?: unknown })?.content;

  const result = validatePostContent(content);
  if (!result.ok) {
    return badRequest(result.error);
  }

  // ── Domain Blocklist Check for URLs in post content ──────────────────
  // Scan the post text for URLs + reject if any match a blocked domain.
  // This is a HARD REJECT (not a moderation flag) — blocked domains never
  // enter the database. The user sees a generic message.
  {
    const { checkTextForBlockedDomains } = await import("@/lib/security/domain-blocklist");
    const blockCheck = await checkTextForBlockedDomains(result.value, user.id, "POST");
    if (blockCheck.blocked) {
      return badRequest("This content contains a link that cannot be used on this platform.");
    }
  }

  // ── Content Moderation Pipeline ────────────────────────────────────
  // Runs server-side BEFORE the DB insert. A malicious user calling the
  // API directly cannot bypass this — the moderation decision is made
  // here, not on the client.
  //
  // The pipeline orchestrates:
  //   1. Text moderation (existing rule-based engine)
  //   2. URL moderation (SSRF-safe probe via media resolver)
  //   3. Image/video moderation (reputation + video always REVIEW)
  //
  // Decision:
  //   - BLOCK → content NOT persisted, return 400 with generic message.
  //   - REVIEW → content persisted with moderationStatus="PENDING_MODERATION"
  //     (excluded from public feeds/search/sitemap until admin approves).
  //   - ALLOW/WARN → content persisted with moderationStatus="APPROVED" (public).
  const moderationResult = await runModerationPipeline({
    text: result.value,
    contentType: "post",
    userId: user.id,
  });
  if (!moderationResult.allowed) {
    // Record the blocked-content event for admin review (contentId=null
    // because nothing was persisted).
    void recordPipelineResult({
      result: moderationResult,
      contentType: "post",
      contentId: null,
      userId: user.id,
      originalText: result.value,
    });
    return badRequest(moderationResult.userMessage);
  }

  // ── Phase 2.1 — Topics: validate topic IDs BEFORE creating the post ──
  // We validate first so we can fail fast without persisting a post that
  // can't have its topics synced. The sync happens AFTER the post is
  // created (we need post.id).
  const rawTopicIds = (body as { topicIds?: unknown })?.topicIds;
  let postTopicIds: string[] = [];
  if (rawTopicIds !== undefined) {
    const validation = await validateTopicIds(rawTopicIds);
    if (!validation.ok) {
      return badRequest(validation.error);
    }
    postTopicIds = validation.topicIds;
  }

  // Insert the post. Prisma parameterizes the query — no SQL injection
  // vector. authorId comes from the authenticated session, never from
  // the request body. moderationStatus is set from the moderation pipeline
  // result — PENDING_MODERATION content is excluded from public feeds.
  const post = await db.post.create({
    data: {
      authorId: user.id,
      content: result.value,
      moderationStatus: moderationResult.moderationStatus,
    },
    select: POST_SELECT,
  });

  // ── Record moderation event for REVIEW/WARN (BLOCK was handled above) ──
  // PENDING_MODERATION content gets a ModerationEvent so admins can review
  // it in the queue. APPROVED content with score=0 doesn't need an event.
  if (moderationResult.moderationStatus === "PENDING_MODERATION" || moderationResult.score > 0) {
    void recordPipelineResult({
      result: moderationResult,
      contentType: "post",
      contentId: post.id,
      userId: user.id,
      originalText: result.value,
    });
  }

  // ── AI Moderation (additive — runs only when ai_moderation is enabled) ──
  // This is a SECOND moderation pass using the AI provider system. It runs
  // AFTER the existing rule-based pipeline + AFTER the post is persisted.
  // Non-breaking: when the feature flag is OFF, moderateContent() returns
  // { ran: false } immediately. When the AI returns BLOCK/DELETE, we apply
  // the content action AFTER the post exists (so the AI can override the
  // rule-based ALLOW decision — but never override an existing PENDING).
  //
  // This is fire-and-forget — we don't await it (the response goes back
  // immediately + the AI pipeline runs in the background). When the AI
  // returns a non-ALLOW action, the post is updated via applyContentAction.
  void (async () => {
    try {
      const { moderateContent, applyContentAction, applyUserAction } = await import("@/lib/ai-moderation");
      const aiResult = await moderateContent({
        text: result.value,
        contentType: "post",
        contentId: post.id,
        userId: user.id,
      });
      if (aiResult.ran && aiResult.decision.contentAction !== "ALLOW") {
        await applyContentAction("post", post.id, aiResult.decision.contentAction);
      }
      if (aiResult.ran && aiResult.decision.userAction !== "NONE" && user.id) {
        await applyUserAction(user.id, aiResult.decision.userAction);
      }
    } catch {
      // Non-fatal — AI moderation is best-effort. The rule-based engine
      // already made its decision + the post is already persisted.
    }
  })();

  // ── Phase 2.1 — Topics: sync topic relationships AFTER post creation ──
  // safe (transactional). If sync fails, the post still exists; the user
  // can re-save via PATCH to assign topics.
  if (rawTopicIds !== undefined && postTopicIds.length > 0) {
    await syncContentTopics("post", post.id, postTopicIds);
  }

  // Newly-created post has no likes/comments/views/shares and the author hasn't
  // liked their own post yet. The author can't follow themselves, so
  // isFollowing and isFollowedBy are both false. Attach zero counts so
  // the response shape matches the GET list response.
  const postWithCounts: PostDTO = {
    ...post,
    likeCount: 0,
    commentCount: 0,
    viewCount: 0,
    shareCount: 0,
    isLiked: false,
    topicIds: postTopicIds,
    author: {
      ...post.author,
      isFollowing: false,
      isFollowedBy: false,
    },
  };

  return ok({ post: postWithCounts });
});

/**
 * GET /api/v1/posts
 * -----------------
 * List posts, newest first, using cursor-based pagination.
 *
 * Auth: requires an authenticated, verified user.
 *
 * Feed semantics (Phase 8 — follow-graph aware):
 *   - If `authorId` query param is provided → return ONLY that author's
 *     posts (used by the Profile screen to show a specific user's posts).
 *     No follow-graph filter applies here — Profile always shows all of
 *     that user's posts regardless of who follows whom.
 *   - If `authorId` is NOT provided (the Home Feed case) → return posts
 *     authored by the current user OR by users the current user follows.
 *     This is the "Following" feed. The follow-graph filter is applied
 *     at the DATABASE level (not in the frontend) for performance —
 *     we fetch the list of followed user IDs in ONE query, then use
 *     `authorId: { in: [...] }` in the posts query.
 *
 * Query params:
 *   - limit    (default 20, max 50)  — page size
 *   - cursor   (optional)            — opaque cursor returned in the previous
 *                                       response's `nextCursor`
 *   - authorId (optional)            — filter to a single author's posts
 *                                       (bypasses the follow-graph filter)
 *
 * Performance:
 *   - Each post includes its likeCount/commentCount/viewCount via Prisma's
 *     `_count` aggregation. Prisma compiles this into a single SQL query
 *     with LEFT JOINs + COUNT(*) — NO N+1.
 *   - isLiked (per post, for the current user) is fetched in ONE additional
 *     query: `WHERE userId = ? AND postId IN (...)`. Result is attached as
 *     a Set for O(1) lookup per post. Total queries = 3 (followed IDs +
 *     posts + likes) regardless of page size.
 *
 * Response: { posts: PostDTO[], nextCursor: string | null }
 */
export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();

  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "20"), 1), 50);
  const cursorParam = url.searchParams.get("cursor");
  const authorId = url.searchParams.get("authorId");

  // Decode the opaque cursor into a (createdAt, id) seek tuple.
  let seek: { createdAt: Date; id: string } | null = null;
  if (cursorParam) {
    try {
      const decoded = JSON.parse(
        Buffer.from(cursorParam, "base64").toString("utf-8")
      ) as { createdAt?: string; id?: string };
      if (decoded.createdAt && decoded.id) {
        seek = { createdAt: new Date(decoded.createdAt), id: decoded.id };
      }
    } catch {
      return badRequest("Invalid cursor.");
    }
  }

  // ── Profile mode (authorId provided) — simple chronological ─────────
  // PENDING_MODERATION and REJECTED posts are excluded from public view.
  // The author themselves can still see their own pending posts (the
  // Profile screen passes the current user's ID as authorId — we check
  // that here so the author sees their full list including pending).
  if (authorId) {
    const where: Prisma.PostWhereInput = { authorId };
    // Hide non-approved posts from everyone EXCEPT the author.
    if (authorId !== user.id) {
      where.moderationStatus = "APPROVED";
    }
    if (seek) {
      where.OR = [
        { createdAt: { lt: seek.createdAt } },
        { createdAt: seek.createdAt, id: { lt: seek.id } },
      ];
    }

    const rows = await db.post.findMany({
      where,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: limit + 1,
      select: POST_SELECT,
    });

    const hasMore = rows.length > limit;
    const trimmed = hasMore ? rows.slice(0, limit) : rows;

    const postIds = trimmed.map((p) => p.id);
    const [likedPostIds, shareRows] = postIds.length > 0
      ? await Promise.all([
          new Set((await db.postLike.findMany({ where: { userId: user.id, postId: { in: postIds } }, select: { postId: true } })).map((l) => l.postId)),
          db.postInteraction.groupBy({
            by: ["postId"],
            where: { postId: { in: postIds }, type: "SHARE" },
            _count: { _all: true },
          }),
        ])
      : [new Set<string>(), [] as { postId: string; _count: { _all: number } }[]];
    const shareMap = new Map(shareRows.map((s) => [s.postId, s._count._all]));

    const uniqueAuthorIds = [...new Set(trimmed.map((p) => p.author.id))];
    // Batch-check BOTH follow directions: does the current user follow
    // the author (isFollowing)? Does the author follow the current user
    // (isFollowedBy, for "Follow Back" on the PostCard)?
    const [followedAuthorIds, followerAuthorIds] = uniqueAuthorIds.length > 0
      ? await Promise.all([
          new Set((await db.follow.findMany({ where: { followerId: user.id, followingId: { in: uniqueAuthorIds } }, select: { followingId: true } })).map((f) => f.followingId)),
          new Set((await db.follow.findMany({ where: { followerId: { in: uniqueAuthorIds }, followingId: user.id }, select: { followerId: true } })).map((f) => f.followerId)),
        ])
      : [new Set<string>(), new Set<string>()];

    // Phase 2.1 — Topics: batch-fetch topic IDs for all posts (1 query).
    // Used to populate `topicIds` in the response DTO.
    const postTopicMap = await batchGetContentTopicIds(
      "post",
      trimmed.map((p) => p.id)
    );

    const posts: PostDTO[] = trimmed.map((p) => ({
      ...p,
      likeCount: p._count.likes,
      commentCount: p._count.comments,
      viewCount: p._count.views,
      shareCount: shareMap.get(p.id) ?? 0,
      isLiked: likedPostIds.has(p.id),
      topicIds: postTopicMap.get(p.id) ?? [],
      author: {
        ...p.author,
        isFollowing: followedAuthorIds.has(p.author.id),
        isFollowedBy: followerAuthorIds.has(p.author.id),
      },
    }));

    const nextCursor = hasMore && posts.length > 0
      ? Buffer.from(JSON.stringify({ createdAt: posts[posts.length - 1].createdAt.toISOString(), id: posts[posts.length - 1].id }), "utf-8").toString("base64")
      : null;

    return ok({ posts, nextCursor });
  }

  // ── Home Feed mode — SMART RANKED FEED ─────────────────────────────
  //
  // Step 1: Fetch the user's followed IDs (1 query, reused for isFollowing).
  const followed = await db.follow.findMany({
    where: { followerId: user.id },
    select: { followingId: true },
  });
  const followedIdsSet = new Set(followed.map((f) => f.followingId));
  const feedAuthorIds = [user.id, ...followedIdsSet];

  // Step 2: Fetch the CANDIDATE POOL (3x page size, capped at 100).
  const poolSize = getCandidatePoolSize(limit);
  const followedPoolSize = Math.ceil(poolSize * (1 - FEED_WEIGHTS.explorationRatio));
  const explorationPoolSize = poolSize - followedPoolSize;

  const poolWhere: Prisma.PostWhereInput = seek
    ? { OR: [{ createdAt: { lt: seek.createdAt } }, { createdAt: seek.createdAt, id: { lt: seek.id } }] }
    : {};
  // Home Feed: exclude PENDING_MODERATION and REJECTED posts from ALL
  // pools (followed + exploration). The author sees their own pending
  // posts in Profile mode (authorId filter), not in the Home Feed.
  poolWhere.moderationStatus = "APPROVED";

  // Fetch from followed users + self.
  const followedPool = await db.post.findMany({
    where: { ...poolWhere, authorId: { in: feedAuthorIds } },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: followedPoolSize,
    select: RANKING_SELECT,
  });

  // Fetch exploration posts (non-followed, non-self).
  let explorationPool: typeof followedPool = [];
  if (explorationPoolSize > 0 && followedIdsSet.size > 0) {
    explorationPool = await db.post.findMany({
      where: { ...poolWhere, authorId: { notIn: feedAuthorIds } },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: explorationPoolSize,
      select: RANKING_SELECT,
    });
  }

  const candidatePool: RankablePost[] = [...followedPool, ...explorationPool];

  if (candidatePool.length === 0) {
    return ok({ posts: [], nextCursor: null });
  }

  // Step 3: Score and rank.
  const userCtx: UserContext = { userId: user.id, followedAuthorIds: followedIdsSet };
  const scored = scoreAndRankPosts(candidatePool, userCtx, limit);
  const hasMore = candidatePool.length >= poolSize && scored.length === limit;

  // Step 4: Fetch full post data for the winners (with author info).
  const winnerIds = scored.map((s) => s.post.id);
  const winners = await db.post.findMany({
    where: { id: { in: winnerIds } },
    select: POST_SELECT,
  });

  // Reorder to match ranking order.
  const winnerMap = new Map(winners.map((w) => [w.id, w]));
  const orderedWinners = winnerIds
    .map((id) => winnerMap.get(id))
    .filter((w): w is NonNullable<typeof w> => !!w);

  // Step 5: Batch fetch isLiked + isFollowedBy.
  // isFollowing is already known from followedIdsSet (step 1).
  // isFollowedBy requires checking the REVERSE follow relationship:
  // does the post's author follow the current user? We fetch ALL users
  // who follow the current user in a SINGLE query, then check each
  // post's author against that set — no N+1.
  const postIds = orderedWinners.map((p) => p.id);
  const [likedPostIds, followersOfMe, shareRows] = await Promise.all([
    postIds.length > 0
      ? new Set((await db.postLike.findMany({ where: { userId: user.id, postId: { in: postIds } }, select: { postId: true } })).map((l) => l.postId))
      : new Set<string>(),
    // Users who follow the current user — for the "Follow Back" state
    // on the PostCard's FollowButton.
    db.follow.findMany({ where: { followingId: user.id }, select: { followerId: true } }),
    // Batch-compute shareCount per post in a single groupBy query
    // (no N+1 — same pattern as articles). Only type="SHARE" events
    // count toward the public shareCount; LINK_COPY events are tracked
    // separately for analytics but not displayed.
    postIds.length > 0
      ? db.postInteraction.groupBy({
          by: ["postId"],
          where: { postId: { in: postIds }, type: "SHARE" },
          _count: { _all: true },
        })
      : Promise.resolve([] as { postId: string; _count: { _all: number } }[]),
  ]);
  const followerIdsSet = new Set(followersOfMe.map((f) => f.followerId));
  const shareMap = new Map(shareRows.map((s) => [s.postId, s._count._all]));

  // Phase 2.1 — Topics: batch-fetch topic IDs for all ranked posts (1 query).
  const homePostTopicMap = await batchGetContentTopicIds(
    "post",
    orderedWinners.map((p) => p.id)
  );

  const posts: PostDTO[] = orderedWinners.map((p) => ({
    ...p,
    likeCount: p._count.likes,
    commentCount: p._count.comments,
    viewCount: p._count.views,
    shareCount: shareMap.get(p.id) ?? 0,
    isLiked: likedPostIds.has(p.id),
    topicIds: homePostTopicMap.get(p.id) ?? [],
    author: {
      ...p.author,
      isFollowing: followedIdsSet.has(p.author.id),
      isFollowedBy: followerIdsSet.has(p.author.id),
    },
  }));

  const nextCursor = hasMore && posts.length > 0
    ? Buffer.from(JSON.stringify({ createdAt: posts[posts.length - 1].createdAt.toISOString(), id: posts[posts.length - 1].id }), "utf-8").toString("base64")
    : null;

  return ok({ posts, nextCursor });
});

/**
 * SELECT projection used by both POST and GET routes.
 *
 * - Excludes passwordHash, email, totpSecret, recoveryCodes, notificationPrefs
 *   and other private fields from the embedded author object.
 * - Includes _count for likes/comments/views — Prisma compiles this into a
 *   single SQL with LEFT JOINs + COUNT(*), no N+1.
 */
const POST_SELECT = {
  id: true,
  content: true,
  createdAt: true,
  updatedAt: true,
  author: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const satisfies Prisma.PostSelect;

/**
 * Lightweight SELECT for the ranking candidate pool. Fetches only the
 * fields needed for scoring (id, authorId, content, createdAt, _count).
 * Author info is fetched separately for the winners only (step 4).
 */
const RANKING_SELECT = {
  id: true,
  authorId: true,
  content: true,
  createdAt: true,
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const satisfies Prisma.PostSelect;

export type RawPostDTO = Prisma.PostGetPayload<{ select: typeof POST_SELECT }>;

/**
 * Public PostDTO — what the client receives. Adds computed fields
 * (likeCount, commentCount, viewCount, isLiked) on top of the raw post.
 * All counts come from the database — never from the client.
 */
export interface PostDTO {
  id: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  author: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
    isFollowing: boolean;
    isFollowedBy: boolean;
  };
  likeCount: number;
  commentCount: number;
  viewCount: number;
  /** Total SHARE interaction count (type='SHARE' only — LINK_COPY not counted). */
  shareCount: number;
  isLiked: boolean;
  /**
   * Phase 2.1 — Topics: the topic IDs assigned to this post.
   * Empty array when the post has no topics. Always present (never undefined).
   */
  topicIds: string[];
}

// Re-exports removed: `export { POST_MAX_LENGTH }`, `export { getCurrentUser }`,
// and `export function withParsedContent` all violated Next.js 16's route
// file signature contract (route files may only export HTTP method handlers
// + a small allowlist of special names). Consumers import these symbols
// directly from their canonical modules:
//   - POST_MAX_LENGTH  → @/lib/posts/parser
//   - getCurrentUser   → @/lib/auth
//   - withParsedContent → was dead code (no caller anywhere in the codebase)
