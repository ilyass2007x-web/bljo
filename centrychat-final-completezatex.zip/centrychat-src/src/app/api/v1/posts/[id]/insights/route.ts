import { apiHandler, ok, notFound } from "@/lib/api";
import { requireUser, ForbiddenError } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * GET /api/v1/posts/:id/insights
 * --------------------------------
 * Returns aggregated analytics for a single post.
 *
 * SECURITY (spec §3, §23, §24):
 *   - The requesting user is resolved from the session (never from the client).
 *   - The post's authorId is compared against the session user's ID.
 *   - Only the post OWNER or an ADMIN/SUPER_ADMIN can access this endpoint.
 *   - A normal user trying another user's post ID gets 403 Forbidden.
 *   - No viewer emails, passwords, or private identifiers are returned.
 *     Only aggregated counts + percentages.
 *
 * METRICS (spec §4):
 *   - uniqueViews: COUNT(*) on PostView (one row per user per post, via @@unique)
 *   - likes: COUNT(*) on PostLike
 *   - comments: COUNT(*) on PostComment
 *   - shares: COUNT(*) on PostInteraction WHERE type = 'SHARE'
 *   - engagementRate: (likes + comments + shares) / uniqueViews * 100
 *   - followerViews: views from users who follow the post's author
 *   - nonFollowerViews: views from users who don't follow the author
 *
 * PRIVACY (spec §13):
 *   No individual viewer identities are exposed. Only aggregated counts.
 *
 * PERFORMANCE (spec §19):
 *   All metrics are computed via batch COUNT queries (no N+1).
 *   Uses the existing indexes on PostView, PostLike, PostComment, PostInteraction.
 */
export const GET = apiHandler(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;

  if (!id || typeof id !== "string") {
    return notFound("Post not found.");
  }

  // Fetch the post to verify ownership.
  const post = await db.post.findUnique({
    where: { id },
    select: {
      id: true,
      authorId: true,
      content: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  if (!post) return notFound("Post not found.");

  // Authorization: only the owner or an admin can view insights.
  const isOwner = post.authorId === user.id;
  const isAdmin = user.role === "ADMIN" || user.role === "SUPER_ADMIN";
  if (!isOwner && !isAdmin) {
    throw new ForbiddenError("You can only view insights for your own posts");
  }

  // ── Run all count queries in parallel (no N+1) ──────────────────
  const [uniqueViews, likes, comments, shares, followerViewRows] = await Promise.all([
    // Unique views — one row per (postId, userId) via @@unique constraint.
    db.postView.count({ where: { postId: id } }),

    // Likes — one row per (postId, userId) via @@unique constraint.
    db.postLike.count({ where: { postId: id } }),

    // Comments.
    db.postComment.count({ where: { postId: id } }),

    // Shares — PostInteraction with type = 'SHARE'.
    db.postInteraction.count({ where: { postId: id, type: "SHARE" } }),

    // Follower vs non-follower views: check which viewers follow the author.
    // This uses a LEFT JOIN via Prisma's relation query — but to avoid N+1,
    // we fetch all view userIds + batch-check the Follow table.
    db.postView.findMany({
      where: { postId: id },
      select: { userId: true },
    }),
  ]);

  // Batch-check follow relationships for all viewers.
  const viewerIds = followerViewRows
    .map((v) => v.userId)
    .filter((id): id is string => !!id);

  let followerCount = 0;
  let nonFollowerCount = 0;

  if (viewerIds.length > 0) {
    const follows = await db.follow.findMany({
      where: {
        followerId: { in: viewerIds },
        followingId: post.authorId,
      },
      select: { followerId: true },
    });
    const followerSet = new Set(follows.map((f) => f.followerId));
    for (const vid of viewerIds) {
      if (followerSet.has(vid)) {
        followerCount++;
      } else {
        nonFollowerCount++;
      }
    }
  }

  // Anonymous views (userId = null) are counted as non-follower.
  const anonViews = followerViewRows.filter((v) => !v.userId).length;
  nonFollowerCount += anonViews;

  // Engagement rate (spec §6).
  const totalEngagement = likes + comments + shares;
  const engagementRate = uniqueViews > 0
    ? Math.round((totalEngagement / uniqueViews) * 1000) / 10 // 1 decimal place
    : 0;

  return ok({
    post: {
      id: post.id,
      content: post.content.slice(0, 200), // preview only
      createdAt: post.createdAt.toISOString(),
    },
    metrics: {
      uniqueViews,
      likes,
      comments,
      shares,
      engagementRate, // percentage, e.g. 12.5
    },
    audience: {
      followerViews: followerCount,
      nonFollowerViews: nonFollowerCount,
      followerPercentage: uniqueViews > 0
        ? Math.round((followerCount / uniqueViews) * 1000) / 10
        : 0,
      nonFollowerPercentage: uniqueViews > 0
        ? Math.round((nonFollowerCount / uniqueViews) * 1000) / 10
        : 0,
    },
    // Traffic sources are NOT available — the PostView.source field exists
    // but is not populated by the client. To enable this, the usePostView
    // hook would need to send the source (home_feed, profile, etc.) in
    // the view request body. This is a future enhancement.
    trafficSources: null,
  });
});
