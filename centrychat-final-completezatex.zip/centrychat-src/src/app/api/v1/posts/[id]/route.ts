import { apiHandler, ok, badRequest, notFound, forbidden } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { validatePostContent, POST_MAX_LENGTH } from "@/lib/posts/parser";
import type { Prisma } from "@prisma/client";
// Content moderation — runs on the EDITED content too (spec §9). A user
// publishing "Hello everyone" then editing to prohibited content is caught
// at the PATCH endpoint, not just at POST.
import { moderateContent, recordModerationEvent } from "@/lib/moderation";
// Phase 2.1 — Topics: validate + sync topic IDs on post update.
import { validateTopicIds, syncContentTopics, getContentTopicIds } from "@/lib/topics";

/**
 * DELETE /api/v1/posts/:id
 * ------------------------
 * Delete a post owned by the current user.
 *
 * Auth: requires an authenticated, verified user.
 * Authorization: only the post's author can delete it. If the requesting
 * user is not the author, returns 404 (we do NOT leak whether the post
 * exists to a non-owner — this avoids information disclosure).
 *
 * Response: { ok: true } on success.
 *
 * Note: This is a hard delete (matches the spec — "يتم حذف/تعطيل Post حسب
 * نظام الحذف الموجود"). The Post model has no soft-delete column today;
 * we delete the row. If soft-delete is needed in the future (e.g. for
 * moderation/audit trails), a `deletedAt` column can be added later
 * without changing this route's contract — just swap `delete` for
 * `update({ data: { deletedAt: new Date() } })` and update the GET
 * query to filter `deletedAt: null`.
 */
export const DELETE = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;

  if (!id || typeof id !== "string" || id.length < 1) {
    return badRequest("Invalid post id.");
  }

  // Fetch the post first to verify ownership. We use select (not include)
  // to keep the query lean — we only need authorId.
  const post = await db.post.findUnique({
    where: { id },
    select: { authorId: true },
  });

  if (!post) {
    // Post doesn't exist (or was already deleted). Return 404 — this is
    // safe whether the requester is the owner or not.
    return notFound("Post not found.");
  }

  if (post.authorId !== user.id) {
    // Not the owner. We return 404 instead of 403 to avoid leaking the
    // existence of the post to non-owners. This matches the security
    // pattern used in the messages delete route.
    return notFound("Post not found.");
  }

  await db.post.delete({ where: { id } });

  return ok({ ok: true });
});

/**
 * PATCH /api/v1/posts/:id
 * -----------------------
 * Edit the content of a post owned by the current user.
 *
 * Auth: requires an authenticated, verified user.
 * Authorization: only the post's author can edit it. Non-owners get 404
 * (no information disclosure).
 *
 * Request body: { content: string }
 *
 * Validation (server-side, source of truth):
 *   - content must be a string
 *   - content after trim + whitespace-normalize must be 1..280 chars
 *   - same validatePostContent() used by POST /api/v1/posts
 *   - character count uses Array.from (code points, not UTF-16 code units)
 *     so emoji = 1 char
 *
 * The authorId is NEVER sent in the request body and cannot be changed
 * via this route — only the content is updated. Prisma's `update` only
 * touches the `content` field, and `updatedAt` auto-updates via
 * `@updatedAt` in the schema.
 *
 * Response: { post: PostDTO } — the updated post with fresh counts.
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;

  if (!id || typeof id !== "string" || id.length < 1) {
    return badRequest("Invalid post id.");
  }

  // Fetch the post first to verify ownership.
  const existing = await db.post.findUnique({
    where: { id },
    select: { authorId: true },
  });

  if (!existing) {
    return notFound("Post not found.");
  }

  if (existing.authorId !== user.id) {
    // Not the owner — return 404 to avoid information disclosure.
    return notFound("Post not found.");
  }

  // Parse + validate the new content.
  const body = await req.json().catch(() => ({} as unknown));
  const content = (body as { content?: unknown })?.content;

  // Phase 2.1 — Topics: validate topic IDs (when provided). Run BEFORE the
  // post update so we can fail fast on invalid topic IDs without persisting
  // a content change the user might want to revert.
  const rawTopicIds = (body as { topicIds?: unknown })?.topicIds;
  let postTopicIds: string[] | undefined;
  if (rawTopicIds !== undefined) {
    const validation = await validateTopicIds(rawTopicIds);
    if (!validation.ok) {
      return badRequest(validation.error);
    }
    postTopicIds = validation.topicIds;
  }

  const result = validatePostContent(content);
  if (!result.ok) {
    return badRequest(result.error);
  }

  // ── Domain Blocklist Check for URLs in edited post content ──────────
  // Same check as POST creation — catches users who publish a clean post
  // then edit it to include a blocked-domain link.
  {
    const { checkTextForBlockedDomains } = await import("@/lib/security/domain-blocklist");
    const blockCheck = await checkTextForBlockedDomains(result.value, user.id, "POST");
    if (blockCheck.blocked) {
      return badRequest("This content contains a link that cannot be used on this platform.");
    }
  }

  // ── Content Moderation on EDITED content (spec §9) ─────────────────
  // Same moderation pipeline as POST — runs server-side before the
  // `db.post.update`. Catches users who publish "Hello everyone" then
  // edit it into prohibited content.
  const moderationResult = await moderateContent({
    text: result.value,
    contentType: "post",
    userId: user.id,
  });
  if (moderationResult.action === "BLOCK") {
    void recordModerationEvent({
      result: moderationResult,
      contentType: "post",
      contentId: id,
      userId: user.id,
      originalText: result.value,
    });
    return badRequest(moderationResult.userMessage);
  }

  // IMPORTANT: only update `content`. The authorId, id, createdAt are
  // untouched — Prisma generates the UPDATE statement with just the
  // content column (plus updatedAt which auto-bumps via @updatedAt).
  // No client-sent field (e.g. authorId) is ever persisted.
  const updated = await db.post.update({
    where: { id },
    data: { content: result.value },
    select: POST_SELECT,
  });

  // ── Record moderation event for WARN/REVIEW on the EDITED content ──
  if (moderationResult.action !== "ALLOW") {
    void recordModerationEvent({
      result: moderationResult,
      contentType: "post",
      contentId: id,
      userId: user.id,
      originalText: result.value,
    });
  }

  // ── Phase 2.1 — Topics: sync topic relationships AFTER post update ──
  // Run only when `topicIds` was provided in the body. Omit the field to
  // leave topics unchanged. Pass [] to clear all topics.
  if (rawTopicIds !== undefined) {
    await syncContentTopics("post", id, postTopicIds ?? []);
  } else {
    // Fetch existing topic IDs for the response (so the editor can hydrate).
    postTopicIds = await getContentTopicIds("post", id);
  }

  // Build the response DTO with fresh counts + isLiked + follow state.
  // Both isFollowing (does the current user follow the author?) AND
  // isFollowedBy (does the author follow the current user? — for the
  // FollowButton's Follow Back state) are checked in parallel.
  const [likeCount, commentCount, viewCount, shareCount, isLikedRow, isFollowingRow, isFollowedByRow] = await Promise.all([
    db.postLike.count({ where: { postId: id } }),
    db.postComment.count({ where: { postId: id } }),
    db.postView.count({ where: { postId: id } }),
    // shareCount: only type="SHARE" interactions count (LINK_COPY tracked separately).
    db.postInteraction.count({ where: { postId: id, type: "SHARE" } }),
    db.postLike.findUnique({
      where: { postId_userId: { postId: id, userId: user.id } },
      select: { id: true },
    }),
    // Does the current user follow the post's author?
    db.follow.findUnique({
      where: {
        followerId_followingId: {
          followerId: user.id,
          followingId: updated.authorId,
        },
      },
      select: { id: true },
    }),
    // Does the post's author follow the current user? (Follow Back state)
    db.follow.findUnique({
      where: {
        followerId_followingId: {
          followerId: updated.authorId,
          followingId: user.id,
        },
      },
      select: { id: true },
    }),
  ]);

  const post: PostDTO = {
    ...updated,
    likeCount,
    commentCount,
    viewCount,
    shareCount,
    isLiked: !!isLikedRow,
    // Phase 2.1 — Topics: include the (possibly updated) topic IDs.
    topicIds: postTopicIds ?? [],
    author: {
      id: updated.author.id,
      fullName: updated.author.fullName,
      username: updated.author.username,
      avatarColor: updated.author.avatarColor,
      avatarUrl: updated.author.avatarUrl,
      isVerified: updated.author.isVerified,
      isFollowing: !!isFollowingRow,
      isFollowedBy: !!isFollowedByRow,
    },
  };

  return ok({ post });
});

// GET /api/v1/posts/:id — fetch a single post by id. Useful for permalinks
// and post-detail views in future phases. For now we keep it minimal.
export const GET = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;

  if (!id || typeof id !== "string" || id.length < 1) {
    return badRequest("Invalid post id.");
  }

  const post = await db.post.findUnique({
    where: { id },
    select: POST_SELECT,
  });

  if (!post) return notFound("Post not found.");

  // Build the response DTO with counts + isLiked + follow state (both directions).
  const [likeCount, commentCount, viewCount, shareCount, isLikedRow, isFollowingRow, isFollowedByRow] = await Promise.all([
    db.postLike.count({ where: { postId: id } }),
    db.postComment.count({ where: { postId: id } }),
    db.postView.count({ where: { postId: id } }),
    // shareCount: only type="SHARE" interactions count (LINK_COPY tracked separately).
    db.postInteraction.count({ where: { postId: id, type: "SHARE" } }),
    db.postLike.findUnique({
      where: { postId_userId: { postId: id, userId: user.id } },
      select: { id: true },
    }),
    // Does the current user follow the post's author?
    db.follow.findUnique({
      where: {
        followerId_followingId: {
          followerId: user.id,
          followingId: post.authorId,
        },
      },
      select: { id: true },
    }),
    // Does the post's author follow the current user? (Follow Back state)
    db.follow.findUnique({
      where: {
        followerId_followingId: {
          followerId: post.authorId,
          followingId: user.id,
        },
      },
      select: { id: true },
    }),
  ]);

  // Phase 2.1 — Topics: fetch the post's topic IDs (1 query).
  const getPostTopicIds = await getContentTopicIds("post", id);

  const postDTO: PostDTO = {
    ...post,
    likeCount,
    commentCount,
    viewCount,
    shareCount,
    isLiked: !!isLikedRow,
    topicIds: getPostTopicIds,
    author: {
      id: post.author.id,
      fullName: post.author.fullName,
      username: post.author.username,
      avatarColor: post.author.avatarColor,
      avatarUrl: post.author.avatarUrl,
      isVerified: post.author.isVerified,
      isFollowing: !!isFollowingRow,
      isFollowedBy: !!isFollowedByRow,
    },
  };

  return ok({ post: postDTO });
});

/**
 * SELECT projection used by PATCH and GET. Matches the projection used
 * by GET /api/v1/posts (the list endpoint) so the response shape is
 * consistent across all routes that return a single post.
 *
 * Includes `authorId` at the TOP LEVEL (not just inside `author.id`)
 * because the GET + PATCH routes need it to query the follow table:
 * `db.follow.findUnique({ where: { followerId_followingId: { ...,
 * followingId: post.authorId } } })`. Without `authorId` in the SELECT,
 * `post.authorId` is `undefined`, and Prisma throws when querying with
 * `followingId: undefined` — resulting in a 500 "Something went wrong"
 * error. This was the ROOT CAUSE of the comments page crash: the
 * comments page fetches the post via GET /api/v1/posts/:id to show a
 * preview, but the 500 error prevented the entire fetch from completing.
 *
 * Includes _count for likes/comments/views — Prisma compiles this into a
 * single SQL with LEFT JOINs + COUNT(*), no N+1.
 */
const POST_SELECT = {
  id: true,
  authorId: true,
  content: true,
  createdAt: true,
  updatedAt: true,
  author: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const satisfies Prisma.PostSelect;

export type RawPostDTO = Prisma.PostGetPayload<{ select: typeof POST_SELECT }>;

export interface PostDTO {
  id: string;
  content: string;
  createdAt: Date;
  updatedAt: Date;
  author: {
    id: string;
    fullName: string;
    username: string;
    avatarColor: string | null;
    avatarUrl: string | null;
    isVerified: boolean;
    isFollowing: boolean;
    isFollowedBy: boolean;
  };
  likeCount: number;
  commentCount: number;
  viewCount: number;
  /** Total SHARE interaction count (type='SHARE' only — LINK_COPY not counted). */
  shareCount: number;
  isLiked: boolean;
  /**
   * Phase 2.1 — Topics: the topic IDs assigned to this post.
   * Empty array when the post has no topics. Always present (never undefined).
   */
  topicIds: string[];
}

// Re-export removed: `export { POST_MAX_LENGTH }` violated Next.js 16's route
// file signature contract (only HTTP method exports are allowed). Consumers
// import `POST_MAX_LENGTH` directly from `@/lib/posts/parser` — this
// re-export was unused dead code.
