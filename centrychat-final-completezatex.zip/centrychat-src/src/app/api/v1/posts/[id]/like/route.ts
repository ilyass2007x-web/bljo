import { apiHandler, ok, notFound, rateLimited} from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { Prisma } from "@prisma/client";
import { notifyPostLiked } from "@/lib/notifications";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";

/**
 * POST /api/v1/posts/:id/like
 * ---------------------------
 * Toggle like on a post. Atomically adds OR removes the like in a single
 * Prisma transaction.
 *
 * Auth: requires authenticated + verified user.
 *
 * Behavior:
 *   - If the user has NOT liked the post → CREATE the like. The unique
 *     constraint `@@unique([postId, userId])` is the source of truth —
 *     if two concurrent requests try to create the same like, only one
 *     succeeds (the other gets P2002 unique violation, which we swallow).
 *   - If the user HAS liked the post → DELETE the like.
 *
 * Phase 9 — notification integration:
 *   - After a successful LIKE creation (not unlike), we create a LIKE
 *     notification for the post's author.
 *   - Self-action exclusion: if the user likes their OWN post, no
 *     notification is created (enforced in notifyPostLiked).
 *   - Dedup: the unique constraint guarantees only ONE like per (user, post),
 *     so notifyPostLiked can only fire once per like. Unlike does NOT
 *     create a notification (spec §4).
 *   - Failure handling: if the notification creation fails, the like itself
 *     still succeeded — the error is swallowed and logged (best-effort).
 *
 * CentryChat — Interest Learning (spec §6):
 *   - After a successful LIKE creation, we fire-and-forget a trackInteraction
 *     call to update the user's interest profile. The `topicSlug` is NOT
 *     known here (posts don't have explicit topic tags yet) — the engine
 *     records the raw interaction but doesn't update the interest score.
 *     When posts get explicit topics, the PostComposer should pass the
 *     selected topicSlug here.
 *   - On UNLIKE, we don't reverse the interest delta (spec §7 — "don't
 *     punish the user harshly for one interaction"). The original like
 *     still counts as a positive signal; unliking is treated as a neutral
 *     event (not a negative one).
 *
 * Race condition handling:
 *   We use a transaction with `deleteMany` first, then check the result count.
 *   If deleteMany removed 1 row → was liked, now unliked. Return { liked: false }.
 *   If deleteMany removed 0 rows → was NOT liked, create the like. Return { liked: true }.
 *   If the create fails with P2002 (unique violation) → another concurrent
 *   request just created it; we treat that as "liked: true" and DO NOT fire
 *   the notification (the winning request already did).
 *
 * The count returned is ALWAYS from the database — we re-query after the
 * mutation so the response is accurate even under high concurrency.
 *
 * Response: { liked: boolean, likeCount: number }
 */
export const POST = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  const rl = await checkRateLimit(`like:${user.id}`, RATE_LIMITS.like);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  if (!id || typeof id !== "string") {
    return notFound("Post not found.");
  }

  // Fetch the post WITH its authorId so we can send a notification.
  // We also grab the actor's profile info here to avoid a second query later.
  const post = await db.post.findUnique({
    where: { id },
    select: { id: true, authorId: true },
  });
  if (!post) return notFound("Post not found.");

  // Track whether THIS request actually created the like (vs. just found
  // it already existed). Only the request that creates the like should fire
  // the notification — otherwise a concurrent double-tap could fire two
  // notifications for the same like.
  let didCreateLike = false;

  // Atomic toggle in a transaction. deleteMany returns { count: number } —
  // if count=1, we unliked; if count=0, we need to create.
  const result = await db.$transaction(async (tx) => {
    const deleteResult = await tx.postLike.deleteMany({
      where: { postId: id, userId: user.id },
    });

    if (deleteResult.count > 0) {
      // Was liked, now unliked.
      return { liked: false };
    }

    // Was not liked — try to create. If a concurrent request created it
    // between our deleteMany and create, we get P2002 and swallow it.
    try {
      await tx.postLike.create({
        data: { postId: id, userId: user.id },
      });
      didCreateLike = true;
      return { liked: true };
    } catch (err) {
      if (
        err instanceof Prisma.PrismaClientKnownRequestError &&
        err.code === "P2002"
      ) {
        // Already liked by a concurrent request — treat as liked, but DON'T
        // fire the notification (the winning request already did).
        return { liked: true };
      }
      throw err;
    }
  });

  // Fire the LIKE notification — ONLY if this request actually created the
  // like (not if it was a concurrent duplicate, and not if it was an unlike).
  // notifyPostLiked handles self-action exclusion internally.
  if (didCreateLike) {
    // Don't await — fire-and-forget so the API response isn't delayed by
    // notification creation. The notification is best-effort.
    void notifyPostLiked({
      postId: id,
      postAuthorId: post.authorId,
      actorId: user.id,
      actorFullName: user.fullName,
      actorUsername: user.username,
      actorIsVerified: user.isVerified,
    });

    // ── CentryChat Interest Learning (spec §6) ────────────────────────
    // Fire-and-forget a trackInteraction call. The action "like" has a
    // positive delta (admin-configured, default +0.10) that increases the
    // user's interest score for the post's topic (when known).
    //
    // topicSlug is NOT passed here because posts don't have explicit topic
    // tags yet. The engine still records the raw interaction for analytics
    // — when posts get topics, the PostComposer should pass the selected
    // topicSlug via the request body + this endpoint should forward it.
    void getRecommendationEngine().trackInteraction({
      userId: user.id,
      contentType: "post",
      contentId: id,
      action: "like",
    });
  }

  // Re-fetch the accurate like count from the database. This is the value
  // the client should display — never trust a client-sent count.
  const likeCount = await db.postLike.count({ where: { postId: id } });

  return ok({ liked: result.liked, likeCount });
});
