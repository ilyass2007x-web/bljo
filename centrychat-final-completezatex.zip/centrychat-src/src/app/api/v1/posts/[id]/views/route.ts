import { apiHandler, ok, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { Prisma } from "@prisma/client";

/**
 * POST /api/v1/posts/:id/views
 * -----------------------------
 * Record a UNIQUE post view. One authenticated user = ONE view per post.
 *
 * UNIQUE VIEW TRACKING (spec PHASE-10Y):
 *   Uses `upsert` (INSERT ... ON CONFLICT DO NOTHING/UPDATE) which is
 *   atomic at the DB level. The @@unique([postId, userId]) constraint
 *   on PostView is the source of truth. If the same user sends 1000
 *   requests, only ONE row exists — the rest are no-ops.
 *
 *   This handles ALL the dedup scenarios from the spec:
 *     - Refresh: same user, same post → upsert no-ops
 *     - Reopen: same user, same post → upsert no-ops
 *     - Re-request: same user, same post → upsert no-ops
 *     - Concurrent requests: DB unique constraint + ON CONFLICT → only
 *       one row survives, the other is a no-op
 *
 * Owner self-view exclusion (spec §2):
 *   If the viewer is the post's author, we SKIP the insert entirely.
 *   The author's own views never count. Enforced SERVER-SIDE.
 *
 * Response: { ok: true, viewCount: number }
 *   viewCount = unique viewer count (one row per user per post).
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;

  if (!id || typeof id !== "string") {
    return notFound("Post not found.");
  }

  const post = await db.post.findUnique({
    where: { id },
    select: { id: true, authorId: true },
  });
  if (!post) return notFound("Post not found.");

  // Owner self-view exclusion — enforced server-side.
  if (post.authorId === user.id) {
    const currentCount = await db.postView.count({ where: { postId: id } });
    return ok({ ok: true, viewCount: currentCount, skipped: true });
  }

  // Parse optional future-use fields.
  let body: { duration?: unknown; completed?: unknown; source?: unknown } = {};
  try { body = await req.json(); } catch { /* empty body */ }

  const duration =
    typeof body.duration === "number" && Number.isFinite(body.duration) && body.duration >= 0 && body.duration <= 3600
      ? Math.floor(body.duration) : null;
  const completed = typeof body.completed === "boolean" ? body.completed : null;
  const source = typeof body.source === "string" && body.source.length <= 32 ? body.source : null;

  // UPSERT — atomic + idempotent. The @@unique([postId, userId]) constraint
  // ensures only ONE row per (post, user). If the row already exists (user
  // viewed this post before), the UPDATE branch runs (updates viewedAt +
  // optional fields). If it doesn't exist, the CREATE branch runs.
  // Either way, the view count stays the same (one row per user).
  await db.postView.upsert({
    where: { postId_userId: { postId: id, userId: user.id } },
    create: {
      postId: id,
      userId: user.id,
      duration,
      completed,
      source,
    },
    update: {
      // On re-view, update the timestamp + optional fields.
      // This does NOT create a new row — it updates the existing one.
      viewedAt: new Date(),
      ...(duration !== null && { duration }),
      ...(completed !== null && { completed }),
      ...(source !== null && { source }),
    },
  }).catch((err: unknown) => {
    // P2002 = unique constraint violation. This happens if two concurrent
    // requests race past the upsert. In that case, the other request won
    // — our request is a no-op. This is the correct behavior.
    if (!(err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002")) {
      throw err;
    }
  });

  // Return the unique viewer count (one row per user per post).
  const viewCount = await db.postView.count({ where: { postId: id } });
  return ok({ ok: true, viewCount });
});
