import { apiHandler, ok, badRequest, notFound, rateLimited} from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireVerifiedUser, getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { validateCommentContent, parsePostContent } from "@/lib/posts/parser";
import { notifyPostCommented, notifyCommentReplied, notifyCommentLiked, notifyMentioned } from "@/lib/notifications";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";
// Content moderation — runs server-side BEFORE the DB insert on every
// comment AND reply. Comments and replies are evaluated independently
// (spec §10 — never assume that because the parent post is safe, comments
// are safe). Uses the unified pipeline which also checks URLs.
import { runModerationPipeline, recordPipelineResult } from "@/lib/moderation/pipeline";
import { moderateContent, recordModerationEvent } from "@/lib/moderation";
import { Prisma } from "@prisma/client";

/**
 * GET /api/v1/posts/:id/comments
 * -------------------------------
 * Phase 3 — Deep Discussions: fetch ALL comments flat (1 query), build the
 * discussion tree in code (supports multi-level nesting), paginate on
 * top-level comments. Supports sorting: top / newest / oldest.
 *
 * Response: { comments: CommentDTO[], nextCursor: string|null, commentCount: number }
 */
export const GET = apiHandler(async (req, ctx) => {
  await requireVerifiedUser();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Post not found.");

  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "20"), 1), 50);
  const cursorParam = url.searchParams.get("cursor");
  const sortParam = url.searchParams.get("sort") ?? "newest";
  const sort = (["top", "newest", "oldest"].includes(sortParam) ? sortParam : "newest") as "top" | "newest" | "oldest";

  let seek: { createdAt: Date; id: string } | null = null;
  if (cursorParam) {
    try {
      const decoded = JSON.parse(Buffer.from(cursorParam, "base64").toString("utf-8")) as { createdAt?: string; id?: string };
      if (decoded.createdAt && decoded.id) seek = { createdAt: new Date(decoded.createdAt), id: decoded.id };
    } catch { return badRequest("Invalid cursor."); }
  }

  const viewer = await getCurrentUser();

  // Phase 3 — fetch ALL comments for this post FLAT (1 query, no nesting).
  // Cap at 2000 for practical performance. For posts with >2000 comments,
  // only the most recent 2000 are loaded (ordered by createdAt DESC).
  // The tree is built in code — no recursive DB queries.
  //
  // Moderation gate: PENDING_MODERATION and REJECTED comments are hidden
  // from everyone EXCEPT the comment's author. The author sees their own
  // pending comments so they know the comment was received (not silently
  // dropped). We use an OR condition: (moderationStatus = APPROVED) OR
  // (authorId = viewer.id).
  const MAX_COMMENTS_FLAT = 2000;
  const commentWhere = viewer
    ? {
        postId: id,
        OR: [
          { moderationStatus: "APPROVED" },
          { authorId: viewer.id },
        ],
      }
    : {
        postId: id,
        moderationStatus: "APPROVED" as const,
      };
  const allComments = await db.postComment.findMany({
    where: commentWhere,
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: MAX_COMMENTS_FLAT,
    select: FLAT_COMMENT_SELECT,
  });

  // Batch-fetch isLiked for ALL comments (1 query).
  const allCommentIds = new Set(allComments.map((c) => c.id));
  const likedIds = viewer
    ? new Set((await db.postCommentLike.findMany({
        where: { userId: viewer.id, commentId: { in: [...allCommentIds] } },
        select: { commentId: true },
      })).map((l) => l.commentId))
    : new Set<string>();

  // Build a lookup map: commentId → comment (with isLiked + replyCount).
  const commentMap = new Map<string, any>();
  for (const c of allComments) {
    commentMap.set(c.id, {
      ...c,
      isLiked: likedIds.has(c.id),
      likeCount: c._count.likes,
      replies: [] as any[],
    });
  }

  // Build the tree: group children by parentCommentId.
  const topLevel: any[] = [];
  for (const c of allComments) {
    if (c.parentCommentId === null) {
      topLevel.push(commentMap.get(c.id));
    } else {
      const parent = commentMap.get(c.parentCommentId);
      if (parent) {
        parent.replies.push(commentMap.get(c.id));
      }
      // If parent not found (deleted or beyond the 2000 cap), the comment
      // is orphaned — it won't appear in the tree. This is acceptable.
    }
  }

  // Phase 3.2 fix — Recursively normalize every parent's `replies` array
  // to (createdAt ASC, id ASC). Required because: the flat fetch is DESC
  // + tree-building pushes replies in DESC order, BUT the client appends
  // new replies with `[...c.replies, newReply]` (expecting oldest-first).
  // Without this normalization, a new reply visually lands BELOW older
  // replies for one render, then jumps to the TOP on next refresh.
  //
  // This sorts ONLY the inner `replies` arrays — it does NOT touch the
  // top-level array. Top-level sorting is handled by the existing
  // topLevel.sort(...) calls below (which only re-order the outermost
  // array, not inner replies).
  sortRepliesAsc(topLevel);

  // Sort top-level comments based on the `sort` param.
  if (sort === "top") {
    // "Top" = most engagement (likeCount + replyCount) DESC, then createdAt DESC.
    topLevel.sort((a, b) => {
      const aScore = (a.likeCount ?? 0) + (a.replies?.length ?? 0);
      const bScore = (b.likeCount ?? 0) + (b.replies?.length ?? 0);
      if (bScore !== aScore) return bScore - aScore;
      return b.createdAt.getTime() - a.createdAt.getTime();
    });
  } else if (sort === "oldest") {
    topLevel.sort((a, b) => {
      const diff = a.createdAt.getTime() - b.createdAt.getTime();
      if (diff !== 0) return diff;
      return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
    });
  } else {
    // "newest" — already sorted by createdAt DESC from the query, but
    // re-sort to be safe (the flat query returns ALL comments DESC, but
    // top-level might not be in the right order after tree-building).
    topLevel.sort((a, b) => {
      const diff = b.createdAt.getTime() - a.createdAt.getTime();
      if (diff !== 0) return diff;
      return b.id < a.id ? -1 : b.id > a.id ? 1 : 0;
    });
  }

  // Apply cursor pagination on top-level comments.
  let paginatedTopLevel = topLevel;
  if (seek) {
    // Find the index of the cursor comment + take everything after it.
    const cursorIdx = topLevel.findIndex(
      (c) => c.createdAt.getTime() === seek!.createdAt.getTime() && c.id === seek!.id
    );
    if (cursorIdx >= 0) {
      paginatedTopLevel = topLevel.slice(cursorIdx + 1);
    }
  }

  const hasMore = paginatedTopLevel.length > limit;
  const page = hasMore ? paginatedTopLevel.slice(0, limit) : paginatedTopLevel;

  const nextCursor = hasMore && page.length > 0
    ? Buffer.from(JSON.stringify({
        createdAt: page[page.length - 1]!.createdAt instanceof Date
          ? (page[page.length - 1]!.createdAt as Date).toISOString()
          : page[page.length - 1]!.createdAt,
        id: page[page.length - 1]!.id,
      }), "utf-8").toString("base64")
    : null;

  // Serialize dates for the response.
  const serialized = page.map((c) => serializeComment(c));

  const commentCount = allComments.length;

  return ok({ comments: serialized, nextCursor, commentCount });
});

/**
 * Phase 3.2 fix — Recursively sort every parent's `replies` array by
 * (createdAt ASC, id ASC). Mutates the tree in place. Required to match
 * the client's optimistic-append pattern (`[...c.replies, newReply]`)
 * which assumes existing replies are oldest-first.
 *
 * Recurses to arbitrary depth. Does NOT sort the input array itself —
 * only the inner `replies` arrays of each node (the top-level array
 * is sorted separately by the topLevel.sort(...) calls below).
 */
function sortRepliesAsc(comments: any[]) {
  for (const c of comments) {
    if (c.replies && c.replies.length > 0) {
      c.replies.sort((a: any, b: any) => {
        const diff = a.createdAt.getTime() - b.createdAt.getTime();
        if (diff !== 0) return diff;
        return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
      });
      sortRepliesAsc(c.replies);
    }
  }
}

/**
 * Recursively serialize a comment tree: convert Date fields to ISO strings.
 */
function serializeComment(c: any): any {
  return {
    ...c,
    createdAt: c.createdAt instanceof Date ? c.createdAt.toISOString() : c.createdAt,
    updatedAt: c.updatedAt instanceof Date ? c.updatedAt.toISOString() : c.updatedAt,
    replies: (c.replies ?? []).map((r: any) => serializeComment(r)),
  };
}

/**
 * POST /api/v1/posts/:id/comments
 * Create a comment or reply on a post.
 *
 * Phase 3 — Deep Discussions: multi-level replies are now allowed.
 * The old "one-level only" restriction is removed. Any comment can be
 * a parent — the DB self-relation already supports arbitrary depth.
 *
 * Phase 3 — Mentions: @username mentions are parsed from the comment
 * content, and mentioned users receive a MENTION notification.
 *
 * Body: { content: string, parentCommentId?: string }
 * - parentCommentId = null/absent → top-level comment.
 * - parentCommentId = <id> → reply to that comment (any depth).
 */
export const POST = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Post not found.");
  const rl = await checkRateLimit(`comment:${user.id}`, RATE_LIMITS.comment);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const post = await db.post.findUnique({ where: { id }, select: { id: true, authorId: true } });
  if (!post) return notFound("Post not found.");

  const body = await req.json().catch(() => ({} as unknown));
  const content = (body as { content?: unknown })?.content;
  const parentCommentId = (body as { parentCommentId?: unknown })?.parentCommentId;

  const result = validateCommentContent(content);
  if (!result.ok) return badRequest(result.error);

  // ── Domain Blocklist Check for URLs in comment/reply content ────────
  // HARD REJECT — blocked domains never enter the database. The context
  // is "REPLY" when this is a reply (parentCommentId set), "COMMENT" otherwise.
  {
    const { checkTextForBlockedDomains } = await import("@/lib/security/domain-blocklist");
    const ctx = typeof parentCommentId === "string" && parentCommentId.trim() ? "REPLY" : "COMMENT";
    const blockCheck = await checkTextForBlockedDomains(result.value, user.id, ctx);
    if (blockCheck.blocked) {
      return badRequest("This content contains a link that cannot be used on this platform.");
    }
  }

  // Phase 3 — validate parent comment exists on this post.
  // REMOVED: the "one-level only" restriction (parentComment.parentCommentId !== null).
  // Multi-level replies are now allowed. The DB self-relation supports it.
  let parentComment: { id: string; authorId: string; postId: string } | null = null;
  if (typeof parentCommentId === "string" && parentCommentId.trim()) {
    parentComment = await db.postComment.findUnique({
      where: { id: parentCommentId.trim() },
      select: { id: true, authorId: true, postId: true },
    });
    if (!parentComment || parentComment.postId !== id) {
      return badRequest("Parent comment not found on this post.");
    }
  }

  // ── Content Moderation Pipeline ────────────────────────────────────
  // Same contentType ("post_comment") for top-level comments AND replies
  // — both live in the same PostComment table; replies just have
  // parentCommentId !== null. The pipeline checks text + URLs.
  const moderationResult = await runModerationPipeline({
    text: result.value,
    contentType: "post_comment",
    userId: user.id,
  });
  if (!moderationResult.allowed) {
    void recordPipelineResult({
      result: moderationResult,
      contentType: "post_comment",
      contentId: null,
      userId: user.id,
      originalText: result.value,
    });
    return badRequest(moderationResult.userMessage);
  }

  const comment = await db.postComment.create({
    data: {
      postId: id,
      authorId: user.id,
      content: result.value,
      parentCommentId: parentComment ? parentComment.id : null,
      // Moderation gate: PENDING_MODERATION comments are hidden from public
      // view until admin approves. The author sees their own comment.
      moderationStatus: moderationResult.moderationStatus,
    },
    select: FLAT_COMMENT_SELECT,
  });

  // Record the pipeline result for PENDING_MODERATION or flagged content.
  if (moderationResult.moderationStatus === "PENDING_MODERATION" || moderationResult.score > 0) {
    void recordPipelineResult({
      result: moderationResult,
      contentType: "post_comment",
      contentId: comment.id,
      userId: user.id,
      originalText: result.value,
    });
  }

  // Notification logic.
  if (parentComment) {
    // Reply → notify the parent comment's author (if not self).
    if (parentComment.authorId !== user.id) {
      void notifyCommentReplied({
        contentType: "post",
        contentId: id,
        contentAuthorId: post.authorId,
        parentCommentId: parentComment.id,
        parentCommentAuthorId: parentComment.authorId,
        replyId: comment.id,
        replyAuthorId: user.id,
        actorFullName: user.fullName,
        actorUsername: user.username,
        actorIsVerified: user.isVerified,
        replyPreview: result.value.slice(0, 100),
      });
    }
  } else {
    // Top-level comment → notify the post's author (existing behavior).
    void notifyPostCommented({
      postId: id,
      postAuthorId: post.authorId,
      commentId: comment.id,
      actorId: user.id,
      actorFullName: user.fullName,
      actorUsername: user.username,
      actorIsVerified: user.isVerified,
      commentPreview: result.value.slice(0, 100),
    });
  }

  // Phase 3 — Parse @mentions from the comment content + create mention notifications.
  // Reuses the existing parsePostContent helper (extracts @mentions via regex).
  // Mentioned users are looked up by username (server-side) and notified.
  const parsed = parsePostContent(result.value);
  if (parsed.mentions.length > 0) {
    // Batch-lookup mentioned users by username (1 query).
    const mentionedUsernames = parsed.mentions.map((m) => m.username);
    const mentionedUsers = await db.user.findMany({
      where: {
        username: { in: mentionedUsernames.map((u) => u.toLowerCase()) },
        status: "ACTIVE",
      },
      select: { id: true, username: true },
    }).catch(() => []);

    // Create mention notifications (fire-and-forget, non-blocking).
    for (const mentionedUser of mentionedUsers) {
      void notifyMentioned({
        mentionedUserId: mentionedUser.id,
        actorId: user.id,
        contentType: "post",
        contentId: id,
        commentId: comment.id,
        actorName: user.fullName,
      });
    }
  }

  // Fire-and-forget: track the "comment" interaction for the recommendation
  // engine. This updates the user's interest profile — commenting is a
  // strong positive signal (weight = 0.15 by default).
  void getRecommendationEngine().trackInteraction({
    userId: user.id,
    contentType: "post",
    contentId: id,
    action: "comment",
  });

  return ok({
    comment: {
      ...comment,
      isLiked: false,
      likeCount: 0,
      replies: [],
    },
  });
});

/**
 * Phase 3 — Flat comment SELECT (no nested replies in the query).
 * The tree is built in code from the flat results. This avoids recursive
 * Prisma relation queries and allows multi-level nesting without schema
 * changes.
 */
const FLAT_COMMENT_SELECT = {
  id: true,
  postId: true,
  content: true,
  parentCommentId: true,
  createdAt: true,
  updatedAt: true,
  author: {
    select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true },
  },
  _count: { select: { likes: true } },
} as const satisfies Prisma.PostCommentSelect;

export type CommentDTO = Prisma.PostCommentGetPayload<{ select: typeof FLAT_COMMENT_SELECT }>;
