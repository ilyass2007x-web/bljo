import { apiHandler, ok, notFound, badRequest, rateLimited} from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";

/**
 * POST /api/v1/posts/:id/share
 * -----------------------------
 * Record a SHARE or LINK_COPY interaction event.
 *
 * Auth: requires an authenticated user (pending-verification users can
 * still share — the share action itself is not gated by verification).
 *
 * Request body:
 *   { type: "SHARE" | "LINK_COPY", metadata?: Record<string, unknown> }
 *
 * Response: { shared: true, shareCount: number }
 *   Mirrors the article share endpoint's response shape. shareCount is
 *   the SERVER-AUTHORITATIVE count of SHARE interactions on this post
 *   (LINK_COPY events are NOT counted toward the public shareCount —
 *   only explicit shares). The client uses this to reconcile its
 *   optimistic UI update.
 *
 * Design notes:
 *   - Opening the share dialog does NOT count as a share — only an
 *     explicit click on "Share" (via native Web Share API success) or
 *     "Copy link" (successful clipboard write) records an event.
 *   - SHARE and LINK_COPY are stored as separate PostInteraction rows so
 *     the analytics phase can distinguish them.
 *   - LIKE and COMMENT are NOT logged here — they live in their own
 *     dedicated tables (PostLike, PostComment) to avoid double-counting.
 *   - Duplicate-prevention: each successful share/copy call records ONE
 *     row. The client disables the share button while a request is
 *     in-flight (see PostActions `shareLoading` flag), preventing
 *     double-submits from rapid clicks. There is intentionally NO
 *     unique-constraint dedup at the DB level for shares (unlike likes)
 *     because a user legitimately CAN share the same post multiple times
 *     (share to Twitter, then share to Facebook, then copy link). The
 *     shareCount reflects TOTAL share events, not unique sharers.
 */
const VALID_TYPES = new Set(["SHARE", "LINK_COPY"]);

export const POST = apiHandler(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const rl = await checkRateLimit(`share:${user.id}`, RATE_LIMITS.share);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  if (!id || typeof id !== "string") {
    return notFound("Post not found.");
  }

  // Verify the post exists.
  const post = await db.post.findUnique({
    where: { id },
    select: { id: true },
  });
  if (!post) return notFound("Post not found.");

  const body = await req.json().catch(() => ({} as unknown));
  const type = (body as { type?: unknown })?.type;
  const metadata = (body as { metadata?: unknown })?.metadata;

  if (typeof type !== "string" || !VALID_TYPES.has(type)) {
    return badRequest(`Invalid share type. Expected one of: ${[...VALID_TYPES].join(", ")}`);
  }

  // Sanitize metadata — only allow plain object with string/number/boolean
  // values, max 1KB serialized. Never store secrets or PII here.
  let metadataJson: string | null = null;
  if (metadata !== undefined && metadata !== null) {
    if (typeof metadata !== "object" || Array.isArray(metadata)) {
      return badRequest("metadata must be a plain object.");
    }
    try {
      const serialized = JSON.stringify(metadata);
      if (serialized.length > 1024) {
        return badRequest("metadata too large (max 1KB).");
      }
      // Reject if it contains anything other than primitives or shallow objects.
      // (Loose check — we just want to prevent accidental nested blobs.)
      metadataJson = serialized;
    } catch {
      return badRequest("metadata is not serializable.");
    }
  }

  await db.postInteraction.create({
    data: {
      postId: id,
      userId: user.id, // from session, never from request body
      type,
      metadata: metadataJson,
    },
  });

  // Re-fetch the accurate SHARE count from the database. Only type="SHARE"
  // events count toward the public shareCount — LINK_COPY events are
  // tracked separately for analytics but not displayed publicly.
  const shareCount = await db.postInteraction.count({
    where: { postId: id, type: "SHARE" },
  });

  // Fire-and-forget: track the "share" interaction for the recommendation
  // engine. Sharing is a strong positive signal (weight = 0.20 by default).
  // Only track actual SHARE events (not LINK_COPY — that's a weaker signal
  // we don't want to double-count).
  if (type === "SHARE") {
    void getRecommendationEngine().trackInteraction({
      userId: user.id,
      contentType: "post",
      contentId: id,
      action: "share",
    });
  }

  return ok({ shared: true, shareCount });
});
