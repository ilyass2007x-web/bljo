import { apiHandler, badRequest, ok, parseJsonBody } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";

/**
 * POST /api/v1/not-interested
 * Mark content as "not interested" — reduces similar recommendations.
 */
export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  const body = await parseJsonBody<{
    contentType?: string;
    contentId?: string;
    topicSlug?: string;
  }>(req);

  if (!body.contentType || !body.contentId) {
    return badRequest("contentType and contentId are required");
  }

  const engine = getRecommendationEngine();
  await engine.markNotInterested({
    userId: user.id,
    contentType: body.contentType,
    contentId: body.contentId,
    topicSlug: body.topicSlug,
  });

  return ok({ marked: true });
});
