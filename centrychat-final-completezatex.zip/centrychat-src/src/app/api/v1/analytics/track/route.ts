import { NextResponse } from "next/server";
import { apiHandler, rateLimited } from "@/lib/api";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { getClientIp } from "@/lib/security/rate-limit";
import {
  VISITOR_COOKIE_NAME,
  generateVisitorToken,
  setVisitorCookieOnResponse,
} from "@/lib/security/visitor-cookie";
import { buildTrackContext } from "@/lib/analytics/context";
import { trackEvent } from "@/lib/analytics/track";

/**
 * POST /api/v1/analytics/track
 * ------------------------------
 * Public analytics tracking endpoint. Records a single analytics event
 * (page_view, article_view, etc.) fire-and-forget.
 *
 * NO authentication required — anonymous visitors are tracked too (this is
 * the whole point of traffic analytics). Rate-limited by IP to prevent
 * event-spam flooding.
 *
 * REQUEST BODY (JSON):
 *   {
 *     eventType: "page_view" | "article_view" | "article_open" | ...,
 *     path: "/articles/abc123",
 *     articleId?: "abc123",        // required for article_view / article_open
 *     referrer?: "https://google.com/search?q=...",
 *     utm?: {
 *       source?: "tiktok",
 *       medium?: "social",
 *       campaign?: "launch"
 *     }
 *   }
 *
 * RESPONSE:
 *   - 204 No Content (always — even on validation failure, to avoid leaking
 *     which events were accepted vs. rejected).
 *   - Sets the visitor cookie (cc_visitor) when missing — so subsequent
 *     requests from the same browser carry it for session identification.
 *
 * PERFORMANCE (spec §19, §31):
 *   - The endpoint responds 204 IMMEDIATELY — the DB write happens in the
 *     background via queueMicrotask (inside trackEvent). The visitor's page
 *     load is never delayed by analytics.
 *   - Rate-limited to 120 events/min per IP (generous enough for normal
 *     browsing, tight enough to prevent flooding).
 *
 * SECURITY (spec §35):
 *   - All inputs validated + sanitized inside trackEvent (path, referrer,
 *     UTM fields, eventType).
 *   - articleId is validated to exist + be PUBLISHED before recording an
 *     article_view event (prevents fabrication).
 *   - The visitor cookie is generated server-side (crypto.randomUUID) —
 *     the client cannot influence its value.
 *   - Rate-limited by IP.
 *   - No sensitive data is logged (no passwords, tokens, message content).
 *
 * FAILURE HANDLING (spec §30):
 *   - Analytics tracking failure must NEVER break the site. This endpoint
 *     always returns 204 — even if the DB is down, the visitor's page
 *     load proceeds normally.
 *   - Errors are logged at warn level (so admins see them in logs) but
 *     never propagated to the client.
 */
export const POST = apiHandler(async (req) => {
  // ── Rate limit ──
  const ip = getClientIp(req);
  const rl = await checkRateLimit(`analytics:${ip}`, RATE_LIMITS.analyticsTrack);
  if (!rl.ok) {
    // Return 429 — but DON'T set the visitor cookie on rate-limited responses
    // (we don't want to track the rate-limited request itself).
    return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));
  }

  // ── Parse body (defensive — never trust the client) ──
  let body: {
    eventType?: unknown;
    path?: unknown;
    articleId?: unknown;
    referrer?: unknown;
    utm?: unknown;
  } = {};
  try {
    const text = await req.text();
    if (text) {
      body = JSON.parse(text);
    }
  } catch {
    // Invalid JSON — silently drop. Return 204 (don't leak that we rejected).
    return new NextResponse(null, { status: 204 });
  }

  // ── Build the tracking context (anonymousId, userId, headers, ip) ──
  // This calls getCurrentUser() (non-blocking on failure) + reads the
  // visitor cookie. NEVER throws.
  const ctx = await buildTrackContext(req);

  // ── Fire the event (non-blocking) ──
  // trackEvent validates all inputs + schedules the DB write via
  // queueMicrotask. The write happens AFTER this function returns.
  trackEvent(ctx, {
    eventType: typeof body.eventType === "string" ? body.eventType : "",
    path: typeof body.path === "string" ? body.path : "",
    articleId: typeof body.articleId === "string" ? body.articleId : null,
    referrer: typeof body.referrer === "string" ? body.referrer : null,
    utm:
      body.utm && typeof body.utm === "object"
        ? {
            source: (body.utm as { source?: unknown }).source as string | undefined,
            medium: (body.utm as { medium?: unknown }).medium as string | undefined,
            campaign: (body.utm as { campaign?: unknown }).campaign as string | undefined,
          }
        : null,
  });

  // ── Set the visitor cookie when missing ──
  // The cookie is read on the NEXT request to identify the visitor's
  // session. We generate a fresh token server-side (the client cannot
  // influence the value) + set it as HttpOnly + SameSite=Lax.
  const cookieHeader = req.headers.get("cookie") ?? "";
  const hasVisitorCookie = cookieHeader
    .split(";")
    .some((c) => c.trim().startsWith(`${VISITOR_COOKIE_NAME}=`));

  const response = new NextResponse(null, { status: 204 });
  if (!hasVisitorCookie) {
    setVisitorCookieOnResponse(response, generateVisitorToken());
  }

  return response;
});
