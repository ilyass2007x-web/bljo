import { apiHandler, badRequest, ok } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { parsePostContent } from "@/lib/posts/parser";
import { getBlockedAuthorIds } from "@/lib/block";
import { normalizeForSearch } from "@/lib/search/normalize";

/**
 * GET /api/v1/search/suggest?q=<query>
 * ------------------------------------
 * Lightweight LIVE SUGGESTIONS endpoint for the search bar (spec §3, §4).
 *
 * Returns the top 3-5 results PER CATEGORY so the user sees live
 * suggestions as they type:
 *   - People (users matching username/fullName)
 *   - Posts (posts whose content contains the query)
 *   - Articles (published articles whose title/excerpt contains the query)
 *   - Topics (hashtags extracted from posts/articles that match the query)
 *
 * Designed for FAST response (target < 100ms):
 *   - 3 parallel DB queries (users + posts + articles).
 *   - Topics are extracted CLIENT-SIDE-FRIENDLY from the post/article
 *     results (we don't do a separate query — we parse the hashtags
 *     from the returned posts' content + the articles' titles/excerpts).
 *   - Light SELECT projections (no full article body, no _count).
 *   - Hard cap: 5 results per category, total 20 results max.
 *
 * DEBOUNCING (spec §4):
 *   The CLIENT is responsible for debouncing (250-300ms). The server
 *   just responds quickly. The client should also cancel stale
 *   requests via AbortController.
 *
 * RELEVANCE (spec §6, §7):
 *   Within each category, results are ranked:
 *     - Exact match (case-insensitive) → top
 *     - Starts-with match → next
 *     - Contains match → next
 *   Sorted by createdAt/publishedAt DESC as a tiebreaker.
 *
 * SECURITY (spec §25):
 *   - All queries use Prisma's parameterized queries (no SQL injection).
 *   - Only PUBLISHED articles are searchable (drafts excluded).
 *   - Only ACTIVE users are searchable (suspended/banned excluded).
 *   - Posts are not filtered by author status (a post by a now-banned
 *     user is still searchable — but the post itself is public content;
 *     the author info is included so the client can navigate to profile).
 *   - Rate-limited: 60 requests/minute per user (live suggestions can
 *     be chatty, but each request is cheap).
 *
 * Response: {
 *   people: UserSuggestion[],
 *   posts: PostSuggestion[],
 *   articles: ArticleSuggestion[],
 *   topics: TopicSuggestion[],
 *   counts: { people, posts, articles, topics }
 * }
 */
export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();

  // Rate-limit: 60/min/user (live suggestions can be chatty, but each
  // request is cheap). We use a higher limit than the regular search
  // endpoint because suggestions are lightweight + the user types fast.
  const rl = await checkRateLimit(`search:suggest:${user.id}`, {
    limit: 60,
    windowSeconds: 60,
  });
  if (!rl.ok) {
    return ok({
      people: [], posts: [], articles: [], topics: [],
      counts: { people: 0, posts: 0, articles: 0, topics: 0 },
      rateLimited: true,
    });
  }

  const url = new URL(req.url);
  const q = (url.searchParams.get("q") ?? "").trim();

  if (q.length < 2) {
    return badRequest("Query must be at least 2 characters");
  }

  // AUDIT FIX (2026-09-22): normalize the query via `normalizeForSearch`
  // (Arabic alef-variants, diacritics, etc.) and query the `*Normalized`
  // columns. This brings /api/v1/search/suggest in line with
  // /api/v1/search/all — both now match `احمد` against stored `أحمد`.
  // Previously this route queried raw `username`/`fullName`/`content`/
  // `title`/`excerpt` columns, so Arabic suggestions missed alef-variant
  // + diacritic-stripped matches that the main search route would catch.
  // The `*Normalized` columns are nullable on legacy DBs (backfilled by
  // migration 20260922000002). Rows with NULL `*Normalized` won't match
  // — the backfill script (`scripts/backfill-normalized-search-fields.ts`)
  // should be run once after the migration to populate them. New rows
  // get normalized automatically via the Prisma Client extension in
  // `src/lib/database/index.ts`.
  const qNormalized = normalizeForSearch(q);

  // ── Parallel queries: Users + Posts + Articles ────────────────────
  // All case-insensitive (Prisma `mode: "insensitive"` → PostgreSQL ILIKE).
  // We fetch a slightly larger pool (8 per category) so we can extract
  // topics from the post/article content + still have 5 results to show.
  const SUGGESTION_LIMIT = 5;
  const POOL_LIMIT = 8;

  // ── Block filtering (Phase 1 — Security Correctness) ─────────────
  // Exclude content + profiles from authors the viewer has blocked OR
  // who have blocked the viewer (bidirectional visibility, mirroring the
  // Block model's documented semantics — see src/lib/block.ts). Single
  // query, pushed into each `where` as `notIn` so filtering happens at
  // the DB level (no N+1, no JS post-filtering, no pagination leak).
  const blockedAuthorIds = await getBlockedAuthorIds(user.id);
  const blockedAuthorFilter = blockedAuthorIds.size > 0
    ? { id: { notIn: [...blockedAuthorIds] } }
    : {};

  const [users, posts, articles] = await Promise.all([
    // Users: username OR fullName contains the query (normalized).
    db.user.findMany({
      where: {
        status: "ACTIVE",
        emailVerified: { not: null },
        OR: [
          { usernameNormalized: { contains: qNormalized, mode: "insensitive" } },
          { fullNameNormalized: { contains: qNormalized, mode: "insensitive" } },
          // Fallback to raw columns for legacy rows where *Normalized is NULL
          // (backfill not yet run). This is a defense-in-depth — new rows
          // have *Normalized populated by the Prisma Client extension.
          { username: { contains: q, mode: "insensitive" } },
          { fullName: { contains: q, mode: "insensitive" } },
        ],
        ...blockedAuthorFilter,
      },
      take: POOL_LIMIT,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        fullName: true,
        username: true,
        avatarColor: true,
        avatarUrl: true,
        isVerified: true,
      },
    }),
    // Posts: content contains the query (normalized).
    // Moderation gate (Phase 1 — Security Correctness): only APPROVED
    // posts are searchable. PENDING_MODERATION / REJECTED / REMOVED
    // posts are excluded — matches the existing behavior of
    // /api/v1/search/all and /api/v1/feed/unified.
    db.post.findMany({
      where: {
        OR: [
          { contentNormalized: { contains: qNormalized, mode: "insensitive" } },
          { content: { contains: q, mode: "insensitive" } },
        ],
        moderationStatus: "APPROVED",
        ...(blockedAuthorIds.size > 0
          ? { authorId: { notIn: [...blockedAuthorIds] } }
          : {}),
      },
      take: POOL_LIMIT,
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        content: true,
        createdAt: true,
        author: {
          select: {
            id: true, fullName: true, username: true,
            avatarColor: true, avatarUrl: true, isVerified: true,
          },
        },
      },
    }),
    // Articles: title OR excerpt contains the query (PUBLISHED + APPROVED only).
    // Moderation gate (Phase 1 — Security Correctness): adds
    // `moderationStatus: "APPROVED"` to match /api/v1/search/all and
    // /api/v1/feed/unified. Previously only `status: "PUBLISHED"` was
    // filtered — PUBLISHED-but-PENDING_MODERATION articles were
    // leaking into live suggestions.
    db.article.findMany({
      where: {
        status: "PUBLISHED",
        moderationStatus: "APPROVED",
        OR: [
          { titleNormalized: { contains: qNormalized, mode: "insensitive" } },
          { excerptNormalized: { contains: qNormalized, mode: "insensitive" } },
          // Fallback to raw columns for legacy rows where *Normalized is NULL.
          { title: { contains: q, mode: "insensitive" } },
          { excerpt: { contains: q, mode: "insensitive" } },
        ],
        ...(blockedAuthorIds.size > 0
          ? { authorId: { notIn: [...blockedAuthorIds] } }
          : {}),
      },
      take: POOL_LIMIT,
      orderBy: { publishedAt: "desc" },
      select: {
        id: true,
        title: true,
        excerpt: true,
        coverImage: true,
        publishedAt: true,
        author: {
          select: {
            id: true, fullName: true, username: true,
            avatarColor: true, avatarUrl: true, isVerified: true,
          },
        },
      },
    }),
  ]);

  // ── Rank users by relevance (exact > startsWith > contains) ──────
  const qLower = q.toLowerCase();
  const rankedUsers = users
    .map((u) => {
      const usernameLower = u.username.toLowerCase();
      const fullNameLower = u.fullName.toLowerCase();
      let rank = 3;
      if (usernameLower === qLower) rank = 0;
      else if (fullNameLower === qLower) rank = 0;
      else if (usernameLower.startsWith(qLower)) rank = 1;
      else if (fullNameLower.startsWith(qLower)) rank = 1;
      return { user: u, rank };
    })
    .sort((a, b) => a.rank - b.rank)
    .slice(0, SUGGESTION_LIMIT)
    .map(({ user, rank }) => ({
      id: user.id,
      fullName: user.fullName,
      username: user.username,
      avatarColor: user.avatarColor,
      avatarUrl: user.avatarUrl,
      isVerified: user.isVerified,
      rank, // for client-side sorting/debugging
    }));

  // ── Rank posts by relevance (exact match > startsWith > contains) ──
  const rankedPosts = posts
    .map((p) => {
      const contentLower = p.content.toLowerCase();
      let rank = 3;
      if (contentLower === qLower) rank = 0;
      else if (contentLower.startsWith(qLower) || contentLower.includes(` ${qLower}`)) rank = 1;
      return { post: p, rank };
    })
    .sort((a, b) => a.rank - b.rank)
    .slice(0, SUGGESTION_LIMIT)
    .map(({ post, rank }) => ({
      id: post.id,
      content: post.content.slice(0, 100), // preview
      createdAt: post.createdAt.toISOString(),
      author: post.author,
      rank,
    }));

  // ── Rank articles by relevance ────────────────────────────────────
  const rankedArticles = articles
    .map((a) => {
      const titleLower = a.title.toLowerCase();
      let rank = 3;
      if (titleLower === qLower) rank = 0;
      else if (titleLower.startsWith(qLower)) rank = 1;
      else if (titleLower.includes(qLower)) rank = 2;
      return { article: a, rank };
    })
    .sort((a, b) => a.rank - b.rank)
    .slice(0, SUGGESTION_LIMIT)
    .map(({ article, rank }) => ({
      id: article.id,
      title: article.title,
      excerpt: article.excerpt?.slice(0, 100) ?? null,
      coverImage: article.coverImage,
      publishedAt: article.publishedAt?.toISOString() ?? null,
      author: article.author,
      rank,
    }));

  // ── Extract topics (hashtags) from posts + articles ───────────────
  // Topics are generated from hashtags in post content + hashtags in
  // article titles/excerpts. We don't query a separate topics table —
  // we parse them from the returned content (spec §13: "Topics can be
  // generated from hashtags, categories, normalized keywords").
  //
  // If the user's query starts with `#`, we treat it as a hashtag
  // search and rank hashtags that match higher.
  const queryIsHashtag = q.startsWith("#");
  const queryWithoutHash = queryIsHashtag ? q.slice(1) : q;

  const topicCounts = new Map<string, number>();
  const topicMatcher = (text: string) => {
    const parsed = parsePostContent(text);
    for (const h of parsed.hashtags) {
      // h.tag is the tag without the leading #.
      const tag = h.tag.toLowerCase();
      // Match: the tag contains the query (case-insensitive).
      if (tag.includes(queryWithoutHash.toLowerCase())) {
        topicCounts.set(tag, (topicCounts.get(tag) ?? 0) + 1);
      }
    }
  };

  // Parse hashtags from posts.
  for (const p of posts) topicMatcher(p.content);
  // Parse hashtags from articles (title + excerpt).
  for (const a of articles) {
    topicMatcher(a.title);
    if (a.excerpt) topicMatcher(a.excerpt);
  }

  // Rank topics: exact match > startsWith > contains; tiebreak by count.
  const rankedTopics = Array.from(topicCounts.entries())
    .map(([tag, count]) => {
      const tagLower = tag.toLowerCase();
      let rank = 3;
      if (tagLower === queryWithoutHash.toLowerCase()) rank = 0;
      else if (tagLower.startsWith(queryWithoutHash.toLowerCase())) rank = 1;
      return { tag, count, rank };
    })
    .sort((a, b) => {
      if (a.rank !== b.rank) return a.rank - b.rank;
      return b.count - a.count;
    })
    .slice(0, SUGGESTION_LIMIT)
    .map(({ tag, count, rank }) => ({ tag, count, rank }));

  return ok({
    people: rankedUsers,
    posts: rankedPosts,
    articles: rankedArticles,
    topics: rankedTopics,
    counts: {
      people: rankedUsers.length,
      posts: rankedPosts.length,
      articles: rankedArticles.length,
      topics: rankedTopics.length,
    },
  });
});
