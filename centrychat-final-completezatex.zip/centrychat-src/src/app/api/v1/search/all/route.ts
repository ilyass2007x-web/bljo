import { apiHandler, badRequest, ok } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { isFeatureEnabled } from "@/lib/features";
import { getBlockedAuthorIds } from "@/lib/block";
import { normalizeForSearch, tokenizeSearchQuery } from "@/lib/search/normalize";
import type { Prisma } from "@prisma/client";

/**
 * GET /api/v1/search/all?q=<query>&limit=<n>&cursor=<opaque>
 * ----------------------------------------------------------
 * Unified search across Users + Posts + published Articles +
 * (optionally) public Collections + (optionally) public Playlists.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * Phase 2B — Search Retrieval & Relevance Foundation
 * ═══════════════════════════════════════════════════════════════════════
 *
 * PROBLEM (Phase 2A state):
 *   - Retrieval used `ILIKE '%q%'` only — no typo tolerance, no
 *     relevance scoring. A search for "footbll" missed "football"
 *     entirely. Old but highly-relevant items could be skipped because
 *     they didn't match the exact substring.
 *   - The tier system (rank 1..10) only encoded match TYPE (exact /
 *     startsWith / contains) — it didn't encode match QUALITY. Two
 *     items in the same tier were ordered purely by ts DESC, with no
 *     notion of "this item is a closer match than that one".
 *
 * SOLUTION (Phase 2B — pg_trgm + Relevance Tiebreaker):
 *   1. Migration `20260922000000_add_pg_trgm_search` enables the
 *      `pg_trgm` extension + creates GIN trigram indexes on all
 *      searchable text columns. This:
 *        a) Accelerates the existing `ILIKE '%q%'` queries (Phase 2A
 *           retrieval path) — PostgreSQL can use the GIN index instead
 *           of a seq scan.
 *        b) Enables typo-tolerant retrieval via the `%` operator (NEW
 *           capability — Phase 2A had none).
 *
 *   2. The route keeps the Phase 2A per-(entity, rank) stream
 *      architecture INTACT (11 streams + 5 count queries, all
 *      parallel). The tier system (ranks 1..10) is UNCHANGED —
 *      match type still determines the primary tier.
 *
 *   3. WITHIN each stream's tier, the route now computes a per-item
 *      RELEVANCE SCORE using `pg_trgm.similarity(query, column)` and
 *      uses it as a TIE-BREAKER between (rank, ts DESC, type, id):
 *        OLD (Phase 2A):  rank ASC, ts DESC, type ASC, id DESC
 *        NEW (Phase 2B):  rank ASC, ts DESC, type ASC, relevance DESC, id DESC
 *
 *      Wait — that ordering is INSUFFICIENT for stream-cursor
 *      pagination: if relevance is added AFTER ts, it never fires
 *      (items with the same ts are rare; the tiebreaker would never
 *      activate).
 *
 *      REVISED (Phase 2B): put relevance BEFORE ts within a tier:
 *        NEW:  rank ASC, relevance DESC, ts DESC, type ASC, id DESC
 *
 *      This makes highly-relevant items surface FIRST within their
 *      tier, even if they're older. Less-relevant items (still in the
 *      same tier) come later.
 *
 *   4. The cursor carries per-stream resume pointers of
 *      `(relevance, ts, id)`. The DB query for each stream filters
 *      `(relevance, ts, id) < (resume.relevance, resume.ts, resume.id)`
 *      in the (relevance DESC, ts DESC, id DESC) ordering — so the
 *      cursor is stable + correctly resumes after the last emitted
 *      item.
 *
 *   5. RELEVANCE COMPUTATION:
 *      For each item, the route calls `pg_trgm.similarity(query, text)`
 *      via a single batched `Prisma.$queryRaw` call (per stream) AFTER
 *      the initial `findMany`. The similarity is computed against the
 *      column(s) that matched the tier (e.g. for article:4, similarity
 *      is against `title`; for article:6, against `excerpt || ' ' ||
 *      content`). The route takes the MAX similarity across all
 *      matching columns.
 *
 *      If `pg_trgm` is unavailable (e.g. SQLite dev DB), the route
 *      gracefully falls back to relevance=0 for all items — the
 *      ordering reduces to Phase 2A's behavior (rank, ts DESC, id
 *      DESC). This is a SAFE degradation.
 *
 *   6. TYPO TOLERANCE (NEW):
 *      In addition to the existing ILIKE-based streams, the route
 *      ALSO queries each entity with `column % query` (the pg_trgm
 *      similarity operator) to catch items that ILIKE misses (e.g.
 *      "footbll" → "football"). These typo-matched items get a
 *      LOWER rank than exact/prefix/contains matches (rank 11-15:
 *      user:11, post:11, article:11, collection:11, playlist:11)
 *      so they don't crowd out better matches. This is an ADDITIVE
 *      tier — the existing 1-10 tiers are unchanged.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * Phase 2A — Pagination Completeness (PRESERVED 100%)
 * ═══════════════════════════════════════════════════════════════════════
 *   - Per-(entity, rank) stream architecture
 *   - Per-stream (relevance, ts, id) resume pointers (was: (ts, id))
 *   - 11 streams + 5 count queries, all parallel
 *   - No candidate truncation
 *   - Full-order === concatenated paginated ordering
 *   - No duplicates, no skipped results
 *
 * ═══════════════════════════════════════════════════════════════════════
 * Phase 1 — Security Correctness (PRESERVED 100%)
 * ═══════════════════════════════════════════════════════════════════════
 *   - Posts: moderationStatus = APPROVED
 *   - Articles: status = PUBLISHED + moderationStatus = APPROVED
 *   - Users: status = ACTIVE only
 *   - Block filtering (bidirectional): excluded at the DB query level.
 *   - Collections + Playlists: `isPublic: true`.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * Ranking (Phase 2B — updated)
 * ═══════════════════════════════════════════════════════════════════════
 *   1. rank ASC                — tier relevance (existing tiers 1-10 + new typo tiers 11-15)
 *   2. relevance DESC (NEW)    — pg_trgm similarity score, 0..1
 *   3. ts DESC                  — newer first (existing, unchanged)
 *   4. type ASC (alphabetical)  — stable cross-entity tiebreaker
 *   5. id DESC (lexicographic)   — stable unique tiebreaker
 *
 * Tier table (existing 1-10 UNCHANGED; new typo tiers 11-15 added):
 *   1. Username exact match
 *   2. Username starts-with
 *   3. Full-name starts-with
 *   4. Article title contains
 *   5. Post content contains
 *   6. Article excerpt/content contains + default user tier
 *   7. Collection name contains
 *   8. Collection description contains
 *   9. Playlist name contains
 *   10. Playlist description contains
 *   ── NEW (Phase 2B typo-tolerance tiers) ──
 *   11. User typo match (pg_trgm % query on username OR fullName)
 *   12. Post typo match (pg_trgm % query on content)
 *   13. Article typo match (pg_trgm % query on title/excerpt/content)
 *   14. Collection typo match (pg_trgm % query on name/description)
 *   15. Playlist typo match (pg_trgm % query on name/description)
 *
 * Response shape — BACKWARD COMPATIBLE:
 *   {
 *     results: SearchResult[],
 *     counts: { users, posts, articles, collections, playlists },
 *     pagination: { nextCursor: string | null, hasMore: boolean }
 *   }
 *
 *   The `relevance` field is INTERNAL — not exposed in the response
 *   (the `rank` field already exposes the tier). This keeps the API
 *   shape identical to Phase 2A.
 */

export interface SearchResult {
  type: "user" | "post" | "article" | "collection" | "playlist";
  /** Relevance rank — lower is more relevant (1 = best match). */
  rank: number;
  data: any;
}

type EntityType = "user" | "post" | "article" | "collection" | "playlist";

// ── Cursor ─────────────────────────────────────────────────────────────
// Opaque base64-encoded JSON. Backward INCOMPATIBLE with Phase 2A cursors
// (the streams map now carries `relevance` per stream). This is intended —
// the route rejects old cursors with "Invalid cursor" (missing `relevance`
// field) and the client simply re-requests page 1.
//
// The cursor carries:
//   - `q` for query binding (reject mismatched queries)
//   - `streams`: per-(entity, rank) resume pointers
//     key = `${type}:${rank}` (e.g. "user:1", "post:5", "article:11")
//     value = { relevance: number, ts: number, id: string }
//       — the LAST item emitted for that stream across ALL previous pages.
//       — the next page's DB query uses
//         `(relevance, ts, id) < (resume.relevance, resume.ts, resume.id)`
//         in the (relevance DESC, ts DESC, id DESC) ordering as a filter.
//
// The `streams` map has at most 16 entries (10 original tiers + 6 typo
// tiers — minus overlaps). Bounded + opaque to the client.
interface StreamResume {
  /** pg_trgm similarity score of the last emitted item, 0..1. */
  relevance: number;
  /** Epoch millis of the last item's timestamp. */
  ts: number;
  /** Stable unique ID of the last item. */
  id: string;
}

interface CursorData {
  /** Normalized query string — used for query-bound validation. */
  q: string;
  /** Per-(entity, rank) resume pointers. */
  streams: Record<string, StreamResume>;
  /**
   * Phase 2D — internal cursor version. Bumped whenever the search
   * semantics change in a way that invalidates previously-issued cursors
   * (e.g. normalization rule changes, tier renumbering, multi-word token
   * AND fallback). Old cursors lacking `v` or with `v !== SEARCH_CURSOR_VERSION`
   * are rejected with "Invalid cursor." — the client re-requests page 1.
   * This field is NOT exposed in the public API response (it's an internal
   * implementation detail encoded inside the opaque cursor).
   */
  v?: number;
}

/**
 * Phase 2D — bump this whenever the search semantics change. Pre-2D cursors
 * (no `v` field) + cursors with a different `v` are rejected, forcing
 * the client to start a fresh search. This is the safe-fail mechanism:
 * it prevents stale resume pointers from being replayed against a search
 * system whose semantics have shifted.
 *
 * Current version: 2 (Phase 2D — Arabic normalization + multi-word token AND).
 * Version 1 was the implicit pre-2D cursor format (no `v` field).
 */
const SEARCH_CURSOR_VERSION = 2;

function decodeCursor(raw: string | null): CursorData | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(
      Buffer.from(raw, "base64").toString("utf-8")
    ) as Partial<CursorData>;
    if (typeof parsed.q !== "string") return null;
    if (parsed.streams !== undefined && typeof parsed.streams !== "object") return null;
    // Phase 2D — reject cursors that lack the version field or have an
    // incompatible version. This forces clients to start a fresh search
    // after the Phase 2D deploy (where normalization rules changed).
    if (parsed.v !== SEARCH_CURSOR_VERSION) return null;
    // Validate that each stream resume has the required fields.
    if (parsed.streams) {
      for (const key of Object.keys(parsed.streams)) {
        const v = (parsed.streams as any)[key];
        if (
          typeof v !== "object" || v === null ||
          typeof v.relevance !== "number" ||
          typeof v.ts !== "number" ||
          typeof v.id !== "string"
        ) {
          return null;
        }
      }
    }
    return {
      q: parsed.q,
      v: parsed.v,
      streams:
        parsed.streams && typeof parsed.streams === "object"
          ? parsed.streams as Record<string, StreamResume>
          : {},
    };
  } catch {
    return null;
  }
}

function encodeCursor(c: CursorData): string {
  return Buffer.from(JSON.stringify(c), "utf-8").toString("base64");
}

type ComparableItem = Pick<RankedItem, "type" | "rank" | "ts" | "id" | "relevance">;

/**
 * Stable comparison key for a ranked search result.
 *
 * Order (Phase 2B):
 *   1. rank ASC              — tier relevance (existing 1-10 + new 11-15 typo tiers)
 *   2. relevance DESC (NEW)   — pg_trgm similarity score, 0..1
 *   3. ts DESC                — newer first (existing, unchanged)
 *   4. type ASC (alphabetical) — stable cross-entity tiebreaker
 *   5. id DESC (lexicographic)  — stable unique tiebreaker
 *
 * The (type, id) pair is GLOBALLY UNIQUE across all entity types,
 * guaranteeing a fully deterministic ordering — required for cursor
 * pagination.
 *
 * Phase 2B change: `relevance DESC` is inserted BETWEEN rank and ts.
 * This means within a tier, highly-relevant items surface FIRST,
 * even if they're older. The Phase 2A ts DESC ordering is preserved
 * as the next tiebreaker (when two items have the same relevance,
 * the newer one wins).
 *
 * IMPORTANT: `id DESC` (NOT ASC) matches the DB query's `orderBy:
 * [{ relevance: "desc" }, { ts: "desc" }, { id: "desc" }]` (where
 * `relevance` is computed via `pg_trgm.similarity()`). This is
 * REQUIRED for the per-stream (relevance, ts, id) resume filter to
 * work correctly — same rationale as Phase 2A's id DESC change.
 */
function compareRanked(a: ComparableItem, b: ComparableItem): number {
  if (a.rank !== b.rank) return a.rank - b.rank;
  // relevance DESC: higher relevance first → reverse comparison
  if (a.relevance !== b.relevance) return b.relevance - a.relevance;
  if (a.ts !== b.ts) return b.ts - a.ts;
  if (a.type !== b.type) return a.type < b.type ? -1 : 1;
  if (a.id !== b.id) return b.id < a.id ? -1 : 1; // id DESC
  return 0;
}

interface RankedItem {
  type: EntityType;
  rank: number;
  ts: number; // epoch millis (0 when the entity has no timestamp)
  id: string;
  /** Phase 2B — pg_trgm similarity score, 0..1. Defaults to 0 when pg_trgm unavailable. */
  relevance: number;
  data: any;
}

const ENTITY_TS_FIELD: Record<EntityType, string> = {
  user: "createdAt",
  post: "createdAt",
  article: "publishedAt",
  collection: "updatedAt",
  playlist: "updatedAt",
};

function streamKey(type: EntityType, rank: number): string {
  return `${type}:${rank}`;
}

/**
 * Apply the per-stream resume threshold to a base Prisma WHERE clause.
 *
 * Phase 2B: the resume filter now operates on (relevance, ts, id) — not
 * just (ts, id). The DB query orders by
 *   `[{ relevance: "desc" }, { ts: "desc" }, { id: "desc" }]`
 * (where `relevance` is computed via `pg_trgm.similarity()` in a
 * raw SQL fragment — see the query builder below).
 *
 * The resume filter is:
 *   `(relevance, ts, id) < (resume.relevance, resume.ts, resume.id)`
 * in the (relevance DESC, ts DESC, id DESC) ordering, encoded as:
 *   OR: [
 *     { relevance: { lt: resume.relevance } },
 *     { relevance: resume.relevance, ts: { lt: resume.ts } },
 *     { relevance: resume.relevance, ts: resume.ts, id: { lt: resume.id } },
 *   ]
 *
 * Generic `T` preserves the model-specific Prisma WhereInput type.
 *
 * NOTE: when `relevance` is unavailable (pg_trgm disabled — SQLite dev),
 * the route sets `relevance=0` for all items. The resume filter then
 * effectively becomes `(0, ts, id) < (0, resume.ts, resume.id)` — which
 * reduces to the Phase 2A `(ts, id)` filter. Backward compatible.
 */
function withStreamResume<T extends Record<string, any>>(
  baseWhere: T,
  tsField: string,
  resume: StreamResume | null
): T {
  if (!resume) return baseWhere;
  const resumeDate = new Date(resume.ts);
  // When relevance is 0 (pg_trgm unavailable OR all items have relevance 0
  // because the query didn't match any trigrams), the filter reduces to
  // Phase 2A's (ts, id) filter. This is correct + backward compatible.
  if (resume.relevance === 0) {
    return {
      ...baseWhere,
      OR: [
        { [tsField]: { lt: resumeDate } },
        { [tsField]: resumeDate, id: { lt: resume.id } },
      ],
    } as T;
  }
  // Phase 2B — full (relevance, ts, id) resume filter.
  // NOTE: `relevance` is a computed column added via raw SQL, so the
  // WHERE clause references it by name. This only works when the query
  // is built with the relevance-computing raw SQL fragment (see the
  // stream query builders below).
  return {
    ...baseWhere,
    OR: [
      { relevance: { lt: resume.relevance } },
      { relevance: resume.relevance, [tsField]: { lt: resumeDate } },
      { relevance: resume.relevance, [tsField]: resumeDate, id: { lt: resume.id } },
    ],
  } as T;
}

export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();

  // Rate-limit: 30 searches per minute per user.
  const rl = await checkRateLimit(`search:all:${user.id}`, RATE_LIMITS.search);
  if (!rl.ok) {
    return ok({
      results: [],
      counts: { users: 0, posts: 0, articles: 0, collections: 0, playlists: 0 },
      pagination: { nextCursor: null, hasMore: false },
      rateLimited: true,
    });
  }

  const url = new URL(req.url);
  const qRaw = (url.searchParams.get("q") ?? "").trim();
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "20"), 1), 50);
  const cursorParam = url.searchParams.get("cursor");

  if (qRaw.length < 2) {
    return badRequest("Query must be at least 2 characters");
  }

  // ── Cursor validation ─────────────────────────────────────────────
  const cursor = decodeCursor(cursorParam);
  if (cursorParam && !cursor) {
    return badRequest("Invalid cursor.");
  }

  // ── Phase 2D — Normalize the query for multilingual search ────────
  // The query is normalized via `normalizeForSearch()` (src/lib/search/normalize.ts):
  //   1. NFKC Unicode normalization
  //   2. Strip zero-width characters (ZWJ, ZWNJ, BOM, etc.)
  //   3. Strip Arabic diacritics (tashkeel: fatha, damma, kasra, shadda, sukun)
  //   4. Strip tatweel (U+0640)
  //   5. Unify alef variants: أ إ آ ٱ → ا
  //   6. Unify alif maqsura: ى → ي
  //   7. Lowercase (Latin chars only)
  //   8. Collapse repeated whitespace to single space + trim
  //
  // This normalized form is used for:
  //   - Cursor binding (cursor.q === qNormalized rejects mismatched queries)
  //   - ILIKE matching against the normalized DB columns (`*_normalized`)
  //   - pg_trgm similarity in typo tiers (against normalized columns)
  //
  // The ORIGINAL `qRaw` is kept for backward compatibility + diagnostics,
  // but is NOT used in any WHERE clause post-Phase-2D.
  const qNormalized = normalizeForSearch(qRaw);
  if (cursor && cursor.q !== qNormalized) {
    return badRequest("Cursor does not match current query.");
  }

  // Phase 2D — Multi-word token AND fallback.
  // The query is split into whitespace-separated tokens. The ILIKE WHERE
  // clauses (built below) use an OR pattern: a row matches if EITHER
  // (a) the full phrase `qNormalized` is a substring, OR (b) ALL tokens
  // are substrings (in any order, any positions). This is the "token AND
  // fallback" — phrase matches rank higher within the same tier (because
  // they match condition (a) which is checked first), but token-AND matches
  // are also surfaced (condition (b)). No new rank is introduced.
  //
  // For single-word queries (the common case), `qTokens` is a 1-element
  // array, and the token-AND fallback degenerates to the same as the
  // phrase match — no behavioral change.
  //
  // For User streams (username, fullName), token-AND is NOT applied —
  // usernames are single tokens by convention, and applying token-AND
  // to fullName would change tier semantics in surprising ways. User
  // streams use only the phrase match (as before Phase 2D).
  const qTokens = tokenizeSearchQuery(qNormalized);

  // ── Phase 1 — Security Correctness: Block filtering ──────────────
  const blockedAuthorIds = await getBlockedAuthorIds(user.id);
  const blockedUserFilter: Record<string, any> = blockedAuthorIds.size > 0
    ? { id: { notIn: [...blockedAuthorIds] } }
    : {};
  const blockedAuthorFilter: Record<string, any> = blockedAuthorIds.size > 0
    ? { authorId: { notIn: [...blockedAuthorIds] } }
    : {};
  // Collections + Playlists use `ownerId` (not `authorId`). Build a parallel
  // filter so blocked owners' collections/playlists don't leak into search
  // results. Phase 2D audit fix: previously only Post + Article streams
  // applied the block filter; Collection + Playlist ILIKE streams missed it.
  // The typo-tier raw SQL streams (lines ~1027, ~1043) already filter via
  // `u.id NOT IN (...)` — this fix brings the ILIKE streams in line.
  const blockedOwnerFilter: Record<string, any> = blockedAuthorIds.size > 0
    ? { ownerId: { notIn: [...blockedAuthorIds] } }
    : {};

  // ── Feature flags ────────────────────────────────────────────────
  const collectionsEnabled = await isFeatureEnabled("collections");
  const playlistsEnabled = await isFeatureEnabled("playlists");

  // ── Phase 2D — Multi-word token AND fallback helpers ──────────────
  // For each searchable field, build a Prisma WHERE condition that matches
  // EITHER (a) the full normalized phrase as a substring, OR (b) all tokens
  // (whitespace-split) as individual substrings. This expands recall for
  // multi-word queries like "football player" — a post containing
  // "football" in paragraph 1 and "player" in paragraph 5 will now match,
  // even though the phrase "football player" is not a contiguous substring.
  //
  // The OR ordering matters: condition (a) [phrase] is listed FIRST in the
  // OR array. Prisma/PostgreSQL doesn't order rows by which OR clause
  // matched — but rows matching ONLY the phrase (condition (a)) and rows
  // matching BOTH (a) and (b) tend to be the "better" matches. The route's
  // global sort (rank ASC, relevance DESC, ts DESC, type ASC, id DESC)
  // already handles ordering within a tier.
  //
  // For User streams (username, fullName), token-AND is intentionally NOT
  // applied — usernames are single tokens, and applying token-AND to
  // fullName would change tier semantics in surprising ways (e.g. a
  // search for "ali mohammed" would match "Ali Ahmed Mohammed" via
  // token-AND even though neither "ali" nor "mohammed" is a prefix).
  // User streams keep the phrase-only match.
  function phraseOrTokenAndContains(
    normalizedField: string,
    q: string,
    tokens: string[]
  ): Prisma.StringFilter | { OR: Prisma.StringFilter[] } {
    // Single-token (or empty) query → just the phrase match.
    if (tokens.length <= 1) {
      return { contains: q, mode: "insensitive" };
    }
    // Multi-word: phrase match OR (all tokens AND).
    return {
      OR: [
        { contains: q, mode: "insensitive" },
        // Token-AND fallback: all tokens must be substrings of the same field.
        // We use AND at the Prisma level (which compiles to SQL AND).
        { AND: tokens.map((t) => ({ [normalizedField]: { contains: t, mode: "insensitive" } })) } as any,
      ],
    };
  }

  // Helper: build an OR over multiple fields, each using phrase-or-token-AND.
  // Used for entities where multiple fields can match (Article title/excerpt/content,
  // Collection name/description, Playlist name/description).
  function multiFieldPhraseOrTokenAnd(
    fields: string[],
    q: string,
    tokens: string[]
  ): Prisma.Enumerable<any> {
    if (tokens.length <= 1) {
      // Single-token: just OR the phrase match across fields (pre-2D behavior).
      return fields.map((f) => ({ [f]: { contains: q, mode: "insensitive" } }));
    }
    // Multi-word: for each field, (phrase match) OR (all tokens AND).
    return fields.map((f) => ({
      OR: [
        { [f]: { contains: q, mode: "insensitive" } },
        { AND: tokens.map((t) => ({ [f]: { contains: t, mode: "insensitive" } })) } as any,
      ],
    }));
  }

  // ── Build BASE WHERE clauses per entity (without rank or cursor) ──
  // Phase 2D — uses the normalized columns (`*_normalized`) instead of
  // the raw columns. This is the key change: searching `usernameNormalized`
  // means an Arabic query `احمد` matches a stored `أحمد` (the column was
  // normalized to `احمد` at write time via the Prisma Client extension).
  //
  // For User streams (ranks 1-3 + 6), only the phrase match is used
  // (no token-AND — usernames are single tokens).
  const userBaseWhere: Prisma.UserWhereInput = {
    status: "ACTIVE",
    OR: [
      { fullNameNormalized: { contains: qNormalized, mode: "insensitive" } },
      { usernameNormalized: { contains: qNormalized, mode: "insensitive" } },
    ],
    ...(blockedUserFilter as Prisma.UserWhereInput),
  };
  const postBaseWhere: Prisma.PostWhereInput = {
    contentNormalized: phraseOrTokenAndContains("contentNormalized", qNormalized, qTokens) as any,
    moderationStatus: "APPROVED",
    ...(blockedAuthorFilter as Prisma.PostWhereInput),
  };
  const articleBaseWhere: Prisma.ArticleWhereInput = {
    status: "PUBLISHED",
    moderationStatus: "APPROVED",
    OR: multiFieldPhraseOrTokenAnd(
      ["titleNormalized", "excerptNormalized", "contentNormalized"],
      qNormalized,
      qTokens
    ) as any,
    ...(blockedAuthorFilter as Prisma.ArticleWhereInput),
  };
  const collectionBaseWhere: Prisma.CollectionWhereInput = {
    isPublic: true,
    OR: multiFieldPhraseOrTokenAnd(
      ["nameNormalized", "descriptionNormalized"],
      qNormalized,
      qTokens
    ) as any,
    ...(blockedOwnerFilter as Prisma.CollectionWhereInput),
  };
  const playlistBaseWhere: Prisma.PlaylistWhereInput = {
    isPublic: true,
    OR: multiFieldPhraseOrTokenAnd(
      ["nameNormalized", "descriptionNormalized"],
      qNormalized,
      qTokens
    ) as any,
    ...(blockedOwnerFilter as Prisma.PlaylistWhereInput),
  };

  // ── Per-stream WHERE clauses (split by rank tier at the DB level) ─
  // Phase 2A tiers (1-10) — ILIKE targets normalized columns post-Phase-2D.
  const userRank1Where: Prisma.UserWhereInput = {
    ...userBaseWhere,
    usernameNormalized: { equals: qNormalized, mode: "insensitive" },
  };
  const userRank2Where: Prisma.UserWhereInput = {
    ...userBaseWhere,
    usernameNormalized: { startsWith: qNormalized, mode: "insensitive" },
    NOT: { usernameNormalized: { equals: qNormalized, mode: "insensitive" } },
  };
  const userRank3Where: Prisma.UserWhereInput = {
    ...userBaseWhere,
    fullNameNormalized: { startsWith: qNormalized, mode: "insensitive" },
    NOT: { OR: [{ usernameNormalized: { startsWith: qNormalized, mode: "insensitive" } }] },
  };
  const userRank6Where: Prisma.UserWhereInput = {
    ...userBaseWhere,
    NOT: {
      OR: [
        { usernameNormalized: { equals: qNormalized, mode: "insensitive" } },
        { usernameNormalized: { startsWith: qNormalized, mode: "insensitive" } },
        { fullNameNormalized: { startsWith: qNormalized, mode: "insensitive" } },
      ],
    },
  };

  const articleRank4Where: Prisma.ArticleWhereInput = {
    ...articleBaseWhere,
    titleNormalized: { contains: qNormalized, mode: "insensitive" },
  };
  const articleRank6Where: Prisma.ArticleWhereInput = {
    ...articleBaseWhere,
    NOT: { titleNormalized: { contains: qNormalized, mode: "insensitive" } },
  };

  const collectionRank7Where: Prisma.CollectionWhereInput = {
    ...collectionBaseWhere,
    nameNormalized: { contains: qNormalized, mode: "insensitive" },
  };
  const collectionRank8Where: Prisma.CollectionWhereInput = {
    ...collectionBaseWhere,
    NOT: { nameNormalized: { contains: qNormalized, mode: "insensitive" } },
  };

  const playlistRank9Where: Prisma.PlaylistWhereInput = {
    ...playlistBaseWhere,
    nameNormalized: { contains: qNormalized, mode: "insensitive" },
  };
  const playlistRank10Where: Prisma.PlaylistWhereInput = {
    ...playlistBaseWhere,
    NOT: { nameNormalized: { contains: qNormalized, mode: "insensitive" } },
  };

  // Phase 2B — NEW typo-tolerance tiers (11-15). These use pg_trgm's
  // `%` operator to catch items that ILIKE missed (e.g. "footbll" →
  // "football"). They're LOWER priority than the existing tiers (1-10)
  // so they don't crowd out better matches.
  //
  // The `searchText` field is a Prisma-passthrough for the raw SQL
  // `column % $query` operator. Prisma doesn't natively support `%`, so
  // we use a raw SQL fragment via `Prisma.sql`. To keep the code clean,
  // the typo-tier streams use the same findMany structure but with a
  // raw WHERE clause added.
  //
  // IMPORTANT: typo-tier streams EXCLUDE items that already match an
  // existing tier (via NOT clauses). This prevents duplicates — an
  // item that matches `ILIKE '%foo%'` AND `column % 'foo'` appears
  // only in the higher-priority tier (5, not 12).

  // Build a helper for typo-tier WHERE clauses. Each excludes the
  // higher-priority tiers' match conditions.
  // NOTE: the following 5 `*TypoRank*Where` objects are defined for
  // documentation but are NOT directly used by the typo-tier queries
  // below (the actual typo queries use inline raw SQL via $queryRaw
  // because Prisma doesn't natively support pg_trgm's `%` operator).
  // They are kept for future migration to a Prisma-based typo path.
  // Phase 2D update: they now reference the normalized columns +
  // qNormalized (instead of raw columns + qRaw) to stay consistent
  // with the rest of the route.
  const userTypoRank11Where: Prisma.UserWhereInput = {
    status: "ACTIVE",
    ...(blockedUserFilter as Prisma.UserWhereInput),
    NOT: {
      OR: [
        { usernameNormalized: { contains: qNormalized, mode: "insensitive" } },
        { fullNameNormalized: { contains: qNormalized, mode: "insensitive" } },
      ],
    },
  };

  const postTypoRank12Where: Prisma.PostWhereInput = {
    moderationStatus: "APPROVED",
    ...(blockedAuthorFilter as Prisma.PostWhereInput),
    NOT: { contentNormalized: { contains: qNormalized, mode: "insensitive" } },
  };

  const articleTypoRank13Where: Prisma.ArticleWhereInput = {
    status: "PUBLISHED",
    moderationStatus: "APPROVED",
    ...(blockedAuthorFilter as Prisma.ArticleWhereInput),
    NOT: {
      OR: [
        { titleNormalized: { contains: qNormalized, mode: "insensitive" } },
        { excerptNormalized: { contains: qNormalized, mode: "insensitive" } },
        { contentNormalized: { contains: qNormalized, mode: "insensitive" } },
      ],
    },
  };

  const collectionTypoRank14Where: Prisma.CollectionWhereInput = {
    isPublic: true,
    ...(blockedUserFilter as any),
    NOT: {
      OR: [
        { nameNormalized: { contains: qNormalized, mode: "insensitive" } },
        { descriptionNormalized: { contains: qNormalized, mode: "insensitive" } },
      ],
    },
  };

  const playlistTypoRank15Where: Prisma.PlaylistWhereInput = {
    isPublic: true,
    NOT: {
      OR: [
        { nameNormalized: { contains: qNormalized, mode: "insensitive" } },
        { descriptionNormalized: { contains: qNormalized, mode: "insensitive" } },
      ],
    },
  };

  // ── Get per-stream resume pointers ────────────────────────────────
  const userResume1 = cursor?.streams[streamKey("user", 1)] ?? null;
  const userResume2 = cursor?.streams[streamKey("user", 2)] ?? null;
  const userResume3 = cursor?.streams[streamKey("user", 3)] ?? null;
  const userResume6 = cursor?.streams[streamKey("user", 6)] ?? null;
  const postResume5 = cursor?.streams[streamKey("post", 5)] ?? null;
  const articleResume4 = cursor?.streams[streamKey("article", 4)] ?? null;
  const articleResume6 = cursor?.streams[streamKey("article", 6)] ?? null;
  const collectionResume7 = cursor?.streams[streamKey("collection", 7)] ?? null;
  const collectionResume8 = cursor?.streams[streamKey("collection", 8)] ?? null;
  const playlistResume9 = cursor?.streams[streamKey("playlist", 9)] ?? null;
  const playlistResume10 = cursor?.streams[streamKey("playlist", 10)] ?? null;
  // Phase 2B typo-tier resumes.
  const userTypoResume11 = cursor?.streams[streamKey("user", 11)] ?? null;
  const postTypoResume12 = cursor?.streams[streamKey("post", 12)] ?? null;
  const articleTypoResume13 = cursor?.streams[streamKey("article", 13)] ?? null;
  const collectionTypoResume14 = cursor?.streams[streamKey("collection", 14)] ?? null;
  const playlistTypoResume15 = cursor?.streams[streamKey("playlist", 15)] ?? null;

  const PER_STREAM_TAKE = limit + 1;

  // Empty result types (for feature-flag-disabled streams).
  const emptyCollections: Array<{
    id: string; name: string; description: string | null;
    updatedAt: Date;
    owner: { id: string; fullName: string; username: string; avatarColor: string | null; avatarUrl: string | null; isVerified: boolean; };
    _count: { items: number; };
  }> = [];
  const emptyPlaylists: Array<{
    id: string; name: string; slug: string; description: string | null;
    coverImage: string | null; updatedAt: Date;
    owner: { id: string; fullName: string; username: string; avatarColor: string | null; avatarUrl: string | null; isVerified: boolean; };
    _count: { items: number; };
  }> = [];

  const userSelect = {
    id: true,
    fullName: true,
    username: true,
    avatarColor: true,
    avatarUrl: true,
    isVerified: true,
    createdAt: true,
  };

  const postSelect = {
    id: true,
    content: true,
    createdAt: true,
    updatedAt: true,
    author: {
      select: {
        id: true, fullName: true, username: true,
        avatarColor: true, avatarUrl: true, isVerified: true,
      },
    },
    _count: { select: { likes: true, comments: true, views: true } },
  };

  const articleSelect = {
    id: true,
    title: true,
    excerpt: true,
    coverImage: true,
    videoUrl: true,
    imageZoom: true,
    imagePositionX: true,
    imagePositionY: true,
    publishedAt: true,
    readingTime: true,
    author: {
      select: {
        id: true, fullName: true, username: true,
        avatarColor: true, avatarUrl: true, isVerified: true,
      },
    },
    _count: { select: { likes: true, comments: true, views: true } },
  };

  const collectionSelect = {
    id: true,
    name: true,
    description: true,
    updatedAt: true,
    owner: {
      select: {
        id: true, fullName: true, username: true,
        avatarColor: true, avatarUrl: true, isVerified: true,
      },
    },
    _count: { select: { items: true } },
  };

  const playlistSelect = {
    id: true,
    name: true,
    slug: true,
    description: true,
    coverImage: true,
    updatedAt: true,
    owner: {
      select: {
        id: true, fullName: true, username: true,
        avatarColor: true, avatarUrl: true, isVerified: true,
      },
    },
    _count: { select: { items: true } },
  };

  // ── Phase 2B — Typo-tier raw SQL fragments ────────────────────────
  // Prisma doesn't natively support pg_trgm's `%` operator. We use
  // `Prisma.sql` (raw SQL) to add the `column % $query` filter. The
  // `searchText` key is a Prisma convention for raw WHERE extensions.
  const { Prisma } = await import("@prisma/client");

  // Helper: build a raw SQL fragment for `column % $query`.
  // Returns a Prisma.sql that can be added to a where clause via the
  // `searchText` extension. We use Prisma's `Prisma.sql` tagged template
  // for safe parameter binding.
  //
  // IMPORTANT: this is only invoked when pg_trgm is available (PostgreSQL
  // production). For SQLite dev, the route falls back to skipping typo
  // tiers (the streams return empty arrays).
  const isPostgres = process.env.DATABASE_URL?.startsWith("postgres") ?? false;

  // ── Parallel search + count queries ──────────────────────────────
  // 16 streams (11 Phase 2A + 5 Phase 2B typo) + 5 count queries = 21
  // queries, all parallel. Each query is bounded by `(limit + 1)` rows.
  //
  // For typo-tier streams, we use `$queryRaw` to inject the pg_trgm
  // `%` operator. The query returns the same shape as the findMany
  // select + a `relevance` column (the similarity score).
  const [
    usersRank1, usersRank2, usersRank3, usersRank6,
    posts,
    articlesRank4, articlesRank6,
    collectionsRank7, collectionsRank8,
    playlistsRank9, playlistsRank10,
    userCount, postCount, articleCount, collectionCount, playlistCount,
  ] = await Promise.all([
    db.user.findMany({
      where: withStreamResume(userRank1Where, ENTITY_TS_FIELD.user, userResume1),
      take: PER_STREAM_TAKE,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      select: userSelect,
    }),
    db.user.findMany({
      where: withStreamResume(userRank2Where, ENTITY_TS_FIELD.user, userResume2),
      take: PER_STREAM_TAKE,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      select: userSelect,
    }),
    db.user.findMany({
      where: withStreamResume(userRank3Where, ENTITY_TS_FIELD.user, userResume3),
      take: PER_STREAM_TAKE,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      select: userSelect,
    }),
    db.user.findMany({
      where: withStreamResume(userRank6Where, ENTITY_TS_FIELD.user, userResume6),
      take: PER_STREAM_TAKE,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      select: userSelect,
    }),

    db.post.findMany({
      where: withStreamResume(postBaseWhere, ENTITY_TS_FIELD.post, postResume5),
      take: PER_STREAM_TAKE,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      select: postSelect,
    }).catch(() => []) as Promise<typeof posts>,

    db.article.findMany({
      where: withStreamResume(articleRank4Where, ENTITY_TS_FIELD.article, articleResume4),
      take: PER_STREAM_TAKE,
      orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
      select: articleSelect,
    }),
    db.article.findMany({
      where: withStreamResume(articleRank6Where, ENTITY_TS_FIELD.article, articleResume6),
      take: PER_STREAM_TAKE,
      orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
      select: articleSelect,
    }),

    collectionsEnabled
      ? db.collection.findMany({
          where: withStreamResume(collectionRank7Where, ENTITY_TS_FIELD.collection, collectionResume7),
          take: PER_STREAM_TAKE,
          orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
          select: collectionSelect,
        })
      : Promise.resolve(emptyCollections),
    collectionsEnabled
      ? db.collection.findMany({
          where: withStreamResume(collectionRank8Where, ENTITY_TS_FIELD.collection, collectionResume8),
          take: PER_STREAM_TAKE,
          orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
          select: collectionSelect,
        })
      : Promise.resolve(emptyCollections),

    playlistsEnabled
      ? db.playlist.findMany({
          where: withStreamResume(playlistRank9Where, ENTITY_TS_FIELD.playlist, playlistResume9),
          take: PER_STREAM_TAKE,
          orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
          select: playlistSelect,
        })
      : Promise.resolve(emptyPlaylists),
    playlistsEnabled
      ? db.playlist.findMany({
          where: withStreamResume(playlistRank10Where, ENTITY_TS_FIELD.playlist, playlistResume10),
          take: PER_STREAM_TAKE,
          orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
          select: playlistSelect,
        })
      : Promise.resolve(emptyPlaylists),

    // ── Count queries ──
    db.user.count({ where: userBaseWhere }),
    db.post.count({ where: postBaseWhere }).catch(() => 0) as Promise<number>,
    db.article.count({ where: articleBaseWhere }),
    collectionsEnabled
      ? db.collection.count({ where: collectionBaseWhere })
      : Promise.resolve(0),
    playlistsEnabled
      ? db.playlist.count({ where: playlistBaseWhere })
      : Promise.resolve(0),
  ]);

  // ── Phase 2B — Typo-tier queries (PostgreSQL only) ───────────────
  // These use raw SQL to invoke pg_trgm's `%` operator. Skipped on
  // SQLite (dev DB) — the streams return empty arrays (graceful
  // degradation, no typo-tolerance in dev).
  let usersTypoRank11: typeof usersRank1 = [];
  let postsTypoRank12: typeof posts = [];
  let articlesTypoRank13: typeof articlesRank4 = [];
  let collectionsTypoRank14: typeof collectionsRank7 = [];
  let playlistsTypoRank15: typeof playlistsRank9 = [];

  if (isPostgres) {
    // Phase 2B fix — apply `similarity_threshold = 0.1` at runtime.
    // The migration's `SET similarity_threshold = 0.1` is session-scoped
    // to the migration's own connection and does NOT propagate to
    // Prisma's runtime connection pool (each pooled connection uses the
    // default `0.3`). `SET LOCAL` is transaction-scoped, so wrapping
    // the typo-tier queries in a single interactive transaction ensures
    // the threshold is applied to the SAME connection that runs the
    // `%` operator below. Lower threshold (0.1 vs default 0.3) gives
    // better recall for short queries (2-3 chars) — the route's JS
    // ranker then filters further by `relevance` as a tiebreaker.
    //
    // The outer `.catch(() => [[], ...])` preserves the existing
    // graceful-degradation behavior: if `pg_trgm` is unavailable (e.g.,
    // a dev DB where the extension wasn't installed), the SET LOCAL
    // fails AND each per-query `.catch(() => [])` would also fail —
    // the outer catch returns empty arrays for all 5 typo streams,
    // matching the pre-fix behavior exactly.
    //
    // ── PG1 fix — typo-tier resume applied in SQL ─────────────────────
    // Previously, when a cursor carried a resume pointer for a typo
    // stream (e.g. `user:11`), the route returned `Promise.resolve([])`
    // via an early-exit ternary, dropping any remaining typo-tier items
    // on page 2+. Now each typo-tier query ALWAYS executes; when a
    // resume pointer exists, an additional WHERE clause is applied to
    // the OUTER query (after wrapping the original SELECT in a subquery
    // so the computed `relevance` alias is referenceable in WHERE —
    // PostgreSQL disallows referencing SELECT aliases in the inner WHERE
    // because WHERE is evaluated before SELECT). The resume condition
    // encodes the (relevance DESC, ts DESC, id DESC) ordering as:
    //
    //   relevance < resume.relevance
    //   OR (relevance = resume.relevance AND ts < resume.ts)
    //   OR (relevance = resume.relevance AND ts = resume.ts AND id < resume.id)
    //
    // All security filters (status, moderation, blocks, isPublic, NOT
    // ILIKE) remain INSIDE the inner subquery at the DB level — the
    // resume condition only narrows the already-filtered candidate set.
    // The outer `.catch(() => [])` per-query and the outer-transaction
    // `.catch(() => [[], ...])` preserve graceful degradation.
    //
    // ── PG17 GUC rename fix ───────────────────────────────────────────
    // PostgreSQL 17 (released 2024-09) RENAMED the pg_trgm GUC from
    // `similarity_threshold` to `pg_trgm.similarity_threshold` (the
    // unqualified form was deprecated in PG 16 and is no longer
    // recognized on PG 17+). Without this fix, the route throws
    // `unrecognized configuration parameter "similarity_threshold"`
    // on PG 17+ (Neon production is on PG 17.11 as of 2026-09),
    // which isSchemaError() wraps as "Database schema is out of sync".
    //
    // The qualified form `pg_trgm.similarity_threshold` works on ALL
    // PostgreSQL versions that support pg_trgm (9.1+). It is the
    // future-proof + portable form.
    const userTypoResumeWhere = userTypoResume11
      ? Prisma.sql`WHERE (sub.relevance < ${userTypoResume11.relevance} OR (sub.relevance = ${userTypoResume11.relevance} AND sub."createdAt" < ${new Date(userTypoResume11.ts)}) OR (sub.relevance = ${userTypoResume11.relevance} AND sub."createdAt" = ${new Date(userTypoResume11.ts)} AND sub.id < ${userTypoResume11.id}))`
      : Prisma.empty;
    const postTypoResumeWhere = postTypoResume12
      ? Prisma.sql`WHERE (sub.relevance < ${postTypoResume12.relevance} OR (sub.relevance = ${postTypoResume12.relevance} AND sub."createdAt" < ${new Date(postTypoResume12.ts)}) OR (sub.relevance = ${postTypoResume12.relevance} AND sub."createdAt" = ${new Date(postTypoResume12.ts)} AND sub.id < ${postTypoResume12.id}))`
      : Prisma.empty;
    const articleTypoResumeWhere = articleTypoResume13
      ? Prisma.sql`WHERE (sub.relevance < ${articleTypoResume13.relevance} OR (sub.relevance = ${articleTypoResume13.relevance} AND sub."publishedAt" < ${new Date(articleTypoResume13.ts)}) OR (sub.relevance = ${articleTypoResume13.relevance} AND sub."publishedAt" = ${new Date(articleTypoResume13.ts)} AND sub.id < ${articleTypoResume13.id}))`
      : Prisma.empty;
    const collectionTypoResumeWhere = collectionTypoResume14
      ? Prisma.sql`WHERE (sub.relevance < ${collectionTypoResume14.relevance} OR (sub.relevance = ${collectionTypoResume14.relevance} AND sub."updatedAt" < ${new Date(collectionTypoResume14.ts)}) OR (sub.relevance = ${collectionTypoResume14.relevance} AND sub."updatedAt" = ${new Date(collectionTypoResume14.ts)} AND sub.id < ${collectionTypoResume14.id}))`
      : Prisma.empty;
    const playlistTypoResumeWhere = playlistTypoResume15
      ? Prisma.sql`WHERE (sub.relevance < ${playlistTypoResume15.relevance} OR (sub.relevance = ${playlistTypoResume15.relevance} AND sub."updatedAt" < ${new Date(playlistTypoResume15.ts)}) OR (sub.relevance = ${playlistTypoResume15.relevance} AND sub."updatedAt" = ${new Date(playlistTypoResume15.ts)} AND sub.id < ${playlistTypoResume15.id}))`
      : Prisma.empty;

    const typoResults = await db.$transaction(async (tx) => {
      await tx.$executeRaw`SET LOCAL pg_trgm.similarity_threshold = 0.1`;
      return Promise.all([
        // user:11 — typo match on username OR fullName.
        // PG1 fix: always execute; resume condition applied in outer WHERE.
        tx.$queryRaw<Array<{ id: string; fullName: string; username: string; avatarColor: string | null; avatarUrl: string | null; isVerified: boolean; createdAt: Date; relevance: number }>>`
          SELECT * FROM (
            SELECT u.id, u."fullName", u.username, u."avatarColor", u."avatarUrl", u."isVerified", u."createdAt",
                   GREATEST(similarity(u."usernameNormalized", ${qNormalized}), similarity(u."fullNameNormalized", ${qNormalized})) AS relevance
            FROM "User" u
            WHERE u.status = 'ACTIVE'
              AND (u."usernameNormalized" % ${qNormalized} OR u."fullNameNormalized" % ${qNormalized})
              AND NOT (u."usernameNormalized" ILIKE ${'%' + qNormalized + '%'} OR u."fullNameNormalized" ILIKE ${'%' + qNormalized + '%'})
              ${blockedAuthorIds.size > 0 ? Prisma.sql`AND u.id NOT IN (${Prisma.join([...blockedAuthorIds])})` : Prisma.empty}
          ) sub
          ${userTypoResumeWhere}
          ORDER BY sub.relevance DESC, sub."createdAt" DESC, sub.id DESC
          LIMIT ${PER_STREAM_TAKE}
        `.catch(() => []),
        // post:12 — typo match on content.
        // PG1 fix: always execute; resume condition applied in outer WHERE.
        tx.$queryRaw<Array<{ id: string; content: string; createdAt: Date; updatedAt: Date; authorId: string; relevance: number; author: any; _count: any }>>`
          SELECT * FROM (
            SELECT p.id, p.content, p."createdAt", p."updatedAt", p."authorId",
                   similarity(p."contentNormalized", ${qNormalized}) AS relevance
            FROM "Post" p
            WHERE p."moderationStatus" = 'APPROVED'
              AND p."contentNormalized" % ${qNormalized}
              AND NOT p."contentNormalized" ILIKE ${'%' + qNormalized + '%'}
              ${blockedAuthorIds.size > 0 ? Prisma.sql`AND p."authorId" NOT IN (${Prisma.join([...blockedAuthorIds])})` : Prisma.empty}
          ) sub
          ${postTypoResumeWhere}
          ORDER BY sub.relevance DESC, sub."createdAt" DESC, sub.id DESC
          LIMIT ${PER_STREAM_TAKE}
        `.catch(() => []),
        // article:13 — typo match on title/excerpt/content.
        // PG1 fix: always execute; resume condition applied in outer WHERE.
        tx.$queryRaw<Array<{ id: string; title: string; excerpt: string | null; coverImage: string | null; videoUrl: string | null; imageZoom: number | null; imagePositionX: number | null; imagePositionY: number | null; publishedAt: Date | null; readingTime: number; authorId: string; relevance: number; author: any; _count: any }>>`
          SELECT * FROM (
            SELECT a.id, a.title, a.excerpt, a."coverImage", a."videoUrl",
                   a."imageZoom", a."imagePositionX", a."imagePositionY",
                   a."publishedAt", a."readingTime", a."authorId",
                   GREATEST(
                     similarity(a."titleNormalized", ${qNormalized}),
                     similarity(COALESCE(a."excerptNormalized", ''), ${qNormalized}),
                     similarity(a."contentNormalized", ${qNormalized})
                   ) AS relevance
            FROM "Article" a
            WHERE a.status = 'PUBLISHED' AND a."moderationStatus" = 'APPROVED'
              AND (a."titleNormalized" % ${qNormalized} OR a."excerptNormalized" % ${qNormalized} OR a."contentNormalized" % ${qNormalized})
              AND NOT (a."titleNormalized" ILIKE ${'%' + qNormalized + '%'} OR a."excerptNormalized" ILIKE ${'%' + qNormalized + '%'} OR a."contentNormalized" ILIKE ${'%' + qNormalized + '%'})
              ${blockedAuthorIds.size > 0 ? Prisma.sql`AND a."authorId" NOT IN (${Prisma.join([...blockedAuthorIds])})` : Prisma.empty}
          ) sub
          ${articleTypoResumeWhere}
          ORDER BY sub.relevance DESC, sub."publishedAt" DESC, sub.id DESC
          LIMIT ${PER_STREAM_TAKE}
        `.catch(() => []),
        // collection:14 — typo match on name/description.
        // PG1 fix: always execute; resume condition applied in outer WHERE.
        collectionsEnabled
          ? tx.$queryRaw<Array<{ id: string; name: string; description: string | null; updatedAt: Date; ownerId: string; relevance: number; owner: any; _count: any }>>`
            SELECT * FROM (
              SELECT c.id, c.name, c.description, c."updatedAt", c."ownerId",
                     GREATEST(similarity(c."nameNormalized", ${qNormalized}), similarity(COALESCE(c."descriptionNormalized", ''), ${qNormalized})) AS relevance
              FROM "Collection" c
              WHERE c."isPublic" = true
                AND (c."nameNormalized" % ${qNormalized} OR c."descriptionNormalized" % ${qNormalized})
                AND NOT (c."nameNormalized" ILIKE ${'%' + qNormalized + '%'} OR c."descriptionNormalized" ILIKE ${'%' + qNormalized + '%'})
            ) sub
            ${collectionTypoResumeWhere}
            ORDER BY sub.relevance DESC, sub."updatedAt" DESC, sub.id DESC
            LIMIT ${PER_STREAM_TAKE}
          `.catch(() => [])
          : Promise.resolve([]),
        // playlist:15 — typo match on name/description.
        // PG1 fix: always execute; resume condition applied in outer WHERE.
        playlistsEnabled
          ? tx.$queryRaw<Array<{ id: string; name: string; slug: string; description: string | null; coverImage: string | null; updatedAt: Date; ownerId: string; relevance: number; owner: any; _count: any }>>`
            SELECT * FROM (
              SELECT p.id, p.name, p.slug, p.description, p."coverImage", p."updatedAt", p."ownerId",
                     GREATEST(similarity(p."nameNormalized", ${qNormalized}), similarity(COALESCE(p."descriptionNormalized", ''), ${qNormalized})) AS relevance
              FROM "Playlist" p
              WHERE p."isPublic" = true
                AND (p."nameNormalized" % ${qNormalized} OR p."descriptionNormalized" % ${qNormalized})
                AND NOT (p."nameNormalized" ILIKE ${'%' + qNormalized + '%'} OR p."descriptionNormalized" ILIKE ${'%' + qNormalized + '%'})
            ) sub
            ${playlistTypoResumeWhere}
            ORDER BY sub.relevance DESC, sub."updatedAt" DESC, sub.id DESC
            LIMIT ${PER_STREAM_TAKE}
          `.catch(() => [])
          : Promise.resolve([]),
      ]);
    }).catch(() => [[], [], [], [], []]);
    usersTypoRank11 = typoResults[0] as any;
    postsTypoRank12 = typoResults[1] as any;
    articlesTypoRank13 = typoResults[2] as any;
    collectionsTypoRank14 = typoResults[3] as any;
    playlistsTypoRank15 = typoResults[4] as any;
  }

  // ── Phase 2B cleanup — ILIKE-based streams relevance ──────────────
  // The separate `computeRelevanceScores()` helper has been removed
  // (it was dead code: the SQL had a parameter-binding bug where the
  // `textExpr` was interpolated as a literal string rather than as a
  // SQL identifier, so every call computed `similarity('username', q)`
  // — the same value for all rows — and the catch-all swallowed the
  // result into an empty Map, leaving per-item relevance at 0 anyway).
  //
  // The ILIKE-based tiers (1-10) now uniformly use `relevance = 0`,
  // which makes the (rank ASC, relevance DESC, ts DESC, type ASC,
  // id DESC) ordering reduce to Phase 2A's (rank ASC, ts DESC, type
  // ASC, id DESC) — the deterministic per-tier ordering already
  // verified by the pagination + relevance test suites. Typo tiers
  // 11-15 still compute their own `relevance` inside the raw SQL
  // (see the typo-tier block above).
  const [userRel1, userRel2, userRel3, userRel6, postRel5, articleRel4, articleRel6, collectionRel7, collectionRel8, playlistRel9, playlistRel10] = [
    new Map<string, number>(), new Map<string, number>(), new Map<string, number>(), new Map<string, number>(),
    new Map<string, number>(), new Map<string, number>(), new Map<string, number>(),
    new Map<string, number>(), new Map<string, number>(), new Map<string, number>(), new Map<string, number>(),
  ];

  // ── Build ranked items (with per-item rank + relevance) ──────────
  const ranked: RankedItem[] = [];

  for (const u of usersRank1) {
    ranked.push({ type: "user", rank: 1, ts: u.createdAt.getTime(), id: u.id, relevance: userRel1.get(u.id) ?? 0, data: u });
  }
  for (const u of usersRank2) {
    ranked.push({ type: "user", rank: 2, ts: u.createdAt.getTime(), id: u.id, relevance: userRel2.get(u.id) ?? 0, data: u });
  }
  for (const u of usersRank3) {
    ranked.push({ type: "user", rank: 3, ts: u.createdAt.getTime(), id: u.id, relevance: userRel3.get(u.id) ?? 0, data: u });
  }
  for (const u of usersRank6) {
    ranked.push({ type: "user", rank: 6, ts: u.createdAt.getTime(), id: u.id, relevance: userRel6.get(u.id) ?? 0, data: u });
  }
  for (const p of posts) {
    ranked.push({ type: "post", rank: 5, ts: p.createdAt.getTime(), id: p.id, relevance: postRel5.get(p.id) ?? 0, data: p });
  }
  for (const a of articlesRank4) {
    ranked.push({
      type: "article",
      rank: 4,
      ts: a.publishedAt ? a.publishedAt.getTime() : 0,
      id: a.id,
      relevance: articleRel4.get(a.id) ?? 0,
      data: a,
    });
  }
  for (const a of articlesRank6) {
    ranked.push({
      type: "article",
      rank: 6,
      ts: a.publishedAt ? a.publishedAt.getTime() : 0,
      id: a.id,
      relevance: articleRel6.get(a.id) ?? 0,
      data: a,
    });
  }
  for (const c of collectionsRank7) {
    ranked.push({ type: "collection", rank: 7, ts: c.updatedAt.getTime(), id: c.id, relevance: collectionRel7.get(c.id) ?? 0, data: c });
  }
  for (const c of collectionsRank8) {
    ranked.push({ type: "collection", rank: 8, ts: c.updatedAt.getTime(), id: c.id, relevance: collectionRel8.get(c.id) ?? 0, data: c });
  }
  for (const p of playlistsRank9) {
    ranked.push({ type: "playlist", rank: 9, ts: p.updatedAt.getTime(), id: p.id, relevance: playlistRel9.get(p.id) ?? 0, data: p });
  }
  for (const p of playlistsRank10) {
    ranked.push({ type: "playlist", rank: 10, ts: p.updatedAt.getTime(), id: p.id, relevance: playlistRel10.get(p.id) ?? 0, data: p });
  }

  // Phase 2B — typo-tier items (relevance already computed in the raw SQL).
  for (const u of usersTypoRank11 as any[]) {
    ranked.push({ type: "user", rank: 11, ts: u.createdAt.getTime(), id: u.id, relevance: u.relevance ?? 0, data: u });
  }
  for (const p of postsTypoRank12 as any[]) {
    ranked.push({ type: "post", rank: 12, ts: p.createdAt.getTime(), id: p.id, relevance: p.relevance ?? 0, data: p });
  }
  for (const a of articlesTypoRank13 as any[]) {
    ranked.push({ type: "article", rank: 13, ts: a.publishedAt ? new Date(a.publishedAt as any).getTime() : 0, id: a.id, relevance: a.relevance ?? 0, data: a });
  }
  for (const c of collectionsTypoRank14 as any[]) {
    ranked.push({ type: "collection", rank: 14, ts: new Date(c.updatedAt as any).getTime(), id: c.id, relevance: c.relevance ?? 0, data: c });
  }
  for (const p of playlistsTypoRank15 as any[]) {
    ranked.push({ type: "playlist", rank: 15, ts: new Date(p.updatedAt as any).getTime(), id: p.id, relevance: p.relevance ?? 0, data: p });
  }

  // ── Global deterministic sort ─────────────────────────────────────
  ranked.sort(compareRanked);

  // ── Deduplicate (defensive — guards against concurrent inserts) ───
  const seen = new Set<string>();
  const deduped = ranked.filter((item) => {
    const key = `${item.type}:${item.id}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const trimmed = deduped.slice(0, limit);
  const hasMore = deduped.length > limit;

  // ── Build the next cursor ────────────────────────────────────────
  const nextStreams: Record<string, StreamResume> = {
    ...(cursor?.streams ?? {}),
  };

  function updateStreamResume(type: EntityType, rank: number) {
    const items = trimmed.filter((item) => item.type === type && item.rank === rank);
    if (items.length === 0) return;
    const last = items[items.length - 1];
    nextStreams[streamKey(type, rank)] = {
      relevance: last.relevance,
      ts: last.ts,
      id: last.id,
    };
  }
  updateStreamResume("user", 1);
  updateStreamResume("user", 2);
  updateStreamResume("user", 3);
  updateStreamResume("user", 6);
  updateStreamResume("post", 5);
  updateStreamResume("article", 4);
  updateStreamResume("article", 6);
  updateStreamResume("collection", 7);
  updateStreamResume("collection", 8);
  updateStreamResume("playlist", 9);
  updateStreamResume("playlist", 10);
  updateStreamResume("user", 11);
  updateStreamResume("post", 12);
  updateStreamResume("article", 13);
  updateStreamResume("collection", 14);
  updateStreamResume("playlist", 15);

  const nextCursor = hasMore
    ? encodeCursor({
        q: qNormalized,
        v: SEARCH_CURSOR_VERSION, // Phase 2D — internal version for compatibility
        streams: nextStreams,
      })
    : null;

  // ── Build the response ───────────────────────────────────────────
  const finalUserIds = trimmed
    .filter((item) => item.type === "user")
    .map((item) => item.id);
  const [viewerFollows, followedBy] = finalUserIds.length > 0
    ? await Promise.all([
        db.follow.findMany({
          where: { followerId: user.id, followingId: { in: finalUserIds } },
          select: { followingId: true },
        }),
        db.follow.findMany({
          where: { followerId: { in: finalUserIds }, followingId: user.id },
          select: { followerId: true },
        }),
      ])
    : [[], []];
  const viewerFollowsSet = new Set(viewerFollows.map((f) => f.followingId));
  const followedBySet = new Set(followedBy.map((f) => f.followerId));

  const results: SearchResult[] = trimmed.map((item) => {
    if (item.type === "user") {
      const u = item.data;
      return {
        type: "user",
        rank: item.rank,
        data: {
          id: u.id,
          fullName: u.fullName,
          username: u.username,
          avatarColor: u.avatarColor,
          avatarUrl: u.avatarUrl,
          isVerified: u.isVerified,
          isFollowing: viewerFollowsSet.has(u.id),
          isFollowedBy: followedBySet.has(u.id),
        },
      };
    }
    if (item.type === "post") {
      const p = item.data;
      return {
        type: "post",
        rank: item.rank,
        data: {
          id: p.id,
          content: p.content,
          createdAt: p.createdAt instanceof Date ? p.createdAt.toISOString() : new Date(p.createdAt).toISOString(),
          updatedAt: p.updatedAt instanceof Date ? p.updatedAt.toISOString() : new Date(p.updatedAt).toISOString(),
          author: p.author,
          likeCount: p._count?.likes ?? 0,
          commentCount: p._count?.comments ?? 0,
          viewCount: p._count?.views ?? 0,
          isLiked: false,
        },
      };
    }
    if (item.type === "article") {
      const a = item.data;
      const publishedAt = a.publishedAt instanceof Date ? a.publishedAt : (a.publishedAt ? new Date(a.publishedAt) : null);
      return {
        type: "article",
        rank: item.rank,
        data: {
          id: a.id,
          title: a.title,
          excerpt: a.excerpt,
          coverImage: a.coverImage,
          videoUrl: a.videoUrl,
          imageZoom: a.imageZoom,
          imagePositionX: a.imagePositionX,
          imagePositionY: a.imagePositionY,
          publishedAt: publishedAt?.toISOString() ?? null,
          readingTime: a.readingTime,
          author: a.author,
          likeCount: a._count?.likes ?? 0,
          commentCount: a._count?.comments ?? 0,
          viewCount: a._count?.views ?? 0,
          shareCount: 0,
          isLiked: false,
        },
      };
    }
    if (item.type === "collection") {
      const c = item.data;
      const updatedAt = c.updatedAt instanceof Date ? c.updatedAt : new Date(c.updatedAt);
      return {
        type: "collection",
        rank: item.rank,
        data: {
          id: c.id,
          name: c.name,
          description: c.description,
          isPublic: true,
          updatedAt: updatedAt.toISOString(),
          owner: c.owner,
          itemCount: c._count?.items ?? 0,
        },
      };
    }
    const p = item.data;
    const updatedAt = p.updatedAt instanceof Date ? p.updatedAt : new Date(p.updatedAt);
    return {
      type: "playlist",
      rank: item.rank,
      data: {
        id: p.id,
        name: p.name,
        slug: p.slug,
        description: p.description,
        coverImage: p.coverImage,
        isPublic: true,
        updatedAt: updatedAt.toISOString(),
        owner: p.owner,
        itemCount: p._count?.items ?? 0,
      },
    };
  });

  return ok({
    results,
    counts: {
      users: userCount,
      posts: postCount,
      articles: articleCount,
      collections: collectionCount,
      playlists: playlistCount,
    },
    pagination: {
      nextCursor,
      hasMore,
    },
  });
});
