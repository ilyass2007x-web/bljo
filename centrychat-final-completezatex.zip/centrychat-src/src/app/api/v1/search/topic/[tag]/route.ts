import { apiHandler, ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/database";
import type { Prisma } from "@prisma/client";
import { parsePostContent } from "@/lib/posts/parser";
import { getBlockedAuthorIds } from "@/lib/block";

/**
 * GET /api/v1/search/topic/[tag]?limit=20&cursor=...
 * ----------------------------------------------------
 * Returns posts + published articles that contain a specific hashtag
 * (topic). This is the data behind the public /topics/[tag] page + the
 * in-app hashtag results view.
 *
 * The `tag` URL parameter is the hashtag WITHOUT the leading `#` —
 * the URL is /api/v1/search/topic/football (not /api/v1/search/topic/%23football).
 *
 * Matching (spec §14):
 *   - Posts:    the post's content contains `#<tag>` (case-insensitive).
 *   - Articles: the article's title, excerpt, OR content contains
 *               `#<tag>` (case-insensitive). Only PUBLISHED articles.
 *
 * The hashtag is extracted using the existing parsePostContent parser
 * (src/lib/posts/parser.ts) on the CLIENT side after fetching — BUT for
 * the DB query, we use `contains: "#<tag>"` (case-insensitive) which is
 * a fast ILIKE query that doesn't require a separate hashtags table.
 * This is a pragmatic approach: it returns all content that mentions
 * the hashtag anywhere, including in the middle of other text. For
 * cleaner hashtag-only matching, a future iteration can add a
 * `PostHashtag` join table with a GIN index.
 *
 * Auth: optional. The endpoint works for both logged-in (returns
 * isLiked) and logged-out users (public topic browsing).
 *
 * Response: { tag, items: UnifiedFeedItem[], nextCursor: string | null }
 */

const POST_SELECT = {
  id: true,
  content: true,
  createdAt: true,
  updatedAt: true,
  authorId: true,
  author: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const satisfies Prisma.PostSelect;

const ARTICLE_SELECT = {
  id: true,
  title: true,
  excerpt: true,
  coverImage: true,
  videoUrl: true,
  publishedAt: true,
  readingTime: true,
  author: {
    select: {
      id: true,
      fullName: true,
      username: true,
      avatarColor: true,
      avatarUrl: true,
      isVerified: true,
    },
  },
  _count: {
    select: {
      likes: true,
      comments: true,
      views: true,
    },
  },
} as const satisfies Prisma.ArticleSelect;

interface CursorData {
  ts: string;
  id: string;
  type: "post" | "article";
}

function decodeCursor(raw: string | null): CursorData | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(
      Buffer.from(raw, "base64").toString("utf-8")
    ) as Partial<CursorData>;
    if (!parsed.ts || !parsed.id || !parsed.type) return null;
    if (parsed.type !== "post" && parsed.type !== "article") return null;
    return { ts: parsed.ts, id: parsed.id, type: parsed.type };
  } catch {
    return null;
  }
}

function encodeCursor(c: CursorData): string {
  return Buffer.from(JSON.stringify(c), "utf-8").toString("base64");
}

export const GET = apiHandler(async (req, ctx) => {
  const { tag: rawTag } = await ctx.params;
  if (!rawTag || typeof rawTag !== "string") {
    return ok({ tag: "", items: [], nextCursor: null });
  }

  // Normalize the tag: strip leading `#`, lowercase, trim.
  // The hashtag regex in parser.ts allows letters/digits/underscore.
  const tag = rawTag.replace(/^#/, "").trim().toLowerCase();
  if (!tag) {
    return ok({ tag: "", items: [], nextCursor: null });
  }

  // Build the search patterns. We search for `#<tag>` (with the #) to
  // reduce false positives (e.g. searching for "football" shouldn't
  // match a post that just says "football" without the #). For articles
  // (which have richer text), we also match the bare word in the title.
  const hashtagPattern = `#${tag}`;

  // Optional auth — works for logged-out users too (public topic browsing).
  const viewer = await getCurrentUser();

  // ── Block filtering (Phase 1 — Security Correctness) ─────────────
  // For authenticated viewers only. Anonymous viewers get an empty Set
  // (no block filtering applies — there is no viewer to filter for).
  // Single query; the resulting IDs are pushed into the post/article
  // WHERE clauses below as `authorId: { notIn: [...] }` so filtering
  // happens at the DB level (no N+1, no pagination leak).
  const blockedAuthorIds = await getBlockedAuthorIds(viewer?.id);
  const blockedAuthorFilter = blockedAuthorIds.size > 0
    ? { authorId: { notIn: [...blockedAuthorIds] } }
    : {};

  const url = new URL(req.url);
  const limit = Math.min(Math.max(Number(url.searchParams.get("limit") ?? "20"), 1), 50);
  const cursorParam = url.searchParams.get("cursor");
  const cursor = decodeCursor(cursorParam);

  const cursorDate = cursor ? new Date(cursor.ts) : null;

  // ── Parallel queries: posts + articles with the hashtag ──────────
  // Moderation gate (Phase 1 — Security Correctness): only APPROVED
  // posts + (PUBLISHED + APPROVED) articles are returned. Matches the
  // existing behavior of /api/v1/search/all + /api/v1/feed/unified.
  // Previously this route returned PENDING_MODERATION / REJECTED
  // content to both anonymous + authenticated viewers.
  const postWhere: Prisma.PostWhereInput = {
    content: { contains: hashtagPattern, mode: "insensitive" },
    moderationStatus: "APPROVED",
    ...blockedAuthorFilter,
    ...(cursor && cursorDate
      ? {
          OR: [
            { createdAt: { lt: cursorDate } },
            { createdAt: cursorDate, id: { lt: cursor.id } },
          ],
        }
      : {}),
  };

  const articleWhere: Prisma.ArticleWhereInput = {
    status: "PUBLISHED",
    moderationStatus: "APPROVED",
    OR: [
      { title: { contains: hashtagPattern, mode: "insensitive" } },
      { excerpt: { contains: hashtagPattern, mode: "insensitive" } },
      { content: { contains: hashtagPattern, mode: "insensitive" } },
    ],
    publishedAt: { not: null },
    ...blockedAuthorFilter,
    ...(cursor && cursorDate
      ? {
          OR: [
            { publishedAt: { lt: cursorDate } },
            { publishedAt: cursorDate, id: { lt: cursor.id } },
          ],
        }
      : {}),
  };

  const [postRows, articleRows] = await Promise.all([
    db.post.findMany({
      where: postWhere,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: limit + 1,
      select: POST_SELECT,
    }),
    db.article.findMany({
      where: articleWhere,
      orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
      take: limit + 1,
      select: ARTICLE_SELECT,
    }),
  ]);

  // ── Merge + sort by timestamp DESC ─────────────────────────────────
  type TaggedItem = {
    type: "post" | "article";
    ts: Date;
    id: string;
    raw: any;
  };

  const tagged: TaggedItem[] = [
    ...postRows.map((p) => ({
      type: "post" as const,
      ts: p.createdAt,
      id: p.id,
      raw: p,
    })),
    ...articleRows.map((a) => ({
      type: "article" as const,
      ts: a.publishedAt ?? new Date(0),
      id: a.id,
      raw: a,
    })),
  ];

  tagged.sort((a, b) => {
    const diff = b.ts.getTime() - a.ts.getTime();
    if (diff !== 0) return diff;
    return b.id < a.id ? -1 : b.id > a.id ? 1 : 0;
  });

  const hasMore = tagged.length > limit;
  const page = hasMore ? tagged.slice(0, limit) : tagged;

  // ── Hydrate with share counts + isLiked (batched) ──────────────────
  const postIds = page.filter((i) => i.type === "post").map((i) => i.id);
  const articleIds = page.filter((i) => i.type === "article").map((i) => i.id);

  const [postShareRows, articleShareRows, postLikedRows, articleLikedRows] = await Promise.all([
    postIds.length > 0
      ? db.postInteraction.groupBy({
          by: ["postId"],
          where: { postId: { in: postIds }, type: "SHARE" },
          _count: { _all: true },
        })
      : [],
    articleIds.length > 0
      ? db.articleInteraction.groupBy({
          by: ["articleId"],
          where: { articleId: { in: articleIds }, type: "SHARE" },
          _count: { _all: true },
        })
      : [],
    viewer && postIds.length > 0
      ? db.postLike.findMany({
          where: { userId: viewer.id, postId: { in: postIds } },
          select: { postId: true },
        })
      : [],
    viewer && articleIds.length > 0
      ? db.articleLike.findMany({
          where: { userId: viewer.id, articleId: { in: articleIds } },
          select: { articleId: true },
        })
      : [],
  ]);

  type ShareRow = { postId?: string; articleId?: string; _count: { _all: number } };
  const postShareMap = new Map(
    (postShareRows as any as ShareRow[]).map((s) => [s.postId!, s._count._all])
  );
  const articleShareMap = new Map(
    (articleShareRows as any as ShareRow[]).map((s) => [s.articleId!, s._count._all])
  );
  const postLikedSet = new Set((postLikedRows as any[]).map((l) => l.postId));
  const articleLikedSet = new Set((articleLikedRows as any[]).map((l) => l.articleId));

  // ── Build response items ───────────────────────────────────────────
  const items = page.map((item) => {
    if (item.type === "post") {
      const p = item.raw;
      return {
        type: "post" as const,
        post: {
          id: p.id,
          content: p.content,
          createdAt: p.createdAt,
          updatedAt: p.updatedAt,
          author: {
            ...p.author,
            isFollowing: false, // not batched for topic page (perf)
            isFollowedBy: false,
          },
          likeCount: p._count.likes,
          commentCount: p._count.comments,
          viewCount: p._count.views,
          isLiked: postLikedSet.has(p.id),
        },
      };
    }
    const a = item.raw;
    return {
      type: "article" as const,
      article: {
        id: a.id,
        title: a.title,
        excerpt: a.excerpt,
        coverImage: a.coverImage,
        videoUrl: a.videoUrl,
        publishedAt: a.publishedAt?.toISOString() ?? null,
        readingTime: a.readingTime,
        author: {
          ...a.author,
          isFollowing: false,
          isFollowedBy: false,
        },
        likeCount: a._count.likes,
        commentCount: a._count.comments,
        viewCount: a._count.views,
        shareCount: articleShareMap.get(a.id) ?? 0,
        isLiked: articleLikedSet.has(a.id),
      },
    };
  });

  const lastItem = page[page.length - 1];
  const nextCursor = hasMore && lastItem
    ? encodeCursor({
        ts: lastItem.ts.toISOString(),
        id: lastItem.id,
        type: lastItem.type,
      })
    : null;

  return ok({
    tag,
    hashtag: `#${tag}`,
    items,
    nextCursor,
  });
});

// Re-export removed: `export { parsePostContent }` violated Next.js 16's
// route file signature contract (only HTTP method exports are allowed).
// Consumers import `parsePostContent` directly from `@/lib/posts/parser` —
// this re-export was unused dead code.
