import { apiHandler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * DELETE /api/v1/search-history/:id
 * Delete a single search history entry (must belong to the current user).
 */
export const DELETE = apiHandler(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;

  // Verify ownership — never trust the client.
  const entry = await db.searchHistory.findUnique({ where: { id } });
  if (!entry || entry.userId !== user.id) {
    return ok({ deleted: false });
  }

  await db.searchHistory.delete({ where: { id } });
  return ok({ deleted: true });
});
