import { apiHandler, ok, parseJsonBody } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";

/**
 * GET /api/v1/search-history
 * Returns the current user's recent search history (private, max 20).
 */
export const GET = apiHandler(async () => {
  const user = await requireUser();
  const history = await db.searchHistory.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 20,
    select: {
      id: true,
      query: true,
      targetUserId: true,
      targetUsername: true,
      targetFullName: true,
      createdAt: true,
    },
  });
  return ok({ history });
});

/**
 * POST /api/v1/search-history
 * Save a search query to the user's history (upsert — no duplicates).
 *
 * Also logs to SearchQueryLog for aggregated admin analytics (spec §35):
 *   - The userId is recorded for the first 24 hours (so admins can see
 *     "what's being searched" + correlate with the searcher if needed
 *     for abuse investigation).
 *   - A future cleanup job anonymizes the userId after 24h.
 *   - The admin analytics endpoint ONLY returns aggregated counts —
 *     never individual user IDs (privacy by design, spec §35).
 *
 * PRIVACY (spec §35):
 *   - The query is normalized (lowercase, trimmed, max 200 chars) to
 *     enable aggregation. This means "Football" and "football" map to
 *     the same log row — useful for "trending searches".
 *   - No sensitive PII is logged beyond the user's ID + the query they
 *     typed (which is their own input).
 */
export const POST = apiHandler(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody<{
    query?: string;
    targetUserId?: string;
    targetUsername?: string;
    targetFullName?: string;
    resultCount?: number;
  }>(req);

  if (!body.query || body.query.trim().length < 1) {
    return ok({ saved: false });
  }

  const normalizedQuery = body.query.trim().toLowerCase().slice(0, 200);
  const resultCount = typeof body.resultCount === "number" ? body.resultCount : 0;

  // Upsert: if the same query exists, update the timestamp + target info.
  await db.searchHistory.upsert({
    where: {
      userId_query: {
        userId: user.id,
        query: body.query.trim(),
      },
    },
    create: {
      userId: user.id,
      query: body.query.trim(),
      targetUserId: body.targetUserId ?? null,
      targetUsername: body.targetUsername ?? null,
      targetFullName: body.targetFullName ?? null,
    },
    update: {
      targetUserId: body.targetUserId ?? null,
      targetUsername: body.targetUsername ?? null,
      targetFullName: body.targetFullName ?? null,
      createdAt: new Date(),
    },
  });

  // Best-effort log to SearchQueryLog for admin analytics. Non-fatal —
  // if this fails, the user's search history is still saved above.
  try {
    await db.searchQueryLog.create({
      data: {
        query: normalizedQuery,
        resultCount,
        hadResults: resultCount > 0,
        userId: user.id, // anonymized after 24h by a future cleanup job
      },
    });
  } catch (err) {
    logger.warn("application", "Failed to log search query for analytics", {
      error: err instanceof Error ? err.message : String(err),
    });
  }

  return ok({ saved: true });
});

/**
 * DELETE /api/v1/search-history
 * Clear ALL search history for the current user.
 *
 * NOTE: This does NOT delete the SearchQueryLog rows (those are
 * anonymized, not deleted — they power aggregated admin analytics
 * which are independent of any one user's history).
 */
export const DELETE = apiHandler(async () => {
  const user = await requireUser();
  await db.searchHistory.deleteMany({ where: { userId: user.id } });
  return ok({ cleared: true });
});
