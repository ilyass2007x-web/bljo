import { apiHandler, ok, notFound } from "@/lib/api";
import { getCurrentUser, requireUser, requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { canModerate } from "@/lib/permissions";
import { Prisma } from "@prisma/client";

/**
 * GET /api/v1/article-comments/:id
 * ----------------------------------
 * Fetch a SINGLE article comment by id, WITH its nested replies +
 * likeCount + isLiked state. Mirrors /api/v1/post-comments/:id.
 *
 * Used by the ArticleCommentsPage for DEEP-LINK navigation from a
 * notification click — when the target comment is not in the first
 * page of comments, the page fetches it directly via this endpoint
 * instead of paginating through hundreds of comments.
 *
 * AUTH:
 *   - Any logged-in user can read a comment on a PUBLISHED article.
 *   - For a comment on a DRAFT article, only the author + admins can
 *     view (the article status is checked after fetching the comment).
 *   - Logged-out visitors are NOT supported here — the public article
 *     reading page doesn't deep-link to comments, so we require auth.
 *     (The CommentsPage itself is auth-gated in the SPA.)
 *
 * PERFORMANCE (spec §25):
 *   Single findUnique on the primary key — O(log n), independent of
 *   the total comment count on the article.
 *
 * SECURITY:
 *   - The comment's articleId is returned so the client can verify it
 *     matches the article the user navigated to.
 *   - Same SELECT projection as the comments list endpoint — no email,
 *     passwordHash, etc.
 */
export const GET = apiHandler(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Comment not found.");

  const comment = await db.articleComment.findUnique({
    where: { id },
    select: COMMENT_SELECT,
  });
  if (!comment) return notFound("Comment not found.");

  // Article draft visibility check — only author + admins see comments
  // on draft articles. We need to fetch the article's status + authorId.
  const article = await db.article.findUnique({
    where: { id: comment.articleId },
    select: { status: true, authorId: true },
  });
  if (!article) return notFound("Article not found.");
  if (article.status !== "PUBLISHED") {
    const isOwner = user.id === article.authorId;
    const isAdmin = user.role === "ADMIN" || user.role === "SUPER_ADMIN";
    if (!isOwner && !isAdmin) return notFound("Comment not found.");
  }

  // Batch-fetch isLiked for the comment + all its replies.
  const allIds = new Set<string>([comment.id]);
  for (const r of comment.replies) allIds.add(r.id);
  const likedRows = await db.articleCommentLike.findMany({
    where: { userId: user.id, commentId: { in: [...allIds] } },
    select: { commentId: true },
  });
  const likedSet = new Set(likedRows.map((l) => l.commentId));

  return ok({
    comment: {
      ...comment,
      isLiked: likedSet.has(comment.id),
      replies: comment.replies.map((r) => ({ ...r, isLiked: likedSet.has(r.id) })),
    },
  });
});

// Re-export removed: `export { getCurrentUser }` violated Next.js 16's route
// file signature contract (only HTTP method exports are allowed). Consumers
// import `getCurrentUser` directly from `@/lib/auth` — this re-export was
// unused dead code.

/**
 * DELETE /api/v1/article-comments/:id
 * -----------------------------------
 * Delete an article comment (top-level OR reply at any depth).
 *
 * Mirrors /api/v1/comments/[id] (the post-comment DELETE handler).
 * Replies live in the SAME ArticleComment table as top-level comments
 * — they just have `parentCommentId` set instead of NULL. The same ID
 * space + the same DELETE handler serve both, so this endpoint works
 * for deleting comments AND replies without any special-casing.
 *
 * Authorization (server-side, source of truth):
 *   - The comment's AUTHOR can delete their own comment.
 *   - The ARTICLE'S AUTHOR can delete any comment on their own article
 *     (gives article owners moderation power over their own content,
 *     matching the post-comment deletion behavior).
 *   - MODERATOR / ADMIN / SUPER_ADMIN can delete any comment (matches
 *     the UI's `canDelete` logic in ArticleCommentsPage — admins see
 *     the trash icon on every comment). This was previously missing,
 *     causing admins to receive "Comment not found" (404 used as
 *     defense-in-depth to avoid leaking the comment's existence to
 *     non-authorized users) even though the comment existed.
 *   - Anyone else gets 404 (we don't leak the comment's existence to
 *     non-authorized users — this avoids information disclosure).
 *
 * Cascade: the Prisma schema's `onDelete: Cascade` on
 * `ArticleComment.replies` (self-relation) + `ArticleComment.likes`
 * handles cleanup of nested replies + likes automatically. Deleting a
 * parent comment removes all of its descendants in one SQL operation
 * (no N+1, no orphan rows).
 *
 * Response: { ok: true }
 */
export const DELETE = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;

  if (!id || typeof id !== "string") {
    return notFound("Comment not found.");
  }

  // Fetch the comment with the article's authorId so we can check ALL
  // ownership paths in a single query.
  const comment = await db.articleComment.findUnique({
    where: { id },
    select: {
      authorId: true,
      article: {
        select: { authorId: true },
      },
    },
  });

  if (!comment) {
    return notFound("Comment not found.");
  }

  // Authorization: comment author OR article author OR moderator/admin.
  // `canModerate` returns true for MODERATOR / ADMIN / SUPER_ADMIN
  // (any role with rank >= MODERATOR), matching the UI's `canDelete`
  // logic in article-comments-page.tsx which renders the trash button
  // for ADMIN / SUPER_ADMIN (and would also cover MODERATOR if/when
  // the UI exposes it).
  const isCommentAuthor = comment.authorId === user.id;
  const isArticleAuthor = comment.article.authorId === user.id;
  const isModerator = canModerate(user.role);

  if (!isCommentAuthor && !isArticleAuthor && !isModerator) {
    // Not authorized — return 404 to avoid leaking the comment's existence.
    return notFound("Comment not found.");
  }

  await db.articleComment.delete({ where: { id } });

  return ok({ ok: true });
});

const COMMENT_SELECT = {
  id: true,
  articleId: true,
  content: true,
  parentCommentId: true,
  createdAt: true,
  updatedAt: true,
  author: {
    select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true },
  },
  _count: { select: { likes: true } },
  replies: {
    orderBy: [{ createdAt: "asc" }, { id: "asc" }],
    select: {
      id: true,
      articleId: true,
      content: true,
      parentCommentId: true,
      createdAt: true,
      updatedAt: true,
      author: {
        select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true },
      },
      _count: { select: { likes: true } },
    },
  },
} as const satisfies Prisma.ArticleCommentSelect;
