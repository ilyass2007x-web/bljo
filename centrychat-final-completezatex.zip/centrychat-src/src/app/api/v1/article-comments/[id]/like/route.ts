import { apiHandler, ok, notFound } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { Prisma } from "@prisma/client";
import { notifyCommentLiked, notifyReplyLiked } from "@/lib/notifications";

/**
 * POST /api/v1/article-comments/:id/like
 * Toggle like on an article comment OR an article reply.
 *
 * Mirrors /api/v1/post-comments/:id/like exactly. The notification
 * branch decides between COMMENT_LIKE (top-level comment) and REPLY_LIKE
 * (reply) based on parentCommentId.
 *
 * Auth: requires verified user.
 * Response: { liked: boolean, likeCount: number }
 */
export const POST = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Comment not found.");

  // Fetch the comment WITH parentCommentId so we can detect replies.
  const comment = await db.articleComment.findUnique({
    where: { id },
    select: { id: true, authorId: true, articleId: true, parentCommentId: true },
  });
  if (!comment) return notFound("Comment not found.");

  let didCreateLike = false;

  const result = await db.$transaction(async (tx) => {
    const deleteResult = await tx.articleCommentLike.deleteMany({
      where: { commentId: id, userId: user.id },
    });
    if (deleteResult.count > 0) return { liked: false };
    try {
      await tx.articleCommentLike.create({ data: { commentId: id, userId: user.id } });
      didCreateLike = true;
      return { liked: true };
    } catch (err) {
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") return { liked: true };
      throw err;
    }
  });

  // Fire the correct notification — only on new like, never for self.
  if (didCreateLike && comment.authorId !== user.id) {
    if (comment.parentCommentId) {
      // Reply → REPLY_LIKE notification.
      void notifyReplyLiked({
        contentType: "article",
        contentId: comment.articleId,
        parentCommentId: comment.parentCommentId,
        replyId: id,
        replyAuthorId: comment.authorId,
        actorId: user.id,
        actorFullName: user.fullName,
        actorUsername: user.username,
        actorIsVerified: user.isVerified,
      });
    } else {
      // Top-level comment → COMMENT_LIKE notification.
      void notifyCommentLiked({
        contentType: "article",
        contentId: comment.articleId,
        commentId: id,
        commentAuthorId: comment.authorId,
        actorId: user.id,
        actorFullName: user.fullName,
        actorUsername: user.username,
        actorIsVerified: user.isVerified,
      });
    }
  }

  const likeCount = await db.articleCommentLike.count({ where: { commentId: id } });
  return ok({ liked: result.liked, likeCount });
});
