import { apiHandler, badRequest, ok, parseJsonBody } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { getRecommendationEngine } from "@/lib/recommendation/rule-based-engine";

/**
 * POST /api/v1/onboarding
 * Set the user's initial interests during onboarding (optional, skippable).
 */
export const POST = apiHandler(async (req) => {
  const user = await requireUser();
  const body = await parseJsonBody<{ topics?: string[] }>(req);

  if (!body.topics || !Array.isArray(body.topics)) {
    return badRequest("topics array is required");
  }

  const engine = getRecommendationEngine();
  await engine.setOnboardingInterests(user.id, body.topics);

  return ok({ completed: true });
});
