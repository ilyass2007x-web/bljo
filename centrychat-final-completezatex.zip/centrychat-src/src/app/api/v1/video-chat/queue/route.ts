import { apiHandler, ok, forbidden, badRequest, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { joinQueue, checkQueueStatus, leaveQueue } from "@/lib/video-chat/matchmaking";

/**
 * POST /api/v1/video-chat/queue
 * ------------------------------
 * Join the matchmaking queue. If a compatible partner is already waiting,
 * returns "matched" immediately with the session + peer info.
 * Otherwise returns "searching" — the client polls GET until matched/timeout.
 *
 * Body (optional): { country?: string, language?: string }
 *
 * DISABLED (TEMPORARY): When VIDEO_CHAT_ENABLED env var is not "true" (or
 * the admin has toggled the `video_chat` FeatureFlag off), every handler
 * in this file returns 403 immediately — no DB query, no matchmaking queue
 * mutation, no session creation. The user sees a clear "Video chat is
 * currently disabled." message. The matchmaking engine itself is
 * preserved — re-enabling the env var restores the feature without code
 * changes.
 */
export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  const enabled = await isVideoChatEnabled();
  if (!enabled) {
    return forbidden("Video chat is currently disabled.");
  }

  const rl = await checkRateLimit(`vc-join:${user.id}`, {
    limit: 10,
    windowSeconds: 60,
  });
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await req.json().catch(() => ({} as Record<string, unknown>));

  // Parse matchmaking preferences.
  // desiredGender: "ANY" | "MALE" | "FEMALE" (default: "ANY")
  // desiredCountry: "WORLDWIDE" or an ISO 3166-1 alpha-2 code (default: "WORLDWIDE")
  const desiredGenderRaw = typeof body.desiredGender === "string" ? body.desiredGender : "ANY";
  const desiredGender: "ANY" | "MALE" | "FEMALE" =
    desiredGenderRaw === "MALE" || desiredGenderRaw === "FEMALE" ? desiredGenderRaw : "ANY";

  let desiredCountry: string = "WORLDWIDE";
  if (typeof body.desiredCountry === "string" && body.desiredCountry !== "WORLDWIDE") {
    // Validate the country code (server-side — never trust client input).
    const { normalizeCountryCode } = await import("@/lib/countries");
    const normalized = normalizeCountryCode(body.desiredCountry);
    if (normalized) {
      desiredCountry = normalized;
    }
  }

  const result = await joinQueue(user.id, { desiredGender, desiredCountry });
  return ok(result);
});

/**
 * GET /api/v1/video-chat/queue
 * ----------------------------
 * Check the queue status. Called by the client every 2s while searching.
 *
 * Returns:
 *   - { status: "searching" } — still in queue
 *   - { status: "matched", sessionId, peer, isOfferer } — matched!
 *   - { status: "timeout" } — queue entry expired, user must re-join
 */
export const GET = apiHandler(async () => {
  const user = await requireVerifiedUser();
  const enabled = await isVideoChatEnabled();
  if (!enabled) {
    return forbidden("Video chat is currently disabled.");
  }

  const result = await checkQueueStatus(user.id);
  return ok(result);
});

/**
 * DELETE /api/v1/video-chat/queue
 * --------------------------------
 * Leave the matchmaking queue (cancel search).
 *
 * NOTE: This DELETE handler does NOT check `isVideoChatEnabled()`. When
 * the feature is disabled, the queue is empty server-side (no POSTs
 * succeed while disabled), so a stray DELETE from a stale client is
 * a no-op. Leaving the guard OUT avoids breaking cleanup for users who
 * had an active queue entry from before the disable.
 */
export const DELETE = apiHandler(async () => {
  const user = await requireVerifiedUser();
  await leaveQueue(user.id);
  return ok({ left: true });
});
