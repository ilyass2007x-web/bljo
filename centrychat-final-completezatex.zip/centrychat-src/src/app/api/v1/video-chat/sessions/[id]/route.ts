import { apiHandler, ok, notFound, forbidden, badRequest } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { db } from "@/lib/database";
import { endSession, markSessionConnected } from "@/lib/video-chat/matchmaking";

/**
 * PATCH /api/v1/video-chat/sessions/[id]
 * ---------------------------------------
 * Update a video chat session's state.
 *
 * Body: { action: "connected" | "end", connectionType?, endReason? }
 *
 * - action="connected": mark the session as connected (WebRTC established).
 *   Requires connectionType: "P2P" | "TURN".
 * - action="end": end the session. Requires endReason.
 *
 * DISABLED (TEMPORARY): When VIDEO_CHAT_ENABLED env var is not "true"
 * (or the admin has toggled the FeatureFlag off), the route returns 403
 * for `action="connected"` (no new sessions can be marked connected) but
 * still ALLOWS `action="end"` so that any pre-existing sessions can be
 * cleaned up server-side. This prevents a stuck "Connecting..." state
 * for users who had an active session at the moment of disable.
 */
export const PATCH = apiHandler(async (req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return badRequest("Invalid session id.");

  // Inspect the action FIRST — `end` is always allowed (cleanup); other
  // actions require the feature to be enabled.
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const action = typeof body.action === "string" ? body.action : "";

  if (action !== "end") {
    // DISABLED GUARD: only `end` is permitted while Video Chat is disabled.
    // `connected` and any future mutation actions require the feature flag.
    const enabled = await isVideoChatEnabled();
    if (!enabled) {
      return forbidden("Video chat is currently disabled.");
    }
  }

  // Verify participation.
  const session = await db.videoChatSession.findUnique({
    where: { id },
    select: { userAId: true, userBId: true, endedAt: true },
  });
  if (!session) return notFound("Session not found.");
  const isParticipant = session.userAId === user.id || session.userBId === user.id;
  if (!isParticipant) return forbidden("You are not a participant in this session.");

  if (action === "connected") {
    const connectionType = body.connectionType === "TURN" ? "TURN" : "P2P";
    await markSessionConnected(id, connectionType);
    return ok({ connected: true, connectionType });
  }

  if (action === "end") {
    const endReason = typeof body.endReason === "string" ? body.endReason : "unknown";
    const connectionType =
      body.connectionType === "P2P" || body.connectionType === "TURN" || body.connectionType === "FAILED"
        ? (body.connectionType as "P2P" | "TURN" | "FAILED")
        : undefined;
    await endSession(id, endReason, connectionType);
    return ok({ ended: true });
  }

  return badRequest("Invalid action. Use 'connected' or 'end'.");
});
