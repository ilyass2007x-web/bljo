import { apiHandler, ok, badRequest, rateLimited, notFound, forbidden } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { checkRateLimit, RATE_LIMITS } from "@/lib/security/rate-limit";
import { getClientIp } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import { recordAudit } from "@/lib/audit";

/**
 * POST /api/v1/video-chat/reports
 * --------------------------------
 * Report a user for abuse during a video chat session.
 *
 * Body: { sessionId, reportedId, reason, description? }
 *   - reason: HARASSMENT | NUDITY | HATE | SPAM | SCAM | OTHER
 *   - description: optional, max 1000 chars
 *
 * SECURITY:
 *   - requireVerifiedUser
 *   - VIDEO_CHAT_ENABLED env var + video_chat FeatureFlag must be enabled
 *   - Rate limited (10 reports per 10 min per user)
 *   - The reporter must be a participant in the session
 *   - The reported user must be the OTHER participant
 *
 * PRIVACY: only stores the report metadata + optional text. NEVER stores
 * video/audio/recordings.
 *
 * DISABLED (TEMPORARY): When the env var is not "true", report submission
 * is also blocked (no active sessions can exist while disabled, so there's
 * nothing to report). The endpoint returns 403 with a clear message. The
 * admin video chat reports listing endpoint (GET
 * /api/v1/admin/video-chat/reports) is NOT blocked — admins can still
 * review historical reports from before the disable.
 */
export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  // DISABLED GUARD: env var hard kill switch + admin FeatureFlag.
  const enabled = await isVideoChatEnabled();
  if (!enabled) {
    return forbidden("Video chat is currently disabled.");
  }

  const rl = await checkRateLimit(`vc-report:${user.id}`, RATE_LIMITS.report);
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const sessionId = typeof body.sessionId === "string" ? body.sessionId : "";
  const reportedId = typeof body.reportedId === "string" ? body.reportedId : "";
  const reason = typeof body.reason === "string" ? body.reason : "";
  const description = typeof body.description === "string" ? body.description.trim().slice(0, 1000) : null;

  if (!sessionId || !reportedId || !reason) {
    return badRequest("sessionId, reportedId, and reason are required.");
  }

  const validReasons = ["HARASSMENT", "NUDITY", "HATE", "SPAM", "SCAM", "OTHER"];
  if (!validReasons.includes(reason)) {
    return badRequest("Invalid reason.");
  }

  // Verify the session exists + the reporter is a participant.
  const session = await db.videoChatSession.findUnique({
    where: { id: sessionId },
    select: { userAId: true, userBId: true },
  });
  if (!session) return notFound("Session not found.");

  const isParticipant = session.userAId === user.id || session.userBId === user.id;
  if (!isParticipant) return forbidden("You are not a participant in this session.");

  // The reported user must be the OTHER participant.
  const otherUserId = session.userAId === user.id ? session.userBId : session.userAId;
  if (reportedId !== otherUserId) {
    return badRequest("Reported user must be the other participant in the session.");
  }

  const report = await db.videoChatReport.create({
    data: {
      sessionId,
      reporterId: user.id,
      reportedId,
      reason,
      description: description || null,
    },
  });

  await recordAudit({
    adminId: user.id,
    action: "videochat.report.created",
    targetType: "video_chat_report",
    targetId: report.id,
    metadata: { sessionId, reason, reportedId },
    ipAddress: getClientIp(req),
    userAgent: req.headers.get("user-agent") ?? undefined,
  });

  return ok({ report, created: true });
});
