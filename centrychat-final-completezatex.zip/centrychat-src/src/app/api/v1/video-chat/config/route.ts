import { apiHandler, ok, forbidden } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { getWebRtcConfig } from "@/lib/video-chat/config";

/**
 * GET /api/v1/video-chat/config
 * -----------------------------
 * Returns the WebRTC ICE server configuration for the current user.
 *
 * The frontend calls this once when entering the video chat view, then
 * passes the config to `new RTCPeerConnection(config)`.
 *
 * SECURITY:
 *   - requireVerifiedUser (must be logged in + email verified)
 *   - VIDEO_CHAT_ENABLED env var must be "true" AND video_chat FeatureFlag
 *     must be enabled (checked via isVideoChatEnabled()).
 *   - TURN credentials are included ONLY when the admin has enabled TURN
 *     (they're never exposed via NEXT_PUBLIC_* env vars)
 *
 * Response: { iceServers, turnEnabled, stunUrl }
 *
 * DISABLED (TEMPORARY): When VIDEO_CHAT_ENABLED env var is not "true",
 * the route returns 403 immediately — BEFORE calling getWebRtcConfig.
 * This means the TURN/STUN credentials are NEVER READ from the DB while
 * disabled — the env vars stay configured in Netlify but are simply not
 * used. The getWebRtcConfig function is preserved + the underlying
 * PlatformSetting rows (turnEnabled, turnUrl, etc.) are untouched.
 */
export const GET = apiHandler(async () => {
  const user = await requireVerifiedUser();

  // HARD KILL SWITCH (env var) + admin FeatureFlag check.
  // Spec Problem 2: the previous message "Video chat is not enabled on this
  // platform." was misleading — it sounded like a browser/device compatibility
  // issue ("platform") when it's actually a feature-flag gate (admin must
  // enable video_chat from the admin panel). Changed to a clear message that
  // tells the user/admin exactly what to do.
  const enabled = await isVideoChatEnabled();
  if (!enabled) {
    return forbidden("Video chat is currently disabled.");
  }

  // Account age check (optional — admin can set min_account_age_hours).
  // Prevents brand-new accounts from using video chat (anti-abuse).
  const minAgeHours = 0; // Could read from settings — keeping simple for MVP.
  if (minAgeHours > 0) {
    const ageMs = Date.now() - new Date(user.createdAt).getTime();
    const ageHours = ageMs / (1000 * 60 * 60);
    if (ageHours < minAgeHours) {
      return forbidden("Your account is too new to use video chat.");
    }
  }

  const config = await getWebRtcConfig();
  return ok(config);
});
