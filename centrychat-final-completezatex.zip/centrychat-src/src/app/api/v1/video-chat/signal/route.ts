import { apiHandler, ok, forbidden, badRequest, notFound, rateLimited } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { isVideoChatEnabled } from "@/lib/video-chat/enabled";
import { checkRateLimit } from "@/lib/security/rate-limit";
import { db } from "@/lib/database";
import { logger } from "@/lib/logging";
import {
  pushSignal,
  popSignals,
  type SignalType,
} from "@/lib/video-chat/signal-store";

/**
 * Video Chat Signaling — REST-based polling, shared across Netlify instances.
 * =============================================================================
 *
 * On Netlify (serverless, no persistent WebSocket), we use REST polling
 * for WebRTC signaling. This is simpler + works reliably on serverless.
 *
 * PHASE 3 FIX: The signal store was previously an in-memory `Map` per
 * process. On Netlify serverless, POST signal landed on Instance #X and
 * GET signal polled Instance #Y → the offer/answer/ICE candidates never
 * reached the other peer → both clients stuck in "Connecting...".
 *
 * The store is now backed by the project's existing Redis/cache
 * abstraction (`src/lib/cache/index.ts`) — `listPush` (atomic LPUSH +
 * EXPIRE on Upstash REST) for POST, `listRange` + `listDelete` for GET
 * drain. Per-(sessionId, recipientUserId) keys eliminate cross-user
 * read-modify-write races.
 *
 * In dev (`CACHE_PROVIDER=memory`, default), the same abstraction falls
 * back to an in-memory `Map<string, string[]>` — single-process, fine
 * for `bun run dev` where both browser tabs share the same Next.js
 * process.
 *
 * Flow:
 *   1. Offerer POSTs { type: "offer", payload: sdp } → stored in the
 *      recipient's queue.
 *   2. Answerer GETs signals → receives the offer → creates answer →
 *      POSTs { type: "answer", payload: sdp } → stored in the offerer's queue.
 *   3. Offerer GETs signals → receives the answer → setRemoteDescription.
 *   4. Both POST { type: "ice", payload: candidate } → stored in the
 *      recipient's queue. Both GET signals → addIceCandidate.
 *
 * SECURITY:
 *   - requireVerifiedUser (auth).
 *   - `video_chat` feature flag enabled (admin-opt-in).
 *   - Rate limited (120 POSTs/min/user — generous for ICE candidate floods).
 *   - The sender's userId comes from the session (NEVER from the body).
 *   - The recipient's userId is derived server-side from the
 *     VideoChatSession's userAId/userBId (the body never tells us who
 *     the recipient is — we look it up).
 *   - The signal payload is opaque — never inspected, never logged.
 */

// ── In-memory signal store ────────────────────────────────────────────
// REMOVED — was: const signalStore = new Map<string, StoredSignal[]>();
// The store is now backed by the shared cache abstraction. See
// src/lib/video-chat/signal-store.ts for the implementation.

/**
 * POST /api/v1/video-chat/signal
 * -------------------------------
 * Send a WebRTC signaling message (offer, answer, ICE candidate, end).
 *
 * Body: { sessionId, type, payload }
 *   - type: "offer" | "answer" | "ice" | "end"
 *   - payload: the SDP or ICE candidate object
 *
 * The signal is stored in the shared cache (Redis in production, memory
 * in dev) + the recipient polls GET to receive it.
 */
export const POST = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  // DISABLED (TEMPORARY): env var hard kill switch + admin FeatureFlag.
  // Returns 403 immediately — no DB query, no signal push, no rate-limit
  // counter increment. The signal store + Redis cache are preserved.
  const enabled = await isVideoChatEnabled();
  if (!enabled) {
    return forbidden("Video chat is currently disabled.");
  }

  const rl = await checkRateLimit(`vc-signal:${user.id}`, {
    limit: 120,
    windowSeconds: 60,
  });
  // M-2 fix: return proper HTTP 429 + Retry-After header (was 400 before).
  // Clients expecting standard 429 semantics will now correctly back off.
  if (!rl.ok) return rateLimited(Math.ceil((rl.resetAt - Date.now()) / 1000));

  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const sessionId = typeof body.sessionId === "string" ? body.sessionId : "";
  const type = typeof body.type === "string" ? body.type : "";
  const payload = body.payload;

  if (!sessionId || !type) return badRequest("sessionId + type are required.");
  if (!["offer", "answer", "ice", "end"].includes(type)) {
    return badRequest("Invalid signal type.");
  }

  // Verify the user is a participant in this session.
  // The session lookup also DERIVES the recipient — the body never tells
  // us who the recipient is. This prevents a malicious client from
  // writing signals into another user's queue.
  const session = await db.videoChatSession.findUnique({
    where: { id: sessionId },
    select: { userAId: true, userBId: true, endedAt: true },
  });
  if (!session) return notFound("Session not found.");
  if (session.endedAt) return badRequest("Session has ended.");

  const isParticipant = session.userAId === user.id || session.userBId === user.id;
  if (!isParticipant) return forbidden("You are not a participant in this session.");

  // Determine the recipient server-side.
  const toUserId = session.userAId === user.id ? session.userBId : session.userAId;

  // Store the signal in the shared cache. Throws on Redis failure → the
  // apiHandler catches and returns 500. The client's signal-poll catch
  // branch swallows the 500 and keeps polling (non-fatal for individual
  // polls). If Redis is down for an extended period, the WebRTC
  // connection eventually times out → "Connection lost" UI state.
  try {
    await pushSignal({
      sessionId,
      fromUserId: user.id,
      toUserId,
      type: type as SignalType,
      payload,
    });
  } catch (err) {
    // Already logged by pushSignal with safe metadata. Re-throw so the
    // route handler returns 500 (not a misleading "sent: true").
    logger.debug("application", "signal POST route propagating store failure", {
      sessionId,
      signalType: type,
      error: err instanceof Error ? err.message : "unknown",
    });
    throw err;
  }

  return ok({ sent: true });
});

/**
 * GET /api/v1/video-chat/signal?sessionId=...
 * --------------------------------------------
 * Poll for signals addressed to the current user.
 *
 * Returns ALL pending signals for this user in this session, then
 * consumes them (deletes from the queue so they're not delivered twice).
 */
export const GET = apiHandler(async (req) => {
  const user = await requireVerifiedUser();
  // DISABLED (TEMPORARY): env var hard kill switch + admin FeatureFlag.
  // Returns 403 immediately — no DB query, no signal pop. Stale clients
  // polling this endpoint while disabled get a clean 403 (their existing
  // catch branch swallows it as a non-fatal error).
  const enabled = await isVideoChatEnabled();
  if (!enabled) {
    return forbidden("Video chat is currently disabled.");
  }

  const url = new URL(req.url);
  const sessionId = url.searchParams.get("sessionId") || "";
  if (!sessionId) return badRequest("sessionId is required.");

  // Verify participation.
  const session = await db.videoChatSession.findUnique({
    where: { id: sessionId },
    select: { userAId: true, userBId: true },
  });
  if (!session) return notFound("Session not found.");
  const isParticipant = session.userAId === user.id || session.userBId === user.id;
  if (!isParticipant) return forbidden("You are not a participant in this session.");

  // Pop (consume) all signals addressed to the current user. Throws on
  // Redis failure → 500 to client. The client's signal-poll catch branch
  // swallows the 500 and keeps polling.
  let signals: Awaited<ReturnType<typeof popSignals>>;
  try {
    signals = await popSignals(sessionId, user.id);
  } catch (err) {
    logger.debug("application", "signal GET route propagating store failure", {
      sessionId,
      userId: user.id,
      error: err instanceof Error ? err.message : "unknown",
    });
    throw err;
  }

  return ok({
    signals: signals.map((s) => ({
      id: s.id,
      type: s.type,
      payload: s.payload,
      fromUserId: s.fromUserId,
    })),
  });
});
