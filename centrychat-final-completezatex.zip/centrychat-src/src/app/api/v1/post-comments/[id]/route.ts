import { apiHandler, ok, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { Prisma } from "@prisma/client";

/**
 * GET /api/v1/post-comments/:id
 * --------------------------------
 * Fetch a SINGLE post comment by id, WITH its nested replies + likeCount
 * + isLiked state. Used by the CommentsPage for DEEP-LINK navigation
 * from a notification click:
 *
 *   User clicks "@UserB commented on your post" notification
 *     → CommentsPage opens with ?commentId=<commentId>
 *     → CommentsPage fetches the first page of comments (newest first)
 *     → If the target commentId is NOT in the first page (e.g. it's
 *       comment #850 out of 1000), the page fetches it DIRECTLY via
 *       this endpoint instead of paging through all 1000.
 *     → The comment is rendered at the TOP of the list (clearly marked
 *       as "loaded for notification"), the user is scrolled to it, and
 *       it is highlighted for ~2 seconds.
 *
 * PERFORMANCE (spec §25):
 *   This endpoint is a SINGLE findUnique on the primary key — O(log n),
 *   independent of the total comment count. It does NOT paginate or
 *   scan the post's entire comment list.
 *
 * RESPONSE:
 *   - 200 with the comment (including replies + isLiked) when found.
 *   - 404 when the comment doesn't exist (or was deleted) — the client
 *     treats this as "the comment is gone, just open the post normally".
 *
 * SECURITY:
 *   - Auth required (any logged-in user can read a post comment).
 *   - The comment's postId is returned so the client can verify it
 *     matches the post the user navigated to.
 *   - The endpoint does NOT expose author email / passwordHash / etc.
 *     (same SELECT projection as the comments list endpoint).
 *
 * The shape matches the CommentDTO returned by GET /api/v1/posts/:id/comments
 * so the client's CommentThread component can consume it directly.
 */
export const GET = apiHandler(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Comment not found.");

  const comment = await db.postComment.findUnique({
    where: { id },
    select: COMMENT_SELECT,
  });
  if (!comment) return notFound("Comment not found.");

  // Batch-fetch isLiked for the comment + all its replies (single query).
  const allIds = new Set<string>([comment.id]);
  for (const r of comment.replies) allIds.add(r.id);
  const likedRows = await db.postCommentLike.findMany({
    where: { userId: user.id, commentId: { in: [...allIds] } },
    select: { commentId: true },
  });
  const likedSet = new Set(likedRows.map((l) => l.commentId));

  return ok({
    comment: {
      ...comment,
      isLiked: likedSet.has(comment.id),
      replies: comment.replies.map((r) => ({ ...r, isLiked: likedSet.has(r.id) })),
    },
  });
});

const COMMENT_SELECT = {
  id: true,
  postId: true,
  content: true,
  parentCommentId: true,
  createdAt: true,
  updatedAt: true,
  author: {
    select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true },
  },
  _count: { select: { likes: true } },
  replies: {
    orderBy: [{ createdAt: "asc" }, { id: "asc" }],
    select: {
      id: true,
      postId: true,
      content: true,
      parentCommentId: true,
      createdAt: true,
      updatedAt: true,
      author: {
        select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true },
      },
      _count: { select: { likes: true } },
    },
  },
} as const satisfies Prisma.PostCommentSelect;
