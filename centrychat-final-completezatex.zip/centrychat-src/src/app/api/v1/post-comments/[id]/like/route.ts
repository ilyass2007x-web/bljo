import { apiHandler, ok, notFound } from "@/lib/api";
import { requireVerifiedUser } from "@/lib/auth";
import { db } from "@/lib/database";
import { Prisma } from "@prisma/client";
import { notifyCommentLiked, notifyReplyLiked } from "@/lib/notifications";

/**
 * POST /api/v1/post-comments/:id/like
 * Toggle like on a post comment OR a post reply.
 *
 * Same atomic toggle pattern as post/article likes. The notification
 * branch decides between COMMENT_LIKE (for top-level comments) and
 * REPLY_LIKE (for replies) based on the comment's `parentCommentId`:
 *   - parentCommentId === null  → top-level comment → notifyCommentLiked
 *   - parentCommentId !== null  → reply              → notifyReplyLiked
 *
 * This distinction matters for two reasons:
 *   1. The notification MESSAGE differs ("liked your comment" vs
 *      "liked your reply") — prevents user confusion.
 *   2. The deep-link TARGET differs: for a reply, the client needs BOTH
 *      the parent comment id AND the reply id to expand the parent's
 *      reply list + scroll to the reply.
 *
 * Auth: requires verified user.
 * Response: { liked: boolean, likeCount: number }
 */
export const POST = apiHandler(async (_req, ctx) => {
  const user = await requireVerifiedUser();
  const { id } = await ctx.params;
  if (!id || typeof id !== "string") return notFound("Comment not found.");

  // Fetch the comment WITH parentCommentId so we can detect replies.
  const comment = await db.postComment.findUnique({
    where: { id },
    select: { id: true, authorId: true, postId: true, parentCommentId: true },
  });
  if (!comment) return notFound("Comment not found.");

  let didCreateLike = false;

  const result = await db.$transaction(async (tx) => {
    const deleteResult = await tx.postCommentLike.deleteMany({
      where: { commentId: id, userId: user.id },
    });
    if (deleteResult.count > 0) return { liked: false };
    try {
      await tx.postCommentLike.create({ data: { commentId: id, userId: user.id } });
      didCreateLike = true;
      return { liked: true };
    } catch (err) {
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002") return { liked: true };
      throw err;
    }
  });

  // Fire the correct notification — only on new like, never for self.
  if (didCreateLike && comment.authorId !== user.id) {
    if (comment.parentCommentId) {
      // It's a reply → REPLY_LIKE notification (deep-link to the reply
      // inside its parent comment's reply list).
      void notifyReplyLiked({
        contentType: "post",
        contentId: comment.postId,
        parentCommentId: comment.parentCommentId,
        replyId: id,
        replyAuthorId: comment.authorId,
        actorId: user.id,
        actorFullName: user.fullName,
        actorUsername: user.username,
        actorIsVerified: user.isVerified,
      });
    } else {
      // Top-level comment → COMMENT_LIKE notification.
      void notifyCommentLiked({
        contentType: "post",
        contentId: comment.postId,
        commentId: id,
        commentAuthorId: comment.authorId,
        actorId: user.id,
        actorFullName: user.fullName,
        actorUsername: user.username,
        actorIsVerified: user.isVerified,
      });
    }
  }

  const likeCount = await db.postCommentLike.count({ where: { commentId: id } });
  return ok({ liked: result.liked, likeCount });
});
