import { apiHandler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/database";

/**
 * POST /api/v1/presence/heartbeat
 *
 * Updates the current user's `lastSeenAt` timestamp. Called by the
 * useHeartbeat hook every 30 seconds while the user is active.
 *
 * Security:
 *   - requireUser: must be authenticated.
 *   - Only updates the CURRENT user's lastSeenAt — userId comes from
 *     the session, never from the request body.
 *
 * Performance:
 *   - Single UPDATE statement (no SELECT needed).
 *   - Called every 30s per active tab — lightweight.
 *   - The heartbeat is stopped when the tab is hidden or the user
 *     navigates away (see useHeartbeat hook).
 */
export const POST = apiHandler(async () => {
  const user = await requireUser();
  await db.user.update({
    where: { id: user.id },
    data: { lastSeenAt: new Date() },
  });
  return ok({ ok: true });
});
