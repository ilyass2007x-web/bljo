import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  // Liveness: app process is up. Do NOT depend on DB.
  return NextResponse.json({
    status: "ok",
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
}
