import { NextResponse } from "next/server";
import { db } from "@/lib/database";
import { loadBaseUrl } from "@/lib/seo/article";
import { logger } from "@/lib/logging";

/**
 * GET /sitemap-articles/[page]
 * ============================
 * Paginated article sitemap chunk.
 *
 * When the total published article count exceeds 50,000 (Google's per-file
 * limit), the main /sitemap.xml returns a <sitemapindex> pointing to
 * /sitemap-articles/1, /sitemap-articles/2, ... Each chunk returns a
 * <urlset> with up to 50,000 article URLs.
 *
 * DATABASE SAFETY:
 *   - If the DB is unreachable, returns an EMPTY <urlset> with HTTP 200
 *     (never 500 — would break Google Search Console).
 *   - Errors are logged server-side via logger.error — never exposed in
 *     the response body.
 *
 * PAGE BOUNDS:
 *   - Page 1 = articles 1..50,000 (most recent by publishedAt DESC).
 *   - Page 2 = articles 50,001..100,000.
 *   - Pages beyond the actual chunk count return an empty <urlset>.
 *
 * PERFORMANCE:
 *   - Single DB query per request: findMany with skip + take + orderBy.
 *   - Only id + publishedAt + updatedAt selected (no content/body).
 *   - Indexed by @@index([status, publishedAt]) in the schema.
 *
 * CACHING (spec §16):
 *   - We rely on Next.js's default caching. The @netlify/plugin-nextjs
 *     serves this route as a Netlify Function; the function's response
 *     is cached at the CDN level via the Cache-Control header we set
 *     here (10 minutes — fresh enough for new articles, not too
 *     aggressive to overload Neon).
 */
const PAGE_SIZE = 50_000;

interface RouteContext {
  params: Promise<{ page: string }>;
}

function escapeXml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function formatDate(d: Date | null | undefined): string | null {
  if (!d) return null;
  // ISO 8601 with milliseconds trimmed — Google prefers this format.
  return d.toISOString();
}

export async function GET(_req: Request, ctx: RouteContext) {
  const { page: pageStr } = await ctx.params;
  const pageNum = parseInt(pageStr, 10);

  // ── Validate page number ───────────────────────────────────────────
  if (!Number.isFinite(pageNum) || pageNum < 1) {
    // Invalid page → return 404. Google will not retry this URL.
    return new NextResponse("Not Found", { status: 404 });
  }

  // ── Resolve the production base URL ───────────────────────────────
  let baseUrl: string;
  try {
    baseUrl = await loadBaseUrl();
  } catch (err) {
    logger.error("seo", `sitemap-articles/${pageNum}: loadBaseUrl() failed`, {
      error: err instanceof Error ? err.message : String(err),
    });
    // Return an empty but valid <urlset> with HTTP 200.
    return new NextResponse(
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n</urlset>`,
      {
        status: 200,
        headers: {
          "Content-Type": "application/xml; charset=utf-8",
          "Cache-Control": "public, max-age=600, must-revalidate",
        },
      }
    );
  }

  // ── Fetch the article slice for this page ─────────────────────────
  const skip = (pageNum - 1) * PAGE_SIZE;
  let articles: { id: string; publishedAt: Date | null; updatedAt: Date }[] = [];
  try {
    articles = await db.article.findMany({
      where: { status: "PUBLISHED", publishedAt: { not: null } },
      select: {
        id: true,
        publishedAt: true,
        updatedAt: true,
      },
      orderBy: { publishedAt: "desc" },
      skip,
      take: PAGE_SIZE,
    });
  } catch (err) {
    logger.error("seo", `sitemap-articles/${pageNum}: article findMany failed`, {
      error: err instanceof Error ? err.message : String(err),
    });
    // DB error — return empty but valid <urlset> with HTTP 200.
    return new NextResponse(
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n</urlset>`,
      {
        status: 200,
        headers: {
          "Content-Type": "application/xml; charset=utf-8",
          "Cache-Control": "public, max-age=60, must-revalidate",
        },
      }
    );
  }

  // ── Build the XML manually (full control over output format) ──────
  // We don't use MetadataRoute.Sitemap here because we need a Route
  // Handler (not the App Router sitemap.ts convention) to support the
  // dynamic [page] param.
  const urls = articles
    .map((a) => {
      const loc = `${baseUrl}/articles/${escapeXml(a.id)}`;
      const lastmod = formatDate(a.updatedAt ?? a.publishedAt);
      const lastmodTag = lastmod ? `<lastmod>${lastmod}</lastmod>` : "";
      return `  <url>\n    <loc>${loc}</loc>\n    ${lastmodTag}\n  </url>`;
    })
    .join("\n");

  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`;

  return new NextResponse(xml, {
    status: 200,
    headers: {
      "Content-Type": "application/xml; charset=utf-8",
      // Cache 10 minutes at the CDN. New articles appear in the sitemap
      // within 10 minutes of publish — acceptable for SEO. The TTL is a
      // TRADE-OFF: shorter = fresher but more DB load; longer = less load
      // but slower discovery. 10min is a balanced default.
      "Cache-Control": "public, max-age=600, must-revalidate",
    },
  });
}
