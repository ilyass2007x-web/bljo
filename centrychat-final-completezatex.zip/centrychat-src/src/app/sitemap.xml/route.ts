import { NextResponse } from "next/server";
import { db } from "@/lib/database";
import { loadBaseUrl } from "@/lib/seo/article";
import { logger } from "@/lib/logging";

/**
 * GET /sitemap.xml
 * =================
 * EXPLICIT ROUTE HANDLER (PHASE-9 SEO audit).
 *
 * WHY THIS EXISTS INSTEAD OF `app/sitemap.ts`:
 *   The previous implementation used the Next.js `MetadataRoute.Sitemap`
 *   convention (`app/sitemap.ts`). Locally the build produced correct XML
 *   (verified: .next/server/app/sitemap.xml.body contained a valid
 *   <urlset>, .next/server/app/sitemap.xml.meta had content-type:
 *   application/xml). BUT on Netlify with `output: "standalone"` + the
 *   @netlify/plugin-nextjs plugin, the deployed /sitemap.xml was returning
 *   the SPA's index.html instead of XML — Google Search Console saw
 *   "general HTTP error" + "HTML instead of XML".
 *
 *   ROOT CAUSE: the @netlify/plugin-nextjs plugin, in some version-specific
 *   cases when `output: "standalone"` is set, does NOT properly serve the
 *   prerendered .body file for App Router metadata routes (sitemap.ts,
 *   robots.ts). It falls back to the SPA's index.html for any path it
 *   doesn't recognize as a function. This is a KNOWN issue with the
 *   plugin's handling of convention-based metadata routes.
 *
 *   FIX: convert sitemap.ts to an EXPLICIT Route Handler at
 *   `app/sitemap.xml/route.ts`. Route Handlers are unambiguously
 *   converted to Netlify Functions by the plugin — the function returns
 *   the EXACT response we code (XML with Content-Type: application/xml).
 *   No dependency on the plugin's convention-handling.
 *
 * RESPONSE CONTRACT:
 *   - HTTP 200 OK (ALWAYS — even on DB error, returns empty <urlset>)
 *   - Content-Type: application/xml; charset=utf-8
 *   - Body: valid XML per https://www.sitemaps.org/schemas/sitemap/0.9
 *
 * DATABASE SAFETY:
 *   - If Neon is unreachable, returns an EMPTY <urlset> with HTTP 200
 *     (never 500 — would break Google Search Console).
 *   - All errors are LOGGED server-side via logger.error — never exposed
 *     in the response body (no DB credentials, no stack traces).
 *   - Only PUBLISHED articles (status="PUBLISHED", publishedAt NOT NULL)
 *     are included. Drafts, deleted, and other statuses are EXCLUDED.
 *
 * SCALABILITY:
 *   - When totalPublished > 50,000 (Google's per-file limit), returns a
 *     <sitemapindex> pointing to /sitemap-articles/1, /sitemap-articles/2, ...
 *     Each chunk is served by src/app/sitemap-articles/[page]/route.ts.
 *   - When totalPublished ≤ 50,000, returns a single <urlset> with all
 *     article URLs + lastModified.
 *
 * PRODUCTION DOMAIN:
 *   - All URLs use loadBaseUrl() — reads platform.site_url PlatformSetting
 *     first (admin-editable via Admin → SEO), falls back to
 *     NEXT_PUBLIC_APP_BASE_URL env var. Default: https://centrychat.netlify.app
 *   - NEVER uses localhost in production (loadBaseUrl throws in production
 *     when both sources are missing → caught here → returns empty urlset).
 *
 * CACHING:
 *   - Cache-Control: public, max-age=600, must-revalidate (10 min CDN cache).
 *   - New articles appear in the sitemap within 10 minutes of publish.
 *   - The admin can manually invalidate via the SEO dashboard (PUT /api/v1/admin/seo
 *     clears the setting:platform.site_url cache so loadBaseUrl picks up changes).
 */
const SITEMAP_MAX_URLS_PER_FILE = 50_000; // Google's official per-file limit.

/** XML-escape a string for safe embedding in <loc> + <lastmod> tags. */
function escapeXml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/** Format a Date as ISO 8601 (Google's preferred format for <lastmod>). */
function formatDate(d: Date | null | undefined): string | null {
  if (!d) return null;
  return d.toISOString();
}

/** Build the XML prolog + <urlset> wrapper. */
function wrapUrlset(urlsXml: string): string {
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urlsXml}\n</urlset>`;
}

/** Build the XML prolog + <sitemapindex> wrapper. */
function wrapSitemapIndex(entriesXml: string): string {
  return `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${entriesXml}\n</sitemapindex>`;
}

/** HTTP 200 response with the given XML body + correct Content-Type + cache headers. */
function xmlResponse(xml: string, cacheMaxAge = 600): NextResponse {
  return new NextResponse(xml, {
    status: 200,
    headers: {
      "Content-Type": "application/xml; charset=utf-8",
      "Cache-Control": `public, max-age=${cacheMaxAge}, must-revalidate`,
      // Prevent any intermediate proxy from interpreting this as HTML.
      "X-Content-Type-Options": "nosniff",
    },
  });
}

export async function GET() {
  // ── 1. Resolve the production base URL ───────────────────────────────
  let baseUrl: string;
  try {
    baseUrl = await loadBaseUrl();
  } catch (err) {
    // NEXT_PUBLIC_APP_BASE_URL + platform.site_url both missing in production.
    // Log + return an EMPTY <urlset> with HTTP 200 (NOT 500 — would break
    // Google Search Console). The admin will see the error in logs and
    // configure the domain via Admin → SEO → Production Domain.
    logger.error(
      "seo",
      "sitemap.xml: loadBaseUrl() failed — returning empty <urlset>",
      { error: err instanceof Error ? err.message : String(err) }
    );
    return xmlResponse(wrapUrlset(""), 60);
  }

  // ── 2. Count published articles + active topics ───────────────────
  // Lightweight count queries — uses indexed columns. Wrapped in .catch()
  // so a DB outage returns an empty sitemap (valid XML, HTTP 200) instead
  // of a 500 error page that would break Google Search Console.
  let totalPublished = 0;
  let totalTopics = 0;
  try {
    [totalPublished, totalTopics] = await Promise.all([
      db.article.count({ where: { status: "PUBLISHED", publishedAt: { not: null } } }),
      // Phase 2.3 — count active topics for the sitemap.
      db.contentTopic.count({ where: { isActive: true } }),
    ]);
  } catch (err) {
    logger.error("seo", "sitemap.xml: count failed — returning empty <urlset>", {
      error: err instanceof Error ? err.message : String(err),
    });
    return xmlResponse(wrapUrlset(""), 60);
  }

  // ── 3a. Sitemap Index path: articles > 50,000 ──────────────────────
  // When the published article count exceeds Google's per-file limit, we
  // switch to a sitemap-index model. Topic URLs are NOT added to the
  // split path (to avoid exceeding the 50K limit per chunk). Topics are
  // discoverable via internal links from indexed article pages (which
  // have topic chips).
  //
  // Phase 2.3: when articles + topics together exceed 50K but articles
  // alone don't, we still use the single sitemap (both fit). Only when
  // articles alone exceed 50K do we split.
  if (totalPublished > SITEMAP_MAX_URLS_PER_FILE) {
    const numChunks = Math.ceil(totalPublished / SITEMAP_MAX_URLS_PER_FILE);
    // Use the most recent article's updatedAt as the lastModified for
    // all chunks (conservative — Google re-fetches each chunk to see its
    // actual contents).
    let lastModified: Date;
    try {
      const latest = await db.article.findFirst({
        where: { status: "PUBLISHED", publishedAt: { not: null } },
        orderBy: { updatedAt: "desc" },
        select: { updatedAt: true },
      });
      lastModified = latest?.updatedAt ?? new Date();
    } catch {
      lastModified = new Date();
    }
    const entries: string[] = [];
    for (let i = 1; i <= numChunks; i++) {
      const loc = `${baseUrl}/sitemap-articles/${i}`;
      const lastmod = formatDate(lastModified);
      const lastmodTag = lastmod ? `<lastmod>${lastmod}</lastmod>` : "";
      entries.push(`  <sitemap>\n    <loc>${escapeXml(loc)}</loc>\n    ${lastmodTag}\n  </sitemap>`);
    }
    return xmlResponse(wrapSitemapIndex(entries.join("\n")));
  }

  // ── 3b. Single sitemap path: count ≤ 50,000 ─────────────────────────
  // Fetch all published articles in a single lightweight query (id +
  // publishedAt + updatedAt only — no content). take=50,000 = Google's
  // per-file limit. Order by publishedAt DESC so the freshest articles
  // appear first.
  let articles: { id: string; publishedAt: Date | null; updatedAt: Date }[] = [];
  try {
    articles = await db.article.findMany({
      // Only PUBLISHED + APPROVED articles go in the sitemap.
      // PENDING_MODERATION and REJECTED articles return 404/noindex on
      // their public URL, so including them would mislead Google.
      where: {
        status: "PUBLISHED",
        publishedAt: { not: null },
        moderationStatus: "APPROVED",
      },
      select: {
        id: true,
        publishedAt: true,
        updatedAt: true,
      },
      orderBy: { publishedAt: "desc" },
      take: SITEMAP_MAX_URLS_PER_FILE,
    });
  } catch (err) {
    logger.error("seo", "sitemap.xml: article findMany failed — returning empty <urlset>", {
      error: err instanceof Error ? err.message : String(err),
    });
    return xmlResponse(wrapUrlset(""), 60);
  }

  // ── 4. Build the <url> entries ───────────────────────────────────────
  // Only PUBLISHED articles (already filtered by the where clause).
  // No drafts, no admin pages, no API routes, no login/register, no
  // private user pages, no /messages, no /notifications.
  const articleUrls = articles
    .map((a) => {
      const loc = `${baseUrl}/articles/${escapeXml(a.id)}`;
      const lastmod = formatDate(a.updatedAt ?? a.publishedAt);
      const lastmodTag = lastmod ? `<lastmod>${lastmod}</lastmod>` : "";
      return `  <url>\n    <loc>${loc}</loc>\n    ${lastmodTag}\n  </url>`;
    })
    .join("\n");

  // Phase 2.3 — fetch active topics + add their URLs to the sitemap.
  // Only added in the single-sitemap path (articles ≤ 50K). The combined
  // articles + topics count is typically well under 50K for most platforms.
  // If the combined count exceeds 50K, the sitemap-index path is used
  // (articles only — topics discoverable via internal links).
  let topicUrls = "";
  try {
    const topics = await db.contentTopic.findMany({
      where: { isActive: true },
      select: { slug: true, updatedAt: true },
      orderBy: { slug: "asc" },
      take: SITEMAP_MAX_URLS_PER_FILE,
    });
    topicUrls = topics
      .map((t) => {
        const loc = `${baseUrl}/topics/${escapeXml(t.slug)}`;
        const lastmod = formatDate(t.updatedAt);
        const lastmodTag = lastmod ? `<lastmod>${lastmod}</lastmod>` : "";
        return `  <url>\n    <loc>${loc}</loc>\n    ${lastmodTag}\n  </url>`;
      })
      .join("\n");
  } catch (err) {
    // Non-fatal — topics fail silently, articles still in the sitemap.
    logger.warn("application", "sitemap.xml: topic fetch failed — articles only", {
      error: err instanceof Error ? err.message : String(err),
    });
  }

  // Combine article + topic URLs. Articles first (higher priority for
  // Google crawl budget), then topics, then the published site pages
  // (/about, /privacy, /terms, /contact — only those that are PUBLISHED
  // in the SitePage CMS). Drafts are excluded (their public route
  // returns 404, so including them would be misleading to Google).
  let sitePageUrls = "";
  try {
    const { listPublishedSitePageSlugs } = await import("@/lib/site-pages");
    const publishedSlugs = await listPublishedSitePageSlugs();
    const now = formatDate(new Date());
    sitePageUrls = publishedSlugs
      .map(
        (slug) =>
          `  <url>\n    <loc>${baseUrl}/${escapeXml(slug)}</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.6</priority>\n  </url>`
      )
      .join("\n");
  } catch (err) {
    // Non-fatal — site pages fail silently, articles + topics still in the sitemap.
    logger.warn("application", "sitemap.xml: site pages fetch failed — articles + topics only", {
      error: err instanceof Error ? err.message : String(err),
    });
  }

  // Playlists — fetch PUBLIC playlists + add their /playlist/[slug] URLs
  // to the sitemap. Private playlists are NEVER indexed (spec §18). The
  // isPublic filter is the SOLE visibility filter — no private playlist
  // ever appears here. Best-effort: if the fetch fails, the sitemap still
  // returns articles + topics + site pages.
  let playlistUrls = "";
  try {
    const playlists = await db.playlist.findMany({
      where: { isPublic: true },
      select: { slug: true, updatedAt: true },
      orderBy: { updatedAt: "desc" },
      take: SITEMAP_MAX_URLS_PER_FILE,
    });
    playlistUrls = playlists
      .map((p) => {
        const loc = `${baseUrl}/playlist/${escapeXml(p.slug)}`;
        const lastmod = formatDate(p.updatedAt);
        const lastmodTag = lastmod ? `<lastmod>${lastmod}</lastmod>` : "";
        return `  <url>\n    <loc>${loc}</loc>\n    ${lastmodTag}\n  </url>`;
      })
      .join("\n");
  } catch (err) {
    // Non-fatal — playlists fail silently, the rest of the sitemap is
    // still returned.
    logger.warn("application", "sitemap.xml: playlist fetch failed — articles + topics + site pages only", {
      error: err instanceof Error ? err.message : String(err),
    });
  }

  const allUrls = [articleUrls, topicUrls, playlistUrls, sitePageUrls].filter(Boolean).join("\n");

  return xmlResponse(wrapUrlset(allUrls));
}
