import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/lib/database";
import { getSetting } from "@/lib/settings";
import { serializeJsonLd, loadBaseUrl } from "@/lib/seo/article";
import { TopicPage } from "@/components/search/topic-page";
// Phase 2 — Topics: use the topic service to resolve ContentTopic by slug.
import { getTopicBySlug } from "@/lib/topics";
// Phase 2.1 — Topics: batch-fetch content topic IDs for the feed.
import { getContentForTopic } from "@/lib/topics";
import { getCurrentUser } from "@/lib/auth";
// Phase 2.3 — Topics: proper topic detail page with header + canonical content.
import { TopicDetailPage } from "@/components/topics/topic-detail-page";

/**
 * /topics/[tag] — public, SEO-friendly topic page (spec §34).
 *
 * Phase 2 — Topics system: this route now resolves ContentTopic by slug
 * FIRST. When a ContentTopic exists with slug = decoded tag, the page
 * renders using the topic's name + description + content from the
 * ArticleTopic/PostTopic relationships.
 *
 * When NO ContentTopic exists with that slug, the route FALLS BACK to the
 * existing hashtag-search behavior (search posts/articles where content
 * contains `#tag`). This preserves backward compatibility for existing
 * indexed URLs that were generated from hashtag content (e.g.
 * /topics/football for posts containing "#football").
 *
 * SEO:
 *   - ContentTopic-based pages: ROBLES_NOINDEX by default per spec §10
 *     ("Topic pages should be treated as application/discovery pages unless
 *     explicitly approved for indexability"). The admin can override this
 *     in a future iteration by adding a `seoNoindex` flag to ContentTopic.
 *   - Hashtag-search pages: UNCHANGED — `robots: { index: true, follow: true }`
 *     (existing behavior preserved).
 *   - Both flavors are EXCLUDED from the sitemap (verified — sitemap only
 *     contains article URLs).
 *
 * SECURITY (spec §25, §37): only PUBLISHED articles are shown. Drafts
 * are excluded. The page respects visibility rules — private/deleted
 * content never appears.
 */

interface PageProps {
  params: Promise<{ tag: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { tag: rawTag } = await params;
  if (!rawTag) {
    return { title: "Topic not found", robots: { index: false, follow: false } };
  }

  const tag = decodeURIComponent(rawTag).replace(/^#/, "").trim();
  if (!tag) {
    return { title: "Topic not found", robots: { index: false, follow: false } };
  }

  // Phase 2 — try to resolve a ContentTopic by slug.
  const viewer = await getCurrentUser().catch(() => null);
  const contentTopic = await getTopicBySlug(tag, {}, viewer?.id ?? null);

  // ── S2 FIX: When no ContentTopic exists, check if ANY hashtag content
  // exists for this tag. If neither a ContentTopic NOR any hashtag content
  // exists, the URL is genuinely nonexistent → return noindex metadata
  // (the Page component will call notFound() to produce HTTP 404).
  //
  // We do a CHEAP count query here (not findMany) so the metadata decision
  // is fast. The Page component re-fetches with findMany for rendering.
  // The duplicate query is acceptable — it's two indexed count/findMany
  // calls on `content contains "#tag"` (case-insensitive ILIKE).
  //
  // Why this matters: previously, any URL like /topics/zzz-not-real-12345
  // returned HTTP 200 with index,follow metadata — Google could index
  // unlimited nonsense topic URLs. Now, only URLs with REAL content
  // (ContentTopic OR hashtag matches) are indexable. Everything else is
  // 404 + noindex.
  if (!contentTopic) {
    const hashtagPattern = `#${tag.toLowerCase()}`;
    // Use count (not findMany) — cheaper, and we only need to know
    // whether ANY content exists, not the content itself.
    const [postCount, articleCount] = await Promise.all([
      db.post.count({
        where: { content: { contains: hashtagPattern, mode: "insensitive" } },
      }).catch(() => 0),
      db.article.count({
        where: {
          status: "PUBLISHED",
          publishedAt: { not: null },
          OR: [
            { title: { contains: hashtagPattern, mode: "insensitive" } },
            { excerpt: { contains: hashtagPattern, mode: "insensitive" } },
            { content: { contains: hashtagPattern, mode: "insensitive" } },
          ],
        },
      }).catch(() => 0),
    ]);

    if (postCount + articleCount === 0) {
      // No ContentTopic AND no hashtag content → genuinely nonexistent.
      // Return noindex metadata. The Page component will call notFound()
      // which triggers Next.js to render the 404 page with these meta
      // tags. No canonical, no OG, no JSON-LD — nothing for Google to
      // index.
      return {
        title: "Topic not found",
        robots: { index: false, follow: false },
      };
    }

    // Hashtag content exists → preserve the existing hashtag-search
    // metadata (indexable, with canonical + OG). This is the backward-
    // compat path for hashtag URLs that Google has already indexed.
    return generateHashtagMetadata(tag);
  }

  // ── ContentTopic path (Phase 2.3 — now indexable) ──────────────────
  // Phase 2.3: the user has explicitly approved topic page indexability.
  // ContentTopic-based pages are now INDEXABLE (changed from Phase 2's
  // noindex default). These are curated topics with unique content —
  // safe to index.
  let baseUrl: string;
  try {
    baseUrl = await loadBaseUrl();
  } catch {
    return {
      title: contentTopic.name,
      robots: { index: false, follow: false },
    };
  }

  const platformName = (await getSetting("platform.name")) ?? "Platform";
  const url = `${baseUrl}/topics/${encodeURIComponent(contentTopic.slug)}`;
  const description = contentTopic.description
    ?? `Posts and articles about ${contentTopic.name} on ${platformName}`;

  return {
    title: `${contentTopic.name} — ${platformName}`,
    description,
    openGraph: {
      title: contentTopic.name,
      description,
      url,
      siteName: platformName,
      type: "website",
      // Phase 2.3 — use the platform's default OG image for topic pages.
      images: [{ url: `${baseUrl}/og-default.png` }],
    },
    twitter: {
      card: "summary_large_image",
      title: contentTopic.name,
      description,
      images: [`${baseUrl}/og-default.png`],
    },
    // Phase 2.3 — ContentTopic pages are now INDEXABLE (user-approved).
    // Inactive topics return 404 (notFound in Page component), so they
    // won't be indexed.
    robots: { index: true, follow: true },
    alternates: { canonical: url },
  };
}

/**
 * Generate metadata for the hashtag-search fallback path (existing behavior).
 * Extracted from the original generateMetadata implementation.
 */
async function generateHashtagMetadata(tag: string): Promise<Metadata> {
  let baseUrl: string;
  try {
    baseUrl = await loadBaseUrl();
  } catch {
    return { title: "Topic", robots: { index: false, follow: false } };
  }
  const platformName = (await getSetting("platform.name")) ?? "Platform";
  const url = `${baseUrl}/topics/${encodeURIComponent(tag)}`;
  const description = `Posts and articles about #${tag} on ${platformName}`;

  return {
    title: `#${tag} — ${platformName}`,
    description,
    openGraph: {
      title: `#${tag}`,
      description,
      url,
      siteName: platformName,
      type: "website",
    },
    twitter: {
      card: "summary",
      title: `#${tag}`,
      description,
    },
    // Hashtag-search pages remain indexable (existing behavior preserved).
    robots: { index: true, follow: true },
    alternates: { canonical: url },
  };
}

export default async function Page({ params }: PageProps) {
  const { tag: rawTag } = await params;
  if (!rawTag) notFound();

  const tag = decodeURIComponent(rawTag).replace(/^#/, "").trim();
  if (!tag) notFound();

  // Phase 2.3 — resolve ContentTopic by slug. When found, render the proper
  // TopicDetailPage with topic header + canonical content from ArticleTopic/
  // PostTopic relationships. When not found, fall back to the existing
  // hashtag-search behavior (TopicPage component).
  const viewer = await getCurrentUser().catch(() => null);
  const contentTopic = await getTopicBySlug(tag, {}, viewer?.id ?? null);

  // ── ContentTopic path: render TopicDetailPage ──────────────────────
  // Fetch content from canonical ArticleTopic/PostTopic relationships.
  // Also includes hashtag-search content (merged + deduplicated) so the
  // page shows ALL relevant content for the topic.
  if (contentTopic) {
    // Fetch content IDs from ArticleTopic/PostTopic (canonical relationships).
    const { posts: topicPostIds, articles: topicArticleIds } = await getContentForTopic(
      contentTopic.id,
      { limit: 20 }
    );

    // Also fetch hashtag-search content (for backward compat — content that
    // contains #topic-slug but hasn't been explicitly assigned via topics).
    const hashtagPattern = `#${tag.toLowerCase()}`;
    const [hashtagPosts, hashtagArticles] = await Promise.all([
      db.post.findMany({
        where: { content: { contains: hashtagPattern, mode: "insensitive" } },
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: 21,
        select: {
          id: true, content: true, createdAt: true, updatedAt: true, authorId: true,
          author: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
          _count: { select: { likes: true, comments: true, views: true } },
        },
      }),
      db.article.findMany({
        where: {
          status: "PUBLISHED", publishedAt: { not: null },
          OR: [
            { title: { contains: hashtagPattern, mode: "insensitive" } },
            { excerpt: { contains: hashtagPattern, mode: "insensitive" } },
            { content: { contains: hashtagPattern, mode: "insensitive" } },
          ],
        },
        orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
        take: 21,
        select: {
          id: true, title: true, excerpt: true, coverImage: true, videoUrl: true,
          publishedAt: true, readingTime: true,
          author: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
          _count: { select: { likes: true, comments: true, views: true } },
        },
      }),
    ]);

    // Fetch full rows for content from canonical topic relationships.
    const [topicPosts, topicArticles] = await Promise.all([
      topicPostIds.length > 0
        ? db.post.findMany({
            where: { id: { in: topicPostIds.map((p) => p.id) } },
            orderBy: [{ createdAt: "desc" }, { id: "desc" }],
            select: {
              id: true, content: true, createdAt: true, updatedAt: true, authorId: true,
              author: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
              _count: { select: { likes: true, comments: true, views: true } },
            },
          })
        : [],
      topicArticleIds.length > 0
        ? db.article.findMany({
            where: { id: { in: topicArticleIds.map((a) => a.id) } },
            orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
            select: {
              id: true, title: true, excerpt: true, coverImage: true, videoUrl: true,
              publishedAt: true, readingTime: true,
              author: { select: { id: true, fullName: true, username: true, avatarColor: true, avatarUrl: true, isVerified: true } },
              _count: { select: { likes: true, comments: true, views: true } },
            },
          })
        : [],
    ]);

    // Merge canonical + hashtag content. Deduplicate by content ID.
    const seenKeys = new Set<string>();
    type TaggedItem = { type: "post" | "article"; ts: Date; id: string; raw: any };
    const allItems: TaggedItem[] = [];

    // Add canonical topic content first (preferred).
    for (const p of topicPosts) {
      const key = `post:${p.id}`;
      if (!seenKeys.has(key)) { seenKeys.add(key); allItems.push({ type: "post", ts: p.createdAt, id: p.id, raw: p }); }
    }
    for (const a of topicArticles) {
      const key = `article:${a.id}`;
      if (!seenKeys.has(key)) { seenKeys.add(key); allItems.push({ type: "article", ts: a.publishedAt ?? new Date(0), id: a.id, raw: a }); }
    }
    // Add hashtag content (deduped — skip items already from canonical).
    for (const p of hashtagPosts) {
      const key = `post:${p.id}`;
      if (!seenKeys.has(key)) { seenKeys.add(key); allItems.push({ type: "post", ts: p.createdAt, id: p.id, raw: p }); }
    }
    for (const a of hashtagArticles) {
      const key = `article:${a.id}`;
      if (!seenKeys.has(key)) { seenKeys.add(key); allItems.push({ type: "article", ts: a.publishedAt ?? new Date(0), id: a.id, raw: a }); }
    }

    // Sort merged content by timestamp DESC.
    allItems.sort((a, b) => {
      const diff = b.ts.getTime() - a.ts.getTime();
      if (diff !== 0) return diff;
      return b.id < a.id ? -1 : b.id > a.id ? 1 : 0;
    });

    // Take first 20 for SSR.
    const page = allItems.slice(0, 20);

    // Serialize for the client component.
    const initialItems = page.map((item) => {
      if (item.type === "post") {
        const p = item.raw;
        return {
          type: "post" as const,
          post: {
            id: p.id, content: p.content,
            createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString(),
            author: { ...p.author, isFollowing: false, isFollowedBy: false },
            likeCount: p._count.likes, commentCount: p._count.comments,
            viewCount: p._count.views, shareCount: 0, isLiked: false,
            topicIds: [],
          },
        };
      }
      const a = item.raw;
      return {
        type: "article" as const,
        article: {
          id: a.id, title: a.title, excerpt: a.excerpt,
          coverImage: a.coverImage, videoUrl: a.videoUrl,
          publishedAt: a.publishedAt?.toISOString() ?? null, readingTime: a.readingTime,
          author: { ...a.author, isFollowing: false, isFollowedBy: false },
          likeCount: a._count.likes, commentCount: a._count.comments,
          viewCount: a._count.views, shareCount: 0, isLiked: false,
          topicIds: [],
        },
      };
    });

    // ── JSON-LD structured data ──────────────────────────────────────
    let baseUrl: string;
    try {
      baseUrl = await loadBaseUrl();
    } catch {
      return <TopicDetailPage topic={contentTopic} initialItems={initialItems as any} />;
    }
    const platformName = (await getSetting("platform.name")) ?? "Platform";
    const jsonLd = {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      name: contentTopic.name,
      description: contentTopic.description
        ?? `Posts and articles about ${contentTopic.name} on ${platformName}`,
      url: `${baseUrl}/topics/${encodeURIComponent(contentTopic.slug)}`,
      isPartOf: { "@type": "WebSite", name: platformName, url: baseUrl },
    };

    return (
      <>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: serializeJsonLd(jsonLd) }}
        />
        <TopicDetailPage topic={contentTopic} initialItems={initialItems as any} />
      </>
    );
  }

  // ── Hashtag-search fallback path (existing behavior, preserved) ──────
  // No ContentTopic found — fall back to the original hashtag-search behavior.
  // Fetch the initial page of posts + articles server-side.
  //
  // S2 FIX: if NEITHER a ContentTopic NOR any hashtag content exists, call
  // notFound() to produce HTTP 404 (with noindex meta from generateMetadata).
  // This prevents nonsense URLs like /topics/zzz-not-real-12345 from
  // returning HTTP 200 + indexable metadata.
  const hashtagPattern = `#${tag.toLowerCase()}`;

  const [postRows, articleRows] = await Promise.all([
    db.post.findMany({
      where: {
        content: { contains: hashtagPattern, mode: "insensitive" },
      },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: 21,
      select: {
        id: true, content: true, createdAt: true, updatedAt: true, authorId: true,
        author: {
          select: {
            id: true, fullName: true, username: true,
            avatarColor: true, avatarUrl: true, isVerified: true,
          },
        },
        _count: { select: { likes: true, comments: true, views: true } },
      },
    }),
    db.article.findMany({
      where: {
        status: "PUBLISHED",
        OR: [
          { title: { contains: hashtagPattern, mode: "insensitive" } },
          { excerpt: { contains: hashtagPattern, mode: "insensitive" } },
          { content: { contains: hashtagPattern, mode: "insensitive" } },
        ],
        publishedAt: { not: null },
      },
      orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
      take: 21,
      select: {
        id: true, title: true, excerpt: true, coverImage: true, videoUrl: true,
        publishedAt: true, readingTime: true,
        author: {
          select: {
            id: true, fullName: true, username: true,
            avatarColor: true, avatarUrl: true, isVerified: true,
          },
        },
        _count: { select: { likes: true, comments: true, views: true } },
      },
    }),
  ]);

  // S2 FIX: No ContentTopic AND no hashtag content → HTTP 404 (not 200).
  // This is the critical fix: previously, any /topics/<nonsense> URL
  // returned 200 with indexable metadata. Now it returns 404 + noindex,
  // preventing Google from indexing unlimited nonsense topic URLs.
  if (postRows.length === 0 && articleRows.length === 0) {
    notFound();
  }

  // Merge + sort by timestamp DESC.
  type TaggedItem = { type: "post" | "article"; ts: Date; id: string; raw: any };
  const tagged: TaggedItem[] = [
    ...postRows.map((p) => ({ type: "post" as const, ts: p.createdAt, id: p.id, raw: p })),
    ...articleRows.map((a) => ({
      type: "article" as const,
      ts: a.publishedAt ?? new Date(0),
      id: a.id,
      raw: a,
    })),
  ];
  tagged.sort((a, b) => {
    const diff = b.ts.getTime() - a.ts.getTime();
    if (diff !== 0) return diff;
    return b.id < a.id ? -1 : b.id > a.id ? 1 : 0;
  });

  const hasMore = tagged.length > 20;
  const page = hasMore ? tagged.slice(0, 20) : tagged;
  const lastItem = page[page.length - 1];
  const nextCursor = hasMore && lastItem
    ? Buffer.from(JSON.stringify({
        ts: lastItem.ts.toISOString(),
        id: lastItem.id,
        type: lastItem.type,
      }), "utf-8").toString("base64")
    : null;

  // Serialize for the client component.
  const initialItems = page.map((item) => {
    if (item.type === "post") {
      const p = item.raw;
      return {
        type: "post" as const,
        post: {
          id: p.id,
          content: p.content,
          createdAt: p.createdAt.toISOString(),
          updatedAt: p.updatedAt.toISOString(),
          author: { ...p.author, isFollowing: false, isFollowedBy: false },
          likeCount: p._count.likes,
          commentCount: p._count.comments,
          viewCount: p._count.views,
          isLiked: false,
        },
      };
    }
    const a = item.raw;
    return {
      type: "article" as const,
      article: {
        id: a.id,
        title: a.title,
        excerpt: a.excerpt,
        coverImage: a.coverImage,
        videoUrl: a.videoUrl,
        publishedAt: a.publishedAt?.toISOString() ?? null,
        readingTime: a.readingTime,
        author: { ...a.author, isFollowing: false, isFollowedBy: false },
        likeCount: a._count.likes,
        commentCount: a._count.comments,
        viewCount: a._count.views,
        shareCount: 0,
        isLiked: false,
      },
    };
  });

  // ── JSON-LD structured data for the hashtag fallback page ─────────
  let baseUrl: string;
  try {
    baseUrl = await loadBaseUrl();
  } catch {
    return (
      <TopicPage
        tag={tag}
        initialItems={initialItems as any}
        initialNextCursor={nextCursor}
      />
    );
  }
  const platformName = (await getSetting("platform.name")) ?? "Platform";
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: `#${tag}`,
    description: `Posts and articles about #${tag} on ${platformName}`,
    url: `${baseUrl}/topics/${encodeURIComponent(tag)}`,
    isPartOf: {
      "@type": "WebSite",
      name: platformName,
      url: baseUrl,
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: serializeJsonLd(jsonLd) }}
      />
      <TopicPage
        tag={tag}
        initialItems={initialItems as any}
        initialNextCursor={nextCursor}
      />
    </>
  );
}
