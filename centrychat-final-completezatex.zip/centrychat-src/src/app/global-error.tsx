"use client";

/**
 * Global Error Boundary — catches any unhandled error in the React tree.
 *
 * Without this, Next.js renders its default "This page couldn't load" page
 * which is generic and gives no way to recover other than a full reload.
 *
 * This boundary renders a branded error UI with:
 *   - A clear message ("Something went wrong")
 *   - A "Try again" button (calls reset() to re-render the error boundary)
 *   - A "Go home" button (navigates to / via window.location)
 *
 * IMPORTANT: this is a Client Component (required for error boundaries).
 * It must NOT import server-only code.
 */

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "var(--background, #0a0a0a)",
          color: "var(--foreground, #ededed)",
          fontFamily: "system-ui, -apple-system, sans-serif",
        }}
      >
        <div style={{ maxWidth: "400px", padding: "32px", textAlign: "center" }}>
          <div
            style={{
              width: "48px",
              height: "48px",
              margin: "0 auto 16px",
              borderRadius: "12px",
              backgroundColor: "rgba(239, 68, 68, 0.1)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "24px",
            }}
          >
            ⚠️
          </div>
          <h1
            style={{
              fontSize: "20px",
              fontWeight: 600,
              margin: "0 0 8px 0",
            }}
          >
            Something went wrong
          </h1>
          <p
            style={{
              fontSize: "14px",
              opacity: 0.7,
              margin: "0 0 24px 0",
              lineHeight: 1.5,
            }}
          >
            An unexpected error occurred. You can try again or go back to the home page.
          </p>
          <div style={{ display: "flex", gap: "8px", justifyContent: "center" }}>
            <button
              onClick={reset}
              style={{
                padding: "8px 20px",
                fontSize: "14px",
                fontWeight: 500,
                borderRadius: "8px",
                border: "none",
                backgroundColor: "var(--primary, #ededed)",
                color: "var(--primary-foreground, #0a0a0a)",
                cursor: "pointer",
              }}
            >
              Try again
            </button>
            <button
              onClick={() => {
                window.location.href = "/";
              }}
              style={{
                padding: "8px 20px",
                fontSize: "14px",
                fontWeight: 500,
                borderRadius: "8px",
                border: "1px solid rgba(255,255,255,0.14)",
                backgroundColor: "transparent",
                color: "inherit",
                cursor: "pointer",
              }}
            >
              Go home
            </button>
          </div>
        </div>
      </body>
    </html>
  );
}
