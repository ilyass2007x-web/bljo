import type { Metadata } from "next";
import { Suspense } from "react";
import { prepareSitePage, buildSitePageMetadata } from "@/lib/site-pages/ssr";
import { SitePageClient } from "@/components/site-pages/site-page-client";
import { Loader2 } from "lucide-react";

/**
 * /contact — public, SEO-friendly "Contact Us" page.
 *
 * Uses the unified SitePage CMS (src/lib/site-pages). The content is
 * fetched from the SitePage table (slug="contact") + rendered by the
 * shared SitePageClient component.
 *
 * The contact page ALSO renders a contact form (the SitePageClient checks
 * the slug + shows the form when slug === "contact"). The form submits to
 * POST /api/v1/contact (public, rate-limited by IP).
 *
 * See src/lib/site-pages/ssr.ts for the shared SSR helpers.
 */

interface PageProps {
  params: Promise<Record<string, string>>;
}

export async function generateMetadata(_props: PageProps): Promise<Metadata> {
  const data = await prepareSitePage("contact");
  return buildSitePageMetadata("contact", data.page, data.platformName, data.baseUrl);
}

export default async function ContactPage() {
  const data = await prepareSitePage("contact");
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: data.jsonLd.webPageHtml }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: data.jsonLd.breadcrumbHtml }}
      />
      <Suspense
        fallback={
          <div className="flex min-h-screen items-center justify-center bg-background">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        }
      >
        <SitePageClient page={data.page} platformName={data.platformName} />
      </Suspense>
    </>
  );
}
