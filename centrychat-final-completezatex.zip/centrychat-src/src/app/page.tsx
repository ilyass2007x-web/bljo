"use client";

import { Suspense, useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useSearchParams } from "next/navigation";
import { useAuthStore } from "@/lib/client/auth-store";
import { useLanguage, detectBrowserLanguage } from "@/lib/client/i18n-store";
import { isVideoChatClientEnabled } from "@/lib/video-chat/enabled";
import { AuthScreen } from "@/components/auth/auth-screen";
import { Messenger } from "@/components/messenger/messenger";
import { MessagesPage } from "@/components/messenger/messages-page";
import { SettingsScreen } from "@/components/messenger/settings-screen";

// Video Chat — dynamically imported (code-split) so the WebRTC code only
// loads when the user navigates to ?view=video-chat. This keeps the initial
// bundle small + prevents the video chat module from affecting other views.
const VideoChatScreen = dynamic(
  () => import("@/components/video-chat/video-chat-screen").then((m) => m.VideoChatScreen),
  { ssr: false, loading: () => null }
);
import { AdminPanel } from "@/components/admin/admin-panel";
import { ProfileScreen } from "@/components/profile/profile-screen";
import { EditProfileScreen } from "@/components/profile/edit-profile-screen";
import { NotificationsPage } from "@/components/notifications/notifications-page";
import { HomeFeed } from "@/components/posts/home-feed";
import { FollowersPage } from "@/components/profile/followers-page";
import { FollowingPage } from "@/components/profile/following-page";
import { CommentsPage } from "@/components/posts/comments-page";
import { PostInsights } from "@/components/posts/post-insights";
import { ArticleEditor } from "@/components/articles/article-editor";
import { ArticleInsights } from "@/components/articles/article-insights";
import { ArticleCommentsPage } from "@/components/articles/article-comments-page";
import { SearchPage } from "@/components/search/search-page";
import { Loader2, MessageSquareLock } from "lucide-react";
import { useHeartbeat } from "@/hooks/use-heartbeat";
// Phase 2 — Topics: topic discovery page.
import { TopicDiscoveryPage } from "@/components/topics/topic-discovery";
// Phase 5 — Collections.
import { CollectionsPage } from "@/components/collections/collections-page";
import { CollectionDetailPage } from "@/components/collections/collection-detail";
// Playlists — ordered collections of Articles (independent from Topics
// + from the polymorphic Collections system).
import { CreatePlaylistPage } from "@/components/playlists/create-playlist-page";

function AppInner() {
  const searchParams = useSearchParams();
  const { user, loading, loaded, fetchUser } = useAuthStore();
  const { setLanguage, language, t } = useLanguage();
  const [booted, setBooted] = useState(false);

  useEffect(() => {
    void fetchUser().finally(() => setBooted(true));
  }, [fetchUser]);

  // Presence heartbeat — updates lastSeenAt every 30s while the tab is
  // visible. This powers the Online/Offline indicator in the chat header.
  useHeartbeat(!!user);

  // Language priority (per spec §21):
  // 1. User's saved language preference (from DB)
  // 2. Browser language (on first visit)
  // 3. Application default (en)
  useEffect(() => {
    if (user?.language) {
      setLanguage(user.language);
    } else if (!loaded) {
      // Before user is loaded, use browser language as a hint.
      setLanguage(detectBrowserLanguage());
    }
  }, [user?.language, loaded, setLanguage]);

  // Deep-link views: verify-email, reset-password, settings, admin
  const view = searchParams.get("view");
  // The ?conversation=<id> query param opens a specific conversation in
  // the Messenger — we keep that working by rendering the Messenger when
  // that param is present, even if no `view` is set.
  const conversationId = searchParams.get("conversation");

  if (!booted || loading) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
          <MessageSquareLock className="h-7 w-7" />
        </div>
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Unauthenticated views — accept both short ("verify", "reset") and email-link
  // formats ("verify-email", "reset-password") so the link in the email works
  // without redirecting through login.
  if (!user) {
    if (view === "verify" || view === "verify-email") {
      return <AuthScreen initialMode="verify" />;
    }
    if (view === "reset" || view === "reset-password") {
      return <AuthScreen initialMode="reset" />;
    }
    if (view === "forgot") {
      return <AuthScreen initialMode="forgot" />;
    }
    return <AuthScreen />;
  }

  // Authenticated views.
  if (view === "settings") return <SettingsScreen />;
  if (view === "edit-profile") return <EditProfileScreen />;
  if (view === "article-editor") return <ArticleEditor />;
  if (view === "profile") return <ProfileScreen />;
  if (view === "notifications") return <NotificationsPage />;
  if (view === "messages") return <MessagesPage />;
  if (view === "followers") return <FollowersPage />;
  if (view === "following") return <FollowingPage />;
  if (view === "comments") return <CommentsPage />;
  if (view === "post-insights") return <PostInsights />;
  if (view === "article-insights") return <ArticleInsights />;
  if (view === "article-comments") return <ArticleCommentsPage />;
  if (view === "search") return <SearchPage />;
  // Phase 2 — Topics: topic discovery page (view=topics).
  if (view === "topics") return <TopicDiscoveryPage />;
  // Phase 5 — Collections: collections list (view=collections) + collection
  // detail (view=collection&id=...). Both routes are SPA-only (no SSR —
  // public collections are discoverable via Search, which is the project's
  // established discovery path).
  if (view === "collections") return <CollectionsPage />;
  if (view === "collection") return <CollectionDetailPage />;
  // Playlists — standalone create-playlist SPA view. Public playlists
  // are server-rendered at /playlist/[slug] (with full SEO + JSON-LD).
  if (view === "create-playlist") return <CreatePlaylistPage />;
  // Video Chat — lazy-loaded (code-split). Requires email verification.
  //
  // DISABLED (TEMPORARY): When NEXT_PUBLIC_VIDEO_CHAT_ENABLED is not "true",
  // the Video Chat view is BLOCKED. Instead of rendering the VideoChatScreen
  // (which would call /api/v1/video-chat/config, attempt getUserMedia, and
  // start the matchmaking queue — all of which would fail/403), we fall
  // through to the default Home Feed view. The user is silently redirected
  // to the feed — no error page, no broken UI.
  //
  // The VideoChatScreen component itself is preserved (the dynamic import
  // above is NOT removed) — it just never mounts when disabled. The API
  // routes also return 403 server-side, so a user who somehow bypasses
  // this client check (e.g. calling the API directly) is still blocked.
  if (view === "video-chat" && isVideoChatClientEnabled()) return <VideoChatScreen />;
  if (view === "admin" && (user.role === "ADMIN" || user.role === "SUPER_ADMIN")) {
    return <AdminPanel />;
  }
  if (user.status === "PENDING_VERIFICATION" && !user.emailVerified) {
    return <PendingVerification email={user.email} onResend={async () => {
      try {
        await fetch("/api/v1/auth/resend-verification", { method: "POST" });
        alert("Verification email sent.");
      } catch {
        alert("Failed to resend. Try again.");
      }
    }} />;
  }

  // ?conversation=<id> opens the Messenger with that conversation selected.
  // This preserves the deep-link behavior used by the "Message" button on
  // profile screens and notification click-throughs.
  if (conversationId) {
    return <Messenger />;
  }

  // Default authenticated view — the Home Feed (Phase 2).
  return <HomeFeed />;
}

function PendingVerification({ email, onResend }: { email: string; onResend: () => void }) {
  const { t } = useLanguage();
  if (!t) return null;
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background p-4">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg">
        <MessageSquareLock className="h-7 w-7" />
      </div>
      <div className="max-w-md text-center">
        <h1 className="text-xl font-bold">{t("auth.verifyYourEmail")}</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {t("auth.verifyEmailDesc")} <strong>{email}</strong>. {t("auth.clickLinkToActivate")}
        </p>
        <p className="mt-2 text-xs text-muted-foreground">
          {t("auth.checkServerConsole")}
        </p>
        <button onClick={onResend} className="mt-4 text-sm text-primary hover:underline">
          {t("auth.resendVerification")}
        </button>
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center bg-background">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      }
    >
      <AppInner />
    </Suspense>
  );
}
