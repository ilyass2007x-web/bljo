import type { Metadata } from "next";
import { Suspense } from "react";
import { prepareSitePage, buildSitePageMetadata } from "@/lib/site-pages/ssr";
import { SitePageClient } from "@/components/site-pages/site-page-client";
import { Loader2 } from "lucide-react";

/**
 * /about — public, SEO-friendly "About Us" page.
 *
 * Uses the unified SitePage CMS (src/lib/site-pages). The content is
 * fetched from the SitePage table (slug="about") + rendered by the
 * shared SitePageClient component.
 *
 * See src/lib/site-pages/ssr.ts for the shared SSR helpers.
 */

interface PageProps {
  params: Promise<Record<string, string>>;
}

export async function generateMetadata(_props: PageProps): Promise<Metadata> {
  const data = await prepareSitePage("about");
  return buildSitePageMetadata("about", data.page, data.platformName, data.baseUrl);
}

export default async function AboutPage() {
  const data = await prepareSitePage("about");
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: data.jsonLd.webPageHtml }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: data.jsonLd.breadcrumbHtml }}
      />
      <Suspense
        fallback={
          <div className="flex min-h-screen items-center justify-center bg-background">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        }
      >
        <SitePageClient page={data.page} platformName={data.platformName} />
      </Suspense>
    </>
  );
}
