import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/lib/database";
import { ArticleReadingPage } from "@/components/articles/article-reading-page";
import { RelatedArticles } from "@/components/articles/related-articles";
import {
  buildArticleMetadata,
  buildArticleJsonLd,
  buildBreadcrumbJsonLd,
  loadPlatformSeoContext,
  serializeJsonLd,
  type ArticleSeoInput,
} from "@/lib/seo/article";
import { resolveMedia } from "@/lib/media/resolver";
import type { ResolvedMedia } from "@/lib/media/types";
import { parseYouTube, parseVimeo } from "@/lib/media/embeds";

/**
 * Fast (no-network) extraction of a video thumbnail URL.
 *
 * Used by `generateMetadata` so the OG image can fall back to the video
 * thumbnail when an article has no coverImage. We use the FAST pattern
 * matchers from `src/lib/media/embeds.ts` (parseYouTube + parseVimeo) —
 * these are pure regex functions, NO network call, so they don't slow
 * down metadata generation.
 *
 * Returns the thumbnail URL (e.g. https://i.ytimg.com/vi/ID/hqdefault.jpg)
 * or null when the URL is not a recognized video platform.
 */
function extractVideoThumbnail(videoUrl: string | null | undefined): string | null {
  if (!videoUrl) return null;
  // YouTube — returns hqdefault.jpg (480×360, JPEG, public, no auth).
  const yt = parseYouTube(videoUrl);
  if (yt?.thumbnailUrl) return yt.thumbnailUrl;
  // Vimeo — parseVimeo returns null thumbnailUrl (needs API call).
  const vm = parseVimeo(videoUrl);
  if (vm) return null; // Vimeo not supported without API key.
  return null;
}

/**
 * /articles/[id] — public article reading page (server-rendered for SEO).
 *
 * SEO SYSTEM (spec §1-§40):
 *   This route is the PRIMARY SEO surface for the platform. Every published
 *   article gets:
 *     - Dynamic <title>            via generateMetadata()
 *     - Dynamic meta description   (extracted from excerpt || content || title)
 *     - Canonical URL               (absolute, no tracking params)
 *     - OpenGraph metadata          (og:title, og:description, og:url,
 *                                    og:type=article, og:image, og:site_name,
 *                                    og:locale, og:publishedTime)
 *     - Twitter Card                (summary_large_image with image + alt)
 *     - Article JSON-LD             (@context, @type=Article, headline,
 *                                    description, image, datePublished,
 *                                    dateModified, author Person, publisher
 *                                    Organization with logo, mainEntityOfPage,
 *                                    url, inLanguage, interactionStatistic)
 *     - BreadcrumbList JSON-LD      (Home → Article)
 *     - robots: index, follow       (only for PUBLISHED articles)
 *
 * DRAFTS / DELETED / NON-EXISTENT:
 *   - 404 (HTTP 404, not 200 with "not found" text — spec §28)
 *   - noindex, nofollow
 *   - No misleading public metadata
 *   - Excluded from sitemap (handled in src/app/sitemap.ts)
 *
 * ARCHITECTURE:
 *   - generateMetadata() runs server-side (NOT in the browser) — search
 *     engines and social-media crawlers receive the full metadata in the
 *     initial HTML, with zero client-side JavaScript required.
 *   - The article data is fetched ONCE in generateMetadata and AGAIN in
 *     the Page component. Next.js does NOT deduplicate these calls
 *     automatically (different request scopes), so we keep both queries
 *     small + indexed. Each is a single Prisma findUnique on the primary
 *     key — O(log n), fast.
 *   - All URL/image URL fields are resolved to ABSOLUTE URLs (https://…)
 *     so they work correctly when fetched by social-media scrapers that
 *     don't resolve relative URLs.
 *   - All user-controlled strings (title, excerpt, content, author name)
 *     are sanitized via stripControlChars before being placed in JSON-LD.
 *     JSON.stringify (used by serializeJsonLd) escapes `</script>` and
 *     `<!--` sequences — preventing the classic JSON-LD XSS vector.
 */

interface PageProps {
  params: Promise<{ id: string }>;
}

/**
 * generateMetadata — runs on every request, server-side.
 *
 * Per spec §20: uses the official Next.js App Router Metadata API (NOT
 * manual <meta> tags in a body component).
 *
 * If the article does not exist OR is not PUBLISHED, we return a minimal
 * noindex metadata + 404 title. The Page component itself calls notFound()
 * to actually emit the 404 HTTP status. This split is correct because:
 *   - generateMetadata must NOT throw or call notFound() — it must return
 *     a Metadata object so the page can still render the 404 page with
 *     proper meta tags.
 *   - The Page component calls notFound() which triggers Next.js' 404
 *     response (HTTP 404, not 200).
 *
 * Error handling (spec §35): if the DB is unreachable during metadata
 * generation, we return neutral fallback metadata rather than crashing
 * the whole page. The Page component will still attempt to render and
 * will itself handle a DB error via its own try/catch.
 */
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { id } = await params;

  // Load platform context (cached 30s — cheap).
  let ctx: Awaited<ReturnType<typeof loadPlatformSeoContext>> | null = null;
  try {
    ctx = await loadPlatformSeoContext();
  } catch {
    // DB unreachable during metadata generation — return neutral fallback.
    // This is rare (DB is normally reachable in production). The Page
    // component will also fail and likely render the 404 page.
    return {
      title: "Article",
      robots: { index: false, follow: false },
    };
  }

  // Fetch the article row with only the fields needed for SEO. This is a
  // SMALL, indexed query (primary key lookup). Wrapped in try/catch so a
  // DB error here doesn't break the page render — the Page component
  // will independently re-fetch and handle errors.
  let article: ArticleSeoInput | null = null;
  try {
    const row = await db.article.findUnique({
      where: { id },
      select: {
        id: true,
        title: true,
        content: true,
        excerpt: true,
        coverImage: true,
        // Include videoUrl so we can extract a YouTube thumbnail as OG
        // image fallback when there's no coverImage. This is a FAST
        // pattern-match extraction (no network) — does not slow down
        // metadata generation.
        videoUrl: true,
        status: true,
        publishedAt: true,
        createdAt: true,
        updatedAt: true,
        // ── Per-article SEO control fields (PHASE-7 SEO audit) ──────
        // Selected so the SEO layer can apply custom overrides.
        seoNoindex: true,
        seoNofollow: true,
        customSeoTitle: true,
        customMetaDescription: true,
        customCanonical: true,
        author: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatarUrl: true,
          },
        },
        _count: {
          select: { likes: true, comments: true, views: true },
        },
      },
    });
    if (row) {
      article = {
        id: row.id,
        title: row.title,
        content: row.content,
        excerpt: row.excerpt,
        coverImage: row.coverImage,
        status: row.status,
        publishedAt: row.publishedAt,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
        author: row.author,
        likeCount: row._count.likes,
        commentCount: row._count.comments,
        viewCount: row._count.views,
        // Pass the per-article SEO overrides to the SEO layer.
        seoNoindex: row.seoNoindex,
        seoNofollow: row.seoNofollow,
        customSeoTitle: row.customSeoTitle,
        customMetaDescription: row.customMetaDescription,
        customCanonical: row.customCanonical,
        // Fast (no-network) YouTube thumbnail extraction. Used as
        // og:image fallback ONLY when coverImage is missing/null.
        videoThumbnailUrl: extractVideoThumbnail(row.videoUrl),
      };
    }
  } catch {
    // DB error — return neutral fallback. Page component will handle.
    return {
      title: "Article",
      robots: { index: false, follow: false },
    };
  }

  // Article does not exist OR is not PUBLISHED → noindex metadata. The
  // Page component below will call notFound() to emit HTTP 404.
  if (!article || article.status !== "PUBLISHED") {
    return {
      title: "Article not found",
      robots: { index: false, follow: false },
    };
  }

  // Build the full Metadata object via the shared SEO helper.
  return buildArticleMetadata(article, ctx);
}

/**
 * Page — renders the article.
 *
 * Fetches the article again (with the full field set needed by the
 * ArticleReadingPage client component, including imageZoom/position config
 * and shareCount). Next.js does not share state between generateMetadata
 * and Page, so this second fetch is necessary.
 *
 * For drafts / non-existent articles: calls notFound() → HTTP 404
 * (spec §28 — must NOT return 200 for missing content).
 */
export default async function Page({ params }: PageProps) {
  const { id } = await params;
  const article = await db.article.findUnique({
    where: { id },
    select: {
      id: true,
      authorId: true,
      title: true,
      content: true,
      excerpt: true,
      coverImage: true,
      videoUrl: true,
      // Phase 18 — image presentation config (passed to ArticleReadingPage
      // so the saved zoom/position is reproduced in the published article).
      imageZoom: true,
      imagePositionX: true,
      imagePositionY: true,
      // Cover image visibility inside the article detail page.
      showCoverInArticle: true,
      // ── Per-article SEO control fields (PHASE-7 SEO audit) ──────
      // Needed by the JSON-LD builder (to keep mainEntityOfPage + url
      // consistent with the <link rel="canonical">).
      seoNoindex: true,
      seoNofollow: true,
      customSeoTitle: true,
      customMetaDescription: true,
      customCanonical: true,
      status: true,
      publishedAt: true,
      readingTime: true,
      createdAt: true,
      updatedAt: true,
      author: {
        select: {
          id: true,
          fullName: true,
          username: true,
          avatarColor: true,
          avatarUrl: true,
          isVerified: true,
        },
      },
      // Phase — Article social features: include interaction counts via
      // Prisma _count aggregation. The ArticleReadingPage needs these to
      // render the ArticleActions row (Like / Comment / Views / Share)
      // with real numbers.
      _count: {
        select: { likes: true, comments: true, views: true },
      },
    },
  });

  if (!article || article.status !== "PUBLISHED") {
    notFound();
  }

  // Batch-compute shareCount (ArticleInteraction WHERE type='SHARE').
  // The server-rendered page can't know who the current user is (no
  // session in SSR), so isLiked defaults to false. The client-side
  // usePostView + useAuthStore will hydrate it after hydration via a
  // follow-up GET /api/v1/articles/:id request that returns the real
  // isLiked. For SSR we just provide the counts.
  const shareCount = await db.articleInteraction.count({
    where: { articleId: id, type: "SHARE" },
  }).catch(() => 0);

  // ── PUBLIC MEDIA RESOLUTION (spec §4-§9) ───────────────────────────────
  // Resolve coverImage + videoUrl SERVER-SIDE so anonymous visitors (Google
  // referrers, Incognito browsers, direct link clicks) see the article
  // media WITHOUT requiring a session.
  //
  // ROOT CAUSE being fixed here:
  //   The previous flow used the client-side `useMediaResolver` hook which
  //   POSTs to `/api/v1/media/resolve`. That endpoint called `requireUser()`
  //   (auth-gated). Anonymous visitors got 401, so `useMediaResolver` set
  //   `error="Authentication required"` + `media=null`, which made
  //   `MediaRenderer` render the "No media available" fallback card —
  //   even though the article row itself had a valid coverImage/videoUrl.
  //
  // FIX (architecture-level, no auth-bypass on the API):
  //   Resolve media DIRECTLY from the server component using the imported
  //   `resolveMedia()` function (the same one the API calls). The result
  //   is passed to ArticleReadingPage as `initialCoverMedia` + `initialVideoMedia`
  //   props. ArticleReadingPage seeds these into the client-side media
  //   cache via `setCachedMedia` so the `useMediaResolver` hook returns
  //   them synchronously WITHOUT hitting the API at all.
  //
  // SECURITY:
  //   - `resolveMedia()` has full SSRF protection (rejects private IPs,
  //     metadata endpoints, dangerous schemes, enforces HTTPS, caps
  //     redirects + body size + timeout).
  //   - Results are cached 5 minutes by URL (server-side).
  //   - We do NOT change `/api/v1/media/resolve` — it stays auth-gated.
  //     Anonymous visitors never call it because they get the SSR-resolved
  //     media for free in the initial HTML.
  //   - Logged-in visitors ALSO get the SSR-resolved media (faster — no
  //     extra API call on first render). The client cache means subsequent
  //     navigation to the same article is instant.
  //
  // ERROR RESILIENCE:
  //   Each resolve is wrapped in .catch() — if the external host is
  //   unreachable, we fall back to `null` and the client MediaRenderer
  //   will render its fallback card. The page itself never crashes.
  const [coverMedia, videoMedia] = await Promise.all([
    article.coverImage
      ? resolveMedia(article.coverImage).catch(() => null)
      : Promise.resolve(null),
    article.videoUrl
      ? resolveMedia(article.videoUrl).catch(() => null)
      : Promise.resolve(null),
  ]);

  // ── SEO: build the JSON-LD structured data ──────────────────────────
  // This runs in the Page component (not generateMetadata) because we
  // need to emit it as a <script> tag inside the rendered HTML body.
  // The data is rebuilt from the article row we just fetched — same
  // source of truth as generateMetadata.
  //
  // Error-resilient: if the platform context load fails (DB issue), we
  // skip the JSON-LD rather than crashing the page. The article itself
  // still renders.
  let articleJsonLdHtml: string | null = null;
  let breadcrumbJsonLdHtml: string | null = null;
  try {
    const ctx = await loadPlatformSeoContext();
    const seoInput: ArticleSeoInput = {
      id: article.id,
      title: article.title,
      content: article.content,
      excerpt: article.excerpt,
      coverImage: article.coverImage,
      status: article.status,
      publishedAt: article.publishedAt,
      createdAt: article.createdAt,
      updatedAt: article.updatedAt,
      author: {
        id: article.author.id,
        fullName: article.author.fullName,
        username: article.author.username,
        avatarUrl: article.author.avatarUrl,
      },
      likeCount: article._count.likes,
      commentCount: article._count.comments,
      viewCount: article._count.views,
      shareCount,
      // Pass the per-article SEO overrides to the JSON-LD builder too
      // (so JSON-LD matches the <meta> tags — Google cross-checks).
      seoNoindex: article.seoNoindex,
      seoNofollow: article.seoNofollow,
      customSeoTitle: article.customSeoTitle,
      customMetaDescription: article.customMetaDescription,
      customCanonical: article.customCanonical,
      // Pass the resolved video thumbnail (if any) so JSON-LD uses the
      // same image source as the og:image meta tag (spec §25 — SEO + social
      // must be consistent). When the article has a real coverImage, the
      // resolver prefers it; this is only used as fallback.
      videoThumbnailUrl: videoMedia?.thumbnailUrl ?? extractVideoThumbnail(article.videoUrl),
    };
    const articleJsonLd = buildArticleJsonLd(seoInput, ctx);
    const breadcrumbJsonLd = buildBreadcrumbJsonLd(seoInput, ctx);
    articleJsonLdHtml = serializeJsonLd(articleJsonLd);
    breadcrumbJsonLdHtml = serializeJsonLd(breadcrumbJsonLd);
  } catch {
    // Non-fatal — the article still renders without JSON-LD. Search
    // engines will still pick up the title/description/OG from the
    // <head> metadata emitted by generateMetadata.
  }

  return (
    <>
      {articleJsonLdHtml && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: articleJsonLdHtml }}
        />
      )}
      {breadcrumbJsonLdHtml && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: breadcrumbJsonLdHtml }}
        />
      )}
      <ArticleReadingPage
        article={{
          id: article.id,
          authorId: article.authorId,
          title: article.title,
          content: article.content,
          excerpt: article.excerpt,
          coverImage: article.coverImage,
          videoUrl: article.videoUrl,
          // Phase 18 — image presentation config (may be null for old
          // articles — ArticleReadingPage normalizes null → default
          // at render time via normalizeImageConfig).
          imageZoom: article.imageZoom,
          imagePositionX: article.imagePositionX,
          imagePositionY: article.imagePositionY,
          // Cover image visibility inside the article detail page.
          // Defaults to true when null (backward compatibility for old articles).
          showCoverInArticle: article.showCoverInArticle !== false,
          status: article.status,
          publishedAt: article.publishedAt?.toISOString() ?? null,
          readingTime: article.readingTime,
          createdAt: article.createdAt.toISOString(),
          updatedAt: article.updatedAt.toISOString(),
          author: article.author,
          // Phase — Article social features.
          likeCount: article._count.likes,
          commentCount: article._count.comments,
          viewCount: article._count.views,
          shareCount,
          // SSR can't know the current user's isLiked state — default
          // to false. The client (ArticleReadingPage) will hydrate the
          // real state via useAuthStore + a follow-up fetch if needed.
          isLiked: false,
        }}
        // Pre-resolved media (server-side) — seeded into the client cache
        // by ArticleReadingPage so anonymous visitors see the cover image
        // + video WITHOUT calling the auth-gated /api/v1/media/resolve
        // endpoint. This is the ROOT FIX for "Not Media available" for
        // logged-out / Incognito / Google-referred visitors.
        initialCoverMedia={coverMedia}
        initialVideoMedia={videoMedia}
      />
      {/* Related Articles — server-rendered for SEO (real crawlable <a> links).
          Computed server-side via findRelatedArticles(). Renders nothing when
          there are no related articles or if an error occurs (graceful
          degradation — the article page never crashes because of this). */}
      <RelatedArticles articleId={article.id} limit={5} />
    </>
  );
}
