import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";
import { AdsProvider, AdSenseScript } from "@/components/ads/adsense";
import { getSetting } from "@/lib/settings";
import {
  buildOrganizationJsonLd,
  serializeJsonLd,
  loadBaseUrl,
} from "@/lib/seo/article";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

/**
 * Fallbacks used ONLY when the database is unreachable or the settings
 * haven't been seeded yet. These are NOT used in normal operation —
 * the values from the `PlatformSetting` table (set via the admin
 * Customization panel) always take precedence.
 *
 * Per spec §12: "أزل أي قيم Hard-coded قديمة مثل: اسم المشروع القديم،
 * z.ai، أي Platform Name مكتوب مباشرة داخل metadata."
 *
 * We use a NEUTRAL placeholder here ("Platform") instead of any brand
 * name. This ensures that if the DB is unreachable, the browser tab
 * shows a generic label rather than a stale brand name from the code.
 */
const FALLBACK_PLATFORM_NAME = "Platform";
const FALLBACK_PLATFORM_DESCRIPTION = "A self-hostable messaging platform.";

/**
 * generateMetadata — fetched SERVER-SIDE on every request.
 *
 * This is the Next.js 16 App Router way to make the <title>,
 * <meta name="description">, OpenGraph, and Twitter Card metadata
 * DYNAMIC — they reflect whatever the admin set in the Customization
 * panel (Platform Name + Platform Description).
 *
 * Per spec §4 + §7: the browser tab title must change automatically
 * when Platform Name changes in Settings. This function reads
 * `platform.name` + `platform.description` directly from the DB via
 * `getSetting()` (which uses a 30-second in-memory cache for
 * performance — see src/lib/settings/index.ts).
 *
 * Revalidation: Next.js calls `generateMetadata` on every request
 * for dynamic routes (which the root layout applies to all routes
 * since we have no `generateStaticParams`). Combined with the 30s
 * cache in `getSetting`, this means: after the admin saves a new
 * platform name, the NEXT page render (within 30s) will reflect
 * the new value in the browser tab.
 *
 * Per spec §5: NO hardcoded brand name (SentryChat, z.ai, etc.)
 * appears in the metadata. The fallback is the neutral word
 * "Platform" — only used if the DB is unreachable.
 */
export async function generateMetadata(): Promise<Metadata> {
  // Fetch both settings in parallel. `getSetting` uses a 30s cache
  // (cacheGetOrSet in src/lib/cache/index.ts) so this is cheap.
  //
  // We wrap in try/catch for resilience: if the DB is temporarily
  // unreachable (e.g. during `next build` prerendering when no real
  // DATABASE_URL is configured, or during a Neon cold start), we fall
  // back to the neutral placeholders instead of crashing the build
  // or rendering the page without a title.
  // Resolve baseUrl SEPARATELY from getSetting() so a DB outage on
  // platform.name/description doesn't discard the baseUrl value that
  // loadBaseUrl() successfully resolved (via env var fallback).
  //
  // loadBaseUrl() has its OWN try/catch internally — it falls through to
  // NEXT_PUBLIC_APP_BASE_URL env var when the DB PlatformSetting is
  // unreachable. So baseUrl is correctly resolved even on DB outage.
  let baseUrl: string | null = null;
  try {
    baseUrl = await loadBaseUrl();
  } catch {
    // Both platform.site_url + env var missing in production — use
    // empty string (browser/scrapers resolve relative URLs against
    // request origin). This is rare; only happens on misconfigured deploys.
    baseUrl = null;
  }

  let platformName: string | null = null;
  let platformDescription: string | null = null;
  try {
    [platformName, platformDescription] = await Promise.all([
      getSetting("platform.name"),
      getSetting("platform.description"),
    ]);
  } catch {
    // DB unreachable — use neutral fallbacks so the page still renders
    // with a valid <title> + meta description. baseUrl is NOT affected
    // (it was resolved above independently).
  }

  const name = platformName || FALLBACK_PLATFORM_NAME;
  const description = platformDescription || FALLBACK_PLATFORM_DESCRIPTION;
  // Use the resolved baseUrl, or fall back to "" (relative — browser
  // resolves against request origin). NEVER falls back to localhost.
  const baseUrlFinal = baseUrl ?? "";

  // The browser tab title. Format: "<Platform Name>" (just the name,
  // clean). If the admin sets Platform Name = "Nexus", the tab shows
  // "Nexus". No hardcoded suffix — the admin controls the full text
  // via the Platform Description setting.
  const title = name;
  // Per spec §6: the description is used as the SEO meta description,
  // OpenGraph description, AND Twitter Card description.
  return {
    title,
    description,
    authors: [{ name }],
    // OpenGraph metadata — used by social-media scrapers (Facebook,
    // LinkedIn, Slack, Discord) to render a rich preview when someone
    // shares a link to the platform.
    openGraph: {
      title,
      description,
      siteName: name,
      type: "website",
      // SEO FIX (M-3): Add default OG image so link previews on WhatsApp/
      // Slack/Twitter show the platform's brand image instead of a blank
      // card. The /og-default.png file exists in public/ (generated by
      // scripts/generate-apple-icon.ts). Article pages override this with
      // the article's cover image.
      images: [{ url: `${baseUrlFinal}/og-default.png` }],
    },
    // Twitter/X Card metadata — used by twitter.com / X to render the
    // link preview. `summary_large_image` shows a larger preview card
    // with the OG image (was `summary` which is text-only).
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [`${baseUrlFinal}/og-default.png`],
    },
    // The platform is a private messaging app — pages should never be
    // indexed by search engines. This is a SECURITY decision (private
    // messages must not appear in Google results) and is independent
    // of the Platform Name/Description settings.
    robots: {
      index: false,
      follow: false,
    },
  };
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // ── Site-wide Structured Data (spec §30, §31) ──────────────────────────
  // Two JSON-LD blocks are rendered on every page:
  //   1. WebSite        — identifies the site + exposes a SearchAction
  //                       so search engines can offer an in-RESULTS
  //                       "search this site" box.
  //   2. Organization    — identifies the publisher. Article JSON-LD on
  //                       /articles/[id] references this Organization
  //                       via the `publisher` field, so the two MUST
  //                       be consistent (same name + logo URL).
  //
  // Both blocks use the dynamic platform name + description from the
  // PlatformSetting table (cached 30s via getSetting). When the admin
  // changes the platform name in the Customization panel, both blocks
  // update within 30s.
  //
  // SECURITY: the platform name + description come from the DB, but
  // they were originally set by an admin (server-side). They are NOT
  // user-controlled free-text from a public form. JSON.stringify escapes
  // </script> sequences, preventing the classic JSON-LD XSS.
  //
  // BASE URL: uses loadBaseUrl() — admin-editable via platform.site_url
  // PlatformSetting (single source of truth). Falls back to env var, then
  // to "" (relative — browser resolves against request origin). Never
  // leaks localhost to Google in production.
  let layoutBaseUrl: string;
  try {
    layoutBaseUrl = await loadBaseUrl();
  } catch {
    // Both platform.site_url + env var missing in production — fall back
    // to relative URLs (browser resolves against request origin). This
    // is rare; only happens on misconfigured deploys.
    layoutBaseUrl = "";
  }

  // Fetch platform name + description + logo URL + AdSense config in parallel.
  // Each is cached for 30s via getSetting, so this is cheap on repeat hits.
  // Wrapped in try/catch — if the DB is unreachable (e.g. during build-
  // time prerender without a real DATABASE_URL), we fall back to neutral
  // placeholder values rather than crashing the layout.
  let platformName = "Platform";
  let platformDescription = "A self-hostable messaging platform.";
  let logoUrl: string | null = null;
  let adsenseEnabled = false;
  let adsensePublisherId: string | null = null;
  try {
    const [name, description, logo, adsEnabled, adsPubId] = await Promise.all([
      getSetting("platform.name"),
      getSetting("platform.description"),
      getSetting("platform.logo_url"),
      getSetting("adsense.enabled"),
      getSetting("adsense.publisher_id"),
    ]);
    if (name) platformName = name;
    if (description) platformDescription = description;
    logoUrl = logo || null;
    adsenseEnabled = adsEnabled === "true" || adsEnabled === "1";
    adsensePublisherId = adsPubId || null;
  } catch {
    // DB unreachable — use neutral fallbacks. Same behavior as
    // generateMetadata above. AdSense script not rendered (would
    // need the publisher ID from DB).
  }

  const websiteJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    url: layoutBaseUrl,
    name: platformName,
    description: platformDescription,
    // SEO FIX (L-5): Removed the SearchAction potentialAction. The target
    // pointed to /?view=profile&username=... which is a noindex SPA route,
    // not a real indexable search results page. Google requires a real
    // crawlable search page for the sitelinks search box feature. Emitting
    // a broken SearchAction can cause Google to flag the structured data
    // as misleading. When a real /search?q=... route is added, this can
    // be re-enabled.
  };

  const organizationJsonLd = buildOrganizationJsonLd({
    name: platformName,
    description: platformDescription,
    baseUrl: layoutBaseUrl,
    logoUrl,
  });

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {adsenseEnabled && adsensePublisherId && (
          <script
            async
            crossOrigin="anonymous"
            src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${encodeURIComponent(adsensePublisherId)}`}
            // data-ad-client is the OFFICIAL AdSense attribute recommended by
            // Google. Some verification flows read it from the <script> tag.
            data-ad-client={adsensePublisherId}
          />
        )}
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: serializeJsonLd(websiteJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: serializeJsonLd(organizationJsonLd) }}
        />
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <AdsProvider>
            {children}
            <AdSenseScript />
          </AdsProvider>
          <Toaster />
          <SonnerToaster position="top-right" richColors closeButton />
        </ThemeProvider>
      </body>
    </html>
  );
}
