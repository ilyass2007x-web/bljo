import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { db } from "@/lib/database";
import { isFeatureEnabled } from "@/lib/features";
import {
  buildPlaylistMetadata,
  buildPlaylistJsonLd,
  loadPlaylistSeoContext,
  resolvePlaylistOgImage,
  resolvePlaylistCoverMedia,
  serializeJsonLd,
  type PlaylistSeoInput,
} from "@/lib/seo/playlist";
import { PlaylistDetailClient } from "@/components/playlists/playlist-detail-client";

/**
 * /playlist/[slug] — public Playlist page (server-rendered for SEO).
 *
 * WHY SERVER-RENDERED (not SPA):
 *   - Public Playlists are indexable by search engines (spec §18) — the
 *     metadata + JSON-LD must be in the initial HTML, not hydrated by JS.
 *   - Anonymous visitors (Google referrers, direct link clicks) see the
 *     full playlist + items WITHOUT requiring a session.
 *   - Mirrors the architecture of /articles/[id] (server component +
 *     generateMetadata + JSON-LD + client child for interactions).
 *
 * DRAFTS / NON-EXISTENT / PRIVATE-NON-OWNER:
 *   - 404 (HTTP 404, not 200 with "not found" text — matches the article
 *     page convention).
 *   - noindex, nofollow.
 *   - No misleading public metadata.
 *
 * ARCHITECTURE:
 *   - generateMetadata() runs server-side. Search engines + social-media
 *     crawlers receive the full metadata in the initial HTML.
 *   - The Page component fetches the playlist row + items once, resolves
 *     the cover image server-side, and passes everything to the client
 *     PlaylistDetailClient component for interactivity.
 *   - The client component handles: drag-and-drop reorder (owner only),
 *     add/remove items (owner only), navigate to articles, follow
 *     playlist owner, etc.
 */

interface PageProps {
  params: Promise<{ slug: string }>;
}

/**
 * generateMetadata — runs on every request, server-side.
 *
 * Returns noindex metadata when:
 *   - Playlists feature is disabled
 *   - The playlist doesn't exist
 *   - The playlist is private AND the viewer is not the owner
 *
 * The Page component itself calls notFound() to emit HTTP 404 for missing
 * / private-non-owner cases. This split is correct because generateMetadata
 * must NOT throw — it must return a Metadata object so the 404 page can
 * still render with proper meta tags.
 */
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;

  // Feature flag — checked first.
  if (!(await isFeatureEnabled("playlists"))) {
    return {
      title: "Playlist",
      robots: { index: false, follow: false },
    };
  }

  const ctx = await loadPlaylistSeoContext();
  if (!ctx) {
    return {
      title: "Playlist",
      robots: { index: false, follow: false },
    };
  }

  // Fetch the playlist row by slug. We don't yet know who the viewer is
  // at metadata time — that's fine, because private playlists ALWAYS
  // noindex regardless of viewer (a private playlist is not indexable even
  // for its owner, because the slug could be shared). For the actual page
  // render, the server component re-checks ownership.
  let playlist: PlaylistSeoInput | null = null;
  try {
    const row = await db.playlist.findUnique({
      where: { slug },
      select: {
        id: true,
        name: true,
        slug: true,
        description: true,
        coverImage: true,
        isPublic: true,
        createdAt: true,
        updatedAt: true,
        owner: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatarUrl: true,
          },
        },
        _count: { select: { items: true } },
      },
    });
    if (row) {
      playlist = {
        id: row.id,
        name: row.name,
        slug: row.slug,
        description: row.description,
        coverImage: row.coverImage,
        // Even if the playlist is private, we generate noindex metadata
        // (the Page component will call notFound() for non-owner viewers).
        isPublic: row.isPublic,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
        owner: row.owner,
        itemCount: row._count.items,
      };
    }
  } catch {
    return {
      title: "Playlist",
      robots: { index: false, follow: false },
    };
  }

  if (!playlist) {
    return {
      title: "Playlist not found",
      robots: { index: false, follow: false },
    };
  }

  // Resolve OG image (playlist.coverImage → first item's article cover →
  // platform default → /og-default.png). Best-effort — falls back to
  // builtin on failure.
  let ogImageUrl = `${ctx.baseUrl.replace(/\/+$/, "")}/og-default.png`;
  try {
    const { url } = await resolvePlaylistOgImage(playlist, ctx);
    ogImageUrl = url;
  } catch {
    // Non-fatal — use the fallback URL set above.
  }

  return buildPlaylistMetadata(playlist, ctx, ogImageUrl);
}

/**
 * Page — renders the playlist.
 *
 * Fetches the playlist row + items + hydrated article data, resolves
 * the cover image server-side, then passes everything to the client
 * PlaylistDetailClient component.
 *
 * For non-existent / private-non-owner playlists: calls notFound() →
 * HTTP 404 (matches the article page convention).
 */
export default async function Page({ params }: PageProps) {
  const { slug } = await params;

  if (!(await isFeatureEnabled("playlists"))) {
    notFound();
  }

  // We need to know the viewer to handle private playlists. Server
  // components can call getCurrentUser (it reads the session cookie).
  const { getCurrentUser } = await import("@/lib/auth");
  const viewer = await getCurrentUser();

  // Fetch the playlist by slug. Visibility:
  //   - Owner: sees their own playlist (any visibility).
  //   - Admin: sees any playlist.
  //   - Non-owner / unauth: sees ONLY public playlists.
  // We do this with a single findUnique + an isPublic OR ownerId filter.
  type PlaylistRow = {
    id: string;
    ownerId: string;
    name: string;
    slug: string;
    description: string | null;
    coverImage: string | null;
    isPublic: boolean;
    createdAt: Date;
    updatedAt: Date;
    owner: {
      id: string;
      fullName: string;
      username: string;
      avatarColor: string | null;
      avatarUrl: string | null;
      isVerified: boolean;
    };
    _count: { items: number };
  };
  let playlist: PlaylistRow | null = null;
  try {
    playlist = await db.playlist.findUnique({
      where: { slug },
      select: {
        id: true,
        ownerId: true,
        name: true,
        slug: true,
        description: true,
        coverImage: true,
        isPublic: true,
        createdAt: true,
        updatedAt: true,
        owner: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatarColor: true,
            avatarUrl: true,
            isVerified: true,
          },
        },
        _count: { select: { items: true } },
      },
    });
  } catch {
    notFound();
  }

  if (!playlist) notFound();

  // Visibility check: owner OR admin OR public.
  const isOwner = viewer?.id === playlist.ownerId;
  const isAdmin = viewer?.role === "ADMIN" || viewer?.role === "SUPER_ADMIN";
  if (!playlist.isPublic && !isOwner && !isAdmin) {
    notFound();
  }

  // Fetch items ordered by position. Cap at 200 (playlist.max_items default).
  const items = await db.playlistItem.findMany({
    where: { playlistId: playlist.id },
    orderBy: [{ position: "asc" }, { addedAt: "asc" }, { id: "asc" }],
    take: 200,
    select: {
      id: true,
      playlistId: true,
      articleId: true,
      position: true,
      addedAt: true,
      article: {
        select: {
          id: true,
          title: true,
          excerpt: true,
          coverImage: true,
          videoUrl: true,
          imageZoom: true,
          imagePositionX: true,
          imagePositionY: true,
          status: true,
          publishedAt: true,
          readingTime: true,
          author: {
            select: {
              id: true,
              fullName: true,
              username: true,
              avatarColor: true,
              avatarUrl: true,
              isVerified: true,
            },
          },
        },
      },
    },
  });

  // Serialize items for the client (ISO dates, only public fields).
  // Filter out items whose underlying article is no longer PUBLISHED
  // (defensive — the FK cascade should have removed them, but a draft
  // article that became a draft AFTER being added to the playlist would
  // still show — we hide it from public viewers but keep it for the owner
  // so they can manage it).
  const serializedItems = items.map((i) => ({
    id: i.id,
    playlistId: i.playlistId,
    articleId: i.articleId,
    position: i.position,
    addedAt: i.addedAt.toISOString(),
    article:
      i.article && i.article.status === "PUBLISHED"
        ? {
            id: i.article.id,
            title: i.article.title,
            excerpt: i.article.excerpt,
            coverImage: i.article.coverImage,
            videoUrl: i.article.videoUrl,
            imageZoom: i.article.imageZoom,
            imagePositionX: i.article.imagePositionX,
            imagePositionY: i.article.imagePositionY,
            publishedAt: i.article.publishedAt?.toISOString() ?? null,
            readingTime: i.article.readingTime,
            author: i.article.author,
          }
        : null,
  }));

  // Resolve the cover image server-side so anonymous visitors see it
  // without calling the auth-gated /api/v1/media/resolve endpoint. Same
  // pattern as the article page.
  const coverMedia = await resolvePlaylistCoverMedia(playlist.coverImage);

  // ── JSON-LD (only for PUBLIC playlists — spec §18) ───────────────
  let playlistJsonLdHtml: string | null = null;
  if (playlist.isPublic) {
    try {
      const ctx = await loadPlaylistSeoContext();
      if (ctx) {
        const seoInput: PlaylistSeoInput = {
          id: playlist.id,
          name: playlist.name,
          slug: playlist.slug,
          description: playlist.description,
          coverImage: playlist.coverImage,
          isPublic: playlist.isPublic,
          createdAt: playlist.createdAt,
          updatedAt: playlist.updatedAt,
          owner: {
            id: playlist.owner.id,
            fullName: playlist.owner.fullName,
            username: playlist.owner.username,
            avatarUrl: playlist.owner.avatarUrl,
          },
          itemCount: playlist._count.items,
        };
        const jsonLd = buildPlaylistJsonLd(
          seoInput,
          serializedItems.map((i) => ({
            articleId: i.articleId,
            position: i.position,
            articleTitle: i.article?.title ?? null,
          })),
          ctx
        );
        playlistJsonLdHtml = serializeJsonLd(jsonLd);
      }
    } catch {
      // Non-fatal — the page still renders without JSON-LD.
    }
  }

  return (
    <>
      {playlistJsonLdHtml && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: playlistJsonLdHtml }}
        />
      )}
      <PlaylistDetailClient
        playlist={{
          id: playlist.id,
          ownerId: playlist.ownerId,
          name: playlist.name,
          slug: playlist.slug,
          description: playlist.description,
          coverImage: playlist.coverImage,
          isPublic: playlist.isPublic,
          createdAt: playlist.createdAt.toISOString(),
          updatedAt: playlist.updatedAt.toISOString(),
          owner: playlist.owner,
          itemCount: playlist._count.items,
        }}
        items={serializedItems}
        initialCoverMedia={coverMedia}
        isOwner={!!isOwner}
      />
    </>
  );
}
