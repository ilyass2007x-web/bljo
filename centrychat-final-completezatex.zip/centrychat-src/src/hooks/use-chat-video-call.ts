"use client";

/**
 * useChatVideoCall — the hook powering Chat-based Video Calls.
 *
 * Architecture (mirrors the existing video-chat-screen.tsx WebRTC
 * flow, adapted for conversation-scoped 1:1 calls):
 *
 *   State machine:
 *     idle → requesting-permission → preview → calling →
 *     connecting → connected → ended
 *                                          ↘ failed
 *     incoming (recipient) → preview → connecting → connected
 *
 *   WebRTC:
 *     - Caller (offerer): creates the offer + sends via POST /signal.
 *     - Recipient (answerer): polls /signal, receives offer, creates answer.
 *     - Both: ICE candidates exchanged via /signal polling (500ms).
 *
 *   Cleanup:
 *     - On unmount, end-call, dialog close, navigation, or tab close:
 *       stop all MediaStream tracks (camera light off), close
 *       RTCPeerConnection, clear all intervals + listeners.
 *     - Uses a ref to track cleanup state so the React strict-mode
 *       double-mount in dev doesn't leak streams.
 *
 *   Performance:
 *     - Polling intervals are ONLY active during calling/connecting
 *       states. They're cleared on connected (no need to poll once
 *       the connection is up — WebRTC events take over) and on
 *       disconnect/end.
 *
 *   Security:
 *     - Authentication + conversation membership are enforced by the
 *       server-side API routes. The client never tells the server who
 *       the recipient is — the server derives the recipient from the
 *       conversation's other member.
 *     - TURN credentials (if any) are fetched via the existing
 *       /api/v1/video-chat/config endpoint (admin-controlled, never
 *       hardcoded).
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { api, ApiClientError } from "@/lib/client/api";
import { isVideoChatClientEnabled } from "@/lib/video-chat/enabled";
import {
  type CallPeer,
  type CallState,
  formatMediaError,
  isVideoCallSupported,
} from "@/lib/chat-video-call/types";

// ── Types (matching the API responses) ───────────────────────────────

interface CallStartResponse {
  callId: string | null;
  status: "ringing" | "busy";
  expiresAt?: number;
  recipient?: CallPeer;
  ringTimeoutMs?: number;
}

interface CallIncomingPayload {
  callId: string;
  conversationId: string;
  caller: CallPeer;
  expiresAt: number;
}

interface CallEventPayload {
  callId: string;
  conversationId: string;
  action: "accept" | "reject" | "end" | "busy";
  byUserId: string;
  reason?: string;
}

interface SignalPayload {
  id: string;
  type: "offer" | "answer" | "ice" | "end";
  payload: unknown;
  fromUserId: string;
}

interface IceConfig {
  iceServers: RTCIceServer[];
  turnEnabled: boolean;
  /**
   * Admin-controlled debug flag (from `videochat.debug_logging` PlatformSetting).
   * When true, the hook emits `[VIDEO]` diagnostic logs (state transitions,
   * ICE events, signaling milestones — NEVER SDP / ICE payloads / credentials).
   * When false (default), the hook is silent in production AND in dev.
   */
  debugLogging?: boolean;
}

// ── Constants ────────────────────────────────────────────────────────

const SIGNAL_POLL_MS = 500; // WebRTC signaling poll interval
const STATUS_POLL_MS = 2000; // Call status poll (fallback if realtime missed)

/**
 * Emit a `[VIDEO]` diagnostic log. Called by the hook at every meaningful
 * WebRTC milestone (peer created, offer sent, ICE state change, etc.).
 *
 * Gated by `debugLoggingRef.current` — when false (default), this is a no-op
 * with negligible overhead (one ref read + early return). The admin enables
 * it via the Video Chat admin panel (`videochat.debug_logging` PlatformSetting)
 * to diagnose "stuck on Connecting..." issues without redeploying.
 *
 * SECURITY: NEVER pass SDP, ICE candidate payloads, TURN credentials, or
 * session cookies to this function. Only safe metadata (state names,
 * session ID suffixes, error names).
 */
function debugLog(ref: React.MutableRefObject<boolean>, tag: string, ...args: unknown[]): void {
  if (!ref.current) return;
  console.log(`[VIDEO] ${tag}`, ...args);
}

function debugError(ref: React.MutableRefObject<boolean>, tag: string, ...args: unknown[]): void {
  if (!ref.current) return;
  console.error(`[VIDEO] ${tag}`, ...args);
}

// ── Hook params ───────────────────────────────────────────────────────

interface UseChatVideoCallParams {
  conversationId: string | null;
  /** Called by the hook when the recipient's tab receives an incoming call. */
  onIncomingCall?: (payload: CallIncomingPayload) => void;
  /** Called when a call-event realtime message arrives. */
  onCallEvent?: (payload: CallEventPayload) => void;
}

// ── Hook return ───────────────────────────────────────────────────────

interface UseChatVideoCallReturn {
  state: CallState;
  error: string | null;
  /** The remote peer's profile (for the UI header). */
  peer: CallPeer | null;
  /** Active callId (set when ringing/connecting/connected). */
  callId: string | null;
  /** Whether this client is the offerer (caller). */
  isOfferer: boolean;
  /** Live camera/mic state. */
  cameraOn: boolean;
  micOn: boolean;
  /** Refs that the dialog binds <video> elements to. */
  localVideoRef: React.RefObject<HTMLVideoElement | null>;
  remoteVideoRef: React.RefObject<HTMLVideoElement | null>;
  /** Actions. */
  startCall: () => Promise<void>;
  /** After preview, the user clicks "Start Call" — rings the recipient. */
  confirmCall: () => Promise<void>;
  /** Cancel at any pre-connected state (preview / calling / incoming). */
  cancelCall: () => Promise<void>;
  acceptIncomingCall: (callId: string, caller: CallPeer) => Promise<void>;
  rejectIncomingCall: (callId: string) => Promise<void>;
  endCall: () => Promise<void>;
  toggleCamera: () => void;
  toggleMic: () => void;
  /** Reset the hook back to idle after the UI shows the ended/failed screen. */
  reset: () => void;
  /** Whether video calling is supported in this browser. */
  supported: boolean;
  unsupportedReason: string | null;
}

// ── Hook implementation ──────────────────────────────────────────────

export function useChatVideoCall(
  params: UseChatVideoCallParams
): UseChatVideoCallReturn {
  const { conversationId } = params;

  const [state, setState] = useState<CallState>("idle");
  const [error, setError] = useState<string | null>(null);
  const [peer, setPeer] = useState<CallPeer | null>(null);
  const [callId, setCallId] = useState<string | null>(null);
  const [isOfferer, setIsOfferer] = useState(false);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);

  // Refs — mutable values that don't trigger re-renders.
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteStreamRef = useRef<MediaStream | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const iceConfigRef = useRef<IceConfig | null>(null);
  const signalPollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const statusPollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const cleanupDoneRef = useRef(false);
  // Admin-controlled debug-logging flag (mirror of iceConfigRef.current.debugLogging).
  // Gated by PlatformSetting `videochat.debug_logging`. When true, the hook
  // emits [VIDEO] diagnostic logs. Off by default — admin enables on demand.
  const debugLoggingRef = useRef(false);
  // ── WebRTC negotiation fix (Connection Reliability) ──────────────────
  // Buffer of remote ICE candidates that arrived BEFORE the remote
  // description (offer/answer) was set. addIceCandidate throws
  // InvalidStateError when called before setRemoteDescription, so we
  // buffer them here and flush immediately after setRemoteDescription
  // succeeds. CLIENT-SIDE only — Redis signaling is unchanged.
  const pendingIceCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  // Defensive 30s connection timeout. If pc.connectionState doesn't
  // reach "connected" within 30s of entering "connecting", we force-
  // fail so the user is not stuck on "Connecting..." forever. Cleared
  // on connected/failed/closed + cleanup().
  const connectionTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Mirror params in refs so callbacks don't get stale closures.
  const conversationIdRef = useRef(conversationId);
  conversationIdRef.current = conversationId;
  const onIncomingCallRef = useRef(params.onIncomingCall);
  onIncomingCallRef.current = params.onIncomingCall;
  const onCallEventRef = useRef(params.onCallEvent);
  onCallEventRef.current = params.onCallEvent;

  // The active callId in a ref so async callbacks can read the latest.
  const callIdRef = useRef<string | null>(null);
  callIdRef.current = callId;

  const supported = isVideoCallSupported();

  // ── ICE config loader (reuses existing /api/v1/video-chat/config) ────
  const loadIceConfig = useCallback(async (): Promise<boolean> => {
    // DISABLED GUARD: when the env var is not "true", short-circuit before
    // any WebRTC config fetch. The API would 403 anyway — but this saves
    // the network round-trip and prevents the ICE config from being
    // populated (which would let initWebRTC proceed).
    if (!isVideoChatClientEnabled()) {
      setError("Video chat is currently disabled.");
      setState("failed");
      return false;
    }
    try {
      const config = await api.get<IceConfig>("/api/v1/video-chat/config");
      iceConfigRef.current = config;
      // Mirror the admin-controlled debug flag into a ref so the debug
      // helpers can read it without re-rendering.
      debugLoggingRef.current = !!config.debugLogging;
      debugLog(debugLoggingRef, "ICE config loaded", {
        turnEnabled: config.turnEnabled,
        iceServerCount: config.iceServers?.length ?? 0,
      });
      return true;
    } catch (err) {
      setError(
        err instanceof ApiClientError
          ? err.message
          : "Failed to load video call configuration."
      );
      return false;
    }
  }, []);

  // ── Stop local media tracks + release camera/mic ───────────────────
  const stopLocalMedia = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {
          // Non-fatal
        }
      });
      localStreamRef.current = null;
    }
    if (localVideoRef.current) {
      // Detach so the video element doesn't keep a reference to a stopped stream.
      localVideoRef.current.srcObject = null;
    }
  }, []);

  // ── Stop remote stream + detach from video element ─────────────────
  const stopRemoteMedia = useCallback(() => {
    if (remoteStreamRef.current) {
      remoteStreamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {
          // Non-fatal
        }
      });
      remoteStreamRef.current = null;
    }
    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null;
    }
  }, []);

  // ── Close RTCPeerConnection ─────────────────────────────────────────
  // Also clears the 30s connection timeout + ICE candidate queue so
  // no stale timer fires after the PC is gone and no stale candidates
  // are flushed into a dead PC.
  const closePeerConnection = useCallback(() => {
    if (connectionTimeoutRef.current) {
      clearTimeout(connectionTimeoutRef.current);
      connectionTimeoutRef.current = null;
    }
    pendingIceCandidatesRef.current = [];
    if (pcRef.current) {
      try {
        pcRef.current.ontrack = null;
        pcRef.current.onicecandidate = null;
        pcRef.current.onconnectionstatechange = null;
        pcRef.current.close();
      } catch {
        // Non-fatal
      }
      pcRef.current = null;
    }
  }, []);

  // ── Clear polling intervals ────────────────────────────────────────
  const clearIntervals = useCallback(() => {
    if (signalPollRef.current) {
      clearInterval(signalPollRef.current);
      signalPollRef.current = null;
    }
    if (statusPollRef.current) {
      clearInterval(statusPollRef.current);
      statusPollRef.current = null;
    }
  }, []);

  // ── Full cleanup (called on end/unmount/dialog-close/tab-close) ─────
  const cleanup = useCallback(async () => {
    debugLog(debugLoggingRef, "cleanup", { callId: callIdRef.current?.slice(-6) });
    clearIntervals();
    closePeerConnection();
    stopRemoteMedia();
    stopLocalMedia();
  }, [clearIntervals, closePeerConnection, stopRemoteMedia, stopLocalMedia]);

  // ── Toggle camera (track.enabled, doesn't re-acquire the stream) ───
  const toggleCamera = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const videoTrack = stream.getVideoTracks()[0];
    if (videoTrack) {
      videoTrack.enabled = !videoTrack.enabled;
      setCameraOn(videoTrack.enabled);
    }
  }, []);

  // ── Toggle mic (track.enabled, doesn't re-acquire the stream) ───────
  const toggleMic = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const audioTrack = stream.getAudioTracks()[0];
    if (audioTrack) {
      audioTrack.enabled = !audioTrack.enabled;
      setMicOn(audioTrack.enabled);
    }
  }, []);

  // ── Build RTCPeerConnection + attach local tracks ───────────────────
  // FIX (initWebRTC early return → throw):
  //   Previously: `if (!iceConfigRef.current || !localStreamRef.current) return;`
  //   This silently returned, leaving pcRef.current = null. The caller
  //   would then proceed to sendOffer() (which also silently returned),
  //   and the UI would stay stuck on "Connecting..." forever — no PC
  //   to fire connectionState events, no timeout to fire (the timeout is
  //   only set AFTER the PC is created).
  //
  //   Now: throw an explicit Error. The caller wraps the call in a
  //   try/catch that sets state to "failed" + shows a user-friendly
  //   message. This guarantees the UI NEVER stays stuck on "Connecting..."
  //   when the prerequisites aren't met.
  const initWebRTC = useCallback(async () => {
    // DISABLED GUARD: short-circuit BEFORE constructing RTCPeerConnection.
    // This is the deepest guard — even if loadIceConfig somehow returned
    // true (it shouldn't when disabled), we NEVER construct the PC, never
    // start ICE gathering, never attach onicecandidate / ontrack handlers.
    // The connection stays null and the caller surfaces the error.
    if (!isVideoChatClientEnabled()) {
      throw new Error("Video chat is currently disabled.");
    }
    if (!iceConfigRef.current) {
      throw new Error("ICE configuration is not available.");
    }
    if (!localStreamRef.current) {
      throw new Error("Local media stream is not available.");
    }

    debugLog(debugLoggingRef, "local stream ready", {
      videoTracks: localStreamRef.current.getVideoTracks().length,
      audioTracks: localStreamRef.current.getAudioTracks().length,
    });

    // Tear down any previous peer connection (shouldn't exist, but defensive).
    closePeerConnection();

    const pc = new RTCPeerConnection(iceConfigRef.current);
    pcRef.current = pc;
    debugLog(debugLoggingRef, "peer created", {
      iceServers: iceConfigRef.current.iceServers.length,
      callId: callIdRef.current?.slice(-6),
    });

    // Add local tracks.
    localStreamRef.current.getTracks().forEach((track) => {
      pc.addTrack(track, localStreamRef.current!);
    });

    // Remote track handler — attach to remote <video> element.
    pc.ontrack = (event) => {
      const remoteStream =
        remoteStreamRef.current ?? new MediaStream();
      event.track.enabled = true;
      remoteStream.addTrack(event.track);
      remoteStreamRef.current = remoteStream;
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStream;
      }
      debugLog(debugLoggingRef, "remote stream received", {
        kind: event.track.kind,
        streamCount: event.streams.length,
      });
      // When the remote track ends (peer hung up), we'll detect via
      // connection state change.
    };

    // ICE candidate → POST to /signal for the peer to poll.
    pc.onicecandidate = (event) => {
      const currentCallId = callIdRef.current;
      const currentConvId = conversationIdRef.current;
      if (event.candidate && currentCallId && currentConvId) {
        debugLog(debugLoggingRef, "ICE candidate sent", {
          type: event.candidate.type,
          protocol: event.candidate.protocol,
          // NEVER log the candidate's address — it may leak NAT topology.
        });
        void api
          .post(`/api/v1/conversations/${currentConvId}/call/signal`, {
            callId: currentCallId,
            type: "ice",
            payload: event.candidate.toJSON(),
          })
          .catch(() => {
            // Non-fatal — ICE candidates are best-effort.
          });
      }
    };

    // ── Connection state machine (Connection Reliability) ──────────────
    //   connected    → clear the 30s timeout, UI = connected
    //   connecting/new → keep "connecting" (or "reconnecting" if we
    //                   briefly dropped from connected during an ICE
    //                   restart). Don't override if already connected.
    //   disconnected → "reconnecting" — WebRTC can recover from this;
    //                  we don't assume the call ended.
    //   failed       → clear the timeout, UI = failed (fatal)
    //   closed       → clear the timeout; treat as ended if we were
    //                  connected, else failed.
    pc.onconnectionstatechange = () => {
      const connState = pc.connectionState;
      debugLog(debugLoggingRef, "connection state", {
        connState,
        signalingState: pc.signalingState,
        iceConnectionState: pc.iceConnectionState,
        callId: callIdRef.current?.slice(-6),
      });
      if (connState === "connected") {
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
          connectionTimeoutRef.current = null;
        }
        setState("connected");
      } else if (connState === "connecting" || connState === "new") {
        // Stay in connecting — don't override "connected" if we briefly
        // drop into "connecting" during ICE restarts.
        setState((prev) =>
          prev === "connected" ? "reconnecting" : "connecting"
        );
      } else if (connState === "disconnected") {
        // Don't fail — WebRTC can recover. Mark as "reconnecting" so
        // the UI shows the user we're trying to restore the call.
        setState("reconnecting");
      } else if (connState === "failed") {
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
          connectionTimeoutRef.current = null;
        }
        setError("Connection failed. The peer may have left.");
        setState("failed");
      } else if (connState === "closed") {
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
          connectionTimeoutRef.current = null;
        }
        setState((prev) =>
          prev === "connected" || prev === "ended" ? "ended" : "failed"
        );
      }
    };

    // ── Defensive 30s connection timeout (Connection Reliability) ────
    // Cleared by onconnectionstatechange on connected/failed/closed,
    // and by cleanup(). If we don't reach "connected" within 30s, we
    // force-fail so the user is not stuck on "Connecting..." forever.
    //
    // FIX: previously this timeout was set INSIDE initWebRTC AFTER the
    //   early-return guard. With the throw-based guard above, the
    //   timeout is now guaranteed to be set whenever a PC is successfully
    //   created (no code path can reach `setState("connecting")` without
    //   a PC and a timeout).
    //
    // The error message is user-friendly (no technical jargon). The
    // technical state values are logged via debugLog when admin-enabled.
    if (connectionTimeoutRef.current) clearTimeout(connectionTimeoutRef.current);
    connectionTimeoutRef.current = setTimeout(() => {
      const currentPc = pcRef.current;
      if (!currentPc) return; // PC was closed via cleanup — no-op.
      if (currentPc.connectionState !== "connected") {
        debugError(debugLoggingRef, "connection timeout", {
          connectionState: currentPc.connectionState,
          signalingState: currentPc.signalingState,
          iceConnectionState: currentPc.iceConnectionState,
          callId: callIdRef.current?.slice(-6),
        });
        setError("Unable to establish video connection. Please try again.");
        setState("failed");
      }
    }, 30_000);
  }, [closePeerConnection]);

  // ── Start signal polling (called after WebRTC init) ─────────────────
  // Connection Reliability:
  //   - Each signal is processed in its OWN try/catch so a failure in
  //     one signal does NOT stop the rest of the batch.
  //   - The outer try/catch only catches the HTTP fetch itself (network
  //     error) — the polling loop keeps running.
  //   - ICE candidates that arrive before setRemoteDescription are
  //     buffered in pendingIceCandidatesRef and flushed atomically
  //     after the offer/answer is set.
  //   - Offer handling is atomic. If any step fails, the call is
  //     marked failed — we don't leave the caller waiting forever.
  //   - Answer handling checks pc.signalingState === "have-local-offer"
  //     first; if not, the answer is stale and we just log + skip.
  const startSignalPolling = useCallback(
    (targetCallId: string, convId: string) => {
      if (signalPollRef.current) clearInterval(signalPollRef.current);

      signalPollRef.current = setInterval(async () => {
        // Outer try/catch ONLY for the HTTP fetch. If the fetch fails,
        // we keep polling — the next tick may succeed.
        let result: { signals: SignalPayload[] };
        try {
          result = await api.get<{ signals: SignalPayload[] }>(
            `/api/v1/conversations/${convId}/call/signal?callId=${targetCallId}`
          );
        } catch (err) {
          // Network error — keep polling. Log safely (no SDP / no
          // tokens / no ICE payloads).
          debugError(debugLoggingRef, "signal fetch failed", {
            callId: targetCallId.slice(-6),
            error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
          });
          return;
        }

        for (const signal of result.signals) {
          const pc = pcRef.current;
          if (!pc) continue;

          // Per-signal try/catch — a failure here does NOT stop the
          // remaining signals in this batch, and does NOT kill the
          // polling loop.
          try {
            if (signal.type === "offer") {
              debugLog(debugLoggingRef, "offer received", {
                callId: targetCallId.slice(-6),
                signalingState: pc.signalingState,
              });
              // Atomic offer handling:
              //   1. setRemoteDescription(offer)
              //   2. flush queued ICE candidates
              //   3. createAnswer()
              //   4. setLocalDescription(answer)
              //   5. POST answer to peer
              await pc.setRemoteDescription(
                signal.payload as RTCSessionDescriptionInit
              );
              const queued = pendingIceCandidatesRef.current;
              pendingIceCandidatesRef.current = [];
              for (const candidate of queued) {
                try {
                  await pc.addIceCandidate(candidate);
                } catch (err) {
                  debugError(debugLoggingRef, "queued addIceCandidate failed (offer-flush)", {
                    callId: targetCallId.slice(-6),
                    error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
                  });
                }
              }
              const answer = await pc.createAnswer();
              await pc.setLocalDescription(answer);
              debugLog(debugLoggingRef, "answer created", { callId: targetCallId.slice(-6) });
              await api.post(
                `/api/v1/conversations/${convId}/call/signal`,
                {
                  callId: targetCallId,
                  type: "answer",
                  payload: answer,
                }
              );
              debugLog(debugLoggingRef, "answer sent", { callId: targetCallId.slice(-6) });
            } else if (signal.type === "answer") {
              // Only apply if we are in "have-local-offer" state. If the
              // state is "stable", we already applied it (duplicate).
              // Otherwise the answer is stale — log + skip without
              // breaking the polling loop.
              if (pc.signalingState === "have-local-offer") {
                debugLog(debugLoggingRef, "answer received", { callId: targetCallId.slice(-6) });
                await pc.setRemoteDescription(
                  signal.payload as RTCSessionDescriptionInit
                );
                // Flush queued ICE candidates that arrived before the answer.
                const queued = pendingIceCandidatesRef.current;
                pendingIceCandidatesRef.current = [];
                for (const candidate of queued) {
                  try {
                    await pc.addIceCandidate(candidate);
                  } catch (err) {
                    debugError(debugLoggingRef, "queued addIceCandidate failed (answer-flush)", {
                      callId: targetCallId.slice(-6),
                      error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
                    });
                  }
                }
              } else {
                debugLog(debugLoggingRef, "skipping stale answer", {
                  callId: targetCallId.slice(-6),
                  signalingState: pc.signalingState,
                });
              }
            } else if (signal.type === "ice") {
              // Queue if remote description not set yet. Otherwise
              // addIceCandidate with try/catch — one bad candidate is
              // not fatal.
              if (!pc.remoteDescription) {
                debugLog(debugLoggingRef, "ICE candidate received (buffered)", {
                  callId: targetCallId.slice(-6),
                  queueSize: pendingIceCandidatesRef.current.length + 1,
                });
                pendingIceCandidatesRef.current.push(
                  signal.payload as RTCIceCandidateInit
                );
              } else {
                debugLog(debugLoggingRef, "ICE candidate received", {
                  callId: targetCallId.slice(-6),
                });
                try {
                  await pc.addIceCandidate(
                    signal.payload as RTCIceCandidateInit
                  );
                } catch (err) {
                  debugError(debugLoggingRef, "addIceCandidate failed", {
                    callId: targetCallId.slice(-6),
                    error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
                  });
                  // Continue — one bad candidate is not fatal.
                }
              }
            } else if (signal.type === "end") {
              setState("ended");
              setError("The other person ended the call.");
              clearIntervals();
              void cleanup();
              return;
            }
          } catch (err) {
            // Per-signal error — log safely (no SDP / no payload) and
            // continue with the next signal. The polling loop is NOT
            // killed.
            debugError(debugLoggingRef, `signal "${signal.type}" failed`, {
              callId: targetCallId.slice(-6),
              error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
            });
            // If this was an offer/answer failure, the negotiation is
            // stuck — mark the call as failed so the user is not left
            // on "Connecting..." forever. ICE failures are non-fatal
            // (handled above).
            if (signal.type === "offer" || signal.type === "answer") {
              if (connectionTimeoutRef.current) {
                clearTimeout(connectionTimeoutRef.current);
                connectionTimeoutRef.current = null;
              }
              setError("Unable to establish video connection. Please try again.");
              setState("failed");
            }
          }
        }
      }, SIGNAL_POLL_MS);
    },
    [clearIntervals, cleanup]
  );

  // ── Caller: create offer + start polling ────────────────────────────
  // FIX (sendOffer silent return → throw):
  //   Previously: `if (!pc) return;` — silently returned if the PC wasn't
  //   created (e.g. initWebRTC threw earlier and the caller didn't check).
  //   This left the caller's UI stuck on "Connecting..." forever — no
  //   offer was sent, no error was surfaced, no timeout was running.
  //
  //   Now: throw an explicit Error. The caller (status-poll handler in
  //   confirmCall, or acceptIncomingCall) wraps the call in a try/catch
  //   that sets state to "failed" + shows a user-friendly message.
  const sendOffer = useCallback(
    async (targetCallId: string, convId: string) => {
      const pc = pcRef.current;
      if (!pc) {
        throw new Error("WebRTC peer connection is not initialized.");
      }
      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        debugLog(debugLoggingRef, "offer created", { callId: targetCallId.slice(-6) });
        await api.post(`/api/v1/conversations/${convId}/call/signal`, {
          callId: targetCallId,
          type: "offer",
          payload: offer,
        });
        debugLog(debugLoggingRef, "offer sent", { callId: targetCallId.slice(-6) });
      } catch (err) {
        debugError(debugLoggingRef, "sendOffer failed", {
          callId: targetCallId.slice(-6),
          error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
        });
        setError(
          err instanceof Error
            ? err.message
            : "Failed to start WebRTC negotiation."
        );
        setState("failed");
      }
    },
    []
  );

  // ── Request camera + mic permission ─────────────────────────────────
  const requestMedia = useCallback(async (): Promise<MediaStream | null> => {
    // DISABLED GUARD: short-circuit BEFORE calling getUserMedia. This
    // is the CRITICAL guard — when Video Chat is disabled, the browser
    // camera/mic permission prompt is NEVER shown to the user. No
    // camera light, no permission dialog, no MediaStream.
    if (!isVideoChatClientEnabled()) {
      setError("Video chat is currently disabled.");
      setState("failed");
      return null;
    }
    if (!isVideoCallSupported()) {
      setError("Video calling is not supported by this browser.");
      setState("failed");
      return null;
    }
    debugLog(debugLoggingRef, "getUserMedia", { step: "requesting" });
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" }, // front camera preferred for calls
        audio: true,
      });
      localStreamRef.current = stream;
      debugLog(debugLoggingRef, "getUserMedia", {
        step: "granted",
        videoTracks: stream.getVideoTracks().length,
        audioTracks: stream.getAudioTracks().length,
      });
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
        // Mute the local preview so the user doesn't hear themselves.
        localVideoRef.current.muted = true;
        try {
          await localVideoRef.current.play();
        } catch {
          // Autoplay might be blocked — the play() call is best-effort.
        }
      }
      // Sync the camera/mic toggle state with the actual track enabled state.
      const videoTrack = stream.getVideoTracks()[0];
      const audioTrack = stream.getAudioTracks()[0];
      setCameraOn(videoTrack ? videoTrack.enabled : false);
      setMicOn(audioTrack ? audioTrack.enabled : false);
      return stream;
    } catch (err) {
      debugError(debugLoggingRef, "getUserMedia failed", {
        error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
      });
      setError(formatMediaError(err));
      setState("failed");
      return null;
    }
  }, []);

  // ── startCall (caller flow): preview → calling → connecting → connected
  const startCall = useCallback(async () => {
    setError(null);
    // DISABLED GUARD: top-level short-circuit. When Video Chat is disabled,
    // the entire flow (permission prompt, preview, ICE config, signaling)
    // is bypassed. The user sees the disabled error and the state moves
    // to "failed" — no camera/mic access, no API call.
    if (!isVideoChatClientEnabled()) {
      setError("Video chat is currently disabled.");
      setState("failed");
      return;
    }
    const convId = conversationIdRef.current;
    if (!convId) {
      setError("No conversation selected.");
      setState("failed");
      return;
    }

    setState("requesting-permission");

    // 1. Get camera + mic.
    const stream = await requestMedia();
    if (!stream) return; // requestMedia already set the error + failed state.

    setState("preview");
  }, [requestMedia]);

  // ── After preview, the user clicks "Start Call" → ring the recipient ─
  const confirmCall = useCallback(async () => {
    const convId = conversationIdRef.current;
    if (!convId) {
      setError("No conversation selected.");
      setState("failed");
      return;
    }
    // Capture as a non-null const for the closure below. TypeScript's
    // control-flow narrowing doesn't currently survive across closure
    // boundaries for refs that hold `T | null`, so we explicitly bind a
    // string-typed alias. This is a type-system artifact only — the runtime
    // value is the same as convId (already verified non-null above).
    const convIdNonNull: string = convId;

    // Load ICE config before starting.
    const ok = await loadIceConfig();
    if (!ok) {
      setState("failed");
      return;
    }

    try {
      const result = await api.post<CallStartResponse>(
        `/api/v1/conversations/${convIdNonNull}/call/start`,
        {}
      );

      if (result.status === "busy" || !result.callId) {
        setState("busy");
        return;
      }

      setCallId(result.callId);
      callIdRef.current = result.callId;
      setIsOfferer(true);
      if (result.recipient) setPeer(result.recipient);
      setState("calling");

      // Bind to non-null locals for the closure below. TypeScript's
      // control-flow narrowing doesn't survive across closure boundaries
      // for property accesses (result.callId), so we explicitly bind
      // string-typed aliases. Runtime values are identical.
      const activeCallId: string = result.callId;
      const activeConvId: string = convIdNonNull;

      // Start polling /call/status as a fallback in case realtime is missed.
      if (statusPollRef.current) clearInterval(statusPollRef.current);
      statusPollRef.current = setInterval(async () => {
        try {
          const status = await api.get<{
            callState: "ringing" | "accepted" | "ended" | "expired";
          }>(`/api/v1/conversations/${activeConvId}/call/status?callId=${activeCallId}`);

          if (status.callState === "expired") {
            if (statusPollRef.current) clearInterval(statusPollRef.current);
            setError("No answer. The call has been cancelled.");
            setState("failed");
            void cleanup();
          } else if (status.callState === "ended") {
            if (statusPollRef.current) clearInterval(statusPollRef.current);
            setState("ended");
            void cleanup();
          } else if (status.callState === "accepted") {
            // Realtime event handler will trigger WebRTC init — but if
            // realtime is missed, this poll is the safety net.
            if (statusPollRef.current) clearInterval(statusPollRef.current);
            // FIX: previously, initWebRTC + sendOffer could silently
            // return (early-return guards) and the caller would proceed
            // to startSignalPolling — leaving the UI stuck on "Connecting..."
            // forever (no PC, no timeout). Now both throw on missing
            // prerequisites; we catch here to surface a user-friendly
            // error + transition to "failed" instead of leaving the UI stuck.
            try {
              await initWebRTC();
              setState("connecting");
              await sendOffer(activeCallId, activeConvId);
              startSignalPolling(activeCallId, activeConvId);
            } catch (err) {
              debugError(debugLoggingRef, "caller WebRTC init/offer failed", {
                callId: activeCallId.slice(-6),
                error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
              });
              if (connectionTimeoutRef.current) {
                clearTimeout(connectionTimeoutRef.current);
                connectionTimeoutRef.current = null;
              }
              setError("Unable to establish video connection. Please try again.");
              setState("failed");
              void cleanup();
            }
          }
        } catch {
          // Non-fatal — keep polling the /call/status endpoint. Network
          // blips shouldn't kill the call attempt.
        }
      }, STATUS_POLL_MS);
    } catch (err) {
      setError(
        err instanceof ApiClientError
          ? err.message
          : "Failed to start the call."
      );
      setState("failed");
    }
  }, [loadIceConfig, initWebRTC, sendOffer, startSignalPolling, cleanup]);

  // ── Cancel at any pre-connected state ───────────────────────────────
  const cancelCall = useCallback(async () => {
    const currentCallId = callIdRef.current;
    const convId = conversationIdRef.current;
    // Only notify the server if we actually started a call (have a callId).
    if (currentCallId && convId) {
      try {
        await api.post(`/api/v1/conversations/${convId}/call/end`, {
          callId: currentCallId,
          reason: "user_cancelled",
        });
      } catch {
        // Non-fatal
      }
    }
    await cleanup();
    setState("idle");
    setCallId(null);
    callIdRef.current = null;
    setPeer(null);
    setError(null);
  }, [cleanup]);

  // ── End an active or ringing call (either party) ────────────────────
  const endCall = useCallback(async () => {
    const currentCallId = callIdRef.current;
    const convId = conversationIdRef.current;
    if (currentCallId && convId) {
      try {
        await api.post(`/api/v1/conversations/${convId}/call/end`, {
          callId: currentCallId,
          reason: "user_ended",
        });
      } catch {
        // Non-fatal
      }
    }
    await cleanup();
    setState("ended");
    setCallId(null);
    callIdRef.current = null;
  }, [cleanup]);

  // ── Recipient accepts an incoming call ──────────────────────────────
  const acceptIncomingCall = useCallback(
    async (incomingCallId: string, caller: CallPeer) => {
      // DISABLED GUARD: short-circuit before requesting media. Even when
      // an incoming call somehow arrives (realtime event or polling), the
      // recipient's UI surfaces "Video chat is currently disabled." instead
      // of opening the camera. The incoming call will time out + ring-back
      // as "missed" server-side (the caller sees "No answer.").
      if (!isVideoChatClientEnabled()) {
        setError("Video chat is currently disabled.");
        setState("failed");
        return;
      }
      const convId = conversationIdRef.current;
      if (!convId) {
        setError("No conversation selected.");
        setState("failed");
        return;
      }

      setState("requesting-permission");
      const stream = await requestMedia();
      if (!stream) return; // error + failed state already set.

      // Load ICE config.
      const ok = await loadIceConfig();
      if (!ok) {
        setState("failed");
        return;
      }

      // Accept via API (server-side checks recipient identity).
      try {
        await api.post(`/api/v1/conversations/${convId}/call/accept`, {
          callId: incomingCallId,
        });
      } catch (err) {
        setError(
          err instanceof ApiClientError
            ? err.message
            : "Failed to accept the call."
        );
        setState("failed");
        return;
      }

      setCallId(incomingCallId);
      callIdRef.current = incomingCallId;
      setIsOfferer(false);
      setPeer(caller);
      setState("connecting");

      // Wait for the offer from the caller via signal polling.
      // FIX: initWebRTC now throws on missing prerequisites (was silent
      // return). Catch here to surface a user-friendly error + transition
      // to "failed" instead of leaving the UI stuck on "Connecting..."
      // (which was the actual bug reported: callers stayed on Connecting
      // forever when the recipient's PC failed to initialize).
      try {
        await initWebRTC();
        startSignalPolling(incomingCallId, convId);
      } catch (err) {
        debugError(debugLoggingRef, "recipient initWebRTC failed", {
          callId: incomingCallId.slice(-6),
          error: err instanceof Error ? `${err.name}: ${err.message}` : "unknown",
        });
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
          connectionTimeoutRef.current = null;
        }
        setError("Unable to establish video connection. Please try again.");
        setState("failed");
        void cleanup();
      }
    },
    [requestMedia, loadIceConfig, initWebRTC, startSignalPolling, cleanup]
  );

  // ── Recipient rejects an incoming call ──────────────────────────────
  const rejectIncomingCall = useCallback(async (incomingCallId: string) => {
    const convId = conversationIdRef.current;
    if (!convId) return;
    try {
      await api.post(`/api/v1/conversations/${convId}/call/end`, {
        callId: incomingCallId,
        reason: "rejected",
      });
    } catch {
      // Non-fatal
    }
    setState("idle");
  }, []);

  // ── Reset back to idle (called by UI after ended/failed screen) ────
  const reset = useCallback(() => {
    setState("idle");
    setError(null);
    setPeer(null);
    setCallId(null);
    callIdRef.current = null;
    setIsOfferer(false);
  }, []);

  // ── Cleanup on unmount + tab close ──────────────────────────────────
  useEffect(() => {
    // Skip the redundant effect run in React strict-mode dev.
    if (cleanupDoneRef.current) return;
    cleanupDoneRef.current = false;

    const handleBeforeUnload = () => {
      // Synchronous best-effort cleanup on tab close.
      // We can't await API calls here, but stopping tracks is sync.
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((t) => {
          try {
            t.stop();
          } catch {
            // ignore
          }
        });
      }
      if (remoteStreamRef.current) {
        remoteStreamRef.current.getTracks().forEach((t) => {
          try {
            t.stop();
          } catch {
            // ignore
          }
        });
      }
      if (pcRef.current) {
        try {
          pcRef.current.close();
        } catch {
          // ignore
        }
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      void cleanup();
      cleanupDoneRef.current = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    state,
    error,
    peer,
    callId,
    isOfferer,
    cameraOn,
    micOn,
    localVideoRef,
    remoteVideoRef,
    startCall,
    confirmCall,
    cancelCall,
    acceptIncomingCall,
    rejectIncomingCall,
    endCall,
    toggleCamera,
    toggleMic,
    reset,
    supported,
    unsupportedReason: supported
      ? null
      : "Video calling is not supported by this browser.",
  };
}
