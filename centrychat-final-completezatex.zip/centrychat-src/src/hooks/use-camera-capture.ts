"use client";

/**
 * useCameraCapture — camera capture hook for the post composer.
 *
 * Manages the full camera-permission + capture lifecycle:
 *   1. Request camera access via navigator.mediaDevices.getUserMedia({video}).
 *   2. Attach the stream to a <video> element for live preview.
 *   3. Capture a still frame onto a <canvas> + convert to a Blob.
 *   4. Stop ALL camera tracks the moment capture completes, the user
 *      cancels, or the component unmounts.
 *  5. Provide graceful fallback when the API is unsupported or permission
 *      is denied (the caller falls back to <input type="file" capture>).
 *
 * STATES (per spec §2):
 *   - "idle"        — no permission requested yet.
 *   - "requesting"  — getUserMedia() is in-flight.
 *   - "granted"     — stream is live + attached to the video element.
 *   - "denied"      — user blocked camera access (NotAllowedError).
 *   - "unsupported" — navigator.mediaDevices is missing or the device
 *                     has no camera (NotFoundError / NotReadableError).
 *   - "error"       — any other failure (OverconstrainedError, etc.).
 *
 * SECURITY (spec §9):
 *   - The hook NEVER requests camera access automatically on mount. The
 *     caller must explicitly call `requestCamera()`.
 *   - The hook NEVER stores the raw stream — it's held in a ref + the
 *     video element's srcObject. The blob URL is created only AFTER the
 *     user clicks "Capture" + is revoked the moment the hook unmounts
 *     or the user retakes / cancels.
 *   - The captured photo is just a Blob — no PII, no audio, no network
 *     upload happens inside this hook. The caller is responsible for
 *     routing the blob through the existing upload pipeline.
 *
 * CLEANUP (spec §2 — "Stop all camera tracks immediately when..."):
 *   - On `stopCamera()` (called when the dialog closes / user cancels /
 *     photo is captured / component unmounts): every track in the stream
 *     has .stop() called, the video element's srcObject is nulled, the
 *     stream ref is cleared. The camera light on the device turns off.
 *
 * BROWSER COMPATIBILITY (spec §5):
 *   - Checks `navigator.mediaDevices` existence + `getUserMedia` presence
 *     BEFORE calling it (feature detection, NOT user-agent sniffing).
 *   - Catches the standard MediaDevices error types + converts each to a
 *     user-friendly state + message:
 *       NotAllowedError       → "denied"
 *       NotFoundError         → "unsupported" (no camera found)
 *       NotReadableError      → "unsupported" (camera in use / hardware)
 *       OverconstrainedError  → "unsupported" (constraints can't be met)
 *       SecurityError         → "denied" (browser-level block)
 *       AbortError            → "idle" (user dismissed the prompt — non-fatal)
 *   - HTTPS-only: getUserMedia is only available in secure contexts.
 *     The hook also checks `window.isSecureContext` and returns
 *     "unsupported" when false (with a clear message).
 */

import { useCallback, useEffect, useRef, useState } from "react";

export type CameraState =
  | "idle"
  | "requesting"
  | "granted"
  | "denied"
  | "unsupported"
  | "error";

export interface CameraCaptureResult {
  /** The captured photo as a Blob (image/jpeg). */
  blob: Blob;
  /** A temporary object URL for previewing the blob. Caller MUST revoke. */
  previewUrl: string;
}

export interface UseCameraCapture {
  state: CameraState;
  /** User-facing message describing the current state (or error). */
  message: string;
  /** Start the camera — request permission + attach to the video element. */
  requestCamera: (videoEl: HTMLVideoElement | null) => Promise<void>;
  /** Capture a still frame from the current stream. Returns the blob + a preview URL. */
  capturePhoto: (videoEl: HTMLVideoElement | null) => Promise<CameraCaptureResult | null>;
  /** Stop all camera tracks + detach the stream. Safe to call multiple times. */
  stopCamera: () => void;
  /** Whether the browser supports getUserMedia at all (for the unsupported state). */
  isSupported: boolean;
}

/**
 * Detect whether the browser supports getUserMedia. Used to render the
 * "unsupported" state instead of attempting the call + crashing.
 */
export function isCameraSupported(): boolean {
  if (typeof window === "undefined") return false;
  if (typeof navigator === "undefined" || !navigator.mediaDevices) return false;
  if (typeof navigator.mediaDevices.getUserMedia !== "function") return false;
  // HTTPS-only. localhost counts as a secure context in dev.
  if (!window.isSecureContext) return false;
  return true;
}

export function useCameraCapture(): UseCameraCapture {
  const [state, setState] = useState<CameraState>("idle");
  const [message, setMessage] = useState<string>("");
  const streamRef = useRef<MediaStream | null>(null);
  // Track the current video element so we can detach on unmount even if
  // the caller forgot to call stopCamera().
  const videoRef = useRef<HTMLVideoElement | null>(null);

  /**
   * Internal: stop every track on the current stream + clear refs.
   * Idempotent — safe to call multiple times.
   */
  const stopTracks = useCallback(() => {
    const stream = streamRef.current;
    if (stream) {
      for (const track of stream.getTracks()) {
        try {
          track.stop();
        } catch {
          /* ignore — track may already be stopped */
        }
      }
      streamRef.current = null;
    }
    if (videoRef.current) {
      try {
        videoRef.current.srcObject = null;
      } catch {
        /* ignore */
      }
      videoRef.current = null;
    }
  }, []);

  /**
   * Request camera access. Resolves when the stream is attached to the
   * video element. Throws (caught + converted to a state) on any error.
   */
  const requestCamera = useCallback(
    async (videoEl: HTMLVideoElement | null) => {
      if (!videoEl) {
        setState("error");
        setMessage("Video element not ready.");
        return;
      }
      if (!isCameraSupported()) {
        setState("unsupported");
        setMessage("Camera is not supported in this browser.");
        return;
      }
      setState("requesting");
      setMessage("");
      try {
        // Prefer the rear/environment camera on mobile. Desktops usually
        // only have a front-facing camera, so we fall back to "any" when
        // the environment facing mode is unavailable (OverconstrainedError).
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: "environment" } },
            audio: false,
          });
        } catch (err) {
          if (err instanceof DOMException && err.name === "OverconstrainedError") {
            // Fallback: any camera (desktop, front-facing, etc.).
            stream = await navigator.mediaDevices.getUserMedia({
              video: true,
              audio: false,
            });
          } else {
            throw err;
          }
        }
        streamRef.current = stream;
        videoRef.current = videoEl;
        videoEl.srcObject = stream;
        // Wait for the video to actually start playing before flipping
        // the state to "granted" — otherwise capturePhoto() may fire
        // before the video dimensions are available.
        await videoEl.play().catch(() => {
          // play() can reject on autoplay-policy issues. We don't treat
          // this as fatal — the video may still render frames. The user
          // can retry by clicking the preview.
        });
        setState("granted");
        setMessage("");
      } catch (err) {
        const name = err instanceof DOMException ? err.name : "Unknown";
        if (name === "NotAllowedError" || name === "SecurityError") {
          setState("denied");
          setMessage("Camera access was blocked. Please allow camera access in your browser settings and try again.");
        } else if (
          name === "NotFoundError" ||
          name === "NotReadableError" ||
          name === "OverconstrainedError"
        ) {
          setState("unsupported");
          setMessage("No camera found on this device.");
        } else if (name === "AbortError") {
          // User dismissed the permission prompt — non-fatal, go back to idle.
          setState("idle");
          setMessage("");
        } else {
          setState("error");
          setMessage("Unable to access the camera. Please try again.");
        }
      }
    },
    []
  );

  /**
   * Capture a still frame from the current video stream onto a canvas
   * + convert to a JPEG Blob. Returns { blob, previewUrl } or null on
   * any error.
   *
   * The caller is responsible for revoking the previewUrl when done
   * (the hook revokes the previous URL when a new capture happens or
   * on unmount, but if the caller holds onto the URL for the post
   * lifetime it must revoke it themselves).
   */
  const capturePhoto = useCallback(
    async (videoEl: HTMLVideoElement | null): Promise<CameraCaptureResult | null> => {
      if (!videoEl || !streamRef.current) return null;
      // Wait until the video has valid dimensions. This handles the race
      // where the user clicks "Capture" before play() has fired the
      // loadedmetadata event.
      const w = videoEl.videoWidth;
      const h = videoEl.videoHeight;
      if (!w || !h) {
        setMessage("Camera is still warming up. Please try again in a moment.");
        return null;
      }
      try {
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) return null;
        ctx.drawImage(videoEl, 0, 0, w, h);
        // Use JPEG for smaller payloads. Quality 0.85 is a good balance.
        const blob: Blob | null = await new Promise((resolve) => {
          canvas.toBlob(resolve, "image/jpeg", 0.85);
        });
        if (!blob) return null;
        const previewUrl = URL.createObjectURL(blob);
        return { blob, previewUrl };
      } catch {
        setMessage("Failed to capture the photo. Please try again.");
        return null;
      }
    },
    []
  );

  const stopCamera = useCallback(() => {
    stopTracks();
    // Don't reset the state to "idle" here — the caller decides what
    // state to show after stopping (idle after cancel, idle after
    // successful capture, etc.).
  }, [stopTracks]);

  // Cleanup on unmount — the camera MUST NOT stay running when the
  // component using this hook unmounts (spec §2 + §12).
  useEffect(() => {
    return () => {
      stopTracks();
    };
  }, [stopTracks]);

  return {
    state,
    message,
    requestCamera,
    capturePhoto,
    stopCamera,
    isSupported: isCameraSupported(),
  };
}
