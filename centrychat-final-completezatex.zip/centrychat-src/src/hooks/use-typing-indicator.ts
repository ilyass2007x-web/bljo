"use client";

import { useCallback, useEffect, useRef, useState } from "react";

interface TypingUser {
  userId: string;
  fullName: string;
}

interface UseTypingIndicatorOptions {
  /** Current conversation ID. */
  conversationId: string | null;
  /** Current user ID (to exclude self from typing display). */
  currentUserId: string | undefined;
  /** Auto-stop timeout in ms (default 3000). */
  timeoutMs?: number;
  /** Throttle interval for emitting typing.start (default 1000ms). */
  throttleMs?: number;
  /** Emit typing event to the server. */
  emitTyping: (conversationId: string, isTyping: boolean) => void;
}

/**
 * Manages typing indicator state for a conversation.
 *
 * Behavior:
 *  - When the local user types, emits typing.start (throttled — not every keystroke).
 *  - After `timeoutMs` of inactivity, emits typing.stop automatically.
 *  - Tracks other users who are typing (received via realtime events).
 *  - Auto-clears a user's typing status if no new event is received within timeoutMs.
 */
export function useTypingIndicator({
  conversationId,
  currentUserId,
  timeoutMs = 3000,
  throttleMs = 1000,
  emitTyping,
}: UseTypingIndicatorOptions) {
  const [typingUsers, setTypingUsers] = useState<TypingUser[]>([]);
  const lastEmitRef = useRef<number>(0);
  const stopTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const userTimeoutsRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  // Keep the latest conversationId in a ref so callbacks don't need to be recreated.
  const conversationIdRef = useRef(conversationId);
  useEffect(() => {
    conversationIdRef.current = conversationId;
  });

  // When the conversation changes, clear typing state.
  useEffect(() => {
    // Clear all remote user timeouts.
    for (const t of userTimeoutsRef.current.values()) clearTimeout(t);
    userTimeoutsRef.current.clear();
    if (stopTimerRef.current) {
      clearTimeout(stopTimerRef.current);
      stopTimerRef.current = null;
    }
    // Clearing typing users when conversation changes is intentional.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setTypingUsers([]);
  }, [conversationId]);

  /**
   * Called when the local user types. Emits typing.start (throttled) and
   * schedules an auto-stop after timeoutMs of inactivity.
   */
  const onLocalTyping = useCallback(() => {
    const convId = conversationIdRef.current;
    if (!convId) return;
    const now = Date.now();
    if (now - lastEmitRef.current >= throttleMs) {
      lastEmitRef.current = now;
      emitTyping(convId, true);
    }
    if (stopTimerRef.current) clearTimeout(stopTimerRef.current);
    stopTimerRef.current = setTimeout(() => {
      emitTyping(convId, false);
    }, timeoutMs);
  }, [throttleMs, timeoutMs, emitTyping]);

  /**
   * Called when the local user sends a message or leaves the conversation.
   * Immediately emits typing.stop.
   */
  const onLocalStop = useCallback(() => {
    const convId = conversationIdRef.current;
    if (!convId) return;
    if (stopTimerRef.current) {
      clearTimeout(stopTimerRef.current);
      stopTimerRef.current = null;
    }
    emitTyping(convId, false);
  }, [emitTyping]);

  /**
   * Called when a remote typing event is received (via realtime).
   * Adds/refreshes the user in the typing list and sets a timeout to auto-remove them.
   */
  const onRemoteTyping = useCallback(
    (payload: { conversationId?: string; userId?: string; fullName?: string; isTyping?: boolean }) => {
      const convId = conversationIdRef.current;
      if (!payload?.conversationId || payload.conversationId !== convId) return;
      if (!payload?.userId || payload.userId === currentUserId) return;

      const userId = payload.userId;
      const fullName = payload.fullName ?? "";

      if (payload.isTyping === false) {
        setTypingUsers((prev) => prev.filter((u) => u.userId !== userId));
        const t = userTimeoutsRef.current.get(userId);
        if (t) {
          clearTimeout(t);
          userTimeoutsRef.current.delete(userId);
        }
      } else {
        setTypingUsers((prev) => {
          const exists = prev.some((u) => u.userId === userId);
          if (exists) {
            return prev.map((u) => (u.userId === userId ? { ...u, fullName } : u));
          }
          return [...prev, { userId, fullName }];
        });
        const existing = userTimeoutsRef.current.get(userId);
        if (existing) clearTimeout(existing);
        userTimeoutsRef.current.set(
          userId,
          setTimeout(() => {
            setTypingUsers((prev) => prev.filter((u) => u.userId !== userId));
            userTimeoutsRef.current.delete(userId);
          }, timeoutMs + 1000)
        );
      }
    },
    [currentUserId, timeoutMs]
  );

  // Cleanup on unmount.
  useEffect(() => {
    return () => {
      if (stopTimerRef.current) clearTimeout(stopTimerRef.current);
      for (const t of userTimeoutsRef.current.values()) clearTimeout(t);
    };
  }, []);

  return {
    typingUsers,
    onLocalTyping,
    onLocalStop,
    onRemoteTyping,
  };
}
