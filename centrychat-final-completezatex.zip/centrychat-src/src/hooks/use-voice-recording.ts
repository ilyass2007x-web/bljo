"use client";

/**
 * useVoiceRecording — microphone recording hook for the post composer.
 *
 * Manages the full microphone-permission + recording lifecycle:
 *   1. Request microphone access via navigator.mediaDevices.getUserMedia({audio}).
 *   2. Start a MediaRecorder on the live stream.
 *   3. Collect chunks as the recording runs.
 *   4. Stop the recorder + assemble the chunks into a single audio Blob.
 *   5. Stop ALL microphone tracks immediately when recording stops or
 *      is cancelled, or when the component unmounts.
 *
 * STATES (per spec §3):
 *   - "idle"        — no permission requested yet.
 *   - "requesting"  — getUserMedia() is in-flight.
 *   - "recording"   — MediaRecorder is running, audio chunks accumulating.
 *   - "denied"      — user blocked microphone access (NotAllowedError).
 *   - "unsupported" — navigator.mediaDevices is missing or no microphone
 *                     is available (NotFoundError / NotReadableError).
 *   - "error"       — any other failure (e.g. MediaRecorder unsupported).
 *
 * DURATION:
 *   A `durationSeconds` counter ticks every second while recording. The
 *   caller renders this as mm:ss for the user.
 *
 * SECURITY (spec §9):
 *   - The hook NEVER requests microphone access automatically on mount.
 *     The caller must explicitly call `startRecording()`.
 *   - Raw audio chunks are NOT exposed outside the hook — only the final
 *     Blob is returned to the caller after `stopRecording()` resolves.
 *   - The stream + recorder are torn down the moment recording stops.
 *     No audio is sent anywhere — the caller is responsible for routing
 *     the Blob through the existing upload pipeline.
 *
 * CLEANUP (spec §3 — "Stop all microphone tracks after recording finishes
 * or is cancelled"):
 *   - On `stopRecording()` + `cancelRecording()` + unmount: every track
 *     in the stream has .stop() called, the MediaRecorder is stopped if
 *     running, the chunk array is cleared, the duration timer is cleared.
 *
 * BROWSER COMPATIBILITY (spec §5):
 *   - Checks `navigator.mediaDevices` + `getUserMedia` + `MediaRecorder`
 *     existence before attempting to record.
 *   - Picks the best supported mime type from a candidate list (audio/webm
 *     on Chrome/Firefox/Edge; audio/mp4 on Safari iOS 14.3+; falls back to
 *     the browser default).
 *   - Catches all the standard MediaDevices + MediaRecorder errors and
 *     converts each to a user-friendly state + message.
 */

import { useCallback, useEffect, useRef, useState } from "react";

export type VoiceState =
  | "idle"
  | "requesting"
  | "recording"
  | "denied"
  | "unsupported"
  | "error";

export interface VoiceRecordingResult {
  /** The recorded audio as a Blob (audio/webm or audio/mp4). */
  blob: Blob;
  /** A temporary object URL for previewing the blob. Caller MUST revoke. */
  previewUrl: string;
  /** The mime type the blob was recorded in. */
  mimeType: string;
  /** The recording duration in seconds. */
  durationSeconds: number;
}

export interface UseVoiceRecording {
  state: VoiceState;
  /** User-facing message describing the current state (or error). */
  message: string;
  /** Seconds elapsed since recording started (0 when idle). */
  durationSeconds: number;
  /** Whether the browser supports audio recording at all. */
  isSupported: boolean;
  /** Start recording — request mic + start MediaRecorder. */
  startRecording: () => Promise<void>;
  /** Stop the recorder + return the captured audio. Resolves after the
      onstop event fires. Returns null on any failure. */
  stopRecording: () => Promise<VoiceRecordingResult | null>;
  /** Cancel an in-progress recording — discards chunks + stops the stream.
      Safe to call when idle. */
  cancelRecording: () => void;
}

/**
 * Detect whether the browser supports voice recording. Used to render
 * the "unsupported" state without attempting the call.
 */
export function isVoiceRecordingSupported(): boolean {
  if (typeof window === "undefined") return false;
  if (typeof navigator === "undefined" || !navigator.mediaDevices) return false;
  if (typeof navigator.mediaDevices.getUserMedia !== "function") return false;
  if (typeof window.MediaRecorder === "undefined") return false;
  if (!window.isSecureContext) return false;
  return true;
}

/**
 * Pick the best supported audio mime type for MediaRecorder.
 *
 * Order:
 *   1. audio/webm;codecs=opus  (Chrome, Firefox, Edge — best compression)
 *   2. audio/webm              (Chrome, Firefox, Edge fallback)
 *   3. audio/mp4               (Safari iOS 14.3+)
 *   4. (browser default — empty string) — let MediaRecorder pick.
 */
function pickAudioMimeType(): string {
  if (typeof window === "undefined" || typeof window.MediaRecorder === "undefined") {
    return "";
  }
  const candidates = [
    "audio/webm;codecs=opus",
    "audio/webm",
    "audio/mp4",
  ];
  for (const t of candidates) {
    try {
      if (window.MediaRecorder.isTypeSupported(t)) return t;
    } catch {
      // isTypeSupported can throw on some browsers — skip + try the next.
    }
  }
  return ""; // let the browser pick
}

export function useVoiceRecording(): UseVoiceRecording {
  const [state, setState] = useState<VoiceState>("idle");
  const [message, setMessage] = useState<string>("");
  const [durationSeconds, setDurationSeconds] = useState<number>(0);
  const streamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mimeTypeRef = useRef<string>("");
  const recordingStartRef = useRef<number>(0);
  // Resolver for the in-flight stopRecording() promise — fired when
  // MediaRecorder's onstop event fires.
  const stopResolverRef = useRef<
    ((result: VoiceRecordingResult | null) => void) | null
  >(null);

  /**
   * Internal: stop every track on the current stream + null the stream ref.
   */
  const stopTracks = useCallback(() => {
    const stream = streamRef.current;
    if (stream) {
      for (const track of stream.getTracks()) {
        try {
          track.stop();
        } catch {
          /* ignore */
        }
      }
      streamRef.current = null;
    }
  }, []);

  /**
   * Internal: clear the duration timer.
   */
  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  /**
   * Internal: tear down the recorder + stream + timer (used by stop,
   * cancel, and unmount).
   */
  const teardown = useCallback(() => {
    clearTimer();
    if (recorderRef.current) {
      try {
        if (recorderRef.current.state !== "inactive") {
          recorderRef.current.stop();
        }
      } catch {
        /* ignore */
      }
      // Detach the onstop handler — we don't want stale handlers firing
      // after teardown (especially after cancel).
      recorderRef.current.onstop = null;
      recorderRef.current.ondataavailable = null;
      recorderRef.current.onerror = null;
      recorderRef.current = null;
    }
    stopTracks();
    chunksRef.current = [];
    mimeTypeRef.current = "";
    stopResolverRef.current = null;
  }, [clearTimer, stopTracks]);

  /**
   * Start recording. Resolves when MediaRecorder.state === "recording".
   * Throws (caught + converted to a state) on any error.
   */
  const startRecording = useCallback(async () => {
    if (!isVoiceRecordingSupported()) {
      setState("unsupported");
      setMessage("Audio recording is not supported in this browser.");
      return;
    }
    setState("requesting");
    setMessage("");
    setDurationSeconds(0);
    chunksRef.current = [];
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false,
      });
      streamRef.current = stream;
      const mimeType = pickAudioMimeType();
      mimeTypeRef.current = mimeType;
      // Construct the recorder. The mime type may be "" (browser default)
      // — that's a valid input for MediaRecorder.
      const recorder = new MediaRecorder(
        stream,
        mimeType ? { mimeType } : undefined
      );
      recorderRef.current = recorder;
      recorder.ondataavailable = (e: BlobEvent) => {
        if (e.data && e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };
      recorder.onstop = () => {
        // Assemble the chunks into a single Blob. If no chunks arrived,
        // resolve with null (caller treats as "no audio captured").
        const chunks = chunksRef.current;
        if (chunks.length === 0) {
          if (stopResolverRef.current) {
            stopResolverRef.current(null);
            stopResolverRef.current = null;
          }
          return;
        }
        const blobMimeType = mimeTypeRef.current || "audio/webm";
        const blob = new Blob(chunks, { type: blobMimeType });
        const previewUrl = URL.createObjectURL(blob);
        // Resolve the in-flight stopRecording() promise with the result.
        // Snapshot durationSeconds from the closure so the result has the
        // final recorded duration (the state update for clearing it
        // hasn't fired yet).
        const duration = Math.round(
          (Date.now() - recordingStartRef.current) / 1000
        );
        const result: VoiceRecordingResult = {
          blob,
          previewUrl,
          mimeType: blobMimeType,
          durationSeconds: duration,
        };
        // Stop the tracks AFTER assembling the blob — on Safari the
        // recorder.onstop event fires before tracks can be safely stopped
        // mid-blob. Calling stopTracks() here is fine.
        stopTracks();
        chunksRef.current = [];
        if (stopResolverRef.current) {
          stopResolverRef.current(result);
          stopResolverRef.current = null;
        }
      };
      recorder.onerror = () => {
        setState("error");
        setMessage("Recording failed. Please try again.");
        teardown();
      };
      // Start the recorder. timeslice=250ms means ondataavailable fires
      // every 250ms — chunks accumulate incrementally (so a crash mid-
      // recording still leaves a partial recording in memory).
      recorder.start(250);
      recordingStartRef.current = Date.now();
      // Tick the duration counter every second.
      clearTimer();
      timerRef.current = setInterval(() => {
        setDurationSeconds((s) => s + 1);
      }, 1000);
      setState("recording");
      setMessage("");
    } catch (err) {
      const name = err instanceof DOMException ? err.name : "Unknown";
      if (name === "NotAllowedError" || name === "SecurityError") {
        setState("denied");
        setMessage("Microphone access was blocked. Please allow microphone access in your browser settings and try again.");
      } else if (
        name === "NotFoundError" ||
        name === "NotReadableError" ||
        name === "OverconstrainedError"
      ) {
        setState("unsupported");
        setMessage("No microphone found on this device.");
      } else if (name === "AbortError") {
        setState("idle");
        setMessage("");
      } else {
        setState("error");
        setMessage("Unable to access the microphone. Please try again.");
      }
      stopTracks();
    }
  }, [clearTimer, stopTracks, teardown]);

  /**
   * Stop recording + return the captured audio. Resolves after
   * MediaRecorder.onstop fires (so the chunks are fully assembled).
   */
  const stopRecording = useCallback(async (): Promise<VoiceRecordingResult | null> => {
    const recorder = recorderRef.current;
    if (!recorder || recorder.state === "inactive") {
      teardown();
      setState("idle");
      return null;
    }
    // Return a promise that resolves when onstop fires.
    const result = await new Promise<VoiceRecordingResult | null>((resolve) => {
      stopResolverRef.current = resolve;
      try {
        recorder.stop();
      } catch {
        // If stop() throws, resolve with null (no recording).
        resolve(null);
      }
      // Safety timeout — if onstop never fires (browser bug), resolve
      // with null after 5 seconds so the UI doesn't hang forever.
      setTimeout(() => {
        if (stopResolverRef.current) {
          stopResolverRef.current(null);
          stopResolverRef.current = null;
        }
      }, 5000);
    });
    clearTimer();
    setState("idle");
    return result;
  }, [clearTimer, teardown]);

  /**
   * Cancel an in-progress recording — discards chunks + stops the stream.
   * Safe to call when idle (no-op).
   */
  const cancelRecording = useCallback(() => {
    // Detach the onstop handler so it doesn't fire after we tear down
    // (we want to discard, not deliver).
    if (recorderRef.current) {
      recorderRef.current.onstop = null;
    }
    teardown();
    setDurationSeconds(0);
    setState("idle");
    setMessage("");
  }, [teardown]);

  // Cleanup on unmount — the microphone MUST NOT stay running.
  useEffect(() => {
    return () => {
      teardown();
    };
  }, [teardown]);

  return {
    state,
    message,
    durationSeconds,
    isSupported: isVoiceRecordingSupported(),
    startRecording,
    stopRecording,
    cancelRecording,
  };
}

/**
 * Format a duration in seconds as "mm:ss" (or "h:mm:ss" when > 1 hour).
 * Pure helper — exported for the UI to format the duration display.
 */
export function formatRecordingDuration(totalSeconds: number): string {
  if (!Number.isFinite(totalSeconds) || totalSeconds < 0) return "0:00";
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.floor(totalSeconds % 60);
  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${m}:${String(s).padStart(2, "0")}`;
}
