"use client";

import { useEffect, useRef, useState } from "react";
import { io, type Socket } from "socket.io-client";

export type RealtimeEvent =
  | "message:new"
  | "message:update"
  | "message:delete"
  | "message:read"
  | "conversation:read"
  | "notification:new"
  | "presence:update"
  | "typing.start"
  | "typing.stop"
  // ── Chat Video Call (additive) ──────────────────────────────────
  | "conversation:call:incoming"
  | "conversation:call:event";

type Handlers = Partial<Record<RealtimeEvent, (payload: unknown) => void>>;

/**
 * Connects to the realtime mini-service via the gateway.
 * The gateway forwards `/?XTransformPort=3003` to the socket.io service.
 * Auth is via the session cookie (sent with credentials:include).
 */
export function useRealtime(enabled: boolean, handlers: Handlers) {
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const handlersRef = useRef<Handlers>(handlers);

  // Update handlers ref in an effect (not during render).
  useEffect(() => {
    handlersRef.current = handlers;
  });

  useEffect(() => {
    if (!enabled) return;
    const socket = io("/", {
      path: "/",
      transports: ["websocket", "polling"],
      withCredentials: true,
      query: { XTransformPort: "3003" },
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 10,
    });
    socketRef.current = socket;

    const onConnect = () => {
      setConnected(true);
      console.log("[realtime] connected");
    };
    const onDisconnect = () => {
      setConnected(false);
      console.log("[realtime] disconnected");
    };
    const onConnectError = (err: Error) => {
      setConnected(false);
      console.log("[realtime] connection error:", err.message);
    };
    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);
    socket.on("connect_error", onConnectError);
    socket.on("auth:error", () => setConnected(false));

    const events: RealtimeEvent[] = [
      "message:new",
      "message:update",
      "message:delete",
      "message:read",
      "conversation:read",
      "notification:new",
      "presence:update",
      "typing.start",
      "typing.stop",
      // Chat Video Call (additive)
      "conversation:call:incoming",
      "conversation:call:event",
    ];
    for (const ev of events) {
      socket.on(ev, (payload: unknown) => {
        handlersRef.current[ev]?.(payload);
      });
    }

    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
      socket.off("connect_error", onConnectError);
      socket.disconnect();
      socketRef.current = null;
      setConnected(false);
    };
  }, [enabled]);

  /**
   * Emit a typing event. The server resolves userId from the authenticated
   * socket — NEVER from the client payload.
   */
  function emitTyping(conversationId: string, isTyping: boolean) {
    const socket = socketRef.current;
    if (!socket || !connected) return;
    socket.emit(isTyping ? "typing:start" : "typing:stop", { conversationId });
  }

  /**
   * Notify the server which conversation is currently being viewed
   * (used for presence & typing fan-out).
   */
  function setActiveConversation(conversationId: string | null) {
    const socket = socketRef.current;
    if (!socket) return;
    if (conversationId) {
      socket.emit("conversation:active", { conversationId });
    }
  }

  return { connected, emitTyping, setActiveConversation };
}
