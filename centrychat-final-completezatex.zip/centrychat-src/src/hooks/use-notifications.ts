"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, type NotificationDTO } from "@/lib/client/api";

export interface NotificationItem extends NotificationDTO {
  readAt: string | null;
  targetType: string | null;
  targetId: string | null;
  conversationId: string | null;
  messageId: string | null;
  senderId: string | null;
}

interface UseNotificationsResult {
  notifications: NotificationItem[];
  unreadCount: number;
  hasMore: boolean;
  loading: boolean;
  open: boolean;
  setOpen: (open: boolean) => void;
  refresh: () => Promise<void>;
  loadMore: () => Promise<void>;
  markAsRead: (id: string) => Promise<NotificationItem | null>;
  markAllAsRead: () => Promise<void>;
  addNotification: (n: NotificationItem) => void;
}

const BROADCAST_CHANNEL = "sentrychat-notifications";

/**
 * Centralized notification state.
 *
 * Features:
 *  - Fetches initial notifications + unread count from the API.
 *  - Realtime: the caller passes new notifications via `addNotification`.
 *  - Multi-tab sync via BroadcastChannel — when Tab A marks a notification
 *    as read, Tab B updates its unread badge instantly.
 *  - Pagination via cursor (beforeId).
 *  - Mark as read / mark all as read update the server then local state.
 */
export function useNotifications(enabled: boolean): UseNotificationsResult {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const channelRef = useRef<BroadcastChannel | null>(null);

  const refresh = useCallback(async () => {
    try {
      const data = await api.get<{
        notifications: NotificationItem[];
        unreadCount: number;
        hasMore: boolean;
      }>("/api/v1/notifications?limit=20");
      setNotifications(data.notifications);
      setUnreadCount(data.unreadCount);
      setHasMore(data.hasMore);
    } catch {
      /* ignore */
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial load.
  useEffect(() => {
    if (!enabled) return;
    void refresh();
  }, [enabled, refresh]);

  // Multi-tab synchronization via BroadcastChannel.
  useEffect(() => {
    if (!enabled || typeof BroadcastChannel === "undefined") return;
    const channel = new BroadcastChannel(BROADCAST_CHANNEL);
    channelRef.current = channel;

    channel.onmessage = (event) => {
      const msg = event.data;
      if (!msg) return;
      if (msg.type === "notification:new") {
        // Another tab received a notification — sync it here too.
        setNotifications((prev) => {
          if (prev.some((n) => n.id === msg.notification.id)) return prev;
          return [msg.notification, ...prev];
        });
        setUnreadCount((c) => c + 1);
      } else if (msg.type === "notification:read") {
        setNotifications((prev) =>
          prev.map((n) =>
            n.id === msg.id
              ? { ...n, read: true, readAt: new Date().toISOString() }
              : n
          )
        );
        setUnreadCount((c) => Math.max(0, c - 1));
      } else if (msg.type === "notification:read-all") {
        setNotifications((prev) =>
          prev.map((n) => ({ ...n, read: true, readAt: new Date().toISOString() }))
        );
        setUnreadCount(0);
      } else if (msg.type === "notification:refresh") {
        // Another tab triggered a refresh — sync from server.
        void refresh();
      }
    };

    return () => {
      channel.close();
      channelRef.current = null;
    };
  }, [enabled, refresh]);

  const broadcast = useCallback((msg: unknown) => {
    channelRef.current?.postMessage(msg);
  }, []);

  const addNotification = useCallback(
    (n: NotificationItem) => {
      setNotifications((prev) => {
        if (prev.some((x) => x.id === n.id)) return prev;
        return [n, ...prev];
      });
      setUnreadCount((c) => c + 1);
      // Broadcast to other tabs.
      broadcast({ type: "notification:new", notification: n });
    },
    [broadcast]
  );

  const loadMore = useCallback(async () => {
    if (!hasMore || notifications.length === 0) return;
    const last = notifications[notifications.length - 1];
    try {
      const data = await api.get<{
        notifications: NotificationItem[];
        hasMore: boolean;
      }>(`/api/v1/notifications?limit=20&beforeId=${last!.id}`);
      setNotifications((prev) => [...prev, ...data.notifications]);
      setHasMore(data.hasMore);
    } catch {
      /* ignore */
    }
  }, [hasMore, notifications]);

  const markAsRead = useCallback(
    async (id: string): Promise<NotificationItem | null> => {
      // Optimistic update.
      let wasUnread = false;
      setNotifications((prev) =>
        prev.map((n) => {
          if (n.id === id && !n.read) {
            wasUnread = true;
            return { ...n, read: true, readAt: new Date().toISOString() };
          }
          return n;
        })
      );
      if (wasUnread) {
        setUnreadCount((c) => Math.max(0, c - 1));
        broadcast({ type: "notification:read", id });
      }
      // Server-side mark as read (returns the notification target for navigation).
      try {
        const data = await api.post<{ notification: NotificationItem }>(
          `/api/v1/notifications/${id}/read`
        );
        return data.notification;
      } catch {
        return null;
      }
    },
    [broadcast]
  );

  const markAllAsRead = useCallback(async () => {
    setNotifications((prev) =>
      prev.map((n) => ({ ...n, read: true, readAt: new Date().toISOString() }))
    );
    setUnreadCount(0);
    broadcast({ type: "notification:read-all" });
    try {
      await api.post("/api/v1/notifications/read-all");
    } catch {
      /* ignore */
    }
  }, [broadcast]);

  return {
    notifications,
    unreadCount,
    hasMore,
    loading,
    open,
    setOpen,
    refresh,
    loadMore,
    markAsRead,
    markAllAsRead,
    addNotification,
  };
}
