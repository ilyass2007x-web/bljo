"use client";

import { useEffect, useRef } from "react";
import { api } from "@/lib/client/api";

/**
 * useHeartbeat — sends a lightweight presence update every 30 seconds
 * while the user is authenticated and the tab is visible.
 *
 * Behavior:
 *   - Sends POST /api/v1/presence/heartbeat every 30s when:
 *     a) The user is authenticated (enabled === true)
 *     b) document.visibilityState === "visible" (tab is in foreground)
 *   - Stops sending when the tab is hidden (backgrounded) — the server's
 *     lastSeenAt becomes stale, which correctly marks the user as Offline.
 *   - Resumes when the tab becomes visible again.
 *   - Cleans up the interval on unmount.
 *
 * Presence threshold:
 *   The chat header considers a user "Online" if their lastSeenAt is
 *   within the last 60 seconds. Since the heartbeat fires every 30s,
 *   a user with an active tab will always be within the 60s window.
 *   If they close the tab or background it, the lastSeenAt stops
 *   updating and they become "Offline" within 60s.
 *
 * No new WebSocket or realtime infrastructure — just a simple polling
 * heartbeat that updates the existing `lastSeenAt` field in the DB.
 * The conversation list (which is polled every 5s by the Messenger)
 * picks up the updated lastSeenAt and the chat header reflects it.
 */
const HEARTBEAT_INTERVAL_MS = 30_000;

export function useHeartbeat(enabled: boolean) {
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!enabled) return;

    const sendHeartbeat = () => {
      // Only send if the tab is visible — background tabs don't count
      // as "active" presence.
      if (typeof document !== "undefined" && document.visibilityState !== "visible") {
        return;
      }
      // Fire-and-forget — don't await, don't block UI.
      void api.post("/api/v1/presence/heartbeat").catch(() => {
        // Silent failure — heartbeat is non-critical. If it fails
        // (network error, server down), the user will just appear
        // Offline sooner, which is the safe default.
      });
    };

    // Send an initial heartbeat immediately.
    void sendHeartbeat();

    // Set up the interval.
    intervalRef.current = setInterval(sendHeartbeat, HEARTBEAT_INTERVAL_MS);

    // Pause/resume on visibility change.
    const onVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        // Tab became visible — send heartbeat immediately, then resume interval.
        void sendHeartbeat();
      }
    };
    document.addEventListener("visibilitychange", onVisibilityChange);

    // Send a final heartbeat when the page is about to unload (best-effort).
    const onBeforeUnload = () => {
      // Use sendBeacon for reliability during page unload.
      if (typeof navigator !== "undefined" && navigator.sendBeacon) {
        navigator.sendBeacon("/api/v1/presence/heartbeat");
      }
    };
    window.addEventListener("beforeunload", onBeforeUnload);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("beforeunload", onBeforeUnload);
    };
  }, [enabled]);
}
