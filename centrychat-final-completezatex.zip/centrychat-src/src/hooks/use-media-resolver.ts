"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { api } from "@/lib/client/api";
import type { ResolvedMedia } from "@/lib/media/types";

/**
 * useMediaResolver — client hook that resolves any URL into a
 * `ResolvedMedia` object via the /api/v1/media/resolve endpoint.
 *
 * Features:
 *   - Debounced (default 500ms) — avoids spamming the API on every keystroke.
 *   - In-memory cache (Map<url, ResolvedMedia>) — multiple components
 *     resolving the same URL share a single API call.
 *   - Stale-response guard — if the user pastes URL A then URL B before A's
 *     response arrives, A's response is discarded.
 *   - Returns loading + error states alongside the resolved media.
 *
 * Usage:
 *   const { media, loading, error } = useMediaResolver(url);
 *   <MediaRenderer media={media} loading={loading} error={error} />
 *
 * The hook is SAFE to use with an empty string (returns null media, no
 * loading state, no API call). This lets callers render a placeholder
 * when the user hasn't pasted a URL yet.
 */

// Module-level cache shared by all useMediaResolver instances.
// Keyed by URL string. Entries never expire at the module level (they're
// just metadata — small). The server-side resolver has its own 5-minute
// cache, so even a "stale" client entry triggers a single cheap API call.
const cache = new Map<string, ResolvedMedia>();

export interface UseMediaResolverResult {
  media: ResolvedMedia | null;
  loading: boolean;
  error: string | null;
}

/**
 * Resolve a URL with debouncing + caching.
 *
 * @param url The URL to resolve. Empty/null = idle state.
 * @param debounceMs Debounce delay (default 500ms). Set to 0 for immediate
 *                   resolution (e.g. when displaying already-stored article
 *                   coverImage/videoUrl).
 */
export function useMediaResolver(
  url: string | null | undefined,
  debounceMs = 500
): UseMediaResolverResult {
  const [media, setMedia] = useState<ResolvedMedia | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Tracks the URL currently in-flight, so we can discard stale responses.
  const inflightRef = useRef<string | null>(null);
  // Tracks the latest URL requested by the caller.
  const latestUrlRef = useRef<string | null>(null);

  const resolve = useCallback(async (target: string) => {
    // Check cache first.
    const cached = cache.get(target);
    if (cached) {
      setMedia(cached);
      setLoading(false);
      setError(null);
      return;
    }
    // Mark loading + dispatch API call.
    setLoading(true);
    setError(null);
    inflightRef.current = target;
    try {
      const data = await api.post<{ media: ResolvedMedia }>("/api/v1/media/resolve", { url: target });
      // Stale check: discard if the user pasted a different URL meanwhile.
      if (inflightRef.current !== target) return;
      const resolved = data.media;
      cache.set(target, resolved);
      setMedia(resolved);
      setLoading(false);
    } catch (err) {
      if (inflightRef.current !== target) return;
      const msg = err instanceof Error ? err.message : "Failed to resolve URL";
      setError(msg);
      setMedia(null);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const trimmed = (url ?? "").trim();
    latestUrlRef.current = trimmed;
    if (!trimmed) {
      // Idle — no media, no loading, no error.
      inflightRef.current = null;
      setMedia(null);
      setLoading(false);
      setError(null);
      return;
    }
    // Basic client-side scheme check — don't bother the server with
    // obviously-invalid URLs.
    if (!/^https?:\/\//i.test(trimmed)) {
      inflightRef.current = null;
      setMedia(null);
      setLoading(false);
      setError("URL must start with http:// or https://");
      return;
    }
    // Synchronous cache hit — skip debounce entirely.
    const cached = cache.get(trimmed);
    if (cached) {
      inflightRef.current = null;
      setMedia(cached);
      setLoading(false);
      setError(null);
      return;
    }
    // Debounced fetch.
    let cancelled = false;
    const timer = setTimeout(() => {
      if (cancelled) return;
      if (latestUrlRef.current !== trimmed) return;
      void resolve(trimmed);
    }, debounceMs);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [url, debounceMs, resolve]);

  return { media, loading, error };
}

/**
 * Synchronous cache accessor — used by SSR components (e.g. the article
 * reading page server component) to skip the client-side fetch when the
 * URL was already resolved server-side.
 *
 * Returns null when the URL isn't in the client cache yet.
 */
export function getCachedMedia(url: string): ResolvedMedia | null {
  return cache.get(url) ?? null;
}

/**
 * Manually add a resolved media to the client cache (e.g. when the server
 * pre-resolved the URL during SSR). The next call to useMediaResolver(url)
 * will return this cached value synchronously.
 */
export function setCachedMedia(url: string, media: ResolvedMedia): void {
  cache.set(url, media);
}
