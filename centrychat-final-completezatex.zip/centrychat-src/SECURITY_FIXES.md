# Security Fixes Applied

## CRITICAL Fixes

### C-1: JSON-LD XSS via topic tag
- **File:** `src/lib/seo/article.ts` — `serializeJsonLd()` now escapes `<` to `\u003c`
- **File:** `src/app/topics/[tag]/page.tsx` — uses `serializeJsonLd()` instead of raw `JSON.stringify()`

## HIGH Fixes

### H-1: Rate limits added to 11 endpoints
- **File:** `src/lib/security/rate-limit/index.ts` — added 8 new presets
- **Files:** 10 API route files — added `checkRateLimit()` calls:
  - `posts/route.ts` (postCreate: 20/min)
  - `articles/route.ts` (articleCreate: 5/5min)
  - `posts/[id]/comments/route.ts` (comment: 30/min)
  - `articles/[id]/comments/route.ts` (comment: 30/min)
  - `posts/[id]/like/route.ts` (like: 60/min)
  - `articles/[id]/like/route.ts` (like: 60/min)
  - `posts/[id]/share/route.ts` (share: 30/min)
  - `articles/[id]/share/route.ts` (share: 30/min)
  - `users/[username]/follow/route.ts` (follow: 30/min)
  - `interactions/route.ts` (interaction: 120/min)

### H-2: JSON-LD XSS via article title/author
- **File:** `src/lib/seo/article.ts` — `serializeJsonLd()` now escapes `<` to `\u003c`

## MEDIUM Fixes

### M-1: Dev fallback secret hardening
- **File:** `src/lib/auth/session.ts` — fail-closed when `NODE_ENV` is not `"development"` or `"test"`

### M-4: Removed unused `next-auth` dependency
- **File:** `package.json`

### M-5: Removed unused `react-syntax-highlighter` dependency
- **File:** `package.json`

## LOW Fixes

### L-1: Permissions-Policy header consistency
- **File:** `netlify.toml` — added `browsing-topics=()`

### L-2: Removed `'unsafe-eval'` from CSP
- **File:** `src/lib/security/headers/index.ts`

## Remaining Issues

### L-3: `sameSite: "lax"` — ACCEPTED RISK
- Acceptable trade-off for UX. `"strict"` would break email deep-links.

### L-6: `ignoreBuildErrors: true` — REMAINING
- Pre-existing TypeScript errors would break the build if set to `false`. Requires fixing all type errors first (out of scope for this audit).
