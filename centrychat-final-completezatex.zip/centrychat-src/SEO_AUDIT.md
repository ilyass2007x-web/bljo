# SEO Audit Report

## Summary

| Severity | Found | Fixed |
|----------|-------|-------|
| CRITICAL | 0 | 0 |
| HIGH | 1 | 1 |
| MEDIUM | 2 | 2 |
| LOW | 3 | 3 |

## HIGH

### SEO-H1: JSON-LD XSS (cross-listed as Security H-2)
- **File:** `src/lib/seo/article.ts:863`, `src/app/topics/[tag]/page.tsx:221`
- **Problem:** `serializeJsonLd` and inline `JSON.stringify` didn't escape `</script>`. Attacker-crafted article titles or topic tags could inject malicious scripts via JSON-LD blocks. Google may also flag the site for malformed structured data.
- **Fix:** `serializeJsonLd` now escapes `<` to `\u003c`. Topic page uses `serializeJsonLd` instead of raw `JSON.stringify`.
- **Status:** ✅ FIXED

## MEDIUM

### SEO-M1: Sitemap includes noindex root URL
- **File:** `src/app/sitemap.ts:59-65`
- **Problem:** Sitemap included `/` (priority 1.0) but `/` has `noindex, nofollow` (robots meta + X-Robots-Tag). Contradictory signals waste crawl budget.
- **Fix:** Removed root entry from sitemap. Only published article URLs remain.
- **Status:** ✅ FIXED

### SEO-M2: Root layout missing default OG image
- **File:** `src/app/layout.tsx:108-127`
- **Problem:** No `og:image` or `twitter:image` in root metadata. Social media link previews showed blank cards.
- **Fix:** Added `images: [{ url: \`${baseUrl}/og-default.png\` }]` to OpenGraph + Twitter Card (upgraded from `summary` to `summary_large_image`).
- **Status:** ✅ FIXED

## LOW

### SEO-L1: Broken SearchAction in WebSite JSON-LD
- **File:** `src/app/layout.tsx:189`
- **Problem:** `SearchAction` target pointed to `/?view=profile&username=...` (noindex SPA route). Google requires a real indexable search results page. Could be flagged as misleading structured data.
- **Fix:** Removed the `potentialAction` field from WebSite JSON-LD.
- **Status:** ✅ FIXED

### SEO-L2: Misleading `keywords` meta tag
- **File:** `src/app/layout.tsx:103`
- **Problem:** `<meta name="keywords">` ignored by Google since ~2009. Adds noise.
- **Fix:** Removed the `keywords` field from generateMetadata.
- **Status:** ✅ FIXED

### SEO-L3: `Permissions-Policy` header mismatch (cross-listed as Security L-1)
- **File:** `netlify.toml:69`
- **Problem:** Static assets served by Netlify got weaker 3-feature header (missing `browsing-topics=()`).
- **Fix:** Added `browsing-topics=()` to netlify.toml.
- **Status:** ✅ FIXED

## What's Already Good (No Action Needed)

- ✅ **Dynamic metadata**: Article + topic pages use `generateMetadata()` for server-rendered `<title>`, `<meta description>`, canonical, OG, Twitter Card.
- ✅ **Canonical URLs**: All use absolute URLs from `NEXT_PUBLIC_APP_BASE_URL`. Article canonical: `${baseUrl}/articles/${id}`. Topic canonical: `${baseUrl}/topics/${tag}`.
- ✅ **Robots.txt**: Correctly allows `/articles/` + `/topics/`, disallows SPA root `/`.
- ✅ **Sitemap**: Dynamic, excludes drafts, caps at 50,000 URLs, uses real `updatedAt` timestamps.
- ✅ **JSON-LD Structured Data**: Article, BreadcrumbList, Organization, WebSite, CollectionPage — all emitted correctly.
- ✅ **Article pages**: Full OG metadata with images, publishedTime, modifiedTime, authors. `robots: { index: true, follow: true }`.
- ✅ **Indexing control**: Admin/dashboard/messages/settings are noindex (SPA root has `robots: { index: false }`). Article + topic pages are indexable.
- ✅ **Internal linking**: Related Articles section (server-rendered) uses real `<a href>` crawlable links.
- ✅ **404 handling**: `notFound()` called for missing/draft articles → HTTP 404 with noindex metadata.
- ✅ **URL structure**: Article URLs are `/articles/${id}` — stable, unique. No trailing-slash issues (Next.js App Router handles this).
- ✅ **Image alt text**: Article cover images use the article title as alt text.
- ✅ **hreflang**: Not implemented — the site doesn't have separate language URLs (translations are a client-side UX feature, not separate indexable pages). Correct to NOT add hreflang when there are no alternate-language URLs.
