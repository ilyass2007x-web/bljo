-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Add parentCommentId to PostComment + ArticleComment,
--            create PostCommentLike + ArticleCommentLike tables.
--
-- IDEMPOTENT — safe to run on every deploy.
-- BACKWARD COMPATIBLE: parentCommentId defaults to NULL (existing comments
-- are treated as top-level). All existing data is preserved.
--
-- ── LEGACY GUARD (added 2026-09) ───────────────────────────────────────────
-- The PostComment + ArticleComment tables may not exist on legacy
-- Production DBs (legacy shape uses Comment+CommentLike for video comments
-- instead). The ALTER TABLE statements below are wrapped in DO blocks
-- that check for table existence — no-op when the table is missing.
-- The CREATE TABLE IF NOT EXISTS statements for PostCommentLike +
-- ArticleCommentLike are already safe (they create new tables).
-- ────────────────────────────────────────────────────────────────────────────

-- Add parentCommentId to PostComment (guarded — no-op if PostComment doesn't exist)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'PostComment'
  ) THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'PostComment' AND column_name = 'parentCommentId'
    ) THEN
      ALTER TABLE "PostComment" ADD COLUMN "parentCommentId" TEXT;
    END IF;
    CREATE INDEX IF NOT EXISTS "PostComment_parentCommentId_idx" ON "PostComment" ("parentCommentId");
  END IF;
END $$;

-- Add parentCommentId to ArticleComment (guarded)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'ArticleComment'
  ) THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'ArticleComment' AND column_name = 'parentCommentId'
    ) THEN
      ALTER TABLE "ArticleComment" ADD COLUMN "parentCommentId" TEXT;
    END IF;
    CREATE INDEX IF NOT EXISTS "ArticleComment_parentCommentId_idx" ON "ArticleComment" ("parentCommentId");
  END IF;
END $$;

-- Create PostCommentLike table (always safe — new table)
CREATE TABLE IF NOT EXISTS "PostCommentLike" (
    "id"        TEXT NOT NULL,
    "commentId" TEXT NOT NULL,
    "userId"    TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "PostCommentLike_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "PostCommentLike_commentId_userId_key" ON "PostCommentLike" ("commentId", "userId");
CREATE INDEX IF NOT EXISTS "PostCommentLike_userId_idx" ON "PostCommentLike" ("userId");

-- Create ArticleCommentLike table (always safe — new table)
CREATE TABLE IF NOT EXISTS "ArticleCommentLike" (
    "id"        TEXT NOT NULL,
    "commentId" TEXT NOT NULL,
    "userId"    TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "ArticleCommentLike_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "ArticleCommentLike_commentId_userId_key" ON "ArticleCommentLike" ("commentId", "userId");
CREATE INDEX IF NOT EXISTS "ArticleCommentLike_userId_idx" ON "ArticleCommentLike" ("userId");
