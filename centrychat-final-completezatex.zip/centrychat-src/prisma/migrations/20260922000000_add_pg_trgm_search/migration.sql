-- ──────────────────────────────────────────────────────────────────────────
-- Phase 2B — Search Retrieval & Relevance Foundation
-- ──────────────────────────────────────────────────────────────────────────
--
-- PURPOSE:
--   Adds the `pg_trgm` PostgreSQL extension + GIN trigram indexes on the
--   searchable text columns. This enables:
--     1. FASTER case-insensitive substring search (`ILIKE`) — the existing
--        Phase 2A retrieval path. With a `gin_trgm_ops` index, PostgreSQL
--        can use the index to satisfy `ILIKE '%foo%'` queries instead of
--        doing a sequential scan. This is a BIG win for tables with many
--        rows (Posts, Articles).
--     2. TYPO-TOLERANT retrieval via the `%` operator + `similarity()`
--        function — a NEW capability. The route uses this to compute a
--        per-item relevance score that's used as a tiebreaker within
--        the same (rank, ts, type) tier, making highly-relevant items
--        surface ahead of less-relevant ones even when they're older.
--
-- COMPATIBILITY:
--   - Neon (production): supports `pg_trgm` on all paid tiers + free tier
--     as of 2024+. The `CREATE EXTENSION IF NOT EXISTS` is idempotent
--     and safe to run on existing databases.
--   - Self-hosted PostgreSQL 9.6+: supported.
--   - SQLite (local dev): the migration SQL is PostgreSQL-specific. The
--     Prisma `mode: "insensitive"` continues to work in SQLite via LIKE
--     (the existing behavior). The route's typo-tolerance path uses
--     `similarity()` which only runs against PostgreSQL — for SQLite,
--     the route falls back to `contains` only (graceful degradation).
--
-- WHY pg_trgm over FTS (tsvector/tsquery):
--   - FTS is great for word-boundary matches in Latin-script languages
--     but has WEAK support for Arabic (no built-in Arabic stemming,
--     requires custom dictionaries). CentryChat has Arabic content.
--   - pg_trgm is CHARACTER-based (trigrams of 3 chars) — language-
--     agnostic. Works equally well for English, Arabic, French, etc.
--   - pg_trgm's `similarity()` gives a [0, 1] relevance score that's
--     easy to use as a tiebreaker. FTS's `ts_rank` is harder to combine
--     with our existing tier system.
--   - pg_trgm ALSO accelerates `ILIKE` — we get faster Phase 2A queries
--     + typo-tolerance for free.
--
-- WHY NOT BOTH (FTS + pg_trgm):
--   - Adds complexity (two new indexes per column, two new code paths).
--   - Marginal gain — pg_trgm covers the use cases FTS would solve.
--   - Keeps the migration small + the route logic simple.
--
-- ──────────────────────────────────────────────────────────────────────────

-- ── Extension ────────────────────────────────────────────────────────────
-- pg_trgm: provides trigram-based similarity + the `%` operator + the
-- `gin_trgm_ops` operator class for GIN indexes. Idempotent.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ── GIN trigram indexes ─────────────────────────────────────────────────
-- These indexes accelerate:
--   1. `ILIKE '%foo%'` (the existing Phase 2A path) — PostgreSQL can use
--      the GIN index with the `gin_trgm_ops` operator class to satisfy
--      ILIKE substring searches without a seq scan.
--   2. `column % 'query'` (the new typo-tolerance path) — the `%`
--      operator uses the GIN index to find rows with trigram similarity
--      above the threshold (default 0.3).
--
-- Index naming convention: `<Table>_<column>_trgm_idx` (matches
-- PostgreSQL's default naming for `<Table>_<column>_idx`).

-- User: username + fullName — speeds up user search by username/name.
-- LEGACY GUARD: User.fullName column may not exist on legacy Production DBs
-- (legacy uses "name" instead). Wrapped in DO block — no-op when missing.
CREATE INDEX IF NOT EXISTS "User_username_trgm_idx" ON "User" USING gin ("username" gin_trgm_ops);
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'User' AND column_name = 'fullName'
  ) THEN
    CREATE INDEX IF NOT EXISTS "User_fullName_trgm_idx" ON "User" USING gin ("fullName" gin_trgm_ops);
  END IF;
END $$;

-- Post: content — speeds up post content search.
-- LEGACY GUARD: Post table may not exist on legacy Production DBs.
-- Wrapped in DO block — no-op when Post is missing.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Post'
  ) THEN
    CREATE INDEX IF NOT EXISTS "Post_content_trgm_idx" ON "Post" USING gin ("content" gin_trgm_ops);
  END IF;
END $$;

-- Article: title + excerpt + content — speeds up article search.
-- Note: `content` can be large (full article body); the GIN index is
-- still beneficial because the index is much smaller than scanning
-- every row's content column. The trade-off is index size on disk.
CREATE INDEX IF NOT EXISTS "Article_title_trgm_idx" ON "Article" USING gin ("title" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Article_excerpt_trgm_idx" ON "Article" USING gin ("excerpt" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Article_content_trgm_idx" ON "Article" USING gin ("content" gin_trgm_ops);

-- Collection: name + description.
CREATE INDEX IF NOT EXISTS "Collection_name_trgm_idx" ON "Collection" USING gin ("name" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Collection_description_trgm_idx" ON "Collection" USING gin ("description" gin_trgm_ops);

-- Playlist: name + description.
CREATE INDEX IF NOT EXISTS "Playlist_name_trgm_idx" ON "Playlist" USING gin ("name" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Playlist_description_trgm_idx" ON "Playlist" USING gin ("description" gin_trgm_ops);

-- ── Set similarity threshold ─────────────────────────────────────────────
-- The `%` operator returns TRUE when similarity(a, b) >= the threshold.
-- Default is 0.3 — too permissive for short queries. We set it to 0.1
-- here so very short queries (2-3 chars) still find matches. The route
-- also computes similarity() explicitly per item and uses it as a
-- tiebreaker (not a filter) — so the threshold only controls whether
-- the GIN index pre-filters candidates. Lower threshold = more
-- candidates = better recall (the route's JS ranker filters further).
--
-- IMPORTANT: `prisma db execute` runs all statements in a single
-- transaction. Within that transaction, the pg_trgm extension's
-- `similarity_threshold` GUC is NOT visible until the extension is
-- fully committed (PostgreSQL registers GUCs at session start, NOT at
-- extension-create time within a running transaction). When the
-- extension is being freshly installed, the `SET` line raises
-- `unrecognized configuration parameter "similarity_threshold"` and
-- rolls back the ENTIRE migration (including CREATE EXTENSION +
-- CREATE INDEX) — defeating the migration's purpose.
--
-- The route's per-session `SET LOCAL similarity_threshold = 0.1`
-- (inside its own transaction, AFTER the extension is already
-- installed) works correctly and is sufficient. The global default of
-- 0.3 doesn't affect the route because the route always overrides it
-- per-session.
--
-- The `SET` line below is intentionally commented out. It's kept as
-- documentation of the intended default for psql sessions inspecting
-- the DB.
-- SET similarity_threshold = 0.1;
