-- Additive migration: creates the Article table for long-form publishing.
-- The existing Post table is NOT modified — Posts (280-char text) and
-- Articles (long-form with title/cover image/drafts) are separate content types.
--
-- Safety:
--   - Additive only — CREATE TABLE, no ALTER/DROP on existing tables.
--   - No existing data is touched.
--   - Compatible with Neon PostgreSQL + Netlify deployment (uses prisma db push).
--
-- Indexes:
--   (authorId, createdAt) — for "list articles by user" queries (Profile page)
--   (status, publishedAt) — for "list published articles" queries (Home feed)
--   (publishedAt) — for sitemap generation + "latest articles" queries

CREATE TABLE IF NOT EXISTS "Article" (
    "id" TEXT NOT NULL,
    "authorId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "excerpt" TEXT,
    "coverImage" TEXT,
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "publishedAt" TIMESTAMP(3),
    "readingTime" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Article_pkey" PRIMARY KEY ("id")
);

-- Foreign key to User (cascade delete: if user is deleted, their articles are too)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'Article_authorId_fkey'
  ) THEN
    ALTER TABLE "Article"
    ADD CONSTRAINT "Article_authorId_fkey"
    FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS "Article_authorId_createdAt_idx" ON "Article"("authorId", "createdAt");
CREATE INDEX IF NOT EXISTS "Article_status_publishedAt_idx" ON "Article"("status", "publishedAt");
CREATE INDEX IF NOT EXISTS "Article_publishedAt_idx" ON "Article"("publishedAt");
