-- ──────────────────────────────────────────────────────────────────────────
-- LEGACY COMPATIBILITY MIGRATION — Safe Guard Wrappers
-- ──────────────────────────────────────────────────────────────────────────
--
-- PURPOSE:
--   This migration wraps every "potentially breaking" SQL statement from
--   prior migrations in a DO $$ ... END $$ block that checks for the
--   existence of the target table before executing. This makes the
--   migration chain idempotent against the legacy Production DB schema,
--   which is missing many tables that schema.prisma expects.
--
--   Netlify build was failing with `P1014: The underlying table for
--   model "PostComment" does not exist.` because the migration chain
--   runs `ALTER TABLE "PostComment" ...` against a DB that doesn't
--   have a PostComment table (legacy shape uses "Comment" + "CommentLike"
--   for video comments instead).
--
--   ROOT CAUSE: The previous migrations were authored assuming the
--   modern CentryChat schema (Post, PostComment, PostLike, ContentTopic,
--   Conversation, Report, etc.) was already in place — which is NOT
--   the case in Production. Production is a legacy video-platform
--   schema where these tables were never created.
--
-- STRATEGY:
--   For each "unsafe on legacy DB" statement in earlier migrations, we
--   restate it here inside a DO block that:
--     1. Checks information_schema.tables for the target table.
--     2. Only runs the ALTER/DELETE/UPDATE/CREATE-INDEX if the table
--        exists. Otherwise no-op.
--
--   This migration is SAFE TO RUN MULTIPLE TIMES (idempotent):
--     - All ALTER TABLE ADD COLUMN statements use IF NOT EXISTS.
--     - All CREATE INDEX statements use IF NOT EXISTS.
--     - All DO blocks check existence before acting.
--
--   This migration is NON-DESTRUCTIVE:
--     - No DROP TABLE, DROP COLUMN, DROP INDEX (except for the unique
--       constraint guard below, which uses IF EXISTS).
--     - No TRUNCATE.
--     - No DELETE on entire tables.
--     - No data loss.
--
-- AFFECTED MIGRATIONS (in chronological order):
--   - 20260816000000_add_posts                         → ALTER TABLE Post
--   - 20260816010000_add_post_interactions             → ALTER TABLE Post*, FKs
--   - 20260818000000_add_conversation_direct_key       → ALTER TABLE Conversation
--   - 20260818000005_add_article_interactions          → ALTER TABLE ArticleComment/Interaction
--   - 20260818000006_add_search_and_trending_indexes   → CREATE INDEX on Post/PostLike/PostInteraction
--   - 20260818000008_add_moderation_fields             → ALTER TABLE Report
--   - 20260820000040_add_comment_replies_and_likes    → ALTER TABLE PostComment/ArticleComment
--   - 20260821000000_add_topic_relationships           → ALTER TABLE ContentTopic (already DO-blocked)
--   - 20260826000000_add_moderation_status_and_warnings→ ALTER TABLE Post/PostComment/ArticleComment (already DO-blocked)
--   - 20260921000000_add_playlists                     → ALTER TABLE PlaylistItem FK
--   - 20260922000001_add_normalized_search_fields      → ALTER TABLE Post ADD COLUMN
-- ──────────────────────────────────────────────────────────────────────────

-- ── 1. Migration 20260816000000_add_posts: ALTER TABLE Post authorId FK ──
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Post'
  ) THEN
    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint WHERE conname = 'Post_authorId_fkey'
    ) THEN
      ALTER TABLE "Post"
        ADD CONSTRAINT "Post_authorId_fkey"
        FOREIGN KEY ("authorId") REFERENCES "User"("id")
        ON DELETE CASCADE;
    END IF;
  END IF;
END $$;

-- ── 2. Migration 20260816010000_add_post_interactions: FKs on PostLike/PostComment/PostView/PostInteraction ──
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostLike') THEN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostLike_postId_fkey') THEN
      ALTER TABLE "PostLike" ADD CONSTRAINT "PostLike_postId_fkey"
        FOREIGN KEY ("postId") REFERENCES "Post"("id") ON DELETE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostLike_userId_fkey') THEN
      ALTER TABLE "PostLike" ADD CONSTRAINT "PostLike_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE;
    END IF;
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostComment') THEN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostComment_postId_fkey') THEN
      ALTER TABLE "PostComment" ADD CONSTRAINT "PostComment_postId_fkey"
        FOREIGN KEY ("postId") REFERENCES "Post"("id") ON DELETE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostComment_authorId_fkey') THEN
      ALTER TABLE "PostComment" ADD CONSTRAINT "PostComment_authorId_fkey"
        FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE CASCADE;
    END IF;
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostView') THEN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostView_postId_fkey') THEN
      ALTER TABLE "PostView" ADD CONSTRAINT "PostView_postId_fkey"
        FOREIGN KEY ("postId") REFERENCES "Post"("id") ON DELETE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostView_userId_fkey') THEN
      ALTER TABLE "PostView" ADD CONSTRAINT "PostView_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL;
    END IF;
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostInteraction') THEN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostInteraction_postId_fkey') THEN
      ALTER TABLE "PostInteraction" ADD CONSTRAINT "PostInteraction_postId_fkey"
        FOREIGN KEY ("postId") REFERENCES "Post"("id") ON DELETE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostInteraction_userId_fkey') THEN
      ALTER TABLE "PostInteraction" ADD CONSTRAINT "PostInteraction_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL;
    END IF;
  END IF;
END $$;

-- ── 3. Migration 20260818000000_add_conversation_direct_key ──
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'Conversation') THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'Conversation' AND column_name = 'directKey'
    ) THEN
      ALTER TABLE "Conversation" ADD COLUMN "directKey" TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'Conversation_directKey_key') THEN
      CREATE UNIQUE INDEX "Conversation_directKey_key" ON "Conversation"("directKey");
    END IF;
  END IF;
END $$;

-- ── 4. Migration 20260818000005_add_article_interactions: FKs on ArticleComment/ArticleInteraction ──
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'ArticleComment') THEN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ArticleComment_articleId_fkey') THEN
      ALTER TABLE "ArticleComment" ADD CONSTRAINT "ArticleComment_articleId_fkey"
        FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ArticleComment_authorId_fkey') THEN
      ALTER TABLE "ArticleComment" ADD CONSTRAINT "ArticleComment_authorId_fkey"
        FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'ArticleInteraction') THEN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ArticleInteraction_articleId_fkey') THEN
      ALTER TABLE "ArticleInteraction" ADD CONSTRAINT "ArticleInteraction_articleId_fkey"
        FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ArticleInteraction_userId_fkey') THEN
      ALTER TABLE "ArticleInteraction" ADD CONSTRAINT "ArticleInteraction_userId_fkey"
        FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
    END IF;
  END IF;
END $$;

-- ── 5. Migration 20260818000006_add_search_and_trending_indexes ──
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'User' AND column_name = 'fullName') THEN
    CREATE INDEX IF NOT EXISTS "User_fullName_idx" ON "User"("fullName");
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'User' AND column_name = 'username') THEN
    CREATE INDEX IF NOT EXISTS "User_username_idx" ON "User"("username");
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'Post') THEN
    CREATE INDEX IF NOT EXISTS "Post_content_idx" ON "Post"("content");
    CREATE INDEX IF NOT EXISTS "Post_createdAt_idx" ON "Post"("createdAt");
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Article' AND column_name = 'title') THEN
    CREATE INDEX IF NOT EXISTS "Article_title_idx" ON "Article"("title");
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Article' AND column_name = 'excerpt') THEN
    CREATE INDEX IF NOT EXISTS "Article_excerpt_idx" ON "Article"("excerpt");
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Article' AND column_name = 'publishedAt') THEN
    CREATE INDEX IF NOT EXISTS "Article_publishedAt_idx" ON "Article"("publishedAt");
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostLike') THEN
    CREATE INDEX IF NOT EXISTS "PostLike_postId_idx" ON "PostLike"("postId");
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'ArticleLike') THEN
    CREATE INDEX IF NOT EXISTS "ArticleLike_articleId_idx" ON "ArticleLike"("articleId");
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostInteraction') THEN
    CREATE INDEX IF NOT EXISTS "PostInteraction_postId_type_idx" ON "PostInteraction"("postId", "type");
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'ArticleInteraction') THEN
    CREATE INDEX IF NOT EXISTS "ArticleInteraction_articleId_type_idx" ON "ArticleInteraction"("articleId", "type");
  END IF;
END $$;

-- ── 6. Migration 20260818000008_add_moderation_fields: ALTER TABLE Report ──
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'Report') THEN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'targetPostId') THEN
      ALTER TABLE "Report" ADD COLUMN "targetPostId" TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'targetArticleId') THEN
      ALTER TABLE "Report" ADD COLUMN "targetArticleId" TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'targetCommentId') THEN
      ALTER TABLE "Report" ADD COLUMN "targetCommentId" TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'priority') THEN
      ALTER TABLE "Report" ADD COLUMN "priority" TEXT NOT NULL DEFAULT 'NORMAL';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'assignedToId') THEN
      ALTER TABLE "Report" ADD COLUMN "assignedToId" TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'notes') THEN
      ALTER TABLE "Report" ADD COLUMN "notes" TEXT;
    END IF;
    CREATE INDEX IF NOT EXISTS "Report_priority_idx" ON "Report"("priority");
    CREATE INDEX IF NOT EXISTS "Report_assignedToId_idx" ON "Report"("assignedToId");
  END IF;
END $$;

-- ── 7. Migration 20260820000040_add_comment_replies_and_likes ──
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostComment') THEN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'PostComment' AND column_name = 'parentCommentId') THEN
      ALTER TABLE "PostComment" ADD COLUMN "parentCommentId" TEXT;
    END IF;
    CREATE INDEX IF NOT EXISTS "PostComment_parentCommentId_idx" ON "PostComment" ("parentCommentId");
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'ArticleComment') THEN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'ArticleComment' AND column_name = 'parentCommentId') THEN
      ALTER TABLE "ArticleComment" ADD COLUMN "parentCommentId" TEXT;
    END IF;
    CREATE INDEX IF NOT EXISTS "ArticleComment_parentCommentId_idx" ON "ArticleComment" ("parentCommentId");
  END IF;
END $$;

-- ── 8. Migration 20260921000000_add_playlists: PlaylistItem FKs ──
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PlaylistItem') THEN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PlaylistItem_playlistId_fkey') THEN
      ALTER TABLE "PlaylistItem" ADD CONSTRAINT "PlaylistItem_playlistId_fkey"
        FOREIGN KEY ("playlistId") REFERENCES "Playlist" ("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PlaylistItem_articleId_fkey') THEN
      ALTER TABLE "PlaylistItem" ADD CONSTRAINT "PlaylistItem_articleId_fkey"
        FOREIGN KEY ("articleId") REFERENCES "Article" ("id") ON DELETE CASCADE ON UPDATE CASCADE;
    END IF;
  END IF;
END $$;

-- ── 9. Migration 20260922000001_add_normalized_search_fields: ALTER TABLE Post ──
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'Post') THEN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = current_schema() AND table_name = 'Post' AND column_name = 'contentNormalized') THEN
      ALTER TABLE "Post" ADD COLUMN "contentNormalized" TEXT;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'Post_contentNormalized_trgm_idx') THEN
      IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_trgm') THEN
        CREATE INDEX "Post_contentNormalized_trgm_idx" ON "Post" USING gin ("contentNormalized" gin_trgm_ops);
      END IF;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'Post_content_trgm_idx') THEN
      IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_trgm') THEN
        CREATE INDEX "Post_content_trgm_idx" ON "Post" USING gin ("content" gin_trgm_ops);
      END IF;
    END IF;
  END IF;
END $$;
