-- Migration: add unique constraint on PostView(postId, userId)
--
-- IDEMPOTENT: safe to run multiple times.
-- Required because `prisma db push` (used in netlify.toml) does NOT
-- run migration files — it directly applies the schema. If the table
-- has duplicates, `db push` fails with P2002. By running this SQL
-- BEFORE `db push` (via `prisma db execute --file`), we ensure the
-- table is clean.
--
-- ── BACKWARD-COMPATIBLE GUARD (Phase 3 — migration dependency fix) ──
-- This migration runs BEFORE `prisma db push` in the Netlify build
-- command (see netlify.toml). On an EXISTING production database the
-- "PostView" table already exists (created by migration
-- 20260816010000_add_post_interactions or by a previous `prisma db
-- push`), so the DELETE + CREATE INDEX below succeed normally.
--
-- However, on a FRESH database (e.g. brand-new Neon branch, a CI
-- container with an empty Postgres, or a local reset), the "PostView"
-- table does NOT yet exist when this migration runs — `prisma db push`
-- (which creates the tables from schema.prisma) runs LATER in the
-- build command. Without a guard, the `DELETE FROM "PostView"` would
-- raise `relation "PostView" does not exist`, failing the entire
-- chained build command (`A && B && ... && prisma db push && build`).
--
-- The DO block below wraps the original two statements in an
-- existence check against `information_schema.tables`. Behavior is
-- IDENTICAL to the previous version when the table exists:
--   - duplicates are deleted (idempotent — no-op if clean)
--   - the unique index is created (IF NOT EXISTS — no-op if present)
-- When the table does NOT exist, both statements are skipped — the
-- subsequent `prisma db push` will create the table WITH the unique
-- constraint already defined in schema.prisma (model PostView has
-- @@unique([postId, userId])), so the end state is identical.
--
-- SAFETY:
--   - No data loss on existing DBs (DELETE only removes duplicates).
--   - No-op on fresh DBs (table existence guard).
--   - Idempotent — safe to re-run on every deploy.
--   - No schema constraint added that would fail on existing rows.
--   - No destructive operation (no DROP, no TRUNCATE, no ALTER DROP).

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.tables
    WHERE table_schema = current_schema()
      AND table_name = 'PostView'
  ) THEN
    -- Step 1: Delete duplicate views, keeping the oldest per (postId, userId).
    -- Idempotent: if no duplicates exist, this is a no-op.
    DELETE FROM "PostView"
    WHERE "userId" IS NOT NULL
      AND ctid NOT IN (
        SELECT MIN(ctid) FROM "PostView"
        WHERE "userId" IS NOT NULL
        GROUP BY "postId", "userId"
      );

    -- Step 2: Create the unique index (IF NOT EXISTS = idempotent).
    CREATE UNIQUE INDEX IF NOT EXISTS "PostView_postId_userId_key"
      ON "PostView"("postId", "userId");
  END IF;
END $$;
