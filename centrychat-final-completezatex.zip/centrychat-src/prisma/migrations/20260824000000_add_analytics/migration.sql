-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Analytics — Traffic Sources + Article-level traffic intelligence
--
-- Creates two new tables:
--   - AnalyticsSession  (one row per visitor session)
--   - AnalyticsEvent    (one row per tracked event: page_view, article_view, etc.)
--
-- IDEMPOTENT — safe to run on every deploy. Uses CREATE TABLE IF NOT EXISTS +
-- CREATE INDEX IF NOT EXISTS so re-runs are no-ops. Backward compatible:
-- existing tables, rows, and indexes are untouched.
--
-- ADDITIVE ONLY — no ALTER on existing tables, no DROP, no rename, no data
-- migration. Existing users + content remain completely unaffected. The new
-- tables start empty.
--
-- RELATIONSHIPS:
--   AnalyticsEvent.sessionId → AnalyticsSession.id (ON DELETE CASCADE)
--   So: session deleted → all its events deleted. No orphan rows.
--
-- PRIVACY:
--   NO raw IP addresses stored. The `country` column stores an ISO 3166-1
--   alpha-2 country code (derived server-side from the IP via a Geo
--   provider when configured, then the IP is discarded).
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "AnalyticsSession" (
    "id"          TEXT NOT NULL,
    "anonymousId" TEXT,
    "userId"      TEXT,
    "firstSeenAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastSeenAt"  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "entryPath"   TEXT NOT NULL,
    "referrer"    TEXT,
    "source"      TEXT NOT NULL DEFAULT 'direct',
    "medium"      TEXT NOT NULL DEFAULT 'direct',
    "utmSource"   TEXT,
    "utmMedium"   TEXT,
    "utmCampaign" TEXT,
    "device"      TEXT,
    "browser"     TEXT,
    "os"          TEXT,
    "country"     TEXT,
    "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"   TIMESTAMP(3) NOT NULL,
    CONSTRAINT "AnalyticsSession_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "AnalyticsSession_userId_lastSeenAt_idx"
    ON "AnalyticsSession" ("userId", "lastSeenAt");
CREATE INDEX IF NOT EXISTS "AnalyticsSession_anonymousId_lastSeenAt_idx"
    ON "AnalyticsSession" ("anonymousId", "lastSeenAt");
CREATE INDEX IF NOT EXISTS "AnalyticsSession_source_firstSeenAt_idx"
    ON "AnalyticsSession" ("source", "firstSeenAt");
CREATE INDEX IF NOT EXISTS "AnalyticsSession_lastSeenAt_idx"
    ON "AnalyticsSession" ("lastSeenAt");

CREATE TABLE IF NOT EXISTS "AnalyticsEvent" (
    "id"          TEXT NOT NULL,
    "sessionId"   TEXT NOT NULL,
    "userId"      TEXT,
    "eventType"   TEXT NOT NULL,
    "path"        TEXT NOT NULL,
    "articleId"   TEXT,
    "referrer"    TEXT,
    "source"      TEXT NOT NULL DEFAULT 'direct',
    "medium"      TEXT NOT NULL DEFAULT 'direct',
    "utmSource"   TEXT,
    "utmMedium"   TEXT,
    "utmCampaign" TEXT,
    "device"      TEXT,
    "browser"     TEXT,
    "os"          TEXT,
    "country"     TEXT,
    "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AnalyticsEvent_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "AnalyticsEvent_createdAt_idx"
    ON "AnalyticsEvent" ("createdAt");
CREATE INDEX IF NOT EXISTS "AnalyticsEvent_eventType_createdAt_idx"
    ON "AnalyticsEvent" ("eventType", "createdAt");
CREATE INDEX IF NOT EXISTS "AnalyticsEvent_articleId_createdAt_idx"
    ON "AnalyticsEvent" ("articleId", "createdAt");
CREATE INDEX IF NOT EXISTS "AnalyticsEvent_source_createdAt_idx"
    ON "AnalyticsEvent" ("source", "createdAt");
CREATE INDEX IF NOT EXISTS "AnalyticsEvent_sessionId_createdAt_idx"
    ON "AnalyticsEvent" ("sessionId", "createdAt");

-- Foreign key: AnalyticsEvent.sessionId → AnalyticsSession.id (CASCADE).
ALTER TABLE "AnalyticsEvent" DROP CONSTRAINT IF EXISTS "AnalyticsEvent_sessionId_fkey";
ALTER TABLE "AnalyticsEvent" ADD CONSTRAINT "AnalyticsEvent_sessionId_fkey"
    FOREIGN KEY ("sessionId") REFERENCES "AnalyticsSession"("id") ON DELETE CASCADE;
