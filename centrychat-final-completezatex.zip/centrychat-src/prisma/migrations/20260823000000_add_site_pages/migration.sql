-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Site Pages CMS
--
-- Creates the SitePage table — a CMS for the platform's informational/legal
-- pages (About, Privacy, Terms, Contact).
--
-- IDEMPOTENT — safe to run on every deploy. Uses CREATE TABLE IF NOT EXISTS +
-- CREATE INDEX IF NOT EXISTS so re-runs are no-ops. Backward compatible:
-- existing tables, rows, and indexes are untouched.
--
-- ADDITIVE ONLY — no ALTER on existing tables, no DROP, no rename, no data
-- migration. Existing users + content remain completely unaffected. The new
-- table starts empty (seeded by scripts/seed-site-pages.ts on first deploy,
-- OR by the admin opening the "Pages & Legal" section for the first time).
--
-- The content column stores a JSON string (validated server-side via Zod).
-- We use TEXT (not JSONB) because:
--   1. We validate the shape in application code (Zod), so DB-level JSON
--      validation is redundant.
--   2. TEXT keeps the migration portable across PostgreSQL + SQLite (the
--      project supports both — see prisma/schema.prisma datasource comment).
--   3. We never query inside the JSON from SQL — we always load the full row
--      + parse in JS.
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "SitePage" (
    "id"             TEXT NOT NULL,
    "slug"           TEXT NOT NULL,
    "title"          TEXT NOT NULL,
    "content"        TEXT NOT NULL,
    "seoTitle"       TEXT,
    "seoDescription" TEXT,
    "isPublished"    BOOLEAN NOT NULL DEFAULT false,
    "updatedById"    TEXT,
    "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"      TIMESTAMP(3) NOT NULL,
    CONSTRAINT "SitePage_pkey" PRIMARY KEY ("id")
);

-- UNIQUE constraint on slug — one row per page. The DROP IF EXISTS + ADD
-- pattern makes this idempotent (safe to re-run on every deploy).
ALTER TABLE "SitePage" DROP CONSTRAINT IF EXISTS "SitePage_slug_key";
ALTER TABLE "SitePage" ADD CONSTRAINT "SitePage_slug_key" UNIQUE ("slug");

-- Index for the admin list query ("all pages, ordered by updatedAt desc")
-- + the public read query ("published pages by slug").
CREATE INDEX IF NOT EXISTS "SitePage_isPublished_updatedAt_idx"
    ON "SitePage" ("isPublished", "updatedAt");
