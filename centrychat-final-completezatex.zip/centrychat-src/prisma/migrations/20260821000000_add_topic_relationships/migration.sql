-- ──────────────────────────────────────────────────────────────────────────
-- Phase 2 — Topics system: additive migration.
--
-- Adds:
--   1. ContentTopic.isActive + ContentTopic.updatedAt — admin can deactivate
--      a topic without deleting (existing relationships preserved).
--   2. ArticleTopic — join table Article ↔ ContentTopic (UNIQUE on
--      (articleId, topicId) prevents duplicate relationships).
--   3. PostTopic — join table Post ↔ ContentTopic (same pattern).
--   4. UserTopicFollow — user explicit topic follows (UNIQUE on
--      (userId, topicId) prevents duplicate follows).
--
-- IDEMPOTENT: every statement uses IF NOT EXISTS so re-running on an
-- already-migrated DB is a no-op. Safe to run on every deploy (this is
-- what netlify.toml does).
--
-- ADDITIVE: no columns dropped, no tables dropped, no data deleted.
-- Existing ContentTopic rows get isActive=true (default) + updatedAt=now()
-- (Prisma's @updatedAt behavior — emulated here via the column DEFAULT).
--
-- BACKWARD COMPATIBLE: the existing /topics/[tag] hashtag-search route is
-- UNCHANGED — it doesn't use any of these new tables. The new tables are
-- only consumed by the new Topic service + the extended /topics/[tag]
-- ContentTopic-lookup path.
-- ──────────────────────────────────────────────────────────────────────────

-- ── 1. ContentTopic: add isActive + updatedAt ──────────────────────────────
-- These two columns are added to the EXISTING ContentTopic table.
-- ADDITIVE — existing rows get the default values (isActive=true, updatedAt=now).
--
-- ── LEGACY GUARD (added 2026-09) ───────────────────────────────────────────
-- The ContentTopic table may not exist on legacy Production DBs.
-- Wrapped in a DO block that checks for table existence — no-op if missing.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'ContentTopic'
  ) THEN
    ALTER TABLE "ContentTopic"
      ADD COLUMN IF NOT EXISTS "isActive" BOOLEAN NOT NULL DEFAULT true;

    ALTER TABLE "ContentTopic"
      ADD COLUMN IF NOT EXISTS "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

    CREATE INDEX IF NOT EXISTS "ContentTopic_isActive_idx" ON "ContentTopic" ("isActive");
  END IF;
END $$;

-- ── 2. ArticleTopic join table ─────────────────────────────────────────────
-- ONE row per (articleId, topicId). UNIQUE constraint prevents duplicates.

CREATE TABLE IF NOT EXISTS "ArticleTopic" (
    "id"        TEXT NOT NULL,
    "articleId" TEXT NOT NULL,
    "topicId"   TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ArticleTopic_pkey" PRIMARY KEY ("id")
);

-- UNIQUE — one topic assignment per (article, topic) pair. The constraint
-- name matches what Prisma generates so `prisma db push` doesn't try to
-- recreate it.
CREATE UNIQUE INDEX IF NOT EXISTS "ArticleTopic_articleId_topicId_key"
  ON "ArticleTopic" ("articleId", "topicId");

-- Indexes for the common query patterns.
CREATE INDEX IF NOT EXISTS "ArticleTopic_articleId_idx" ON "ArticleTopic" ("articleId");
CREATE INDEX IF NOT EXISTS "ArticleTopic_topicId_idx" ON "ArticleTopic" ("topicId");

-- Foreign keys. ON DELETE CASCADE so cleanup is automatic when either side
-- is removed (the Article or the ContentTopic).
-- Constraint names match Prisma's convention so `prisma db push` recognizes them.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleTopic_articleId_fkey'
  ) THEN
    ALTER TABLE "ArticleTopic"
      ADD CONSTRAINT "ArticleTopic_articleId_fkey"
      FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE;
  END IF;
END$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleTopic_topicId_fkey'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'ContentTopic'
  ) THEN
    ALTER TABLE "ArticleTopic"
      ADD CONSTRAINT "ArticleTopic_topicId_fkey"
      FOREIGN KEY ("topicId") REFERENCES "ContentTopic"("id") ON DELETE CASCADE;
  END IF;
END$$;

-- ── 3. PostTopic join table (same shape as ArticleTopic) ───────────────────
CREATE TABLE IF NOT EXISTS "PostTopic" (
    "id"        TEXT NOT NULL,
    "postId"    TEXT NOT NULL,
    "topicId"   TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PostTopic_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "PostTopic_postId_topicId_key"
  ON "PostTopic" ("postId", "topicId");

CREATE INDEX IF NOT EXISTS "PostTopic_postId_idx" ON "PostTopic" ("postId");
CREATE INDEX IF NOT EXISTS "PostTopic_topicId_idx" ON "PostTopic" ("topicId");

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'PostTopic_postId_fkey'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'Post'
  ) THEN
    ALTER TABLE "PostTopic"
      ADD CONSTRAINT "PostTopic_postId_fkey"
      FOREIGN KEY ("postId") REFERENCES "Post"("id") ON DELETE CASCADE;
  END IF;
END$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'PostTopic_topicId_fkey'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'ContentTopic'
  ) THEN
    ALTER TABLE "PostTopic"
      ADD CONSTRAINT "PostTopic_topicId_fkey"
      FOREIGN KEY ("topicId") REFERENCES "ContentTopic"("id") ON DELETE CASCADE;
  END IF;
END$$;

-- ── 4. UserTopicFollow table ───────────────────────────────────────────────
-- ONE row per (userId, topicId). UNIQUE constraint prevents duplicate follows.
CREATE TABLE IF NOT EXISTS "UserTopicFollow" (
    "id"        TEXT NOT NULL,
    "userId"    TEXT NOT NULL,
    "topicId"   TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "UserTopicFollow_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "UserTopicFollow_userId_topicId_key"
  ON "UserTopicFollow" ("userId", "topicId");

CREATE INDEX IF NOT EXISTS "UserTopicFollow_userId_idx" ON "UserTopicFollow" ("userId");
CREATE INDEX IF NOT EXISTS "UserTopicFollow_topicId_idx" ON "UserTopicFollow" ("topicId");

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'UserTopicFollow_userId_fkey'
  ) THEN
    ALTER TABLE "UserTopicFollow"
      ADD CONSTRAINT "UserTopicFollow_userId_fkey"
      FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE;
  END IF;
END$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'UserTopicFollow_topicId_fkey'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'ContentTopic'
  ) THEN
    ALTER TABLE "UserTopicFollow"
      ADD CONSTRAINT "UserTopicFollow_topicId_fkey"
      FOREIGN KEY ("topicId") REFERENCES "ContentTopic"("id") ON DELETE CASCADE;
  END IF;
END$$;
