-- Migration: Add post interaction tables (Phase 3 — Likes, Comments, Views, Share events).
--
-- This migration is documentation-only — the project uses `prisma db push`
-- (see netlify.toml `command = "bun run db:generate && npx prisma db push
-- --accept-data-loss && bun run build"`) which syncs the schema directly
-- against the live Neon database on every deploy. We keep this SQL file
-- for review/audit purposes and so it can be applied manually if needed.

-- PostLike: one row per (post, user). The unique constraint is the source
-- of truth for "no duplicate likes" — the API uses upsert + deleteMany
-- in a transaction to atomically toggle.
CREATE TABLE IF NOT EXISTS "PostLike" (
    "id"        TEXT NOT NULL,
    "postId"    TEXT NOT NULL,
    "userId"    TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PostLike_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX IF NOT EXISTS "PostLike_postId_userId_key"
    ON "PostLike"("postId", "userId");

CREATE INDEX IF NOT EXISTS "PostLike_userId_idx"
    ON "PostLike"("userId");

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostLike_postId_fkey')
    AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostLike')
  THEN
    ALTER TABLE "PostLike"
      ADD CONSTRAINT "PostLike_postId_fkey"
      FOREIGN KEY ("postId") REFERENCES "Post"("id") ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostLike_userId_fkey')
    AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostLike')
  THEN
    ALTER TABLE "PostLike"
      ADD CONSTRAINT "PostLike_userId_fkey"
      FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE;
  END IF;
END $$;

-- PostComment: user-generated content (max 500 chars enforced in app code).
CREATE TABLE IF NOT EXISTS "PostComment" (
    "id"        TEXT NOT NULL,
    "postId"    TEXT NOT NULL,
    "authorId"  TEXT NOT NULL,
    "content"   TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PostComment_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "PostComment_postId_createdAt_idx"
    ON "PostComment"("postId", "createdAt");

CREATE INDEX IF NOT EXISTS "PostComment_authorId_idx"
    ON "PostComment"("authorId");

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostComment_postId_fkey')
    AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostComment')
  THEN
    ALTER TABLE "PostComment"
      ADD CONSTRAINT "PostComment_postId_fkey"
      FOREIGN KEY ("postId") REFERENCES "Post"("id") ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostComment_authorId_fkey')
    AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostComment')
  THEN
    ALTER TABLE "PostComment"
      ADD CONSTRAINT "PostComment_authorId_fkey"
      FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE CASCADE;
  END IF;
END $$;

-- PostView: designed for future expansion (duration, completed, source)
-- without needing a migration of existing columns.
CREATE TABLE IF NOT EXISTS "PostView" (
    "id"        TEXT NOT NULL,
    "postId"    TEXT NOT NULL,
    "userId"    TEXT,
    "viewedAt"  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "duration"  INTEGER,
    "completed" BOOLEAN,
    "source"    TEXT,

    CONSTRAINT "PostView_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "PostView_postId_viewedAt_idx"
    ON "PostView"("postId", "viewedAt");

CREATE INDEX IF NOT EXISTS "PostView_userId_postId_idx"
    ON "PostView"("userId", "postId");

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostView_postId_fkey')
    AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostView')
  THEN
    ALTER TABLE "PostView"
      ADD CONSTRAINT "PostView_postId_fkey"
      FOREIGN KEY ("postId") REFERENCES "Post"("id") ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostView_userId_fkey')
    AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostView')
  THEN
    ALTER TABLE "PostView"
      ADD CONSTRAINT "PostView_userId_fkey"
      FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL;
  END IF;
END $$;

-- PostInteraction: generic event log for SHARE, LINK_COPY, PROFILE_CLICK,
-- HASHTAG_CLICK. LIKE and COMMENT are NOT logged here (they live in their
-- own tables to avoid double-counting).
CREATE TABLE IF NOT EXISTS "PostInteraction" (
    "id"        TEXT NOT NULL,
    "postId"    TEXT NOT NULL,
    "userId"    TEXT,
    "type"      TEXT NOT NULL,
    "metadata"  TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PostInteraction_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "PostInteraction_postId_createdAt_idx"
    ON "PostInteraction"("postId", "createdAt");

CREATE INDEX IF NOT EXISTS "PostInteraction_userId_createdAt_idx"
    ON "PostInteraction"("userId", "createdAt");

CREATE INDEX IF NOT EXISTS "PostInteraction_type_createdAt_idx"
    ON "PostInteraction"("type", "createdAt");

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostInteraction_postId_fkey')
    AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostInteraction')
  THEN
    ALTER TABLE "PostInteraction"
      ADD CONSTRAINT "PostInteraction_postId_fkey"
      FOREIGN KEY ("postId") REFERENCES "Post"("id") ON DELETE CASCADE;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'PostInteraction_userId_fkey')
    AND EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostInteraction')
  THEN
    ALTER TABLE "PostInteraction"
      ADD CONSTRAINT "PostInteraction_userId_fkey"
      FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL;
  END IF;
END $$;
