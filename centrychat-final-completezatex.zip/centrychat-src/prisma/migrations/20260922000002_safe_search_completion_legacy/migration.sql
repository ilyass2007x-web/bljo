-- ──────────────────────────────────────────────────────────────────────────
-- SAFE ADDITIVE-ONLY SEARCH SCHEMA COMPLETION (Production-specific)
-- ──────────────────────────────────────────────────────────────────────────
--
-- PURPOSE:
--   This migration is a SAFE, IDEMPOTENT, ADDITIVE-ONLY script that
--   completes the Phase 2B + Phase 2D search schema on the tables that
--   currently exist in the production database. It is a COMPLEMENT to
--   the existing migrations:
--     - 20260922000000_add_pg_trgm_search           (pg_trgm + raw indexes)
--     - 20260922000001_add_normalized_search_fields  (normalized cols + indexes)
--
--   The original migrations assume the current CentryChat schema is
--   already in place (Post table with content column, Playlist with
--   name/description, etc.). Production is running a LEGACY schema
--   where some of these tables/columns have different shapes:
--
--     - "Post" table       → does NOT exist (legacy used "Video" for posts)
--     - "Playlist" table   → exists but uses "title" instead of "name",
--                             "thumbnail" instead of "coverImage",
--                             "visibility" instead of "isPublic"
--     - "Collection" table → exists with name + description ✓
--     - "Article" table    → exists with title + content + excerpt ✓
--     - "User" table       → exists with username + name (NOT fullName) ⚠
--
--   Running `prisma db push` against this legacy schema would be
--   DESTRUCTIVE (drop Video, Page, Bookmark, Account, etc., and remove
--   ~34 columns from existing tables). We MUST NOT do that.
--
--   Instead, this migration adds the search-specific objects ON THE
--   EXISTING TABLES ONLY, so the search route can find:
--     - pg_trgm extension installed ✓
--     - Normalized columns on User, Article, Collection, Playlist ✓
--     - GIN trigram indexes on those columns ✓
--
--   The "Post" entity search path will continue to throw a schema error
--   because the Post table does not exist. That is documented in the
--   final report — it requires a separate, larger schema migration
--   effort (outside the scope of this safe fix).
--
-- SAFETY:
--   - CREATE EXTENSION IF NOT EXISTS pg_trgm      → idempotent
--   - ALTER TABLE ADD COLUMN IF NOT EXISTS         → idempotent
--   - CREATE INDEX IF NOT EXISTS ... gin_trgm_ops  → idempotent
--   - NO DROP, NO ALTER COLUMN, NO DELETE, NO TRUNCATE
--   - NO changes to existing columns or constraints
--   - NO changes to existing indexes (except additive CREATE IF NOT EXISTS)
--   - Safe to re-run on every deploy
--
-- COLUMN MAPPING (existing-table → normalized column):
--   User.username       → usernameNormalized
--   User.name           → fullNameNormalized   (legacy column is "name",
--                                                not "fullName" — see backfill)
--   Article.title       → titleNormalized
--   Article.excerpt     → excerptNormalized
--   Article.content     → contentNormalized
--   Collection.name     → nameNormalized
--   Collection.description → descriptionNormalized
--   Playlist.title      → nameNormalized       (legacy column is "title",
--                                                not "name" — see backfill)
--   Playlist.description → descriptionNormalized
--
--   (Post.contentNormalized is OMITTED — Post table does not exist.)
-- ──────────────────────────────────────────────────────────────────────────

-- ── 1. pg_trgm extension ──────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ── 2. Normalized columns on EXISTING tables only ──────────────────────────
-- User (legacy column is "name", not "fullName")
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "usernameNormalized" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "fullNameNormalized" TEXT;

-- Article (columns match schema.prisma)
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "titleNormalized" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "excerptNormalized" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "contentNormalized" TEXT;

-- Collection (columns match schema.prisma)
ALTER TABLE "Collection" ADD COLUMN IF NOT EXISTS "nameNormalized" TEXT;
ALTER TABLE "Collection" ADD COLUMN IF NOT EXISTS "descriptionNormalized" TEXT;

-- Playlist (legacy uses "title" instead of "name", but the normalized
-- column name in schema.prisma is "nameNormalized" — same name, just
-- backed by a different raw column)
ALTER TABLE "Playlist" ADD COLUMN IF NOT EXISTS "nameNormalized" TEXT;
ALTER TABLE "Playlist" ADD COLUMN IF NOT EXISTS "descriptionNormalized" TEXT;

-- NOTE: Post.contentNormalized is intentionally NOT added because the
-- "Post" table does not exist in this legacy production schema. The
-- search route's "post" stream will continue to throw a schema error
-- until the Post table is created via a future schema migration
-- (out of scope for this safe additive-only fix).

-- ── 3. GIN trigram indexes on RAW columns (existing tables only) ──────────
-- Mirrors 20260922000000_add_pg_trgm_search but skips Post + uses
-- legacy column names where they differ.

-- User: username + name (legacy "name" replaces "fullName")
CREATE INDEX IF NOT EXISTS "User_username_trgm_idx"
  ON "User" USING gin ("username" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "User_fullName_trgm_idx"
  ON "User" USING gin ("name" gin_trgm_ops);  -- legacy column

-- Article: title + excerpt + content
CREATE INDEX IF NOT EXISTS "Article_title_trgm_idx"
  ON "Article" USING gin ("title" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Article_excerpt_trgm_idx"
  ON "Article" USING gin ("excerpt" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Article_content_trgm_idx"
  ON "Article" USING gin ("content" gin_trgm_ops);

-- Collection: name + description
CREATE INDEX IF NOT EXISTS "Collection_name_trgm_idx"
  ON "Collection" USING gin ("name" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Collection_description_trgm_idx"
  ON "Collection" USING gin ("description" gin_trgm_ops);

-- Playlist: title (legacy, replaces "name") + description
CREATE INDEX IF NOT EXISTS "Playlist_name_trgm_idx"
  ON "Playlist" USING gin ("title" gin_trgm_ops);  -- legacy column
CREATE INDEX IF NOT EXISTS "Playlist_description_trgm_idx"
  ON "Playlist" USING gin ("description" gin_trgm_ops);

-- ── 4. GIN trigram indexes on NORMALIZED columns ──────────────────────────
-- These mirror the indexes in 20260922000001_add_normalized_search_fields
-- but skip Post.

CREATE INDEX IF NOT EXISTS "User_usernameNormalized_trgm_idx"
  ON "User" USING gin ("usernameNormalized" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "User_fullNameNormalized_trgm_idx"
  ON "User" USING gin ("fullNameNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "Article_titleNormalized_trgm_idx"
  ON "Article" USING gin ("titleNormalized" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Article_excerptNormalized_trgm_idx"
  ON "Article" USING gin ("excerptNormalized" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Article_contentNormalized_trgm_idx"
  ON "Article" USING gin ("contentNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "Collection_nameNormalized_trgm_idx"
  ON "Collection" USING gin ("nameNormalized" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Collection_descriptionNormalized_trgm_idx"
  ON "Collection" USING gin ("descriptionNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "Playlist_nameNormalized_trgm_idx"
  ON "Playlist" USING gin ("nameNormalized" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS "Playlist_descriptionNormalized_trgm_idx"
  ON "Playlist" USING gin ("descriptionNormalized" gin_trgm_ops);

-- ── 5. Similarity threshold (per-session default) ─────────────────────────
-- IMPORTANT: prisma db execute runs statements in a single transaction.
-- Within the SAME transaction, the pg_trgm extension's `similarity_threshold`
-- GUC is NOT visible until the extension is fully committed (PostgreSQL
-- registers GUCs at session start, not at extension-create time within a
-- running transaction). Therefore the `SET similarity_threshold` line is
-- OMITTED here — the search route sets it per-session via
-- `SET LOCAL similarity_threshold = 0.1` inside its own transaction
-- (after the extension is already installed), which works correctly.
--
-- The 20260922000000_add_pg_trgm_search migration has the same SET line
-- but it has never run successfully against this legacy production DB
-- (see the migration log above). The route's per-session SET LOCAL is
-- sufficient — the global default of 0.3 doesn't affect the route
-- because the route always overrides it.
