-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Content Moderation — ModerationEvent table
--
-- Creates a NEW table for the centralized content moderation system. Tracks
-- every moderation decision the engine made that was NOT "ALLOW" (WARN,
-- REVIEW, BLOCK) so admins can review flagged content via the Moderation
-- Queue UI.
--
-- IDEMPOTENT — safe to run on every deploy. Uses CREATE TABLE IF NOT EXISTS +
-- CREATE INDEX IF NOT EXISTS so re-runs are no-ops. Backward compatible:
-- existing tables, rows, and indexes are untouched.
--
-- ADDITIVE ONLY — no ALTER on existing tables (except the optional FK
-- constraints below, also idempotent), no DROP, no rename, no data migration.
-- Existing users + content remain completely unaffected. The new table starts
-- empty.
--
-- RELATIONSHIPS:
--   ModerationEvent.userId      → User.id (ON DELETE SET NULL — keeps the
--                                  audit trail even if the user is deleted)
--   ModerationEvent.reviewedById → User.id (ON DELETE SET NULL)
--
-- PRIVACY (data minimization):
--   NO full original text is stored. Only:
--     - contentType + contentId (reference to the flagged content row)
--     - userId (author — for repeat-violation tracking)
--     - action / severity / score / categories / reasons (engine output)
--     - contentPreview — first 200 chars of the user's text, sanitized.
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "ModerationEvent" (
    "id"             TEXT NOT NULL,
    "contentType"    TEXT NOT NULL,
    "contentId"      TEXT,
    "userId"         TEXT,
    "status"         TEXT NOT NULL DEFAULT 'PENDING',
    "action"         TEXT NOT NULL,
    "severity"       TEXT NOT NULL,
    "score"          INTEGER NOT NULL,
    "categories"     JSONB NOT NULL,
    "reasons"        JSONB NOT NULL,
    "contentPreview" TEXT NOT NULL DEFAULT '',
    "reviewedAt"     TIMESTAMP(3),
    "reviewedById"   TEXT,
    "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"      TIMESTAMP(3) NOT NULL,
    CONSTRAINT "ModerationEvent_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ModerationEvent_userId_createdAt_idx"
    ON "ModerationEvent" ("userId", "createdAt");
CREATE INDEX IF NOT EXISTS "ModerationEvent_status_createdAt_idx"
    ON "ModerationEvent" ("status", "createdAt");
CREATE INDEX IF NOT EXISTS "ModerationEvent_contentType_createdAt_idx"
    ON "ModerationEvent" ("contentType", "createdAt");
CREATE INDEX IF NOT EXISTS "ModerationEvent_severity_createdAt_idx"
    ON "ModerationEvent" ("severity", "createdAt");
CREATE INDEX IF NOT EXISTS "ModerationEvent_action_createdAt_idx"
    ON "ModerationEvent" ("action", "createdAt");

-- Foreign keys (idempotent — drop + add so re-runs are safe).
ALTER TABLE "ModerationEvent" DROP CONSTRAINT IF EXISTS "ModerationEvent_userId_fkey";
ALTER TABLE "ModerationEvent" ADD CONSTRAINT "ModerationEvent_userId_fkey"
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "ModerationEvent" DROP CONSTRAINT IF EXISTS "ModerationEvent_reviewedById_fkey";
ALTER TABLE "ModerationEvent" ADD CONSTRAINT "ModerationEvent_reviewedById_fkey"
    FOREIGN KEY ("reviewedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
