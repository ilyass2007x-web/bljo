-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Extend ArticleView with traffic-source analytics columns.
--
-- This is an ADDITIVE migration:
--   - Adds a new nullable column `referralDomain` to the ArticleView table.
--   - Adds new indexes on the existing `source` column + the new
--     `referralDomain` column to speed up admin analytics aggregation
--     queries that filter by source / referralDomain within a date range.
--   - The existing `source` column (TEXT, nullable) was created by the
--     initial 20260818000003 migration but was never populated by the
--     view-tracking endpoint. The endpoint is now extended to populate
--     both `source` and `referralDomain` (using the existing
--     classifyTrafficSource() helper from src/lib/analytics/classify-source.ts).
--   - No DROP, no rename, no data type change, no constraint change.
--   - All existing rows are untouched. Old rows will have NULL in the
--     new `referralDomain` column — that's fine, the admin queries
--     treat NULL as "unknown" and skip it in the Top Referrers list.
--
-- IDEMPOTENT — safe to run on every deploy. Uses ADD COLUMN IF NOT EXISTS +
-- CREATE INDEX IF NOT EXISTS so re-runs are no-ops.
--
-- COMPATIBILITY:
--   - Prisma db push (used by netlify.toml) will pick up these columns
--     automatically because they're in schema.prisma.
--   - This migration SQL is run BEFORE db push (per the existing netlify.toml
--     pattern) so the columns exist when Prisma generates its client.
--   - The unique constraints on (articleId, userId) and
--     (articleId, anonymousVisitorId) are UNCHANGED — existing view
--     dedup behavior is preserved exactly.
-- ────────────────────────────────────────────────────────────────────────────

-- 1. Add referralDomain column (nullable — old rows stay NULL).
ALTER TABLE "ArticleView"
    ADD COLUMN IF NOT EXISTS "referralDomain" TEXT;

-- 1b. Add the `source` column too — legacy Production doesn't have it.
-- schema.prisma expects `source String?` on ArticleView. Idempotent.
ALTER TABLE "ArticleView"
    ADD COLUMN IF NOT EXISTS "source" TEXT;

-- 2. Indexes for the admin analytics queries.
--    (source) — speeds up "group views by source for this article".
--    (referralDomain) — speeds up "top referrers for this article".
--    (articleId, source) — speeds up the per-article source breakdown.
--    (articleId, referralDomain) — speeds up the per-article referrer list.
-- Each CREATE INDEX wrapped in a DO block that verifies column existence
-- (defensive — the ALTER ADD COLUMN above should make these always exist,
-- but DO guards prevent any chance of failure on a partially-migrated DB).
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'ArticleView' AND column_name = 'source'
  ) THEN
    CREATE INDEX IF NOT EXISTS "ArticleView_source_idx"
      ON "ArticleView" ("source");
    CREATE INDEX IF NOT EXISTS "ArticleView_articleId_source_idx"
      ON "ArticleView" ("articleId", "source");
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'ArticleView' AND column_name = 'referralDomain'
  ) THEN
    CREATE INDEX IF NOT EXISTS "ArticleView_referralDomain_idx"
      ON "ArticleView" ("referralDomain");
    CREATE INDEX IF NOT EXISTS "ArticleView_articleId_referralDomain_idx"
      ON "ArticleView" ("articleId", "referralDomain");
  END IF;
END $$;
