-- Additive migration: adds two nullable columns to the User table.
--
-- Purpose:
--   Enable collection of optional demographic info at registration (or via
--   Profile Settings). Stored as:
--     gender        String?    — one of "MALE" | "FEMALE" | "PREFER_NOT_TO_SAY"
--     dateOfBirth   DateTime?  — the raw date of birth (NOT age — age is
--                                computed on demand to avoid staleness)
--
-- Privacy:
--   - Both columns are nullable. Existing users get NULL (no data migration
--     required, no forced re-registration).
--   - These fields are NEVER exposed on the PUBLIC profile API
--     (getProfileByUsername / getProfileById). Only the user's own
--     /api/v1/auth/me and /api/v1/profile endpoints return them — the user
--     can see/edit their own data, but no one else can.
--
-- Safety:
--   - Additive only — no existing column removed/renamed, no existing row
--     rejected. All existing users retain gender = NULL, dateOfBirth = NULL.
--   - No unique constraint, no NOT NULL — purely optional metadata.
--
-- Generated for audit purposes. Production deploys use `prisma db push`
-- (see netlify.toml), which applies the additive ALTER TABLE automatically.

ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "gender" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "dateOfBirth" TIMESTAMP(3);
