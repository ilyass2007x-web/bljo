-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Add per-article SEO control fields.
--
-- IDEMPOTENT — safe to run on every deploy. Uses ADD COLUMN IF NOT EXISTS.
--
-- BACKWARD COMPATIBILITY:
--   - All new columns are NULLABLE or have safe defaults.
--   - Existing articles: seoNoindex=false, seoNofollow=false,
--     customSeoTitle=NULL, customMetaDescription=NULL, customCanonical=NULL.
--   - Behavior unchanged for existing articles — they continue to be
--     `index, follow` with auto-generated metadata (excerpt/content-derived
--     description, /articles/{id} canonical).
--
-- PURPOSE (per PHASE-7 SEO audit):
--   - seoNoindex       : when true, the article's <meta name="robots">
--                        becomes "noindex, follow" (instead of "index, follow").
--                        Default false → public articles stay indexable.
--   - seoNofollow      : when true, robots meta becomes "noindex, nofollow"
--                        (or "index, nofollow" when seoNoindex=false). Default
--                        false → Google follows links from the article.
--   - customSeoTitle   : when non-null, overrides the article title in
--                        <title>, og:title, twitter:title, JSON-LD headline.
--                        Useful for SEO-optimized titles that differ from the
--                        user-facing article title. NULL = use article.title.
--   - customMetaDescription: when non-null, overrides the auto-extracted meta
--                        description. NULL = auto-extract from excerpt/content.
--   - customCanonical  : when non-null, overrides the canonical URL. Useful
--                        for syndicated content (point canonical to the
--                        original source). NULL = canonical = /articles/{id}.
--
-- SECURITY:
--   - These fields are only editable by the article's author + admins via
--     the article PATCH endpoint (already auth-protected server-side).
--   - All values are sanitized via the existing article content sanitizers
--     before being stored + rendered.
-- ────────────────────────────────────────────────────────────────────────────

ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "seoNoindex" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "seoNofollow" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "customSeoTitle" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "customMetaDescription" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "customCanonical" TEXT;

-- Index on seoNoindex for the sitemap query (so we can quickly exclude
-- noindex articles from the sitemap when needed — currently the sitemap
-- includes ALL published articles regardless of noindex, but having the
-- index future-proofs the schema).
CREATE INDEX IF NOT EXISTS "Article_seoNoindex_idx" ON "Article"("seoNoindex");
