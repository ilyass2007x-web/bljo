-- ──────────────────────────────────────────────────────────────────────────
-- Global Domain Blocklist — BlockedDomain + BlockedDomainHit
-- ──────────────────────────────────────────────────────────────────────────
-- Creates two new tables:
--   1. BlockedDomain    — the admin-managed blocklist rules
--   2. BlockedDomainHit — the audit trail of every blocked URL attempt
--
-- IDEMPOTENT: every statement uses IF NOT EXISTS so re-running on an
-- already-migrated database is a no-op. Safe to run on every deploy.
--
-- BACKWARD COMPATIBLE:
--   - No existing tables or columns are modified.
--   - No existing data is touched.
--   - The new tables start empty — no blocking happens until the admin
--     adds rules via the dashboard.
-- ──────────────────────────────────────────────────────────────────────────

-- ── BlockedDomain table ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "BlockedDomain" (
  "id"               TEXT PRIMARY KEY,
  "domain"           TEXT NOT NULL,
  "normalizedDomain" TEXT NOT NULL,
  "reason"           TEXT,
  "notes"            TEXT,
  "isActive"         BOOLEAN NOT NULL DEFAULT true,
  "blockSubdomains"  BOOLEAN NOT NULL DEFAULT true,
  "hitCount"         INTEGER NOT NULL DEFAULT 0,
  "createdAt"        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "createdBy"        TEXT,

  CONSTRAINT "BlockedDomain_createdBy_fkey"
    FOREIGN KEY ("createdBy") REFERENCES "User"("id") ON DELETE SET NULL
);

-- The UNIQUE constraint on normalizedDomain prevents duplicate rules for
-- the same domain. Added separately so we can use IF NOT EXISTS.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'BlockedDomain_normalizedDomain_key'
  ) THEN
    ALTER TABLE "BlockedDomain" ADD CONSTRAINT "BlockedDomain_normalizedDomain_key" UNIQUE ("normalizedDomain");
  END IF;
END $$;

-- Indexes for the blocklist queries.
CREATE INDEX IF NOT EXISTS "BlockedDomain_isActive_idx" ON "BlockedDomain"("isActive");
CREATE INDEX IF NOT EXISTS "BlockedDomain_normalizedDomain_idx" ON "BlockedDomain"("normalizedDomain");

-- ── BlockedDomainHit table ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "BlockedDomainHit" (
  "id"              TEXT PRIMARY KEY,
  "blockedDomainId" TEXT NOT NULL,
  "userId"          TEXT,
  "context"         TEXT NOT NULL,
  "attemptedUrl"    TEXT NOT NULL,
  "createdAt"       TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "BlockedDomainHit_blockedDomainId_fkey"
    FOREIGN KEY ("blockedDomainId") REFERENCES "BlockedDomain"("id") ON DELETE CASCADE,
  CONSTRAINT "BlockedDomainHit_userId_fkey"
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL
);

-- Indexes for the "Blocked Activity" dashboard queries (filter by domain,
-- user, context, or date — all indexed).
CREATE INDEX IF NOT EXISTS "BlockedDomainHit_blockedDomainId_createdAt_idx"
  ON "BlockedDomainHit"("blockedDomainId", "createdAt");
CREATE INDEX IF NOT EXISTS "BlockedDomainHit_userId_createdAt_idx"
  ON "BlockedDomainHit"("userId", "createdAt");
CREATE INDEX IF NOT EXISTS "BlockedDomainHit_context_createdAt_idx"
  ON "BlockedDomainHit"("context", "createdAt");
CREATE INDEX IF NOT EXISTS "BlockedDomainHit_createdAt_idx"
  ON "BlockedDomainHit"("createdAt");
