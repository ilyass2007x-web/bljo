-- ──────────────────────────────────────────────────────────────────────────
-- SAFE ADDITIVE COLUMN COMPLETION (Production-specific, focused on search)
-- ──────────────────────────────────────────────────────────────────────────
--
-- PURPOSE:
--   Adds the missing columns referenced by src/app/api/v1/search/all/route.ts
--   (both via Prisma select clauses + raw SQL fragments) to the existing
--   User / Article / Playlist / Collection tables in production.
--
--   This is a COMPLEMENT to:
--     - 20260922000002_safe_search_completion_legacy (pg_trgm + normalized cols + indexes)
--
--   Without these columns, the Prisma client throws:
--     "The column User.fullName does not exist in the current database."
--   which the route's isSchemaError() catches and surfaces as:
--     "Database schema is out of sync"
--
-- SAFETY:
--   - All statements use ADD COLUMN IF NOT EXISTS (idempotent).
--   - All new columns are NULLABLE (backward-compatible with existing rows).
--   - Default values are added where the schema requires non-null behavior
--     (e.g. moderationStatus default 'APPROVED' so existing articles stay visible).
--   - NO DROP, NO DELETE, NO ALTER COLUMN TYPE, NO rename.
--   - Safe to re-run on every deploy.
--
-- COLUMN MAPPING (search route touch points):
--   User.fullName          (legacy "name" — populated by backfill from name)
--   User.avatarColor       (nullable, defaults to NULL)
--   User.avatarUrl         (nullable, defaults to NULL)
--   User.isVerified        (defaults to false)
--   Article.moderationStatus (defaults to 'APPROVED' — existing articles stay visible)
--   Article.coverImage     (nullable)
--   Article.videoUrl       (nullable)
--   Article.imageZoom      (nullable)
--   Article.imagePositionX (nullable)
--   Article.imagePositionY (nullable)
--   Article.showCoverInArticle (defaults to true)
--   Article.readingTime    (defaults to 1)
--   Playlist.name          (legacy "title" — populated by backfill from title)
--   Playlist.coverImage    (nullable, replaces legacy "thumbnail")
--   Playlist.isPublic     (defaults to true — visible by default for backward compat)
-- ──────────────────────────────────────────────────────────────────────────

-- ── User table ────────────────────────────────────────────────────────────
-- Schema.prisma: model User { fullName String  ... }
-- Legacy DB column: "name" (text, nullable). Add fullName as nullable text.
-- Backfill from "name" is done by a separate script.
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "fullName" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "avatarColor" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "avatarUrl" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "isVerified" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "lastSeenAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "totpSecret" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "recoveryCodes" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "bio" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "avatarColor" TEXT;

-- Backfill User.fullName from User.name where fullName is NULL.
-- Idempotent — safe to re-run.
UPDATE "User"
SET "fullName" = "name"
WHERE "fullName" IS NULL AND "name" IS NOT NULL;

-- ── Article table ──────────────────────────────────────────────────────────
-- Schema.prisma: model Article { moderationStatus String @default("APPROVED") ... }
-- Legacy DB column: missing. Default to 'APPROVED' so existing articles stay visible.
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "moderationStatus" TEXT NOT NULL DEFAULT 'APPROVED';
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "coverImage" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "videoUrl" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "imageZoom" DOUBLE PRECISION;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "imagePositionX" DOUBLE PRECISION;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "imagePositionY" DOUBLE PRECISION;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "showCoverInArticle" BOOLEAN NOT NULL DEFAULT true;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "readingTime" INTEGER NOT NULL DEFAULT 1;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "seoNoindex" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "seoNofollow" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "customSeoTitle" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "customMetaDescription" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "customCanonical" TEXT;

-- Backfill Article.coverImage from legacy "featuredImage" column.
UPDATE "Article"
SET "coverImage" = "featuredImage"
WHERE "coverImage" IS NULL AND "featuredImage" IS NOT NULL;

-- ── Playlist table ─────────────────────────────────────────────────────────
-- Schema.prisma: model Playlist { name String  isPublic Boolean @default(false)  coverImage String?  ... }
-- Legacy DB columns: "title" (replaces "name"), "thumbnail" (replaces "coverImage"),
--                    "visibility" (replaces "isPublic" — 'public' → true, else false).
ALTER TABLE "Playlist" ADD COLUMN IF NOT EXISTS "name" TEXT;
ALTER TABLE "Playlist" ADD COLUMN IF NOT EXISTS "coverImage" TEXT;
ALTER TABLE "Playlist" ADD COLUMN IF NOT EXISTS "isPublic" BOOLEAN NOT NULL DEFAULT true;
ALTER TABLE "Playlist" ADD COLUMN IF NOT EXISTS "ownerId" TEXT;

-- Backfill Playlist.name from legacy "title".
UPDATE "Playlist"
SET "name" = "title"
WHERE "name" IS NULL AND "title" IS NOT NULL;

-- Backfill Playlist.coverImage from legacy "thumbnail".
UPDATE "Playlist"
SET "coverImage" = "thumbnail"
WHERE "coverImage" IS NULL AND "thumbnail" IS NOT NULL;

-- Backfill Playlist.ownerId from legacy "authorId".
UPDATE "Playlist"
SET "ownerId" = "authorId"
WHERE "ownerId" IS NULL AND "authorId" IS NOT NULL;

-- Backfill Playlist.isPublic from legacy "visibility".
UPDATE "Playlist"
SET "isPublic" = (CASE WHEN "visibility" = 'public' THEN true ELSE false END)
WHERE "visibility" IS NOT NULL;

-- ── Collection table ──────────────────────────────────────────────────────
-- Legacy shape already matches schema.prisma (id, ownerId, name, description,
-- isPublic, createdAt, updatedAt). No additional columns needed.

