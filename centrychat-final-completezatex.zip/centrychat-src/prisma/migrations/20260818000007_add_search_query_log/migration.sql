-- ──────────────────────────────────────────────────────────────────────────
-- Migration: add_search_query_log
-- Purpose : Add the SearchQueryLog table for aggregated admin search
--           analytics (spec §35, §36).
--
-- Pure CREATE TABLE — no ALTER, no DROP, no data migration. Existing
-- tables are untouched.
-- ──────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "SearchQueryLog" (
    "id"          TEXT NOT NULL,
    "query"       TEXT NOT NULL,
    "resultCount" INTEGER NOT NULL DEFAULT 0,
    "hadResults"  BOOLEAN NOT NULL DEFAULT true,
    "userId"      TEXT,
    "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "SearchQueryLog_pkey" PRIMARY KEY ("id")
);

-- (query, createdAt) — powers "most searched terms" + "trending searches".
CREATE INDEX IF NOT EXISTS "SearchQueryLog_query_createdAt_idx" ON "SearchQueryLog"("query", "createdAt");

-- (hadResults, createdAt) — powers "no-result queries" (spec §36).
CREATE INDEX IF NOT EXISTS "SearchQueryLog_hadResults_createdAt_idx" ON "SearchQueryLog"("hadResults", "createdAt");

-- (createdAt) — powers time-window filters + future cleanup jobs
-- (anonymize userId after 24h).
CREATE INDEX IF NOT EXISTS "SearchQueryLog_createdAt_idx" ON "SearchQueryLog"("createdAt");

-- No foreign key on userId — we WANT to keep the row after the user is
-- deleted (for analytics integrity). The userId is nullable + set to NULL
-- after 24h by a future cleanup job (anonymization).
