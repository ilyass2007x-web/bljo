-- ──────────────────────────────────────────────────────────────────────────
-- Migration: add_search_and_trending_indexes
-- Purpose : Add indexes for search queries (case-insensitive contains)
--           and trending queries (recent engagement velocity).
--
-- ALL indexes are CREATE INDEX — non-destructive, no data migration.
-- Existing queries continue to work; they just get faster.
--
-- The platform uses PostgreSQL in production (Neon) + SQLite in dev.
-- Both support the indexes below:
--   - "plain" indexes (no operator class) work on both.
--   - PostgreSQL: for case-insensitive search we use `mode: "insensitive"`
--     in Prisma which compiles to ILIKE. A trigram GIN index would help
--     ILIKE, but requires the pg_trgm extension (not always available on
--     Neon's free tier). For now, plain indexes are added — they help
--     the initial scan + sort, even if ILIKE does a seq scan.
--   - SQLite: ILIKE falls back to LIKE which uses indexes.
-- ──────────────────────────────────────────────────────────────────────────

-- ── Search indexes ────────────────────────────────────────────────────────
-- Speeds up the "fullName contains" search in searchUsers() (src/lib/messaging.ts).
-- LEGACY GUARD: User.fullName column may not exist on legacy Production DBs
-- (legacy uses "name"). Wrapped in DO block — no-op when missing.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'User' AND column_name = 'fullName'
  ) THEN
    CREATE INDEX IF NOT EXISTS "User_fullName_idx" ON "User"("fullName");
  END IF;
END $$;

-- Speeds up the "username contains" search.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'User' AND column_name = 'username'
  ) THEN
    CREATE INDEX IF NOT EXISTS "User_username_idx" ON "User"("username");
  END IF;
END $$;

-- Speeds up the "post content contains" search in /api/v1/search/all.
-- LEGACY GUARD: Post table may not exist on legacy Production DBs.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Post'
  ) THEN
    CREATE INDEX IF NOT EXISTS "Post_content_idx" ON "Post"("content");
  END IF;
END $$;

-- Speeds up the "article title contains" search.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'Article' AND column_name = 'title'
  ) THEN
    CREATE INDEX IF NOT EXISTS "Article_title_idx" ON "Article"("title");
  END IF;
END $$;

-- Speeds up the "article excerpt contains" search.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'Article' AND column_name = 'excerpt'
  ) THEN
    CREATE INDEX IF NOT EXISTS "Article_excerpt_idx" ON "Article"("excerpt");
  END IF;
END $$;

-- ── Trending indexes ─────────────────────────────────────────────────────
-- Speeds up the "posts published in the last 48h" query (createdAt >= ?).
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Post'
  ) THEN
    CREATE INDEX IF NOT EXISTS "Post_createdAt_idx" ON "Post"("createdAt");
  END IF;
END $$;

-- Speeds up the "articles published in the last 48h" query (publishedAt >= ?).
-- (Already exists in the schema as part of @@index([publishedAt]) — but
-- IF NOT EXISTS makes this migration idempotent.)
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'Article' AND column_name = 'publishedAt'
  ) THEN
    CREATE INDEX IF NOT EXISTS "Article_publishedAt_idx" ON "Article"("publishedAt");
  END IF;
END $$;

-- ── Engagement-count indexes (for the admin dashboard's "top content"
--    queries that ORDER BY engagement counts) ─────────────────────────────
-- PostLike: helps the groupBy query for share counts + the admin
-- dashboard's "top posts" aggregation.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'PostLike'
  ) THEN
    CREATE INDEX IF NOT EXISTS "PostLike_postId_idx" ON "PostLike"("postId");
  END IF;
END $$;

-- ArticleLike: same.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'ArticleLike'
  ) THEN
    CREATE INDEX IF NOT EXISTS "ArticleLike_articleId_idx" ON "ArticleLike"("articleId");
  END IF;
END $$;

-- PostInteraction: helps the groupBy for share counts (type='SHARE').
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'PostInteraction'
  ) THEN
    CREATE INDEX IF NOT EXISTS "PostInteraction_postId_type_idx" ON "PostInteraction"("postId", "type");
  END IF;
END $$;

-- ArticleInteraction: same.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'ArticleInteraction'
  ) THEN
    CREATE INDEX IF NOT EXISTS "ArticleInteraction_articleId_type_idx" ON "ArticleInteraction"("articleId", "type");
  END IF;
END $$;
