-- ──────────────────────────────────────────────────────────────────────────
-- SAFE ADDITIVE: Normalize User.email to lowercase
-- ──────────────────────────────────────────────────────────────────────────
--
-- PURPOSE:
--   The EMAIL_SCHEMA validation layer (src/lib/security/sanitize.ts) lowercases
--   the input email before lookup. This was added at some point AFTER the
--   platform launched. Legacy users (registered before the lowercasing was
--   enforced) may have stored emails with mixed case, e.g.:
--     - "User@Gmail.com"
--     - "USER@gmail.com"
--     - "user@Gmail.com"
--
--   On PostgreSQL, the UNIQUE constraint on `email` is case-sensitive by
--   default — meaning "User@Gmail.com" and "user@gmail.com" can BOTH exist
--   as separate rows. The application layer normalizes input to lowercase
--   before `findUnique`, so a legacy user typing their original mixed-case
--   email into the login form would have their input lowercased → the
--   case-sensitive lookup misses them → "Invalid email or password".
--
--   This migration normalizes ALL existing User.email values to lowercase,
--   so the storage matches the validation layer. Combined with the
--   case-insensitive lookup code in the login/register/forgot-password
--   routes, this provides BOTH:
--     1. Forward compatibility — future lookups work case-sensitively too.
--     2. Backward compatibility — legacy users can still log in.
--
-- SAFETY:
--   - Idempotent: only updates rows where email != LOWER(email).
--   - Non-destructive: no DROP, no DELETE, no schema change.
--   - Collision-safe: the DO block FIRST checks for case-insensitive
--     duplicates. If any exist (e.g. both "User@Gmail.com" and
--     "user@gmail.com" exist as separate rows), the migration REFUSES
--     to lowercase either — instead it logs the conflict via RAISE NOTICE
--     so the admin can resolve manually. This prevents a UNIQUE constraint
--     violation that would abort the migration.
--   - SURFACES CONFLICTS via PlatformSetting: any conflict count is written
--     to PlatformSetting (key='auth.email_lowercase_conflicts') so the
--     admin dashboard can display an alert. This addresses the audit
--     finding that RAISE NOTICE alone is not surfaced through
--     `prisma db execute`. The PlatformSetting row is upserted (idempotent)
--     so re-running the migration updates the count rather than duplicating.
--   - The User.email column itself is NOT modified (no type change, no
--     constraint change, no default change).
--
-- POST-MIGRATION STATE:
--   All User.email values are lowercase. The unique constraint continues
--   to work as before. Future registrations store lowercase emails
--   (enforced by the EMAIL_SCHEMA validation layer).
--
-- REVERSIBILITY:
--   This migration is NOT reversible — once emails are lowercased, you
--   cannot recover the original case. This is by design: the original
--   case was never meaningful (emails are case-insensitive per RFC 5321
--   for the domain part, and case-insensitive in practice for the local
--   part on all major providers — Gmail, Outlook, Yahoo, etc.).
-- ──────────────────────────────────────────────────────────────────────────

-- ── STEP 1: Detect case-insensitive duplicate emails ────────────────────
-- If two rows exist with the same email in different cases, lowercasing
-- would cause a UNIQUE constraint violation. We detect this BEFORE
-- attempting the UPDATE and refuse to lowercase the conflicting rows.
-- The admin must manually resolve the conflict (e.g. merge accounts or
-- delete the duplicate) before re-running this migration.
DO $$
DECLARE
  conflict_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO conflict_count
  FROM (
    SELECT LOWER("email") AS lower_email
    FROM "User"
    WHERE "email" IS NOT NULL
    GROUP BY LOWER("email")
    HAVING COUNT(*) > 1
  ) dup;

  IF conflict_count > 0 THEN
    RAISE NOTICE 'Found % case-insensitive duplicate email(s). Lowercase migration SKIPPED to avoid UNIQUE constraint violation. Resolve manually.', conflict_count;
    -- Insert a row into a temporary log so the admin can see which emails
    -- are conflicting (NOT the user data itself — just the lowercased
    -- email that has duplicates).
    RAISE NOTICE 'Conflicting lowercased emails (run: SELECT LOWER("email"), COUNT(*) FROM "User" GROUP BY LOWER("email") HAVING COUNT(*) > 1):';
  END IF;
END $$;

-- ── STEP 2: Lowercase emails where no conflict exists ────────────────────
-- This UPDATE only affects rows where:
--   1. The email is not already lowercase (email != LOWER(email)).
--   2. The lowercased version does NOT collide with another existing email
--      (case-sensitive) — i.e. no other row has the LOWER(email) value.
-- The subquery ensures we never violate the UNIQUE constraint.
UPDATE "User" u
SET "email" = LOWER(u."email")
WHERE u."email" IS NOT NULL
  AND u."email" != LOWER(u."email")
  AND NOT EXISTS (
    SELECT 1
    FROM "User" other
    WHERE other."email" = LOWER(u."email")
      AND other.id != u.id
  );

-- ── STEP 3: Record remaining mixed-case count + conflict count in PlatformSetting ─
-- After the UPDATE, any remaining mixed-case emails are CONFLICTS that
-- could not be auto-resolved. We persist this count to PlatformSetting so
-- the admin dashboard can display an alert (audit fix: previously this
-- was only emitted via RAISE NOTICE which is invisible via `prisma db execute`).
DO $$
DECLARE
  remaining INTEGER;
  conflicts INTEGER;
  setting_exists BOOLEAN;
BEGIN
  -- Count remaining mixed-case emails (conflicts that couldn't be auto-resolved)
  SELECT COUNT(*) INTO remaining
  FROM "User"
  WHERE "email" IS NOT NULL AND "email" != LOWER("email");

  -- Count case-insensitive duplicate groups (the underlying conflicts)
  SELECT COUNT(*) INTO conflicts
  FROM (
    SELECT LOWER("email") AS lower_email
    FROM "User"
    WHERE "email" IS NOT NULL
    GROUP BY LOWER("email")
    HAVING COUNT(*) > 1
  ) dup;

  -- Upsert into PlatformSetting so the admin dashboard can surface this.
  -- Two settings: remaining-mixed-case count + active-conflicts count.
  -- Safe: only runs if the PlatformSetting table exists (it does in
  -- Production — created by an early migration).
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'PlatformSetting'
  ) THEN
    -- Check if the row already exists (upsert pattern, no SQL UPSERT to
    -- avoid version-specific syntax issues).
    SELECT EXISTS(
      SELECT 1 FROM "PlatformSetting" WHERE "key" = 'auth.email_lowercase_conflicts'
    ) INTO setting_exists;

    IF setting_exists THEN
      UPDATE "PlatformSetting"
      SET "value" = conflicts::text, "updatedAt" = NOW()
      WHERE "key" = 'auth.email_lowercase_conflicts';
    ELSE
      INSERT INTO "PlatformSetting" ("id", "key", "value", "type", "updatedAt")
      VALUES (gen_random_uuid()::text, 'auth.email_lowercase_conflicts', conflicts::text, 'number', NOW());
    END IF;

    SELECT EXISTS(
      SELECT 1 FROM "PlatformSetting" WHERE "key" = 'auth.email_lowercase_remaining'
    ) INTO setting_exists;

    IF setting_exists THEN
      UPDATE "PlatformSetting"
      SET "value" = remaining::text, "updatedAt" = NOW()
      WHERE "key" = 'auth.email_lowercase_remaining';
    ELSE
      INSERT INTO "PlatformSetting" ("id", "key", "value", "type", "updatedAt")
      VALUES (gen_random_uuid()::text, 'auth.email_lowercase_remaining', remaining::text, 'number', NOW());
    END IF;

    RAISE NOTICE 'Recorded auth.email_lowercase_conflicts=% and auth.email_lowercase_remaining=% in PlatformSetting.', conflicts, remaining;
  ELSE
    RAISE NOTICE 'PlatformSetting table not found — could not record conflict count. Remaining mixed-case: %', remaining;
  END IF;
END $$;
