-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Add AdUnit table for Google AdSense management.
--
-- IDEMPOTENT — safe to run on every deploy (Netlify build runs this before
-- `prisma db push`). Uses `CREATE TABLE IF NOT EXISTS` so a partial prior
-- run doesn't conflict.
--
-- SECURITY:
--   - No data is migrated (new table — no existing rows).
--   - No existing table is touched.
--   - Indexes are also IF NOT EXISTS.
--
-- PRISMA SCHEMA LOCATION:
--   prisma/schema.prisma → `model AdUnit` (added in this task).
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "AdUnit" (
    "id"          TEXT NOT NULL,
    "name"        TEXT NOT NULL,
    "description" TEXT,
    "slotId"      TEXT NOT NULL,
    "format"      TEXT NOT NULL DEFAULT 'RESPONSIVE',
    "placement"   TEXT NOT NULL,
    "priority"    INTEGER NOT NULL DEFAULT 10,
    "active"      BOOLEAN NOT NULL DEFAULT true,
    "devices"     TEXT,
    "pages"       TEXT,
    "rotation"    BOOLEAN NOT NULL DEFAULT false,
    "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"   TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AdUnit_pkey" PRIMARY KEY ("id")
);

-- Indexes — used by the AdsManager's main query:
--   "Give me all active units for placement X, ordered by priority."
CREATE INDEX IF NOT EXISTS "AdUnit_placement_active_priority_idx"
    ON "AdUnit" ("placement", "active", "priority");

CREATE INDEX IF NOT EXISTS "AdUnit_active_idx"
    ON "AdUnit" ("active");

CREATE INDEX IF NOT EXISTS "AdUnit_format_idx"
    ON "AdUnit" ("format");
