-- ──────────────────────────────────────────────────────────────────────────
-- Migration: add_article_interactions
-- Purpose : Add Article interaction tables (Like/Comment/View/Interaction)
--           mirroring the Post interaction tables.
--
-- Design rationale: see the `Article` model comment in schema.prisma.
-- The short version: PostgreSQL's UNIQUE constraint treats NULLs as
-- distinct, so a polymorphic (postId, articleId, userId) unique
-- constraint would NOT enforce uniqueness for rows where articleId is
-- NULL (i.e. all existing post likes). Separate tables are the safest
-- design — they don't touch the existing Post tables, so no migration
-- risk to existing data, no risk of breaking the working Post system.
--
-- All four new tables are pure additions (CREATE TABLE only).
-- No ALTER TABLE, no DROP, no data migration.
-- Existing PostLike/PostComment/PostView/PostInteraction are untouched.
-- ──────────────────────────────────────────────────────────────────────────

-- ArticleLike ──────────────────────────────────────────────────────────────
-- One row per (articleId, userId). The @@unique constraint is the source
-- of truth for "no duplicate likes" — concurrent double-tap requests
-- get P2002, which the API swallows.
CREATE TABLE IF NOT EXISTS "ArticleLike" (
    "id"        TEXT NOT NULL,
    "articleId" TEXT NOT NULL,
    "userId"    TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ArticleLike_pkey" PRIMARY KEY ("id")
);

-- Unique constraint — source of truth for "no duplicate likes".
CREATE UNIQUE INDEX IF NOT EXISTS "ArticleLike_articleId_userId_key" ON "ArticleLike"("articleId", "userId");
-- Index for "what articles has this user liked?" (future Profile tab).
CREATE INDEX IF NOT EXISTS "ArticleLike_userId_idx" ON "ArticleLike"("userId");

-- Foreign keys — cascade-delete with the article + the user.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleLike_articleId_fkey'
  ) THEN
    ALTER TABLE "ArticleLike" ADD CONSTRAINT "ArticleLike_articleId_fkey"
    FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleLike_userId_fkey'
  ) THEN
    ALTER TABLE "ArticleLike" ADD CONSTRAINT "ArticleLike_userId_fkey"
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;

-- ArticleComment ──────────────────────────────────────────────────────────
-- Same shape as PostComment: user-generated comments, oldest-first.
CREATE TABLE IF NOT EXISTS "ArticleComment" (
    "id"        TEXT NOT NULL,
    "articleId" TEXT NOT NULL,
    "authorId"  TEXT NOT NULL,
    "content"   TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ArticleComment_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ArticleComment_articleId_createdAt_idx" ON "ArticleComment"("articleId", "createdAt");
CREATE INDEX IF NOT EXISTS "ArticleComment_authorId_idx" ON "ArticleComment"("authorId");

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleComment_articleId_fkey'
  ) THEN
    ALTER TABLE "ArticleComment" ADD CONSTRAINT "ArticleComment_articleId_fkey"
    FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleComment_authorId_fkey'
  ) THEN
    ALTER TABLE "ArticleComment" ADD CONSTRAINT "ArticleComment_authorId_fkey"
    FOREIGN KEY ("authorId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;

-- ArticleView ─────────────────────────────────────────────────────────────
-- One row per (articleId, userId) — DB-level enforcement prevents
-- duplicates from refreshes, reopens, and concurrent requests (smart
-- unique view system, mirroring PostView's design).
CREATE TABLE IF NOT EXISTS "ArticleView" (
    "id"        TEXT NOT NULL,
    "articleId" TEXT NOT NULL,
    "userId"    TEXT,
    "viewedAt"  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "duration"  INTEGER,
    "completed" BOOLEAN,
    "source"    TEXT,

    CONSTRAINT "ArticleView_pkey" PRIMARY KEY ("id")
);

-- Unique constraint — source of truth for smart unique views.
-- PostgreSQL treats NULLs as distinct, so anonymous views (userId=NULL)
-- are NOT deduped at the DB level — client-side dedup handles that.
CREATE UNIQUE INDEX IF NOT EXISTS "ArticleView_articleId_userId_key" ON "ArticleView"("articleId", "userId");
CREATE INDEX IF NOT EXISTS "ArticleView_articleId_viewedAt_idx" ON "ArticleView"("articleId", "viewedAt");
CREATE INDEX IF NOT EXISTS "ArticleView_userId_articleId_idx" ON "ArticleView"("userId", "articleId");

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleView_articleId_fkey'
  ) THEN
    ALTER TABLE "ArticleView" ADD CONSTRAINT "ArticleView_articleId_fkey"
    FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;
-- userId is nullable (anonymous views). On user delete, set NULL to keep
-- the anonymous view row for analytics integrity (per spec — don't keep
-- unnecessary PII, but keep aggregate counts accurate).
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleView_userId_fkey'
  ) THEN
    ALTER TABLE "ArticleView" ADD CONSTRAINT "ArticleView_userId_fkey"
      FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;

-- ArticleInteraction ──────────────────────────────────────────────────────
-- Generic event log for articles (SHARE, LINK_COPY, etc.).
-- LIKE and COMMENT are NOT logged here (they live in ArticleLike /
-- ArticleComment) to avoid double-counting.
CREATE TABLE IF NOT EXISTS "ArticleInteraction" (
    "id"        TEXT NOT NULL,
    "articleId" TEXT NOT NULL,
    "userId"    TEXT,
    "type"      TEXT NOT NULL,
    "metadata"  TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ArticleInteraction_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ArticleInteraction_articleId_createdAt_idx" ON "ArticleInteraction"("articleId", "createdAt");
CREATE INDEX IF NOT EXISTS "ArticleInteraction_userId_createdAt_idx" ON "ArticleInteraction"("userId", "createdAt");
CREATE INDEX IF NOT EXISTS "ArticleInteraction_type_createdAt_idx" ON "ArticleInteraction"("type", "createdAt");

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleInteraction_articleId_fkey'
  ) THEN
    ALTER TABLE "ArticleInteraction" ADD CONSTRAINT "ArticleInteraction_articleId_fkey"
    FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'ArticleInteraction_userId_fkey'
  ) THEN
    ALTER TABLE "ArticleInteraction" ADD CONSTRAINT "ArticleInteraction_userId_fkey"
      FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;
