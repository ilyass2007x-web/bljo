-- AI Moderation Provider System (Additive — Phase: AI Moderation)
-- =================================================================
-- Creates 4 new tables + indexes. NO changes to existing tables except
-- adding 4 new optional relations on the User side (handled via the new
-- FK columns below — all are nullable so existing rows are unaffected).
--
-- SECURITY:
--   - API keys are stored AES-GCM encrypted in ai_moderation_provider.api_key_encrypted
--     (never in plaintext, never returned by any API).
--   - The encryption key (MODERATION_ENCRYPTION_KEY) lives ONLY in the
--     server-side environment — NEVER in the database.
--   - All admin mutations are audit-logged via the existing AdminAuditLog.
--
-- IDempotent: every CREATE uses IF NOT EXISTS, every index uses IF NOT EXISTS.
-- Safe to run on every deploy.

-- ── AiModerationProvider ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "ai_moderation_provider" (
    "id"              TEXT NOT NULL,
    "name"            TEXT NOT NULL,
    "type"            TEXT NOT NULL,
    "model"           TEXT NOT NULL,
    "api_key_encrypted" TEXT,
    "endpoint"        TEXT,
    "priority"        INTEGER NOT NULL DEFAULT 0,
    "supports_text"   BOOLEAN NOT NULL DEFAULT TRUE,
    "supports_image"  BOOLEAN NOT NULL DEFAULT FALSE,
    "supports_video"  BOOLEAN NOT NULL DEFAULT FALSE,
    "health_status"   TEXT NOT NULL DEFAULT 'unknown',
    "last_health_check" TIMESTAMP(3),
    "last_health_error" TEXT,
    "total_requests"  INTEGER NOT NULL DEFAULT 0,
    "failed_requests" INTEGER NOT NULL DEFAULT 0,
    "created_at"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at"      TIMESTAMP(3) NOT NULL,
    "updated_by_id"   TEXT,

    CONSTRAINT "ai_moderation_provider_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ai_moderation_provider_priority_idx"
    ON "ai_moderation_provider"("priority");
CREATE INDEX IF NOT EXISTS "ai_moderation_provider_type_idx"
    ON "ai_moderation_provider"("type");
CREATE INDEX IF NOT EXISTS "ai_moderation_provider_health_status_idx"
    ON "ai_moderation_provider"("health_status");

-- FK: updated_by_id → User.id (ON DELETE SET NULL — audit survives admin deletion)
ALTER TABLE "ai_moderation_provider"
    DROP CONSTRAINT IF EXISTS "ai_moderation_provider_updated_by_id_fkey";
ALTER TABLE "ai_moderation_provider"
    ADD CONSTRAINT "ai_moderation_provider_updated_by_id_fkey"
    FOREIGN KEY ("updated_by_id") REFERENCES "User"("id")
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ── AiModerationResult ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "ai_moderation_result" (
    "id"                TEXT NOT NULL,
    "provider_id"       TEXT,
    "provider_name"     TEXT NOT NULL,
    "model_name"        TEXT NOT NULL,
    "content_type"      TEXT NOT NULL,
    "content_id"        TEXT,
    "content_hash"      TEXT,
    "user_id"           TEXT,
    "category_scores"   JSONB NOT NULL,
    "score"             DOUBLE PRECISION NOT NULL,
    "confidence"        DOUBLE PRECISION,
    "reason"            TEXT NOT NULL DEFAULT '',
    "action"            TEXT NOT NULL,
    "policy_version"    INTEGER NOT NULL,
    "fallback_from"     TEXT,
    "processing_time_ms" INTEGER NOT NULL,
    "created_at"        TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ai_moderation_result_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ai_moderation_result_provider_id_created_at_idx"
    ON "ai_moderation_result"("provider_id", "created_at");
CREATE INDEX IF NOT EXISTS "ai_moderation_result_user_id_created_at_idx"
    ON "ai_moderation_result"("user_id", "created_at");
CREATE INDEX IF NOT EXISTS "ai_moderation_result_content_type_created_at_idx"
    ON "ai_moderation_result"("content_type", "created_at");
CREATE INDEX IF NOT EXISTS "ai_moderation_result_action_created_at_idx"
    ON "ai_moderation_result"("action", "created_at");
CREATE INDEX IF NOT EXISTS "ai_moderation_result_content_hash_idx"
    ON "ai_moderation_result"("content_hash");
CREATE INDEX IF NOT EXISTS "ai_moderation_result_policy_version_idx"
    ON "ai_moderation_result"("policy_version");

-- FK: provider_id → ai_moderation_provider.id (ON DELETE SET NULL)
ALTER TABLE "ai_moderation_result"
    DROP CONSTRAINT IF EXISTS "ai_moderation_result_provider_id_fkey";
ALTER TABLE "ai_moderation_result"
    ADD CONSTRAINT "ai_moderation_result_provider_id_fkey"
    FOREIGN KEY ("provider_id") REFERENCES "ai_moderation_provider"("id")
    ON DELETE SET NULL ON UPDATE CASCADE;

-- FK: user_id → User.id (ON DELETE SET NULL — result row survives user deletion)
ALTER TABLE "ai_moderation_result"
    DROP CONSTRAINT IF EXISTS "ai_moderation_result_user_id_fkey";
ALTER TABLE "ai_moderation_result"
    ADD CONSTRAINT "ai_moderation_result_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "User"("id")
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ── AiModerationReviewItem ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "ai_moderation_review_item" (
    "id"              TEXT NOT NULL,
    "result_id"       TEXT NOT NULL,
    "status"          TEXT NOT NULL DEFAULT 'PENDING',
    "admin_notes"     TEXT,
    "applied_actions" JSONB NOT NULL DEFAULT '[]'::jsonb,
    "reviewer_id"     TEXT,
    "reviewed_at"     TIMESTAMP(3),
    "created_at"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at"      TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ai_moderation_review_item_pkey" PRIMARY KEY ("id")
);

-- One review item per result (UNIQUE)
CREATE UNIQUE INDEX IF NOT EXISTS "ai_moderation_review_item_result_id_key"
    ON "ai_moderation_review_item"("result_id");
CREATE INDEX IF NOT EXISTS "ai_moderation_review_item_status_created_at_idx"
    ON "ai_moderation_review_item"("status", "created_at");
CREATE INDEX IF NOT EXISTS "ai_moderation_review_item_reviewer_id_idx"
    ON "ai_moderation_review_item"("reviewer_id");

-- FK: result_id → ai_moderation_result.id (ON DELETE CASCADE)
ALTER TABLE "ai_moderation_review_item"
    DROP CONSTRAINT IF EXISTS "ai_moderation_review_item_result_id_fkey";
ALTER TABLE "ai_moderation_review_item"
    ADD CONSTRAINT "ai_moderation_review_item_result_id_fkey"
    FOREIGN KEY ("result_id") REFERENCES "ai_moderation_result"("id")
    ON DELETE CASCADE ON UPDATE CASCADE;

-- FK: reviewer_id → User.id (ON DELETE SET NULL)
ALTER TABLE "ai_moderation_review_item"
    DROP CONSTRAINT IF EXISTS "ai_moderation_review_item_reviewer_id_fkey";
ALTER TABLE "ai_moderation_review_item"
    ADD CONSTRAINT "ai_moderation_review_item_reviewer_id_fkey"
    FOREIGN KEY ("reviewer_id") REFERENCES "User"("id")
    ON DELETE SET NULL ON UPDATE CASCADE;

-- ── AiModerationUserViolation ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "ai_moderation_user_violation" (
    "id"                       TEXT NOT NULL,
    "user_id"                  TEXT NOT NULL,
    "result_id"                TEXT,
    "content_type"             TEXT NOT NULL,
    "content_id"               TEXT,
    "category"                 TEXT NOT NULL,
    "severity"                 TEXT NOT NULL,
    "score"                    DOUBLE PRECISION NOT NULL,
    "policy_version"           INTEGER NOT NULL,
    "applied_action"           TEXT,
    "applied_content_action"   TEXT,
    "restriction_ends_at"      TIMESTAMP(3),
    "created_at"               TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ai_moderation_user_violation_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ai_moderation_user_violation_user_id_created_at_idx"
    ON "ai_moderation_user_violation"("user_id", "created_at");
CREATE INDEX IF NOT EXISTS "ai_moderation_user_violation_category_created_at_idx"
    ON "ai_moderation_user_violation"("category", "created_at");
CREATE INDEX IF NOT EXISTS "ai_moderation_user_violation_policy_version_idx"
    ON "ai_moderation_user_violation"("policy_version");

-- FK: user_id → User.id (ON DELETE CASCADE — deleted user's violations are cleaned up)
ALTER TABLE "ai_moderation_user_violation"
    DROP CONSTRAINT IF EXISTS "ai_moderation_user_violation_user_id_fkey";
ALTER TABLE "ai_moderation_user_violation"
    ADD CONSTRAINT "ai_moderation_user_violation_user_id_fkey"
    FOREIGN KEY ("user_id") REFERENCES "User"("id")
    ON DELETE CASCADE ON UPDATE CASCADE;
