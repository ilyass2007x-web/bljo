-- Migration: Add anonymous visitor support for ArticleView
--
-- PURPOSE (spec §2 — Anonymous Visitors):
--   Allow logged-out visitors (Google referrers, direct link clicks,
--   Incognito browsers) to have their article views counted — with proper
--   deduplication so a single browser cannot inflate counts via Refresh.
--
-- CHANGES:
--   1. Add column `anonymousVisitorId` (TEXT, nullable) to ArticleView.
--      For logged-in users, this is NULL (we use `userId` for dedup).
--      For logged-out users, this is a SHA-256 hash of the visitor cookie
--      token (prefixed with "anon:") — see src/lib/security/visitor-cookie.ts.
--
--   2. Add a SECONDARY unique constraint on (articleId, anonymousVisitorId).
--      PostgreSQL treats NULLs as distinct in UNIQUE constraints, so this
--      constraint is a no-op for logged-in rows (anonymousVisitorId IS NULL).
--      For anonymous rows (anonymousVisitorId IS NOT NULL), it enforces
--      one row per (article, visitor token) — preventing Refresh inflation.
--
--   3. Add an index on (anonymousVisitorId, articleId) for fast reverse
--      lookups ("what articles has this anonymous visitor viewed?").
--
-- IDEMPOTENT: safe to run on every deploy. No-op if the column already exists.
-- This migration is RUN BEFORE `prisma db push` in the Netlify build command
-- (see netlify.toml). The db push then syncs any other additive schema changes.

-- 1. Add the column if it doesn't exist.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = 'ArticleView'
      AND column_name = 'anonymousVisitorId'
  ) THEN
    ALTER TABLE "ArticleView"
      ADD COLUMN "anonymousVisitorId" TEXT;
  END IF;
END$$;

-- 2. Add the secondary unique constraint if it doesn't exist.
--    Drop first to be idempotent (no-op if not present).
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'ArticleView_articleId_anonymousVisitorId_key'
  ) THEN
    ALTER TABLE "ArticleView"
      DROP CONSTRAINT "ArticleView_articleId_anonymousVisitorId_key";
  END IF;
  ALTER TABLE "ArticleView"
    ADD CONSTRAINT "ArticleView_articleId_anonymousVisitorId_key"
    UNIQUE ("articleId", "anonymousVisitorId");
END$$;

-- 3. Add the index if it doesn't exist (idempotent).
CREATE INDEX IF NOT EXISTS "ArticleView_anonymousVisitorId_articleId_idx"
  ON "ArticleView" ("anonymousVisitorId", "articleId");
