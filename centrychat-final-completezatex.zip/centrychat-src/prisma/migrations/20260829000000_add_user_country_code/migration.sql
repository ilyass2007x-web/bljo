-- ──────────────────────────────────────────────────────────────────────────
-- Add countryCode to User — for Video Chat country-based matchmaking
-- ──────────────────────────────────────────────────────────────────────────
-- Adds a nullable `countryCode` column to the User table (ISO 3166-1 alpha-2).
--
-- IDEMPOTENT: uses ADD COLUMN IF NOT EXISTS so re-running is a no-op.
--
-- BACKWARD COMPATIBLE:
--   - The column is nullable — existing users have NULL until they set it.
--   - No existing columns are modified or deleted.
--   - The API layer enforces the requirement for NEW registrations.
-- ──────────────────────────────────────────────────────────────────────────

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'User' AND column_name = 'countryCode'
  ) THEN
    ALTER TABLE "User" ADD COLUMN "countryCode" TEXT;
  END IF;
END $$;

-- Index for country-based queries (video chat matchmaking filters by country).
CREATE INDEX IF NOT EXISTS "User_countryCode_idx" ON "User"("countryCode");
