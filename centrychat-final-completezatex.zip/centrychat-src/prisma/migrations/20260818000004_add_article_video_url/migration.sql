-- Additive migration: adds nullable `videoUrl` column to the Article table.
-- Safe: no existing data is modified, no existing columns are changed.
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "videoUrl" TEXT;
