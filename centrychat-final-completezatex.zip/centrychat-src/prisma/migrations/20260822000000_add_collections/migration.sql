-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Phase 5 — Collections
--
-- Creates two new tables:
--   - Collection         (user-owned curated lists of polymorphic content)
--   - CollectionItem      (the items inside a collection, polymorphic)
--
-- IDEMPOTENT — safe to run on every deploy. Uses CREATE TABLE IF NOT EXISTS +
-- CREATE INDEX IF NOT EXISTS so re-runs are no-ops. Backward compatible:
-- existing tables, rows, and indexes are untouched.
--
-- ADDITIVE ONLY — no ALTER on existing tables (except none needed here),
-- no DROP, no rename, no data migration. Existing users + content remain
-- completely unaffected. The new tables start empty.
--
-- POLYMORPHIC DESIGN:
--   CollectionItem has NO foreign key to Post/Article/etc. The pair
--   (contentType, contentId) identifies the underlying content, validated
--   server-side in the API route before insertion. This avoids nullable
--   per-type FKs + keeps the schema simple. See prisma/schema.prisma for
--   the rationale comment on the CollectionItem model.
--
-- DELETION CASCADE:
--   Collection.ownerId        → User.id             (onDelete: Cascade)
--   CollectionItem.collectionId → Collection.id      (onDelete: Cascade)
--   So: User deleted → their Collections deleted → their items deleted.
--   The underlying Post/Article/Video/Discussion content is NEVER touched
--   (no FK in that direction).
-- ────────────────────────────────────────────────────────────────────────────

-- Create Collection table
CREATE TABLE IF NOT EXISTS "Collection" (
    "id"          TEXT NOT NULL,
    "ownerId"     TEXT NOT NULL,
    "name"        TEXT NOT NULL,
    "description" TEXT,
    "isPublic"    BOOLEAN NOT NULL DEFAULT false,
    "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"   TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Collection_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "Collection_ownerId_idx" ON "Collection" ("ownerId");
CREATE INDEX IF NOT EXISTS "Collection_isPublic_updatedAt_idx" ON "Collection" ("isPublic", "updatedAt");
-- Foreign key to User. ON DELETE CASCADE — when a User is deleted, all their
-- Collections (and the items inside, via the CollectionItem cascade below)
-- are cleaned up automatically. No orphan rows.
ALTER TABLE "Collection" DROP CONSTRAINT IF EXISTS "Collection_ownerId_fkey";
ALTER TABLE "Collection" ADD CONSTRAINT "Collection_ownerId_fkey"
    FOREIGN KEY ("ownerId") REFERENCES "User"("id") ON DELETE CASCADE;

-- Create CollectionItem table
CREATE TABLE IF NOT EXISTS "CollectionItem" (
    "id"           TEXT NOT NULL,
    "collectionId" TEXT NOT NULL,
    "contentType"  TEXT NOT NULL,
    "contentId"    TEXT NOT NULL,
    "position"     INTEGER NOT NULL DEFAULT 0,
    "addedAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "CollectionItem_pkey" PRIMARY KEY ("id")
);
-- SOURCE OF TRUTH for "no duplicate items in the same collection".
CREATE UNIQUE INDEX IF NOT EXISTS "CollectionItem_collectionId_contentType_contentId_key"
    ON "CollectionItem" ("collectionId", "contentType", "contentId");
-- Powers "list items in collection X, ordered by position".
CREATE INDEX IF NOT EXISTS "CollectionItem_collectionId_position_idx"
    ON "CollectionItem" ("collectionId", "position");
-- Powers "which collections contain this content?" (Save dialog already-saved state).
CREATE INDEX IF NOT EXISTS "CollectionItem_contentType_contentId_idx"
    ON "CollectionItem" ("contentType", "contentId");
-- Foreign key to Collection. ON DELETE CASCADE — when a Collection is
-- deleted, all its items are deleted automatically. No orphan rows.
ALTER TABLE "CollectionItem" DROP CONSTRAINT IF EXISTS "CollectionItem_collectionId_fkey";
ALTER TABLE "CollectionItem" ADD CONSTRAINT "CollectionItem_collectionId_fkey"
    FOREIGN KEY ("collectionId") REFERENCES "Collection"("id") ON DELETE CASCADE;
