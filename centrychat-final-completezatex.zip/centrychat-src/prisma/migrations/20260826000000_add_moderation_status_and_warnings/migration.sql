-- ──────────────────────────────────────────────────────────────────────────
-- Content Moderation Gate + User Warnings
-- ──────────────────────────────────────────────────────────────────────────
-- Adds a `moderationStatus` column to Post, Article, PostComment, and
-- ArticleComment so that content flagged for review (PENDING_MODERATION)
-- or rejected can be excluded from public feeds, search, sitemap, trending,
-- and topics — even when the row exists in the database.
--
-- Also creates the `UserWarning` table for the admin user-warning system.
--
-- IDEMPOTENT: every statement uses IF NOT EXISTS so re-running on an
-- already-migrated database is a no-op. Safe to run on every deploy.
--
-- BACKWARD COMPATIBLE:
--   - All new columns default to 'APPROVED' so existing content stays public.
--   - No existing columns are removed or renamed.
--   - No existing indexes are dropped.
-- ──────────────────────────────────────────────────────────────────────────

-- ── Post.moderationStatus ───────────────────────────────────────
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Post'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'Post' AND column_name = 'moderationStatus'
  ) THEN
    ALTER TABLE "Post" ADD COLUMN "moderationStatus" TEXT NOT NULL DEFAULT 'APPROVED';
  END IF;
END $$;

-- ── Article.moderationStatus ───────────────────────────────────────────
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Article'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'Article' AND column_name = 'moderationStatus'
  ) THEN
    ALTER TABLE "Article" ADD COLUMN "moderationStatus" TEXT NOT NULL DEFAULT 'APPROVED';
  END IF;
END $$;

-- ── PostComment.moderationStatus ───────────────────────────────────────
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'PostComment'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'PostComment' AND column_name = 'moderationStatus'
  ) THEN
    ALTER TABLE "PostComment" ADD COLUMN "moderationStatus" TEXT NOT NULL DEFAULT 'APPROVED';
  END IF;
END $$;

-- ── ArticleComment.moderationStatus ────────────────────────────────────
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'ArticleComment'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = current_schema() AND table_name = 'ArticleComment' AND column_name = 'moderationStatus'
  ) THEN
    ALTER TABLE "ArticleComment" ADD COLUMN "moderationStatus" TEXT NOT NULL DEFAULT 'APPROVED';
  END IF;
END $$;

-- ── Indexes for moderationStatus filtering ─────────────────────────────
-- Speeds up the WHERE moderationStatus = 'APPROVED' filter used by every
-- public feed/search/sitemap query. Idempotent (IF NOT EXISTS).
-- Each CREATE INDEX is wrapped in a DO block that checks for table existence
-- (legacy Production DB may not have Post / PostComment / ArticleComment).
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'Post') THEN
    CREATE INDEX IF NOT EXISTS "Post_moderationStatus_idx" ON "Post"("moderationStatus");
  END IF;
END $$;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'Article') THEN
    CREATE INDEX IF NOT EXISTS "Article_moderationStatus_idx" ON "Article"("moderationStatus");
  END IF;
END $$;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'PostComment') THEN
    CREATE INDEX IF NOT EXISTS "PostComment_moderationStatus_idx" ON "PostComment"("moderationStatus");
  END IF;
END $$;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = current_schema() AND table_name = 'ArticleComment') THEN
    CREATE INDEX IF NOT EXISTS "ArticleComment_moderationStatus_idx" ON "ArticleComment"("moderationStatus");
  END IF;
END $$;

-- ── UserWarning table ──────────────────────────────────────────────────
-- Stores formal warnings issued by admins to users. Each warning also
-- creates a Notification (so the user sees it) + an AdminAuditLog entry.
CREATE TABLE IF NOT EXISTS "UserWarning" (
  "id"                 TEXT PRIMARY KEY,
  "userId"             TEXT NOT NULL,
  "issuedById"         TEXT,
  "reason"             TEXT NOT NULL,
  "message"            TEXT NOT NULL,
  "moderationEventId"  TEXT,
  "createdAt"          TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "UserWarning_userId_fkey"
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
  CONSTRAINT "UserWarning_issuedById_fkey"
    FOREIGN KEY ("issuedById") REFERENCES "User"("id") ON DELETE SET NULL
);

-- Indexes for the user moderation history + analytics queries.
CREATE INDEX IF NOT EXISTS "UserWarning_userId_createdAt_idx" ON "UserWarning"("userId", "createdAt");
CREATE INDEX IF NOT EXISTS "UserWarning_reason_createdAt_idx" ON "UserWarning"("reason", "createdAt");
CREATE INDEX IF NOT EXISTS "UserWarning_issuedById_idx" ON "UserWarning"("issuedById");
