-- Playlists — ordered collections of Articles (Additive — independent from
-- Topics + Collections + Posts).
-- =============================================================================
-- Creates 2 new tables + indexes. NO changes to existing tables except
-- adding 2 new optional relations on the User + Article side (handled via
-- the new FK columns below — all are nullable so existing rows are
-- unaffected).
--
-- SECURITY:
--   - ownerId is always derived from the session server-side; never
--     accepted from the client body (defense-in-depth at the API layer).
--   - articleId is a REAL foreign key (not polymorphic like
--     CollectionItem.contentId) — gives DB-level referential integrity +
--     cascade-delete when the Article is removed (spec §14).
--   - The @@unique([playlistId, articleId]) constraint enforces
--     "no duplicate items" at the DB level (spec §2).
--
-- IDempotent: every CREATE uses IF NOT EXISTS, every index uses IF NOT EXISTS.
-- Safe to run on every deploy.

-- ── Playlist ──────────────────────────────────────────────────────────
-- A user-owned, ordered bundle of published Articles. Independent from
-- the Topic system (ContentTopic / ArticleTopic / PostTopic).
CREATE TABLE IF NOT EXISTS "Playlist" (
    "id"           TEXT NOT NULL,
    "ownerId"      TEXT NOT NULL,
    "name"         TEXT NOT NULL,
    "slug"         TEXT NOT NULL,
    "description" TEXT,
    "coverImage"   TEXT,
    "isPublic"     BOOLEAN NOT NULL DEFAULT false,
    "createdAt"    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"    TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Playlist_pkey" PRIMARY KEY ("id")
);

-- Unique slug — one Playlist per slug (case-sensitive — slugs are
-- pre-normalized to lowercase in the application layer).
CREATE UNIQUE INDEX IF NOT EXISTS "Playlist_slug_key" ON "Playlist" ("slug");

-- Powers "list my playlists" + count queries for limits.
CREATE INDEX IF NOT EXISTS "Playlist_ownerId_idx" ON "Playlist" ("ownerId");
-- Powers "discover public playlists" + search. Compound is good enough
-- (Prisma can't express a partial index on isPublic=true only).
CREATE INDEX IF NOT EXISTS "Playlist_isPublic_updatedAt_idx" ON "Playlist" ("isPublic", "updatedAt");
-- Powers the SEO-friendly /playlist/[slug] lookup. The unique index above
-- already covers slug lookups efficiently; this explicit index is listed
-- for schema parity with the Prisma @@index([slug]) directive.
CREATE INDEX IF NOT EXISTS "Playlist_slug_idx" ON "Playlist" ("slug");

-- Foreign key: Playlist.owner → User.id, cascade on delete.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'Playlist_ownerId_fkey'
  ) THEN
    ALTER TABLE "Playlist"
      ADD CONSTRAINT "Playlist_ownerId_fkey"
    FOREIGN KEY ("ownerId") REFERENCES "User" ("id")
    ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;

-- ── PlaylistItem ─────────────────────────────────────────────────────
-- A single Article inside a Playlist. ONE row per (playlistId, articleId)
-- enforced by the unique constraint — duplicate items are impossible.
CREATE TABLE IF NOT EXISTS "PlaylistItem" (
    "id"          TEXT NOT NULL,
    "playlistId"  TEXT NOT NULL,
    "articleId"   TEXT NOT NULL,
    "position"    INTEGER NOT NULL DEFAULT 0,
    "addedAt"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PlaylistItem_pkey" PRIMARY KEY ("id")
);

-- SOURCE OF TRUTH for "no duplicate items in the same playlist".
CREATE UNIQUE INDEX IF NOT EXISTS "PlaylistItem_playlistId_articleId_key"
    ON "PlaylistItem" ("playlistId", "articleId");

-- Powers "list items in this playlist, ordered by position".
CREATE INDEX IF NOT EXISTS "PlaylistItem_playlistId_position_idx"
    ON "PlaylistItem" ("playlistId", "position");

-- Powers "which playlists contain this article?" (used by the Article
-- reading page to render the Playlist Navigation section + the
-- Add-to-Playlist dialog to show already-added state).
CREATE INDEX IF NOT EXISTS "PlaylistItem_articleId_idx"
    ON "PlaylistItem" ("articleId");

-- Foreign key: PlaylistItem.playlist → Playlist.id, cascade on delete
-- (deleting a Playlist removes all its items).
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'PlaylistItem_playlistId_fkey'
  ) THEN
    ALTER TABLE "PlaylistItem"
      ADD CONSTRAINT "PlaylistItem_playlistId_fkey"
    FOREIGN KEY ("playlistId") REFERENCES "Playlist" ("id")
    ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;

-- Foreign key: PlaylistItem.article → Article.id, cascade on delete.
-- This is the KEY integrity guarantee (spec §14): when an Article is
-- deleted, all PlaylistItem rows pointing to it are removed cleanly —
-- the Playlist itself stays intact, only the dangling item is gone.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'PlaylistItem_articleId_fkey'
  ) THEN
    ALTER TABLE "PlaylistItem"
      ADD CONSTRAINT "PlaylistItem_articleId_fkey"
    FOREIGN KEY ("articleId") REFERENCES "Article" ("id")
    ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;
