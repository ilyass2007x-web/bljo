-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Add AdMobApp + AdMobAdUnit tables for Google AdMob management.
--
-- IDEMPOTENT — safe to run on every deploy (Netlify build runs this before
-- `prisma db push`). Uses `CREATE TABLE IF NOT EXISTS` + `CREATE INDEX IF
-- NOT EXISTS`.
--
-- SEPARATE from AdSense (spec §4 + §30 + §31):
--   - AdSense uses the `AdUnit` table (WEB ads).
--   - AdMob uses `AdMobApp` + `AdMobAdUnit` tables (APP ads — Android/iOS).
--   - No existing table is touched. No data is migrated.
--
-- PRISMA SCHEMA LOCATION:
--   prisma/schema.prisma → `model AdMobApp` + `model AdMobAdUnit` (added in this task).
-- ────────────────────────────────────────────────────────────────────────────

-- AdMob Application — one row per platform (ANDROID / IOS).
CREATE TABLE IF NOT EXISTS "AdMobApp" (
    "id"          TEXT NOT NULL,
    "platform"    TEXT NOT NULL,
    "appName"     TEXT NOT NULL DEFAULT '',
    "packageName" TEXT,
    "admobAppId"  TEXT NOT NULL DEFAULT '',
    "enabled"     BOOLEAN NOT NULL DEFAULT false,
    "createdAt"   TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"   TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AdMobApp_pkey" PRIMARY KEY ("id")
);

-- ONE app per platform (Android + iOS). The unique constraint prevents
-- duplicate app rows for the same platform.
CREATE UNIQUE INDEX IF NOT EXISTS "AdMobApp_platform_key"
    ON "AdMobApp" ("platform");

-- AdMob Ad Unit — one row per configured ad unit (e.g. "Home Banner Android").
CREATE TABLE IF NOT EXISTS "AdMobAdUnit" (
    "id"                TEXT NOT NULL,
    "name"              TEXT NOT NULL,
    "description"       TEXT,
    "platform"          TEXT NOT NULL,
    "adUnitId"          TEXT NOT NULL,
    "format"            TEXT NOT NULL DEFAULT 'BANNER',
    "placement"         TEXT NOT NULL,
    "priority"          INTEGER NOT NULL DEFAULT 10,
    "active"            BOOLEAN NOT NULL DEFAULT true,
    "environment"       TEXT NOT NULL DEFAULT 'ALL',
    "fallbackAdUnitId"  TEXT,
    "createdAt"         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"         TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AdMobAdUnit_pkey" PRIMARY KEY ("id")
);

-- ONE ad unit per (platform, adUnitId) — prevents duplicate configuration.
CREATE UNIQUE INDEX IF NOT EXISTS "AdMobAdUnit_platform_adUnitId_key"
    ON "AdMobAdUnit" ("platform", "adUnitId");

-- Powers the mobile config API's main query:
--   "Give me all active units for platform X, ordered by placement + priority."
CREATE INDEX IF NOT EXISTS "AdMobAdUnit_platform_active_priority_idx"
    ON "AdMobAdUnit" ("platform", "active", "priority");

CREATE INDEX IF NOT EXISTS "AdMobAdUnit_placement_active_idx"
    ON "AdMobAdUnit" ("placement", "active");

CREATE INDEX IF NOT EXISTS "AdMobAdUnit_format_idx"
    ON "AdMobAdUnit" ("format");
