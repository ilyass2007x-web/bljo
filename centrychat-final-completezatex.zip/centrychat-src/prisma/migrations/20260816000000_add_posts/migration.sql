-- Migration: Add Post table for the text-posts feature (Phase 1).
--
-- This migration is documentation-only — the project uses `prisma db push`
-- (see netlify.toml `command = "bun run db:generate && npx prisma db push
-- --accept-data-loss && bun run build"`) which syncs the schema directly
-- against the live Neon database on every deploy. We keep this SQL file
-- for review/audit purposes and so it can be applied manually if needed.
--
-- Post table stores short text posts (max 280 chars enforced in app code).
-- Phase 1 is TEXT ONLY — no images, videos, or other media.

CREATE TABLE IF NOT EXISTS "Post" (
    "id"        TEXT NOT NULL,
    "authorId"  TEXT NOT NULL,
    "content"   TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Post_pkey" PRIMARY KEY ("id")
);

-- Index: list posts by a specific author, newest first.
-- Used by future "user profile → posts" view.
CREATE INDEX IF NOT EXISTS "Post_authorId_createdAt_idx"
    ON "Post"("authorId", "createdAt");

-- Index: cursor-based pagination across all posts (home feed).
-- The composite (createdAt, id) index supports
--   ORDER BY "createdAt" DESC, "id" DESC
--   WHERE ("createdAt", "id") < (cursor.createdAt, cursor.id)
-- which is the seek-pattern used by GET /api/v1/posts.
CREATE INDEX IF NOT EXISTS "Post_createdAt_id_idx"
    ON "Post"("createdAt", "id");

-- Foreign key: when a User is deleted, their posts are deleted too
-- (onDelete: Cascade — matches the existing Message / Notification pattern).
-- LEGACY GUARD: wrapped in DO block so the migration is idempotent.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'Post_authorId_fkey'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Post'
  ) THEN
    ALTER TABLE "Post"
      ADD CONSTRAINT "Post_authorId_fkey"
      FOREIGN KEY ("authorId") REFERENCES "User"("id")
      ON DELETE CASCADE;
  END IF;
END $$;
