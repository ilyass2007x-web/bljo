-- Additive migration: adds a nullable `directKey` column with a UNIQUE
-- constraint to the Conversation table.
--
-- Purpose:
--   Enables an atomic find-or-create (upsert) for DIRECT conversations
--   between two specific users. Without this, two concurrent "Message"
--   button clicks (e.g. a user double-clicking) could BOTH pass the
--   "existing?" check, BOTH call prisma.conversation.create, and produce
--   two duplicate DIRECT conversations for the same pair of users.
--
--   The `directKey` is computed as `[userIdA, userIdB].sort().join(":")`,
--   which is order-independent (so userA↔userB and userB↔userA produce
--   the same key). The UNIQUE constraint at the DB level is the source
--   of truth — concurrent inserts race, but only one wins (the other gets
--   P2002 and re-fetches the just-created row).
--
--   For group conversations, `directKey` remains NULL. PostgreSQL's
--   UNIQUE constraint treats NULLs as distinct, so multiple group rows
--   coexist fine.
--
-- Safety:
--   - Additive only — adds a column, no existing column is removed or
--     renamed, no existing row is rejected (all existing rows get NULL
--     for the new column, which the UNIQUE constraint allows).
--   - Backfill of existing DIRECT conversations is done at the APPLICATION
--     level (lazy backfill in getOrCreateDirectConversation). The first
--     time a legacy DIRECT conversation is re-opened, the app sets its
--     directKey. New conversations always get a directKey at creation.
--
-- LEGACY GUARD (added 2026-09):
--   The Conversation table may not exist on legacy Production DBs.
--   Wrapped in a DO block — no-op when the table is missing.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Conversation'
  ) THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'Conversation' AND column_name = 'directKey'
    ) THEN
      ALTER TABLE "Conversation" ADD COLUMN "directKey" TEXT;
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM pg_indexes WHERE indexname = 'Conversation_directKey_key'
    ) THEN
      CREATE UNIQUE INDEX "Conversation_directKey_key" ON "Conversation"("directKey");
    END IF;
  END IF;
END $$;
