-- ──────────────────────────────────────────────────────────────────────────
-- Phase 2D — Search Quality: Multilingual Arabic Normalization + Multi-word
-- ──────────────────────────────────────────────────────────────────────────
--
-- PURPOSE:
--   Adds 10 normalized text columns (one per searchable field) + 10 GIN
--   trigram indexes on those columns. The normalized columns are populated
--   at write time by the Prisma Client extension in src/lib/database/index.ts
--   (intercepts create/update on User, Post, Article, Collection, Playlist).
--   Existing rows are backfilled by a separate TypeScript script:
--     scripts/backfill-normalized-search-fields.ts
--   (run manually after this migration, before deploying the search route
--   change that uses the normalized columns).
--
-- WHY NORMALIZED COLUMNS (Option C from the Phase 2D-A audit):
--   - Query-only normalization is insufficient for Arabic — the column
--     stores un-normalized text (e.g. `أحمد` with U+0623) and the query
--     normalizes to `احمد` (U+0627), so `ILIKE '%احمد%'` does NOT match
--     the stored `أحمد`. Both sides must be normalized.
--   - Stored normalized columns allow GIN trigram indexes on the
--     normalized form, preserving the existing pg_trgm retrieval path.
--   - Prisma-friendly: no expression indexes, no PL/pgSQL functions, no
--     `unaccent` extension. Just plain columns + plain GIN indexes.
--
-- NULLABILITY:
--   All new columns are NULLABLE. This is intentional:
--     1. ALTER TABLE ADD COLUMN on a non-empty table would fail with NOT NULL.
--     2. The backfill script populates existing rows AFTER this migration.
--     3. The Prisma Client extension sets the normalized value on every
--        new create/update, so future rows are never NULL.
--   A follow-up migration (NOT in this phase) could ALTER to NOT NULL
--   after backfill is verified, but for now nullable is the safe default.
--
-- INDEX NAMING CONVENTION:
--   Mirrors the existing pg_trgm migration
--   (20260922000000_add_pg_trgm_search): `<Table>_<column>_trgm_idx`.
--   The normalized columns use the same suffix to keep index discovery
--   via `pg_indexes WHERE indexname ILIKE '%trgm%'` working uniformly.
--
-- BACKFILL STRATEGY (run AFTER this migration, BEFORE deploying the
-- search route change):
--   The backfill is done in TypeScript (not SQL) because the normalize
--   function lives in `src/lib/search/normalize.ts` — writing it in
--   PL/pgSQL would duplicate the logic. The backfill script reads rows
--   in batches of 1000, normalizes in TS, and writes back via
--   `db.$executeRawUnsafe`. See:
--     scripts/backfill-normalized-search-fields.ts
--
-- SAFETY:
--   - All statements are idempotent (ADD COLUMN IF NOT EXISTS, CREATE INDEX
--     IF NOT EXISTS).
--   - No data is deleted or modified.
--   - No existing indexes are dropped.
--   - No schema constraints are added that would fail on existing rows.
--   - The backfill UPDATEs are in a SEPARATE script (not this migration)
--     so they can be re-run + monitored independently.
-- ──────────────────────────────────────────────────────────────────────────

-- ── User: usernameNormalized + fullNameNormalized ─────────────────────────
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "usernameNormalized" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "fullNameNormalized" TEXT;

-- ── Post: contentNormalized ──────────────────────────────────────────────
-- LEGACY GUARD: Post table may not exist on legacy Production DBs.
-- Wrapped in DO block — no-op when Post is missing.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Post'
  ) THEN
    ALTER TABLE "Post" ADD COLUMN IF NOT EXISTS "contentNormalized" TEXT;
  END IF;
END $$;

-- ── Article: titleNormalized + excerptNormalized + contentNormalized ─────
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "titleNormalized" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "excerptNormalized" TEXT;
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "contentNormalized" TEXT;

-- ── Collection: nameNormalized + descriptionNormalized ───────────────────
ALTER TABLE "Collection" ADD COLUMN IF NOT EXISTS "nameNormalized" TEXT;
ALTER TABLE "Collection" ADD COLUMN IF NOT EXISTS "descriptionNormalized" TEXT;

-- ── Playlist: nameNormalized + descriptionNormalized ─────────────────────
ALTER TABLE "Playlist" ADD COLUMN IF NOT EXISTS "nameNormalized" TEXT;
ALTER TABLE "Playlist" ADD COLUMN IF NOT EXISTS "descriptionNormalized" TEXT;

-- ── GIN trigram indexes on normalized columns ────────────────────────────
-- Same `gin_trgm_ops` operator class as the existing pg_trgm migration.
-- These indexes accelerate:
--   1. `ILIKE '%foo%'` on normalized columns (Phase 2D ILIKE path)
--   2. `column % 'query'` on normalized columns (Phase 2D typo path)
-- Idempotent — safe to re-run.

CREATE INDEX IF NOT EXISTS "User_usernameNormalized_trgm_idx"
  ON "User" USING gin ("usernameNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "User_fullNameNormalized_trgm_idx"
  ON "User" USING gin ("fullNameNormalized" gin_trgm_ops);

-- LEGACY GUARD: Post table may not exist on legacy Production DBs.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Post'
  ) THEN
    CREATE INDEX IF NOT EXISTS "Post_contentNormalized_trgm_idx"
      ON "Post" USING gin ("contentNormalized" gin_trgm_ops);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS "Article_titleNormalized_trgm_idx"
  ON "Article" USING gin ("titleNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "Article_excerptNormalized_trgm_idx"
  ON "Article" USING gin ("excerptNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "Article_contentNormalized_trgm_idx"
  ON "Article" USING gin ("contentNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "Collection_nameNormalized_trgm_idx"
  ON "Collection" USING gin ("nameNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "Collection_descriptionNormalized_trgm_idx"
  ON "Collection" USING gin ("descriptionNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "Playlist_nameNormalized_trgm_idx"
  ON "Playlist" USING gin ("nameNormalized" gin_trgm_ops);

CREATE INDEX IF NOT EXISTS "Playlist_descriptionNormalized_trgm_idx"
  ON "Playlist" USING gin ("descriptionNormalized" gin_trgm_ops);
