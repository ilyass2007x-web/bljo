-- ──────────────────────────────────────────────────────────────────────────
-- Migration: add_article_image_config
-- Purpose  : Phase 18 — store the article cover image presentation
--            configuration (zoom + position) so the visual composition
--            chosen during article creation is reproduced in the
--            published article card + reading page.
--
-- Pure ALTER TABLE ADD COLUMN — no DROP, no data migration, no schema
-- resets. All three new columns are NULLABLE so existing rows are
-- unaffected. The renderer treats NULL as the natural default state:
--   - zoom     = 1.0  (100%)
--   - position = center (translateX=0, translateY=0)
--
-- The original coverImage URL column is NOT modified. No new image
-- files are stored — only the visual configuration floats alongside
-- the existing URL. Backward compatibility for old Pinterest / direct
-- image / og:image articles is preserved automatically.
-- ──────────────────────────────────────────────────────────────────────────

-- Zoom multiplier (1.0 = 100%, 3.0 = 300%). Validated server-side.
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "imageZoom" DOUBLE PRECISION;

-- Horizontal translate offset as a fraction of container width.
-- Range: -1.0 (full left) to 1.0 (full right). 0 = centered.
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "imagePositionX" DOUBLE PRECISION;

-- Vertical translate offset as a fraction of container height.
-- Range: -1.0 (full up) to 1.0 (full down). 0 = centered.
ALTER TABLE "Article" ADD COLUMN IF NOT EXISTS "imagePositionY" DOUBLE PRECISION;
