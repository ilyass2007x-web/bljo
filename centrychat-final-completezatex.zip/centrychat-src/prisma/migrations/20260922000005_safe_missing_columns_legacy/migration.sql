-- ──────────────────────────────────────────────────────────────────────────
-- SAFE ADDITIVE MISSING COLUMNS — Legacy Compatibility
-- ──────────────────────────────────────────────────────────────────────────
--
-- PURPOSE:
--   Adds columns that schema.prisma expects but Production doesn't have
--   on EXISTING tables (User, Notification, ArticleLike, ArticleView).
--   These columns are referenced by the deployed application code, so
--   without them Prisma queries fail with:
--     "The column X.Y does not exist in the current database"
--
-- SAFETY:
--   - All ALTER TABLE ADD COLUMN use IF NOT EXISTS (idempotent).
--   - All new columns are NULLABLE or have safe defaults.
--   - No DROP, no RENAME, no TYPE change, no data loss.
--   - Safe to re-run on every deploy.
--
-- COLUMN BACKFILL:
--   Where there's a clear 1:1 mapping (e.g. User.fullName ← User.name),
--   an UPDATE statement backfills the new column from the legacy one.
--   These UPDATEs are idempotent — they only set rows where the new
--   column is NULL.
--
-- AFFECTED TABLES / COLUMNS:
--   User:        gender, dateOfBirth, language, notificationPrefs
--   Notification: message (← backfilled from body), readAt,
--                 targetType, targetId, conversationId, messageId,
--                 senderId, metadata
--   ArticleLike: id (NOT added — Production uses composite PK; adding an
--                 `id` column would require dropping the existing PK,
--                 which is destructive. The schema.prisma ArticleLike
--                 model expects an `id` column, but the deployed app
--                 code that creates ArticleLikes will generate cuid()
--                 IDs at the application layer — Prisma will then fail
--                 because the column doesn't exist. To avoid breaking
--                 the deployed app, we DO add the `id` column as nullable
--                 with a default of NULL — old rows have NULL, new rows
--                 get a Prisma-generated cuid.)
--   ArticleView: viewedAt (← backfilled from createdAt)
-- ──────────────────────────────────────────────────────────────────────────

-- ── 1. User: add gender, dateOfBirth, language, notificationPrefs ──
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "gender" TEXT;
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "dateOfBirth" TIMESTAMP(3);
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "language" TEXT NOT NULL DEFAULT 'en';
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "notificationPrefs" TEXT;

-- ── 2. Notification: add message + readAt + targeting fields ──
-- Production uses "body"; schema.prisma expects "message".
-- Add the "message" column + backfill from "body" (idempotent).
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "message" TEXT;
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "readAt" TIMESTAMP(3);
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "targetType" TEXT;
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "targetId" TEXT;
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "conversationId" TEXT;
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "messageId" TEXT;
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "senderId" TEXT;
ALTER TABLE "Notification" ADD COLUMN IF NOT EXISTS "metadata" TEXT;

-- Backfill Notification.message from Notification.body (legacy column).
-- Idempotent — only fills rows where message is NULL.
UPDATE "Notification"
SET "message" = "body"
WHERE "message" IS NULL AND "body" IS NOT NULL;

-- ── 3. ArticleLike: add `id` column ──
-- Production uses a composite PK (userId, articleId). schema.prisma
-- expects a separate `id` column (cuid). We add the `id` column as
-- nullable text so existing rows aren't rejected; new likes will have
-- Prisma-generated cuid() values.
--
-- IMPORTANT: this does NOT drop the existing composite PK. The
-- existing PK stays in place — adding a nullable column is additive
-- and doesn't conflict with the existing PK. Prisma's ArticleLike
-- model uses @id on `id` and @@unique([articleId, userId]), so the
-- unique constraint will be needed too. The unique index
-- ArticleLike_articleId_userId_key already exists in Production
-- (created by a prior migration).
ALTER TABLE "ArticleLike" ADD COLUMN IF NOT EXISTS "id" TEXT;

-- ── 4. ArticleView: add viewedAt ──
-- Production uses "createdAt"; schema.prisma expects "viewedAt".
-- Add the "viewedAt" column + backfill from "createdAt" (idempotent).
ALTER TABLE "ArticleView" ADD COLUMN IF NOT EXISTS "viewedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

UPDATE "ArticleView"
SET "viewedAt" = "createdAt"
WHERE "viewedAt" IS NULL OR "viewedAt" = CURRENT_TIMESTAMP;
