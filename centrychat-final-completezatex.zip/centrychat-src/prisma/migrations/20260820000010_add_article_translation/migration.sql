-- ────────────────────────────────────────────────────────────────────────────
-- Migration: Add ArticleTranslation table for AI-translated article content.
--
-- IDEMPOTENT — safe to run on every deploy (Netlify build runs this before
-- `prisma db push`). Uses `CREATE TABLE IF NOT EXISTS` + `CREATE INDEX IF
-- NOT EXISTS`.
--
-- SECURITY:
--   - No data is migrated (new table — no existing rows).
--   - No existing table is touched.
--   - Indexes are also IF NOT EXISTS.
--
-- PRISMA SCHEMA LOCATION:
--   prisma/schema.prisma → `model ArticleTranslation` (added in this task).
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "ArticleTranslation" (
    "id"                     TEXT NOT NULL,
    "articleId"              TEXT NOT NULL,
    "languageCode"           TEXT NOT NULL,
    "translatedTitle"        TEXT NOT NULL,
    "translatedDescription"  TEXT,
    "translatedContent"      TEXT NOT NULL,
    "sourceContentHash"      TEXT NOT NULL,
    "model"                  TEXT,
    "createdAt"              TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"              TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ArticleTranslation_pkey" PRIMARY KEY ("id")
);

-- UNIQUE: one translation per (article, language). Re-requests return the
-- cached row WITHOUT calling the LLM API (saves cost + latency).
CREATE UNIQUE INDEX IF NOT EXISTS "ArticleTranslation_articleId_languageCode_key"
    ON "ArticleTranslation" ("articleId", "languageCode");

-- Powers "get all translations for article X" (used by the invalidation
-- path on article edit/delete).
CREATE INDEX IF NOT EXISTS "ArticleTranslation_articleId_idx"
    ON "ArticleTranslation" ("articleId");

-- Powers "get translations in language Y" (future analytics — not used today).
CREATE INDEX IF NOT EXISTS "ArticleTranslation_languageCode_idx"
    ON "ArticleTranslation" ("languageCode");
