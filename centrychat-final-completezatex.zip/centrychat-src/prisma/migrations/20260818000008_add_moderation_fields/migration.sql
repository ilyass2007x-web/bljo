-- ──────────────────────────────────────────────────────────────────────────
-- Migration: add_moderation_fields
-- Purpose : Add moderation fields to the Report model (spec §4 PHASE 4).
--
-- Pure ALTER TABLE ADD COLUMN — no DROP, no data migration.
-- All new columns are nullable (or have defaults) so existing rows
-- are unaffected. The user-facing report form does NOT change — only
-- the admin moderation center uses these new fields.
--
-- LEGACY GUARD (added 2026-09):
--   The Report table may not exist on legacy Production DBs.
--   Wrapped in a DO block — no-op when the table is missing.
-- ──────────────────────────────────────────────────────────────────────────

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = current_schema() AND table_name = 'Report'
  ) THEN
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'targetPostId'
    ) THEN
      ALTER TABLE "Report" ADD COLUMN "targetPostId" TEXT;
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'targetArticleId'
    ) THEN
      ALTER TABLE "Report" ADD COLUMN "targetArticleId" TEXT;
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'targetCommentId'
    ) THEN
      ALTER TABLE "Report" ADD COLUMN "targetCommentId" TEXT;
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'priority'
    ) THEN
      ALTER TABLE "Report" ADD COLUMN "priority" TEXT NOT NULL DEFAULT 'NORMAL';
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'assignedToId'
    ) THEN
      ALTER TABLE "Report" ADD COLUMN "assignedToId" TEXT;
    END IF;
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = current_schema() AND table_name = 'Report' AND column_name = 'notes'
    ) THEN
      ALTER TABLE "Report" ADD COLUMN "notes" TEXT;
    END IF;

    CREATE INDEX IF NOT EXISTS "Report_priority_idx" ON "Report"("priority");
    CREATE INDEX IF NOT EXISTS "Report_assignedToId_idx" ON "Report"("assignedToId");
  END IF;
END $$;
