-- ──────────────────────────────────────────────────────────────────────────
-- Video Chat — Block + VideoChatSession + VideoChatReport
-- ──────────────────────────────────────────────────────────────────────────
-- Creates three new tables for the Centry Global Video Chat feature:
--   1. Block             — user-to-user blocking (mirrors Follow)
--   2. VideoChatSession  — call metadata (participants, duration, connection type)
--   3. VideoChatReport   — video-chat-specific abuse reports
--
-- IDEMPOTENT: every statement uses IF NOT EXISTS so re-running on an
-- already-migrated database is a no-op. Safe to run on every deploy.
--
-- BACKWARD COMPATIBLE:
--   - No existing tables or columns are modified.
--   - No existing data is touched.
--   - The new tables start empty — no video chat activity until the admin
--     enables the feature flag + users start calls.
--
-- PRIVACY: VideoChatSession stores ONLY metadata (timestamps, duration,
-- connection type). NEVER stores video/audio frames, recordings, or stream
-- content. VideoChatReport stores only the report reason + optional text.
-- ──────────────────────────────────────────────────────────────────────────

-- ── Block table (user-to-user blocking) ────────────────────────────────
CREATE TABLE IF NOT EXISTS "Block" (
  "id"         TEXT PRIMARY KEY,
  "blockerId"  TEXT NOT NULL,
  "blockedId"  TEXT NOT NULL,
  "createdAt"  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "Block_blockerId_fkey"
    FOREIGN KEY ("blockerId") REFERENCES "User"("id") ON DELETE CASCADE,
  CONSTRAINT "Block_blockedId_fkey"
    FOREIGN KEY ("blockedId") REFERENCES "User"("id") ON DELETE CASCADE
);

-- UNIQUE constraint prevents duplicate block rows.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'Block_blockerId_blockedId_key'
  ) THEN
    ALTER TABLE "Block" ADD CONSTRAINT "Block_blockerId_blockedId_key" UNIQUE ("blockerId", "blockedId");
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS "Block_blockedId_idx" ON "Block"("blockedId");
CREATE INDEX IF NOT EXISTS "Block_blockerId_idx" ON "Block"("blockerId");

-- ── VideoChatSession table ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "VideoChatSession" (
  "id"             TEXT PRIMARY KEY,
  "userAId"        TEXT NOT NULL,
  "userBId"        TEXT NOT NULL,
  "startedAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "connectedAt"    TIMESTAMP(3),
  "endedAt"        TIMESTAMP(3),
  "durationSec"    INTEGER,
  "endReason"      TEXT,
  "connectionType" TEXT,

  CONSTRAINT "VideoChatSession_userAId_fkey"
    FOREIGN KEY ("userAId") REFERENCES "User"("id") ON DELETE CASCADE,
  CONSTRAINT "VideoChatSession_userBId_fkey"
    FOREIGN KEY ("userBId") REFERENCES "User"("id") ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS "VideoChatSession_userAId_startedAt_idx"
  ON "VideoChatSession"("userAId", "startedAt");
CREATE INDEX IF NOT EXISTS "VideoChatSession_userBId_startedAt_idx"
  ON "VideoChatSession"("userBId", "startedAt");
CREATE INDEX IF NOT EXISTS "VideoChatSession_startedAt_idx"
  ON "VideoChatSession"("startedAt");
CREATE INDEX IF NOT EXISTS "VideoChatSession_connectionType_idx"
  ON "VideoChatSession"("connectionType");

-- ── VideoChatReport table ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "VideoChatReport" (
  "id"           TEXT PRIMARY KEY,
  "sessionId"    TEXT NOT NULL,
  "reporterId"   TEXT NOT NULL,
  "reportedId"   TEXT NOT NULL,
  "reason"       TEXT NOT NULL,
  "description"  TEXT,
  "status"       TEXT NOT NULL DEFAULT 'OPEN',
  "reviewedById" TEXT,
  "reviewedAt"   TIMESTAMP(3),
  "createdAt"    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "VideoChatReport_sessionId_fkey"
    FOREIGN KEY ("sessionId") REFERENCES "VideoChatSession"("id") ON DELETE CASCADE,
  CONSTRAINT "VideoChatReport_reporterId_fkey"
    FOREIGN KEY ("reporterId") REFERENCES "User"("id") ON DELETE CASCADE,
  CONSTRAINT "VideoChatReport_reportedId_fkey"
    FOREIGN KEY ("reportedId") REFERENCES "User"("id") ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS "VideoChatReport_sessionId_idx"
  ON "VideoChatReport"("sessionId");
CREATE INDEX IF NOT EXISTS "VideoChatReport_reportedId_createdAt_idx"
  ON "VideoChatReport"("reportedId", "createdAt");
CREATE INDEX IF NOT EXISTS "VideoChatReport_status_createdAt_idx"
  ON "VideoChatReport"("status", "createdAt");
